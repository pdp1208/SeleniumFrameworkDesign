package com.oracle.pgbu.selenium.common.reportms.steps;

import com.oracle.pgbu.selenium.common.reportms.pages.FilterDialog;
import com.oracle.pgbu.selenium.common.reportms.pages.ListTemplate;
import com.oracle.pgbu.selenium.common.reportms.pages.ReportEditorPage;
import com.oracle.pgbu.selenium.common.reportms.pages.bip.BIPLayoutEditor;
import com.oracle.pgbu.selenium.common.reportms.pages.bip.BIPublisherPage;

import java.util.List;
import java.util.Map;

/**
 * This class contains implementation of common functional flows related to report microservice which will remain consistent irrespective of products.
 */
public class ReportCommonMethods {

    public Application application;
    public ReportEditorPage reportEditorePage;
    public BIPublisherPage bip = new BIPublisherPage();
    public BIPLayoutEditor bipLayoutEditor;

    public static final String REPORT_LIST_WINDOW_TITAL = "Aconex";
    public static final String DOWNLOAD_LOCATION = "C:\\Users\\USER\\Downloads\\";
    public static final String BIP_LAYOUT_TYPE = "Blank (Landscape)";
    public static final String PAGE_SIZE = "A3";

    /**
     * Method to verify create,ad bip layout, download report and data verification.
     *
     * @param reportName - Name of the report
     * @param subjectAreaAndColumns - Map containing subject areas as key and list columns as value.
     * @param expReportDirName - Location of expected report which is required at the time of actual and expected report comparison.
     */
    public void createReportAndVerify(String reportName, Map<String, List<String>> subjectAreaAndColumns, String parentSubjectArea, String expReportDirName) throws Exception {
        createReportAndAddBIPLayout(reportName, subjectAreaAndColumns, parentSubjectArea);
        downloadAndVerifyReport(reportName, reportName, expReportDirName);
    }

    /**
     * Method to create report by adding subject areas and columns to the report.
     *
     * @param reportName - Name of the report
     * @param subjectAreaAndColumns - Map containing subject areas as key and list columns as value.
     */
    public void createReport(String reportName, Map<String, List<String>> subjectAreaAndColumns, String parentSubjectArea) throws Exception {
        application.navigateToReportEditorPage();
        reportEditorePage.switchToFrame();
        reportEditorePage.waitForLoaderToDisappear();
        reportEditorePage.editReportName(reportName);
        reportEditorePage.addSubjectAreasAndColumns(subjectAreaAndColumns, true, parentSubjectArea);
        reportEditorePage.saveReportEditorPage();
    }

    /**
     * Method to create report by adding subject areas and columns to the report.
     *
     * @param reportName - Name of the report
     * @param subjectAreaAndColumns - Map containing subject areas as key and list columns as value.
     */
    public void createReportAndCloseEditor(String reportName, Map<String, List<String>> subjectAreaAndColumns, String parentSubjectArea) throws Exception {
        createReport(reportName, subjectAreaAndColumns, parentSubjectArea);
        reportEditorePage.closeReportEditorPage();
        application.waitForLoaderToDisappear();
    }

    /**
     * Method to create report and adding bip layout for the report..
     *
     * @param reportName - Name of the report
     * @param subjectAreaAndColumns - Map containing subject areas as key and list columns as value.
     */
    public void createReportAndAddBIPLayout(String reportName, Map<String, List<String>> subjectAreaAndColumns, String parentSubjectArea) throws Exception {
        createReport(reportName, subjectAreaAndColumns, parentSubjectArea);
        application.navigateToReportListPage();
        openBIPLayoutEdiroPage(reportName);
        addBIPLayout(reportName, subjectAreaAndColumns, "");
        switchWindowWithTitle(REPORT_LIST_WINDOW_TITAL, true);
        application.navigateToReportListPage();
    }

    /**
     * Method to add bip layout for the report..
     *
     * @param reportName - Name of the report
     * @param subjectAreaAndColumns - Map containing subject areas as key and list columns as value.
     */
    public void addBIPLayout(String reportName, Map<String, List<String>> subjectAreaAndColumns, String mainSubjectArea){
        bip.selectLayout(BIP_LAYOUT_TYPE);
        bipLayoutEditor = new BIPLayoutEditor();
        bipLayoutEditor.selectSize(PAGE_SIZE);
        bipLayoutEditor.selectColumns(subjectAreaAndColumns, true, mainSubjectArea);
        bipLayoutEditor.saveLayout(reportName);
    }

    /**
     * Method to add bip layout for the report..
     *
     * @param subjectAreaAndColumns - Map containing subject areas as key and list columns as value.
     * @param mainSubjectArea - main subject area.
     */
    public void addBIPLayout(Map<String, List<String>> subjectAreaAndColumns, String mainSubjectArea){
        bip.selectLayout(BIP_LAYOUT_TYPE);
        bipLayoutEditor = new BIPLayoutEditor();
        bipLayoutEditor.selectSize(PAGE_SIZE);
        bipLayoutEditor.selectColumns(subjectAreaAndColumns, true, mainSubjectArea);
    }

    /**
     * Method to save layout.
     *
     * @param layoutName - Name of the layout.
     */
    public void saveLayout(String layoutName){
        bipLayoutEditor.saveLayout(layoutName);
    }

    public void downloadAndVerifyReport(String reportName, String layoutname, String expReportDirName) throws Exception {
        application.downloadReport(reportName, layoutname, "As HTML");
        verifyReport(expReportDirName, reportName, true);
    }

    /**
     * Method to download the report and to compare it with expected report.
     *
     * @param reportName - Name of the report
     * @param layoutname - Name of the bip layout.
     * @param expReportDirName - Location of expected report which is required at the time of actual and expected report comparison.
     */
    public void downloadAndVerifyReportWithDefaultLayout(String reportName, String layoutname, String expReportDirName) throws Exception {
        application.downloadReport(reportName, layoutname, "As HTML");
        verifyReport(expReportDirName, reportName, true);
    }

    /**
     * Method to compare actual and expected reports.
     *
     * @param expReportDirName - Location of expected report which is required at the time of actual and expected report comparison.
     * @param reportName - Name of the report
     * @param verifyActiualFile - boolean value to specify the source of actual data (actual file or REST call).
     */
    public void verifyReport(String expReportDirName, String reportName, boolean verifyActiualFile) throws Exception {
        String downloadLocation = DOWNLOAD_LOCATION.replace("USER", System.getProperty("user.name"));
        application.verifyReport(expReportDirName, downloadLocation, reportName, verifyActiualFile);
    }

    /**
     * Method to delete the report.
     *
     * @param name - Name of the report
     */
    public void deleteReport(String name){
        application.deleteReport(name);
    }

    /**
     * Method to check that report with specified name is not listed on report list page.
     *
     * @param name - Name of the report
     */
    public void verifyReportNotListed(String name){
        application.verifyReportNameNotListed(name);
    }

    /**
     * Method to check that report with specified name is listed on report list page.
     *
     * @param name - Name of the report
     */
    public void verifyReportIsListed(String name){
        application.verifyReportNameIsListed(name);
    }

    /**
     * Method to export report to xml.
     *
     * @param name - Name of the report
     */
    public void exportReportToXML(String name){
        application.exporReporttToXML(name);
    }

    /**
     * Method to navigate to report list page.
     *
     */
    public void navigateToReportListPage(){
        application.navigateToReportListPage();
    }

    /**
     * Method to switch to another window based on the title.
     *
     * @param windowTitle - Title of the window.
     * @param closeCurrentWindow - boolean value to specify if currrent window needs to be closed after switching to another window.
     */
    public void switchWindowWithTitle(String windowTitle, boolean closeCurrentWindow){
        bip.switchToWindowContaningTitle(REPORT_LIST_WINDOW_TITAL, true);
    }

    /**
     * Method to open BIP editor page.
     *
     * @param reportName - Name of the repotr for which we need to add bip layout.
     */
    public void openBIPLayoutEdiroPage(String reportName){
        application.openBIPLayoutEditor(reportName);
    }

    /**
     * Method to add filter in the report.
     *
     * @param subjectArea - name of the subject area for whihc we want to apply filters.
     * @param field - Name of the filter field.
     * @param operator - name of the filter operator.
     * @param value - Filter value.
     * @param save - boolean value to specify filters needs to be saved.
     * @param openDialog - boolean value to specify if filter dialog needs to be open.
     * @param promptAtRun - boolean value for setting propmtAtRun option.
     */
    public void addFilter(String subjectArea, String field, String operator, List<String> value, boolean openDialog, boolean save, boolean promptAtRun) {
        if(openDialog) {
            ListTemplate subjectAreaTemplate = reportEditorePage.selectListTempate(subjectArea);
            subjectAreaTemplate.openFilterFields();
        }
        FilterDialog filterDialog = new FilterDialog();
        if(promptAtRun!=filterDialog.checkPromptAtRun()){
            filterDialog.enablePromptAtRun();
        }
        filterDialog.getNextFilterRowLocator();
        filterDialog.selectFilterField(field);
        filterDialog.selectOperator(operator);
        filterDialog.selectValue(value);
        if(save) {
            filterDialog.apply();
        }
    }

    /**
     * Method to edit existing BIP layout.
     *
     * @param layoutName - Name of the layout.
     * @param columnToBeDeleted - List column names to be deleted.
     * @param subjectAreaAndColumns - Map with subject area and column names.
     * @param mainSubjectArea - Main subject area name.
     * @param addDataTable - if new data table needs to be added.
     */
    public void editBIPLayout(String layoutName, String columnToBeDeleted, Map<String, List<String>> subjectAreaAndColumns, String mainSubjectArea, boolean addDataTable){
        bipLayoutEditor = bip.editLayout(layoutName);
        if(!columnToBeDeleted.isEmpty()) {
            bipLayoutEditor.deleteColumnFromDataTable(columnToBeDeleted);
        }
        if(!subjectAreaAndColumns.isEmpty()){
            bipLayoutEditor.selectColumns(subjectAreaAndColumns, addDataTable, mainSubjectArea);
        }
        bipLayoutEditor.save.click();
        bipLayoutEditor.done.click();
    }

    /**
     * Method to add columns to BIP layout.
     *
     * @param subjectAreaAndColumns - Map with subject area and column names.
     * @param addDataTable - If new data table needs to be added.
     * @param mainSubjectArea - Main subject area name.
     */
    public void addColumnsToBIPLayout(Map<String, List<String>> subjectAreaAndColumns, boolean addDataTable, String mainSubjectArea){
        bipLayoutEditor.selectColumns(subjectAreaAndColumns, addDataTable, mainSubjectArea);
    }

    /**
     * Method to switch to report list page.
     *
     */
    public void switchToReportListWindow(){
        switchWindowWithTitle(REPORT_LIST_WINDOW_TITAL, true);
    }

    public void openFilterForSubjectArea(String subjectArea){
        ListTemplate subjectAreaTemplate = reportEditorePage.selectListTempate(subjectArea);
        subjectAreaTemplate.openFilterFields();
    }

    /**
     * Method to change state of prompt at run flag.
     *
     * @param promtAtRun - True for enabling and false for disabling.
     */
    public void setPromptAtRun(boolean promtAtRun){
        FilterDialog filterDialog = new FilterDialog();
        if(promtAtRun!=filterDialog.promptAtRunCheckbox.isSelected()){
            filterDialog.enablePromptAtRun();
            filterDialog.apply();
        } else {
            filterDialog.cancel();
        }
    }

    /**
     * Method to perform action for filter.
     *
     * @param action - Action to perform.
     * @param fields - List of filter fields.
     */
    public void selectsActionforFiltersAppliedToFields(String action, List<String> fields){
        FilterDialog filterDialog = new FilterDialog();
        for(String field : fields){
            filterDialog.selectActionForFilter(action, field);
        }
        filterDialog.apply();
    }

    /**
     * Method to enable csv formating for bip layout.
     *
     * @param layoutName - Layout name.
     */
    public void enableCSVFormatForLayout(String layoutName){
        bip.enableCSVFormatForLayout(layoutName);
    }

    /**
     * Method to upload bip layout.
     *
     * @param template - template to upload.
     */
    public void uploadTemplate(String template,String locale,String layoutName){
        bip.uploadTemplate(template, locale, layoutName);
    }
}