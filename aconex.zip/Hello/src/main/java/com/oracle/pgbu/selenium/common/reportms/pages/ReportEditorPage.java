package com.oracle.pgbu.selenium.common.reportms.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.*;

/**
 * This is a page object class for report editor page.
 *
 */
public class ReportEditorPage extends BasePage {

    @FindBy(css = ".edit-report-name-button")
    private WebElement editReportNameButton;

    @FindBy(css = ".orcl-text-field>input")
    private WebElement reportnameInputBox;

    @FindBy(css = "#main-subject-areas-list  li .item-delete")
    private WebElement rmDefaultSubjectArea;

    @FindBy(css = "#main-subject-areas  .pgbu-icon-chevron-right")
    private WebElement expendSubjectArea;

    @FindBy(css = "#main-subject-area-body  .add-column-search-typeahead")
    private WebElement searchBox;

    @FindBy(css = "#main-subject-areas-container .btn.btn-action")
    private WebElement okbtn;

    @FindBy(css = "button.save-button")
    private WebElement save;

    @FindBy(css = "#support-subject-areas")
    private WebElement expandSupportingSubArea;

    @FindBy(css = ".reports-editor-modal .auiModal-close")
    private WebElement close;

    @FindBy(css = "#report-description")
    private WebElement reportDescriptionInputBox;

    private By subjectAreaPopup = By.cssSelector(".in.flyout");
    private By loading = By.cssSelector(".list-view-gc .loading-spinner-large");


    private By editDescriptionButton = By.xpath("//button[contains(@class,'description')][contains(@class,'edit')]");
    private By includeHistoricalDataCheckbox = By.cssSelector("#show_document_revision");
    private By editorModalLocator = By.xpath("//div[contains(@class, 'modal-backdrop')]");
    private By saveLocator = By.cssSelector(".save-cancel-controls .save, .save-cancel-controls .save-button, .save-cancel-controls .saveDraft");
    private By saveCancelControlsLocator = By.cssSelector("div.save-cancel-controls.in");
    private By frameLocator = By.cssSelector(".page-iframe");
    private By closeButtonLocator = By.cssSelector(".reports-editor-modal .auiModal-close");
    private By spinner = By.cssSelector(".spinner-large.loading-spinner-large");
    private By loader = By.cssSelector(".list-view-gc .loading-spinner-large");
    private By editorflyout = By.cssSelector(".in.flyout");
    private By edit = By.cssSelector(".edit-report-name-button");
    private By tableHeaderLocator = By.cssSelector("table.main-table tr:nth-child(1)");
    private By deleteButton = By.cssSelector("button.​delete-button");
    private By addColumnButton = By.cssSelector(".add-column-btn");
    private By filterModal = By.xpath("//div[contains(@class, 'modal-backdrop')]");

    /**
     * Constructor to initialize page factory elements.
     *
     */
    public ReportEditorPage(){
        PageFactory.initElements(m_driver,this);
    }

    /**
     * Method to edit report name on report editor page.
     *
     * @param reportName - Name of report.
     */
    public void editReportName(String reportName){
        waitForElement(edit, 60);
        editReportNameButton.click();
        reportnameInputBox.sendKeys(Keys.CONTROL + "a");
        reportnameInputBox.sendKeys(reportName);
        reportnameInputBox.sendKeys(Keys.RETURN);
    }

    /**
     * Method to edit description for report on editor page.
     *
     * @param description - description.
     */
    public void setDescription(String description){
        waitForElement(editDescriptionButton, 60).click();
        reportDescriptionInputBox.sendKeys(Keys.CONTROL + "a");
        reportDescriptionInputBox.sendKeys(description);
        reportDescriptionInputBox.sendKeys(Keys.RETURN);
    }

    /**
     * Method to add subject areas and columns to the report.
     *
     * @param subjectAreasAndColumns - Map with subject area names
     * @param removeDefault - boolean value to specify if default subject area needs to be removed.
     */
    public void addSubjectAreas(Map<String, List<String>> subjectAreasAndColumns, boolean removeDefault, String parentSubjectArea) {
        List<String> subjectAreas = new ArrayList<>(subjectAreasAndColumns.keySet());
        addSubjectAreas(subjectAreas, removeDefault, parentSubjectArea);
    }

    /**
     * Method to add subject areas to the report.
     *
     * @param subjectAreas - String list with subject area names.
     * @param removeDefault - boolean value to specify if default subject area needs to be removed.
     */
    public void addSubjectAreas(List<String> subjectAreas, boolean removeDefault, String parentSubjectArea) {

        if(removeDefault) {
            try {
                rmDefaultSubjectArea.click();
            }catch(NoSuchElementException e){
                //No main subject area will be available for the first time.
            }
        }
        Flyout flyout = new Flyout();
        if (!subjectAreas.isEmpty()) {
            if(parentSubjectArea.isEmpty()) {
                waitForElementToBeClickable(expendSubjectArea);
                expendSubjectArea.click();
            } else {
                expandSupportingSubArea.click();
            }
            try {
                waitForElementToBeDisplayed(subjectAreaPopup, 60);
            }catch(TimeoutException e){
                if(parentSubjectArea.isEmpty()) {
                    expendSubjectArea.click();
                } else {
                    expandSupportingSubArea.click();
                }
            }
            for(String subjectArea : subjectAreas) {
                flyout.selecteItem(subjectArea, parentSubjectArea);
            }
            flyout.ok();
        }
        try {
            waitForElementToBeDisplayed(By.cssSelector(".list-view-gc .loading-spinner-large"), 4);
            waitForElementToDisappear(By.cssSelector(".list-view-gc .loading-spinner-large"), 10);
        } catch(NoSuchElementException | TimeoutException e){
            //ignore
        }
    }

    /**
     * Method to add subject areas and columns to the report.
     *
     * @param subjectAreaAndColumns - Map with subject area names and column names.
     * @param removeDefault - boolean value to specify if default subject area needs to be removed.
     */
    public void addSubjectAreasAndColumns(Map<String, List<String>> subjectAreaAndColumns, boolean removeDefault, String parentSubjectArea){
        addSubjectAreas(subjectAreaAndColumns, removeDefault, parentSubjectArea);
        addColumns(subjectAreaAndColumns, parentSubjectArea);
    }

    /**
     * Method to add columns to the report.
     *
     * @param subjectAreaColumns - Map with subject area as keys and column list as value.
     */
    public void addColumns(Map<String, List<String>> subjectAreaColumns, String parentSubjectArea) {

        ListTemplate listTemplate;

        for(String subjectArea : subjectAreaColumns.keySet()) {
            listTemplate = new ListTemplate(subjectArea, !(parentSubjectArea.isEmpty()));
            listTemplate.addColumns(subjectAreaColumns.get(subjectArea), parentSubjectArea);
        }
    }

    /**
     * Method to save report.
     *
     */
    public void saveReportEditorPage() {
        waitForElementToDisappear(filterModal, 20);
        WebElement saveButton = waitForElement(saveLocator, waitTime);
        saveButton.click();
        waitForElementToDisappear(saveCancelControlsLocator, waitTime);
    }

    /**
     * Method to switch iframe.
     *
     */
    public void switchToFrame(){
        waitForElementToBeDisplayed(frameLocator, 15);
        m_driver.switchTo().frame(m_driver.findElement(frameLocator));
    }

    /**
     * Method to select list template based on subject area which is needed to perfrom different operations on report.
     *
     * @param subjectArea - Name of the subject area.
     */
    public ListTemplate selectListTempate(String subjectArea){
        ListTemplate subjectAreaTemplate = new ListTemplate(subjectArea, false);
        return subjectAreaTemplate;
    }

    /**
     * Method to delete columns from report.
     *
     * @param columnLabel - Name of the column to delete.
     * @param subjectArea - Name of the subject.
     */
    public void deleteColumn(String columnLabel, String subjectArea) {
        WebElement headerRow = m_driver.findElement(tableHeaderLocator);
        List<WebElement> headers = headerRow.findElements(By.tagName("th"));
        WebElement headerElement;
        for (WebElement header : headers) {
            headerElement = header.findElement(By.cssSelector("label"));
            String label = headerElement.getAttribute("innerHTML");
            if (label.equals(columnLabel)) {
                new Actions(m_driver).moveToElement(headerElement).build().perform();
                new Actions(m_driver).moveToElement(header.findElement(deleteButton)).click().build().perform();
            }
        }
    }

    /**
     * Method to delete columns in bulk from report.
     *
     * @param columnLabels - List of column to delete.
     * @param subjectArea - Name of the subject.
     */
    public void deleteColumnsForSubjectArea(List<String> columnLabels, String subjectArea){
        ListTemplate subjectAreaTemplate = new ListTemplate(subjectArea, false);
        subjectAreaTemplate.deleteColumns(columnLabels);
    }

    public void waitForLoaderToDisappear(){
        try {
            waitForElementToBeDisplayed(spinner, 8000);
            waitForElementToDisappear(spinner, 15000);
        }catch(Exception e){
        }
    }

    /**
     * Method to close report editor page.
     *
     */
    public void closeReportEditorPage() {
        m_driver.switchTo().defaultContent();
        m_driver.switchTo().frame(m_driver.findElement(By.cssSelector("#frameMain")));
        waitForElement(closeButtonLocator, 20).click();
    }

    /**
     * Method to get listed main subject areas.
     *
     */
    public List<String> getListedSubjectAreas() {
        m_driver.switchTo().defaultContent();
        waitForElementToBeDisplayed(By.cssSelector("#frameMain"), 15);
        m_driver.switchTo().frame(m_driver.findElement(By.cssSelector("#frameMain")));
        switchToFrame();
        try {
            waitForElementToBeDisplayed(By.cssSelector("#main-subject-areas-list  li .item-delete"), 10);
            rmDefaultSubjectArea.click();
        }catch(TimeoutException e){
            //ignore
        }
        expendSubjectArea.click();
        return new Flyout().getMainSubjectAreasDisplayed();
    }

    /**
     * Method to wait for add column button.
     *
     */
    public void waitForAddColumnButton() {
        switchToFrame();
        waitForElementToBeDisplayed(addColumnButton, 30);
    }

    /**
     * Method to set include historical data flag.
     *
     * @param includeHistoricalData  flag to include historical data.
     */
    public void setIncludeHistoricalDataFlag(String includeHistoricalData){
        if(Boolean.valueOf(includeHistoricalData)){
            waitForElementToBeDisplayed(includeHistoricalDataCheckbox, 10).click();
        }
    }

    /**
     * Method to get custom headings for all the columns.
     *
     */
    public Map<String, String> getCustomHeadingsForAllColumns(String subjectArea) {
        return new ListTemplate(subjectArea, false).getAllColumnLabelsWithCustomHeadings(subjectArea);
    }

    /**
     * Method to get listed supporting subject areas.
     *
     */
    public List<String> getListedSupportingSubjectAreas(String mainSubjectArea) {
        addSubjectAreas(Arrays.asList(mainSubjectArea),true, "");
        try {
            waitForElementToBeClickable(expandSupportingSubArea).click();
            return new Flyout().getSupportingSubjectAreas(mainSubjectArea);
        } catch(TimeoutException e){
            //No supporting subject areas under 'USER' main subject area.
        }
        return Arrays.asList("");
    }
}