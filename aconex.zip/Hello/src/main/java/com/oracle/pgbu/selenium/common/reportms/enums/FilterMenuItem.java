package com.oracle.pgbu.selenium.common.reportms.enums;

public enum FilterMenuItem {
    ADD_ABOVE(1),
    ADD_BELOW(2),
    DELETE(3),
    MOVE_DOWN(4);

    private final int value;

    private FilterMenuItem(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
