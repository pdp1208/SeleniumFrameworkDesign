package com.oracle.pgbu.selenium.common.reportms.steps;

/**
 * This interface contains common function related to report microservice. These functions will remain consistent irrispective of application
 * with which report micriservice will be integrated.
 */
public interface Application {
    public void navigateToReportListPage();
    public void navigateToReportEditorPage();
    public void openBIPLayoutEditor(String reportName);
    public void downloadReport(String reportName, String layoutName, String outputFormat);
    public void verifyReport(String expReportDir, String downloadLocation, String reportName, boolean verifyActualFile) throws Exception;
    public void deleteReport(String name);
    public void verifyReportNameNotListed(String reportName);
    public void exporReporttToXML(String name);
    public void verifyReportNameIsListed(String name);
    public void waitForLoaderToDisappear();
}