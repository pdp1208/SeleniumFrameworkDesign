package com.oracle.pgbu.selenium.common.reportms.pages;

import com.google.common.base.Function;
import com.oracle.babylon.Utils.helper.CommonMethods;
import com.oracle.babylon.Utils.helper.WebDriverInstanceHolder;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * This is a base page class which report related page classes needs to extend from.
 * This class receives webdriver instance from framework and shares betwwen page classes.
 */
public class BasePage {

    protected WebDriver m_driver = WebDriverInstanceHolder.getInstance().getDriver();
    protected static final int waitTime = 60;
    WebElement m_element;
    CommonMethods commonMethods = new CommonMethods();

    /**
     * method waits for a particular element to disappear from the page
     *
     * @param by            - search by
     * @param secondsToWait - time to wait before throwing an error
     */
    public void waitForElementToDisappear(By by, long secondsToWait) {
        final FluentWait<By> wait = new FluentWait<>(by).withTimeout(secondsToWait, TimeUnit.SECONDS);

        wait.withMessage("waitForElementToDisappear timed out. Element " + by.toString() + " is still present")
                .until(new Function<org.openqa.selenium.By, Boolean>() {

                    @Override
                    public Boolean apply(org.openqa.selenium.By by) {
                        try {
                            if (!m_driver.findElement(by).isDisplayed()) {
                                return true;
                            }
                        } catch (final NoSuchElementException e) {
                            return true;
                        } catch (final StaleElementReferenceException ef) {
                            return true;
                        } catch (final ScriptTimeoutException ste) {
                            return true;
                        }
                        return false;
                    }
                });
    }


    /**
     * method waits till specified timeout for element specified in the By to appear on the page
     * <p>
     * - search by
     * <p>
     * - time to wait before throwing an error
     */
    public WebElement waitForElement(By by, int timeout) {
        FluentWait<By> wait = new FluentWait<>(by).withTimeout(timeout, TimeUnit.SECONDS).pollingEvery(waitTime, TimeUnit.MILLISECONDS)
                .ignoring(NoSuchElementException.class).ignoring(TimeoutException.class);

        wait.withMessage("waitForElement timed out. Element " + by.toString() + " not present").until(new Function<By, Boolean>() {
            @Override
            public Boolean apply(By by) {
                try {
                    m_driver.findElement(by);
                    return true;
                } catch (final NoSuchElementException e) {
                    return false;
                }
            }
        });
        return m_driver.findElement(by);
    }

    /**
     * method waits for a particular element to disappear from the page
     * <p>
     * <p>
     * - search by
     *
     * @param secondsToWait - time to wait before throwing an error
     */
    public void waitForElementToDisappear(WebElement element, long secondsToWait) {
        final FluentWait<WebElement> wait = new FluentWait<>(element).withTimeout(secondsToWait, TimeUnit.SECONDS);

        wait.withMessage("waitForElementToDisappear timed out. Element " + element.toString() + " is still present").until(new Function<WebElement, Boolean>() {

            @Override
            public Boolean apply(WebElement element) {
                try {
                    if (!element.isDisplayed()) {
                        return true;
                    }
                } catch (final NoSuchElementException e) {
                    return true;
                }
                return false;
            }
        });
    }

    /**
     * Method waits for a particular element to be displayed
     * <p>
     * <p>
     * - search by
     *
     * @param by - Locator expression with type of locator.
     * @param timeout - Timeout in seconds
     */
    public WebElement waitForElementToBeDisplayed(By by, int timeout) {
        FluentWait<By> wait = new FluentWait<>(by).withTimeout(timeout, TimeUnit.SECONDS).pollingEvery(waitTime, TimeUnit.MILLISECONDS)
                .ignoring(NoSuchElementException.class).ignoring(TimeoutException.class);

        wait.withMessage("waitForElement timed out. Element " + by.toString() + " not present").until(new Function<By, Boolean>() {

            @Override
            public Boolean apply(By by) {
                try {
                    return m_driver.findElement(by).isDisplayed();
                } catch (final NoSuchElementException e) {
                    return false;
                }
            }
        });
        return m_driver.findElement(by);
    }

    /**
     * method waits for a particular element to disappear from the page
     * <p>
     * <p>
     * - search by
     *
     * @param locator - Locator expression with type of locator.
     * @param timeout - Timeout in seconds
     */
    public void waitForElementToBeGone(By locator, int timeout) {
        WebElement element;
        if ((element = isElementDisplayed(locator)) != null) {
            new WebDriverWait(m_driver, timeout).until(ExpectedConditions.not(ExpectedConditions.visibilityOf(element)));
        }
    }

    /**
     * method waits for a particular element to be displayed
     * <p>
     * <p>
     * - search by
     *
     * @param locator - Locator expression with type of locator.
     */
    public WebElement isElementDisplayed(By locator) {
        WebElement waitElement = null;
        // Sets FluentWait Setup
        FluentWait<WebDriver> fwait = new FluentWait<>(m_driver).withTimeout(7, TimeUnit.SECONDS).pollingEvery(500, TimeUnit.MILLISECONDS)
                .ignoring(NoSuchElementException.class).ignoring(TimeoutException.class);

        try {
            waitElement = fwait.until(new Function<WebDriver, WebElement>() {

                @Override
                public WebElement apply(WebDriver driver) {
                    return driver.findElement(locator);
                }
            });
        } catch (Exception e) {

        }
        return null;
    }

    /**
     * method to switch to another window based on the title.
     *
     *
     * @param windowTitle - Title of the window to switch
     * @param closeCurrent - Boolean value to specify if current window needs to be closed
     */
    public void switchToWindowContaningTitle(String windowTitle, boolean closeCurrent) {
        if (!m_driver.getTitle().toLowerCase().contains(windowTitle.toLowerCase()) && closeCurrent) {
            m_driver.close();
        }

        Set<String> windows = m_driver.getWindowHandles();
        for (String window : windows) {
            if (m_driver.switchTo().window(window).getTitle().toLowerCase().contains(windowTitle.toLowerCase())) {
                break;
            }
        }
    }

    public WebElement waitForElementToBeClickable(WebElement element){
        return new WebDriverWait(m_driver, 10).until(ExpectedConditions.elementToBeClickable(element));
    }

    /**
     * method to wait for an element with text.
     *
     *
     * @param text - element text.
     * @return true or false based on presence of element.
     */
    public boolean waitForElementWithText(String text){
        try{
            m_driver.switchTo().defaultContent();
            new WebDriverWait(m_driver, 10).until(ExpectedConditions.or(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[text()='"+ text +"']"))));
            return true;
        } catch(TimeoutException e){
            return false;
        }
    }
}