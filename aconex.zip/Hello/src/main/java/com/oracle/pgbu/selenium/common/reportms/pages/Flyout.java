package com.oracle.pgbu.selenium.common.reportms.pages;

import com.oracle.babylon.Utils.helper.CommonMethods;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * This is a page object class for add column and add subject area flyouts.
 *
 */
public class Flyout extends ReportEditorPage {

    protected WebElement flyout;

    private static final String flyoutLocator = ".in.flyout ";

    @FindBy(css = flyoutLocator + ".flyout-footer .btn-action")
    private WebElement ok;

    @FindBy(css = flyoutLocator + ".flyout-footer .btn-blue-dark")
    private WebElement cancel;

    @FindBy(css = flyoutLocator + "input[class*='search-typeahead']")
    private WebElement searchBox;

    @FindBy(xpath = "//*[contains(@class,'flyout')]//*[contains(@class,'flyout-items')]//label")
    private List<WebElement> subjectAreas;

    public Flyout(){
        PageFactory.initElements(m_driver, this);
    }

    /**
     * method to click ok button on add column/subjectarea flyouts.
     *
     */
    public void ok(){
        ok.click();
    }

    /**
     * method to click Cancel button on add column/subjectarea flyouts.
     *
     */
    public void cancel(){
        cancel.click();
    }

    /**
     * method to select item from dropdown on add column/subjectarea flyout.
     *
     * @param item - Name of the item to select from dropdown
     * @param parentSubjectArea - parent subject area.
     */
    public void selecteItem(String item, String parentSubjectArea){
        String locator = flyoutLocator;
        try {
            waitForElementToBeDisplayed(By.cssSelector(locator + "input[class*='search-typeahead']"), 5);
        } catch(Exception e){
            try {
                Thread.sleep(2000);
            } catch(InterruptedException exception){
            }
            m_driver.findElement(By.xpath("(//*[contains(@class,'flyout')][contains(@class,'in')]//span[@class='token-container'])[last()]")).click();
        }
        searchBox.sendKeys(Keys.CONTROL + "a");
        for(char c : item.toCharArray()){
            searchBox.sendKeys(Character.toString(c));
        }
        if(parentSubjectArea.isEmpty()) {
            try {
                waitForElement(By.cssSelector("li.orcl-type-ahead-node [title='" + item + "']"), 10).click();
            } catch(TimeoutException | StaleElementReferenceException e){
                searchBox.sendKeys(Keys.CONTROL + "a");
                for(char c : item.toCharArray()){
                    searchBox.sendKeys(Character.toString(c));
                    waitForElement(By.cssSelector("li.orcl-type-ahead-node [title='" + item + "']"), 10).click();
                }
            }
        } else {
            try {
                waitForElement(By.cssSelector("li.orcl-type-ahead-node [title='" + parentSubjectArea + " - " + item + "']"), 10).click();
            } catch(TimeoutException e){
                waitForElement(By.cssSelector("li.orcl-type-ahead-node [title='" + item + "']"), 10).click();
            }
        }
        searchBox.sendKeys(Keys.TAB);
    }

    /**
     * method to return main subject area names.
     *
     * @return subject area names
     */
    public List<String> getMainSubjectAreasDisplayed(){
        List<String> subjectAreaNames = new ArrayList<>();
        for(WebElement subjectAreaElement : subjectAreas){
            subjectAreaNames.add(subjectAreaElement.getText());
        }
        cancel.click();
        return subjectAreaNames;
    }

    /**
     * method to return supporting subject area names.
     *
     * @return supporting subject area names
     */
    public List<String> getSupportingSubjectAreas(String mainSubjectArea){
        waitForElement(By.xpath("//*[@id='support-subject-areas-flyout']//a[contains(text(),'"+ mainSubjectArea + "')]"), 10).click();
        if(mainSubjectArea.split(" ").length>2) {
            mainSubjectArea = mainSubjectArea.substring(0, mainSubjectArea.lastIndexOf(" "));
        }
        String locator = "//*[@id='support-subject-areas-flyout']//div[contains(@data-selector,'" + mainSubjectArea.replace(" ","_").toUpperCase() + "')]/label";
        By supportinSubjectAreas = By.xpath(locator);
        waitForElementToBeDisplayed(supportinSubjectAreas,10);
        List<String> subjectAreaNames = new ArrayList<>();
        for(WebElement subjectAreaElement : m_driver.findElements(supportinSubjectAreas)){
            commonMethods.waitForElementExplicitly(1000);
            subjectAreaNames.add(subjectAreaElement.getText());
        }
        return subjectAreaNames;
    }
}
