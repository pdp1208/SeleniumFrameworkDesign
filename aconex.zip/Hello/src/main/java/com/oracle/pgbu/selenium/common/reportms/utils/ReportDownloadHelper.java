package com.oracle.pgbu.selenium.common.reportms.utils;

import com.oracle.babylon.Utils.setup.utils.ConfigPropertyReader;
import io.restassured.http.Cookie;
import io.restassured.http.Header;
import io.restassured.http.Method;
import io.restassured.response.Response;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Class for methods useful for downloading report using rest apis.
 *
 */
public class ReportDownloadHelper {

    HttpClientHelper httpClientHelper = new HttpClientHelper();
    private ConfigPropertyReader configPropertyReader = new ConfigPropertyReader();
    private static final String getUserReportspath = "bipreporting-service/reports/getUserReports";
    private static final String exportReportsPath = "bipreporting-service/reports/export/";
    private static final String settings = "internal/admin/reporting/bipreportservice/settings";
    private static final String exportToXmlPath = "bipreporting-service/reports/execute/reportId/exportToXml";

    /**
     * Method to fetch reportid using rest API.
     *
     * @param reportName Name of the report.
     * @param cookies List of required cookies.
     * @param headersList List of required headers.
     * @return reportid
     */
    public String getReportId(String reportName, List<Cookie> cookies, List<Header> headersList) {
        String url = configPropertyReader.getApplicationBaseURL() + getUserReportspath;
        Response userReports = httpClientHelper.execRequest(Method.GET, url, headersList, null, cookies, null, null, "");
        return fetchReportIdFromJsonResponse(userReports, reportName);
    }

    /**
     * Method to get runtime filters at run time using api.
     *
     * @param cookies list of cookies.
     * @param headersList list of headers.
     */
    public String getRunTimeFilters(String reportId, List<Cookie> cookies, List<Header> headersList){
        String url = configPropertyReader.getApplicationBaseURL() + "bipreporting-service/reports/getReport/" + reportId + "?pageName=undefined";
        Response reportDdetails = httpClientHelper.execRequest(Method.GET, url, headersList, null, cookies, null, null, "");
        String filters = fetchFiltersFromReportDetails(reportDdetails);
        return filters;
    }

    /**
     * Method to download report data using rest API.
     * @param reportId report id
     * @param layoutName layout name
     * @param format repotr format
     * @param filters runtime filtres.
     * @param cookies list of cookies
     * @param headerList list of headers
     * @return report data
     */
    public InputStream downlodReport(String reportId, String layoutName, String format, String filters, List<Cookie> cookies, List<Header> headerList){
        String url = configPropertyReader.getApplicationBaseURL() + exportReportsPath + reportId + "/" + layoutName + "/" + format;
        Response reportData = httpClientHelper.execRequest(Method.POST, url, headerList, filters, cookies, null, null, "");
        return reportData.getBody().asInputStream();
    }

    /**
     * Method to export report to xml using rest API.
     * @param reportId report id
     * @param cookies list of cookies
     * @param headerList list of headers
     * @return report data
     */
    public InputStream exportToXmlReport(String reportId, List<Cookie> cookies, List<Header> headerList, Map<String,String> queryParams){
        String exportToXmlPathWithReportId = "bipreporting-service/reports/execute/reportId/exportToXml".replaceAll("reportId", reportId);
        String url = configPropertyReader.getApplicationBaseURL() + exportToXmlPathWithReportId;
        Response reportData = httpClientHelper.execRequest(Method.GET, url, headerList, null, cookies, queryParams, null, "");
        return reportData.getBody().asInputStream();
    }

    /**
     * Method to fetch report id from json object.
     * @param userReportsResponse user session
     * @param reportName report name
     * @return report id
     */
    public String fetchReportIdFromJsonResponse(Response userReportsResponse, String reportName) {
        JSONParser parser = new JSONParser();
        JSONArray reportsListArray, catagorizedReportsList, reportsViews;
        JSONObject reportsListJson;
        String reportId = "";
        Object reportsList = null;
        JSONObject reportsListObject;

        try {
            reportsList = parser.parse(new StringReader(userReportsResponse.getBody().prettyPrint()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        reportsListObject = (JSONObject) reportsList;
        reportsListArray = (JSONArray) reportsListObject.get("reportLists");

        for (Object object : reportsListArray) {
            reportsListJson = (JSONObject) object;
            catagorizedReportsList = (JSONArray) reportsListJson.get("categorizedReportViews");
            for (Object obj11 : catagorizedReportsList) {
                reportsViews = (JSONArray) ((JSONObject) obj11).get("reportViews");
                for (Object report : reportsViews) {
                    JSONObject reportDetails = (JSONObject) report;
                    if (reportDetails.get("label").toString().equalsIgnoreCase(reportName)) {
                        reportId = reportDetails.get("reportId").toString();
                        break;
                    }
                }
                if(!reportId.isEmpty()){
                    break;
                }
            }
            if(!reportId.isEmpty()){
                break;
            }
        }
        return reportId;
    }

    /**
     * Method to get runtime filters at run time using api.
     *
     * @param reportDetails report details
     */
    public String fetchFiltersFromReportDetails(Response reportDetails){
        JSONParser parser = new JSONParser();
        JSONArray reportsListArray;
        JSONObject reportsListObject;
        JSONObject reportsListJson, filter = null;
        Object reportsList = null;
        try {
            reportsList = parser.parse(new StringReader(reportDetails.getBody().prettyPrint()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        reportsListObject = (JSONObject) reportsList;
        reportsListArray = (JSONArray) reportsListObject.get("reportList");
        for (Object object : reportsListArray) {
            reportsListJson = (JSONObject) object;
            filter = (JSONObject) reportsListJson.get("filter");
        }
        return filter.toJSONString();
    }

    /**
     * Method to execute REST call to get runtime settings using org id and user id.
     *
     * @param cookies list of cookies.
     * @param headersList list of headers.
     */
    public Response getSettings(List<Cookie> cookies, List<Header> headersList){
        String url = configPropertyReader.getApplicationBaseURL() + settings;
        return httpClientHelper.execRequest(Method.GET, url, headersList, null, cookies, null, null, "");
    }

    /**
     * Method to execute REST call to get token required for creating of csrf token.
     *
     * @param response http respanse from settings REST call.
     * @param cookies list of cookies.
     * @param headersList list of headers.
     */
    public Response getToken(Response response, List<Cookie> cookies, List<Header> headersList){
        String token = fetchTokenFromResponse(response);
        List<Cookie> cookies1 = new ArrayList<>();
        for(Cookie c:cookies){
            if(c.getName().equalsIgnoreCase("JSESSIONID") || c.getName().equalsIgnoreCase("XSRF-TOKEN")) {
                cookies1.add(c);
            }
        }
        cookies.clear();
        for(Cookie c:cookies1){
            cookies.add(c);
        }
        cookies.add(response.getDetailedCookie("ASESSIONID"));
        cookies.add(response.getDetailedCookie("ASDSESSIONID"));
        String url = configPropertyReader.getApplicationBaseURL() + "bipreporting-service/?pp=" + token;
        return httpClientHelper.execRequest(Method.GET, url, headersList, null, cookies, null, null, "");
    }

    /**
     * Method to fetch token from response of settings REST call.
     *
     * @param response http respanse from settings REST call.
     */
    public String fetchTokenFromResponse(Response response){
        JSONParser parser = new JSONParser();
        String token = "";
        Object listOfValues = null;
        JSONObject listObject;
        try {
            listOfValues = parser.parse(new StringReader(response.getBody().prettyPrint()));
            listObject = (JSONObject) listOfValues;
            token = listObject.get("token").toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return token;
    }

    /**
     * Method to fetch csrf token from response of pp REST call.
     *
     * @param response http respanse from pp REST call.
     */
    public String getCSRFToken(Response response){
        String csrfToken = "";
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        try {
            Document d = factory.newDocumentBuilder().parse(new InputSource(new StringReader(response.getBody().prettyPrint())));
            XPath xpath = XPathFactory.newInstance().newXPath();
            Node node = (Node) xpath.evaluate("//*[@id='csrf-token']", d, XPathConstants.NODE);
            csrfToken = node.getTextContent();
        } catch (ParserConfigurationException | SAXException | IOException | XPathExpressionException e) {
            e.printStackTrace();
        }
        return csrfToken.replaceAll("^\"|\"$", "");
    }
}
