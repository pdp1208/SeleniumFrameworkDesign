package com.oracle.pgbu.selenium.common.reportms.pages;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;

/**
 * This is a page object class for initializing list tempalte for a particular subject area.
 *
 */
public class ListTemplate extends ReportEditorPage {

    private String m_selector;
    private String subjectArea;
    private String accordionString;
    private WebElement accordion;
    private WebElement addColumns;
    private WebElement filter;
    private String gridSelector;
    private WebElement columnGrid;
    private WebElement menuGrid;
    private Actions action = new Actions(m_driver);

    /**
     * constructor to initialize webelement based on the type of subject area.
     *
     * @param subjectAreakey - Name of the subject area to add in the report.
     * @param subsubjectArea - boolean value to specify if provided subject area is subporting subject area or not.
     *
     */
    public ListTemplate(String subjectAreakey, boolean subsubjectArea) {

        subjectArea = subjectAreakey;
        setAccordionString();
        m_selector = "#" + accordionString;
        try {
            m_driver.findElement(By.cssSelector(m_selector));
            gridSelector = m_selector + " > .accordion-inner > .list-view-gc";
            refreshElements();
        }catch(NoSuchElementException e){
            accordionString = subjectArea.replaceAll("\\s+","_").toUpperCase();// + "_SSA";
            m_selector = "[data-selector*='" + accordionString + "']";
            gridSelector = m_selector + " > .list-view-gc";
            refreshSubSubjectElements();
        }
    }

    /**
     * Method to initialize webelement for supporting subject areas.
     *
     */
    public void refreshSubSubjectElements() {
        addColumns = m_driver.findElement(By.cssSelector(m_selector + " > .list-view-toolbar .add-column-btn"));
        filter = m_driver.findElement(By.cssSelector(m_selector + " > .list-view-toolbar .pgbu-icon-filter"));
        columnGrid = m_driver.findElement(By.cssSelector("div[class*=viewport-flex]:not([class*=headers])"));
        menuGrid = m_driver.findElement(By.cssSelector("[class*='viewport-menu-button-group']:not([data-rowset='headers'])"));
    }

    /**
     * Method to initialize webelement for main subject areas.
     *
     */
    public void refreshElements() {
        accordion = m_driver.findElement(By.cssSelector("[aria-controls='" + accordionString + "']"));
        addColumns = m_driver.findElement(By.cssSelector(m_selector + " > .accordion-inner > .list-view-toolbar .add-column-btn"));
        filter = m_driver.findElement(By.cssSelector(m_selector + " > .accordion-inner > .list-view-toolbar .pgbu-icon-filter"));
    }

    /**
     * Method to ad column under subject areas.
     *
     * @param columns String list of column names.
     * @param mainSubjectArea - boolean value to specify if provided subject area is main subject area or supporting subject area.
     */
    public void addColumns(List<String> columns, String parentSubjectArea) {
        if (parentSubjectArea.isEmpty()) {
            expandAccordion();
        }
        ((JavascriptExecutor)m_driver).executeScript("arguments[0].scrollIntoView();", addColumns);
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        addColumns.click();
        Flyout flyout = new Flyout();
        for (String column : columns) {
            flyout.selecteItem(column, parentSubjectArea);
        }
        flyout.ok();
    }

    /**
     * Method to expand accordion element to add subject area.
     *
     */
    public boolean expandAccordion() {
        ((JavascriptExecutor) m_driver).executeScript("arguments[0].scrollIntoView(" + false + ");", accordion);
        if (!accordion.isDisplayed()) {
            return false;
        } else if (isCollapsed()) {
            accordion.click();
        }
        return true;
    }

    /**
     * Method to check if accordion element is expanded or collapsed.
     *
     */
    public boolean isCollapsed() {
        return m_driver.findElement(By.id(accordionString)).getAttribute("class").contains("hidden");
    }

    /**
     * Method to select common base locator with respective to subject area.
     *
     */
    private void setAccordionString() {
        String[] parts = subjectArea.split("\\s+"); // Split on white space
        StringBuilder builder = new StringBuilder();
        for (String part : parts) {
            builder.append(part.toLowerCase());
            builder.append("-");
        }
        builder.append("accordion");
        accordionString = builder.toString();
    }

    /**
     * Method to click on button whcih opens filter dialog for subject area.
     *
     */
    public void openFilterFields() {
        filter.click();
        try {
            waitForElementToBeDisplayed(By.xpath("//div[contains(@class,'filter-view')][contains(@class,'in')]"), 10);

        }catch(TimeoutException e){
            waitForElementToBeDisplayed(By.xpath("//div[contains(@class,'filter-view')][contains(@class,'" + subjectArea.toUpperCase().replaceAll("\\s+","_") + "_SSA" + "')]"), 10);
        }
    }

    /**
     * Method to delete columns from report.
     *
     * @param columns - string list with name of columns
     */
    public void deleteColumns(List<String> columns) {
        for(String column : columns) {
            selectMenuForColumn(column, "delete");
        }
    }

    /**
     * Method to get index of column added in the report.
     *
     * @param column - name of columns
     */
    public int getColumnIndex(String column){
        int index = 0;
        List<WebElement> rows = columnGrid.findElements(By.cssSelector(" tbody tr td[data-index='name'] div[class='cell-renderer  ']"));
        for(WebElement row : rows){
            index++;
            if(row.getText().equals(column)){
                return index;
            }
        }
        return index;
    }

    /**
     * Method to select action for column which is added in the report.
     *
     * @param column - name of columns.
     * @param menu - action item name.
     */
    public void selectMenuForColumn(String column, String menu){
        int index = getColumnIndex(column);
        WebElement gearIcon = menuGrid.findElement(By.cssSelector(" tbody tr:nth-of-type("+ index + ") div.row-menu-button"));
        action.moveToElement(gearIcon).click().perform();
        m_driver.findElement(By.cssSelector(".menu-items [data-action-index='" + menu + "']")).click();
    }

    /**
     * Method to get custom heading for specified column.
     *
     * @param subjectArea - name of subject area.
     */
    public Map<String,String> getAllColumnLabelsWithCustomHeadings(String subjectArea) {
        Map<String,String> columnHeadings = new LinkedHashMap<String,String>();
        List<WebElement> columnLabels = m_driver.findElements(By.cssSelector(gridSelector + " td[data-index='name'] > div > div"));
        for(int i=0;i<columnLabels.size();i++){
            String columnLabel = columnLabels.get(i).getText();
            columnHeadings.put(columnLabel, columnLabels.get(i).findElement(By.xpath("(//following::td[@data-index='columnLabel']/div/div)[" + (i+1) + "]")).getText());
        }
        return columnHeadings;
    }
}