package com.oracle.pgbu.selenium.common.reportms.pages;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TreePanel extends BasePage{

    @FindBy(css = ".modal-accept")
    private WebElement ok;

    @FindBy(css = ".modal-cancel")
    private WebElement cancel;

    public TreePanel(WebElement element){
        PageFactory.initElements(m_driver, this);
        m_element = element;
    }

    /**
     * method to select a Tree item. If a list of strings is passed, n-1 objects
     * will be expended, and nth object will be selected
     *
     * @param items
     */
    public void selectItem(String... items) {
        // Expand Items
        if (items.length > 1) {
            expand(Arrays.copyOf(items, items.length - 1));
        }
        // Select the items[item.length-1] node here and return
        m_element.findElement(By.cssSelector("li .item-content[title='" + items[items.length - 1] + "']")).click();
    }

    public void selectItemLike(String... items) {
        List<WebElement> elements = m_element.findElements(By.cssSelector("[role=\"treeitem\"]"));
        for (String item : items) {
            for (WebElement element : elements) {
                if (element.getText().contains(item)) {
                    element.click();
                    break;
                }
            }
        }
    }

    public void expand(String... items) {
        for (String item : items) {
            WebElement treeItem = waitForElementToBeDisplayed(By.cssSelector("li .item-content[title='" + item + "']"), 4);
            WebElement parent = (WebElement) ((JavascriptExecutor)m_driver).executeScript("return arguments[0].parentNode;", treeItem);
            if (!parent.getAttribute("class").contains("expanded")) {
                expandCollapse(parent, false);
            }
        }
    }

    private void expandCollapse(WebElement treeItem, boolean bCollapse) {
        String state = (bCollapse) ? "expanded" : "collapsed";
        try {
            treeItem.findElement(By.cssSelector("div.item-content i.tree-icon." + state)).click();
        } catch (NoSuchElementException e) {
        }
    }

    public void confirmSelection(){
        ok.click();
    }

    public void cancelSelection(){
        cancel.click();
    }
}
