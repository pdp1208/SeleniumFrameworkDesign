package com.oracle.pgbu.selenium.common.reportms.pages.bip;

import com.oracle.pgbu.selenium.common.reportms.pages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

/**
 * This is a page object class for BI Publicher page belongs to BIP microservice UI.
 * This class contains locators for webelements and methods representing user actions.
 */
public class BIPublisherPage extends BasePage {

    @FindBy(css = "a[title='Add New Layout']")
    public WebElement addNewLayoutButton;

    @FindBy(xpath = "//a[@class='dataLink'][contains(text(),'View a list')]")
    public WebElement viewList;

    @FindBy(xpath = "//*[@id='saverdlink']")
    public WebElement save;

    private By addLayout = By.cssSelector("a[title='Add New Layout']");
    private By editButton = By.xpath("//a[contains(text(),'Edit')]");
    private By csvOptionlocator = By.xpath("//input[@value='csv']");
    private By saveSuccessMessage = By.xpath("//*[contains(@class,'statusText')]");

    @FindBy(xpath = "//img[@id='buttonUploadLayout']")
    public WebElement upload;

    @FindBy(id = "template_label")
    public WebElement layoutName;

    @FindBy(xpath = "//input[@name='template_url'][@type='file']")
    public WebElement templateFile;

    @FindBy(id = "template_type")
    public WebElement templateType;

    @FindBy(xpath = "//Select[@id='template_type']/following::select")
    public WebElement locale;

    @FindBy(xpath = "//button[contains(text(),'Upload')]")
    public WebElement uploadButton;

    public BIPublisherPage() {
        PageFactory.initElements(m_driver,this);
    }

    /**
     * Method to select layout type
     *
     * @param layoutType layout type
     */
    public void selectLayout(String layoutType) {
        m_driver.switchTo().defaultContent();
        try {
            waitForElementToBeDisplayed(By.cssSelector("#reporttemplate img[label='" + layoutType + "']"), 160).click();
        } catch(Exception e){
            waitForElementToBeDisplayed(addLayout, 160).click();
            waitForElement(By.cssSelector("#reporttemplate img[label='" + layoutType + "']"), 30).click();
        }
    }

    /**
     * Method to click button to add new layout.
     *
     */
    public void clickAddNewLayout() {
        m_driver.switchTo().defaultContent();
        addNewLayoutButton.click();
    }

    /**
     * Method to select layout type
     *
     * @param layoutName name of existing layout to be edited.
     * @return BIPLayoutEditor instance of BIPLayoutEditor page class.
     */
    public BIPLayoutEditor editLayout(String layoutName){
        WebElement actionRowForExistingLayout = m_driver.findElement(By.xpath("//span[@title='" + layoutName +"']/ancestor::tr[1]/following::tr[1]"));
        actionRowForExistingLayout.findElement(editButton).click();
        return new BIPLayoutEditor();
    }

    /**
     * Method to enable csv format for layout.
     *
     * @param layoutName name of existing layout to be edited.
     */
    public void enableCSVFormatForLayout(String layoutName){
        m_driver.switchTo().defaultContent();
        waitForElementToBeClickable(viewList).click();
        waitForElement(By.xpath("//input[@value='" + layoutName + "']/parent::td/following-sibling::td//*[contains(@id,'output')][contains(@class,'listBox')]"), 30).click();
        WebElement csvOption = m_driver.findElement(csvOptionlocator);
        JavascriptExecutor js = (JavascriptExecutor)m_driver;
        js.executeScript("arguments[0].scrollIntoView();", csvOption);
        csvOption.click();
        saveLayout();
    }

    /**
     * Method to save layout.
     *
     */
    public void saveLayout(){
        save.click();
        waitForElement(saveSuccessMessage, 50);
    }

    /**
     * Method to upload xpt file as a template.
     *
     */
    public void uploadTemplate(String templateName, String localeName, String name){
        upload.click();
        layoutName.sendKeys(name);
        templateFile.sendKeys(templateName);
        new Select(templateType).selectByVisibleText("RTF Template");
        new Select(locale).selectByVisibleText(localeName);
        uploadButton.click();
        waitForElementToBeDisplayed(By.xpath("//div[@id='repThumbNailsHolder']//span[contains(text(),'" + name + "')]"), 70);
    }
}