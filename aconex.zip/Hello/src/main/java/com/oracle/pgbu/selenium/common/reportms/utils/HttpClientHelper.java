package com.oracle.pgbu.selenium.common.reportms.utils;

import io.restassured.RestAssured;
import io.restassured.config.SSLConfig;
import io.restassured.http.*;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.util.List;
import java.util.Map;

/**
 * Class for providing wrapper methods for executing http request.
 *
 */
public class HttpClientHelper {
    public static RequestSpecification httpRequest;
    public static Response response;

    /**
     * Overloaded method to handle a custom httpRequest with cookies, headers, queryParams, formParams & contentTYpe.
     * @param method http method
     * @param url request url
     * @param headersList headers to authenticate
     * @param body only specific to put and post methods
     * @param cookies http cokkies
     * @param queryParams query parameters
     * @param formParameters form parameters
     * @param contentType content type
     * @return response of the api call
     */
    public Response execRequest(Method method, String url, List<Header> headersList, String body, List<Cookie> cookies, Map<String, String> queryParams, Map<String, Object> formParameters, String contentType) {
        httpRequest = RestAssured.given().config(RestAssured.config().sslConfig(new SSLConfig().allowAllHostnames().relaxedHTTPSValidation()));
        if(headersList!=null) {
            Headers header = new Headers(headersList);
            httpRequest.headers(header);
        }
        if ((method.equals(Method.PUT) || method.equals(Method.POST)) && body != null) {
            httpRequest.body(body);
        }
        if(cookies!=null){
            httpRequest.cookies(new Cookies(cookies));
        }
        if(queryParams!=null){
            httpRequest.queryParams(queryParams);
        }
        if(formParameters!=null){
            httpRequest.formParams(formParameters);
        }
        if((method.equals(Method.PUT) || method.equals(Method.POST))){
            if(contentType!=null && (!contentType.isEmpty())){
                httpRequest.contentType(contentType);
            } else {
                httpRequest.contentType(ContentType.JSON);
            }
        }
        response = httpRequest.request(method, url);
        return response;
    }
}
