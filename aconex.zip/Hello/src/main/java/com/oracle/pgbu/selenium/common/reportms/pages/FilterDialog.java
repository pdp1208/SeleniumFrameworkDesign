package com.oracle.pgbu.selenium.common.reportms.pages;

import com.oracle.pgbu.selenium.common.reportms.enums.FilterMenuItem;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

/**
 * This is a page object class for filter dialog on report editor page.
 *
 */
public class FilterDialog extends BasePage{

    @FindBy(css = ".filter-view.in input.filter-prompt-at-run-checkbox")
    public WebElement promptAtRunCheckbox;

    private String rowLocator = "div.filter-view.in div.filter-rows>div:nth-of-type(index)";

    public FilterDialog(){
        PageFactory.initElements(m_driver, this);
    }

    /**
     * method to filter field on which we need to apply filter.
     *
     * @param field - Name of the field
     *
     */
    public void selectFilterField(String field){
        Actions actions = new Actions(m_driver);
        actions.moveToElement(m_driver.findElement(By.cssSelector(rowLocator + " button[title='Select Field']"))).click().build().perform();
        actions.moveToElement(m_driver.findElement(By.cssSelector(rowLocator + " input"))).click().sendKeys(field).build().perform();
        m_driver.findElement(By.cssSelector("ul.oui-shown a[title='" + field + "']")).click();
    }

    /**
     * method to select operator for filter.
     *
     * @param operator - Name of the operator
     *
     */
    public void selectOperator(String operator){
        m_driver.findElement(By.cssSelector(rowLocator + " button.filter-operator")).click();
        m_driver.findElement(By.cssSelector("ul.oui-shown a[title='" + operator + "']")).click();
    }

    /**
     * method to select value for filter.
     *
     * @param value - filter value
     *
     */
    public void selectValue(List<String> value){
        String valueListType = m_driver.findElement(By.cssSelector(rowLocator + " div.filter-value-group div.filter-value *")).getTagName();
        switch(valueListType){
            case "button":
                m_driver.findElement(By.cssSelector(rowLocator + " div.filter-value-group button.combo-value")).click();
                m_driver.findElement(By.cssSelector("ul.oui-shown a[title='" + value.get(0) + "']")).click();
                break;
            case "input":
                if(m_driver.findElement(By.cssSelector(rowLocator + " div.filter-value-group div.filter-value")).getAttribute("class").contains("picker")){
                    m_driver.findElement(By.cssSelector(rowLocator + " div.filter-value-group button ")).click();
                    waitForElementToBeDisplayed(By.cssSelector(".orcl-picker-modal.in .tree-items"), 4);
                    TreePanel selector = new TreePanel(m_driver.findElement(By.cssSelector(".orcl-picker-modal.in .tree-items")));
                    selector.selectItem(value.toArray(new String[0]));
                    selector.confirmSelection();
                } else {
                    m_driver.findElement(By.cssSelector(rowLocator + " div.filter-value-group input")).sendKeys(value.get(0));
                }
                break;
            default:
                m_driver.findElement(By.cssSelector(rowLocator + " div.filter-value-group input")).sendKeys(value.get(0));
                break;
        }
    }

    /**
     * method to get next filter row available.
     *
     */
    public void getNextFilterRowLocator(){
        int index = 0;
        List<WebElement> rows = m_driver.findElements(By.xpath("//div[contains(@class,'filter-view')][@aria-hidden='false']//input[@role='combobox']/span"));
        for(WebElement row : rows){
            index++;
            if(row.getAttribute("title").length() < 3){
                rowLocator = rowLocator.replaceAll("index", String.valueOf(index));
                break;
            }
        }
    }

    /**
     * method to click on apply button on filter dialog.
     *
     *
     */
    public void apply(){
        m_driver.findElement(By.cssSelector(".in.modal .modal-footer .btn[title='Apply']")).click();
    }

    /**
     * method to click on cancel button on filter dialog.
     *
     */
    public void cancel(){
        m_driver.findElement(By.xpath("//*[contains(@class,'in')][contains(@class,'modal')]//div[contains(@class,'modal-footer')]//button[text()='Cancel']")).click();
    }

    /**
     * method to click on checkbox option for promptAtRun
     *
     */
    public void enablePromptAtRun(){
        promptAtRunCheckbox.click();
    }

    /**
     * method to check if checkbox for promptAtRun is selected or not.
     *
     */
    public boolean checkPromptAtRun(){
        return promptAtRunCheckbox.isSelected();
    }

    /**
     * method to perform specified action on filter.
     *
     * @param action - Action to be performed.
     * @param field - Field to be selected for apply filter.
     */
    public void selectActionForFilter(String action, String field) {
        int filterRowindex = filterRowLocator(field);
        WebElement rowElement = m_driver.findElement(By.cssSelector(rowLocator.replaceAll("index",String.valueOf(filterRowindex))));
        new Actions(m_driver).moveToElement(rowElement).build().perform();
        invokeGearMenu(filterRowindex);
        try {
            m_driver.findElement(By.cssSelector(".dropdown-menu li:nth-of-type(" + FilterMenuItem.valueOf(action).getValue() +") a")).click();
        } catch (NoSuchElementException e) {
            throw new RuntimeException("Invalid MenuItem specified or it cannot be located. Source: " + e);
        }
    }

    /**
     * method to select row of filter.
     *
     * @param field - Field to be selected for apply filter.
     */
    public int filterRowLocator(String field){
        int index = 0;
        List<WebElement> filterFields = m_driver.findElements(By.cssSelector("div.filter-view.in div.filter-rows .field-filter-combo>input>span"));
        for(WebElement filterField : filterFields){
            index++;
            if(filterField.getAttribute("title").equalsIgnoreCase(field)){
                return index;
            }
        }
        return -1;
    }

    /**
     * method to invoke gear menu on filter row.
     *
     * @param index - Index of filter row.
     */
    private void invokeGearMenu(int index) {
        try {
            m_driver.findElement(By.cssSelector(rowLocator.replaceAll("index",String.valueOf(index)) + " .grid-root-menu"));
        } catch (NoSuchElementException e) {
            new Actions(m_driver).moveToElement(getGearButton(index)).click().build().perform();
        }
    }

    /**
     * Method to get gear menu element for filter row.
     *
     * @param index - Index of filter row.
     */
    protected WebElement getGearButton(int index) {
        return m_driver.findElement(By.cssSelector(rowLocator.replaceAll("index",String.valueOf(index)) + " .row-menu-column button.dropdown-toggle"));
    }
}