package com.oracle.pgbu.selenium.common.reportms.pages.bip;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import com.oracle.pgbu.selenium.common.reportms.pages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 * This is a page object class for ReportEditor page belongs to report microservice UI.
 * This class contains locators for webelements and methods representing user actions.
 */
public class BIPLayoutEditor extends BasePage {

    @FindBy(css = "img[title='Save']")
    public WebElement save;

    @FindBy(css = "#app_contents")
    public WebElement appContents;

    @FindBy(css = "#app_canvas")
    public WebElement appCanvas;

    @FindBy(css = "div.ribbon_header #app_ribbon_insert_tab")
    public WebElement insertTab;

    @FindBy(css = "div.ribbon_header #app_ribbon_page_tab")
    public WebElement pageLayoutTab;

    @FindBy(css = "#ribbon_insert_table")
    public WebElement dataTable;

    @FindBy(css = "table.inputPane input[type='text']")
    public WebElement layoutNameInputBox;

    @FindBy(xpath = "//button[@class='dialogButton'][text()='Save']")
    public WebElement saveLayoutButton;

    @FindBy(xpath = "//button[@class='PushButton'][text()='Done']")
    public WebElement done;

    @FindBy(css = "div[data-value='/report_data_model']")
    public WebElement reportDataModel;

    public By loader = By.cssSelector("#applicationsplash_dlg_modalOverlay");
    public By header = By.cssSelector("div.ribbon_header #app_ribbon_page_tab");
    public By paperSize = By.cssSelector(".papersize");

    public static Map<WebElement, List<WebElement>> subjectColumnMap = new LinkedHashMap<>();

    public BIPLayoutEditor() {
        PageFactory.initElements(m_driver,this);
        waitForElementToBeGone(By.xpath("//div[@class='message'][text()='Loaded']"), 6);
        m_driver.switchTo().frame("xdo:online_tb_frame");
    }

    /**
     * Method to select page layout & size of the page on BIP layout editor page.
     *
     * @param layout type of layout to be selected.
     * @param size size of the page
     */
    public void setPageLayout(String layout, String size) {
        pageLayoutTab.click();
        appContents.findElement(By.cssSelector("#app_contents div.ribbon_body span." + layout.toLowerCase())).click();
        selectSize(size);
    }

    /**
     * Method to select page size on BIP layout editor page.
     *
     * @param size type of layout to be selected.
     */
    public void selectSize(String size) {
        try {
            waitForElement(loader, 100);
            waitForElementToDisappear(loader, 100);
        } catch(TimeoutException | NoSuchElementException e){
            System.out.println(e);
        }
        waitForElement(header, 30).click();
        WebElement sizeDropDown = m_driver.findElement(paperSize);
        sizeDropDown.click();
        List<WebElement> sizes = sizeDropDown.findElements(By.cssSelector(" ul>li"));

        for (WebElement sizeElement : sizes) {
            if (sizeElement.getText().equals(size)) {
                sizeElement.click();
            }
        }
    }

    /**
     * Method to add darta table on BIP layout editor page.
     *
     */
    public void addDataTable() {
        insertTab.click();
        dataTable.click();
    }

    /**
     * Method to add columns to BIP layout.
     *
     * @param subColumns subject area and respective column list
     */
    public Map<String, String> selectColumns(Map<String, List<String>> subColumns, boolean addDataTable, String mainSubjectArea) {
        Actions action = new Actions(m_driver);
        WebElement subjectElement;
        WebElement dataTableArea1;
        int dataTableCount1;
        if(addDataTable) {
            dataTableCount1 = m_driver.findElements(By.cssSelector(".component.table")).size();
        } else {
            dataTableCount1 = 0;
        }
        Map<String, String> columnNameFormats = new TreeMap<>();
        String inputColumnName;
        WebElement columnElement;
        WebElement columnTypeIcon;

        for (Entry<String, List<String>> entry : subColumns.entrySet()) {
            if(addDataTable) {
                addDataTable();
            }
            waitForElement(By.cssSelector(".component.table:nth-of-type(" + (++dataTableCount1) + ")"), 5);
            dataTableArea1 = appCanvas.findElement(By.cssSelector(".component.table:nth-of-type(" + dataTableCount1 + ")"));
            if(!mainSubjectArea.isEmpty()){
                subjectElement = reportDataModel
                        .findElement(By.cssSelector(".children [data-value='/report_data_model/" + mainSubjectArea.toLowerCase().replaceAll("\\s+","_") + "/" + entry.getKey().toLowerCase().replaceAll("\\s+","_") + "']"));
            } else {
                subjectElement = reportDataModel
                        .findElement(By.cssSelector(".children [data-value='/report_data_model/" + entry.getKey().toLowerCase().replaceAll("\\s+","_") + "']"));
            }
            for (String columnName : entry.getValue()) {
                inputColumnName = columnName;
                columnName = columnName.toLowerCase().replaceAll(" ", "_");
                columnName = columnName.replaceAll("'", "");
                if(!mainSubjectArea.isEmpty()){
                    columnElement = subjectElement
                            .findElement(By.cssSelector(".children [data-value='/report_data_model/" + mainSubjectArea.toLowerCase().replaceAll("\\s+","_") + "/" + entry.getKey().toLowerCase().replaceAll("\\s+","_") + "/"
                                    + columnName + "'] span"));
                    columnTypeIcon = subjectElement.findElement(
                            By.cssSelector(".children [data-value='/report_data_model/" + mainSubjectArea.toLowerCase().replaceAll("\\s+","_") + "/" + entry.getKey().toLowerCase().replaceAll("\\s+","_") + "/" + columnName + "'] div.icon"));
                } else {
                    columnElement = subjectElement
                            .findElement(By.cssSelector(".children [data-value='/report_data_model/" + entry.getKey().toLowerCase().replaceAll("\\s+","_") + "/"
                                    + columnName + "'] span"));
                    columnTypeIcon = subjectElement.findElement(
                            By.cssSelector(".children [data-value='/report_data_model/" + entry.getKey().toLowerCase().replaceAll("\\s+","_") + "/" + columnName + "'] div.icon"));
                }
                String columnDataType = columnTypeIcon.getAttribute("title");
                columnNameFormats.put(inputColumnName, columnDataType);
                try {
                    Thread.sleep(4000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                int retryCount =0;
                while(retryCount < 3) {
                    action.clickAndHold(columnElement).build().perform();
                    int width = dataTableArea1.getSize().getWidth();
                    action.moveToElement(dataTableArea1).moveByOffset(width / 2 - 2, 0).click().perform();
                    action.release(dataTableArea1).build().perform();
                    waitForElement(By.xpath("//div[contains(@class,'component table')][" + dataTableCount1 + "]//div[text()='" + columnElement.getText() + "']"), 90);
                    List<WebElement> columnHeaders = dataTableArea1.findElements(By.xpath("//th[@class='columnhead component']/div"));
                    if (columnHeaders.get(columnHeaders.size() - 1).getText().equalsIgnoreCase(inputColumnName)) {
                        break;
                    }
                    System.out.println("Column '" + columnName + "' added at wrong position.");
                    deleteColumnFromDataTable(inputColumnName);
                    retryCount++;
                }
            }
        }
        return columnNameFormats;
    }

    /**
     * Method to save BIP layout.
     *
     * @param LayoutName layout name.
     */
    public void saveLayout(String LayoutName) {
        save.click();
        layoutNameInputBox.sendKeys(LayoutName);
        saveLayoutButton.click();
        done.click();
    }

    /**
     * Method to delete column from BIP layout.
     *
     * @param columnName column name.
     */
    public void deleteColumnFromDataTable(String columnName){
        WebElement columnToBeDeleted = m_driver.findElement(By.cssSelector(".component.table:nth-of-type(1) tbody tr:nth-of-type(1) td:nth-of-type(" + getIndexOfColumn(columnName) +")"));
        Actions action = new Actions(m_driver);
        action.moveToElement(columnToBeDeleted).doubleClick().build().perform();
        WebElement deleteButton =  waitForElementToBeDisplayed(By.xpath("//*[@title='Delete selection']"), 20);
        action.moveToElement(deleteButton).click().build().perform();
        waitForElementToDisappear(By.xpath("//div[contains(@class,'component table')]//div[text()='" + columnName + "']"), 20);
    }

    /**
     * Method to return the index of column in BIP layout.
     *
     * @param columnName column name.
     */
    public int getIndexOfColumn(String columnName){
        try {
            waitForElementToBeDisplayed(By.xpath("//*[@class='tableHeader']/th"), 8);
        } catch(TimeoutException e){
        }
        List<WebElement> columnHeaders = m_driver.findElements(By.xpath("//*[@class='tableHeader']/th"));
        for(int index=0;index<columnHeaders.size();index++){
            if(columnHeaders.get(index).getText().equalsIgnoreCase(columnName)){
                return index + 1;
            }
        }
        return -1;
    }

}
