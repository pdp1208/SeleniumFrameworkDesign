package com.oracle.pgbu.selenium.common.reportms.utils;

import com.google.common.io.ByteStreams;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.tika.exception.TikaException;
import org.apache.tika.io.IOUtils;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.parser.microsoft.ooxml.OOXMLParser;
import org.apache.tika.parser.pdf.PDFParser;
import org.apache.tika.parser.xml.XMLParser;
import org.apache.tika.sax.BodyContentHandler;
import org.apache.tika.sax.XHTMLContentHandler;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;

import java.io.*;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * This class contains common utility methods required for report ms.
 *
 */
public class CommonUtilities {

    protected static final String expectedReportDirectory = "expectedReports/";

    /**
     * Method to construct relative path for the file name provided.
     *
     * @param fileName - Name of the file
     */
    public String constructFilePath(String fileName) {
        fileName = fileName.replaceAll(" ", "_").toLowerCase();
        fileName = expectedReportDirectory + fileName;
        URL fileURL = this.getClass().getResource(fileName);
        if(fileURL != null){
            fileName = fileURL.getPath().substring(1).replaceAll("%20", " ");
            return fileName;
        }
        ClassLoader classLoader = this.getClass().getClassLoader();
        File reportFile=new File(classLoader.getResource(fileName).getFile());
        fileName = reportFile.getAbsolutePath().replaceAll("%20", " ");

        return fileName;
    }


    /**
     * Method to fetch data from file.
     *
     * @param filePath - Relative path to the file.
     * @param format - Format of report.
     */
    public String getExpectedDataFromFileWithEncoding(String filePath, String format) throws IOException, SAXException, TikaException {
        InputStream inputStream = null;
        switch(format){
            case "HTML":
            case "XML":
                BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(filePath), "UTF-8"));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                    sb.append(System.lineSeparator());
                }
                int start = sb.indexOf("<style");
                int end = sb.lastIndexOf("</style>");
                if(start > 0 && end > 0) {
                    sb.replace(start, end + 8, "");
                }
                inputStream = new ByteArrayInputStream(new StringBuilder(StringEscapeUtils.unescapeHtml4(sb.toString())).toString().replaceAll("&","&amp;").getBytes(Charset.forName("UTF-8")));
                break;
            case "PDF":
                inputStream = new FileInputStream(new File(filePath));
                break;
            case "EXCEL":
                inputStream = new FileInputStream(new File(filePath));
                break;
            case "CSV":
                return readCSVFile(filePath);
        }
        return getExpectedDataFromFile(inputStream, format);
    }

    /**
     * Method to fetch data from input stream.
     *
     * @param input - input stream for the data.
     */
    public String getExpectedDataFromFile(InputStream input) throws IOException, SAXException, TikaException {
        ContentHandler handler = new BodyContentHandler();
        Metadata metadata = new Metadata();
        new XMLParser().parse(input, handler, metadata, new ParseContext());
        return StringEscapeUtils.unescapeXml(handler.toString()).replaceAll("\\s+", " ").trim();
    }

    /**
     * Method to fetch data from input stream.
     *
     * @param inputStream - input stream for the data.
     */
    public String getExpectedDataFromFile(InputStream inputStream, String format) throws IOException, SAXException, TikaException {
        ContentHandler handler = new BodyContentHandler();
        Metadata metadata = new Metadata();
        ParseContext parseContext = new ParseContext();
        switch(format){
            case "HTML":
            case "XML":
                new XMLParser().parse(inputStream, handler, metadata, parseContext);
                return StringEscapeUtils.unescapeXml(handler.toString()).replaceAll("\\s+", " ").trim();
            case "PDF":
                new PDFParser().parse(inputStream, handler, metadata, parseContext);
                return handler.toString().replaceAll("\\s+", " ").trim();
            case "EXCEL":
                new OOXMLParser().parse(inputStream, handler, metadata, parseContext);
                return handler.toString().replaceAll("\\s+", " ").trim();
            case "CSV":
                return IOUtils.toString(inputStream, String.valueOf(StandardCharsets.UTF_8)).replaceAll("\n","").replaceAll("\\s+", " ").trim();
        }
        return null;
    }

    /**
     * Method to fetch data from CSV file.
     *
     * @param filePath - file path.
     * @return data
     */
    public String readCSVFile(String filePath){
        String line;
        String plainText = "";
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            while ((line = br.readLine()) != null) {
                // use comma as separator
                plainText = plainText + line;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return plainText;
    }

    /**
     * Method to wait for a file to be available
     *
     * @param filePath path of the file
     * @param timeout timeout in seconds
     */
    public boolean waitForFile(String filePath, int timeout){
        while (new Date().getTime() - new Date().getTime() <= (timeout * 1000)) {
            if(new File(filePath).exists()) {
                return true;
            }
        }
        return false;
    }

    public String extractDataFromFile(String expReportDir, String format) throws TikaException, SAXException, IOException {
        return getExpectedDataFromFileWithEncoding(constructFilePath(expReportDir), format);
    }


    /**
     * Method to parse data based on the format specified.
     * @param inputData input data
     * @param format output format
     * @return parsed data
     */
    public String parseData(InputStream inputData, String format) throws IOException, SAXException, TikaException {
        if(format.equalsIgnoreCase("HTML")){
            String result = IOUtils.toString(inputData, String.valueOf(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder(result);
            int start = sb.indexOf("<style");
            int end = sb.lastIndexOf("</style>");
            if(start > 0 && end > 0) {
                sb.replace(start, end + 8, "");
            }
            inputData = new ByteArrayInputStream(sb.toString().getBytes(Charset.forName("UTF-8")));
        }
        return getExpectedDataFromFile(inputData, format);
    }

    /**
     * Method to replace timestamp in data.
     *
     * @param data - input data
     * @param replacement - replacement string
     */
    public String replaceTimestamp(String data,String replacement){
        List<String> matchList = new ArrayList<String>();
        Matcher timestampMatcher = Pattern.compile("[+-]?\\d{4}(-[01]\\d(-[0-3]\\d(T[0-2]\\d:[0-5]\\d:?([0-5]\\d(\\.\\d+)?)?([+-][0-2]\\d:[0-5]\\d)?Z?)?)?)?").matcher(data);
        while (timestampMatcher.find()) {//Finds Matching Pattern in String
            matchList.add(timestampMatcher.group(1));//Fetching Group from String
        }
        for (String timestamp : matchList) {
            if(timestamp!=null) {
                data = data.replaceAll(timestamp, timestamp.replaceAll("T.*?Z", replacement));
            }
        }
        return data;
    }
}