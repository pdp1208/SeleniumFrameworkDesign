package com.oracle.pgbu.selenium.common.reportms.enums;

/**
 * Enum for storing filter operators..
 *
 */
public enum Operators {

    EQUALS("equals"),

    IS_NOT_EQUAL_TO("is not equal to"),

    STARTS_WITH("starts with"),

    ENDS_WITH("ends with"),

    IS_EMPTY("is empty"),

    IS_NOT_EMPTY("is not empty"),

    IS_GREATER_THAN("is greater than"),

    IS_GREATER_THAN_EQUALS("is greater than or equals"),

    IS_LESS_THAN("is less than"),

    CONTAINS("contains"),

    DOES_NOT_CONTAIN("does not contain"),

    IS_UNDER("is under"),

    IS_ONE_OF("is one of"),

    IS_NOT_ONE_OF("is not one of"),

    IS_LESS_THAN_EQUALS("is less than or equals");

    private final String m_title;

    Operators(String title) {
        m_title = title;
    }

    public String getTitle() {
        return m_title;
    }
}
