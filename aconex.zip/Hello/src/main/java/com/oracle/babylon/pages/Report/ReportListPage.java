package com.oracle.babylon.pages.Report;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.ex.ElementNotFound;
import com.codeborne.selenide.ex.ElementShould;
import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

/**
 * Page object class for report list page.
 *
 */
public class ReportListPage extends Navigator {

    private By addButon = By.cssSelector("#add-report-button");
    private By customTab = By.cssSelector("#nav-custom-tab");
    private By standardTab = By.cssSelector("#nav-standard-tab");
    private By deleteSuccessMessage = By.xpath("//*[contains(text(),'Report Deleted')]");
    private By saveSuccessMessage = By.cssSelector("#set-default-success");
    private By defaultLayoutSelectionDialog = By.xpath("#select-default-layout");
    public EditReportPropertiesBox editProperties = new EditReportPropertiesBox();
    public ConfirmationDialog confirmationDialog = new ConfirmationDialog();
    public DefaultLayoutSelectionDialog defaultLayoutSelctionDialog = new DefaultLayoutSelectionDialog();
    public By loader = By.xpath("//div[contains(text(),'Loading Reports.')]");
    public By loaderOverlay = By.cssSelector(".auiLoaderOverlay");
    public By downloadItemFromHistorySection = By.xpath("//div[@id='report-history-tab']//*[@class='auiMenuButton-dropdown']//li[@title='Download'][not(contains(@class,'hidden'))]");
    private By cutomSearchInput = By.xpath("//input[contains(@id,'custom_tab_search_input')]");
    private By customSearchButton = By.xpath("(//button[contains(@id,'search_filter_button')])[2]");
    private By standardSearchButton = By.xpath("(//button[contains(@id,'search_filter_button')])[1]");
    private By standardSearchInput = By.xpath("//input[contains(@id,'standard_tab_search_input')]");
    private By standardReportTable = By.xpath("//*[@class='standardReportTableBody']//tr");
    private By customReportTable = By.xpath("//*[contains(@class,'reportListTableBody')]//ancestor::tr");
    private String cusotmReportTableLocator = "(//*[contains(@class,'reportListTableBody')]//ancestor::tr)";
    private By customPageClearCriteria = By.xpath("//*[contains(@id,'custom-search')]//*[contains(@id,'clear')]");
    public String contextColumnLocator = "//*[@id='history-table-body']/tr[INDEX]//td[contains(@class,'reportHistoryContextColumn')]";
    public String contexMenuOptions = "//*[@id='history-table-body']/tr[INDEX]//button[contains(@id,'contextMenuOptions')]";
    private By availableOptions = By.xpath("//div[@id='report-history-tab']//*[@class='auiMenuButton-dropdown']//li[not(contains(@class,'hidden'))]");
    private By importLayout = By.xpath("//*[@id='file-input']");
    private By historyTable = By.xpath("//*[@id='history-table-body']/tr");
    private By optionsForReport = By.xpath("//*[@id='menuList']//li[not(contains(@class,'hidden'))]//p");
    private By actionItemsForReport = By.xpath("//div[not(contains(@class,'hidden'))][(contains(@class,'menuOptions'))]//div[@class='auiMenuButton-dropdown']");
    private By historyTitle = By.id("history-title");
    private By reportTypeOptions = By.xpath("//*[@class='report-types']//li//input[@type='checkbox']/following-sibling::span");
    private By noReportMessageOnCustomPage = By.xpath("//*[contains(@class,'customNoReportErrorMessage')]/p");
    private By noReportMessageOnStandardPage = By.xpath("//*[contains(@class,'standardNoReportErrorMessage')]/p");
    private By sharedAcrossInfo = By.xpath("//div[@id='info_popover']//li[1]");
    private By createdInInfo = By.xpath("//div[@id='info_popover']//li[2]");
    private By reportEditorHeader = By.xpath("//h3[text()='Data model editor']");
    private By allFilters = By.xpath("//*[text()='All Filters']");
    private By expandedFilters = By.xpath("//*[contains(@class, 'expandedSearchFilters')][not(contains(@class, 'hidden'))]");
    private By createdByMyself = By.xpath("//*[contains(@class, 'expandedSearchFilters')]//input[@id='created_by']");
    private By sourceProject = By.xpath("//*[contains(@class, 'expandedSearchFilters')]//input[@id='source_project']");
    private By sharedWithList = By.xpath("//*[contains(text(),'Select Shared With')]/parent::*[contains(@class, 'sSelect-input')]");
    private By sharedWithInput = By.xpath("//*[@id='shared_with']//a[@class='sSelect-input']");
    private By searchInoutBox = By.xpath("//input[contains(@id,'search_input')]");
    private By searchButton = By.xpath("//button[text()='Search']");
    private String standardReportsLocalizedDetails = System.getProperty("user.dir") + "/src/main/resources/data/files/layouts/reportDetails.properties";
    public WaitOptionDialog waitOptionDialog = new WaitOptionDialog();
    public ReportTypeInfoPopup reportTypeInfoPopup = new ReportTypeInfoPopup();

    /**
     * Method to navigate to report list page.
     *
     */
    public void navigateToPage(){
        getMenuSubmenu("Insights", "Reports");
        commonMethods.switchToFrame(driver, "frameMain");
        try {
            commonMethods.waitForElement(driver, loader, 10);
            $(loader).waitUntil(hidden, 25000);
        } catch(TimeoutException e){
            //ignore
        }
        try {
            commonMethods.waitForElement(driver, customTab, 20);
        }catch(TimeoutException | NoSuchElementException e){
            refresh();
            getMenuSubmenu("Insights", "Reports");
            commonMethods.switchToFrame(driver, "frameMain");
            waitForLoaderToDisapper();
        }
    }

    /**
     * Method to navigate to report editor page.
     *
     */
    public List<String> navigateToReportEditorPage(){
        List<String> reportTypes = new ArrayList<>();
        navigateToPage();
        $(customTab).click();
        $(addButon).waitUntil(appear, 15000).click();
        try {
            $(reportTypeOptions).waitUntil(appears, 6000);
            $$(reportTypeOptions).forEach(element -> reportTypes.add(element.getText()));
            reportTypeInfoPopup.selectSubjectAreaTypesToAdd(reportTypes.stream().collect(Collectors.toSet()));
        } catch(TimeoutException | NoSuchElementException | ElementNotFound e){
            //Report info popup which got added in 22.1 release of report module has not been displayed. Older version of report module is deployed.
        }
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, reportEditorHeader, 20);
        return reportTypes;
    }

    /**
     * Method to select action for report using tri colon icon on report list page.
     *
     * @param reportName Name of the report to be selected
     * @param action Action to perform
     */
    public void selectActionForReport(String reportName, String action){
        openActionItemListForReport(reportName);
        $(By.xpath("//*[@class='auiMenuButton-dropdown']//li[@class='" + action +"']")).click();
    }

    /**
     * Method to select custom tab on report list page
     *
     */
    public void selectCustomTab(){
        $(customTab).waitUntil(appears, 20000, 2 * 1000);
        if(!($(customTab).getAttribute("class").contains("active"))){
            $(customTab).click();
        }
    }

    /**
     * Method to preview specific report.
     *
     * @param reportName Name of the report to be selected.
     */
    public void selectReport(String reportName){
        selectRowForReport(reportName).findElement(By.xpath("//a[text()= '" + reportName + "']")).click();
        try {
            commonMethods.waitForElement(driver, loaderOverlay, 50);
            $(loaderOverlay).waitUntil(disappear, 90000, 3000);
        }catch(Exception e){
            //No action needs to be taken.
        }
        try {
            if($(waitOptionDialog.waitingOption).isDisplayed()){
                waitOptionDialog.keepWaiting();
                commonMethods.waitForElement(driver, loaderOverlay, 10);
                $(loaderOverlay).waitUntil(disappear, 90000, 3000);
            }
        }catch(Exception e){
            //No action needs to be taken.
        }
    }

    /**
     * Method to select particula row on report list page.
     *
     * @param reportName Name of the report to be selected.
     */
    public WebElement selectRowForReport(String reportName){
        WebElement row = driver.findElement(By.xpath("//*[contains(@class,'tab-pane fade show')]//a[contains(text(),'" + reportName + "')]//ancestor::tr"));
        new Actions(driver).moveToElement(row, row.getSize().getWidth() / 2, 1).click(row).build().perform();
        return row;
    }

    /**
     * Method to edit report properties.
     *
     * @param reportName Name of the report.
     * @param description Description fot the report.
     */
    public void editReportProperties(String reportName, String description){
        editProperties.waitForEditPropertiesBoxToOpen();
        if(!reportName.isEmpty()){
            editProperties.editReportName(reportName);
        }
        if(!description.isEmpty()){
            editProperties.editDescription(description);
        }
    }

    /**
     * Method to check that report name is listed on report list page.
     *
     * @param reportName Name of the report.
     */
    public void isReportNameListed(String reportName){
        $(By.xpath("//a[text()='" + reportName + "']//ancestor::tr")).isDisplayed();
    }

    /**
     * Method to check that report name is listed on report list page.
     *
     * @param reportName Name of the report.
     */
    public boolean isReportPresent(String reportName){
        return $(By.xpath("//*[contains(@class, 'tab-pane fade show')]//a[text()='" + reportName + "']//ancestor::tr")).isDisplayed();
    }

    /**
     * Method to check that report name is not listed on report list page.
     *
     * @param reportName Name of the report.
     */
    public void verifyReportNameNotListed(String reportName){
        $(By.xpath("//a[text()='" + reportName + "']//ancestor::tr")).shouldNot(visible);
    }

    /**
     * Method to verify delete report success message.
     *
     */
    public void verifyDeleteSuccessMessage(){
        $(deleteSuccessMessage).waitUntil(appear, 10000);
        $(deleteSuccessMessage).waitUntil(disappear, 10000);
    }

    /**
     * Method to confirm the action.
     *
     */
    public void confirm() {
        confirmationDialog.waitForConfirmationDialogToOpen();
        confirmationDialog.confirm();
    }

    /**
     * Method to cancel the action.
     *
     */
    public void cancel() {
        confirmationDialog.waitForConfirmationDialogToOpen();
        confirmationDialog.cancel();
    }

    /**
     * Method to get properties of report on report list page.
     *
     * @param reportName name of the report to be selected.
     */
    public Map<String, String> getReportProperties(String  reportName){
        Map<String, String> properties = new HashMap<String, String>();
        WebElement row = getReportRow(reportName);
        properties.put("description", $(By.xpath("//a[text()='"+ reportName +"']//ancestor::tr//td[3]/div")).getText());
        properties.put("sharedWith", row.findElement(By.xpath("//td[7]/div")).getText());
        properties.put("modifiedBy", row.findElement(By.xpath("//td[8]/div")).getText());
        properties.put("dateModified", row.findElement(By.xpath("//td[9]/div")).getText());
        $(By.xpath("//a[text()='"+ reportName +"']//ancestor::tr//span[contains(@class,'shared-with-info')]")).waitUntil(appears, 7000).click();
        properties.put("sharedAcross", $(sharedAcrossInfo).waitUntil(appears, 5000).getText());
        properties.put("createdIn", $(createdInInfo).waitUntil(appears, 5000).getText());
        return properties;
    }

    /**
     * Method to get report names along with their properties on report list page.
     *
     */
    public Map<String, Map<String, String>> getReportsDetails(){
        Map<String, String> properties;
        Map<String, Map<String, String>> reportsDetails = new LinkedHashMap<>();
        ElementsCollection reportList = $$(customReportTable);
        for(int i=1;i<=reportList.size();i++){
            String reportName = $(By.xpath(cusotmReportTableLocator + "[" + i + "]//td[contains(@class,'reportLabel')]//a[contains(@class, 'reportLink')]")).scrollTo().hover().getText();
            properties = new LinkedHashMap<>();
            properties.put("Description", $(By.xpath(cusotmReportTableLocator + "[" + i + "]/td[3]/div")).getText());
            properties.put("Shared With", $(By.xpath(cusotmReportTableLocator + "[" + i + "]/td[7]/div")).getText());
            properties.put("Modified By", $(By.xpath(cusotmReportTableLocator + "[" + i + "]/td[8]/div")).getText());
            properties.put("Date Modified", $(By.xpath(cusotmReportTableLocator + "[" + i + "]/td[9]/div")).getText());
            if(!reportName.isEmpty() && reportName!=null) {
                reportsDetails.put(reportName, properties);
            }
        }
        return reportsDetails;
    }

    /**
     * Method to get standard report names along with their properties on report listing page.
     *
     */
    public Map<String, Map<String, String>> getStandardReportsDetails(){
        Map<String, String> properties;
        Map<String, Map<String, String>> reportsDetails = new LinkedHashMap<>();
        String reportName;
        $(standardReportTable).waitUntil(appears, 30000);
        ElementsCollection reportList = $$(standardReportTable);
        for(int i=1;i<=reportList.size();i++){
            reportName = $(By.xpath("//*[@class='standardReportTableBody']//tr" + "[" + i + "]//a[@class='reportLink']")).scrollTo().hover().getText();
            properties = new LinkedHashMap<>();
            properties.put("Description", $(By.xpath("//*[@class='standardReportTableBody']//tr" + "[" + i + "]//a[@class='reportLink']/ancestor::td/following-sibling::td")).getText());
            if(!reportName.isEmpty() && reportName!=null) {
                reportsDetails.put(reportName, properties);
            }
        }
        return reportsDetails;
    }

    /**
     * Method to get the particular row specific to desired report on report list page.
     *
     * @param reportName name of the report to be selected.
     */
    public WebElement getReportRow(String reportName){
        WebElement row = driver.findElement(By.xpath("//a[text()='"+ reportName +"']//ancestor::tr"));
        return row;
    }

    /**
     * Method to verify success message on report list page.
     *
     */
    public void verifySaveSuccessMessage(){
        $(saveSuccessMessage).waitUntil(appear, 15000);
        $(saveSuccessMessage).waitUntil(disappear, 10000);
    }

    /**
     * Method to to select default layout.
     *
     * @param layoutName Name of the layout to be selected.
     * @param availableLayouts List of available layouts.
     */
    public void selecttDefaultLayout(String layoutName, List<String> availableLayouts){
        defaultLayoutSelctionDialog.verifyListOfAvailableLayouts(availableLayouts);
        defaultLayoutSelctionDialog.selctDefaultlayout(layoutName);
        defaultLayoutSelctionDialog.save();
    }

    /**
     * Method to fetch execution count from history table.
     *
     */
    public int getExecutionCount(){
        return $$(historyTable).size();
    }

    /**
     * Method to fetch execution date from history table for particular run.
     *
     * @param executionIndex Index of run.
     */
    public String getExecutionDate(int executionIndex){
        return $(By.xpath("//*[@id='history-table-body']/tr[" + executionIndex + "]//*[@class='content-cell']//*[contains(@class,'cell-renderer')]")).text();
    }

    /**
     * Method to fetch output format from history table for particular run.
     *
     * @param executionIndex Index of run.
     */
    public String getExportFormat(int executionIndex){
        return $(By.xpath("//*[@id='history-table-body']/tr[" + executionIndex + "]//td[contains(@class,'reportFormat')]/div")).getAttribute("class");
    }

    /**
     * Method to fetch available options from history table.
     *
     */
    public List<String> getAvailableOptionsForHistoryreport(int index){
        index++;
        $(By.xpath(contextColumnLocator.replaceAll("INDEX",Integer.toString(index)))).hover();
        $(By.xpath(contexMenuOptions.replaceAll("INDEX",Integer.toString(index)))).hover().click();
        List<String> availaleOptions = new ArrayList<>();
        for(SelenideElement e : $$(availableOptions)){
            availaleOptions.add(e.getAttribute("title"));
        }
        $(By.xpath(contextColumnLocator.replaceAll("INDEX",Integer.toString(index)))).hover();
        $(By.xpath(contexMenuOptions.replaceAll("INDEX",Integer.toString(index)))).hover().click();
        return availaleOptions;
    }

    /**
     * Method to wait history section.
     *
     */
    public void waitForReportHistorySection(){
        $(historyTitle).waitUntil(appear, 15000);
    }

    /**
     * Method to fetch action items for particular report.
     *
     * @param reportName Report name.
     */
    public List<String> getAvailableOptionsForReport(String reportName){
        openActionItemListForReport(reportName);
        return $$(optionsForReport).texts();
    }

    /**
     * Method to open action item list for particular report.
     *
     * @param reportName Report name.
     */
    public void openActionItemListForReport(String reportName){
        $(By.xpath("//a[text()= '"+ reportName + "']//ancestor::tr")).waitUntil(appears, 3000).hover();
        $(By.xpath("//a[text()= '"+ reportName + "']//ancestor::tr//td[1]/button")).waitUntil(appears, 3000).hover().click();
        $(actionItemsForReport).waitUntil(appear, 30);
    }

    /**
     * Method to untill loader disappers.
     *
     */
    public void waitForLoaderToDisapper(){
        try {
            commonMethods.waitForElement(driver, loader, 20);
            $(loader).waitUntil(hidden, 80000);
        } catch(TimeoutException | NoSuchElementException e){
            try {
                commonMethods.waitForElement(driver, loaderOverlay, 20);
                $(loaderOverlay).waitUntil(disappear, 90000, 3000);
            }catch(TimeoutException | NoSuchElementException e1){
                //ignore
            }
        }
    }

    /**
     * Method to untill loader disappers.
     *
     */
    public void downloadReportFromHistorySection(){
        $(downloadItemFromHistorySection).click();
    }

    /**
     * Method to untill loader disappers.
     *
     */
    public void searchReportWithSubstring(String searchText){
        commonMethods.waitForElement(driver, addButon, 10);
        $$(searchInoutBox).filter(visible).get(0).setValue(searchText);
        $$(searchButton).filter(visible).get(0).click();
    }

    /**
     * Method to get count of reports listed.
     *
     */
    public int getReportCount(){
        try {
            commonMethods.waitForElement(driver, standardReportTable, 10);
            return $$(standardReportTable).size();
        } catch(TimeoutException e){
            return $$(customReportTable).size();
        }
    }

    /**
     * Method to clear search criteria.
     *
     */
    public void clearSearchCriteria(){
        $(customPageClearCriteria).click();
    }

    /**
     * Method to verify presence of button.
     *
     */
    public boolean waitForElementWithText(String innerText){
        try{
            verifyAndSwitchFrame();
            commonMethods.waitForElement(driver, By.xpath("//*[contains(text(),'"+ innerText +"')]"));
            return true;
        } catch(TimeoutException e){
            return false;
        }
    }

    /**
     * Method to apply all filters on report listing page.
     *
     * @param sharedWithOptions list of shared with otpions.
     * @param createdByMyselfFlag created by myself flag.
     */
    public void applyAllFilters(List<String> sharedWithOptions, boolean createdByMyselfFlag){
        $$(allFilters).exclude(hidden).get(0).click();
        commonMethods.waitForElement(driver, expandedFilters, 5);
        if(createdByMyselfFlag != $(createdByMyself).isSelected()){
            $(createdByMyself).click();
        }
        SelenideElement shareWithDropDown = $$(sharedWithList).exclude(hidden).get(0);
        shareWithDropDown.click();
        for(String sharedWith : sharedWithOptions) {
            if (!sharedWith.trim().equalsIgnoreCase("EMPTY") && !$(By.xpath("//input[@title-val='" + sharedWith + "']")).isSelected()) {
                $(By.xpath("//input[@title-val='" + sharedWith + "']")).click();
            }
        }
        $(sharedWithInput).click();
        $(customSearchButton).click();
    }

    /**
     * Method to apply all filters on report listing page.
     *
     * @param sharedWithOptions list of shared with otpions.
     * @param createdByMyselfFlag created by myself flag.
     */
    public void applyAllFilters(List<String> sharedWithOptions, boolean createdByMyselfFlag, boolean createdInThisProject){
        $$(allFilters).exclude(hidden).get(0).click();
        commonMethods.waitForElement(driver, expandedFilters, 5);
        if(createdByMyselfFlag != $(createdByMyself).isSelected()){
            $(createdByMyself).click();
        }
        if(createdInThisProject != $(sourceProject).isSelected()){
            $(sourceProject).click();
        }
        SelenideElement shareWithDropDown = $$(sharedWithList).exclude(hidden).get(0);
        shareWithDropDown.click();
        for(String sharedWith : sharedWithOptions) {
            if (!sharedWith.trim().equalsIgnoreCase("EMPTY") && !$(By.xpath("//input[@title-val='" + sharedWith + "']")).isSelected()) {
                $(By.xpath("//input[@title-val='" + sharedWith + "']")).click();
            }
        }
        shareWithDropDown.click();
        $(customSearchButton).click();
    }

    /**
     * Method to import layout for the report.
     *
     * @param reportName Report name.
     * @param templateName name of the template to be imported.
     */
    public void importLayout(String reportName,String templateName){
        selectActionForReport(reportName, "importLayout");
        Assert.assertFalse("Error displayed on the page when import layout option selected.", isErrorDispalyedOnPage());
        driver.switchTo().activeElement().sendKeys(templateName);
        try {
            commonMethods.waitForElementExplicitly(5000);
            new Robot().keyPress(KeyEvent.VK_ESCAPE);
            new Robot().keyRelease(KeyEvent.VK_ESCAPE);
        } catch (AWTException e) {
            e.printStackTrace();
        }
        $(importLayout).sendKeys(templateName);
    }

    /**
     * Method to fetch no report error message from report listing page.
     *
     * @return error message.
     */
    public String getNoReportErrorMessage() {
        try{
            commonMethods.waitForElement(driver, noReportMessageOnCustomPage, 5);
            return $(noReportMessageOnCustomPage).getText();
        }catch(TimeoutException e){
            return $(noReportMessageOnStandardPage).getText();
        }
    }

    /**
     * Method to fetch expected repots details.
     *
     */
    public Map<String, Map<String,String>> fetchExpectedReportDetails() throws IOException {
        Map<String, Map<String,String>> reportDetails = new LinkedHashMap<>();
        String[] standardReports = new String[] {"Project Overview","Document Status","RFI Sent","RFI Received","Mail Status","Mail Response", "Document Transmittal","Project Directory","Workflow Status","Workflow Documents"};
        Properties p =new Properties();
        p.load(new BufferedReader(new InputStreamReader(new FileInputStream(System.getProperty("user.dir") + "/src/main/resources/data/files/layouts/reportDetails.properties"),StandardCharsets.UTF_8)));
        for(int i=0;i<standardReports.length;i++){
            Map<String, String> reportAttributes = new LinkedHashMap<>();
            reportAttributes.put("Description", p.get(standardReports[i].replaceAll("\\s+","_") + "_DESCRIPTION").toString());
            reportDetails.put(p.get(standardReports[i].replaceAll("\\s+","_") + "_REPORT_NAME").toString(), reportAttributes);
        }
        return reportDetails;
    }

    /**
     * Method to select aconex categories on report info popup.
     *
     * @param categories report categories to select.
     */
    public void selectCategories(List<String> categories){
        $(addButon).waitUntil(appear, 15000).click();
        categories.forEach(category -> {
            $(By.xpath("//*[@class='report-types']//*[text()='" + category + "']/preceding-sibling::input")).waitUntil(appears, 10000).click();
        });
        $(reportTypeInfoPopup.saveButton).click();
    }
}