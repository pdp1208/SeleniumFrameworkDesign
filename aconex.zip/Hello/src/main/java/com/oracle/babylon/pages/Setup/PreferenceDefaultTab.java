package com.oracle.babylon.pages.Setup;

import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.$;

public class PreferenceDefaultTab extends PreferencesPage {

    private By defaultTab = By.xpath("//li[contains(.,'Default')]");

    public void navigateAndVerifyPage() {
        getMenuSubmenu("Setup", "Preferences");
        verifyAndSwitchFrame();
        $(defaultTab).click();
        verifyPageTitle("Edit Preferences");
    }

    /**
     * Function to select non default setting
     *
     * @param preference name
     * @param flag true/false
     */
    public void selectNonDefaultSetting(String preference, Boolean flag) {
        selectDefaultSettings(preference, flag);
    }

    public void editSettings(String preference, String option) {
        selectSettingFrom(preference, option);
    }

    public void editSettingForDefault(String preferences) {
        clickEditButtonForSetting(preferences);
    }

    public void checkNonDefaultSettingsForDefault(String preference, String flag) {
        selectNonDefaultSettings(preference, flag);
    }
}
