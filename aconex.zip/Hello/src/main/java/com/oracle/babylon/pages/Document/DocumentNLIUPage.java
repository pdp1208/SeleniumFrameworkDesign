package com.oracle.babylon.pages.Document;

import org.junit.Assert;
import org.openqa.selenium.By;

import java.util.List;

import static com.codeborne.selenide.Selenide.$;

public class DocumentNLIUPage extends DocumentPage {


    //Initialization of web elements
    private By markNoLongerInUse = By.xpath("//a[contains(.,'Mark as No Longer in Use')]");
    private By noLongerInUseWarningMsg = By.xpath("//div[contains(text(),'This action will hide the selected documents in your register and also in the register of all organizations the documents have been transmitted to.')]");
    private By markNoLongerInUseBtn = By.xpath("//div[@class='uiButton-content']/div[contains(.,'Mark as No Longer in Use')]");
    private By addDocsBtn = By.xpath("//button[@id='btnAddDocuments_page']");
    private By noLongerInUseTipMsg = By.xpath("//li[@class='message tip']");


    /**
     * Function to verify multiple Docs under MNLIU page
     *
     * @param docs
     */
    public void verifyNLIUDocs(List<String> docs, String flag) {
        verifyAndSwitchFrame();
        for (int i = 0; i <= docs.size() - 1; i++) {
            String doc = returnDocumentNumber(docs.get(i));
            verifyDocInNLIUPage(doc, flag);
        }
    }

    /**
     * Function to verify Doc in NLIU page
     *
     * @param docName
     * @param flag
     */
    public void verifyDocInNLIUPage(String docName, String flag) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver,addDocsBtn,40);
        commonMethods.waitForElementExplicitly(3000);
        if (flag.equalsIgnoreCase("present")) {
            Assert.assertTrue($(By.xpath("//div[contains(text(),'" + docName + "')]")).isDisplayed());
        } else {
            Assert.assertFalse($(By.xpath("//div[contains(text(),'" + docName + "')]")).isDisplayed());
        }
    }

    /**
     * Function verify fields in NLIU page
     */
    public void verifyFields() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, addDocsBtn, 20);
        Assert.assertTrue($(addDocsBtn).isDisplayed());
        Assert.assertTrue($(markNoLongerInUseBtn).isDisplayed());
        Assert.assertTrue($(noLongerInUseWarningMsg).isDisplayed());
        Assert.assertTrue($(noLongerInUseTipMsg).isDisplayed());
    }

    /**
     * Function to verify doc Bil Icon in NLIU page
     *
     * @param docName
     * @return
     */
    public boolean verifyDocBinIcon(String docName) {
        verifyAndSwitchFrame();
        return $(By.xpath(" //div[contains(text(),'" + returnDocumentNumber(docName) + "')]//../..//img")).isDisplayed();
    }

    /**
     * Function to delete document from NLIU page
     *
     * @param docName
     */
    public void deleteDocInNLIU(String docName) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        $(By.xpath(" //div[contains(text(),'" + returnDocumentNumber(docName) + "')]//../..//img")).click();
    }

    /**
     * Function to add Document
     * @param docOne
     * @param docTwo
     */
    public void addDocument(String docOne, String docTwo) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(4000);
        getElementInView(addDocsBtn);
        commonMethods.waitForElement(driver,addDocsBtn,40);
        $(addDocsBtn).click();
        searchDocumentNo(returnDocumentNumber(docOne) + " OR " + returnDocumentNumber(docTwo));
    }

    /**
     * Function to click on NLIB btn
     */
    public void clickMarkNLIUBtn(){
        verifyAndSwitchFrame();
        $(markNoLongerInUseBtn).click();
    }
}
