package com.oracle.babylon.pages.Package;

import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import static com.codeborne.selenide.Selenide.$;

/**
 * Class created to link the mails to packages
 * Author : susgopal
 */
public class LinkPackagePage extends Navigator {

    private By title = By.xpath("//div[text()='Link to packages']");
    private By packageNumber = By.xpath("//div[text()='Package No']//..//input");
    private By firstCell = By.xpath("//table[@class='auiTable']//tbody//tr[1]//td[1]//input");
    private By linkPackagesBtn = By.xpath("//button[text()='Link to packages']");
    private By successMsg = By.xpath("//div[text()='The process is completed']");
    private By closeBtn = By.xpath("//button[text()='Close']");

    /**
     * Method to verify the page title
     */
    public void verifyTitle(){
        commonMethods.waitForElement(driver, title);
        Assert.assertTrue($(title).isDisplayed());
    }

    public void searchPackage(String packageNo){
        verifyAndSwitchFrame("attachPanel_iframe");
        $(packageNumber).clear();
        $(packageNumber).sendKeys(packageNo);
        $(packageNumber).sendKeys(Keys.ENTER);
        driver.switchTo().defaultContent();
    }

    /**
     * Attach the package to the mails
     */
    public void attachPackage(){
        verifyAndSwitchFrame();
        verifyAndSwitchFrame("attachPanel_iframe");
        commonMethods.waitForElement(driver, firstCell);
        $(firstCell).setSelected(true);
        $(linkPackagesBtn).click();
        driver.switchTo().defaultContent();
    }

    /**
     * Method to verify if we are able to attach successfully
     */
    public void verifySuccessMsg(){
        verifyAndSwitchFrame();
        verifyAndSwitchFrame("attachPanel_iframe");
        commonMethods.waitForElement(driver, successMsg);
        Assert.assertTrue("Success message is not displayed", $(successMsg).isDisplayed());
        $(closeBtn).click();
        driver.switchTo().defaultContent();
    }
}
