package com.oracle.babylon.Utils.setup.dataStore;

import com.oracle.babylon.Utils.helper.CommonMethods;
import com.oracle.babylon.Utils.helper.DirectoryAPI;
import com.oracle.babylon.Utils.setup.FakeData;
import com.oracle.babylon.Utils.setup.dataStore.pojo.Document;
import com.oracle.babylon.Utils.setup.utils.ConfigFileReader;
import io.cucumber.datatable.DataTable;

import java.lang.reflect.Field;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Class to convert the data tables from the test files to data store tables for a document
 * Author : susgopal
 */
public class DocumentTableConverter {
    private Document document;
    private DirectoryAPI directoryAPI = new DirectoryAPI();
    private CommonMethods commonMethods = new CommonMethods();

    public Map<String, Document> createDocumentData(String userIdentifier, DataTable dataTable, String projectId) {
        Map<String, Document> data = new LinkedHashMap<>();
        String author;
        //Object Initialization
        for (Map<Object, Object> documentHashMap : dataTable.asMaps(String.class, String.class)) {
            document = new Document();
            //Map<String, String> documentHashMap = dataTable.transpose().asMap(String.class, String.class);
            FakeData fakeData = new FakeData();
            Date date = new Date();
            //Fetching data
            String companyName = fakeData.getCompanyName();
            fieldReflection(documentHashMap);
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'.0Z'");
            //Assigning values to Document Object
            if (document.getDocumentNumber() == null) {
                if (documentHashMap.containsKey("Document No"))
                    document.setDocumentNumber(documentHashMap.get("Document No").toString());
                else document.setDocumentNumber(fakeData.getDocumentNumber().replace("\\", "").replace("/", ""));
            }

            document.setComments("Test comments for " + companyName + " document");

            if (documentHashMap.containsKey("HasFile"))
                document.setHasFile(documentHashMap.get("HasFile").toString());

            setDocConfidentiality(userIdentifier, projectId, documentHashMap);

            document.setRevision(documentHashMap.get("Revision").toString());

            if (documentHashMap.containsKey("Title")){
                document.setTitle(documentHashMap.get("Title").toString());
            }else {
                if (document.getTitle() == null) document.setTitle(companyName+ " Doc");
            }

            if (documentHashMap.containsKey("Discipline"))
                document.setDiscipline(documentHashMap.get("Discipline").toString());

            if (documentHashMap.containsKey("Attribute 1"))
                document.setAttribute1(documentHashMap.get("Attribute 1").toString().split(","));

            if (documentHashMap.containsKey("Attribute 2"))
                document.setAttribute2(documentHashMap.get("Attribute 2").toString().split(","));

            if (documentHashMap.containsKey("Author")) {
                if (documentHashMap.get("Author").toString().startsWith("user"))
                    author = commonMethods.getUserData(documentHashMap.get("Author").toString(), "organisation");
                else author = documentHashMap.get("Author").toString();
                document.setAuthor(author);
            }

            if (documentHashMap.containsKey("Category")) {
                document.setCategory(documentHashMap.get("Category").toString().split(","));
            }

            if (documentHashMap.containsKey("Reference")) {
                document.setReference(documentHashMap.get("Reference").toString());
            }

            if (documentHashMap.containsKey("Select List 1")) {
                document.setSelectList1(documentHashMap.get("Select List 1").toString().split(","));
            }

            if (documentHashMap.containsKey("Select List 2")) {
                document.setSelectList2(documentHashMap.get("Select List 2").toString().split(","));
            }

            if (documentHashMap.containsKey("VDR Code")) {
                document.setVdrCode(documentHashMap.get("VDR Code").toString().split(","));
            }

            if (documentHashMap.containsKey("Date Created")) {
                document.setDateCreated(dateFormat.format(date));
            }

            document.setRevisionDate(dateFormat.format(date));

            data.put("document" + documentHashMap.get("serial_num"), document);
        }
        return data;
    }

    /**
     * Rename it appropriately
     */
    public void fieldReflection(Map<Object, Object> documentHashMap) {
        for (Field field : document.getClass().getDeclaredFields()) {
            if (field != null) {
                field.setAccessible(true);
                for (Object key : documentHashMap.keySet()) {
                    if (key != null) {
                        String keyname = (String) key;
                        if (field.getName().equalsIgnoreCase(keyname.replaceAll("\\s+", ""))) {
                            if (field.getType() == Integer.TYPE) {
                                try {
                                    field.setInt(document, (Integer) documentHashMap.get(key));
                                } catch (IllegalAccessException e) {
                                    e.printStackTrace();
                                }
                            } else if (field.getType().equals(String.class)) {
                                try {
                                    field.set(document, documentHashMap.get(key));
                                } catch (IllegalAccessException e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public List<Map<String, Document>> getDocumentData(String userIdentifier, DataTable dataTable, String projectId) {
        List<Map<String, Document>> data = new ArrayList<>();
        String author;
        FakeData fakeData = new FakeData();
        Date date = new Date();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'.0Z'");

        //Object Initialization
        for (Map<Object, Object> documentHashMap : dataTable.asMaps(String.class, String.class)) {
            Map<String, Document> docData = new LinkedHashMap<>();
            document = new Document();
            //Assigning values to Document Object

            if (documentHashMap.containsKey("HasFile"))
                document.setHasFile(documentHashMap.get("HasFile").toString());

            if (documentHashMap.containsKey("Confidentiality"))
                setDocConfidentiality(userIdentifier, projectId, documentHashMap);

            if (documentHashMap.containsKey("Revision"))
                document.setRevision(documentHashMap.get("Revision").toString());

            if (documentHashMap.containsKey("Status"))
                document.setDocumentStatusId(documentHashMap.get("Status").toString());

            if (documentHashMap.containsKey("Type"))
                document.setDocumentTypeId(documentHashMap.get("Type").toString());

            if (documentHashMap.containsKey("Title")){
                document.setTitle(documentHashMap.get("Title").toString());
            }else {
                if (document.getTitle() == null) document.setTitle(fakeData.getCompanyName() + " Doc");
            }

            if (documentHashMap.containsKey("Discipline"))
                document.setDiscipline(documentHashMap.get("Discipline").toString());

            if (documentHashMap.containsKey("Attribute 1"))
                document.setAttribute1(documentHashMap.get("Attribute 1").toString().split(","));

            if (documentHashMap.containsKey("Attribute 2"))
                document.setAttribute2(documentHashMap.get("Attribute 2").toString().split(","));

            if (documentHashMap.containsKey("Author")) {
                if (documentHashMap.get("Author").toString().startsWith("user"))
                    author = commonMethods.getUserData(documentHashMap.get("Author").toString(), "organisation");
                else author = documentHashMap.get("Author").toString();
                document.setAuthor(author);
            }

            if (documentHashMap.containsKey("Category"))
                document.setCategory(documentHashMap.get("Category").toString().split(","));

            if (documentHashMap.containsKey("Reference"))
                document.setReference(documentHashMap.get("Reference").toString());

            if (documentHashMap.containsKey("Select List 1"))
                document.setSelectList1(documentHashMap.get("Select List 1").toString().split(","));

            if (documentHashMap.containsKey("Select List 2"))
                document.setSelectList2(documentHashMap.get("Select List 2").toString().split(","));

            if (documentHashMap.containsKey("VDR Code"))
                document.setVdrCode(documentHashMap.get("VDR Code").toString().split(","));

            if (documentHashMap.containsKey("Date Created")) document.setDateCreated(dateFormat.format(date));

            document.setRevisionDate(dateFormat.format(date));
            docData.put("document" + documentHashMap.get("serial_num"), document);
            data.add(docData);
        }
        return data;
    }

    public void setDocConfidentiality(String userIdentifier, String projectId, Map<Object, Object> documentHashMap) {
        if (documentHashMap.get("Confidentiality").toString().equalsIgnoreCase("yes") && documentHashMap.containsKey("AccessList")) {
            List<String> userIds = directoryAPI.searchProjectDirectory(documentHashMap.get("AccessList").toString(), projectId);
            if (userIds.size() == 1) {
                document.setAccessList(userIds.get(0));
            } else {
                StringBuilder id = new StringBuilder();
                for (String userId : userIds) {
                    id.append(userId).append(",");
                }
                id = new StringBuilder(id.substring(0, id.toString().lastIndexOf(',')));
                document.setAccessList(id.toString());
            }
        } else if (documentHashMap.get("Confidentiality").toString().equalsIgnoreCase("yes")) {
            List<String> userIds = directoryAPI.searchProjectDirectory(userIdentifier, projectId);
            document.setAccessList(userIds.get(0));
        }
    }

}
