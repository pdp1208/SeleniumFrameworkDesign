package com.oracle.babylon.Utils.helper;

import java.io.*;
import java.util.Properties;

public class DataLoader {
    static Properties properties;
    static String configFilePath = "src/main/resources/configFile.properties";

    /**
     * Load the properties from the config file
     */
    public  static Properties loadProperties(){
        System.out.println("Loading properties");
        BufferedReader reader;

        try {
            reader = new BufferedReader(new FileReader(configFilePath));
            properties = new Properties();
            try {
                properties.load(reader);
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            throw new RuntimeException("Configuration.properties not found at " + configFilePath);
        }
        return properties;
    }
    /**
     * Method to create a folder and copy the required data files
     * @param folderName
     */
    public static void createFolder(String folderName){

        String folderPath = System.getProperty("user.dir") + properties.getProperty("DATA_JSON");
        String path = folderPath + folderName;
        File newDirectory = new File(path);
        if(!newDirectory.exists()){
            newDirectory.mkdir();
            File sourceDirectory = new File(folderPath + "mumbaiqa17");
            File[] listOfFiles = sourceDirectory.listFiles();
            try {
                for (File oldFile : listOfFiles) {
                    File newFile = new File(newDirectory + "/" + oldFile.getName());
                    newFile.createNewFile();
                    FileWriter myWriter = new FileWriter(newFile);
                    myWriter.write("{}");
                    myWriter.close();

                }
            } catch (IOException io){
                io.printStackTrace();
            }
        } else {
            System.out.println("Folder already is present");
        }
    }
}
