package com.oracle.babylon.pages.Field;

import com.codeborne.selenide.Condition;
import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class InspectionsPage extends IssuesPage {

    private String acceptType = "audio/mp3, audio/wav, video/mpg, video/mp4, video/mov, video/avi, video/mpeg, video/qt(?), image/jpg, image/jpeg, image/png, .xlsx, .xls, .doc, .docx, .ppt, .pptx, .txt, .dwg, .dxf, .pdf, .mov";
    private String fieldInspectionDataPath = configFileReader.getFieldInspectionDataPath();
    private By backBtn = By.xpath("//button[@class='auiButton back ng-scope']");
    private By newInspection = By.xpath("//button[text()='New Inspection']");
    private By searchTemplate = By.xpath("//div[@class='search-filter-component']//input[@type='text']");
    private By chooseTemplateAll = By.xpath("//li//*[text()='All']");
    private By question1 = By.xpath("//label[text()='Question 1']//..//..//*[text()='Pass']");
    private By question1_issue = By.xpath("//label[text()='Question 1']//..//..//*[contains(@class,'issue-attachment ng-binding')]");
    private By question2 = By.xpath("//label[text()='Question 2']//..//..//input[@type='text']");
    private By question2_photo = By.xpath("//label[text()='Question 2']//..//..//*[contains(@class,'photo-attachment ng-binding')]");
    private By uploadPhoto = By.id("//input[@id='upload-checklist-add-photo-attachment']");
    private By question3Label = By.xpath("//label[text()='Question 3']");
    private By question3 = By.xpath("//label[text()='Question 3']//..//..//textarea");
    private By question4 = By.xpath("//label[text()='Question 4']//..//..//span[text()='Yes']");
    private By question4_issue = By.xpath("//label[text()='Question 4']//..//..//*[contains(@class,'issue-attachment ng-binding')]");
    private By addAnIssue = By.xpath("//div//*[text()='Add Issue']");
    private By addAPhoto = By.xpath("//div//span[text()='Add Photos']");
    private By doneBtn = By.xpath("//button[@class='auiButton primary']//span[text()='Done']");
    private By doneOnUploadBtn = By.xpath("//button[text()='Done']");
    private By successMsg = By.xpath("//div[text()='Changes to the inspection have been saved']");
    private By uploadAttachment = By.xpath("//div[@class='add-photo']//div[@class='upload-attachment']");
    protected By loader = By.xpath("//div[@class='auiLoaderOverlay-loader']");
    private By closeAttachmentBtn = By.xpath("//span[@class='auiIcon close-attachment']");
    private By checkListCreatedNo = By.xpath("//div[@class='checklist-details-number no-padding ng-binding']");
    //private By searchInspectionNo=By.xpath("//input[@placeholder='Search by inspection number or title']");
    private By searchInspectionNo = By.xpath("//input[@placeholder='Search in Inspections']");
    private By searchBtn = By.xpath("//button[(text()='Search')]");
    private By statusDropDown = By.xpath("//div[contains(@class,'status-field ng-scope dropdown')]");
    private By provideComments = By.id("content");
    private By filtersLink = By.xpath("//div[@class='vertical-text ng-scope']//*[text()='Filters']");
    private By applyBtn = By.xpath("//button[text()='Apply']");
    private By clearAll = By.xpath("//div[text()='Clear All']");
    private By actionBtn = By.xpath("//button//span[text()='Actions']");
    private By savingMsgInTemp = By.xpath("//div[@class='content-message ng-binding']");
    private By contentMsgInTemp = By.xpath("//div[@class='content-message-link']");
    private By okBtn = By.xpath("//button[text()='OK']");
    private By exportAll = By.xpath("//button[text()='Export All']");
    private By goToTemporaryFiles = By.xpath("//a[text()='Go to the Temporary Files List']");
    private By temporaryFilesHeader = By.id("mainHeading");
    private By temporaryFilesSearch = By.xpath("//div[contains(@class,'ag-center-cols-container')]//div[@role='row']");
    private By requestCheckBox = By.xpath("//div[@id='REQUEST_CHECKBOX']//input[@type='checkbox']");
    private By inspectionsAttachments = By.xpath("//a[text()='Attachments']");
    private By attachNewFile = By.xpath("//*[text()='Attach new file']");
    private By uploadAttachmentOnInspection = By.xpath("//li//a//*[text()='Upload File']");
    private By browseAttachmentOnInspection = By.xpath("//a[text()='browse']");
    private By inputIdAttachment = By.xpath("//input[@id='file-attachment']");
    private By uploadAttachmentBtn = By.xpath("//button[text()='Upload']");
    private By chevorIconLeft = By.xpath("//*[@class='auiIcon chevronLeft']");


    public void navigateAndVerifyPage() {
    	getMenuSubmenu("Tasks", "My Tasks");
        getMenuSubmenu("Field", "Inspections");
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, toolBarSection, 90);
        Assert.assertTrue("Inspections page title is not displayed", $(toolBarSection).getText().contains("Inspections"));
    }

    public void clickNewInspection() {
        commonMethods.waitForElement(driver, newInspection, 60);
        $(newInspection).click();
    }

    public void startInspection(String templateName) {
        $(searchTemplate).sendKeys(templateName);
        $(By.xpath("//td[@class='template-name-cell']//span[text()='" + templateName + "']")).click();
        By value = By.xpath("//td[@class='template-name-cell']//span[text()='" + templateName + "']//..//..//button[contains(text(),'Start')]");
        $(value).click();
    }

    public void selectAllTemplatesDisplay() {
        commonMethods.waitForElementExplicitly(5000);
        $(loadingIcon).should(disappear);
        //commonMethods.waitForElement(driver, loader, 5);
        $(loader).waitUntil(disappear, 5000);
        commonMethods.waitForElement(driver, chooseTemplateAll);
        //        $(chooseTemplateAll).click();
    }

    public String fillInspection() {
        $(question1).click();
        $(question1_issue).click();
        $(addAnIssue).click();
        fillIssueOnInspection("Safety");
        commonMethods.waitForElementExplicitly(5000);
        $(question2).sendKeys("Test");
        $(By.xpath("//div[@class='main-section wide']")).click();
        commonMethods.waitForElementExplicitly(5000);
        try {
            pressDownKey();
        } catch (Exception e) {
        }
        $(question4).click();
        commonMethods.waitForElementExplicitly(5000);
        getElementInView(saveButton);
        clickSaveBtn();
        commonMethods.waitForElement(driver, successMsg);
        $(backBtn).click();
        return getInspectionNo();
        //$(question2_photo).click();
        //$(uploadAttachment).click();
        // commonMethods.waitForElement(driver,uploadPhoto);
        //$(uploadAttachment).sendKeys(filePath+"sample.png");
        //Actions action = new Actions(driver);
        //action.sendKeys(Keys.ESCAPE);
        //action.sendKeys(Keys.ESCAPE);
        //action.sendKeys(Keys.ESCAPE);
        //commonMethods.waitForElementExplicitly(5000);
        //getElementInView(question3Label);
        // $(question3).scrollTo();
        //JavascriptExecutor js = ((JavascriptExecutor) driver);
        //js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
//        $(question3).click();
        //      $(question3).sendKeys("test textarea");

        //getElementInView(question4);
      /*  $(question4_issue).click();
        $(addAnIssue).click();
        fillIssueOnInspection("Safety");*/
    }


    public void fillIssueOnInspection(String issueTypeText) {
        commonMethods.waitForElement(driver, doneBtn);
        $(issueType).click();
        try {
            commonMethods.waitForElement(driver, issueSearchInput, 60);
            $(issueSearchInput).sendKeys(issueTypeText);
        } catch (Exception e) {
            $(By.xpath("(//input[@type='search' and contains(@class,'form-control ui-select-search')])[2]")).sendKeys(issueTypeText);
        }
        commonMethods.waitForElementExplicitly(2000);
        By selectType = By.xpath("//span[@class='ui-select-choices-row-inner']//span[text()='" + issueTypeText + "']");
        commonMethods.waitForElement(driver, selectType);
        $(selectType).click();
        String descriptionValue = "This is for Testing Issue " + faker.number().digits(5);
        $(textArea).click();
        commonMethods.waitForElementExplicitly(3000);
        $(textArea).sendKeys(descriptionValue);
        //$(photoAttachment).sendKeys(filePath+"sample.png");
        commonMethods.waitForElementExplicitly(3000);
        $(By.cssSelector(".auiLoaderOverlay-loader")).waitUntil(disappear, 60000, 3000);
        $(doneBtn).click();
        $(By.cssSelector(".auiLoaderOverlay-loader")).waitUntil(disappear, 60000, 3000);
        commonMethods.waitForElementExplicitly(2000);
        if ($(chevorIconLeft).isDisplayed()) {
            $(chevorIconLeft).click();
            commonMethods.waitForElementExplicitly(2000);
        }
        commonMethods.waitForElement(driver, closeAttachmentBtn, 60);
        $(closeAttachmentBtn).click();
    }

    public void pressDownKey() throws Exception {
        Robot robot = new Robot();  // Robot class throws AWT Exception
        commonMethods.waitForElementExplicitly(3000);
        robot.keyPress(KeyEvent.VK_DOWN);  // press arrow down key of keyboard to navigate and select Save radio button
        commonMethods.waitForElementExplicitly(3000);
        robot.keyPress(KeyEvent.VK_DOWN);
        commonMethods.waitForElementExplicitly(3000);
        robot.keyPress(KeyEvent.VK_DOWN);
    }

    public void writeInspectionNumToJson(String inspectionId, String inspectionNo) {
        //Write the data to the json file
        Map<String, Object> map = new Hashtable<>();
        Map<String, Map<String, Object>> mapOfMap = new HashMap<>();
        map.put("inspection_number", inspectionNo);
        mapOfMap.put(inspectionId, map);
        dataSetup.fileWrite(inspectionId, mapOfMap, fieldInspectionDataPath);
    }

    public String getInspectionNoFromJSON(String issueId) {
        Map<String, Map<String, Object>> jsonData = new HashMap<>();
        Map<String, Object> map = new HashMap<>();
        jsonData = dataSetup.loadJsonDataToMap(fieldInspectionDataPath);
        map = jsonData.get(issueId);
        return map.get("inspection_number").toString();
    }

    public void searchInspection(String inspectionNo) {
        commonMethods.waitForElementExplicitly(10000);
        commonMethods.waitForElement(driver, searchInspectionNo);
        $(searchInspectionNo).sendKeys(inspectionNo);
        clickSearch();
        $(loadingIcon).should(disappear);
        commonMethods.waitForElementExplicitly(3000);
        Assert.assertEquals("Inspection " + inspectionNo + " is not displayed", inspectionNo, getInspectionNo());
    }

    public void clickSearch() {
        commonMethods.waitForElement(driver, searchBtn);
        $(searchBtn).click();
    }

    public String getInspectionNo() {
        commonMethods.waitForElement(driver, checkListCreatedNo);
        return $(checkListCreatedNo).getText();
    }

    public void changeStatus(String statusValue) {
        commonMethods.waitForElement(driver, statusDropDown);
        $(statusDropDown).click();
        // By status=By.xpath("//span[@class='status-description ng-binding' and text()='"+statusValue+"']");
        By status = By.xpath("//*[contains(@class,'new-checklist-details ng-scope')]//*[contains(@class,'ng-binding') and text()='" + statusValue + "']");
        commonMethods.waitForElement(driver, status);
        $(status).click();
        commonMethods.waitForElementExplicitly(5000);
        if ($(saveButton).isDisplayed()) {
            $(provideComments).click();
            $(provideComments).sendKeys("Changing the " + statusValue);
            clickSaveBtn();
        }
    }

    public String verifyStatus() {
        commonMethods.waitForElementExplicitly(4000);
        commonMethods.waitForElement(driver, statusDropDown);
        return $(statusDropDown).getText();
    }

    public void navigateToFilters() {
        commonMethods.waitForElement(driver, filtersLink);
        $(filtersLink).click();
    }

    public void applyFilters(String status) {
        By statusCheckBox = By.xpath("//label[text()='" + status + "']//..//input[@type='checkbox']");
        commonMethods.waitForElement(driver, statusCheckBox);
        $(statusCheckBox).click();
        clickApplyBtn();
        commonMethods.waitForElementExplicitly(4000);
    }

    public void clickApplyBtn() {
        commonMethods.waitForElement(driver, applyBtn);
        $(applyBtn).click();
    }

    public boolean verifyAppliedFilters(String status) {
        boolean flag = false;
        String classValue;
        if (status.equalsIgnoreCase("Open"))
            classValue = "checklist-status open";
        else
            classValue = "Closed";
        commonMethods.waitForElementExplicitly(15000);
        int sizeValue = $$(By.xpath("//div[@class='status-line']//div")).size();
        int iterationSize = 0;
        System.out.println(sizeValue);
        if (sizeValue < 10)
            iterationSize = sizeValue;
        else
            iterationSize = sizeValue / 2;
        for (int iterator = 1; iterator <= iterationSize; iterator++) {
            try {
                Assert.assertEquals(classValue + " is not displayed", classValue, $(By.xpath("(//div[@class='status-line']//div)[" + iterator + "]")).getText());
                flag = true;
            } catch (Exception e) {
                return flag;
            }

        }
        return flag;
    }

    public void clearFilters() {
        commonMethods.waitForElement(driver, clearAll);
        $(clearAll).click();
    }

    public void clickActionBtn(String option) {
        commonMethods.waitForElement(driver, actionBtn);
        $(actionBtn).click();
        By optionProp = By.xpath("//ul//a[text()='" + option + "']");
        commonMethods.waitForElement(driver, optionProp);
        $(optionProp).click();
    }

    public String getInspectionFileName() {
        commonMethods.waitForElement(driver, By.xpath("//div[@class='fileNameTitle ng-binding']//..//input[@type='text']"));
        return $(By.xpath("//div[@class='fileNameTitle ng-binding']//..//input[@type='text']")).getValue();
    }

    public void verifySuccessMsgOnTemp() {
        commonMethods.waitForElement(driver, savingMsgInTemp);
        Assert.assertTrue("You will receive an email notification when it is ready message is not displayed", $(savingMsgInTemp).getText().contains("You will receive an email notification when it is ready."));
        Assert.assertTrue("Currently saving the inspection as is not displayed", $(savingMsgInTemp).getText().contains("Currently saving the inspection as "));
        Assert.assertTrue("Saved inspections can be found in Temporary Files message is not displayed", $(contentMsgInTemp).getText().contains("Saved inspections can be found in Temporary Files."));
        $(okBtn).click();
    }

    public void exportAllToTemp() {
        commonMethods.waitForElement(driver, exportAll);
        $(exportAll).click();
        commonMethods.waitForElement(driver, goToTemporaryFiles);
        $(goToTemporaryFiles).click();
        commonMethods.waitForElement(driver, temporaryFilesHeader);
        Assert.assertEquals("Temporary files page header is not displayed", "Temporary Files", $(temporaryFilesHeader).getText());
        commonMethods.waitForElement(driver, temporaryFilesSearch);

    }

    public String fillPDFInspection() {
        webViewerFrame();
        commonMethods.waitForElement(driver, requestCheckBox);
        $(requestCheckBox).setSelected(true);
        verifyAndSwitchFrame();
        clickSaveBtn();
        commonMethods.waitForElement(driver, successMsg);
        $(backBtn).click();
        return getInspectionNo();
    }

    public void clickAttachmentsOnInspections() {
        commonMethods.waitForElement(driver, inspectionsAttachments);
        $(inspectionsAttachments).click();
        commonMethods.waitForElement(driver, attachNewFile);
        $(attachNewFile).click();
//        if (configFileReader.getApplicationUrl().contains("us1preprod")) {
//            commonMethods.waitForElement(driver, uploadAttachmentOnInspection);
//            $(uploadAttachmentOnInspection).click();
//        }
        commonMethods.waitForElement(driver, browseAttachmentOnInspection);
        //$(browseAttachmentOnInspection).click();
        Assert.assertEquals(acceptType, $(inputIdAttachment).getAttribute("accept"));
        //$(inputIdAttachment).sendKeys(filePath+"sample.png");
        //commonMethods.waitForElementExplicitly(3000);
        //$(inputIdAttachment).sendKeys(filePath+"16.jpg");
        commonMethods.waitForElementExplicitly(3000);
        $(inputIdAttachment).sendKeys(filePath + "street_plan.pdf");
        commonMethods.waitForElementExplicitly(3000);
        $(inputIdAttachment).sendKeys(filePath + "street_plan.txt");
        commonMethods.waitForElementExplicitly(3000);
        $(uploadAttachmentBtn).click();
        commonMethods.waitForElementExplicitly(6000);
        $(doneOnUploadBtn).click();
        commonMethods.waitForElementExplicitly(6000);
        commonMethods.waitForElement(driver, By.xpath("//td[contains(text(),'street_plan.pdf')]"));
    }
}
