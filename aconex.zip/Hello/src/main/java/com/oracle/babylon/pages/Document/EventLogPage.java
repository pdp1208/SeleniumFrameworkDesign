package com.oracle.babylon.pages.Document;

import com.oracle.babylon.Utils.helper.Navigator;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.$;

public class EventLogPage extends Navigator {
    private By relatedItemsTab = By.xpath("//a[text()='Related Items Events']");
    private By eventElement = By.xpath("//th[text()='Event']//input");
    private By eventValue = By.xpath("//table[@class='auiTable']//tbody//tr//td[2]");
    private By typeValue = By.xpath("//table[@class='auiTable']//tbody//tr//td[1]");

    /**
     * Method to click on the Related items tab
     */
    public void clickRelatedItemsTab(){
        $(relatedItemsTab).click();
    }

    /**
     * Method to search for an event.
     * @param documentNumber Providing this parameter to search the documents
     */
    public void searchEvent(String documentNumber){
        $(eventElement).sendKeys(documentNumber);
    }

    /**
     * Method to clear the event text box
     */
    public void clearEvent(){
        $(eventElement).clear();
    }

    /**
     * Method to return the first event in the table
     * @return
     */
    public String returnFirstEvent(String documentNumber){
        By by = By.xpath("//table[@class='auiTable']//tbody//tr//a[contains(text(),'" + documentNumber +"')]//..");
        return $(by).getText();
    }

    /**
     * Method to return the type value from the table
     * @return
     */
    public String returnFirstType(){
        return $(typeValue).getText();
    }

    /**
     * Method to click on source document event in the table
     * @return
     */
    public void clickOnSourceDoc(String documentNumber){
        commonMethods.waitForElementExplicitly(2000);
        By by = By.xpath("//table[@class='auiTable']//tbody//tr[2]//a[contains(text(),'" + documentNumber +"')]");
         $(by).click();
    }
}
