package com.oracle.babylon.Utils.setup.utils;

import com.oracle.babylon.Utils.setup.utils.ConfigFileReader;

/**
 * Class for sharing application specific properties with report microservice specific classes.
 *
 */
public abstract class ConfigPropertyHelper extends ConfigFileReader {

    /**
     * Method for getting application base url.
     *
     */
    public String getApplicationBaseURL(){
        return getApplicationUrl();
    }
}
