package com.oracle.babylon.pages.Fields;

import com.oracle.babylon.Utils.helper.Navigator;
import io.cucumber.datatable.DataTable;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;

import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;

public class DailyReportsPage extends Navigator {

    private By weatherTime = By.xpath("//div[@id='WEATHER_TIME']//oj-input-time//input[contains(@class, 'oj-inputdatetime-input')]");
    private By weatherObservation = By.xpath("//div[@id='WEATHER_OBSERVATION']//oj-select-single//a");
    private By weatherTemperature = By.xpath("//div[@id='WEATHER_TEMPERATURE']//input");
    private By weatherWindDir = By.xpath("//div[@id='WEATHER_WIND_DIR']//oj-select-single//a");
    private By weatherWindSpeed = By.xpath("//div[@id='WEATHER_WIND_SPEED']//input");
    private By weatherPrecipitation = By.xpath("//div[@id='WEATHER_PRECIPITATION']//input");
    private By weatherHumidity = By.xpath("//div[@id='WEATHER_HUMIDITY']//input");
    private By addWeatherRowButton = By.xpath("//div[@id='WEATHER']//div//div[2]//oj-button");
    private By addWorkforceRowButton = By.xpath("//div[@id='WORKFORCE']//div//div[2]//oj-button");
    private By workforceOrg = By.xpath("//*[@id='WORKFORCE_ORGANIZATION']//input[contains(@class, 'combobox-input')]");
    private By myOrg = By.xpath("//li/div[contains(text(),'My Organization')]");
    private By workforce = By.xpath("(//group-panel[@id='WORKFORCE']//input[contains(@class,'oj-inputnumber-input')])[1]");
    private By total = By.xpath("(//group-panel[@id='WORKFORCE']//input[contains(@class,'oj-inputnumber-input')])[2]");
    private By workUnderTaken = By.xpath("//group-panel[@id='WORKFORCE']//textarea");
    private By generalComments = By.xpath("//group-panel[@id='GENERAL_COMMENTS']//textarea");
    private By dateContainer = By.xpath("//*[contains(@id,'date-container')]");
    private By dayCard = By.xpath("//*[contains(@id,'date-container')]/*[contains(@class,'day-card')]//*[contains(@class,'date-container')]");
    private By reportEdit = By.xpath("//*[@id='view-daily-reports-edit']");
    private By saveReport = By.xpath("//*[contains(@class,'button-container')]//span[text()='Save']/parent::div");
    private By back = By.xpath("//*[text()='Back']");
    /**
     * Method to navigate to Daily Reports page.
     * .
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Field", "Daily Reports");
        commonMethods.switchToFrame(driver, "frameMain");
        waitForLoaderToDisappear();
    }

    /**
     * Method to add workforce data for field.
     * .
     */
    public void addWeatherData(List<Map<String, String>> dataTable) {
        int dataRow = 0;
        for (Map<String, String> row : dataTable) {
            dataRow++;
            for(Map.Entry<String, String> entry : row.entrySet()){
                switch(entry.getKey().toLowerCase()){
                    case "time":
                        $(weatherTime).setValue(row.get("Time"));
                        break;
                    case "observation":
                        $(weatherObservation).click();
                        $(By.xpath("//li/div/span[contains(text(), '" + row.get("Observation") + "')]")).click();
                        break;
                    case "temp":
                        $(weatherTemperature).setValue(row.get("Temp"));
                        break;
                    case "winddirection":
                        $(weatherWindDir).click();
                        $(By.xpath("//li/div/span[contains(text(), '" + row.get("WindDirection") + "')]")).click();
                        break;
                    case "windspeed":
                        $(weatherWindSpeed).setValue(row.get("WindSpeed"));
                        break;
                    case "precipitation":
                        $(weatherPrecipitation).setValue(row.get("Precipitation"));
                        break;
                    case "humidity":
                        $(weatherHumidity).setValue(row.get("Humidity"));
                        break;
                    case "weathercomments":
                        break;
                }
            }
            $(addWeatherRowButton).click();
            commonMethods.waitForElement(driver, By.xpath("//group-panel[@id='WEATHER']//table//tbody/tr[" + dataRow + "]"));
        }
    }

    /**
     * Method to add workforce data for field.
     * .
     */
    public void addWorkforceData(List<Map<String, String>> dataTable) {
        int dataRow = 0;
        for (Map<String, String> row : dataTable) {
            dataRow++;
            for(Map.Entry<String, String> entry : row.entrySet()){
                switch(entry.getKey().toLowerCase()){
                    case "organization":
                        $(workforceOrg).click();
                        $(myOrg).click();
                        break;
                    case "people":
                        $(workforce).setValue(entry.getValue());
                        break;
                    case "total":
                        $(total).setValue(entry.getValue());
                        break;
                    case "workundertaken":
                        $(workUnderTaken).setValue(entry.getValue());
                        break;
                }
            }
            $(addWorkforceRowButton).click();
            commonMethods.waitForElement(driver, By.xpath("//group-panel[@id='WORKFORCE']//table//tbody/tr[" + dataRow + "]"));
        }
    }

    /**
     * Method to add general comments for field.
     * .
     */
    public void addGeneralComments(List<Map<String, String>> dataTable) {
        for (Map<String, String> row : dataTable) {
            for(Map.Entry<String, String> entry : row.entrySet()){
                $(generalComments).setValue(entry.getValue());
            }
        }
    }

    /**
     * Method to open edit data page for specified section.
     *
     * @param dataTable data
     * @param section section.
     */
    public void addData(DataTable dataTable, String section) {
        commonMethods.waitForElement(driver, dateContainer, 10);
        for (int index=5; index<7; index++) {
            $(dayCard, index).waitUntil(appears, 6000).click();
            String date = $(dayCard, index).getText();
            if ($(By.xpath("//group-panel[@id='" + section.toUpperCase() + "']/oj-collapsible")).getAttribute("class").contains("collapsed")) {
                $(By.xpath("//group-panel[@id='" + section.toUpperCase() + "']//a[contains(@class,'component')]")).click();
            }
            $(reportEdit).waitUntil(appears, 5000).click();
            commonMethods.waitForElement(driver, By.xpath("//*[text()='" + date + "']"));
            $(By.xpath("//group-panel[@id='" + section.toUpperCase() + "']")).scrollTo();
            if ($(By.xpath("//group-panel[@id='" + section.toUpperCase() + "']/oj-collapsible")).getAttribute("class").contains("collapsed")) {
                $(By.xpath("//group-panel[@id='" + section.toUpperCase() + "']//a[contains(@class,'component')]")).click();
            }
            switch(section.toLowerCase()){
                case "weather":
                    addWeatherData(dataTable.asMaps(String.class,String.class));
                    break;
                case "workforce":
                    addWorkforceData(dataTable.asMaps(String.class,String.class));
                    break;
                case "general_comments":
                    addGeneralComments(dataTable.asMaps(String.class,String.class));
                    break;
            }

            try {
                commonMethods.waitForElement(driver, saveReport, 6);
                $(saveReport).waitUntil(appears, 5000).click();
            } catch(TimeoutException e){
                //ignore
            }
            $(back).waitUntil(appears, 5000).click();
        }
    }
}
