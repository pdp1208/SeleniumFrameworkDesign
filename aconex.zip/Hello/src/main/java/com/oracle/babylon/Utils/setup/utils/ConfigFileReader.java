package com.oracle.babylon.Utils.setup.utils;

import com.oracle.babylon.Utils.helper.ConfigSingleton;
import com.oracle.babylon.Utils.helper.DataLoader;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Class to read the values of the config file and use it in the framework
 */
public class ConfigFileReader {

    private static Properties properties = DataLoader.loadProperties();
    public String confileFilePath = "src/main/resources/configFile.properties";
    private static boolean apiProxy;
    private static String envName = returnEnvVar();
    public static boolean onlyAPIFlag=false;


//    /**
//     * Load the data from the config file and make it accessible to the Properties variable
//     */
//    public ConfigFileReader() {
//        BufferedReader reader;
//        try {
//            reader = new BufferedReader(new FileReader(confileFilePath));
//            properties = new Properties();
//            try {
//                properties.load(reader);
//                reader.close();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//            throw new RuntimeException("Configuration.properties not found at " + confileFilePath);
//        }
//    }

    //Each field in the config file has a respective Getter method
    public String getDriverPath() {
        String driverPath = properties.getProperty("DriverPath");
        if (driverPath != null) return driverPath;
        else throw new RuntimeException("driverPath not specified in the configFile.properties file.");
    }

    public String getProxyURL() {
        String proxyUrl = properties.getProperty("PROXY_URL");
        if (proxyUrl != null) return proxyUrl;
        else throw new RuntimeException("Proxy URL not specified in the configFile.properties file.");
    }

    public String getNoProxyURL() {
        String noProxyUrl = properties.getProperty("NO_PROXY_URL");
        if (noProxyUrl != null) return noProxyUrl;
        else throw new RuntimeException("No Proxy URL not specified in the configFile.properties file.");
    }

    public long getImplicitlyWait() {
        String implicitlyWait = properties.getProperty("ImplicitlyWaitTime");
        if (implicitlyWait != null) return Long.parseLong(implicitlyWait);
        else throw new RuntimeException("implicitlyWait not specified in the CconfigFile.properties file.");
    }

    public boolean getHttpProxyStatus() {
        String setProxy = properties.getProperty("HTTP_PROXY");
        if (setProxy != null && setProxy.equals("true")) return true;
        else return false;
    }

    public boolean getAPIProxyStatus() {
        return ConfigFileReader.apiProxy;
    }

    /**
     * Method to set the api proxy to the state present in the config file
     */
    public void setAPIProxyStatus() {
        String setProxy = properties.getProperty("API_PROXY");
        if (setProxy != null && setProxy.equals("true")) {
            ConfigFileReader.apiProxy = true;
        } else {
            ConfigFileReader.apiProxy = false;
        }

    }

    /**
     * Method to set the api proxy value. We need to dynamically switch within a test execution
     *
     * @param status
     */
    public void setAPIProxyStatus(boolean status) {
        ConfigFileReader.apiProxy = status;
    }


    public static String getApplicationUrl() {
        String url = properties.getProperty("URL");
        if (url != null) return url;
        else throw new RuntimeException("Url not specified in the configFile.properties file.");
    }

    public String getPassword() {
        String password = properties.getProperty("PASSWORD");
        if (password != null) return password;
        else throw new RuntimeException("Password not specified in the configFile.properties file.");
    }


    public String getBrowser() {
        String browser = properties.getProperty("BROWSER");
        if (browser != null) return browser;
        else throw new RuntimeException("Browser is not specified in the configFile.properties file.");
    }

    public String getMode() {
        String mode = properties.getProperty("MODE");
        if (mode != null) return mode;
        else throw new RuntimeException("Mode is not specified in the configuration.propertied file");
    }

    public String getJiraUrl() {
        String jira_url = properties.getProperty("JIRA_URL");
        if (jira_url != null) return jira_url;
        else throw new RuntimeException("JIRA URL is not specified in the configuration.propertied file");
    }

    public String getAdminUsername() {
        String admin_username = properties.getProperty("ADMIN_USERNAME");
        if (admin_username != null) return admin_username;
        else throw new RuntimeException("Admin Username is not specified in the configuration.propertied file");
    }

    public String getPolearyUsername() {
        String admin_username = properties.getProperty("POLEARY_USERNAME");
        if (admin_username != null) return admin_username;
        else throw new RuntimeException("Admin Username is not specified in the configuration.propertied file");
    }

    public String getPolearyPassword() {
        String admin_username = properties.getProperty("POLEARY_PASSWORD");
        if (admin_username != null) return admin_username;
        else throw new RuntimeException("Admin Username is not specified in the configuration.propertied file");
    }

    public String getPolearyProject() {
        String project = properties.getProperty("POLEARY_PROJECT");
        if (project != null) return project;
        else throw new RuntimeException("Admin Username is not specified in the configuration.propertied file");
    }

    public String getEmailId() {
        String email_id = properties.getProperty("EMAIL");
        if (email_id != null) return email_id;
        else throw new RuntimeException("Email is not specified in the configuration.properties file");
    }

    public String getTestEmailId() {
        String email_id = properties.getProperty("TEST_EMAILID");
        if (email_id != null) return email_id;
        else throw new RuntimeException("Email is not specified in the configuration.properties file");
    }

    /**
     * Function to get User.json form configuration.properties file
     */

    public String getUserDataPath() {
        String filePath = System.getProperty("user.dir") + properties.getProperty("DATA_JSON") + envName + "/user.json";
//        String filePath =  "user.json";
        if (filePath != null) return filePath;
        else throw new RuntimeException("File Path is not specified in the configuration.properties file");
    }


    /**
     * Function to get Document_Fields.json form configuration.properties file
     */

    public String getDocFieldPath() {
        String filePath = System.getProperty("user.dir") + properties.getProperty("DATA_JSON") + envName + "/document_fields.json";
        if (filePath != null) return filePath;
        else throw new RuntimeException("File Path is not specified in the configuration.properties file");
    }

    /**
     * Function to get Supplier_Document.json form configuration.properties file
     */

    public String getSDDataPath() {
        String filePath = System.getProperty("user.dir") + properties.getProperty("DATA_JSON") + envName + "/supplier_document.json";
        if (filePath != null) return filePath;
        else throw new RuntimeException("File Path is not specified in the configuration.properties file");
    }

    /**
     * Function to get Document.json form configuration.properties file
     */

    public String getDocumentDataPath() {

        String filePath = System.getProperty("user.dir") + properties.getProperty("DATA_JSON") + envName + "/document.json";
        if (filePath != null) return filePath;
        else throw new RuntimeException("File Path is not specified in the configuration.properties file");
    }

    /**
     * Function to get projectfileds.json form configuration.properties file
     */

    public String getProjectFieldsDataPath() {

        String filePath = System.getProperty("user.dir") + properties.getProperty("DATA_JSON") + envName + "/project_fields.json";
        if (filePath != null) return filePath;
        else throw new RuntimeException("File Path is not specified in the configuration.properties file");
    }

    /**
     * Function to get documentNumbering.json form configuration.properties file
     */

    public String getDocNumberingDataPath() {

        String filePath = System.getProperty("user.dir") + properties.getProperty("DATA_JSON") + envName + "/documentNumbering.json";
        if (filePath != null) return filePath;
        else throw new RuntimeException("File Path is not specified in the configuration.properties file");
    }

    /**
     * Function to get ProjParticipants.json form configuration.properties file
     */

    public String getProjParticipantsDataPath() {

        String filePath = System.getProperty("user.dir") + properties.getProperty("DATA_JSON") + envName + "/project_participants.json";
        if (filePath != null) return filePath;
        else throw new RuntimeException("File Path is not specified in the configuration.properties file");
    }

    /**
     * Function to get Mail.json form configuration.properties file
     */

    public String getMailDataPath() {
        String filePath = System.getProperty("user.dir") + properties.getProperty("DATA_JSON") + envName + "/mail.json";
//        String filePath = "mail.json";
        if (filePath != null) return filePath;
        else throw new RuntimeException("File Path is not specified in the configuration.properties file");
    }

    /**
     * Function to get workflow.json form configuration.properties file
     */

    public String getWorkflowDataPath() {
        String filePath = System.getProperty("user.dir") + properties.getProperty("DATA_JSON") + envName + "/workflow.json";
        if (filePath != null) return filePath;
        else throw new RuntimeException("File Path is not specified in the configuration.properties file");
    }

    /**
     * Function to get Tender.json form configuration.properties file
     */
    public String getTenderDataPath() {
        String filePath = System.getProperty("user.dir") + properties.getProperty("DATA_JSON") + envName + "/tender.json";
        if (filePath != null) return filePath;
        else throw new RuntimeException("File Path is not specified in the configuration.properties file");
    }


    public String getPackageDataPath() {
        String filePath = System.getProperty("user.dir") + properties.getProperty("DATA_JSON") + envName + "/package.json";
        if (filePath != null) return filePath;
        else throw new RuntimeException("File Path is not specified in the configuration.properties file");
    }

    public String getPackageTypeDataPath() {
        String filePath = System.getProperty("user.dir") + properties.getProperty("DATA_JSON") + envName + "/package_type.json";
        if (filePath != null) return filePath;
        else throw new RuntimeException("File Path is not specified in the configuration.properties file");
    }

    public String getPackageTemplateDataPath() {
        String filePath = System.getProperty("user.dir") + properties.getProperty("DATA_JSON") + envName + "/package_template.json";
        if (filePath != null) return filePath;
        else throw new RuntimeException("File Path is not specified in the configuration.properties file");
    }

    public String getPackageReviewDataPath() {
        String filePath = System.getProperty("user.dir") + properties.getProperty("DATA_JSON") + envName + "/package_review.json";
        if (filePath != null) return filePath;
        else throw new RuntimeException("File Path is not specified in the configuration.properties file");
    }

    public String getSSOAuthString() {
        String sso_auth_string = properties.getProperty("SSO_Auth_String");
        if (sso_auth_string != null) return sso_auth_string;
        else throw new RuntimeException("SSO Auth String not specified in the configuration.properties file");

    }

    public Boolean getUseJsonFileFlag() {
        String use_json_file = properties.getProperty("USE_JSON_FILE");
        if (use_json_file.equals("true")) return true;
        else return false;
    }

    public String getJiraExecutionUrl() {
        String jira_exec_url = properties.getProperty("ZEPHYR_EXECUTION_URL");
        if (jira_exec_url != null) return jira_exec_url;
        else return null;
    }

    public String getJiraIssueUrl() {
        String jira_issue_url = properties.getProperty("JIRA_ISSUE_URL");
        if (jira_issue_url != null) return jira_issue_url;
        else return null;
    }

    public boolean getUpdateJiraFlag() {
        String update_jira_flag = properties.getProperty("UPDATE_JIRA_FLAG");
        if (update_jira_flag.equals("true")) return true;
        else return false;
    }

    public String getCountryName() {
        String country_name = properties.getProperty("COUNTRY_NAME");
        if (country_name != null) return country_name;
        else return null;
    }

    /**
     * Method to return the path of all the test files placed in main/resources package
     *
     * @return
     */
    public String getTestDataPath() {
        String testDataPath = properties.getProperty("TEST_DATA");
        if (testDataPath != null) return testDataPath;
        else return null;
    }

    /**
     * Method to return the template files path placed in main/resources package
     *
     * @return
     */
    public String getTemplateDataPath() {
        String testDataPath = properties.getProperty("TEMPLATE_DATA");
        if (testDataPath != null) return testDataPath;
        else return null;
    }

    /**
     * Function to get text_contents.json form configuration.properties file
     *
     * @return
     */
    public String getTextContentDataPath() {
        String filePath = System.getProperty("user.dir") + properties.getProperty("DATA_JSON") + "contents/text_contents.json";
        if (filePath != null) return filePath;
        else throw new RuntimeException("File Path is not specified in the configuration.properties file");
    }

    /**
     * Method to return the environment variable of the server
     *
     * @return
     */
    public static String returnEnvVar() {
        String envName = "";
        Pattern pattern = Pattern.compile("\\/\\/(.*?)\\.");
        Matcher matcher = pattern.matcher(getApplicationUrl());
        if (matcher.find()) {
            envName = matcher.group(1);
        }
        return envName;
//        if (getApplicationUrl().contains("qa122")) return "qa122";
//        else if (getApplicationUrl().contains("qa123")) return "qa123";
//        else if (getApplicationUrl().contains("ops1")) return "ops1";
//        else if (getApplicationUrl().contains("rqs3")) return "rqs3";
//        else if (getApplicationUrl().contains("mumbaiqa4")) return "mumbaiqa4";
//        else if (getApplicationUrl().contains("qa108")) return "qa108";
//        else if (getApplicationUrl().contains("mumbaiqa17")) return "mumbaiqa17";
//        return "qa122";
    }

   /* *//**
     * Method to return the environment variable of the server
     *
     * @return
     *//*
    public String returnEnvVar() {
        if (getApplicationUrl().contains("qa122")) {
            return "qa122";
        } else if (getApplicationUrl().contains("qa123")) {
            return "qa123";
        } else if (getApplicationUrl().contains("ops1")) {
            return "ops1";
        } else if (getApplicationUrl().contains("rqs3")) {
            return "rqs3";
        } else if (getApplicationUrl().contains("mumbaiqa4")) {
            return "mumbaiqa4";
        }
        else if (getApplicationUrl().contains("us1preprod")) {
            return "us1preprod";
        }
        else if (getApplicationUrl().contains("cn1")) {
            return "cn1";
        }else if (getApplicationUrl().contains("eu1")) {
            return "eu1";
        }else if (getApplicationUrl().contains("ksa1")) {
            return "ksa1";
        }else if (getApplicationUrl().contains("hk1")) {
            return "hk1";
        }else if (getApplicationUrl().contains("ca1")) {
            return "ca1";
        }else if (getApplicationUrl().contains("uk1")) {
            return "uk1";
        }else if (getApplicationUrl().contains("au1")) {
            return "au1";
        }else if (getApplicationUrl().contains("mea")) {
            return "mea";
        }else if (getApplicationUrl().contains("us1")) {
            if (getApplicationUrl().contains("us1preprod")) {
                return "us1preprod";
            }else
                return "us1";
        }
        return "qa122";
    }*/

    /**
     * Method to control the version of the test execution that needs to
     * be updated in JIRA
     *
     * @return
     */
    public String getTestVersionNumber() {
        String testVersionNumber = properties.getProperty("TEST_VERSION_NUMBER");
        if (testVersionNumber != null) return testVersionNumber;
        else return null;
    }

    /**
     * Method to control the cycle name of the test execution that needs to
     * be updated in JIRA
     *
     * @return
     */
    public String getTestCycleName() {
        String testCycleName = properties.getProperty("TEST_CYCLE_NAME");
        if (testCycleName != null) return testCycleName;
        else return null;
    }

    /**
     * Method to control enable new doc search operation
     *
     * @return
     */

    public Boolean getEnableNewDocSearchFlag() {
        String newDocSearchFlag = properties.getProperty("ENABLE_NEW_DOC_SEARCH");
        if (newDocSearchFlag.equals("true")) return true;
        else return false;
    }

    /**
     * Method to get Time zone for instance
     *
     * @return
     */
    public String getTimeZone() {
        if (System.getProperty("os.name").equalsIgnoreCase("linux"))
            return properties.getProperty("LINUX_TIME_ZONE");
        else return properties.getProperty("TIME_ZONE");
    }

    /**
     * Method to provide the hub url for the remote execution
     *
     * @return
     */
    public String getHubUrl() {
        String hubUrl = properties.getProperty("HUB_URL");
        if (hubUrl != null) return hubUrl;
        else return null;
    }

    /**
     * Get the user name of the jira account
     *
     * @return
     */
    public String getJiraUsername() {
        String username = properties.getProperty("JIRA_LOGIN_ID");
        if (username != null) return username;
        else return null;
    }

    /**
     * Return the session url
     *
     * @return
     */
    public String getJiraSessionUrl() {
        String url = properties.getProperty("JIRA_SESSION_URL");
        if (url != null) return url;
        else return null;
    }

    /**
     * Return the java version
     *
     * @return
     */
    public String getJavaVersion() {
        String javaVersion = properties.getProperty("JAVA_VERSION");
        if (javaVersion != null) return javaVersion;
        else return null;
    }

    /**
     * Return the cucumber version. Used for reporting
     *
     * @return
     */
    public String getCucumberVersion() {
        String cucumberVersion = properties.getProperty("CUCUMBER_VERSION");
        if (cucumberVersion != null) return cucumberVersion;
        else return null;
    }

    /**
     * Return the folder where the extent reports are present
     *
     * @return
     */
    public String getExtentReportFolder() {
        String filePath = properties.getProperty("EXTENTREPORT_OUTPUT");
        if (filePath != null) return filePath.trim();
        else return null;
    }

    /**
     * Return the extent reports properties file path
     *
     * @return
     */
    public String getExtentPropFilePath() {
        String filePath = properties.getProperty("EXTENTREPORT_PROPERTY");
        if (filePath != null) return filePath.trim();
        else return null;
    }

    /**
     * Function to get field_issue.json form configuration.properties file
     */
    public String getFieldIssueDataPath() {
        String filePath = System.getProperty("user.dir") + properties.getProperty("DATA_JSON") + envName + "/fieldIssue.json";
        if (filePath != null) return filePath;
        else throw new RuntimeException("File Path is not specified in the configuration.properties file");
    }

    /**
     * Function to get field_inspection.json from configuration.properties file
     */
    public String getFieldInspectionDataPath() {
        String filePath = System.getProperty("user.dir") + properties.getProperty("DATA_JSON") + envName + "/fieldInspection.json";
        if (filePath != null) return filePath;
        else throw new RuntimeException("File Path is not specified in the configuration.properties file");
    }

    /**
     * Method to return the download files path placed in main/resources package
     *
     * @return
     */
    public String getDownloadFilePath() {
        return properties.getProperty("DOWNLOAD_FILE_PATH");
    }

    /**
     * Method to return the browser download urls
     *
     * @return
     */
    public String getBrowserDownloadUrl() {
        String downloadUrl = "";
        switch (getBrowser().toLowerCase()) {
            case "chrome":
                downloadUrl = "chrome://downloads/";
                break;
            case "firefox":
                downloadUrl = "about:downloads";
                break;
            case "edge":
                downloadUrl = "edge://downloads/all";
        }
        return downloadUrl;
    }

    /**
     * Method to return the browser download urls
     *
     * @return
     */
    public String getDownloadQuery() {
        String downloadQuery = "";
        switch (getBrowser().toLowerCase()) {
            case "chrome":
                downloadQuery = "document.querySelector('downloads-manager').shadowRoot.querySelector('#downloadsList downloads-item').shadowRoot.querySelector('div#content #file-link').text";
                break;
            case "firefox":
                downloadQuery = "document.querySelector('#contentAreaDownloadsView .downloadMainArea .downloadContainer description:nth-of-type(1)').value";
                break;
        }
        return downloadQuery;
    }

    /**
     * Method to return the user for resetting the password
     *
     * @return
     */
    public List<String> getUserPasswordReset() {
        String users = properties.getProperty("RESET_PASSWORD");
        List<String> items = Arrays.asList(users.split(","));
        if (users != null)
            return items;
        else
            return null;
    }

    /**
     * Method to return the users starting from
     *
     * @return
     */
    public String getUserListStartingIndex() {
        String usersIndex = properties.getProperty("USERS_STARTING_FROM");
        if (usersIndex != null)
            return usersIndex;
        else
            return null;
    }

    /**
     * Function to get Group management path
     *
     * @return
     */
    public String getGroupManagementDataPath() {
        String filePath = System.getProperty("user.dir") + properties.getProperty("DATA_JSON") + envName + "/groupManagement.json";
        if (filePath != null) return filePath;
        else throw new RuntimeException("File Path is not specified in the configuration.properties file");
    }

    /**
     * Function to get Partner ID for SSO setup
     */
    public String getPartnerId() {
        String partnerId = properties.getProperty("SSO_PARTNER_ID");
        if (partnerId != null) return partnerId;
        else throw new RuntimeException("SSO Partner Id is not specified in the configuration.properties file");
    }

    /**
     * Function to get mandatory field color code
     */
    public String getMandatoryFieldColorCode() {
        String colorCode = properties.getProperty("MANDATORY_FIELD_CC");
        if (colorCode != null) return colorCode.trim();
        else return null;
    }

    /**
     * Function to get restricted mandatory field color code
     */
    public String getRestrictedFieldColorCode() {
        String colorCode = properties.getProperty("RESTRICTED_FIELD_CC");
        if (colorCode != null) return colorCode.trim();
        else return null;
    }

    /**
     * Function to get restricted non mandatory field color code
     */
    public String getRFNotMandatoryColorCode() {
        String colorCode = properties.getProperty("RESTRICTED_FIELD_NO_CC");
        if (colorCode != null) return colorCode.trim();
        else return null;
    }

    /**
     * Function to get Cookie of ASESSION ID
     */
    public String getAPICookie() {
        String asessionId = properties.getProperty("APICOOKIE");
        if (asessionId != null) return asessionId.trim();
        else return null;
    }

    /**
     * Function to get ACONEX_AUTHENTICATION used in Trused API
     */
    public String getAconexAuthentication() {
        String aconexAuth = properties.getProperty("ACONEX_AUTHENTICATION");
        if (aconexAuth != null) return aconexAuth.trim();
        else return null;
    }


    /**
     * Function to get request body form configuration.properties file
     */

    public String getRequestBodyDataPath() {
        String filePath = System.getProperty("user.dir") + properties.getProperty("DATA_JSON") + "/requestBody/";
        if (filePath != null) return filePath;
        else throw new RuntimeException("File Path is not specified in the configuration.properties file");
    }


    /**
     * Function to get common data path
     */
    public String getCommonDataPath() {
        return System.getProperty("user.dir") + properties.getProperty("DATA_JSON") + envName + "/";
    }


    /**
     * Function to get status of apphub feature switch
     */
    public boolean getAppHubEnable() {
        return ConfigSingleton.apphubEnable;
    }

    /**
     * Function to return the App Hub URL
     * @return
     */
    public String getAppHubURL() {
        String apphuburl = properties.getProperty("APPHUB_URL");
        if (apphuburl != null) return apphuburl;
        else throw new RuntimeException("Apphub url is not specified in the configuration.properties file");
    }

    /**
     * Function to get browser dimension
     *
     * @return
     */
    public String getBrowserDimensions() {
        String dimensions = properties.getProperty("BROWSER_DIMENSIONS");
        if (dimensions != null) return dimensions;
        else throw new RuntimeException("Browser dimensions are not specified in the configuration.properties file");
    }

    /**
     * Function to get downloaded paths for windows and linux machines
     *
     * @return
     */
    public String getDownloadedFilePath() {
        if (System.getProperty("os.name").toLowerCase().contains("windows"))
            return System.getProperty("user.dir") + File.separator + getDownloadFilePath().replace("/", "\\");
        else
            return properties.getProperty("JENKINS_DOWNLOAD_PATH");
    }

    /**
     * Function to copy downloaded files for windows and linux machines
     *
     * @return
     */
    public String copyDownloadedFiles() {
        return properties.getProperty("JENKINS_COPY_FILES");
    }

    /**
     * Function to get the content type for api calls
     *
     * @return
     */
    public String getContentType() {
        String contentType = properties.getProperty("CONTENT_TYPE");
        if (contentType != null) return contentType;
        else throw new RuntimeException("content type is not specified in the configuration.properties file");
    }


    public String getFilesFolderLocation(){
        return System.getProperty("user.dir") + properties.getProperty("DATA_JSON")  + "/files";
    }

    public String getBimModelDataPath()
    {
        String filePath = System.getProperty("user.dir") + properties.getProperty("DATA_JSON") + returnEnvVar() + "/bimModel.json";
        if (filePath != null) return filePath;
        else throw new RuntimeException("File Path is not specified in the configuration.properties file");
    }

    public String getcostDataPath()
    {
        String filePath = System.getProperty("user.dir") + properties.getProperty("DATA_JSON") + returnEnvVar() + "/cost.json";
        if (filePath != null) return filePath;
        else throw new RuntimeException("File Path is not specified in the configuration.properties file");
    }

    public String getDownloadPath()
    {
        String downloadFilepath =System.getProperty("user.dir") + "\\src\\main\\resources\\data\\downloads\\";
        return downloadFilepath;
    }

    /**
     * Function to return the AAS Enable
     * @return
     */
    public boolean getAASEnable() {
        return ConfigSingleton.aasEnable;
    }

    /**
     * Function to return the AAS URL
     * @return
     */
    public String getAASURL() {
        String aasurl = properties.getProperty("AAS_URL");
        if (aasurl != null) return aasurl;
        else throw new RuntimeException("AAS url is not specified in the configuration.properties file");
    }
}