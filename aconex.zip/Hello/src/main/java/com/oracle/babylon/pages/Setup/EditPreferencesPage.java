package com.oracle.babylon.pages.Setup;

import com.codeborne.selenide.WebDriverRunner;
import com.github.javafaker.Faker;
import com.oracle.babylon.Utils.helper.Navigator;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class EditPreferencesPage extends Navigator {

    private By editPreferencesLabel = By.xpath("//h1[text()='Edit Preferences']");
    private By addLink = By.xpath("//a[text()='Add']");
    private By saveBtn = By.id("btnSave");
    private By useDefaultsChkBox = By.xpath("//input[@value='reset']");
    private By allAttributeCheckbox = By.xpath("//table[@class='dataTable']//input[@type='checkbox']");
    private By mailAttribute1 = By.xpath("//tr[@id='mail.attributes.1.list.tr']//button['Edit']");
    private By textAreaAttribute = By.xpath("//td[@class='contentcell']//textarea");
    private By attributeAdd = By.xpath("//td[@class='contentcell']//a[text()='Add']");
    private By reasonForIssueTable = By.xpath("//table[@class='dataTable']//tbody//td");
    private By firstCell = By.xpath("//table[@class='dataTable']//td[1]");
    private By attrbuteValues = By.xpath("//table[@class='dataTable']//tr/td[1]");
    private By btnEditDocReg = By.xpath("//td[contains(text(),'Registered Documents')]/..//td/button[@title='Edit this item']");
    private By btnEditTempFiles = By.xpath("//td[contains(text(),'Temporary Files')]/..//td/button[@title='Edit this item']");
    private By btnEditWorkflows = By.xpath("//td[contains(text(),'Workflows')]/..//td/button[@title='Edit this item']");
    private By workflowCols = By.xpath("//span[@id='workflowColumnsPanel_title']/../following-sibling::div//div[@class='uiBidi-right']//select/option");
    private By docRegCols = By.xpath("//span[@id='documentColumnsPanel_title']/../following-sibling::div//div[@class='uiBidi-right']//select/option");
    private By tempFilesCols = By.xpath("//span[@id='tempRegisterColumnsPanel_title']/../following-sibling::div//div[@class='uiBidi-right']//select/option");


    PreferencesPage preferencesPage = new PreferencesPage();

    /**
     * Function to navigate and verify page
     */

    public void navigateAndVerifyPage() {
        getMenuSubmenu("Setup", "Preferences");
        verifyPageTitle("Edit Preferences");

    }

    /**
     * Function to set the value of the checkbox for Attribute to be made compulsory
     *
     * @param attribute
     */
    public void setAttributeCompulsory(String attribute) {

        verifyAndSwitchFrame();
        commonMethods.clickListToChange(editPreferencesLabel, "Project");
        int number = Integer.parseInt(attribute.substring(attribute.length() - 1));
        By attributeChkBox = By.name("PREFERENCE_mailattributes" + number + "compulsory_DISPLAY");
        By attributeCurrentValue = By.name("PREFERENCE_mailattributes" + number + "compulsory_CURRENT_VALUE");
        String value = commonMethods.returnElementAttributeValue(attributeCurrentValue, "value");
        if (value != "true") {
            $(attributeChkBox).click();
        }

    }

    /**
     * Function to click the edit button for any label
     */
    public void clickEditBtn(String labelTxt) {
        commonMethods.waitForElementExplicitly(500);
        driver = WebDriverRunner.getWebDriver();
        By by = By.xpath("//td[contains(text(),\"" + labelTxt + "\")]//..//button[@title='Edit this item']");
        commonMethods.waitForElement(driver, by);
        $(by).click();

    }

    /**
     * Function to validate if we have navigated to the right page
     *
     * @param attributeNum
     * @param projectName
     */
    public void checkLabelWhenAddingAttribute(String attributeNum, String projectName) {
        attributeNum = attributeNum.substring(0, attributeNum.length() - 1) + " " + attributeNum.substring(attributeNum.length() - 2, attributeNum.length() - 1);
        By header = By.xpath("//h1[text()='Select values for " + attributeNum + " -Project: " + projectName + "']");
        $(header).isDisplayed();
    }

    /**
     * Function to add attributes to mails
     *
     * @param attributeNumber
     * @return
     */
    public List<String> addMailAttribute(String attributeNumber, int numOfValues) {
        Faker faker = new Faker();
        List<String> valuesList = new LinkedList<String>();
        for (int valueCount = 0; valueCount < numOfValues; valueCount++) {
            String attribute = faker.address().city();
            int number = Integer.parseInt(attributeNumber.substring(attributeNumber.length() - 1));
            By attributeTxtAreaBox = By.name("PREFERENCE_mailattributes" + number + "list_new");
            commonMethods.waitForElementExplicitly(3000);
            $(attributeTxtAreaBox).sendKeys(attribute);
            $(addLink).click();
            commonMethods.waitForElement(driver, preferencesPage.closeBtn, 10);
            $(preferencesPage.closeBtn).click();
            //commonMethods.acceptAlert(driver);
            valuesList.add(attribute);
        }
        return valuesList;
    }

    /**
     * Function to remove mail attributes
     */

    public void removeMailAttribute() {
        List<WebElement> allCheckbox = driver.findElements(allAttributeCheckbox);
        for (WebElement element : allCheckbox) {
            element.click();
        }
        $(saveBtn).click();
        commonMethods.acceptAlert(driver);
    }

    /**
     * Single method to redirect to the relevant page and create a attribute of user's choice
     *
     * @param attributeNumber
     * @param projectName
     * @return
     */
    public List<String> createNewMailAttribute(String attributeNumber, String projectName, int numOfValues) {
        verifyAndSwitchFrame();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,-document.body.scrollHeight)", "");
        commonMethods.clickListToChange(editPreferencesLabel, "Project");
        String lblTxt = "Select values for " + attributeNumber;
        clickEditBtn(lblTxt);
        checkLabelWhenAddingAttribute(attributeNumber, projectName);
        return addMailAttribute(attributeNumber, numOfValues);
    }

    /**
     * method to redirect to the relevant page and remove a attribute of user's choice
     *
     * @param attributeNumber
     * @param projectName
     */

    public void removeNewMailAttribute(String attributeNumber, String projectName) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(3000);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,-document.body.scrollHeight)", "");
        commonMethods.clickListToChange(editPreferencesLabel, "Project");
        verifyAndSwitchFrame();
        String lblTxt = "Select values for " + attributeNumber;
        clickEditBtn(lblTxt);
        checkLabelWhenAddingAttribute(attributeNumber, projectName);
        removeMailAttribute();
    }

    public void refresh() {
        driver.navigate().refresh();
    }

    /**
     * Method to add Doc Attributes for Types and status
     *
     * @param field
     * @param attribute
     * @param tab
     */
    public void addAttributes(String field, String attribute, String tab) {
        gotoEditScreen(field, tab);
        checkUseDefaults();
        commonMethods.waitForElementExplicitly(2000);
        String xpath = "//td" + "[text()='" + attribute + "']//..";
        if (tab.equalsIgnoreCase("default")) {
            xpath = "//td//a" + "[text()='" + attribute + "']//..//..";
        }
        if (!$(By.xpath(xpath + "//td//input[@value='i' and @checked]")).isDisplayed()) {
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, -document.body.scrollHeight)");
            $(By.xpath(xpath + "//td//input[@value='i']")).click();
        }
//        $(saveBtn).click();
//        commonMethods.acceptAlert(driver);
        preferencesPage.saveAndClose();
        preferencesPage.clickBackButton();
    }

    /**
     * Method to check and navigate to edit screen
     */
    public void gotoEditScreen(String field, String tab) {
        verifyAndSwitchFrame();
        By by = By.xpath("//li[contains(text(),'" + tab + "')]");
        commonMethods.scrollToTop(driver);
        commonMethods.waitForElement(driver, by);
        if ($(by).isDisplayed()) {
            commonMethods.clickListToChange(editPreferencesLabel, tab);
            String lblTxt = "Select " + field;
            clickEditBtn(lblTxt);
        }
    }

    /**
     * Method to add Doc Attributes for Types and status
     *
     * @param field
     * @param attributes
     * @param tab
     */
    public void addAttributes(String field, List<String> attributes, String tab) {
        verifyAndSwitchFrame();
        commonMethods.clickListToChange(editPreferencesLabel, tab);
        clickEditBtn("Select " + field);
        checkUseDefaults();
        commonMethods.waitForElementExplicitly(2000);
        for (String attribute : attributes) {
            if (!$(By.xpath("//td[text()='" + attribute + "']//..//td//input[@value='i' and @checked]")).isDisplayed()) {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, -document.body.scrollHeight)");
                $(By.xpath("//td[text()='" + attribute + "']//..//td//input[@value='i']")).click();
            }
        }
        $(saveBtn).click();
        commonMethods.acceptAlert(driver);
    }

    /**
     * Method to uncheck use defaults
     */
    public void checkUseDefaults() {
        verifyAndSwitchFrame();
        if ($(useDefaultsChkBox).isDisplayed() && $(useDefaultsChkBox).isSelected()) {
            $(useDefaultsChkBox).click();
        }
    }

/**
     * Method to return the reason for issue values from the UI
     * @param labelText
     * @return
     */    public ArrayList<String> getReasonForIssueValues(String labelText) {
        clickEditBtn(labelText);
        ArrayList<String> reasonForIssueValues = new ArrayList<>();
        commonMethods.waitForElement(driver, reasonForIssueTable);
        for (int iterator = 1; iterator < $$(reasonForIssueTable).size(); iterator++) {
            String currentReason = $(By.xpath("(//table[@class='dataTable']//tbody//td)[" + iterator + "]")).getText();
            if (currentReason.length() > 1)
                reasonForIssueValues.add(currentReason);
        }
        return reasonForIssueValues;
    }

    /**
     * Method to edit the attribute values and add them
     * @param attributeIndex
     * @param attributeValue
     */
    public void editAttributeValues(String attributeIndex, String attributeValue) {
        commonMethods.waitForElement(driver, mailAttribute1);
        $(By.xpath("//tr[@id='mail.attributes." + attributeIndex + ".list.tr']//button['Edit']")).click();
        $(textAreaAttribute).sendKeys(attributeValue);
        $(attributeAdd).click();
        closeAlertMsg();
        clickBackButton();
    }

    /**
     * Method to remove the attribute values
     * @param attributeIndex
     * @param attributeValue
     */
    public void removeAttributeValues(String attributeIndex, String attributeValue) {
        commonMethods.waitForElement(driver, mailAttribute1);
        $(By.xpath("//tr[@id='mail.attributes." + attributeIndex + ".list.tr']//button['Edit']")).click();
        commonMethods.waitForElement(driver, attributeAdd);
        $(By.xpath("//input[@type='checkbox' and @value='" + attributeValue + "']")).click();
        clickSaveButton();
        closeAlertMsg();
        clickBackButton();
    }

    /**
     * Method to exclude Doc Attributes for Types and status
     *
     * @param field
     * @param attribute
     * @param tab
     */
    public void excludeAttributes(String field, String attribute, String tab) {
        gotoEditScreen(field, tab);
        checkUseDefaults();
        commonMethods.waitForElementExplicitly(2000);
        if ($(By.xpath("//td[text()='" + attribute + "']")).isDisplayed()) {
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, -document.body.scrollHeight)");
            $(By.xpath("//td[text()='" + attribute + "']//..//td//input[@value='e']")).click();
        }
        $(saveBtn).click();
        commonMethods.acceptAlert(driver);
    }

    /**
     * Method to return the values added for a attribute
     *
     * @param attribute
     * @return
     */
    public String returnAttribute(String attribute) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,-document.body.scrollHeight)", "");
        commonMethods.clickListToChange(editPreferencesLabel, "Project");
        String lblTxt = "Select values for " + attribute;
        clickEditBtn(lblTxt);
        return $(firstCell).getText();
    }

    /**
     * Method to switch tabs in preferences page
     */
    public void switchTab(String option) {
        commonMethods.clickListToChange(editPreferencesLabel, option);
    }

    /**
     * Method to get all attribute values
     */
    public List<String> getAttributes(String attribute) {
        List<String> values = new ArrayList<>();
        if (attribute.startsWith("Attribute")) attribute = "Select values for " + attribute;
        clickEditBtn(attribute);
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, By.xpath("//h1[contains(text(),\"" + attribute + "\")]"));
        List<WebElement> elements = new ArrayList<>($$(attrbuteValues));
        for (int i =0; i<elements.size(); i++)
            values.add(elements.get(i).getText());
        $(backBtn).click();
        return values;
    }

    /**
     * Method to get preference setting value
     */
    public String getPreferenceValue(String preference, String type) {
        if (type.equalsIgnoreCase("dropdown"))
            return $(By.xpath("//td[contains(text(),\"" + preference + "\")]/../td[2]//select")).getSelectedText();
        else if (type.equalsIgnoreCase("checkbox")) {
            String value = $(By.xpath("//td[contains(text(),\"" + preference + "\")]/../td[2]/input[2]")).getValue();
            if (value.equalsIgnoreCase("true")) return "On";
            else return "Off";
        } else return "";
    }

    /**
     * Method to get default cols of doc register
     */
    public List<String> getDocRegDefaultCols() {
        commonMethods.scrollPageUp(driver);
        commonMethods.waitForElement(driver, btnEditDocReg, 30);
        $(btnEditDocReg).click();
        return commonMethods.getValues(docRegCols);
    }

    /**
     * Method to get default cols of temporary files
     */
    public List<String> getTempFilesDefaultCols() {
        commonMethods.waitForElement(driver, btnEditTempFiles, 30);
        $(btnEditTempFiles).click();
        return commonMethods.getValues(tempFilesCols);
    }

    /**
     * Method to get default cols of workflows
     */
    public List<String> getWFDefaultCols() {
        commonMethods.waitForElement(driver, btnEditWorkflows, 30);
        $(btnEditWorkflows).click();
        return commonMethods.getValues(workflowCols);
    }
}
