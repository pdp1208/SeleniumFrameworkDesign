package com.oracle.babylon.pages.Document;

import com.codeborne.selenide.WebDriverRunner;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

/**
 * Class that contains functions to upload files
 */
public class MultiFileUploadPage extends DocumentPage {

    //Initialization of Web Elements
    private By zipFileUpload = By.xpath("//div[contains(text(),'Zip File Upload')]");
    private By createFileUpload = By.xpath("//*[contains(text(),'Create Upload Profile')]");
    private By inputProfileName = By.xpath("//input[@name='ImportName']");
    private By profileDescription = By.xpath("//input[@name='ImportDescription']");
    private By saveBtn = By.xpath("//div[contains(text(),'Save')]");
    private By backBtn = By.xpath("//button[@id='btnBack']");
    private By documentAttachPanel = By.xpath("//input[@name='qqfile']");
    private By selectUploadProfile = By.xpath("//select[@name='documentImportDefaultsId']");
    private By editProfile = By.xpath("//span[@title='Edit Profile']");
    private By closeBtn = By.xpath("//button[text()='Close']");
    private By files = By.xpath("//div[@class='files']//li//div[@class='fileInfo ng-scope']");
    private By confidentialChkBox = By.xpath("//span[contains(text(),'Limit access to selected individuals')]//..//input[@type='checkbox']");
    private By lnkViewEditProfile = By.xpath("//a[contains(text(),'View / Edit Profile')]");
    private By hdrUpload = By.xpath("//span[text()='Upload']");
    private By hdrMultipleFileUpload = By.xpath("//h1[contains(text(),'Multiple File Upload')]");
    private By btnCancel = By.xpath("//div[@id='uploadPanel']//div[@title='Close this window']");

    //Zipfile upload
    private By chooseZipFileUploadBtn = By.xpath("//input[@type='file']");
    //rename the button to btn
    private By uploadBtn = By.xpath("//button[@id='btnUpload']");
    //MultiFile Upload
    private By startUploadBtn = By.xpath("//button[@id='startUpload']");
    private By multiFileUploadBtn = By.xpath("//button[@title='Multi File Upload']");
    private By uploaderHelperMsg=By.id("uploaderHelperMsg");
    private By fileUploadInput = By.xpath("//div[@id='uploaderHelperMsg']//input[@name='qqfile']");
    private By btnAddFiles = By.xpath("(//input[@title='file input'])[1]");
    private By lnkClearAll = By.xpath("//div[text()='Clear All']");
    private By zipFileUploadInput = By.xpath("//input[@name='FileName']");
    private By uploadSuccessMessage = By.xpath("//div[@class='auiMessage success']");
    private By filesUploadedSuccessfully=By.xpath("//*[text()='Files Uploaded Successfully']");
    private By pageTitle = By.xpath("//div[text()='Select an Option Below to Proceed']");
    private By multiFileUploadTitle = By.xpath("//h1[text()='Multiple File Upload']");
    private By btnStartUpload = By.xpath("//button[text()='Start Upload']");
    private By lblFileUploadSuccess = By.xpath("//span[contains(text(),'Files Uploaded Successfully')]");
    private By lnkViewTempFiles = By.xpath("//a[contains(text(),'View in Temporary Files')]");
    private By lnkUploadMoreFiles = By.xpath("//a[contains(text(),'Upload more files')]");
    private By hdrTemporaryFiles = By.xpath("//span[@id='mainHeading']");
    private By lblZipSuccess = By.xpath("//div[contains(text(),'Your files are now available in your temporary files and are available to be uploaded or superseded in your register.')]");
    private By sltProfile = By.xpath("//select[@name='documentImportDefaultsId']");
    private By btnTellUs = By.xpath("//button[contains(text(),'Tell us what you think')]");
    private By AddMoreInput = By.xpath("//div[@id='filesContainer']//input[@name='qqfile']");
    private By selectUploadProfileDropDown = By.xpath("//button[@class='dropdown-trigger auiIcon expanded']");
    private By selectProfile = By.xpath("(//label[@class='auiText-normal ng-binding' and contains(text(),'uploadProfile1')])[1]");
    private By attribute1 = By.xpath("//tr//td//following::div[@title='Attribute 1 List']/div");
    private By attributeValue = By.xpath("//div[@class='uiBidi-left']//select[@multiple='multiple']//option");
    private By addItemsLeft = By.xpath("//button[@title='Add item to list']");
    //private By btnOk = By.xpath("//button[@title='OK']");
    private By btnOk = By.xpath("//button[@title='OK']//div[@class='uiButton-content']");
    private By profileSuccessMessage = By.xpath("//div[text()='Saved']");
    private By docUpload = By.xpath("//div[text()='Upload']");
    private By profileUploadErrMsg = By.xpath("//span[@id='errorBox']");
    private By docMenu = By.xpath("//div[text()='Documents']");
    private By oldEditProfile = By.xpath("//a[text()='View / Edit Profile']");
    private By viewCopyPanelErrMsg = By.xpath("//li[@class='message warning']//div[contains(text(),\"violate the access control rule\")]");
    private By successMsg = By.xpath("//div[text()='The following documents have been moved to your register.']");
    private By uploaderHelpMsg = By.xpath("//div[@id='uploaderHelperMsg']");
    AddDocumentsPage addDocumentsPage = new AddDocumentsPage();
    TemporaryFilesPage tempFilesPage = new TemporaryFilesPage();
    private By attrValRight = By.xpath("//div[@class='uiBidi-right']//select[@multiple='multiple']//option");
    private By mileStoneDate = By.xpath("//input[@title='Milestone Date']");
    private By status = By.xpath("//select[@title='Current status of this document']");
    private By uploadedByMe = By.xpath("//a[text()='View files uploaded by me today']");

    public MultiFileUploadPage() {
        this.driver = WebDriverRunner.getWebDriver();
    }

    /**
     * Method to navigate to Document and verify for the title of the page
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Documents", "Add/Update Documents");
        commonMethods.waitForElementExplicitly(3000);
        Assert.assertTrue(verifyPageTitle(pageTitle));
    }

    /**
     * Method to navigate to Document and verify for the title of the page
     */
    public void navigateAndVerifyPage(String instance) {
        getMenuSubmenu(instance, "Multiple File Upload");
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, multiFileUploadTitle);
        Assert.assertTrue(verifyPageTitle(multiFileUploadTitle));
    }

    /**
     * Function create upload profile
     */
    public void createUploadProfile(String profileName) {
        commonMethods.waitForElement(driver, createFileUpload, 60);
        $(createFileUpload).scrollTo();
        $(createFileUpload).click();
        $(inputProfileName).sendKeys(profileName);
        $(profileDescription).sendKeys(profileName);
        $(saveBtn).click();
        $(backBtn).click();
    }

    /**
     * Function click on Create Upload Profile button
     */
    public void clickCreateProfile() {
        $(createFileUpload).click();
    }

    /**
     * Function to View and Edit Profile
     *
     * @param profileName
     */
    public void viewAndEditUploadedProfile(String profileName) {
        addDocumentsPage.chooseUploadProfile();
        By profile = By.xpath("(//label[@class='auiText-normal ng-binding' and contains(text(),'" + profileName + "')])[1]");
        commonMethods.waitForElement(driver, profile, 60);
        $(profile).click();
        $(editProfile).click();
        $(saveBtn).click();
        $(backBtn).click();
    }

    /**
     * Function to  Upload Zipfile
     *
     * @param fileName
     * @param fileLocation
     */
    public void zipFileUpload(String fileLocation, String fileName) {
        commonMethods.waitForElement(driver, zipFileUpload);
        $(zipFileUpload).click();
        commonMethods.waitForElement(driver, zipFileUploadInput, 30);
        $(zipFileUploadInput).sendKeys(new File(fileLocation + "/" + fileName).getAbsolutePath());
        $(uploadBtn).click();
        commonMethods.waitForElementExplicitly(3000);
    }

    /**
     * Method to upload all files from test data path
     *
     * @param directoryPath
     */
    public void uploadZipFiles(String directoryPath, List<String> fileNames) {
        commonMethods.waitForElement(driver, zipFileUpload);
        $(zipFileUpload).click();
        commonMethods.waitForElement(driver, zipFileUploadInput, 30);
        for (String file : fileNames) {
            $(zipFileUploadInput).sendKeys(new File(directoryPath + "/" + file).getAbsolutePath());
        }
        commonMethods.waitForElementExplicitly(5000);
        switchToOriginal();
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, files);
        List<WebElement> list = driver.findElements(files);
        for (WebElement element : list) {
            commonMethods.waitForElementExplicitly(3000);
            $(element).click();
            commonMethods.waitForElementExplicitly(3000);
            $(confidentialChkBox).setSelected(false);
        }
        clickSaveTempFiles();
        commonMethods.waitForElement(driver, closeBtn, 60);
        $(closeBtn).click();
    }

    public List<String> returnFileNames(String directoryPath) {
        List<String> results = new ArrayList<>();
        File[] files = new File(directoryPath).listFiles();
        //If this pathname does not denote a directory, then listFiles() returns null.
        for (File file : files) {
            if (file.isFile()) {
                results.add(file.getAbsolutePath());
            }
        }
        return results;

    }

    public ZonedDateTime returnOzTime() {
        Instant nowUtc = Instant.now();
        ZoneId australiaSydney = ZoneId.of("Australia/Sydney");
        ZonedDateTime nowAusSydney = ZonedDateTime.ofInstant(nowUtc, australiaSydney);
        System.out.println("Current date");
        System.out.println(nowAusSydney);
        return nowAusSydney;
    }


    public void returnRequiredDate(String requirement) {
        ZonedDateTime currentDate = returnOzTime();
        System.out.println("Changed date");
        switch (requirement) {
            case "yesterday":
                ZonedDateTime yesterday = currentDate.minusDays(1);
                System.out.println(yesterday);
                break;
            case "today":
                System.out.println(currentDate);
                break;
            case "tomorrow":
                ZonedDateTime tomorrow = currentDate.plusDays(1);
                System.out.println(tomorrow);
                break;
        }
    }

    /**
     * Function to  edit upload profile Info
     *
     * @param profileName
     * @param uploadInfo
     * @param flag
     */

    public void editUploadInfo(String profileName, String uploadInfo, String flag) {
        verifyAndSwitchFrame();
//        $(selectUploadProfile).selectOption(profileName);
        $(By.xpath("//div[@class='upload-profiles-list']//div[contains(text(),'" + profileName + "')]")).click();
        $(editProfile).click();
        By infoName = By.xpath("//td[contains(.,'" + uploadInfo + "')]//..//td//input");
        if (flag.equals("true") && (!$(infoName).isSelected())) {
            $(infoName).click();
            $(saveBtn).click();
            return;
        }
        if (flag.equals("false") && ($(infoName).isSelected())) {
            $(infoName).click();
            $(saveBtn).click();
        }
    }

    /**
     * Method to upload a single file from test data path
     *
     * @param fileName
     */
    public void uploadFile(String directoryPath, String fileName) {
        String filePath = directoryPath + fileName;
        File file = new File(filePath);
        filePath = file.getAbsolutePath();
        verifyAndSwitchFrame();
//        driver.switchTo().frame("dropZone");
        commonMethods.waitForElementExplicitly(2000);
        $(documentAttachPanel).sendKeys(filePath);
        clickSaveTempFiles();
        commonMethods.waitForElement(driver, docUploadSuccess, 60);
        commonMethods.waitForElement(driver, closeBtn, 60);
        $(closeBtn).click();
    }

    /**
     * Method to upload all the files from test data path
     *
     * @param directoryPath
     */
    public void uploadMultiFiles(String directoryPath) {
        java.util.List<String> filesToUpload = returnFileNames(directoryPath);
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver,multiFileUploadBtn);
        $(multiFileUploadBtn).click();
        commonMethods.waitForElement(driver,uploaderHelperMsg);
        for (String file : filesToUpload) {
            $(fileUploadInput).sendKeys(file);
        }
        commonMethods.waitForElementExplicitly(5000);
       /* switchToOriginal();
        verifyAndSwitchFrame();*/
        commonMethods.waitForElement(driver, startUploadBtn);
        $(startUploadBtn).click();
       commonMethods.waitForElement(driver,filesUploadedSuccessfully,120);
    }

    /**
     * Function to  Upload file in Multi File Upload screen
     *
     * @param fileName
     * @param fileLocation
     */
    public void multiFileUpload(String fileLocation, String fileName) {
        commonMethods.waitForElement(driver, multiFileUploadBtn);
        $(multiFileUploadBtn).click();
        commonMethods.waitForElement(driver, By.xpath("//div[@id='uploaderHelperMsg']"), 60);
        $(fileUploadInput).sendKeys(new File(fileLocation + "/" + fileName).getAbsolutePath());
        commonMethods.waitForElement(driver, lnkClearAll, 60);
    }

    /**
     * Function to verify upload screen
     */
    public void verifyUploadPage() {
        commonMethods.waitForElement(driver, hdrUpload, 30);
        Assert.assertTrue($(hdrUpload).isDisplayed());
        verifyAndSwitchFrame("uploadIframe");
        Assert.assertTrue($(hdrMultipleFileUpload).isDisplayed());
        Assert.assertTrue($(createFileUpload).isDisplayed());
        Assert.assertTrue($(lnkViewEditProfile).isDisplayed());
        Assert.assertTrue($(selectUploadProfile).isDisplayed());
        Assert.assertTrue($(multiFileUploadBtn).isDisplayed());
        Assert.assertTrue($(zipFileUpload).isDisplayed());
    }

    /**
     * Function to close upload window
     */
    public void clickClose() {
        commonMethods.getElementInViewAndUp(btnCancel);
        $(btnCancel).click();
    }

    /**
     * Function to click on View/Edit Profile link
     */
    public void clickViewEditProfile() {
        $(lnkViewEditProfile).click();
    }

    /**
     * Function to upload multiple files and submit uploading
     */
    public void uploadMultipleFiles(String path, String fileName) {
        multiFileUpload(path, fileName);
        $(btnStartUpload).click();
        commonMethods.waitForElement(driver, lblFileUploadSuccess, 60);
    }

    /**
     * Function to upload more files
     */
    public void uploadMoreFiles(String fileName) {
        $(loadingIcon).should(disappear);
        $(AddMoreInput).sendKeys(new File(fileName).getAbsolutePath());
        commonMethods.waitForElement(driver, lnkClearAll, 60);
        $(btnStartUpload).click();
        commonMethods.waitForElement(driver, lblFileUploadSuccess, 60);
    }

    /**
     * Function to click upload more files link
     */
    public void clickUploadMoreFiles() {
        commonMethods.waitForElement(driver, lnkUploadMoreFiles);
        $(lnkUploadMoreFiles).click();
    }

    /**
     * Function to click view in temporary files link
     */
    public void clickViewTempFiles() {
        commonMethods.waitForElement(driver, lnkViewTempFiles);
        $(lnkViewTempFiles).click();
    }

    /**
     * Function to verify upload success message
     */
    public boolean verifyUploadSuccess() {
        commonMethods.waitForElement(driver, lblFileUploadSuccess, 60);
        return $(lblFileUploadSuccess).isDisplayed();
    }

    /**
     * Function to verify temp files page
     */
    public boolean verifyTempFilesPage() {
        commonMethods.waitForElement(driver, hdrTemporaryFiles);
        return $(hdrTemporaryFiles).isDisplayed();
    }

    /**
     * Function to verify zip upload success message
     */
    public boolean verifyZipUploadSuccess() {
        commonMethods.waitForElement(driver, lblZipSuccess, 60);
        return $(lblZipSuccess).isDisplayed();
    }

    /**
     * Method to select a profile
     */
    public void selectProfile(String profileName) {
        commonMethods.enterDropdownValue(sltProfile, profileName);
    }

    /**
     * Method to verify upload profile name in Multi file upload page
     */
    public List<String> getAllUploadProfiles() {
        return commonMethods.returnAllOptionsInDropDown(driver, sltProfile);
    }


    /**
     * Function to  Upload multiple file in Multi File Upload screen
     *
     * @param fileName
     * @param fileLocation
     */
    public void multiFileUploadAttach(String fileLocation, List<String> fileName) {
        commonMethods.waitForElement(driver, multiFileUploadBtn);
        $(multiFileUploadBtn).click();
        commonMethods.waitForElement(driver, uploaderHelpMsg, 60);
        for (String file : fileName) {
            $(fileUploadInput).sendKeys(new File(fileLocation + "/" + file).getAbsolutePath());
        }
        commonMethods.waitForElementExplicitly(3000);
        $(btnStartUpload).click();
        commonMethods.waitForElement(driver, lblFileUploadSuccess, 60);
    }


    /**
     * Function to select the attribute value inside the profile page
     */

    public void addAttributeValue(String saveType) {
        $(status).scrollTo();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver,attribute1,30);
        $(attribute1).click();
        commonMethods.waitForElementExplicitly(2000);
        List<WebElement> elements = new ArrayList<>($$(attributeValue));
        if ($$(attributeValue).size() > 1) {
            for (WebElement element : elements) {
                commonMethods.waitForElement(driver, attributeValue, 30);
                $(attributeValue).click();
                commonMethods.waitForElementExplicitly(1000);
                commonMethods.waitForElement(driver,addItemsLeft,20);
                $(addItemsLeft).click();
                commonMethods.waitForElementExplicitly(1000);
                $(btnOk).click();
                break;
            }
        } else {
            commonMethods.waitForElement(driver,btnOk,30);
            $(btnOk).click();
        }
        if (saveType.equalsIgnoreCase("Save")) {
           commonMethods.waitForElement(driver,saveBtn,30);
            $(saveBtn).click();
        } else {
            commonMethods.waitForElement(driver,docUpload,30);
            $(docUpload).click();
        }
    }

    /**
     * Function to verify the success message displayed while saving the profile changes
     */
    public boolean profileSuccessMessage() {
        return $(profileSuccessMessage).isDisplayed();
    }

    /**
     * Function to close the multifile popup
     */
    public void clickCloseMultiFile() {
        $(closeBtn).click();
    }

    /**
     * Function to verify the error message displayed while saving the profile changes
     */
    public boolean verifyErrorMsgProfile() {
        return $(profileUploadErrMsg).isDisplayed();
    }


    /**
     * Function to verify the error message displayed in copy to panel page
     */
    public boolean verifyErrMsg() {
        commonMethods.scrollPageUp(driver);
        return $(viewCopyPanelErrMsg).isDisplayed();
    }

    /**
     * Function to verify the success message displayed in copy to panel page
     */
    public boolean verifySuccessMsg() {
        return $(successMsg).isDisplayed();
    }

    /**
     * Method to fill fields in view copy to panel
     */
    public void fillLegacyUpCopyFields(String fieldName, String value, String type) {
        switch (type.toLowerCase()) {
            case "dropdown":
                commonMethods.enterDropdownValue(By.xpath("//div[@id='copyToPanelContainer']//select[contains(@title, '" + fieldName + "')]"), value);
                break;
            case "text":
                commonMethods.enterTextValue(By.xpath("//div[@id='copyToPanelContainer']//input[contains(@title, '" + fieldName + "')]"), value);
                break;
            case "checkbox":
                $(By.xpath("//acx-bulk-edit-field//acx-checkbox-field//input[contains(@name, '" + fieldName + "')]")).setSelected(Boolean.parseBoolean(value));
                break;
            case "date":
                updateDateField(value, By.xpath("//div[@id='copyToPanelContainer']//input[contains(@title, '" + fieldName + "')]"));
                break;
            case "selectlist":
                fillLegacySelectListField(fieldName, value);
                break;
        }
    }

    /**
     * Method to fill fields in view copy to panel
     */
    public void clickUploadedByMeLink() {
        commonMethods.waitForElement(driver, uploadedByMe, 60);
        $(uploadedByMe).click();
    }
}