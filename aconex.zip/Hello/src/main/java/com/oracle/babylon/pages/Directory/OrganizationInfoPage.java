package com.oracle.babylon.pages.Directory;

import org.junit.Assert;
import org.openqa.selenium.By;
import static com.codeborne.selenide.Selenide.$;
public class OrganizationInfoPage extends DirectoryPage{

    /**
     * Identifiers
     */
    private By pageTitle = By.xpath("//h1[text()='Organization Information']");
    private By addGuest = By.xpath("//button[contains(@title,'Create another Guest')]//div[contains(text(),'Add Guest')]");
    private By newUser = By.xpath("//button[contains(@title,'Create a new user for organisation')]//div[contains(text(),'New User')]");

    private By tradingNameLbl = By.xpath("//td[text()='Trading Name']");
    private By tradingName = By.xpath("//td[text()='Trading Name']//..//td[2]");
    private By organizationIdLbl = By.xpath("//td[text()='Organization ID']");
    private By organizationId = By.xpath("//td[text()='Organization ID']//..//td[2]");
    private By organizationCodeLbl = By.xpath("//td[text()='Organization Code']");
    private By organizationCode = By.xpath("//td[text()='Organization Code']//..//td[2]");
    private By craLbl = By.xpath("//td[text()='Company Registration Number']");
    private By orgAdminLbl = By.xpath("//td[contains(text(),'Aconex Organization Administrator(s)')]");
    private By contactSpan = By.xpath("//span[text()='Contact if you have any Aconex User or Organization account queries']");
    private By adminTableLbl = By.xpath("//th[text()='Administrator']");
    private By cityTableLbl = By.xpath("//th[text()='City']");
    private By phoneTableLbl = By.xpath("//th[text()='Phone']");
    private By emailTableLbl = By.xpath("//th[text()='Email']");
    private By addressTableLbl = By.xpath("//td[text()='Address']");
    private By postalAddressLbl = By.xpath("//td[text()='Postal Address']");
    private By postalAddress = By.xpath("//td[text()='Postal Address']//..//td[2]");
    private By deliveryAddressLbl = By.xpath("//td[text()='Delivery Address']");
    private By deliveryAddress = By.xpath("//td[text()='Delivery Address']//..//td[2]");
    private By phoneLbl = By.xpath("//td[text()='Phone']");
    private By faxLbl = By.xpath("//td[text()='Fax']");
    private By websiteLbl = By.xpath("//td[text()='Website']");
    private By emailLbl = By.xpath("//td[text()='Email Address']");
    private By orgRoleLbl = By.xpath("//td[text()='Organization project roles']");


    /**
     * Method to validate the page title
     */
    public void verifyPageTitle(){
        commonMethods.waitForElement(driver, pageTitle);
        Assert.assertTrue($(pageTitle).isDisplayed());
    }

    /**
     * Method to validate the values in the text boxes
     */
    public void verifyContents(){
        Assert.assertTrue($(tradingName).getText()!=null);
        Assert.assertTrue($(organizationCode).getText()!=null);
        Assert.assertTrue($(organizationId).getText()!=null);
        Assert.assertTrue($(postalAddress).getText()!=null);
        Assert.assertTrue($(deliveryAddress).getText()!=null);
    }

    /**
     * Method to validate the buttons
     */
    public void verifyButtons(){
        Assert.assertTrue($(addGuest).isDisplayed());
        Assert.assertTrue($(newUser).isDisplayed());
    }


    /**
     * Method to validate the UI screen
     */
    public void verifyUI(){
        Assert.assertTrue($(organizationCodeLbl).isDisplayed());
        Assert.assertTrue($(tradingNameLbl).isDisplayed());
        Assert.assertTrue($(organizationIdLbl).isDisplayed());
        Assert.assertTrue($(craLbl).isDisplayed());
        Assert.assertTrue($(orgAdminLbl).isDisplayed());
        Assert.assertTrue($(contactSpan).isDisplayed());
        Assert.assertTrue($(adminTableLbl).isDisplayed());
        Assert.assertTrue($(cityTableLbl).isDisplayed());
        Assert.assertTrue($(phoneTableLbl).isDisplayed());
        Assert.assertTrue($(emailTableLbl).isDisplayed());
        Assert.assertTrue($(addressTableLbl).isDisplayed());
        Assert.assertTrue($(postalAddressLbl).isDisplayed());
        Assert.assertTrue($(deliveryAddressLbl).isDisplayed());
        Assert.assertTrue($(postalAddressLbl).isDisplayed());
        Assert.assertTrue($(phoneLbl).isDisplayed());
        Assert.assertTrue($(faxLbl).isDisplayed());
        Assert.assertTrue($(websiteLbl).isDisplayed());
        Assert.assertTrue($(emailLbl).isDisplayed());
        Assert.assertTrue($(orgRoleLbl).isDisplayed());

    }

}