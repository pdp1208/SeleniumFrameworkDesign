package com.oracle.babylon.pages.Document;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import java.util.List;

import static com.codeborne.selenide.Selenide.$;

public class RelatedItemsPage  extends DocumentPropertiesPage{

    private By relatedItems = By.xpath("//a[text()='Related Items']");
    private By manageRelatedItemsBtn = By.xpath("//button[@id='manageRelationshipsBtn']");
    private By documentRegisterBtn = By.xpath("//button[@id='showInDocumentRegisterBtn']");
    private By searchRelatedItems = By.xpath("//input[@ng-model='data.query']");
    private By docLinkIframe = By.xpath("//iframe[@id='doclinkframe']");
    private By tableRows = By.xpath("//div[@class='relatedDocsTable']//table//tbody//tr");
    private By docNoField = By.xpath("//div[@class='relatedDocsTable']//table//tbody//tr//td[4]");
    private By relationshipField = By.xpath("//div[@class='relatedDocsTable']//table//tbody//tr//td[2]");
    private By firstDocCheckbox = By.xpath("//div[@class='relatedDocsTable']//table//tbody//tr//td[1]//input");
    private By allRelationshipCount = By.xpath("//a[contains(text(),'All Relationship')]//span");
    private By manageRelatedItemsHeader=By.xpath("//h1[text()='Manage Related Items']");
    /**
     * Method to navigate to Related Items page
     */
    public void navigate(){
        clickRelatedItems();
    }

    /**
     * Method to click on Related Items tab
     */
    public void clickRelatedItems(){
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, relatedItems);
        $(relatedItems).click();
    }

    /**
     * Method to click on Manage Related Items button
     */
    public void manageRelatedItems(){
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, manageRelatedItemsBtn);
        $(manageRelatedItemsBtn).click();
    }


    /**
     * Method to display the selected document in the document register page
     */
    public void showInDocRegister(){
        $(documentRegisterBtn).click();
    }

    /**
     * Method to search for a document in the related items list
     * @param documentNumber
     */
    public void searchRelatedItems(String documentNumber){
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, searchRelatedItems,20);
        $(searchRelatedItems).clear();
        $(searchRelatedItems).sendKeys(documentNumber);
        $(searchRelatedItems).sendKeys(Keys.ENTER);
    }


    /**
     * Method to return the number of rows in the table
     * @return
     */
    public int returnRowsCount(){
        commonMethods.waitForElementExplicitly(2000);
        List<WebElement> rows = driver.findElements(tableRows);
        return rows.size();
    }

    /**
     * Method to return the document number from the table
     * @return
     */
    public String returnDocNo(){
       return $(docNoField).getText();
    }

    /**
     * Method to select the first document in the page
     */
    public void selectDocument(){
        $(firstDocCheckbox).click();
    }

    /**
     * Method to clear the text box
     */
    public void clearSearchTextBox(){
        $(searchRelatedItems).clear();
    }

    /**
     * Method to switch the frame where document identifiers are present
     */
    public void switchToDocFrame(){
        verifyAndSwitchFrame(docLinkIframe);
    }

    /**
     * Method to return the relationship from the table
     * @return
     */
    public String returnRelationship(){
        return $(relationshipField).getText();
    }

    /**
     * Method to click on relationship tab in the Related Items page
     * @param relationship
     */
    public void clickRelationshipTab(String relationship){
        By by = By.xpath("//a[contains(text(),'" + relationship + "')]");
        commonMethods.waitForElement(driver, by);
        $(by).click();
    }

    /**
     * Method to return the count of the documents related
     * @return
     */
    public int returnAllRelationshipCount(){
        return Integer.parseInt($(allRelationshipCount).getText());
    }

    /**
     *
     */
    public boolean verifyManageRelatedItemsHeader()
    {
        commonMethods.waitForElement(driver,manageRelatedItemsHeader,60);
        return $(manageRelatedItemsHeader).isDisplayed();
    }
}
