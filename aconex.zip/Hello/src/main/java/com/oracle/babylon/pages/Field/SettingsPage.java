package com.oracle.babylon.pages.Field;

import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.$;

public class SettingsPage extends Navigator {
    private By issueTypeLink= By.xpath("//a[text()='Issue types']");
    private By addIssueTypeTextBox=By.xpath("//label[@for='add-more-issue-types']//..//input[@type='text']");
    private By addIssueTypeBtn=By.xpath("//button[@type='submit']");

    public void navigateAndVerifyPage() {
        getMenuSubmenu("Field", "Settings");
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, toolBarSection);
        Assert.assertTrue($(toolBarSection).getText().contains("Settings"));
    }

    public void addIssueType()
    {

    }
}
