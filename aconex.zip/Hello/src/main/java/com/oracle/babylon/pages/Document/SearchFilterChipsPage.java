package com.oracle.babylon.pages.Document;

import com.codeborne.selenide.WebDriverRunner;
import com.oracle.babylon.pages.Mail.MailPage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

/**
 * Class that contains all the methods specific to the Document Register search filter chips
 */
public class SearchFilterChipsPage extends DocumentRegisterPage {

    //Initialization of Web Elements
    //Document Register search screen
    private By loadingIcon = By.cssSelector(".loading_progress");
    //All filters tab
    private By lblPinnedFilters = By.xpath("//div[contains(text(),'Pinned filters')]");
    private By lblMoreFilters = By.xpath("//label[contains(text(),'More filters')]");
    private By btnPin = By.xpath("(//*[@id='searchCriteriaContainer']//aui-collapsible-section-body/div//a[@class='auiIcon pin-icon inline'])");
    private By btnUnPin = By.xpath("(//*[@id='searchCriteriaContainer']//a[@class='auiIcon unpin-icon inline'])");
    private String unpinFilters = "//div[contains(@class, 'hbox unpinnedFilters')]//acx-document-search-field//div[@class='auiForm-field ng-scope']";
    private By btnCloseMoreFilters = By.xpath("//span[@class='auiIcon auiCollapsibleSection-headerArrow chevronDown']");
    private String btnPinFilter = "(//*[@id='searchCriteriaContainer']//a[@class='inline oj-ux-ico-unpin'])";
    private String btnUnpinFilter = "(//*[@id='searchCriteriaContainer']//a[@class='inline oj-ux-ico-pin'])";
    //Search results
    private By sltListFilterChip = By.xpath("//div[contains(@class,'active-filter-chip')]/following-sibling::div//div/input");
    private By sltListdropdown = By.xpath("//div[contains(@class,'active-filter-chip')]/following-sibling::div//div/ul/li[@class='ui-select-choices-group']");
    private By txtTextFilterChip = By.xpath("//div[contains(@class,'active-filter-chip')]/following-sibling::div//div[@class='auiForm-field ng-scope']/label//input");
    private By sltTextFilterChip = By.xpath("//div[contains(@class,'active-filter-chip')]/following-sibling::div//div[@class='auiForm-field ng-scope']//input");
    private By sltDropDownFilterChip = By.xpath("//div[contains(@class,'active-filter-chip')]/following-sibling::div//div[@class='auiForm-field ng-scope']//select");
    private By sltDateFilterChip = By.xpath("//div[contains(@class,'active-filter')]/following-sibling::div//select");
    private By btnFilterFieldClear = By.xpath("//div[contains(@class,'active-filter-chip')]/following-sibling::div//acx-search-multi-select-field//span[@class='close ui-select-match-close']");
    private By btnFilterValueClear = By.xpath("//div[contains(@class,'active-filter-chip')]/div/following-sibling::div[contains(@class,'close-btn')]");
    private By txtNoRecordsFound = By.xpath("//p[contains(text(),'No results found matching your search criteria.')]");
    private By linkSelectAll = By.xpath("//span[text()='Select All']");
    private By btnNavigate = By.xpath("//div[@role='row']//button[@class='auiMenuButton auiButton ng-binding']");
    private By btnUpdate = By.xpath("//a[@id='supersedePopupMenuItem' and text()='Update']");
    private By txtFromDate = By.xpath("(//div[@class='dateRangePicker-input ng-scope margins']/input)[1]");
    private By txtToDate = By.xpath("(//div[@class='dateRangePicker-input ng-scope margins']/input)[2]");
    private By activeFilterChip = By.xpath("//div[contains(@class,'active-filter-chip')]/following-sibling::div//div/input");
    //Update Document screen
    private By btnUpdateDocument = By.xpath("//button[contains(text(),'Update Documents')]");
    private By lblDocumentUpload = By.xpath("//div[contains(text(),'Document Upload')]");
    private By btnClose = By.xpath("//button[contains(text(),'Close')]");
    private By btnCancel = By.xpath("//button[@class='auiButton link ng-binding' and text()='Cancel']");
    private By lblShowDocHistory = By.xpath("//label[contains(text(),'Show document history')]");
    private By chkboxShowDocHis = By.xpath("//input[@id='isShowDocumentHistory']");
    private By lblDateModified = By.xpath("//div[contains(text(),'Date Modified')]");
    private By sltDateModified = By.xpath("//div[contains(text(),'Date Modified')]/following-sibling::div");
    private By lblShowUploadsOnly = By.xpath("//label[contains(text(),'Show my uploads only')]");
    private By lblShowSupCandidate = By.xpath("//label[contains(text(),'Show update candidates')]");
    private By chkboxShowUploadsOnly = By.xpath("//input[@id='isShowUploadedByMeOnly']");
    private By chkboxShowSupCandidate = By.xpath("//input[@id='isShowUploadedByMeOnly']");
    private By lblDateUploaded = By.xpath("//div[contains(text(),'Date Uploaded')]");
    private By sltDateUploaded = By.xpath("//div[contains(text(),'Date Uploaded')]/following-sibling::div");
    private By lblReviewStatus = By.xpath("//div[contains(text(),'Review Status')]");
    private By sltReviewStatus = By.xpath("//div[contains(text(),'Review Status')]/following-sibling::div//select");
    private By drpdwnDateType = By.xpath("//acx-date-type-picker//div[@class='selectize-input items not-full ng-valid ng-pristine has-options']//input");
    private By drpdwnDateRange = By.xpath("//acx-date-range-picker//div[@class='selectize-input items not-full ng-valid ng-pristine has-options']//input");

    Actions action = new Actions(driver);
    SmartFoldersTab smartFoldersTab = new SmartFoldersTab();
    DocumentPage documentPage = new DocumentPage();
    DrawingsPage drawingsPage = new DrawingsPage();
    AddDocumentsPage addDocumentsPage = new AddDocumentsPage();

    /**
     * Method to navigate to All filters tab and verify for the PINNED AND MORE FILTERS LABELS
     */
    public void navigateToAllFiltersTab() {
        if (!$(lblPinnedFilters).isDisplayed()) {
            commonMethods.waitForElementExplicitly(2000);
            Assert.assertTrue(new DocumentRegisterPage().verifyPageTitle(lblMoreFilters));
        }
    }

    /**
     * Method to verify all filter chips in All filters tab
     */
    public void verifySearchFilterChips(String filterName, String type) {
        By labelName;
        By filterField;
        expandMoreFilters();
        labelName = By.xpath("//div[text()='" + filterName + "']");
        switch (type.toLowerCase()) {
            case "select list":
                filterField = By.xpath("//div[contains(text(),'" + filterName + "')]/following-sibling::div//div[contains(@class,'ui-select-multiple ui-select-bootstrap dropdown')]");
                break;
            case "text":
                filterField = By.xpath("//div[contains(text(),'" + filterName + "')]/following-sibling::div/label[contains(@class,'auiForm-field')]");
                break;
            case "date":
                filterField = By.xpath("//div[contains(text(),'" + filterName + "')]/following-sibling::div/acx-date-range-picker");
                break;
            case "dropdown":
                filterField = By.xpath("//div[contains(text(),'" + filterName + "')]/following-sibling::div//div[contains(@class,'selectize-input items not-full ng-valid ng-pristine')]");
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + type);
        }
        Assert.assertTrue(verifyFilterDetails(labelName));
        System.out.println(labelName);
        Assert.assertTrue(verifyFilterDetails(filterField));
    }

    /**
     * Method to expand MORE FILTERS section
     */
    public void expandMoreFilters() {
        if ($(btnMoreFiltersArrow).isDisplayed()) {
            $(btnMoreFiltersArrow).click();
            commonMethods.waitForElementExplicitly(500);
        }
    }

    /**
     * Method to verify element is displayed or not
     */
    public boolean verifyFilterDetails(By by) {
        return $(by).isDisplayed();
    }

    /**
     * Method to unpin all filters from All filters tab
     */
    public void unpinAllFilters() {
        //expandMoreFilters();
        unpinAllFilterChip(pinFilters, btnPinFilter);
        Assert.assertFalse($(btnUnPin).isDisplayed());
    }

    /**
     * Method to pin all filters from All filters tab
     */
    public void pinAllFilters() {
        expandMoreFilters();
        pinAllFilterChip(unpinFilters, btnUnpinFilter);
        Assert.assertFalse($(btnPin).isDisplayed());
    }

    /**
     * Method to unpin all filters from All filters tab
     */
    public void unpinAllFilterChip(String pinUnpinElement, String element) {
        List<WebElement> filterChipsCount = new ArrayList<>($$(By.xpath(pinUnpinElement)));
        for (int i = filterChipsCount.size(); i > 0; i--) {
            By xpath = By.xpath(element + "[1]");
            By filter = By.xpath("(" + pinUnpinElement + ")[1]");
            commonMethods.mouseHoverElement(driver, $(filter));
            commonMethods.waitForElementExplicitly(200);
            $(filter).click();
            commonMethods.waitForElementExplicitly(200);
            commonMethods.mouseHoverElement(driver, $(xpath));
            $(xpath).click();
            commonMethods.waitForElementExplicitly(200);
        }
    }

    /**
     * Method to pin all filters from All filters tab
     */
    public void pinAllFilterChip(String unpinElement, String element) {
        List<WebElement> filterChipsCount = new ArrayList<>($$(By.xpath(unpinElement)));
        for (int i = filterChipsCount.size(); i > 0; i--) {
            By xpath = By.xpath(element + "[1]");
            By filter = By.xpath("(" + unpinElement + ")[1]");
            commonMethods.mouseHoverElement(driver, $(filter));
            commonMethods.waitForElementExplicitly(200);
            $(filter).click();
            commonMethods.waitForElementExplicitly(200);
            commonMethods.mouseHoverElement(driver, $(xpath));
            $(xpath).click();
            commonMethods.waitForElementExplicitly(200);
        }
    }

    /**
     * Method to pin specific filter from All filters tab
     */
    public void pinFilter(String filterName) {
        By pinFilter = By.xpath("//div[text()='" + filterName + "']/../../..//div/a[@class='inline oj-ux-ico-pin']");
        By xpath = By.xpath("//acx-document-search-field//div[text()='" + filterName + "']/../div[@class='auiForm-field ng-scope']");
        $(xpath).click();
        action.moveToElement($(pinFilter)).build().perform();
        commonMethods.mouseHoverElement(driver, $(pinFilter));
        commonMethods.waitForElementExplicitly(2000);
        $(pinFilter).click();
    }

    /**
     * Method to unpin specific filter from All filters tab
     */
    public void unpinFilter(String filterName) {
        closeMoreFilters();
        commonMethods.scrollPageUp(driver);
        List<String> filterNames = commonMethods.getValues(By.xpath(pinFilters + "/../div[1]"));
        By unpinFilter = By.xpath("//div[text()='" + filterName + "']/../../..//div/a[@class='inline oj-ux-ico-unpin']");
        By xpath = By.xpath("//acx-document-search-field//div[text()='" + filterName + "']/../div[@class='auiForm-field ng-scope']");
        action.moveByOffset(0, 0).build().perform();
        commonMethods.mouseHoverElement(driver, $(xpath));
        commonMethods.waitForElementExplicitly(200);
        $(xpath).click();
        action.moveToElement($(unpinFilter)).build().perform();
        commonMethods.mouseHoverElement(driver, $(unpinFilter));
        commonMethods.waitForElementExplicitly(200);
        $(unpinFilter).click();
    }

    /**
     * Method to verify and Pin filters if those are not pinned already
     */
    public void pinFilters(String filterName) {
        expandMoreFilters();
        By filter = By.xpath("//div[text()='" + filterName + "']/parent::div/ancestor::div[contains(@class,'filter-wrapper')]/div/a");
        action.moveByOffset(0, 0).build().perform();
        commonMethods.mouseHoverElement(driver, $(filter));
        if ($(filter).getAttribute("title").equalsIgnoreCase("Pin")) {
            pinFilter(filterName);
        }
    }

    /**
     * Method to verify and unpin filters if those are not pinned already
     */
    public void unpinFilters(String filterName) {
        expandMoreFilters();
        By filter = By.xpath("//div[text()='" + filterName + "']/parent::div/ancestor::div[contains(@class,'filter-wrapper')]/div/a");
        action.moveByOffset(0, 0).build().perform();
        commonMethods.mouseHoverElement(driver, $(filter));
        commonMethods.mouseHoverElement(driver, $(filter));
        if ($(filter).getAttribute("title").equalsIgnoreCase("Unpin")) {
            unpinFilter(filterName);
        }
    }

    /**
     * Method to select filter value from select list
     */
    public void selectValueFromFilters(String filterName, String filterValue, String type, String location) {
        switch (type.toLowerCase()) {
            case "select list":
                selectListValue(filterValue, filterName, location);
                break;
            case "text":
                $(By.xpath("//div[contains(text(),'" + filterName + "')]")).click();
                commonMethods.getElementInViewAndUp(By.xpath("//div[contains(text(),'" + filterName + "')]"));
                $(By.xpath("//div[contains(text(),'" + filterName + "')]/following-sibling::div/label[@class='auiForm-field']/input")).sendKeys(filterValue);
                break;
            case "dropdown":
                $(By.xpath("//div[contains(text(),'" + filterName + "')]//..//div[contains(@class,'selectize-input items')]")).click();
                commonMethods.waitForElementExplicitly(1000);
                $(By.xpath("//div[contains(text(),'" + filterName + "')]//..//div[contains(@class,'selectize-dropdown single')]//div[text()='" + filterValue + "']")).click();
                break;
            case "date":
                selectDateFilter(filterValue, filterName, location);
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + type);
        }
    }

    /**
     * Method to select list filter value
     */
    public void selectListValue(String filterValue, String filterName, String location) {
        String[] filterValues = filterValue.split(",");
        for (String value : filterValues) {
            if (value.trim().equalsIgnoreCase("random string"))
                value = commonMethods.getRandomString(8);
            commonMethods.waitForElementExplicitly(3000);
            $(By.xpath("//div[text()='" + filterName + "']/following-sibling::div//div/input")).click();
            By xpath = By.xpath("//div[contains(@class,'ui-select-bootstrap dropdown')]//ul/li[@class='ui-select-choices-group']/div/span/div[text()=\"" + value.trim() + "\"]");
            $(xpath).click();
            commonMethods.waitForElementExplicitly(1000);
        }
    }

    /**
     * Method to verify document results with various specific period dates
     */
    public void verifyDocsWithDates(String filterName, String filterValue, String dateType, String id) {
        clearAllFilters();
        String dateValue;
        switch (filterValue) {
            case "last":
            case "yesterday":
            case "after":
            case "between":
                if (filterName.equalsIgnoreCase("date modified"))
                    dateValue = commonMethods.getDate(configFileReader.getTimeZone(), "today");
                else dateValue = commonMethods.getDate(configFileReader.getTimeZone(), "yesterday");
                break;
            case "tomorrow":
                dateValue = commonMethods.getDate(configFileReader.getTimeZone(), "tomorrow");
                break;
            default:
                dateValue = commonMethods.getDate(configFileReader.getTimeZone(), "today");
                break;
        }
        verifyResultsForDate(filterName, filterValue, dateValue, dateType, id);
    }

    /**
     * Method to verify document results for date filters
     */
    public void verifyResultsForDate(String filterName, String filterValue, String date, String dateType, String id) {
        clickAndSelectDate(filterName, filterValue);
        verifyDateDocResults(filterName, date, dateType, id);
    }

    /**
     * Method to verify no document results for date filters
     */
    public void verifyNoDocForDate(String filterName, String filterValue) {
        clickAndSelectDate(filterName, filterValue);
        verifyNoRecordsFound();
    }

    /**
     * Method to select date from date filters and click on search
     */
    public void clickAndSelectDate(String filterName, String filterValue) {
        clearAllFilters();
        commonMethods.waitForElementExplicitly(1000);
        $(drpdwnDateType).sendKeys(filterName + Keys.ENTER);
        commonMethods.waitForElementExplicitly(1000);
        $(drpdwnDateRange).sendKeys(filterValue + Keys.ENTER);
        clickSearchBtn();
    }

    /**
     * Method to select date period or date range
     */
    public void selectDateFilter(String value, String filterName, String location) {
        commonMethods.waitForElementExplicitly(1000);
        $(drpdwnDateType).sendKeys(filterName + Keys.ENTER);
        commonMethods.waitForElementExplicitly(1000);
        $(drpdwnDateRange).sendKeys(value + Keys.ENTER);
        if (value.equalsIgnoreCase("between") || value.equalsIgnoreCase("after")) {
            commonMethods.waitForElement(WebDriverRunner.getWebDriver(), txtFromDate, 5);
            enterFromDate(commonMethods.getDate(configFileReader.getTimeZone(), "yesterday"));
            if (value.equalsIgnoreCase("between"))
                enterToDate(commonMethods.getDate(configFileReader.getTimeZone(), "tomorrow"));
        } else if (value.equalsIgnoreCase("on") || value.equalsIgnoreCase("before")) {
            commonMethods.waitForElement(WebDriverRunner.getWebDriver(), txtFromDate, 5);
            enterFromDate(commonMethods.getDate(configFileReader.getTimeZone(), "today"));
        }
    }

    /**
     * Method to click on filter in search screen
     */
    public void clickOnFilterName(String filterName) {
        commonMethods.scrollPageUp(driver);
        commonMethods.waitForElementExplicitly(1000);
        $(By.xpath("//div[contains(@class,'auiForm-section')]/div[text()='" + filterName + "']")).click();
    }

    /**
     * Method to verify search results
     */
    public void verifyDocSearchResults(String filterName, String filterValue, String id) {
        addColumns(filterName);
        commonMethods.waitForElementExplicitly(2000);
        resultTable();
        if (!getColHdrName(4).equalsIgnoreCase(filterName)) {
            addColumns(filterName);
            commonMethods.waitForElementExplicitly(2000);
        }
        assertColValues(filterValue, id);
    }

    /**
     * Method to verify default search results
     */
    public void verifyDocDefaultResults(String filterName, String filterValue, String id) {
        addColumns(filterName);
        assertDefaultColValues(filterValue, id);
    }

    /**
     * Method to assert date column in document results
     */
    public void verifyDateDocResults(String filterName, String expValue, String type, String id) {
        resultTable();
        addColumns(filterName);
        resultTable();
        assertDateColValues(expValue, id, type);
    }

    /**
     * Method to verify no results found
     */
    public void verifyNoRecordsFound() {
        commonMethods.waitForElement(WebDriverRunner.getWebDriver(), txtNoRecordsFound, 30);
        Assert.assertTrue($(txtNoRecordsFound).isDisplayed());
    }

    /**
     * Method to assert col values
     */
    public void assertColValues(String values, String id) {
        List<String> colValue = Arrays.asList(values.split(","));
        List<String> colValues = setColValue(colValue);
        colValues = colValues.stream().map(String::trim).collect(Collectors.toList());
        List<String> filterColValues = getColData(id);
        Assert.assertTrue(filterColValues.containsAll(colValues));
    }

    /**
     * Method to assert default col values
     */
    public void assertDefaultColValues(String value, String id) {
        List<String> filterColValues = getColData(id);
        commonMethods.waitForElementExplicitly(1000);
        Assert.assertTrue(filterColValues.contains(value.trim()));
    }

    /**
     * Method to check whether filter values have a Random String string
     */
    public List<String> setColValue(List<String> colValue) {
        for (int i = 0; i < colValue.size(); i++) {
            if (colValue.get(i).trim().equalsIgnoreCase("random string"))
                colValue.set(i, commonMethods.getRandomString(8));
        }
        return colValue;
    }

    /**
     * Method to assert date
     */
    public void assertDateColValues(String expValue, String id, String dateType) {
        try {
            SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
            Date expectedDate = format.parse(expValue);
            List<String> filterColValues = getColData(id);
            for (String actualValues : filterColValues) {
                Date actualDate = format.parse(actualValues);
                switch (dateType.toLowerCase()) {
                    case "yesterday":
                        Assert.assertTrue(actualDate.compareTo(expectedDate) <= 0);
                        break;
                    case "today":
                        Assert.assertEquals(0, actualDate.compareTo(expectedDate));
                        break;
                    case "tomorrow":
                        Assert.assertTrue(actualDate.compareTo(expectedDate) >= 0);
                        break;
                }
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    /**
     * Method to get col values
     */
    public List<String> getColData(String id) {
        List<String> cellValues = new ArrayList<>();
        waitForResultsDisplay(documentPage.linkSelectAll);
        resultTable();
        verifyAndSwitchFrame();
        List<WebElement> cellElements = new ArrayList<>($$(By.xpath("//div[contains(@col-id,'" + id + "')]")));
        for (int i = 1; i < cellElements.size(); i++) {
            if (!cellValues.contains(cellElements.get(i).getText().trim()))
                cellValues.add(cellElements.get(i).getText().trim());
        }
        return cellValues;
    }

    /**
     * Method to verify filter fields
     */
    public void verifyFilterFields(String filterName, String type, Map<String, String> values) {
        String value;
        switch (type.toLowerCase()) {
            case "select list":
                validateSelectListField(filterName, values.get("DataValue"), values.get("Type"));
                break;
            case "text":
                validateTextField(filterName, values.get("DataValue"), values.get("Type"));
                break;
            case "dropdown":
                if (values.get("DataValue").startsWith("user"))
                    value = commonMethods.getUserData(values.get("DataValue"), "organisation");
                else value = values.get("DataValue");
                assertValuesInSltField(value, values.get("Type"));
                clickOnFilterName(filterName);
                break;
            case "date":
                assertDateFilterField(filterName, values.get("DataValue"), values.get("Date"), values.get("Type"));
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + type);
        }
    }

    /**
     * Method to validate select list field
     */
    public void validateSelectListField(String filterName, String data, String type) {
        if (type.equalsIgnoreCase("valid")) {
            verifySelectListField(filterName, data, type);
            clearFilterValue(filterName);
        } else {
            verifySelectListField(filterName, data, type);
        }
    }

    /**
     * Method to validate text field
     */
    public void validateTextField(String filterName, String data, String type) {
        assertValuesInTextField(filterName, data);
        if (type.equalsIgnoreCase("valid")) {
            $(By.xpath("//div[text()='" + filterName + "']/following-sibling::div//input")).sendKeys(data);
        }
    }

    /**
     * Method to assert date field with valid and invalid data
     */
    public void assertDateFilterField(String filterName, String filterValue, String date, String type) {
        $(drpdwnDateType).click();
        $(By.xpath("//div[@class='selectize-dropdown-content']//div[text()='" + filterName + "']")).click();
        commonMethods.waitForElementExplicitly(1000);
        $(drpdwnDateRange).click();
        $(By.xpath("//div[@class='selectize-dropdown-content']//div[text()='" + filterValue + "']")).click();
        commonMethods.waitForElement(WebDriverRunner.getWebDriver(), txtFromDate, 5);
        if (type.equalsIgnoreCase("valid")) {
            enterFromDate(commonMethods.getDate(configFileReader.getTimeZone(), date).replace("/", "-"));
            Assert.assertEquals($(txtFromDate).getAttribute("value"), commonMethods.getDate(configFileReader.getTimeZone(), "Today"));
            $(txtFromDate).clear();
            if (filterValue.equalsIgnoreCase("Between")) {
                enterToDate(commonMethods.getDate(configFileReader.getTimeZone(), date).replace("/", "-"));
                Assert.assertEquals($(txtToDate).getAttribute("value"), commonMethods.getDate(configFileReader.getTimeZone(), "Today"));
            }
        } else {
            enterFromDate(date);
            Assert.assertEquals("rgb(214, 59, 37)", commonMethods.getBorderColor(txtFromDate));
            if (filterValue.equalsIgnoreCase("Between")) {
                enterToDate(date);
                Assert.assertEquals("rgb(214, 59, 37)", commonMethods.getBorderColor(txtToDate));
                enterFromDate(commonMethods.getDate(configFileReader.getTimeZone(), "Today"));
                enterToDate(date);
                clickSearchBtn();
                Assert.assertFalse($(linkSelectAll).isDisplayed());
                clearAllFilters();
                commonMethods.waitForElementExplicitly(1000);
                $(drpdwnDateType).click();
                $(By.xpath("//div[@class='selectize-dropdown-content']//div[text()='" + filterName + "']")).click();
                commonMethods.waitForElementExplicitly(1000);
                $(drpdwnDateRange).click();
                $(By.xpath("//div[@class='selectize-dropdown-content']//div[text()='" + filterValue + "']")).click();
                enterFromDate(date);
                enterToDate(commonMethods.getDate(configFileReader.getTimeZone(), "Today"));
            }
            clickSearchBtn();
            Assert.assertFalse($(linkSelectAll).isDisplayed());
            clearAllFilters();
        }
    }

    /**
     * Method to enter date value in from date
     */
    public void enterFromDate(String date) {
        $(txtFromDate).clear();
        commonMethods.waitForElementExplicitly(500);
        $(txtFromDate).sendKeys(date + Keys.TAB);
        commonMethods.waitForElementExplicitly(1000);
    }

    /**
     * Method to enter date value in to date
     */
    public void enterToDate(String date) {
        $(txtToDate).clear();
        $(txtToDate).click();
        commonMethods.waitForElementExplicitly(500);
        $(txtToDate).sendKeys(date + Keys.TAB);
        commonMethods.waitForElementExplicitly(1000);
    }

    /**
     * Method to enter values in select list field and validate
     */
    public void verifySelectListField(String data, String dataType) {
        String[] filterValue = data.split(",");
        for (String value : filterValue) {
            if (value.contains("user")) value = commonMethods.getUserData(value, "name");
            $(sltListFilterChip).clear();
            $(sltListFilterChip).sendKeys(value);
            commonMethods.waitForElementExplicitly(1000);
            if (dataType.equalsIgnoreCase("valid")) {
                Assert.assertTrue("Dropdown is displayed", $(sltListdropdown).isDisplayed());
                $(sltListFilterChip).sendKeys(Keys.ENTER);
                Assert.assertTrue($(By.xpath("//div[contains(@class,'active-filter-chip')]/div/following-sibling::div[contains(text(),'" + value + "')]")).isDisplayed());
            } else {
                Assert.assertFalse("Dropdown is not displayed", $(sltListdropdown).isDisplayed());
                $(sltListFilterChip).sendKeys(Keys.ENTER);
                Assert.assertTrue($(By.xpath("//div[contains(@class,'active-filter-chip')]/div/following-sibling::div[contains(text(),'Any')]")).isDisplayed());
            }
        }
    }

    /**
     * Method to enter values in select list field and validate
     */
    public void verifySelectListField(String filterName, String data, String dataType) {
        String[] filterValue = data.split(",");
        for (String value : filterValue) {
            if (value.contains("user")) value = commonMethods.getUserData(value, "name");
            By xpath = By.xpath("//div[text()='" + filterName + "']/following-sibling::div//div/input");
            $(xpath).clear();
            $(xpath).sendKeys(value);
            commonMethods.waitForElementExplicitly(1000);
            if (dataType.equalsIgnoreCase("valid")) {
                By sltListdropdown = By.xpath("//div[contains(@class,'ui-select-bootstrap dropdown')]//ul/li[@class='ui-select-choices-group']/div[@class='ui-select-choices-row ng-scope active']");
                Assert.assertTrue("Dropdown is displayed", $(sltListdropdown).isDisplayed());
                $(xpath).sendKeys(Keys.ENTER);
                Assert.assertTrue($(By.xpath("//div[text()='" + filterName + "']/following-sibling::div//span[text()='" + data + "']")).isDisplayed());
            } else {
                Assert.assertFalse("Dropdown is not displayed", $(sltListdropdown).isDisplayed());
                $(xpath).sendKeys(Keys.ENTER);
                Assert.assertFalse($(By.xpath("//div[text()='" + filterName + "']/following-sibling::div//span[text()='" + data + "']")).isDisplayed());
            }
        }
    }

    /**
     * Method to enter values in text list field and validate
     */
    public void assertValuesInTextField(String data) {
        $(txtTextFilterChip).sendKeys(data);
        Assert.assertTrue($(By.xpath("//div[contains(@class,'active-filter-chip')]/div/following-sibling::div[contains(text(),'" + data + "')]")).isDisplayed());
        $(txtTextFilterChip).clear();
        Assert.assertEquals("Field is blank", "", $(txtTextFilterChip).getText());
    }

    /**
     * Method to enter values in text list field and validate
     */
    public void assertValuesInTextField(String filterName, String data) {
        By xpath = By.xpath("//div[text()='" + filterName + "']/following-sibling::div//input");
        $(xpath).clear();
        $(xpath).sendKeys(data);
        Assert.assertEquals(data, $(By.xpath("//div[text()='" + filterName + "']/following-sibling::div//input")).getValue());
        $(xpath).clear();
    }

    /**
     * Method to enter values in text list field and validate
     */
    public void assertValuesInSltField(String data, String type) {
        By xpath = By.xpath("//div[contains(@class,'active-filter-chip')]/div/following-sibling::div[contains(text(),'" + data + "')]");
        $(By.xpath("//div[contains(@class,'active-filter-chip')]/following-sibling::div//div[contains(@class, 'option') and text()='" + data + "']")).click();
        Assert.assertTrue($(xpath).isDisplayed());
        clearAllFilters();
    }

    /**
     * Method to clear filter value by click X next to filter field value
     */
    public void clearFilterValue() {
        $(btnFilterFieldClear).click();
    }

    /**
     * Method to clear filter value by click X next to filter field value
     */
    public void clearFilterValue(String filterName) {
        $(By.xpath("//div[text()='" + filterName + "']/following-sibling::div//span[@class='close ui-select-match-close']")).click();
    }

    /**
     * Method to clear filter by click X next to filter name
     */
    public void clearFilter() {
        $(btnFilterValueClear).click();
        commonMethods.waitForElementExplicitly(1000);
    }

    /**
     * Method to change document fields in update screen
     */
    public void changeDocumentFields(String fieldName, String fieldValue, String fieldType) {
        switch (fieldType.toLowerCase()) {
            case "select list":
                addDocumentsPage.updateSelectListField("//form[@name='uploadForm']//div/acx-multi-select-field/aui-select[contains(@title,'" + fieldName + "')]", fieldValue);
                break;
            case "dropdown":
                By dropdownElement = By.xpath("//form[@name='uploadForm']//div/acx-single-select-field/select[contains(@title,'" + fieldName + "')]");
                commonMethods.waitForElement(driver, dropdownElement, 30);
                commonMethods.enterDropdownValue(dropdownElement, fieldValue);
                break;
            case "text":
                By txtElement = By.xpath("//form[@name='uploadForm']//div/acx-text-field//input[contains(@title,'" + fieldName + "')]");
                commonMethods.waitForElement(driver, txtElement, 10);
                commonMethods.enterTextValue(txtElement, fieldValue);
                break;
            case "date":
                addDocumentsPage.updateDateField(fieldValue, By.xpath("//form[@name='uploadForm']//div/acx-unified-upload-date-field/input[@title='" + fieldName + "']"));
                break;
        }
    }

    /**
     * Method to update date fields for document
     */
    public void changeDateForDocument(String filterName, String docId, String date, String type) {
        clearAllFilters();
        searchDocUsingEnter(docId);
        waitForResultsDisplay(documentPage.linkSelectAll);
        verifyAndSwitchFrame();
        switchToListView();
        waitForResultsDisplay(documentPage.linkSelectAll);
        commonMethods.waitForElementExplicitly(1000);
        selectFirstFile();
        navigateToUpdateScreen();
        if (type.equalsIgnoreCase("document field"))
            addDocumentsPage.updateDateField(date, By.xpath("//form[@name='uploadForm']//div/acx-unified-upload-date-field/input[@title='" + filterName + "']"));
        else
            addDocumentsPage.updateDateField(date, By.xpath("//label[text()='" + filterName + "']/../following-sibling::div//acx-date-field/input"));
        saveDocumentUpdates();
    }

    /**
     * Method to navigate to Update Document screen
     */
    public void navigateToUpdateScreen() {
        commonMethods.waitForElementExplicitly(2000);
        action.moveToElement($(btnNavigate)).perform();
        $(btnNavigate).click();
        commonMethods.waitForElement(WebDriverRunner.getWebDriver(), btnUpdate, 5);
        $(btnUpdate).click();
        $(loadingIcon).should(disappear);
    }

    /**
     * Method to save update documents
     */
    public void saveDocumentUpdates() {
        commonMethods.waitForElementExplicitly(6000);
        $(btnUpdateDocument).click();
        commonMethods.waitForElement(WebDriverRunner.getWebDriver(), lblDocumentUpload, 30);
        $(btnClose).click();
        commonMethods.waitForElement(WebDriverRunner.getWebDriver(), searchBtn, 60);
    }

    /**
     * Method to click on All filters link
     */
    public void clickOnAllFilters() {
        commonMethods.waitForElement(driver, lnkAllFilters, 60);
        if ($(lnkAllFilters).isDisplayed()) {
            $(lnkAllFilters).click();
        }
    }

    /**
     * Method to verify filter values
     */
    public void verifyFilterChips(String filterName, String filterValue, String operation, String location, String type) {
        switch (location.toLowerCase()) {
            case "search screen":
                if (operation.equalsIgnoreCase("Removed"))
                    Assert.assertFalse($(By.xpath("//div[contains(@class,'selected-pinned-filter-chip')]/div/span[text()='" + filterName + "']")).isDisplayed());
                else validateFilterValues(filterName, filterValue, type);
                break;
            case "filters tab":
                //clickOnAllFilters();
                validateFiltersTabFilters(filterName, filterValue, type);
                break;
        }
    }

    /**
     * Method to validate filter values
     */
    public void validateFilterValues(String filterName, String filterValue, String type) {
        String value = "";
        if (type.equalsIgnoreCase("text"))
            value = $(By.xpath("//div[contains(@class,'auiForm-section')]/div[text()='" + filterName + "']/parent::div//input")).getValue().trim();
        else if (type.equalsIgnoreCase("select list"))
            value = $(By.xpath("//div[contains(@class,'auiForm-section')]/div[text()='" + filterName + "']/parent::div//span[contains(@class,'ui-select-match-item')]//span/span")).getText().trim();
        Assert.assertEquals("Comparing filter value", filterValue, value);
    }

    /**
     * Method to filter tab filter chips
     */
    public void validateFiltersTabFilters(String filterName, String filterValue, String type) {
        String value = "";
        switch (type.toLowerCase()) {
            case "select list":
                List<String> expValue = Arrays.asList(filterValue.split(", "));
                List<String> actValue = Arrays.asList($(By.xpath("//div[text()='" + filterName + "']/following-sibling::div//div[contains(@class,'ui-select-multiple')]")).getText().replaceAll("[^a-zA-Z0-9\n\\- ]", "").split("\n"));
                Assert.assertTrue(actValue.containsAll(expValue));
                break;
            case "text":
                value = $(By.xpath("//div[text()='" + filterName + "']/following-sibling::div/label/input")).getAttribute("class");
                Assert.assertTrue(value.contains("ng-not-empty"));
                //Assert.assertEquals("Comparing Filter values", filterValue, value);
                break;
            case "date":
                value = $(By.xpath("//div[text()='" + filterName + "']/following-sibling::div[1]")).getText();
                Assert.assertEquals(filterValue.toLowerCase(), value.toLowerCase());
                if (filterValue.equalsIgnoreCase("On") || filterValue.equalsIgnoreCase("Before")) {
                    Assert.assertEquals(commonMethods.getDate(configFileReader.getTimeZone(), "today"), $(txtFromDate).getAttribute("value").trim());
                } else if (filterValue.equalsIgnoreCase("After")) {
                    Assert.assertEquals(commonMethods.getDate(configFileReader.getTimeZone(), "yesterday"), $(txtFromDate).getAttribute("value").trim());
                } else if (filterValue.equalsIgnoreCase("Between")) {
                    Assert.assertEquals(commonMethods.getDate(configFileReader.getTimeZone(), "yesterday"), $(txtFromDate).getAttribute("value").trim());
                    Assert.assertEquals(commonMethods.getDate(configFileReader.getTimeZone(), "tomorrow"), $(txtToDate).getAttribute("value").trim());
                }
                break;
            case "dropdown":
                value = $(By.xpath("//div[text()='" + filterName + "']/following-sibling::div/label/selectize")).getAttribute("class");
                Assert.assertTrue(value.contains("ng-not-empty"));
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + type);
        }
    }

    /**
     * Method to verify default filter values
     */
    public void verifyDefaultFilterValues() {
        List<WebElement> elements = new ArrayList<>($$(By.xpath("//div[contains(@class,'pinned-filter-chip')]/div/following-sibling::div[contains(@class,'filter-chip-value')]")));
        for (WebElement filter : elements) {
            if (filter.isDisplayed())
                Assert.assertEquals("Any", filter.getText());
        }
    }

    /**
     * Method to verify default filter chips
     */
    public void verifyDefaultFilterChips(String filterName) {
        Assert.assertTrue($(By.xpath("//div[contains(@class,'filter-chip-type')]/span[text()='" + filterName + "']")).isDisplayed());
    }

    /**
     * Method to verify sing default filter values
     */
    public void verifyDefaultFilterValue(String filterName) {
        By element = By.xpath("//div[contains(@class,'filter-chip-type')]/span[text()='" + filterName + "']/parent::div/following-sibling::div[1]");
        Assert.assertTrue($(element).isDisplayed());
        Assert.assertEquals("Any", $(element).getText());

    }

    /**
     * Method to check previous filter chip is closed by clicking another filter chip
     */
    public void closeFilterFields(String filter1, String filter2) {
        clickOnFilterName(filter1);
        clickOnFilterName(filter2);
        Assert.assertFalse($(By.xpath("//div[@class='filter-chip-type active-filter-chip-type']/span[text()='" + filter1 + "']/ancestor::div//span[@class='ui-select-match']/following-sibling::input")).isDisplayed());
    }

    /**
     * Method to verify doc register specific filter chips
     */
    public void verifyDocRegSpecificFields() {
        Assert.assertTrue($(lblShowDocHistory).isDisplayed());
        Assert.assertTrue($(chkboxShowDocHis).isDisplayed());
    }

    /**
     * Method to verify Temp files specific filter chips
     */
    public void verifyTempFilesSpecificFields() {
        Assert.assertTrue($(lblShowUploadsOnly).isDisplayed());
        Assert.assertTrue($(lblShowSupCandidate).isDisplayed());
        Assert.assertTrue($(chkboxShowUploadsOnly).isDisplayed());
        Assert.assertTrue($(chkboxShowSupCandidate).isDisplayed());
    }

    /**
     * Method to verify doc register specific filter chips
     */
    public void verifyDrawingsSpecificFields() {
        Assert.assertFalse($(lblShowDocHistory).isDisplayed());
        drawingsPage.openInfoMessageBox();
        drawingsPage.closeInfoMessageBox();
    }

    /**
     * Method to navigate to different tab via menu tab or smart folders
     */
    public void navigateToAnotherTab(String tabName, String location) {
        switch (location.toLowerCase()) {
            case "menu tab":
                documentPage.navigateAndVerifyPage(tabName);
                break;
            case "smart folders":
                smartFoldersTab.navigateToSmartFolderTabs(tabName);
                smartFoldersTab.closeSmartFolders();
                break;
            case "saved searches":
                smartFoldersTab.navigateToSavedSearch(tabName);
                smartFoldersTab.closeSmartFolders();
        }
    }

    /**
     * Method to verify filter values
     */
    public void verifyFilterValues(String filterName, String filterValues, String type) {
        String[] values = filterValues.split(",");
        for (String value : values) {
            switch (type.toLowerCase()) {
                case "select list":
                    By xpath = By.xpath("//div[text()='" + filterName + "']/following-sibling::div//div/input");
                    $(xpath).clear();
                    $(xpath).sendKeys(value);
                    commonMethods.waitForElementExplicitly(1000);
                    By sltListdropdown = By.xpath("//div[contains(@class,'ui-select-bootstrap dropdown')]//ul/li[@class='ui-select-choices-group']/div[@class='ui-select-choices-row ng-scope active']");
                    Assert.assertTrue("Dropdown is displayed", $(sltListdropdown).isDisplayed());
                    break;
                case "date":
                    Assert.assertTrue($(By.xpath("//div[text()='" + filterName + "']/following-sibling::div//select/optgroup/option[contains(text(),'" + value.trim() + "')]")).isDisplayed());
                    break;
            }
        }
    }

    /**
     * Method to verify filter count
     */
    public void filtersCount(int count) {
        int filterCount = Integer.parseInt($(lnkAllFilters).getText().split("\\(")[1].replace(")", "").trim());
        Assert.assertEquals(count, filterCount);
    }

    /**
     * Method to close MORE FILTERS section
     */
    public void closeMoreFilters() {
        if ($(btnCloseMoreFilters).isDisplayed()) {
            $(btnCloseMoreFilters).click();
            commonMethods.waitForElementExplicitly(1000);
        }
    }

}
