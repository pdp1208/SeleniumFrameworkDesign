package com.oracle.babylon.pages.Workflows;

import org.junit.Assert;
import org.openqa.selenium.By;

import java.util.List;

import static com.codeborne.selenide.Selenide.$;

public class SearchWorkFlowsAssignedPage extends WorkflowsPage {

    private By pageTitle = By.xpath("//h1//span[contains(text(),'Assigned to me')]");
    private By noWorkFlowsMsg=By.xpath("//div[@id='loadingMessage']");
    private By dueDateList = By.xpath("//table[@id='resultTable']//tbody//td[8]");


    /**
     * Method to navigate to the workflows page and verify the title
     */
    public void navigateAndVerifyPage() {
        commonMethods.waitForElementExplicitly(2000);
        getMenuSubmenu("Workflows", "Standard Searches", "Assigned to me");
        commonMethods.waitForElementExplicitly(2000);
        Assert.assertTrue(verifyPageTitle(pageTitle));
    }
    /**
     * Function to verify no workflows
     * @return
     */
    public boolean verifyNoWorkFlows(String msg) {
        commonMethods.waitForElementExplicitly(1000);
        getElementInView(noWorkFlowsMsg);
        commonMethods.waitForElement(driver,noWorkFlowsMsg,40);
        return $(noWorkFlowsMsg).getText().contains(msg);
    }

    /**
     * Method to sort the fields
     * @param fieldName
     */
    public void sortField(String fieldName) {
        clickSearchBtn();
        By xpath = By.xpath("//tr[@class='dataHeaders']//th//div[text()='" + fieldName +"']");
        $(xpath).click();
        commonMethods.waitForElementExplicitly(2000);
        $(closeButtonOnSort).click();
    }

    /**
     * Method to fetch the due dates from the due date column
     * @return
     */
    public List<String> fetchDueDates() {
       return commonMethods.columnValues(driver, dueDateList);
    }
}
