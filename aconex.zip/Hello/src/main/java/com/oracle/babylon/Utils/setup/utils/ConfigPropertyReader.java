package com.oracle.babylon.Utils.setup.utils;

/**
 * Abstract Class for sharing application specific properties with report microservice specific classes.
 *
 */
public class ConfigPropertyReader extends ConfigPropertyHelper {
}
