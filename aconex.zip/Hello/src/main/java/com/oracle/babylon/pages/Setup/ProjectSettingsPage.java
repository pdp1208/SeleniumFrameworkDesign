package com.oracle.babylon.pages.Setup;

import com.codeborne.selenide.Condition;
import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static com.codeborne.selenide.Selenide.*;

public class ProjectSettingsPage extends Navigator {

    protected By projectSettingsLabel = By.xpath("//h1[text()='Project Settings']");
    private By workflowStatusHeader = By.xpath("//h3[contains(text(),'Workflow Status Sets')]");
    private By projectSettingsOption = By.xpath("//div[contains(text(),'Project Settings')]");
    private By pageTitle = By.xpath("//h1[contains(text(),'Project Settings')]");
    protected By documentSettings = By.xpath("//span[contains(text(),'Documents')]");
    private By createProjectField = By.xpath("//button[contains(text(), 'New Field')]");
    private By typeList = By.xpath("//label[text()='Type']//..//..//div[2]//select");
    private By label = By.xpath("//label[text()='Label']//..//..//div[2]//input");
    private By tableRows = By.xpath("//table[@class='auiTable']//tbody//tr");
    private By assetSettingsLink = By.xpath("//div[@class='auiTabs vertical ng-scope']//div[contains(text(),'Assets Settings')]");
    private By assetsSectionLink = By.xpath("//div[@class='auiCollapsibleSection collapsed']//*[contains(text(),'Assets')]");
    private By reviewLinks = By.xpath("//div[@id='project-settings-navigation']//span[text()='Reviews']");
    private By workflowsAndSupplierDocuments = By.xpath("//div[contains(text(),'Workflows and Supplier Documents')]");
    private By getWorkFlowStatus = By.xpath("//div[@class='workflowStatusSet ng-isolate-scope']//div[@class='workflowStatusSet-label ng-binding']");
    private By projectLink = By.xpath("//a[@class='auiCollapsibleSection-header']//span[text()='Project']");
    private By reviewLink = By.xpath("//a[@class='auiCollapsibleSection-header']//span[contains(text(),'Reviews')]");
    private By reviewSubOption = By.xpath("//div[contains(text(),'Workflows and Supplier Documents')]");
    private By rightArrow = By.xpath("//span[@class='auiIcon auiCollapsibleSection-headerArrow chevronRight']");
    private By documentRoleSettings = By.xpath("//div[contains(text(),'Mail/Documents Role Settings')]");
    private By securityTab = By.xpath("//span[contains(text(),'Security')]");
    private By fileRestriction = By.xpath("//div[contains(text(),'File restrictions')]");
    private By workingWeek = By.xpath("//div[contains(text(),'Working Week')]");
    private By fileRestrictionHeader = By.xpath("//h1[@class='auiToolbar-header']");
    private By projectFields = By.xpath("//span[contains(text(),'Project Fields')]");
    private By fields = By.xpath("//div[@id='ProjectFields']");
    private By headerPrjFields = By.xpath("//h1[contains(text(),'Project Fields')]");
    private By mailLink = By.xpath("//a[@class='auiCollapsibleSection-header']//span[contains(text(),'Mail')]");
    private By documentLink = By.xpath("//a[@class='auiCollapsibleSection-header']//span[contains(text(),'Documents')]");
    private By mailTypes = By.xpath("//div[contains(text(),'Mail Types')]");
    private By mailStatus = By.xpath("//div[contains(text(),'Mail Statuses')]");
    private By respondedSelect = By.xpath("//select[@ng-model='selectedRespondedValue']");
    private By closedOutSelect = By.xpath("//select[@ng-model='selectedClosedOutValue']");
    private By mailTypeHeader = By.xpath("//h1[contains(text(),'Welcome to Mail Types')]");
    private By documentNumbering = By.xpath("//div[@class='auiCollapsibleSection-body']//div[contains(text(),'Document Numbering')]");
    private By drawingHeader = By.xpath("//h1[contains(text(),'Drawings')]");
    private By addressTab = By.xpath("//div[contains(text(),'Addresses')]");
    private By documentTypesTab = By.xpath("//div[@class='auiCollapsibleSection-body']//div[contains(text(),'Document Types')]");
    private By btnDocumentFields = By.xpath("//div[@id='DocFields']");
    private By btnSavePage = By.xpath("//button[@id='btnSave_page']//div[text()='Save']");
    private By cascadingMetadata = By.xpath("//div[contains(text(),'Cascading Metadata')]");
    private By projectName = By.xpath("//input[@name='ProjectName']");
    private By projectShortName = By.xpath("//input[@name='ProjectShortName']");
    private By projectAddress1 = By.xpath("//input[@name='ProjectAddress1']");
    private By projectSuburb = By.xpath("//input[@name='ProjectSuburb']");
    private By projectState = By.xpath("//input[@name='ProjectState']");
    private By projectCountry = By.xpath("//select[@name='ProjectCountry']");
    private By docFields = By.xpath("//div[@class='auiCollapsibleSection-body']//div[contains(text(),'Document Fields')]");
    private By docFieldsList = By.xpath("//table[@class='dataTable']//tbody//tr//td[1]");
    private By hierarchies = By.xpath("//div[contains(text(),'Hierarchies')]");
    private By reviewElements = By.xpath("//div[@class='workflowStatusSet-label ng-binding']");
    private By approved = By.xpath("//div[@class='supplierDocumentsStatusSet ng-isolate-scope']//div[@data-value='Approved']");
    private By approvedWithComments = By.xpath("//div[@class='supplierDocumentsStatusSet ng-isolate-scope']//div[@data-value='Approved with Comments']");
    private By rejected = By.xpath("//div[@class='supplierDocumentsStatusSet ng-isolate-scope']//div[@data-value='Rejected']");
    private By noComments = By.xpath("//div[@class='supplierDocumentsStatusSet ng-isolate-scope']//div[@data-value='No Comments']");
    private By completesSubmissionChk = By.xpath("//div[@class='supplierDocumentsStatusSet ng-isolate-scope']//input[@checked='checked']");
    private By replacementFileChk = By.xpath("//input[@value='MARKUP_BY_REPLACEMENT_FILE']");
    private By onlineMarkupChk = By.xpath("//input[@value='MARKUP_BY_ONLINE_VIEWER']");
    private By mailTypeList = By.xpath("//table[@class='auiTable']//tbody//tr/td[1]");
    protected By createRole = By.xpath("//button[@id='btnNewProjectRole']");
    private By txtBoxPhone = By.xpath("//input[@name='PhoneNbr']");
    private By txtBoxFax = By.xpath("//input[@name='FaxNbr']");
    private By btnExport = By.xpath("//button[contains(text(),'Export')]");
    private By allowChkBox = By.xpath("//input[@name='CanAdminUsersCopyProject']");
    private By txtExportProgress = By.xpath("//div[text()='Preparing your Project Settings Report. Your download will begin shortly.']");
    private By lnkpackageTypes = By.xpath("//div[contains(text(),'Package Types')]");
    private By packagesLink = By.xpath("//a[@class='auiCollapsibleSection-header']//span[contains(text(),'Packages')]");
    private By lnkPackageSettings = By.xpath("//div[contains(text(),'Package Settings')]");
    private By mainPageIdentifier = By.xpath("//span[contains(text(),'Packages')]");
    public static List<String> actualDocFieldList = new ArrayList<String>();
    private By packageTab = By.xpath("//span[text()='Packages']");
    private By docRegisterFields = By.xpath("//form[@name='uploadForm']//div[@class='auiForm-section auiDetails-row ng-scope']/div[1]");
    private By mailStatusSave = By.xpath("//button[@id='save']");
    private By editIcon = By.xpath("//a[contains(@class,'auiIcon edit')]");
    protected By document_apphub = By.xpath("//li[@id='nav-bar-DOC']//span[@class='nav-item']");
    private By workday = By.xpath("//label[@ng-repeat='weekDay in weekDays']//span//input");

    /**
     * Function to navigate to the project settings page under Setup
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Setup", "Project Settings");
        $(loadingIcon).should(Condition.disappear);
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, pageTitle, 80);
        Assert.assertTrue($(pageTitle).isDisplayed());

    }

    /**
     * Function to navigate to the project settings page under Setup
     */
    public void navigateToPage() {
        getMenuSubmenu("Setup", "Project Settings");
    }

    /**
     * Function to verify project settings option
     *
     * @return
     */

    public boolean verifyProjectSettings() {
        driver.switchTo().defaultContent();
        clickSetupLink();
        return $(projectSettingsOption).isDisplayed();

    }

    /**
     * Function to switch project frame
     */
//    public void switchProjectSettingsFrame() {
//        switchTo().defaultContent();
//        verifyAndSwitchFrame();
//        verifyAndSwitchFrame("project-settings-page");
//    }

    /**
     * Method to navigate to the package type page to create new packages
     */
    public void clickPackageTypes(String pageText) {
        verifyAndSwitchFrame();
        if($(mainPageIdentifier).isDisplayed()) $(mainPageIdentifier).click();
        By childPageIdentifier = By.xpath("//div[contains(text(),'" + pageText + "')]");
        $(childPageIdentifier).click();
    }

    /**
     * Method to navigate to the fields page to create new packages
     */
    public void clickFields(String pageText) {
        // driver.switchTo().defaultContent();
        verifyAndSwitchFrame();
        By pageIdentifier = By.xpath("//span[text()='" + pageText + "']");
        commonMethods.clickLinkToChange(driver, projectSettingsLabel, pageIdentifier);
        $(fields).click();


    }

    /**
     * Method to get the section label on Documents
     */
    public String getDocHeaderLabel() {
        switchToOriginal();
        if(configFileReader.getAppHubEnable())
            return $(document_apphub).getText();
        else
            return $(document).getText();
    }

    /**
     * Method to verify the Assets label
     */
    public void verifyAssetsLabel() {
        $(assetsSectionLink).shouldBe(Condition.appear);
        $(assetSettingsLink).shouldBe(Condition.appear);
    }


    public void navigateToWorkflowSupplierDocuments() {
//        commonMethods.waitForElement(driver, reviewLinks);
//        $(reviewLinks).click();
        commonMethods.waitForElement(driver, workflowsAndSupplierDocuments);
        $(workflowsAndSupplierDocuments).click();
    }

    public ArrayList<String> getWorkFlowReviewStatus() {
        ArrayList<String> statusValues = new ArrayList<>();
        for (int iterator = 1; iterator <= $$(getWorkFlowStatus).size(); iterator++)
            statusValues.add($(By.xpath("(//div[@class='workflowStatusSet ng-isolate-scope']//div[@class='workflowStatusSet-label ng-binding'])[" + iterator + "]")).getText());
        return statusValues;
    }

    /**
     * Function to verify tabs present on the page
     */

    public void verifyTabs(List<String> data) {
        for (String element : data) {
            By tab = By.xpath("//div[contains(text(),'" + element + "')]");
            commonMethods.waitForElement(driver, tab, 45);
            Assert.assertTrue($(tab).isDisplayed());
        }
    }

    /**
     * Function to verify tabs are not present on the page
     */

    public void verifyTabsAbsent(List<String> data) {
        for (String element : data) {
            By tab = By.xpath("//div[contains(text(),'" + element + "')]");
            Assert.assertFalse($(tab).isDisplayed());
        }
    }

    /**
     * Function to verify the elements present on the page
     */

    public void verifyElements(List<String> data) {
        for (String element : data) {
            By tab = By.xpath("//a[@class='auiCollapsibleSection-header']//span[contains(text(),'" + element + "')]");
            commonMethods.waitForElement(driver, tab, 45);
            Assert.assertTrue($(tab).isDisplayed());
        }
    }

    /**
     * Function to verify the elements absent on the page
     */

    public void verifyElementsAbsent(List<String> data) {
        for (String element : data) {
            By tab = By.xpath("//a[@class='auiCollapsibleSection-header']//span[contains(text(),'" + element + "')]");
            Assert.assertFalse($(tab).isDisplayed());
        }
    }

    /**
     * Function to verify the options present for Project tab
     */

    public void verifyProjectOption(List<String> data) {
        if ($(rightArrow).isDisplayed()) {
            $(rightArrow).click();
        }
        for (String element : data) {
            Assert.assertTrue($(By.xpath("//div[@class='auiCollapsibleSection-body']//div[contains(text(),'" + element + "')]")).isDisplayed());
        }
    }

    /**
     * Function to click on project Tab
     */

    public void clickProjectTab() {
        commonMethods.waitForElement(driver, projectLink, 35);
        $(projectLink).click();
    }

    /**
     * Function to verify the Review option and sub options present
     *
     * @return
     */

    public boolean verifyReview() {
        $(reviewLink).click();
        $(reviewSubOption).click();
        switchProjectSettingsFrame();
        commonMethods.waitForElement(driver, workflowStatusHeader, 35);
        return $(workflowStatusHeader).isDisplayed();
    }

    /**
     * Function to navigate to the project settings page under Setup
     */

    public void clickMailDocumentsTab() {
        $(documentRoleSettings).click();
    }


    /**
     * Function to click on Security tab and verify
     *
     * @return
     */

    public boolean verifySecurityTab() {
        switchProjectSettingsFrame();
        commonMethods.waitForElement(driver, fileRestrictionHeader, 45);
        return $(fileRestrictionHeader).isDisplayed();
    }

    /**
     * Function to click on Address tab
     */

    public void clickAddressTab() {
        $(addressTab).click();
    }

    /**
     * Function to verify the Organisation present
     */

    public void verifyOrganization(String user) {
        commonMethods.waitForElement(driver, createRole, 30);
        String org = commonMethods.getUserData(user, "organisation");
        Assert.assertTrue($(By.xpath("//div//span//a[contains(text(),'"+org+"')]")).isDisplayed());
    }

    /**
     * Function to click on Project Fields
     */
    public void clickProjectFields() {
        if (!$(fields).isDisplayed()) {
            $(projectFields).click();
        }
        $(fields).click();
    }

    /**
     * Function to verify Project Field Header
     *
     * @return
     */

    public boolean verifyPrjFieldHeader() {
        commonMethods.waitForElement(driver, headerPrjFields, 45);
        return $(headerPrjFields).isDisplayed();
    }

    /**
     * Function to click on Mail Tab
     */

    public void clickMailTab() {
        $(mailLink).click();
    }

    /**
     * Function to click on Mail Types
     */

    public void clickMailTypes() {
        $(mailTypes).click();
    }

    /**
     * Function to click on Document tab
     */

    public void clickDocumentTab() {
        $(documentLink).click();
    }

    /**
     * Function to click on Mail Type tab and verify the header on the page
     *
     * @return
     */

    public boolean verifyMailType() {
        $(mailTypes).click();
        switchProjectSettingsFrame();
        commonMethods.waitForElement(driver, mailTypeHeader, 45);
        return $(mailTypeHeader).isDisplayed();
    }

    /**
     * Function to verify the Documents tab options
     */

    public void verifyDocumentOptions(List<String> data) {
        for (String element : data) {
            By documentOptions = By.xpath("//div[@class='auiCollapsibleSection-body']//div[contains(text(),'" + element + "')]");
            commonMethods.waitForElement(driver, documentOptions, 45);
            Assert.assertTrue($(documentOptions).isDisplayed());
        }
    }

    /**
     * Function to click Document Types tab
     */

    public void clickDocumentTypesTab() {
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, documentTypesTab, 45);
        $(documentTypesTab).click();
    }

    public void verifyDeniedMessage(String msg) {
        Assert.assertTrue($(By.xpath("//h1[contains(text(),'" + msg + "')]")).isDisplayed());
    }

    /**
     * Function to navigate to Cascading metadata
     */
    public void navigateCascadingMetadata() {
        getMenuSubmenu("Setup", "Project Settings");
        verifyAndSwitchFrame();
        commonMethods.clickLinkToChange(driver, projectSettingsLabel, documentSettings);
        commonMethods.clickLinkToChange(driver, projectSettingsLabel, cascadingMetadata);
    }

    /**
     * Function to navigate to File Restrictions tab
     */
    public void navigateFileRestrictions() {
        getMenuSubmenu("Setup", "Project Settings");
        verifyAndSwitchFrame();
        commonMethods.clickLinkToChange(driver, projectSettingsLabel, securityTab);
        commonMethods.clickLinkToChange(driver, projectSettingsLabel, fileRestriction);
    }

    /**
     * Function to navigate to File Restrictions tab
     */
    public void navigateWorkingWeek() {
        getMenuSubmenu("Setup", "Project Settings");
        verifyAndSwitchFrame();
        $(projectLink).click();
        $(workingWeek).click();
    }

    /**
     * Method to get the Project Name and Address details
     */
    public String[] getProjectNameAndAddress() {
        String[] projectDetails = new String[2];
        // navigateAndVerifyPage();
        switchProjectSettingsFrame();
        projectDetails[0] = $(projectName).getAttribute("value");
        projectDetails[1] = $(projectAddress1).getAttribute("value") + "\n" + $(projectSuburb).getAttribute("value") + "\n" + $(projectState).getAttribute("value") + " " + $(projectCountry).getAttribute("value");
        return projectDetails;
    }

    /**
     * Method to verify Document Type Tab present
     */
    public void verifyDocumentTypeTabPresent() {
        Assert.assertTrue($(documentTypesTab).isDisplayed());
    }

    /**
     * Method to verify Document Type Tab not present
     */
    public void verifyDocumentTypeTabNotPresent() {
        Assert.assertFalse($(documentTypesTab).isDisplayed());
    }

    /**
     * Function to click document link in the project settings page
     */
    public void clickOnDocuments() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(3000);
        $(documentSettings).click();
    }

    /**
     * Function to click on document type option
     */
    public void clickOnDocumentType(String documentTypeName) {
        By xpath = By.xpath("//table[@class='auiTable']//tr//a[text()='" + documentTypeName + "']");
        commonMethods.waitForElementExplicitly(2000);
        switchProjectSettingsFrame();
        commonMethods.waitForElement(driver, xpath);
        $(xpath).click();
        commonMethods.waitForElementExplicitly(1000);
        verifyAndSwitchFrame();
    }

    /**
     * Function to click Document Fields
     */
    public void clickDocumentFields() {
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, docFields, 45);
        $(docFields).click();
    }

    /**
     * Function to click Document Fields
     */

    public void getDocumentFieldList() {
        commonMethods.waitForElementExplicitly(2000);
        verifyAndSwitchFrame("project-settings-page");
        for (WebElement element : $$(docFieldsList)) {
            actualDocFieldList.add(element.getText());
        }
    }

    /**
     * Function to navigate to Document types page
     */
    public void navigateToDocTypes() {
        getMenuSubmenu("Setup", "Project Settings");
        verifyAndSwitchFrame();
        commonMethods.clickLinkToChange(driver, projectSettingsLabel, documentSettings);
        commonMethods.waitForElementExplicitly(500);
        commonMethods.clickLinkToChange(driver, projectSettingsLabel, documentTypesTab);
    }

    /**
     * Function to navigate to Project hierarchies
     */
    public void navigateProjectHierarchies() {
        getMenuSubmenu("Setup", "Project Settings");
        verifyAndSwitchFrame();
        commonMethods.clickLinkToChange(driver, projectSettingsLabel, projectFields);
        commonMethods.clickLinkToChange(driver, projectSettingsLabel, hierarchies);
    }
    /**
     * Function to verify the review status labels in work flows and supplier document page under project settings
     */
    public List<String> verifyReviewStatusLabels() {
       List<String> reviewStatusLabels = new ArrayList<>();
       commonMethods.waitForElement(driver, reviewElements);
       List<WebElement> reviewList = driver.findElements(reviewElements);
       for(WebElement element : reviewList) {
           reviewStatusLabels.add(element.getText());
       }
        return reviewStatusLabels;
    }
    /**
     * Function to verify complete submission check box in work flows and supplier document page under project settings
     *
     */
    public boolean verifyCompleteSubmission() {
        return $(completesSubmissionChk).isDisplayed();
    }

    /**
     * Function to check the replacement file checkbox in work flows and supplier document page under project settings
     *
     */
    public boolean chkReplacementFile() {
        return $(replacementFileChk).isSelected();
    }

    /**
     * Function to check the online markup checkbox in work flows and supplier document page under project settings
     *
     */
    public boolean chkOnlineMarkup() {
        return $(onlineMarkupChk).isSelected();
    }

    /**
     * Function to get all the mail types in the mail section of the project settings
     *
     */
    public List<String> getMailTypes(){
     return commonMethods.getValues(mailTypeList);
    }

    /**
     * Function to update project name in project details page
     *
     */
    public void updateProjectName(String prjtName) {
        commonMethods.waitForElement(driver, projectName, 60);
        commonMethods.enterTextValue(projectName, prjtName);
        $(saveBtn).click();
    }

    /**
     * Function to update project address in project details page
     *
     */
    public void updateAddress(String address) {
        commonMethods.waitForElement(driver, projectAddress1, 60);
        commonMethods.enterTextValue(projectAddress1, address);
        $(saveBtn).click();
    }

    /**
     * Function to update project city in project details page
     *
     */
    public void updateCity(String cityName) {
        commonMethods.waitForElement(driver, projectSuburb, 60);
        commonMethods.enterTextValue(projectAddress1, cityName);
        $(saveBtn).click();
    }

    /**
     * Function to update project phone in project details page
     *
     */
    public void updatePhone(String phoneNum) {
        commonMethods.waitForElement(driver, txtBoxPhone, 60);
        commonMethods.enterTextValue(txtBoxPhone, phoneNum);
        $(saveBtn).click();
    }

    /**
     * Function to update project fax in project details page
     *
     */
    public void updateFax(String faxNum) {
        commonMethods.waitForElement(driver, txtBoxFax, 60);
        commonMethods.enterTextValue(txtBoxFax, faxNum);
        $(saveBtn).click();
    }


    /**
     * Method to fix the project name
     * When we copy of project, string 'Of' is copied.
     * Removing that in this method
     */
    public void correctProjectName() {
        navigateAndVerifyPage();
        verifyAndSwitchFrame();
        switchProjectSettingsFrame();
        String project = $(projectName).getValue();
        if(project.contains(" of ")){
            project = project.replace(" of ", " ");
        }
        $(projectName).clear();
        commonMethods.waitForElementExplicitly(500);
        $(projectName).sendKeys(project);
        $(projectShortName).clear();
        commonMethods.waitForElementExplicitly(500);
        $(projectShortName).sendKeys(project);
        clickSaveButton();
        refresh();
    }

    /**
     * Function to verify export button is present in project details page
     *
     */
    public boolean verifyExportButton() {
        commonMethods.waitForElement(driver, btnExport);
        return $(btnExport).isDisplayed();
    }

    /**
     * Function to click on export button in project details page
     *
     */
    public void clickExport() {
        commonMethods.waitForElement(driver, btnExport, 60);
        $(btnExport).click();
    }

    /**
     * Function to check allow oracle support staff to copy this project configuration checkbox
     */
    public void setAllowChkBox(boolean flag) {
        commonMethods.waitForElement(driver, allowChkBox);
        $(allowChkBox).setSelected(flag);
    }

    /**
     * Function to wait until export progress loader is disappear
     */
    public void verifyExportProgress() {
        commonMethods.waitForElementHidden(driver, txtExportProgress);
    }

    /**
     * Function to return field value
     */
    public String getFieldValue(String fieldName, String type) {
        if (type.equalsIgnoreCase("text"))
            return $(By.xpath("//td[text()='" + fieldName + "']/following-sibling::td//input[1]")).getValue();
        else if (type.equalsIgnoreCase("dropdown"))
            return $(By.xpath("//td[text()='" + fieldName + "']/following-sibling::td//select[1]")).getSelectedText();
        else if (type.equalsIgnoreCase("selectlist"))
            return $(By.xpath("//*[text()='" + fieldName + "']/../following-sibling::td//select[1]")).getSelectedText();
        else if (type.equalsIgnoreCase("textarea"))
            return $(By.xpath("//td[text()='Project Description']/../following-sibling::tr//textarea[1]")).getValue();
        else
            return $(By.xpath("//td[text()='" + fieldName + "']/following-sibling::td//input[1]")).getText();
    }

    /**
     * Method to navigate to the package type page to create new packages
     */
    public void clickPackageTypes() {
        commonMethods.waitForElement(driver, lnkpackageTypes);
        $(lnkpackageTypes).click();
    }

    /**
     * Function to click on Mail Tab
     */
    public void clickPackages() {
        $(packagesLink).click();
    }

    /**
     * Function to verify packages tab displayed
     */
    public boolean verifyPackagesTab() {
       return $(packagesLink).isDisplayed();
    }

    /**
     * Function to verify mail type option
     */
    public boolean verifyMailTypeOption() {
        return $(mailTypes).isDisplayed();
    }

    /**
     * Function to verify mail type option
     */
    public void clickPackageSettings() {
        $(lnkPackageSettings).click();
    }

    /**
     * Click on the mail status tab under Mail
     */
    public void clickMailStatus() {
        $(mailStatus).click();
    }

    /**
     * Method to enter the values to mail status pop up and save it
     * @param map
     */
    public void changeMailStatus(Map<Object, Object> map) {
        By by = By.xpath("//td[contains(text(),'" + map.get("When")+"')]//following::td//span[2]");
        $(by).click();
        $(respondedSelect).selectOptionContainingText(map.get("Responded").toString());
        $(closedOutSelect).click();
        Select select = new Select($(closedOutSelect));
        select.selectByVisibleText(map.get("Closed-Out").toString());
        $(mailStatusSave).click();
    }

    /**
     * Method to edit the values selected for project working week
     * @param days
     */
    public void editWorkingWeek(List<String> days) {
        $(editIcon).click();
        List<WebElement> daysElement = driver.findElements(workday);
        for(WebElement dayElement:daysElement){
            $(dayElement).setSelected(false);
        }
        for(String value:days){
            By by = By.xpath("//input[@value='"+ value.toUpperCase() +"']");
            $(by).setSelected(true);
        }
        clickSaveBtn();
    }
}