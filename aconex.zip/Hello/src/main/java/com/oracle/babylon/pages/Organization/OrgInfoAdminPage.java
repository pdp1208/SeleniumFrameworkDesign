package com.oracle.babylon.pages.Organization;

import com.oracle.babylon.Utils.helper.Navigator;
import org.openqa.selenium.By;
import static com.codeborne.selenide.Selenide.$;

public class OrgInfoAdminPage extends Navigator {

    private By availableSettingsBtn = By.xpath("//button//div[contains(text(),'View Available Secured Assets')]");

    /**
     * Method to edit the available settings for an organization
     */
    public void editAvailableSettings(String text){
        commonMethods.waitForElement(driver,availableSettingsBtn);
        $(availableSettingsBtn).click();
        String[] assets = null;
        if(text.contains(",")){
            assets = text.split(",");
            for (String asset: assets) {
                $(By.xpath("//label[contains(.,'" + asset + "')]//input")).setSelected(true);
            }
        }else {
            $(By.xpath("//label[contains(.,\"" + text + "\")]//input")).setSelected(true);
        }

        $(pageSaveBtn).click();
    }

    /**
     * Method to click on available asset button.
     */
    public void clickAvailableAssets(){
        $(availableSettingsBtn).click();
    }
}
