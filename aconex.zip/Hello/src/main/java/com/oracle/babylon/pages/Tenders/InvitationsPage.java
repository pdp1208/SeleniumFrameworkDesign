package com.oracle.babylon.pages.Tenders;

import com.codeborne.selenide.WebDriverRunner;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;

import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class InvitationsPage extends TenderPage {

    private By loadingIcon = By.cssSelector(".loading_progress");
    private By tenderSearchField = By.xpath("//input[@name='tenderSuperSearch']");
    private By searchBtn = By.xpath("//button[contains(.,'Search')]");
    private By firstTender = By.xpath("//table[@class='grid-body-table dataTable']//tbody//tr[1]//td[1]//a");
    private By createRFI = By.xpath("//button//div[text()='Create RFI']");
    private By createAddendum = By.xpath("//button//div[text()='Create Addendum']");
    private By declineInvitation = By.xpath("//button//div[text()='Decline Invitation']");
    private By createSubmission = By.xpath("//button//div[text()='Create Submission']");
    private By printRequest = By.xpath("//button//div[text()='Print Request']");
    private By zipDownload = By.xpath("//button//div[text()='Zip Download']");
    private By addRecipients = By.xpath("//button//div[text()='Add Recipients']");
    private By send = By.xpath("//button//div[text()='Send']");
    protected By searchStatus = By.xpath("//div[@id='tenderStatus']");
    private By searchArea = By.xpath("//div[@class='uiBidi-left']//select[@multiple='multiple']");
    private By selectedArea = By.xpath("//div[@class='uiBidi-right']//select[@multiple='multiple']");
    private By okBtn = By.xpath("//button[@id='tenderStatus_panel-commit']//div[text()='OK']");
    private By addButton = By.xpath("//button[@id='tenderStatus_bidi_add']");
    private By removeButton = By.xpath("//button[@id='tenderStatus_bidi_remove']");
    private By tableNoResults = By.xpath("//td[@class='dataNoResults']");
    private By cancelNotification = By.xpath("//div[contains(text(),'The tender has been cancelled')]");
    private By columnOpenDate = By.xpath("//table[@class='grid-header-table dataTable']//th//div[text()='Open Date']");
    private By tenders = By.xpath("//table[@class='grid-body-table dataTable']//tbody//tr//td[1]//a");



    /**
     * Method to navigate to tender invitation page
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Tenders", "Invitations");
        $(loadingIcon).should(disappear);
        Assert.assertTrue("Tender Invitation Page title is not matched correctly", verifyPageTitle(pageTitle));
        commonMethods.waitForElementExplicitly(4000);
    }


    /**
     * Method to click on first tender invitation
     */
    public void clickOnFirstTender(){
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, firstTender);
        $(firstTender).click();
    }

    /**
     * Method to search tender
     */
    public void searchTender(String tenderNum){
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, tenderSearchField, 60);
        $(tenderSearchField).click();
        $(tenderSearchField).sendKeys(tenderNum);
        commonMethods.waitForElementExplicitly(5000);
        clickSearch();
        commonMethods.waitForElementExplicitly(8000);
    }


    /**
     * Method to click on search button
     */
    public void clickSearch(){
        Actions actions = new Actions(WebDriverRunner.getWebDriver());
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, searchBtn);
        actions.moveToElement($(searchBtn)).click().build().perform();
//        $(searchBtn).click();
    }

    /**
     * Method to click on search button
     */
    public void verifyTenderPresent(String tenderNum){
        commonMethods.waitForPageLoad(WebDriverRunner.getWebDriver());
        commonMethods.waitForElement(driver, firstTender, 60);
        commonMethods.waitForPageLoad(WebDriverRunner.getWebDriver());
        commonMethods.waitForElementExplicitly(2000);
        System.out.println("Page Loaded");
        commonMethods.scrollToBottom(WebDriverRunner.getWebDriver());
        System.out.println("Page scrolled to bottom");
        commonMethods.waitForElementExplicitly(4000);
        commonMethods.scrollToTop(WebDriverRunner.getWebDriver());
        System.out.println("Page scrolled to top");
        commonMethods.waitForElementExplicitly(1000);
//        searchTender(tenderNum);

        sortTendersToLatest();
        commonMethods.waitForElement(driver, firstTender);
        $(tenderSearchField).click();
        $(tenderSearchField).clear();
        $(tenderSearchField).sendKeys(tenderNum);

        int searchedTimes = 0;
        int MaxSearchTimes = 10;
        String xpath = "//table[@class='grid-body-table dataTable']//tbody//tr//td[1]//a[text()='" + tenderNum + "']";


        while (searchedTimes <= MaxSearchTimes) {
            searchedTimes++;
            boolean gotError = false;

            System.out.println("Searching for tender '" + tenderNum + "': " + searchedTimes + " of " + MaxSearchTimes + ".");

            $(searchBtn).click();

            try {
                commonMethods.waitForElement(driver, firstTender);
            }
            catch (org.openqa.selenium.NoSuchElementException ex){
                gotError = true;
                commonMethods.waitForElementExplicitly(10000); // sleep for 10 seconds
            }

            if (!gotError) {
                By obj = By.xpath(xpath);
                if ($(obj).isDisplayed()) {
                searchedTimes = Integer.MAX_VALUE;
                }
                else {
                    commonMethods.waitForElementExplicitly(10000); // sleep for 10 seconds
                }
            }
        }       
        
        Assert.assertTrue($(By.xpath(xpath)).isDisplayed());
        }

    /**
     * Method to click on search button
     */
    private void sortTendersToLatest() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, firstTender);
        commonMethods.waitForElementExplicitly(1000);
        $(tenderSearchField).click();
        commonMethods.waitForElementExplicitly(1000);
        $(columnOpenDate).click();
        commonMethods.waitForElement(driver, firstTender);
        if (!$(columnOpenDate).getAttribute("class").equals("sortDesc")) {
            $(columnOpenDate).click();
            commonMethods.waitForElement(driver, firstTender);
        }
    }

    /**
     * Method to verify the ui in a open tender invitation
     */
    public void verifyOpenButtons(){
        Assert.assertTrue($(createRFI).isDisplayed());
        Assert.assertTrue($(createAddendum).isDisplayed());
        Assert.assertTrue($(addRecipients).isDisplayed());
        Assert.assertTrue($(send).isDisplayed());
        Assert.assertTrue($(actionsBtn).isDisplayed());
    }

    /**
     * Method to verify the ui in a closed tender invitation
     */
    public void verifyClosedButtons(){
        Assert.assertTrue($(createRFI).isDisplayed());
        Assert.assertTrue($(createSubmission).isDisplayed());
        Assert.assertTrue($(declineInvitation).isDisplayed());
        Assert.assertTrue($(printRequest).isDisplayed());
        Assert.assertTrue($(zipDownload).isDisplayed());
    }

    /**
     * Method to fill the search status
     * @param status
     */
    public void fillSearchStatus(String status)
    {
        commonMethods.waitForElementExplicitly(2000);
        Actions actions = new Actions(driver);
        actions.moveToElement($(searchStatus)).click().build().perform();
       // $(searchStatus).click();
        Select select = new Select($(searchArea));
        select.selectByValue(status.toUpperCase());
        $(addButton).click();
        $(okBtn).click();
    }


    /**
     * Method to remove the status from the selected text area
     */
    public void removeSelectedElements(){
        Actions actions = new Actions(driver);
        actions.moveToElement($(searchStatus)).click().build().perform();
        Select rightSelect = new Select($(selectedArea));
        for(WebElement selectedElement:rightSelect.getOptions())
        {
            rightSelect.selectByValue(selectedElement.getText().toUpperCase());
        }
        $(removeButton).click();
        $(okBtn).click();
    }

    /**
     * Method to return the list of status available
     * @return
     */
    public ArrayList returnSearchOptions() {
        ArrayList<String> list = new ArrayList<>();
        $(searchStatus).click();
        Select select = new Select($(searchArea));
        for (WebElement element : select.getOptions()) {
            //String text = element.getText().toLowerCase();
            list.add(element.getText());
        }
        $(cancelBtn).click();
        return list;
    }

    /**
     * Method to add a recipient
     */
    public void addRecipient(){
        commonMethods.waitForElement(driver, addRecipients);
        $(addRecipients).click();
    }


    /**
     * Verify if tender is available
     */
    public void verifyNoResults() {
        Assert.assertTrue($(tableNoResults).isDisplayed());
    }

    public boolean verifyTenderId(String tenderId) {
        commonMethods.waitForElement(driver, invitationTab, 60);
        return $(By.xpath("//table[@class='formTable']//*[contains(text(),'" + tenderId + "')]")).isDisplayed();
    }

    /**
     * Method to verify tender cancel notification
     */
    public boolean verifyCancelNotification() {
        commonMethods.waitForElement(driver, cancelNotification, 60);
        return $(cancelNotification).isDisplayed();
    }

    /**
     * Method to click on last tender invitation
     */
    public void clickOnLastTender(){
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, firstTender);
        int count = $$(tenders).size();
        $(By.xpath("//table[@class='grid-body-table dataTable']//tbody//tr[" + count + "]//td[1]//a")).click();
    }

    /**
     * Method to click on last tender invitation
     */
    public void clickOnTender(String tender){
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, firstTender);
        $(By.xpath("//table[@class='grid-body-table dataTable']//tbody//tr//td[1]//a[text()='" + tender + "']")).click();
    }
}
