package com.oracle.babylon.pages.Directory;

import org.junit.Assert;
import org.openqa.selenium.By;
import static com.codeborne.selenide.Selenide.$;

/**
 * Author : susgopal
 * Class to verify the details present in User Information Page
 */


public class UserInfoPage extends DirectoryPage{

    /**
     * Identifiers
     */
    private By jobTitle = By.xpath("//td[text()='Job Title']");
    private By organization = By.xpath("//td[text()='Organization']");
    private By userAddress = By.xpath("//td[text()='User Address']");
    private By phone = By.xpath("//td[text()='Phone']");
    private By fax = By.xpath("//td[text()='Fax']");
    private By mobile = By.xpath("//td[text()='Mobile']");
    private By pageTitle = By.xpath("//h1[text()='User Information']");


    /**
     * Method to validate the page title
     */
    public void verifyPageTitle(){
        commonMethods.waitForElement(driver, pageTitle);
        Assert.assertTrue($(pageTitle).isDisplayed());
    }

    /**
     * Methdo to verify the name in the results table
     * @param name
     */
    public void verifyName(String name){
        By by = By.xpath("//td[contains(text(),'" + name +"')]");
        Assert.assertTrue($(by).isDisplayed());
    }

    /**
     * Method to validate the organization returned in the results table
     * @param organization
     */
    public void verifyOrganization(String organization){
        By by = By.xpath("//td[contains(text(),'" + organization +"')]");
        Assert.assertTrue($(by).isDisplayed());
    }

    /**
     * Method to validate the job title
     * @param title
     */
    public void verifyJobTitle(String title){
        By by = By.xpath("//td[contains(text(),'" + title +"')]");
        Assert.assertTrue($(by).isDisplayed());
    }

    /**
     * Method to validate the column headers
     */
    public void verifyColumns(){
        Assert.assertTrue($(jobTitle).isDisplayed());
        Assert.assertTrue($(organization).isDisplayed());
        Assert.assertTrue($(userAddress).isDisplayed());
        Assert.assertTrue($(phone).isDisplayed());
        Assert.assertTrue($(fax).isDisplayed());
        Assert.assertTrue($(mobile).isDisplayed());
    }


}
