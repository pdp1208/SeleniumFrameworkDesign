package com.oracle.babylon.pages.Workflows;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ex.InvalidStateException;
import com.oracle.babylon.Utils.helper.CommonMethods;
import com.oracle.babylon.Utils.helper.Navigator;
import com.oracle.babylon.pages.Document.DocumentReviewListModePage;
import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

/**
 * Class to handle the actions of the Workflow page
 * We handle the functions related to search workflow and the initiator tools
 * created by susgopal
 */
public class WorkflowsPage extends Navigator {
    private By mailSubject = By.xpath("//div[@class='mailHeader-subject']//h2//span");

    private By pageTitle = By.xpath("//h1[contains(text(),'Search Workflows')]");
    private By workflowNo = By.xpath("//input[@id='workFlowNo']");
    protected By searchBtn = By.xpath("//button[@id='btnSearch_page']");
    private By selectRecord = By.xpath("//input[@id='selectedIdsInPage']");
    private By reviewDocument = By.xpath("//a[@title='Review all documents in this step']");
    private By editMarkup = By.xpath("//a[text()='Edit Markup Options']");
    private By markupChkBox = By.xpath("//input[@id='markupOptions' and @value='MARKUP_BY_ONLINE_VIEWER']");
    private By replacementFileChkBox = By.xpath("//input[@id='markupOptions' and @value='MARKUP_BY_REPLACEMENT_FILE']");
    private By okBtn = By.xpath("//button[@id='btnworkFlowSearchConfirmation_dialogPanel_ok']");
    private By closeBtn = By.xpath("//button[@id='btnworkFlowSearchConfirmation_dialogPanel_close']");
    private By terminateLink = By.xpath("//a[text()='Terminate']");
    private By stepStatus = By.xpath("//table[@class='dataTable']//tbody//tr[1]//td[7]");
    private By skipStep = By.xpath("//a[text()='Skip Step']");
    private By wfHistory = By.xpath("//a[@title='View workflow history of this document']//img");
    private By historyStepOutcome = By.xpath("//div[@class='wfSteps']//table[@class='dataTable']//tbody//tr//td[4]");
    private By historyStepStatus = By.xpath("//div[@class='wfSteps']//table[@class='dataTable']//tbody//tr//td[5]");
    private By docPanel = By.xpath("//div[@id='excludedDocs_body']//div[2]");
    private By workflowNote = By.xpath("//div//b[contains(text(),'Workflow Note')]");
    private By numberOfDocs = By.xpath("//table[@id='resultTable']//input[@type='checkbox']");
    private By firstDocName = By.xpath("//table[@id='resultTable']//tr[1]//td[contains(text(),'step')]//..//div");
    private String workflowPath = configFileReader.getWorkflowDataPath();
    protected CommonMethods commonMethods = new CommonMethods();
    private By superSearch = By.xpath("//input[@id='rawQueryText']");
    private By clearBtn = By.xpath("//div[contains(text(),'Clear')]");
    private By saveSearchAsBtn = By.xpath("//div[contains(text(),'Save Search As')]");
    private By saveSearchName = By.xpath("//input[@id='savedSearchName']");
    private By saveSearchDescription = By.xpath("//textarea[@id='savedSearchDescription']");
    private By saveSearchShareFlag = By.xpath("//input[@id='savedSearchSharedFlag']");
    private By saveSearchOkBtn = By.xpath("//button[@id='btnsaveSearchPanel_ok']//div[@class='uiButton-label'][contains(text(),'OK')]");
    private By saveSearchCancelBtn = By.xpath("//button[@id='btnsaveSearchPanel_ok']//div[@class='uiButton-label'][contains(text(),'OK')]");
    private By closeSaveSearchPanelX = By.xpath("//div[@id='btnsaveSearchPanel_closeBox']");
    private By savedSearchDropDown = By.xpath("//span[@id='savedSearchSelector']");
    private By manageSavedSearch = By.xpath("//option[contains(text(),'Manage Saved Searches')]");
    private By savedSearchManageDrpDown = By.xpath("//select[@id='savedSearchManageSSList']");
    private By deleteSavedSearchLink = By.xpath("//a[@class='delete-link']");
    private By manageSavedSearchOkBtn = By.xpath("//button[@id='btnsaveSearchPanel_ok']//div[@class='uiButton-label'][contains(text(),'OK')]");
    private By publisherName = By.xpath("//tr[@id='savedSearchPublishedByRow']//td[@class='contentcell']");
    private By documentNoField = By.xpath("//input[@id='docNo']");
    private By workflowNameField = By.xpath("//input[@id='workFlowName']");
    private By stepNameField = By.xpath("//input[@id='stepName']");
    private By assignedTo = By.xpath("//table[@id='querySearchQueryTable']//tr//td[contains(.,'Assigned To')]/following-sibling::td");
    private By initiator = By.xpath("//table[@id='querySearchQueryTable']//tr//td[contains(.,'Initiator')]/following-sibling::td[1]");
    private By workflowSearchTable = By.xpath("//table[@id='resultTable']");
    private By dueDate = By.xpath("//table[@id='querySearchQueryTable']//tr//td[contains(.,'Date Range')]/following-sibling::td//select[1]");
    private By dateRange = By.xpath("//table[@id='querySearchQueryTable']//tr//td[contains(.,'Date Range')]/following-sibling::td//select[2]");
    private By addDateQueryLink = By.xpath("//a[@id='wfSearchDP_add']");
    private By toDate = By.xpath("//table[@id='querySearchQueryTable']//tr//td[contains(.,'Date Range')]/following-sibling::td//tr[1]//input[@class='date drp_date2_txt']");
    private By fromDate = By.xpath("//table[@id='querySearchQueryTable']//tr//td[contains(.,'Date Range')]/following-sibling::td//tr[1]//input[@class='date drp_date1_txt']");
    private By firstTemplate = By.xpath("//table[@id='resultTable']//tbody[1]//a");
    private By backButton = By.xpath("//button[@id='btnBack']");
    private By workflowStatusMultiSelect = By.xpath("//div[@id='workFlowStatus_multiselectdiv']");
    private By stepStatusMultiSelect = By.xpath("//div[@id='stepStatus_multiselectdiv']");
    private By stepOutComeMultiSelect = By.xpath("//div[@id='reviewOutcome_multiselectdiv']");
    private String tableHeaders = "//table[@id='resultTable']//thead//th";
    private String selectedColumnsList = "//div[@id='configColumns_body']//div[@class='uiBidi-right']//select//option";
    private String availableColumnList = "//div[@id='configColumns_body']//div[@class='uiBidi-left']//select//option";
    private String dateDueResult = "//table[@id='resultTable']//tbody//tr[@class='dataRow']//td[8]";
    private String sortByOption = "//select[@id='sortField']//option";
    private By tableHeader = By.xpath("//table[@id='resultTable']//thead");
    private String multiSelectOkBtn = "//div[@class='uiButton-label'][contains(text(),'OK')]";
    private By resetColumnBtn = By.xpath("//div[contains(text(),'Reset')]");
    private By sortByDropdown = By.xpath("//select[@id='sortField']");
    private By invalidQueryMessage = By.xpath("//div[@id='searchResultsContainer']//div[@id='searchMessagePanel']");
    private By firstWorkflowRow = By.xpath("//table[@id='resultTable']//tbody[1]//tr[@class='dataGroup']");
    private By myTaskOnly = By.xpath("//input[@id='myItemsOnly']");
    private By contractAdvancedSearchFilter = By.xpath("//a//img[@id='toggleModeIcon' and @src='/html/Images/icons/ic_lrg_less.gif']");
    private By expandAdvancedSearchFilter = By.xpath("//a//img[@id='toggleModeIcon' and @src='/html/Images/icons/ic_lrg_more.gif']");
    private By resultCountContainer = By.xpath("//div[@id='searchResultsContainer']//div[@class='searchNav clearFloats'][1]//div[@id='numResults']/b[1]");
    private By collapseFirstResultRows = By.xpath("//table[@id='resultTable']//tbody[1]//td[1]//div[@class='collapseIcon']");
    private By expandFirstResultRows = By.xpath("//table[@id='resultTable']//tbody[1]//td[1]//div[@class='expandIcon']");
    private By secondRow = By.xpath("//table[@id='resultTable']//tbody[2]");
    private By zeroResultMessage = By.xpath("//div[@id='loadingMessage']");
    private String multiSelectWorkflowStatus = "//select[@id='bidi_workFlowStatus_AVAIL']//option";
    private String multiSelectWorkflowStepStatus = "//select[@id='bidi_stepStatus_AVAIL']//option";
    private String multiSelectWorkflowStepOutcome = "//select[@id='bidi_reviewOutcome_AVAIL']//option";
    private String multiSelectWorkflowStatusOk = "//button[@id='btnbidiPanel_workFlowStatus_ok']";
    private String multiSelectWorkflowStepStatusOk = "//button[@id='btnbidiPanel_stepStatus_ok']";
    private String multiSelectWorkflowStepOutcomeOk = "//button[@id='btnbidiPanel_reviewOutcome_ok']";
    private By searchResultsContainer = By.xpath("//*[@id='searchResultsContainer']");
    public By workflowNoHeader = By.xpath("//th[@class='sortable']//div[contains(text(),'Workflow No.')]");
    public By workflowNameHeader = By.xpath("//th[@class='sortable']//div[contains(text(),'Workflow Name')]");
    public By workflowNoInRow = By.xpath("(//tr[@class='dataGroup']//td//*[contains(text(),'Workflow No.:')])[1]");
    public By workflowNameInRow = By.xpath("(//tr[@class='dataGroup']//td//*[contains(text(),'Name:')])[1]");
    private By initiatorInput = By.xpath("//input[@id='initiator_query']");
    private By initiatorSearchIcon = By.xpath("//span[@id='initiator']//*[@class='bicon ic-search']");
    private By assignedToSearchIcon = By.xpath("//span[@id='assignee']//*[@class='bicon ic-search']");
    private By rowDataGroup = By.xpath("//tr[@class='dataGroup']");
    private By templateResults = By.xpath("//table[@id='resultsTable']");
    private By templateNameOnResults = By.xpath("//table[@id='resultsTable']//tr[@class='dataRow']//td//a[@title='View template settings']");
    private By templateDropDown = By.xpath("//select[@id='workFlowId']");

    private By submitSelectedDocumentsBtn = By.xpath("//button[@id='btnSubmitSelected']//div[@class='uiButton-label'][contains(text(),'Submit Selected Documents')]");
    private By summaryPanel = By.xpath("//*[@id='summaryPanel']");
    private By summaryPanelOKBtn = By.xpath("//button[@id='btnsummaryPanel_ok']");
    private By successMsgOnReview = By.xpath("//*[@class='message success']//div[contains(text(),'Reviewed documents have been submitted to the next step in the workflow')]");
    private By workflowStatusHeader = By.xpath("//th[@class='sortable']//*[contains(text(),'Workflow Status')]");
    private By stepStatusHeader = By.xpath("//th[@class='sortable']//*[contains(text(),'Step Status')]");
    private By closeBtnOnSortTip = By.xpath("//div[@id='sortingTip']//*[@class='uiButton-content']//*[contains(text(),'Close')]");
    private String addToFilter = "//*[@class='uiButton-content']//div[contains(text(),'>>')]";
    private String filterOKBtn = "//button[@title='OK and close window']";
    private By initiatorContainer = By.xpath("//table[@id='initiator_container']//div[@class='lookup-assignee lookup-user truncated']");
    private By replaceContainer = By.xpath("//table[@id='delegateReassign_originalLookup_container']//div[@class='lookup-assignee lookup-user truncated']");
    private By withContainer = By.xpath("//table[@id='delegateReassign_replaceLookup_container']//div[@class='lookup-assignee lookup-user truncated']");
    private By mailGrpContainer = By.xpath("//div[@class='lookup-multimatches']//span");
    private By removeIcon = By.xpath("//div[@class='auiIcon trash']");
    private By assigneeContainer = By.xpath("//table[@id='assignee_container']//div[@class='lookup-assignee lookup-user truncated']");
    private By initiatorErrorMsg = By.xpath("//div[@id='initiator_list']//div[@class='lookup-error-message']");
    private By replaceErrorMsg = By.xpath("//div[@id='delegateReassign_originalLookup_list']//div[@class='lookup-error-message']");
    private By withErrorMsg = By.xpath("//div[@id='delegateReassign_replaceLookup_list']//div[@class='lookup-error-message']");
    private By assigneeErrorMsg = By.xpath("//div[@id='assignee_list']//div[@class='lookup-error-message']");
    private By initiatorToolsBtn = By.xpath("//button[@id='btnInitiatorTools_page']");
    private By reasonTxtArea = By.xpath("//textarea[@id='workFlowSearchConfirmation_txt']");
    private By skipCancelBtn = By.xpath("//button[@id='btnworkFlowSearchConfirmation_dialogPanel_cancel']");
    private By skipStepSuccessMsg = By.xpath("//div[contains(text(),'Selected steps have been successfully skipped')]");
    private By terminateSuccessMsg = By.xpath("//div[contains(text(),'Selected documents have been successfully terminated from this workflow')]");
    private By reassignSuccessMsg = By.xpath("//div[contains(text(),'Tasks successfully reassigned')]");
    private By reassignMsg = By.xpath("//b[contains(text(),'1 out of 1 selected tasks have been reassigned to the following participants')]");
    private By docChkBoxes = By.xpath("//table[@id='resultTable']//td[contains(text(),'step')]//..//input[1]");
    private By markupSuccessMsg = By.xpath("//div[contains(text(),'Markup options for the selected documents have been successfully updated')]");
    private By markupOptionsTxt = By.xpath("//span[contains(text(),'Markup options')]");
    private By noteTxt = By.xpath("//div[contains(text(),'Note: These options will now be available for this document on all subsequent steps of this workflow')]");
    private By replaceUserField = By.xpath("//input[@id='delegateReassign_originalLookup_query']");
    private By inputWithUser = By.xpath("//input[@id='delegateReassign_replaceLookup_query']");
    private By fileAttachIcon = By.xpath("//img[contains(@id,'fileAttachIcon')]");
    private By attachFilePanel = By.xpath("//div[@id='attachFileChoice_fileChoicePanel']");
    private By localAttach = By.xpath("//button[@id='attachFileChoice_fileChoicePanel_btnAttachFromLocal_page']");
    private By temporaryFilesAttach = By.xpath("//button[@id='attachFileChoice_fileChoicePanel_btnAttachFromControlledDocs_page']");
    private By attachPanelCancelBtn = By.xpath("//button[@id='btnattachFileChoice_fileChoicePanel_cancel']");
    private By markupEyeIcon = By.xpath("//button[@title='View and markup this document']");
    private By noWorkFlowsMsg = By.xpath("//div[@id='loadingMessage']");
    private By docReviewMode = By.xpath("//span[contains(text(),'Document Review (Doc Mode)')]");
    private By fileFormatTxt = By.xpath("//div[text()='This file format is not currently supported for viewing and editing']");
    private By linkDownloadOriginalFile = By.xpath("//button[@data-element='downloadButton']");
    private By moreInfoTxt = By.xpath("//span[contains(text(),'More information about supported file types.')]");
    private By selectReview = By.xpath("//select[@class='auiField-input dropdown-arrow']");
    private By submitReviewBtn = By.xpath("//span[@id='submitReview']");
    private By commentTxtArea = By.xpath("//textarea[@class='auiField-input review-comment']");
    private By backBtn = By.xpath("//button[@class='auiButton backbutton header-button']");
    private By imgSubWorkflowLck = By.xpath("//img[@src='/html/Images/icons/ic_subworkflow_locked.gif']");
    private By imgsubWorkflowCompltd = By.xpath("//img[@src='/html/Images/icons/ic_subworkflow_completed.gif']");
    private By delegateMsg = By.xpath("//b[contains(text(),'1 out of 1 selected documents have been delegated to the following participants')]");
    private By workflowNum = By.xpath("//span[text()='Workflow No.:']");
    private By supplementBtn = By.xpath("//div[text()='Supplementary Files']");
    private By selectSupplementaryFiles = By.xpath("//li[contains(text(),'Supplementary Files')]");
    private By supplementCloseBtn = By.xpath("//button[@id='btnsuppFilesPanel_ok']");
    private By supplementReviewTab = By.xpath("//li[@id='SUPP_FILES_TABList']");
    private By txtBoxFilePath = By.xpath("//td/input[@id='FILE_PATH_NAME']");
    private By btnReports = By.xpath("//div[contains(text(),'Reports')]");
    private By lstReportTypes = By.xpath("//ul[@id='REPORTS_MENU']/li//a");
    private By bannerExportExcel = By.xpath("//div[@class='auiMessage message-banner info']");
    private By lblSelectTemplate = By.xpath("//span[@id='selectTemplatePanel_title']");
    private By infoSelectATemplate = By.xpath("//div[contains(text(),'Please select a template')]");
    private By sltTemplate = By.xpath("//select[@id='workFlowIdDialog']");
    private By btnOk = By.xpath("//button[@id='btnselectTemplatePanel_ok']//div[contains(text(),'OK')]");
    private By btnCancel = By.xpath("//button[@id='btnselectTemplatePanel_cancel']//div[contains(text(),'Cancel')]");
    private By lnkTemporaryFiles = By.xpath("//a[contains(text(),'Temporary Files')]");
    private By tblResultsHdrs = By.xpath("//table[@id='resultTable']//tr/th");
    private By txtNoResults = By.xpath("//div[text()='No workflows matched your request']");
    private By txtBoxReplace = By.xpath("//input[@id='delegateReassign_originalLookup_query']");
    private By txtBoxWith = By.xpath("//input[@id='delegateReassign_replaceLookup_query']");
    private By btnDelegateOk = By.xpath("//button[@id='btnworkFlowSearchConfirmation_dialogPanel_ok']");
    private By btnDelegateCancel = By.xpath("//button[@id='btnworkFlowSearchConfirmation_dialogPanel_cancel']");
    private By btnDelegateClose = By.xpath("//div[@id='btnworkFlowSearchConfirmation_dialogPanel_closeBox']");
    private By lblSuccessTask = By.xpath("//div[contains(text(),'Tasks successfully delegated')]");
    private By lblDelegateSummary = By.xpath("//div[@class='summaryMessage']");
    private By btnDelegateSuccessClose = By.xpath("//button[@id='btnworkFlowSearchConfirmation_dialogPanel_close']");
    private By btnTrash = By.xpath("//div[@class='auiIcon trash']");
    String workflowFilePath = configFileReader.getWorkflowDataPath();
    String userFilePath = configFileReader.getUserDataPath();
    String filePath = System.getProperty("user.dir") + "/src/main/resources/data/files/";
    public By zipDownloadButton = By.xpath("//button//*[contains(text(),'Zip Download')]");
    public By btnAttachSupplimentaryFile = By.id("btnAttach");
    public By uploadSupplimentaryFile = By.xpath("//input[@name='qqfile']");
    public By btnAttachLocalFile = By.id("btnAttachLocalFile");
    public By attachSuccess = By.xpath("//*[contains(@class,'scope progress-bar-success')]");
    private By btnCloseAttachments = By.id("btnCloseAttachments");
    private By btnattachFileChoice_ok = By.id("btnattachFileChoice_fileChoicePanel_ok");

    DocumentReviewListModePage documentReviewListModePage = new DocumentReviewListModePage();
    private By noRecords = By.xpath("//div[@class='files']//ul//li");
    private By selectedColumns = By.xpath("//select[@name='bidi_configColumns']");

    /**
     * Method to navigate to the workflows page and verify the title
     */
    public void navigateAndVerifyPage() {
        refresh();
        commonMethods.waitForElementExplicitly(2000);
        getMenuSubmenu("Workflows", "Search", "Workflows");
        commonMethods.waitForElementExplicitly(2000);
        Assert.assertTrue(verifyPageTitle(pageTitle));
    }

    /**
     * Method to verify the title of the Document Review List mode page
     *
     * @return
     */
    public boolean verifyTitle() {
        commonMethods.waitForElement(driver, pageTitle, 60);
        return $(pageTitle).isDisplayed();
    }

    /**
     * Method to return the workflow id from the mail transmitted
     *
     * @return
     */
    public String returnWorkflowId() {
        commonMethods.waitForElement(driver, mailSubject, 120);
        String subject = $(mailSubject).getText();
        return subject.substring(subject.indexOf("(") + 1, subject.indexOf(")"));
    }

    /**
     * Method to search for a workflow by the workflow id
     *
     * @param workflowId
     */
    public void searchWorkflowNumber(String workflowId) {
        verifyAndSwitchFrame();
        $(workflowNo).clear();
        $(workflowNo).sendKeys(workflowId);
        commonMethods.waitForElementExplicitly(3000);
        $(searchBtn).click();
    }

    /**
     * Method to click on the review Documents icon.
     * Usually the green tick icon
     */
    public void reviewDocuments() {
        commonMethods.waitForElement(driver, reviewDocument, 60);
        commonMethods.waitForElementExplicitly(3000);
        $(reviewDocument).click();
    }

    /**
     * Method to select the first document/workflow
     */
    public void selectFirstDocument() {
        commonMethods.waitForElement(driver, selectRecord);
        $(selectRecord).click();
    }


    /**
     * Method to click on the initiator tools
     */
    public void clickInitiatorTools() {
        commonMethods.waitForElement(driver, initiatorToolsBtn);
        $(initiatorToolsBtn).click();
    }

    /**
     * Method to click on edit markup options
     */
    public void editMarkupOptions() {
        $(editMarkup).click();
    }

    /**
     * Method to select the options for the check boxes
     *
     * @param replacementFile
     * @param onlineMarkup
     */
    public void selectMarkUpOptions(String replacementFile, String onlineMarkup) {
        if (Boolean.parseBoolean(replacementFile)) {
            $(replacementFileChkBox).setSelected(true);
        }
        if (Boolean.parseBoolean(onlineMarkup)) {
            $(markupChkBox).setSelected(true);
        }
        $(okBtn).click();
        if (commonMethods.isAlertPresent(driver)) {
            commonMethods.acceptAlert(driver);
        }
        $(closeBtn).click();
    }

    /**
     * Method to terminate the workflow
     */
    public void terminateWorkflow() {
        $(terminateLink).click();
        $(reasonTxtArea).sendKeys("testing the terminate workflow process");
        $(okBtn).click();
        commonMethods.waitForElement(driver, closeBtn, 20);
        $(closeBtn).click();
    }

    /**
     * Method to return the step status from the table
     *
     * @param index
     * @return
     */
    public String returnStepStatus(int index) {
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.scrollToBottom(driver);
        return driver.findElement(By.xpath("//table[@class='dataTable']//tbody//tr[" + index + "]//td[7]")).getText();

    }

    /**
     * Method to click on the skip step option
     */
    public void skipStep() {
        $(skipStep).click();
    }

    /**
     * Method to validate if the user has correct permissions
     * to skip a step in the workflow process
     *
     * @return
     */
    public boolean validateSkipStep() {
        commonMethods.waitForElementExplicitly(2000);
        Boolean alertStatus = commonMethods.isAlertPresent(driver);
        if (alertStatus) {
            commonMethods.acceptAlert(driver);
            return true;
        } else {
            return false;
        }
    }

    /**
     * Method to validate the history of the workflow
     * We validate the review outcome and the step status
     *
     * @param outcome
     * @param status
     */
    public void validateHistory(String outcome, String status) {
        verifyAndSwitchFrame();
        $(wfHistory).click();
        Assert.assertEquals(outcome, $(historyStepOutcome).getText());
        Assert.assertEquals(status, $(historyStepStatus).getText());
    }

    /**
     * Method to validate if the green tick icon is present for Pending step
     *
     * @param index row index
     * @return
     */
    public Boolean validatePendingStep(int index) {
        WebElement element = driver.findElement(By.xpath("//table[@class='dataTable']//tr[" + index
                + "]//img[@title='This step is not current. Documents can only be reviewed at current or overdue steps.']"));
        if (element.isDisplayed()) {
            return true;
        }
        return false;
    }

    /**
     * Method to validate if the green tick icon is displayed for current step
     *
     * @param index row index
     * @return
     */
    public Boolean validateCurrentStep(int index) {
        WebElement element = driver.findElement(By.xpath("//table[@class='dataTable']//tr[" + index
                + "]//a[@title='View workflow history of this document']//img"));
        if (element.isDisplayed()) {
            return true;
        }
        return false;

    }

    /**
     * Method to get Document workflow Panel text
     */
    public String getDocumentPanelText() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, docPanel, 30);
        return $(docPanel).text();
    }

    /**
     * Function to click save search button
     */
    public void clickSaveSearchAs() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, saveSearchAsBtn, 30);
        if ($(closeSaveSearchPanelX).isDisplayed()) $(closeSaveSearchPanelX).click();
        $(saveSearchAsBtn).click();
    }


    /**
     * Function to save a search
     *
     * @param attribute
     */
    public void saveSearch(String attribute) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, saveSearchName, 30);
        Map<String, String> table = dataStore.getTable(attribute);
        for (String tableData : table.keySet()) {
            switch (tableData) {
                case "Name":
                    $(saveSearchName).clear();
                    $(saveSearchName).setValue(table.get(tableData));
                    break;
                case "Description":
                    $(saveSearchDescription).clear();
                    $(saveSearchDescription).setValue(table.get(tableData));
                    break;
                case "Share":
                    $(saveSearchShareFlag).setSelected(Boolean.parseBoolean(table.get(tableData)));
                    break;
            }
        }
    }

    /**
     * Function to search workflow
     *
     * @param savedSearchAttribute
     */
    public void searchWorkflow(String savedSearchAttribute) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, superSearch, 30);
        if (!$(workflowNameField).isDisplayed()) showAdvancedSearchFilters();
        Map<String, String> table = dataStore.getTable(savedSearchAttribute);
        for (String tableData : table.keySet()) {
            switch (tableData) {
                case "Name":
                    $(workflowNameField).clear();
                    $(workflowNameField).setValue(table.get(tableData));
                    break;
                case "Step Name":
                    $(stepNameField).clear();
                    $(stepNameField).setValue(table.get(tableData));
                    break;
                case "Super Search":
                    fillSuperSearch(table.get(tableData));
                    break;
                case "Document No":
                    $(documentNoField).clear();
                    $(documentNoField).setValue(commonMethods.returnDocNumberInJson(table.get(tableData)));
                    break;
                case "Workflow No":
                    fillWorkflowNo(table.get(tableData));
                    break;
                case "Date Range":
                    fillDate(table.get(tableData));
                    break;
                case "Workflow Name":
                    fillWorkflowName(table.get(tableData));
                    break;
                case "Show my task only":
                    $(myTaskOnly).setSelected(Boolean.parseBoolean(table.get(tableData)));
                    break;
                case "Workflow Status":
                    List<String> options = Arrays.asList(table.get(tableData).split(","));
                    selectMultiSelectFilter(tableData, options);
                    break;
            }
        }
    }

    /**
     * Function to fill super search field
     *
     * @param value
     */
    public void fillSuperSearch(String value) {
        verifyAndSwitchFrame();
        $(superSearch).clear();
        $(superSearch).setValue(value);
    }

    /**
     * Function to fill workflow name field
     *
     * @param value
     */

    public void fillWorkflowName(String value) {
        $(workflowNameField).click();
        $(workflowNameField).setValue(value);
    }

    /**
     * Function to fill workflow number field
     *
     * @param value
     */
    public void fillWorkflowNo(String value) {
        $(workflowNo).clear();
        $(workflowNo).setValue(value);
    }

    /**
     * Function to fill workflow number field
     *
     * @param dateString will be in format of "datedue,daterange,fromdate,todate" if multiple date split the date sting using '@'
     */
    public void fillDate(String dateString) {
        if (dateString.contains("@")) {
            String[] dates = dateString.split("@");
            for (int i = 0; i < dates.length; i++) {
                String[] date = dates[i].split(",");
                $(addDateQueryLink).click();
                if (date.length > 0) selectDueDate(date[0], i + 1);
                if (date.length > 1) selectDateRange(date[1], i + 1);
                if (date.length > 2) fromDate(date[2], i + 1);
                if (date.length > 3) fromDate(date[3], i + 1);

            }
        } else {
            String[] date = dateString.split(",");
            if (date.length > 0) selectDueDate(date[0]);
            if (date.length > 1) selectDateRange(date[1]);
            if (date.length > 2) fromDate(date[2]);
            if (date.length > 3) toDate(date[3]);
        }
    }


    /**
     * Function to select due date field
     *
     * @param due
     */
    public void selectDueDate(String due) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, dueDate, 10);
        $(dueDate).selectOptionContainingText(due);
    }

    /**
     * Function to select date range field
     *
     * @param range
     */
    public void selectDateRange(String range) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, dateRange, 10);
        $(dateRange).selectOptionContainingText(range);
    }


    /**
     * Function to select multiple due date
     *
     * @param due
     * @param row
     */
    public void selectDueDate(String due, int row) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, dueDate, 10);
        $(By.xpath("//table[@id='querySearchQueryTable']//tr//td[contains(.,'Date Range')]/following-sibling::td//tr[" + row + "]//select[1]")).selectOptionContainingText(due);
    }

    /**
     * Function to select multiple date range
     *
     * @param range
     * @param row
     */
    public void selectDateRange(String range, int row) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, dateRange, 10);
        $(By.xpath("//table[@id='querySearchQueryTable']//tr//td[contains(.,'Date Range')]/following-sibling::td//tr[" + row + "]//select[2]")).selectOptionContainingText(range);
    }

    /**
     * Function to fill from date value if only one date range is required to fill
     *
     * @param date
     */
    public void fromDate(String date) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, fromDate, 10);
        $(fromDate).setValue(date);
    }

    /**
     * Function to fill to date field
     *
     * @param date
     */
    public void toDate(String date) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, toDate, 10);
        $(toDate).setValue(date);
    }

    /**
     * Function to get to date filled value
     */
    public String getToDateValue() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, toDate, 10);
        return $(toDate).getValue();
    }


    /**
     * Function to get from date filled value
     */
    public String getFromDateValue() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, toDate, 10);
        return $(fromDate).getValue();
    }

    /**
     * Function to get selected due date value
     */
    public String getSelectedDueDate() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, dueDate);
        return $(dueDate).getSelectedText();
    }

    /**
     * Function to get selected date range value
     */
    public String getSelectedDateRange() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, dateRange);
        return $(dateRange).getSelectedText();
    }


    /**
     * Function to fill multiple from date value when there is multiple date range values
     *
     * @param date
     * @param row  for the multiple date field
     */
    public void fromDate(String date, int row) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, dateRange, 10);
        $(By.xpath("//table[@id='querySearchQueryTable']//tr//td[contains(.,'Date Range')]/following-sibling::td//tr[" + row + "]//input[@name='dueDate1_da']")).setValue(date);
    }


    /**
     * Function to fill multiple to date value
     *
     * @param date
     * @param row
     */
    public void toDate(String date, int row) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, dateRange, 10);
        $(By.xpath("//table[@id='querySearchQueryTable']//tr//td[contains(.,'Date Range')]/following-sibling::td//tr[" + row + "]//input[@name='dueDate2_da']")).setValue(date);
    }

    /**
     * Function to click Search button
     */
    public void clickSearch() {
        commonMethods.waitForElementExplicitly(5000);
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, searchBtn, 120);
        $(searchBtn).click();
    }

    /**
     * Function to verify search filter as per the saved search
     *
     * @param attribute
     */
    public void verifySearchFilter(String attribute) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, superSearch, 30);
        Map<String, String> table = dataStore.getTable(attribute);
        for (String tableData : table.keySet()) {
            switch (tableData) {
                case "Name":
                    Assert.assertTrue($(workflowNameField).getValue().equalsIgnoreCase(table.get(tableData)));
                    break;
                case "Step Name":
                    Assert.assertTrue($(stepNameField).getValue().equalsIgnoreCase(table.get(tableData)));
                    break;
                case "Super Search":
                    Assert.assertTrue($(superSearch).getValue().equalsIgnoreCase(table.get(tableData)));
                    break;
                case "Document No":
                    Assert.assertTrue($(documentNoField).getValue().equalsIgnoreCase(commonMethods.returnDocNumberInJson(table.get(tableData))));
                    break;
                case "Workflow No":
                    Assert.assertTrue($(workflowNo).getValue().equalsIgnoreCase(table.get(tableData)));
                    break;
            }
        }

    }

    /**
     * Function to verify option under due date
     *
     * @param option
     */
    public boolean verifyDueDateOption(String option) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, dueDate, 10);
        return $(By.xpath("//table[@id='querySearchQueryTable']//tr//td[contains(.,'Date Range')]/following-sibling::td//select[1]//option[contains(.,'" + option + "')]")).exists();
    }

    /**
     * Function to verify option under date range
     *
     * @param option
     */
    public boolean verifyDateRangeOption(String option) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, dueDate, 20);
        $(dueDate).selectOptionContainingText("Date Completed");
        return $(By.xpath("//table[@id='querySearchQueryTable']//tr//td[contains(.,'Date Range')]/following-sibling::td//select[2]//option[contains(.,'" + option + "')]")).exists();
    }

    /**
     * Function to clear all results
     */
    public void clickClear() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, clearBtn, 40);
        $(clearBtn).click();
    }


    /**
     * Function to click on first workflow template
     */
    public void clickOnFirstWorkflowTemplate() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, firstTemplate, 10);
        $(firstTemplate).click();
    }

    /**
     * Function to get Default column configured
     *
     * @return list of columns
     */
    public List<String> getDefaultColumn() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, addRemoveColumnsBtn);
        $(addRemoveColumnsBtn).click();
        $(resetColumnBtn).click();
        List<String> columnList = new ArrayList<>();
        List<WebElement> elements = driver.findElements(By.xpath(selectedColumnsList));
        for (WebElement e : elements) {
            columnList.add(e.getText());
        }
        return columnList;
    }

    /**
     * Function to get selected column configured
     *
     * @return list of columns
     */
    public List<String> getSelectedColumns() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, addRemoveColumnsBtn);
        List<String> columnList = new ArrayList<>();
        List<WebElement> elements = driver.findElements(By.xpath(selectedColumnsList));
        for (WebElement e : elements) {
            columnList.add(e.getText());
        }
        return columnList;
    }

    /**
     * Function to get selected column configured on table
     *
     * @return list of columns
     */
    public List<String> getSelectedColumnsTable() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, addRemoveColumnsBtn);
        String columnText = $(tableHeader).getText();
        return Arrays.asList(columnText.split("\\r?\\n"));
    }


    /**
     * Function to add columns
     *
     * @param columns as list of columns to be added
     */
    public void addColumns(List<String> columns) {
        verifyAndSwitchFrame();
        for (String column : columns) {
            commonMethods.waitForElementExplicitly(1000);
            if ($(By.xpath(availableColumnList + "[contains(.,'" + column + "')]")).exists()) {
                $(By.xpath(availableColumnList + "[contains(.,'" + column + "')]")).doubleClick();
            }
        }
    }

    /**
     * Function to remove columns
     *
     * @param columns as list of columns to be added
     */
    public void removeColumns(List<String> columns) {
        verifyAndSwitchFrame();
        for (String column : columns) {
            commonMethods.waitForElementExplicitly(500);
            if ($(By.xpath(selectedColumnsList + "[contains(.,'" + column + "')]")).exists()) {
                $(By.xpath(selectedColumnsList + "[contains(.,'" + column + "')]")).doubleClick();
            }
        }
    }

    /**
     * Function to click on add remove column button
     */
    public void clickAddRemoveColumn() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, addRemoveColumnsBtn, 15);
        $(addRemoveColumnsBtn).click();
    }


    /**
     * Function to click ok button on add remove panel
     */
    public void clickAddColumnOkBtn() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        $(addColumnOkBtn).click();
    }

    /**
     * Function to get options selected under sort by
     *
     * @return option selected
     */
    public String getSortByValue() {
        verifyAndSwitchFrame();
        return $(sortByDropdown).getSelectedText();
    }

    /**
     * Function to get options available under sort by
     *
     * @return list of options
     */
    public List<String> getSortByOptions() {
        verifyAndSwitchFrame();
        List<WebElement> elements = driver.findElements(By.xpath(sortByOption));
        List<String> options = new LinkedList<>();
        for (WebElement e : elements) {
            options.add(e.getText());
        }
        return options;
    }

    /**
     * Function to reset column configured
     */
    public void resetColumn() {
        verifyAndSwitchFrame();
        clickClear();
        clickAddRemoveColumn();
        $(resetColumnBtn).click();
        clickAddColumnOkBtn();
    }

    /**
     * Function to get due date available in result
     *
     * @return list of date
     */
    public boolean verifyOrderedDueDate() throws ParseException {
        verifyAndSwitchFrame();
        LinkedList<String> result = new LinkedList<>();
        List<WebElement> elements = driver.findElements(By.xpath(dateDueResult));
        for (WebElement e : elements) {
            result.add(e.getText());
        }
        return verifyDateOrder(result);
    }

    /**
     * Function to verify Date order
     *
     * @param dates
     * @return
     * @throws ParseException
     */
    public boolean verifyDateOrder(LinkedList<String> dates) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("DD/MM/YYYY");
        for (int i = 0; i <= dates.size() - 1; i++) {
            Date firstDate = dateFormat.parse(dates.get(i));
            for (int j = i + 1; j <= dates.size() - 1; j++) {
                Date d2 = dateFormat.parse(dates.get(j).toString());
                if (firstDate.compareTo(d2) < 0) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Function to get value filled in document no field
     *
     * @return value
     */
    public String getDocumentNoFieldValue() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, documentNoField, 10);
        return $(documentNoField).getValue();
    }

    /**
     * Function to get first workflow number from result
     *
     * @return value
     */
    public String getFirstWorkFlowNumber() {
        verifyAndSwitchFrame();
        String text = $(firstWorkflowRow).getText();
        return StringUtils.substringBetween(text, "Workflow No.: ", "  Name");
    }


    /**
     * Function to get first workflow name from result
     *
     * @return value
     */
    public String getFirstWorkflowName() {
        verifyAndSwitchFrame();
        String text = $(firstWorkflowRow).getText();
        return text.substring(text.lastIndexOf("Name:") + 6);
    }

    /**
     * Function to verify when searched with invalid query
     */
    public void verifyInvalidQuery() {
        verifyAndSwitchFrame();
        Assert.assertTrue($(invalidQueryMessage).getText().toLowerCase().contains("The query entered was not valid.".toLowerCase()));
    }

    /**
     * Function to hide advanced search filter
     */
    public void hideAdvancedSearchFilters() {
        verifyAndSwitchFrame();
        $(contractAdvancedSearchFilter).click();
    }

    /**
     * Function to show advanced search filter
     */
    public void showAdvancedSearchFilters() {
        verifyAndSwitchFrame();
        $(expandAdvancedSearchFilter).click();
    }

    /**
     * Function to verify field displayed
     *
     * @return boolean flag
     */
    public boolean verifyFields(String filter) {
        verifyAndSwitchFrame();
        switch (filter) {
            case "Document No":
                return $(documentNoField).isDisplayed();
            case "Workflow Name":
                return $(workflowNameField).isDisplayed();
            case "Workflow Number":
                return $(workflowNo).isDisplayed();
            case "Step Name":
                return $(stepNameField).isDisplayed();
        }
        return false;
    }

    /**
     * Function to verify options present under show per page option
     *
     * @return boolean flag
     */
    public boolean verifyShowPerPageOption(String option) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, showPerPageDropDown, 10);
        return $(By.xpath("//select[@id='pageSize']//option[contains(.,'" + option + "')]")).exists();
    }

    /**
     * Function to select show per page option
     */
    public void selectShowPerPage(String option) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, showPerPageDropDown, 10);
        $(showPerPageDropDown).selectOptionContainingText(option);
    }

    /**
     * Function to get to from page result
     */
    public String getPageResultCountRange() {
        verifyAndSwitchFrame();
        return $(resultCountContainer).getText();
    }

    /**
     * Function to collapse result
     */
    public void collapseFirstResult() {
        verifyAndSwitchFrame();
        $(collapseFirstResultRows).click();
    }

    /**
     * Function to expand result
     */
    public void expandFirstResult() {
        verifyAndSwitchFrame();
        $(expandFirstResultRows).click();
    }

    /**
     * Function to verify Second row is visible
     *
     * @return boolean flag
     */
    public boolean getVisibilityOfSecondRow() {
        verifyAndSwitchFrame();
        return $(secondRow).isDisplayed();
    }

    /**
     * Function to verify Zero result message
     *
     * @return boolean flag
     */
    public boolean verifyZeroResult() {
        verifyAndSwitchFrame();
        return $(zeroResultMessage).text().contains("No workflows matched your request");
    }


    /**
     * Function to select multiselect field in advanced search field
     *
     * @param field   name
     * @param options list of option
     */
    public void selectMultiSelectFilter(String field, List<String> options) {
        verifyAndSwitchFrame();
        switch (field) {
            case "Workflow Status":
                $(workflowStatusMultiSelect).click();
                for (String option : options) {
                    $(By.xpath("//select[@id='bidi_workFlowStatus_AVAIL']//option[contains(.,'" + option + "')]")).doubleClick();
                }
                $(By.xpath("//button[@id='btnbidiPanel_workFlowStatus_ok']" + multiSelectOkBtn)).click();
                break;
            case "Step Status":
                $(stepStatusMultiSelect).click();
                for (String option : options) {
                    $(By.xpath("//select[@id='bidi_stepStatus_AVAIL']//option[contains(.,'" + option + "')]")).doubleClick();
                }
                $(By.xpath("//button[@id='btnbidiPanel_stepStatus_ok']" + multiSelectOkBtn)).click();
                break;
            case "Step Outcome":
                $(stepOutComeMultiSelect).click();
                for (String option : options) {
                    $(By.xpath("//select[@id='bidi_reviewOutcome_AVAIL']//option[contains(.,'" + option + "')]")).doubleClick();
                }
                $(By.xpath("//button[@id='btnbidiPanel_reviewOutcome_ok']" + multiSelectOkBtn)).click();
        }


    }

    /**
     * Function to get multiselect field options in advanced search field
     *
     * @param field name
     * @return List of options available
     */
    public List<String> getMultiSelectFieldOptions(String field) {
        verifyAndSwitchFrame();
        List<WebElement> elements = new ArrayList<>();
        List<String> optionsAvailable = new ArrayList<>();
        switch (field) {
            case "Workflow Status":
                $(workflowStatusMultiSelect).click();
                elements = driver.findElements(By.xpath(multiSelectWorkflowStatus));
                for (WebElement e : elements) {
                    optionsAvailable.add(e.getText());
                }
                $(By.xpath(multiSelectWorkflowStatusOk + multiSelectOkBtn)).click();
                return optionsAvailable;
            case "Step Status":
                $(stepStatusMultiSelect).click();
                elements = driver.findElements(By.xpath(multiSelectWorkflowStepStatus));
                for (WebElement e : elements) {
                    optionsAvailable.add(e.getText());
                }
                $(By.xpath(multiSelectWorkflowStepStatusOk + multiSelectOkBtn)).click();
                return optionsAvailable;
            case "Step Outcome":
                $(stepOutComeMultiSelect).click();
                elements = driver.findElements(By.xpath(multiSelectWorkflowStepOutcome));
                for (WebElement e : elements) {
                    optionsAvailable.add(e.getText());
                }
                $(By.xpath(multiSelectWorkflowStepOutcomeOk + multiSelectOkBtn)).click();
                return optionsAvailable;
        }
        return optionsAvailable;
    }

    /**
     * Function to get text of table rows
     */
    public String getTableRowText() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, workflowSearchTable, 20);
        return $(workflowSearchTable).text();
    }


    /**
     * Function to verify component of saved search panel
     */
    public void verifySavedSearchComponent() {
        verifyAndSwitchFrame();
        clickSaveSearchAs();
        commonMethods.waitForElement(driver, saveSearchName, 20);
        Assert.assertTrue($(saveSearchName).isDisplayed());
        Assert.assertTrue($(saveSearchDescription).isDisplayed());
        Assert.assertTrue($(saveSearchOkBtn).isDisplayed());
        Assert.assertTrue($(saveSearchCancelBtn).isDisplayed());
        Assert.assertTrue($(saveSearchShareFlag).isDisplayed());
        Assert.assertTrue($(closeSaveSearchPanelX).isDisplayed());
    }

    /**
     * Function to verify share option for saved search is there
     */
    public boolean getShareOptionAvailability() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, saveSearchShareFlag, 10);
        try {
            $(saveSearchShareFlag).setSelected(true);
        } catch (InvalidStateException e) {
            return false;
        }
        return $(saveSearchShareFlag).isSelected();
    }

    /**
     * Function to click save button
     */
    public void clickSaveOk() {
        commonMethods.waitForElementExplicitly(2000);
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, saveSearchName, 20);
        $(saveSearchOkBtn).click();
    }


    /**
     * Function to delete saved search if present
     */
    public void deleteSavedSearchIfPresent(String attribute) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, savedSearchDropDown, 30);
        $(savedSearchDropDown).click();
        Map<String, String> table = dataStore.getTable(attribute);
        if ($(By.xpath("//select[@id='savedsearches']//option[contains(text(),'" + table.get("Name") + "')]")).isDisplayed()) {
            $(manageSavedSearch).click();
            $(savedSearchManageDrpDown).selectOptionContainingText(table.get("Name"));
            $(deleteSavedSearchLink).click();
            acceptAlert();
            commonMethods.waitForElementExplicitly(2000);
            $(closeSaveSearchPanelX).click();
        }
    }


    /**
     * Function to set save search name
     *
     * @param name
     */
    public void setSavedSearchName(String name) {
        verifyAndSwitchFrame();
        $(saveSearchName).clear();
        $(saveSearchName).setValue(name);
    }

    /**
     * Function to get save search name
     *
     * @return field value
     */
    public String getSavedSearchNameFieldValue() {
        verifyAndSwitchFrame();
        return $(saveSearchName).getValue();
    }

    /**
     * Function to click saved search dropdown option
     */
    public void clickSavedSearchDropDown() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, savedSearchDropDown, 20);
        $(savedSearchDropDown).click();
    }

    /**
     * Function to verify saved search is available
     *
     * @param name
     */
    public boolean verifySavedSearch(String name) {
        commonMethods.waitForElementExplicitly(2000);
        verifyAndSwitchFrame();
        return $(By.xpath("//select[@id='savedsearches']//option[contains(text(),'" + name + "')]")).isDisplayed();
    }


    /**
     * Function to edit saved search
     *
     * @param oldSearch to be edited
     * @param newSearch edited to be
     */
    public void editSavedSearch(String oldSearch, String newSearch) {
        verifyAndSwitchFrame();
        Map<String, String> tableOld = dataStore.getTable(oldSearch);
        Map<String, String> tableNew = dataStore.getTable(newSearch);
        commonMethods.waitForElement(driver, savedSearchDropDown, 30);
        $(savedSearchDropDown).click();
        $(manageSavedSearch).click();
        $(savedSearchManageDrpDown).selectOptionContainingText(tableOld.get("Name"));
        saveSearch(newSearch);
    }


    /**
     * Function to verify saved search under user saved search
     *
     * @param name
     */
    public boolean verifyUserSavedSearch(String name) {
        verifyAndSwitchFrame();
        return $(By.xpath("//select[@id='savedsearches']//optgroup[@id='savedsearchesgroup']//option[contains(text(),'" + name + "')]")).isDisplayed();
    }

    /**
     * Function to verify saved search under organisation saved search
     *
     * @param name
     */
    public boolean verifyOrganisationSavedSearch(String name) {
        verifyAndSwitchFrame();
        return $(By.xpath("//select[@id='savedsearches']//optgroup[@id='savedsearchessharedgroup']//option[contains(text(),'" + name + "')]")).isDisplayed();
    }

    /**
     * Function to select saved search from dropdown
     *
     * @param name
     */
    public void selectSavedSearch(String name) {
        verifyAndSwitchFrame();
        $(By.xpath("//select[@id='savedsearches']//option[contains(text(),'" + name + "')]")).click();
    }

    /**
     * Function to get super search field value
     */
    public String getSuperSearchValue() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, superSearch, 10);
        return $(superSearch).getValue();
    }

    /**
     * Function to get publisher of saved search
     *
     * @param name of saved search
     * @return publisher name
     */
    public String getPublisherName(String name) {
        verifyAndSwitchFrame();
        $(savedSearchDropDown).click();
        $(manageSavedSearch).click();
        $(savedSearchManageDrpDown).selectOptionContainingText(name);
        commonMethods.waitForElementExplicitly(2000);
        return $(publisherName).text();
    }

    /**
     * Function to verify saved search under Standard saved search
     *
     * @param name
     */
    public boolean verifyStandardSearch(String name) {
        verifyAndSwitchFrame();
        return $(By.xpath("//select[@id='savedsearches']//optgroup[@id='savedsearchescommongroup']//option[contains(text(),'" + name + "')]")).isDisplayed();
    }

    /**
     * Function to get value assigned to
     *
     * @return assigned to user
     */
    public String getAssignedTo() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, assignedTo, 10);
        return $(assignedTo).text();
    }

    /**
     * Function to get value of initiator
     *
     * @return initiator user
     */
    public String getInitiator() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, initiator, 10);
        return $(initiator).text();
    }

    /**
     * Function to get available column configured
     *
     * @return list of columns
     */
    public List<String> getAvailableColumn() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, addRemoveColumnsBtn);
        List<String> columnList = new ArrayList<>();
        List<WebElement> elements = driver.findElements(By.xpath(availableColumnList));
        for (WebElement e : elements) {
            columnList.add(e.getText());
        }
        return columnList;
    }

    /**
     * Function to get selected column on header
     *
     * @return list of columns
     */
    public List<String> getColumnsOnTable() {
        verifyAndSwitchFrame();
        List<String> columnList = new ArrayList<>();
        List<WebElement> elements = driver.findElements(By.xpath(tableHeaders));
        for (WebElement e : elements) {
            columnList.add(e.getText());
        }
        return columnList;
    }

    /**
     * Function to verify the results on each groupBy
     *
     * @param showOptionA,showOptionB
     * @param hideOptionA,hideOptionB
     */
    public void verifyGroupBy(By showOptionA, By showOptionB, By hideOptionA, By hideOptionB) {
        commonMethods.waitForElement(driver, dataRows, 10);
        Assert.assertTrue($(showOptionA).isDisplayed());
        Assert.assertTrue($(showOptionB).isDisplayed());
        $(hideOptionA).shouldBe(Condition.hidden);
        $(hideOptionB).shouldBe(Condition.hidden);
    }

    /**
     * Function to verify the default search message
     */
    public void verifySearchDefaultMessage() {
        commonMethods.waitForElementExplicitly(3000);
        clickClear();
        commonMethods.waitForElement(driver, searchDefaultMessage, 10);
        Assert.assertTrue($(searchDefaultMessage).isDisplayed());
    }

    /**
     * Function to select the filter
     */
    public void setFilter(String type, String filter) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(1000);
        commonMethods.waitForElement(driver, stepOutComeMultiSelect);
        commonMethods.scrollPageUp(driver);
        $(By.xpath("//label[text()='" + type + "']//..//following-sibling::td//div")).click();
        $(By.xpath("//label[text()='" + type + "']//..//following-sibling::td//div//select//option[text()='" + filter + "']")).click();
        $(By.xpath("//label[text()='" + type + "']//..//following-sibling::td//div" + addToFilter)).click();
        $(By.xpath("//label[text()='" + type + "']//..//following-sibling::td//div" + filterOKBtn)).click();

    }

    /**
     * Function to validate the results against the Filter Name
     *
     * @param columnIndex
     * @param filterName
     */

    public void validateResultOnMultiSelect(int columnIndex, String filterName) {
        boolean filterFlag = false;
        commonMethods.waitForElement(driver, dataRows);
        for (int rowIterator = 1; rowIterator <= $$(dataRows).size(); rowIterator++) {
            Assert.assertEquals($(By.xpath("(//tr[@class='dataRow'])[" + rowIterator + "]//td[" + columnIndex + "]")).getText(), filterName);
            filterFlag = true;
        }
        Assert.assertEquals(true, filterFlag);
    }

    /**
     * Function to enter text using type
     *
     * @param instance user
     */

    public void enterUserQuery(String instance, String user) {
        $(By.xpath("(//label[text()='" + instance + "']//..//following-sibling::td//input)[1]")).click();
        $(By.xpath("(//label[text()='" + instance + "']//..//following-sibling::td//input)[1]")).sendKeys(user);
        if (instance.equals("Initiator"))
            $(initiatorSearchIcon).click();
        else
            $(assignedToSearchIcon).click();
    }

    /**
     * Function to search using the user looks ups
     *
     * @param instance user
     */
    public void verifySearchResultsOnUser(String instance, String user) {
        verifyAndSwitchFrame();
        boolean userStatus = false;
        $(By.xpath("//tr[@class='dataHeaders']//*[contains(text(),'" + instance + "')]")).shouldBe(Condition.appear);
        commonMethods.waitForElementExplicitly(2000);
        $(searchResultsContainer).exists();
        for (int iterator = 1; iterator <= $$(dataHeaders).size(); iterator++) {
            if ($(By.xpath("(//tr[@class='dataHeaders']//th)[" + iterator + "]")).getText().contains(instance)) {
                for (int rowIterator = 2; rowIterator <= $$(dataRows).size(); rowIterator++) {
                    Assert.assertTrue($(By.xpath("(//tr[@class='dataRow'])[" + rowIterator + "]//td[" + iterator + "]")).getText().contains(commonMethods.getUserData(user, "name")));
                    userStatus = true;
                }
                break;
            }
        }
        Assert.assertEquals(true, userStatus);
    }

    /**
     * Function to search Templates available in the Organization
     */
    public ArrayList<String> searchOnTemplateWindow(String user) {
        clickSearch();
        commonMethods.waitForElement(driver, templateResults, 40);
        commonMethods.waitForElement(driver, templateResults);
        ArrayList<String> templatesPresent = new ArrayList<>();
        for (int iterator = 1; iterator <= $$(templateNameOnResults).size(); iterator++) {
            templatesPresent.add($(By.xpath("(//table[@id='resultsTable']//tr[@class='dataRow']//td//a[@title='View template settings'])[" + iterator + "]")).getText());
            Assert.assertTrue($(By.xpath("(//tr[@class='dataRow'])[" + iterator + "]//td[4]")).getText().contains(commonMethods.getUserData(user, "organisation")));
        }
        return templatesPresent;
    }

    /**
     * Function to pick a template
     *
     * @param templateName
     */

    public void chooseTemplate(String templateName) {
        commonMethods.waitForElement(driver, templateDropDown, 60);
        $(templateDropDown).selectOptionContainingText(templateName);
    }

    /**
     * Function to search workflows based on the Templates
     *
     * @param templateName
     */
    public void filterUsingTemplates(ArrayList<String> templateName) {
        commonMethods.waitForElement(driver, templateDropDown, 90);
        Select templates = new Select($(templateDropDown));
        List<WebElement> allOptions = templates.getOptions();
        for (int iterator = 1; iterator < allOptions.size(); iterator++) {
            $(templateDropDown).selectOptionContainingText(allOptions.get(iterator).getText());
            commonMethods.waitForElementExplicitly(3000);
            clickSearch();
            commonMethods.waitForElement(driver, rowDataGroup);
            commonMethods.waitForElementExplicitly(2000);
            for (int rowIterator = 1; rowIterator <= $$(rowDataGroup).size(); rowIterator++) {
                Assert.assertTrue($(By.xpath("(//tr[@class='dataGroup'])[" + rowIterator + "]//td//a[contains(text(),'" + allOptions.get(iterator).getText() + "')]")).isDisplayed());
            }
        }
    }

    /**
     * Function to review the document and mark the status
     *
     * @param docNum,status
     */

    public void reviewDocumentToStatus(String docNum, String status) {
        reviewDocuments();
        commonMethods.waitForElement(driver, submitSelectedDocumentsBtn);
        $(By.xpath("//a[contains(text(),'" + docNum + "')]//..//..//input[@type='checkbox']")).click();
        $(By.xpath("//a[contains(text(),'" + docNum + "')]//..//..//select")).selectOptionContainingText(status);
        $(By.xpath("//a[contains(text(),'" + docNum + "')]//..//..//div[starts-with(@id,'divDisplay_comments')]")).click();
        commonMethods.waitForElementExplicitly(1000);
        $(By.xpath("//a[contains(text(),'" + docNum + "')]//..//..//div[starts-with(@id,'divCommentsTxt_comments')]//textarea")).sendKeys("Test Comments");
        $(submitSelectedDocumentsBtn).click();
        commonMethods.waitForElement(driver, summaryPanel);
        $(summaryPanelOKBtn).scrollTo();
        commonMethods.waitForElementExplicitly(2000);
        $(summaryPanelOKBtn).click();
        commonMethods.waitForElement(driver, successMsgOnReview);
        $(submitSelectedDocumentsBtn).scrollTo();
        Assert.assertTrue($(successMsgOnReview).isDisplayed());
    }

    /**
     * Function to select the document in step with document number
     *
     * @param docNum
     */
    public void selectDocument(String docNum) {
        commonMethods.waitForElement(driver, By.xpath("//td//div[contains(text(),'" + docNum + "')]"), 30);
        $(By.xpath("//td//div[contains(text(),'" + docNum + "')]//..//..//input[@type='checkbox']")).setSelected(true);
    }

    /**
     * Function to Get the Row No on the results based on the Document name
     *
     * @param docNum
     * @return
     */
    public void verifyStepStatus(String docNum, String status, String columnName) {
        boolean verifyStatus = false;
        if (columnName.equalsIgnoreCase("Assigned To")) {
            jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
            userMap = jsonMapOfMap.get(status);
            status = "Professor" + " " + userMap.get("full_name").toString() + " - " + userMap.get("org_name").toString();
        }
        commonMethods.waitForElement(driver, By.xpath("//td//div[contains(text(),'" + docNum + "')]"), 30);
        int stepStatus = getColumnIndex("dataHeaders", columnName);
        verifyAndSwitchFrame();
        for (int rowIterator = 1; rowIterator <= $$(dataRows).size(); rowIterator++) {
            if ($(By.xpath("(//tr[@class='dataRow'])[" + rowIterator + "]//td//div[@class='searchResults-cellWrap']")).getText().contains(docNum)) {
                Assert.assertTrue($(By.xpath("(//tr[@class='dataRow'])[" + rowIterator + "]//td[" + stepStatus + "]")).getText().contains(status));
                verifyStatus = true;
                break;
            }
        }
        Assert.assertEquals(true, verifyStatus);
    }

    /**
     * Function to verify the workflow sort based on status
     *
     * @param sortOrder
     * @return
     */

    public void verifySortOnStatus(List<String> sortOrder) {
        boolean sortFlag = false;
        commonMethods.waitForElementExplicitly(2000);
        Assert.assertTrue($(workflowStatusHeader).isDisplayed());
        $(workflowStatusHeader).click();
        commonMethods.waitForElement(driver, closeBtnOnSortTip);
        $(closeBtnOnSortTip).click();
        int wfStatusIndex = getColumnIndex("dataHeaders", "Workflow Status");
        commonMethods.waitForElement(driver, dataRows);
        for (int rowIterator = 1; rowIterator <= $$(dataRows).size(); rowIterator++) {
            Assert.assertEquals($(By.xpath("(//tr[@class='dataRow'])[" + rowIterator + "]//td[" + wfStatusIndex + "]")).getText(), sortOrder.get(rowIterator - 1));
            sortFlag = true;
        }
        Assert.assertEquals(true, sortFlag);
    }

    /**
     * Function to sort based on the step status
     *
     * @param sortOrder
     * @return
     */
    public void verifySortOnStepStatus(List<String> sortOrder, String columnName) {
        commonMethods.waitForElementExplicitly(2000);
        Assert.assertTrue($(stepStatusHeader).isDisplayed());
        $(stepStatusHeader).click();
        commonMethods.waitForElement(driver, closeBtnOnSortTip);
        $(closeBtnOnSortTip).click();
        int wfStatusIndex = getColumnIndex("dataHeaders", columnName);
        commonMethods.waitForElement(driver, dataRows);
        ArrayList<String> stepStatus = new ArrayList<>();
        stepStatus.add(sortOrder.get(0));
        for (int rowIterator = 1; rowIterator <= $$(dataRows).size(); rowIterator++) {
            String stepStatusActual = $(By.xpath("(//tr[@class='dataRow'])[" + rowIterator + "]//td[" + wfStatusIndex + "]")).getText();
            boolean repeatFlag = stepStatus.contains(stepStatusActual);
            if (repeatFlag == false)
                stepStatus.add(stepStatusActual);
        }
        for (int iterator = 0; iterator < sortOrder.size(); iterator++)
            Assert.assertEquals(sortOrder.get(iterator), stepStatus.get(iterator));

    }

    /**
     * Function to validate the user search on the directory
     *
     * @param user,type,instance
     * @return
     */

    public void validateUserSearch(String user, String instance, String type) {
        commonMethods.waitForElement(driver, initiatorInput);
        switch (instance) {
            case "Initiator":
                if (type.equals("valid"))
                    Assert.assertEquals($(initiatorContainer).getText(), commonMethods.getUserName(user) + " - " + commonMethods.getUserData(user, "organisation"));
                else
                    Assert.assertEquals($(initiatorErrorMsg).getText(), "No match found for " + commonMethods.getUserName(user) + ". Try a less specific query or remove");
                break;
            case "Assigned To":
                if (type.equals("valid"))
                    Assert.assertEquals($(assigneeContainer).getText(), commonMethods.getUserName(user) + " - " + commonMethods.getUserData(user, "organisation"));
                else
                    Assert.assertEquals($(assigneeErrorMsg).getText(), "No match found for " + commonMethods.getUserName(user) + ". Try a less specific query or remove");
                break;
        }
    }

    /**
     * Function to input user to replace search box
     *
     * @param user
     */
    public void replaceUser(String user) {
        commonMethods.waitForElement(driver, replaceUserField, 40);
        $(replaceUserField).clear();
        $(replaceUserField).sendKeys(user + Keys.ENTER);
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Function to input user to with search box
     *
     * @param user
     */
    public void enterWithUser(String user) {
        commonMethods.waitForElement(driver, inputWithUser, 40);
        $(inputWithUser).clear();
        $(inputWithUser).sendKeys(user + Keys.ENTER);
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Function to validate replace search box user
     *
     * @param userMap
     * @param type
     */
    public void validateReplaceUserSearch(Map<String, Object> userMap, String type) {
        commonMethods.waitForElement(driver, replaceUserField, 40);
        replaceUser(userMap.get("full_name").toString());
        if (type.equals("valid")) {
            Assert.assertEquals($(replaceContainer).getText(), userMap.get("full_name").toString() + " - " + userMap.get("org_name").toString());
            $(removeIcon).click();
        } else {
            Assert.assertEquals($(replaceErrorMsg).getText(), "No match found for " + userMap.get("full_name").toString() + ". Try a less specific query or remove");
        }

    }

    /**
     * Function to validate replace search box user
     *
     * @param userMap
     * @param type
     */
    public void validateWithUserSearch(Map<String, Object> userMap, String type) {
        commonMethods.waitForElement(driver, replaceUserField, 40);
        enterWithUser(userMap.get("full_name").toString());
        if (type.equals("valid")) {
            Assert.assertEquals($(withContainer).getText(), userMap.get("full_name").toString() + " - " + userMap.get("org_name").toString());
            $(removeIcon).click();
        } else {
            Assert.assertEquals($(withErrorMsg).getText(), "No match found for " + userMap.get("full_name").toString() + ". Try a less specific query or remove");
        }
    }

    /**
     * Function to verify mail group
     *
     * @param userMap
     */
    public boolean verifyMailGroup(Map<String, Object> userMap) {
        commonMethods.waitForElement(driver, replaceUserField, 40);
        enterWithUser(userMap.get("full_name").toString());
        commonMethods.waitForElement(driver, mailGrpContainer, 40);
        return $(mailGrpContainer).getText().contains("Several matches were found for " + userMap.get("full_name").toString());
    }


    /**
     * Function to validate the group name in the directory on WorkFlow Status
     *
     * @param mailGroupName,type
     * @return
     */
    public void validateGroupName(String mailGroupName, String type) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        if (type.equals("Initiator"))
            Assert.assertTrue($(By.xpath("//*[@id='initiator_list']//li[@class='lookup-assignee lookup-group']//a[contains(text(),'" + mailGroupName + "')]")).isDisplayed());
        else
            Assert.assertTrue($(By.xpath("//*[@id='assignee_list']//li[@class='lookup-assignee lookup-group']//a[contains(text(),'" + mailGroupName + "')]")).isDisplayed());
    }

    /**
     * Function to verify workflow Note
     *
     * @return
     */
    public boolean verifyWorkflowNote() {
        verifyAndSwitchFrame();
        return $(workflowNote).isDisplayed();
    }

    /**
     * Function to select template
     *
     * @param template
     */
    public void selectTemplate(String template) {
        commonMethods.waitForElementExplicitly(1500);
        String workflow = commonMethods.getWFTemplateDetails(template, "template_name");
        By xpath = By.xpath("//td//a[text()='" + workflow + "']//..//..//..//..//following-sibling::tbody//td[1]//input");
        $(xpath).setSelected(true);
    }

    /**
     * Function to click on search button
     */
    public void clickSearchBtn() {
        $(searchBtn).click();
    }

    /**
     * Function to select first document
     */
    public void selectFirstDoc() {
        $(selectRecord).click();
    }

    /**
     * Function to select initiator tools option
     *
     * @param option
     */
    public void selectInitiatorToolsOption(String option) {
        commonMethods.waitForElement(driver, initiatorToolsBtn, 40);
        commonMethods.getElementInViewAndUp(initiatorToolsBtn);
        $(initiatorToolsBtn).click();
        $(By.xpath("//a[text()='" + option + "']")).click();
    }

    /**
     * Function to skip step
     *
     * @param reason
     */
    public void skipStep(String reason) {
        commonMethods.waitForElement(driver, reasonTxtArea, 40);
        $(reasonTxtArea).sendKeys(reason);
        $(okBtn).click();
    }

    /**
     * Function to reassign user
     *
     * @return
     */
    public boolean validateReassignMsg() {
        commonMethods.waitForElement(driver, reassignMsg, 40);
        return $(reassignMsg).isDisplayed();
    }


    /**
     * Function to replace user
     *
     * @param replaceUser
     * @param withUser
     */
    public void replaceUser(String replaceUser, String withUser) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userFilePath);
        userMap = jsonMapOfMap.get(replaceUser);
        String rUser = userMap.get("full_name").toString();
        userMap = jsonMapOfMap.get(withUser);
        String wUser = userMap.get("full_name").toString();
        commonMethods.waitForElementExplicitly(500);
        replaceUser(rUser);
        commonMethods.waitForElementExplicitly(2000);
        enterWithUser(wUser);
        commonMethods.waitForElementExplicitly(2000);
        $(okBtn).click();
    }


    /**
     * Function to verify replace alert
     */
    public void verifyReplaceAlert() {
        $(replaceUserField).clear();
        $(okBtn).click();
        verifyAlert("Please specify original participant before continuing");
    }

    /**
     * Function to verify skip success msg
     *
     * @return
     */
    public boolean verifySkipSuccessMsg() {
        commonMethods.waitForElement(driver, skipStepSuccessMsg, 40);
        return $(skipStepSuccessMsg).isDisplayed();
    }

    /**
     * function to verify terminated success msg
     *
     * @return
     */
    public boolean verifyTerminateSuccessMsg() {
        commonMethods.waitForElement(driver, terminateSuccessMsg, 40);
        return $(terminateSuccessMsg).isDisplayed();
    }

    /**
     * function to verify markup success msg
     *
     * @return
     */
    public boolean verifyMarkupSuccessMsg() {
        commonMethods.waitForElement(driver, markupSuccessMsg, 40);
        return $(markupSuccessMsg).isDisplayed();
    }

    /**
     * Function to verify reassign success msg
     *
     * @return
     */
    public boolean verifyReassignSuccessMsg() {
        commonMethods.waitForElement(driver, reassignSuccessMsg, 40);
        return $(reassignSuccessMsg).isDisplayed();
    }

    /**
     * click on close button
     */
    public void clickCloseBtn() {
        commonMethods.waitForElement(driver, closeBtn, 40);
        $(closeBtn).click();

    }

    /**
     * Function to verify skip current window
     *
     * @return
     */
    public boolean verifySkipCurrentWindow() {
        commonMethods.waitForElement(driver, reasonTxtArea, 40);
        return $(reasonTxtArea).isDisplayed();
    }

    /**
     * click on cancel button
     */
    public void clickCancelSkipBtn() {
        commonMethods.waitForElement(driver, skipCancelBtn, 40);
        $(skipCancelBtn).click();
    }

    /**
     * Function to select doc chk box
     *
     * @param status
     * @param docName
     */
    public void selectDocChkBox(String status, String docName) {
        commonMethods.waitForElement(driver, searchBtn, 40);
        commonMethods.waitForElementExplicitly(1000);
        By docChkBox = By.xpath("//td[text()='" + status + "']//..//div[text()='" + docName + "']//../..//input");
        commonMethods.waitForElement(driver, docChkBox, 80);
        $(docChkBox).click();
    }

    /**
     * Function to select multiple doc chk boxes
     *
     * @param numOfDocs
     */
    public void selectMultipleDocs(int numOfDocs) {
        commonMethods.waitForElement(driver, docChkBoxes, 40);
        List<WebElement> docs = driver.findElements(docChkBoxes);
        for (int i = 0; i <= numOfDocs - 1; i++) {
            docs.get(i).click();
        }
    }

    /**
     * Function to search doc
     *
     * @param docName
     */
    public void searchDocNumber(String docName) {
        $(documentNoField).clear();
        $(documentNoField).sendKeys(docName);

    }

    /**
     * Function to verify markup window options
     */
    public void verifyMarkupOptions() {
        commonMethods.waitForElement(driver, replacementFileChkBox, 50);
        Assert.assertTrue($(replacementFileChkBox).isDisplayed());
        Assert.assertTrue($(markupChkBox).isDisplayed());
        Assert.assertTrue($(noteTxt).isDisplayed());
        Assert.assertTrue($(markupOptionsTxt).isDisplayed());
        Assert.assertTrue($(okBtn).isDisplayed());
        Assert.assertTrue($(skipCancelBtn).isDisplayed());
        $(skipCancelBtn).click();
    }

    /**
     * Function to verify reassign window options
     */
    public void verifyReassignOptions() {
        commonMethods.waitForElement(driver, replaceUserField, 40);
        Assert.assertTrue($(replaceUserField).isDisplayed());
        Assert.assertTrue($(inputWithUser).isDisplayed());
        Assert.assertTrue($(okBtn).isDisplayed());
        Assert.assertTrue($(skipCancelBtn).isDisplayed());
    }

    /**
     * Function to verify invalid symbol
     *
     * @param docName
     * @return
     */
    public boolean verifyInvalidSymbol(String docName) {
        commonMethods.waitForElement(driver, okBtn, 40);
        By symbol = By.xpath("//td[text()='" + docName + "']//..//img");
        getElementInView(symbol);
        return $(symbol).isDisplayed();
    }

    /**
     * Function to get first doc name
     *
     * @return
     */
    public String getFirstDocName() {
        commonMethods.waitForElement(driver, selectRecord, 40);
        return $(firstDocName).getText();
    }

    /**
     * Function to verify Markup doc
     *
     * @param docName
     * @return
     */
    public boolean verifyMarkupDoc(String docName) {
        commonMethods.waitForElement(driver, okBtn, 40);
        return $(By.xpath("//td[text()='" + docName + "']")).isDisplayed();

    }

    /**
     * Function to verify Attach file panel
     *
     * @return
     */
    public boolean verifyAttachFilePanel() {
        commonMethods.waitForElement(driver, fileAttachIcon, 40);
        $(fileAttachIcon).click();
        Assert.assertTrue($(attachFilePanel).isDisplayed());
        Assert.assertTrue($(localAttach).isDisplayed());
        Assert.assertTrue($(temporaryFilesAttach).isDisplayed());
        $(attachPanelCancelBtn).click();
        commonMethods.waitForElement(driver, markupEyeIcon, 40);
        return $(markupEyeIcon).isDisplayed();
    }

    /**
     * Function to verify Pin icon
     *
     * @return
     */
    public boolean verifyPinIcon() {
        return $(fileAttachIcon).isDisplayed();
    }

    /**
     * Function to verify fields in doc review mode page
     *
     * @param docName
     */
    public void verifyDocumentReviewPageFields(String docName) {
        commonMethods.waitForElementExplicitly(2000);
        By docTxt = By.xpath("//span[text()='" + docName + "']");
        commonMethods.waitForElement(driver, docTxt, 40);
        //$(docTxt).isDisplayed();
        commonMethods.waitForElement(driver, linkDownloadOriginalFile, 40);
        Assert.assertTrue($(fileFormatTxt).isDisplayed());
        Assert.assertTrue($(linkDownloadOriginalFile).isDisplayed());
        Assert.assertTrue($(moreInfoTxt).isDisplayed());
        Assert.assertTrue($(selectReview).isDisplayed());
        Assert.assertTrue($(submitReviewBtn).isDisplayed());
        Assert.assertTrue($(commentTxtArea).isDisplayed());
        Assert.assertTrue($(backBtn).isDisplayed());
    }

    /**
     * Function to verify doc review page
     *
     * @return
     */
    public boolean verifyDocReviewPage(String docNum) {
        commonMethods.waitForElement(driver, markupEyeIcon, 40);
        $(markupEyeIcon).click();
        commonMethods.waitForElement(driver, By.xpath("//span[text()='" + docNum + "']"), 40);
        return $(By.xpath("//span[text()='" + docNum + "']")).isDisplayed();
    }


    /**
     * Function to click on back button
     */
    public void clickBackBtn() {
        commonMethods.waitForElement(driver, backBtn, 40);
        $(backBtn).click();
    }

    /**
     * Function to click on doc number
     *
     * @param docName
     */
    public void clickDocNumber(String docName) {
        commonMethods.waitForElement(driver, workflowNote, 40);
        $(By.xpath("//tbody[@id='wfreviewResults']//a[text()='" + docName + "']")).click();
    }

    /**
     * Function to verify wf search page options
     */
    public boolean verifySearchPage() {
        commonMethods.waitForElement(driver, searchBtn, 40);
        Assert.assertTrue($(searchBtn).isDisplayed());
        Assert.assertTrue($(savedSearchDropDown).isDisplayed());
        Assert.assertTrue($(saveSearchAsBtn).isDisplayed());
        Assert.assertTrue($(addRemoveColumnsBtn).isDisplayed());
        Assert.assertTrue($(clearBtn).isDisplayed());
        $(searchBtn).click();
        commonMethods.waitForElement(driver, delegateBtn, 40);
        return $(initiatorToolsBtn).isDisplayed();
    }

    /**
     * Function to validate multiple users with replace
     *
     * @param userMap
     * @param user
     */
    public void validateMultipleReplaceUsers(Map<String, Object> userMap, String user) {
        replaceUser(user);
        commonMethods.waitForElement(driver, replaceContainer, 40);
        Assert.assertEquals($(replaceContainer).getText(), userMap.get("full_name").toString() + " - " + userMap.get("org_name").toString());
    }

    /**
     * Function to validate multiple users with replace with
     *
     * @param userOne
     * @param userTwo
     */
    public boolean validateMultipleWithUsers(String userOne, String userTwo) {
        enterWithUser(userOne + "," + userTwo);
        commonMethods.waitForElement(driver, withContainer, 40);
        List<WebElement> users = driver.findElements((withContainer));
        for (int i = 0; i <= users.size() - 1; i++) {
            if (!(users.get(i).getText().contains(userOne) || users.get(i).getText().contains(userTwo))) {
                return false;
            }

        }
        return true;
    }

    /**
     * Function to verify alert msg
     *
     * @param msg
     */
    public void verifyMarkupAlertMsg(String msg) {
        $(okBtn).click();
        Assert.assertTrue(verifyAlert(msg));
    }

    /**
     * Function to click on submit doc
     */
    public void clickSubmitDocs() {
        $(submitSelectedDocumentsBtn).click();
    }

    /**
     * Click sun WF image
     */
    public void clickSubWorkflowLock() {
        commonMethods.waitForElement(driver, imgSubWorkflowLck, 40);
        $(imgSubWorkflowLck).click();
    }

    /**
     * Function to verify sub workflow icon
     *
     * @return
     */
    public boolean verifySubWorkflowIcon() {
        commonMethods.waitForElementExplicitly(2000);
        return $(imgSubWorkflowLck).isDisplayed();
    }

    /**
     * Function to verify sub workflow completed icon
     *
     * @return
     */
    public boolean verifySubWorkflowCompletedIcon() {
        commonMethods.waitForElementExplicitly(2000);
        return $(imgsubWorkflowCompltd).isDisplayed();
    }

    /**
     * Click on delegate
     */
    public void clickDelegate() {
        commonMethods.waitForElement(driver, delegateBtn, 40);
        $(delegateBtn).click();
    }

    /**
     * Function to verify delegate msg
     *
     * @return
     */
    public boolean verifyDelegateMsg() {
        commonMethods.waitForElement(driver, delegateMsg, 40);
        return $(delegateMsg).isDisplayed();
    }

    /**
     * Attach file from temprory files
     */
    public void attachFile(String fileName) {
        commonMethods.waitForElement(driver, fileAttachIcon, 40);
        $(fileAttachIcon).click();
        $(temporaryFilesAttach).click();
    }

    /**
     * Function to verify number of workflows
     *
     * @param num
     * @return
     */
    public boolean validateWorkflows(int num, String name) {
        commonMethods.waitForElement(driver, workflowNum, 40);
        jsonMapOfMap = dataSetup.loadJsonDataToMap(workflowFilePath);
        mailMap = jsonMapOfMap.get(name);
        Assert.assertTrue(driver.findElements((workflowNum)).size() == num);
        return driver.findElement(By.xpath("//a[text()='" + mailMap.get("template_name").toString() + "']")).isDisplayed();
    }

    /**
     * Function to verify step status
     *
     * @param row
     * @param status
     * @param columnName
     */
    public void verifyWfStatus(int row, String status, String columnName) {
        commonMethods.waitForElementExplicitly(2000);
        int stepStatus = getColumnIndex("dataHeaders", columnName);
        Assert.assertTrue($(By.xpath("(//tr[@class='dataRow'])[" + row + "]//td[" + stepStatus + "]")).getText().contains(status));
    }

    /**
     * Function to verify supplementary data files
     *
     * @param fileName
     * @param comments
     * @return
     */
    public boolean verifyFileData(String fileName, String comments, String value) {
        commonMethods.waitForElementExplicitly(2000);
        if ($(By.xpath("//table[@id='supplementaryFilesResultsTable']//td[contains(text(),'" + fileName + "')]")).isDisplayed() && ($(By.xpath("//table[@id='supplementaryFilesResultsTable']//td[contains(text(),'" + comments + "')]")).isDisplayed())) {
            return true;
        }
        return false;

    }

    /**
     * Close supplement window
     */
    public void clickSupplementWindow() {
        if ($(supplementCloseBtn).isDisplayed()) {
            commonMethods.waitForElement(driver, supplementCloseBtn, 40);
            $(supplementCloseBtn).click();
        }
    }

    /**
     * click supplement tab
     */
    public void clickSupplementReviewTab() {
        commonMethods.waitForElement(driver, supplementReviewTab, 40);
        $(supplementReviewTab).click();
    }

    /**
     * click supplement btn
     */
    public void clickSupplementBtn() {
        commonMethods.waitForElement(driver, supplementBtn, 40);
        $(supplementBtn).click();
    }

    /**
     * Method to verify if any records are found in the search workflow page
     *
     * @return
     */
    public boolean recordsFound() {
        return $(noRecords).isDisplayed();
    }

    /**
     * Attach file from local files
     */
    public void attachLocalFile(String fileLocation, String fileName) {
        commonMethods.waitForElement(driver, fileAttachIcon, 40);
        $(fileAttachIcon).click();
        $(localAttach).click();
        commonMethods.waitForElement(driver, txtBoxFilePath, 30);
        $(txtBoxFilePath).sendKeys(new File(fileLocation + "/" + fileName).getAbsolutePath());
        $(okBtn).click();
        commonMethods.waitForElementExplicitly(3000);
    }

    /**
     * Method to get report types
     */
    public List<String> getReportTypes() {
        verifyAndSwitchFrame();
        List<String> reportTypes = new ArrayList<>();
        commonMethods.waitForElement(driver, btnReports, 30);
        clickOnReports();
        List<WebElement> elements = new ArrayList<>($$(lstReportTypes));
        for (WebElement element : elements) {
            if (element.getText().contains("Export to Excel"))
                reportTypes.add("Export to Excel");
            else reportTypes.add(element.getText());
        }
        return reportTypes;
    }

    /**
     * Method to click on reports button
     */
    public void clickOnReports() {
        commonMethods.waitForElement(driver, btnReports, 30);
        $(btnReports).click();
    }

    /**
     * Method to click on report type
     */
    public void selectReportType(String reportType) {
        clickOnReports();
        $(By.xpath("//ul[@id='REPORTS_MENU']/li//a[contains(text(),'" + reportType + "')]")).click();
    }

    /**
     * Method to verify excel to export message banner
     */
    public boolean verifyExportToExcelBanner() {
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.scrollToTop(driver);
        return $(bannerExportExcel).isDisplayed();
    }

    /**
     * Method to verify Select Template popup window
     */
    public void verifyTemplatePopup() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, sltTemplate, 30);
        Assert.assertTrue($(lblSelectTemplate).isDisplayed());
        Assert.assertTrue($(infoSelectATemplate).isDisplayed());
        Assert.assertTrue($(sltTemplate).isDisplayed());
        Assert.assertTrue($(btnOk).isDisplayed());
        Assert.assertTrue($(btnCancel).isDisplayed());
    }

    /**
     * Method to verify Select Template popup window
     */
    public void selectTemplatePopup(String template) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, sltTemplate, 30);
        $(sltTemplate).selectOptionContainingText(template);
        $(btnOk).click();
    }

    /**
     * Method to verify Select Template popup window
     */
    public void clickTemporaryFiles() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, lnkTemporaryFiles, 30);
        commonMethods.scrollToTop(driver);
        $(lnkTemporaryFiles).click();
    }

    /**
     * Function to verify WF results WFNo and name
     */
    public String verifyWFResults(String wfNum) {
        verifyAndSwitchFrame();
        getElementInView(btnReports);
        return $(By.xpath("//table[@id='resultTable']/tbody[@id='" + wfNum + "']//td[2]")).getAttribute("innerText");
    }

    /**
     * Function to verify WF Tasks results
     */
    public String verifyWFTasksResults(int docNo, String wfId, String colName) {
        List<String> colNames = new ArrayList<>();
        List<WebElement> elements = new ArrayList<>($$(tblResultsHdrs));
        for (WebElement element : elements)
            colNames.add(element.getText());
        int colIndex = colNames.indexOf(colName);
        return $(By.xpath("//table[@id='resultTable']/tbody[@id='wfTasks_" + wfId + "']/tr[" + docNo + "]/td[" + (colIndex + 1) + "]")).getAttribute("innerText");
    }

    /**
     * Function to get document row number
     */
    public int getWorkflowDocRow(String WfId, String docName) {
        By xpath = By.xpath("//table[@id='resultTable']/tbody[@id='wfTasks_" + WfId + "']/tr/td[2]/div");
        return commonMethods.getDocumentRow(xpath, docName);
    }

    /**
     * Function to verify No results found message in workflow screen
     */
    public boolean verifyNoResults() {
        $(loadingIcon).should(disappear);
        commonMethods.waitForElementExplicitly(2000);
        return $(txtNoResults).isDisplayed();
    }

    /**
     * Function to search for Replace user in delegate window
     */
    public void searchReplaceUser(String userName) {
        commonMethods.waitForElement(driver, txtBoxReplace, 30);
        commonMethods.enterTextValue(txtBoxReplace, userName);
        $(txtBoxReplace).sendKeys(Keys.ENTER);
        verifyDelegateUser(userName);
    }

    /**
     * Function to search for Replace user in delegate window
     */
    public void searchWithUser(String userName) {
        commonMethods.waitForElement(driver, txtBoxWith, 30);
        commonMethods.enterTextValue(txtBoxWith, userName);
        $(txtBoxWith).sendKeys(Keys.ENTER);
        verifyDelegateUser(userName);
    }

    /**
     * Function to verify delegate popup window
     */
    public void verifyDelegatepopup() {
        commonMethods.waitForElement(driver, documentReviewListModePage.hdrDelegateTask, 30);
        Assert.assertTrue($(documentReviewListModePage.hdrDelegateTask).isDisplayed());
        Assert.assertTrue($(documentReviewListModePage.lblDelegateTask).isDisplayed());
        Assert.assertTrue($(txtBoxWith).isDisplayed());
        Assert.assertTrue($(txtBoxReplace).isDisplayed());
        Assert.assertTrue($(btnDelegateOk).isDisplayed());
        Assert.assertTrue($(btnDelegateCancel).isDisplayed());
        Assert.assertTrue($(btnDelegateClose).isDisplayed());
    }

    /**
     * Function to click on delegate cancel btn
     */
    public void clickDelegateCancel() {
        commonMethods.waitForElement(driver, btnDelegateCancel, 40);
        $(btnDelegateCancel).click();
    }

    /**
     * Function to close delegate window by clicking X button
     */
    public void closeDelegateWindow() {
        commonMethods.waitForElement(driver, btnDelegateClose, 30);
        $(btnDelegateClose).click();
    }

    /**
     * Function to click ok in delegate popup window
     */
    public void clickDelegateOk() {
        commonMethods.waitForElement(driver, btnDelegateOk, 60);
        $(btnDelegateOk).click();
    }

    /**
     * Function to delegate a task
     */
    public void delegateTask(String userName) {
        searchWithUser(userName);
        commonMethods.waitForElementExplicitly(2000);
        clickDelegateOk();
    }

    /**
     * Function to verify delegate task success message
     */
    public void verifyDelegateSuccess() {
        commonMethods.waitForElement(driver, lblSuccessTask, 60);
        Assert.assertTrue($(lblSuccessTask).isDisplayed());
        Assert.assertTrue($(lblDelegateSummary).isDisplayed());
        Assert.assertTrue($(btnDelegateSuccessClose).isDisplayed());
    }

    /**
     * Function to close delegate task success window
     */
    public void closeDelegateSuccess() {
        $(btnDelegateSuccessClose).click();
    }

    /**
     * Function to verify delegate user
     */
    public void verifyDelegateUser(String user) {
        commonMethods.waitForElementExplicitly(5000);
        Assert.assertTrue($(By.xpath("//div[contains(text(),'" + user + "')]")).isDisplayed());
        Assert.assertTrue($(btnTrash).isDisplayed());
    }

    /**
     * Method to return the columns displayed in the search result table
     *
     * @return
     */
    public List<String> returnSelectedColumns() {
        Select select = new Select($(selectedColumns));
        List<WebElement> columns = select.getOptions();
        List<String> values = new ArrayList<>();
        for (WebElement column : columns) {
            values.add(column.getText());
        }
        return values;
    }

    /**
     * click supplementary Files
     */
    public void clickSupplementaryFilesBtn() {
        commonMethods.waitForElement(driver, selectSupplementaryFiles, 40);
        $(selectSupplementaryFiles).click();
    }

    public void selectZipDownload(int index) {
        commonMethods.waitForElement(driver, zipDownloadButton, 60);
        By selectValue = By.xpath("(//td//input[@type='checkbox'])[" + index + "]");
        commonMethods.waitForElement(driver, selectValue);
        $(selectValue).setSelected(true);
        commonMethods.waitForElementExplicitly(1000);
        $(zipDownloadButton).click();
        commonMethods.waitForElementExplicitly(3000);
    }

    public void attachFileOnSupplmentary() {
        commonMethods.waitForElement(driver, btnAttachSupplimentaryFile, 60);
        $(btnAttachSupplimentaryFile).click();
        commonMethods.waitForElement(driver, localAttach);
        $(localAttach).click();
        commonMethods.waitForElementExplicitly(3000);
        verifyAndSwitchFrame("attachFiles-frame");
        $(uploadSupplimentaryFile).sendKeys(filePath + "sample.png");
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, btnAttachLocalFile);
        $(btnAttachLocalFile).click();
        verifyAndSwitchFrame("attachFiles-frame");
        commonMethods.waitForElement(driver, attachSuccess, 80);
        verifyAndSwitchFrame();
        $(btnCloseAttachments).click();
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, btnattachFileChoice_ok);
        $(btnattachFileChoice_ok).click();
    }

    /*
    Method to return the workflow id from the json file
     */
    public String getWorkflowNumber(String wfId) {
        Map<String, Map<String, Object>> jsonData = new HashMap<>();
        Map<String, Object> map = new HashMap<>();
        jsonData = dataSetup.loadJsonDataToMap(workflowPath);
        map = jsonData.get(wfId);
        return map.get("workflow_id").toString();
    }

}
