package com.oracle.babylon.pages.Setup.ProjectSettings;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.WebDriverRunner;
import com.github.javafaker.Faker;
import com.oracle.babylon.pages.Setup.ProjectSettingsPage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.*;

import static com.codeborne.selenide.Condition.appears;
import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class DocumentFieldsPage extends ProjectSettingsPage {
    private By docTable = By.xpath("//table[@class='dataTable']");
    private By saveButton = By.xpath("//button[@id='btnSave_page']//div[@class='uiButton-label'][contains(text(),'Save')]");
    private By lockFieldsLabel = By.xpath("//div[contains(text(),'Lock field labels')]");
    private By lockFieldsLabelStatus = By.xpath("//button[@id='btnLockDocumentFields']");
    private By saveChanges = By.xpath("//div[contains(text(),'Save Changes')]");
    private By okBtn = By.xpath("//button[@id='btnlockFieldsPanel_ok']//div[@class='uiButton-label'][contains(text(),'OK')]");
    private By copyFromProject = By.xpath("//div[contains(text(),'Copy From Project')]");

    private By copyFromProjectStatus = By.xpath("//button[@id='btnCopyFromProject']");
    private By documentFields = By.xpath("//div[contains(text(),'Document Fields')]");
    private By lockDocFieldsBtn = By.xpath("//button[@id='btnLockDocumentFields']");
    private By unlockDocFieldsBtn = By.id("btnUnlockDocumentFields");
    private By lockFieldOkBtn = By.xpath("//div[@id='lockFieldsPanel']//button[@id='btnlockFieldsPanel_ok']");
    private By saveChangesBtn = By.xpath("//button[@title='Save all changes before continuing']");
    private By attributeTextArea = By.name("newNames");
    private By addBtn = By.id("btnAdd");
    private By saveBtn = By.id("btnSave");
    private By abbreviation = By.xpath("//input[@name='abbreviation']");
    private By previewBtn = By.xpath("//div[contains(text(),'Preview')]");
    private By dataHeaders = By.xpath("//tr[@class='dataHeaders']//th");
    private By labelName1 = By.xpath("//table[@id='labeltab_content']//tr[2]//td[2]//input[@type='text']");
    private By labelName2 = By.xpath("//table[@id='labeltab_content']//tr[3]//td[2]//input[@type='text']");
    private By editLabelOkBtn = By.xpath("//button[@id='btni18nTextPanel_ok']");
    private By activeFields = By.xpath("//input[@name='checkbox_active']");
    private By columnHeaders = By.xpath("//table[@class='dataTable']//thead//th");
    private By txtTextArea = By.xpath("//textarea[@name='newNames']");
    private By btnSaveChanges = By.xpath("//div[contains(text(),'Save Changes')]");
    private By btnAdd = By.xpath("//div[contains(text(),'Add')]");
    private By newNameArea = By.xpath("//*[@name='newNames']");
    private By saveSuccessMsg = By.xpath("//*[@class='message success']");
    private By abbriviation = By.xpath("//*[@name='abbreviation']");
    private By loader = By.xpath("//*[contains(@class,'auiLoaderOverlay-loader')]");
    private By lblSaveSuccess = By.xpath("//div[@id='messagePanel']//li//div[text()='Saved successfully']");
    private By docFieldRows = By.xpath("//table[@class='dataTable']/tbody/tr/td[1]");
    private By labelNames = By.xpath("//table[@class='formTable']//tbody/tr[@class='dataRow']/td[1]");
    String xpath = "//table[@class='dataTable']/tbody/tr";
    String docFieldsTable = "//table[@class='formTable']/tbody/tr";

    public void navigateAndVerifyPage() {
        getMenuSubmenu("Setup", "Project Settings");
        navigateToDocFields();
    }

    /**
     * Function to navigate to the Documents setting page and lock the fields button
     */
    public void lockFieldsInDocuments(String documentType) {
        getMenuSubmenu("Setup", "Project Settings");
        $(By.cssSelector(".auiLoaderOverlay-loader")).waitUntil(disappear, 60000, 3000);
        HashMap<String, String> docMap = commonMethods.getDocumentTypeDetail(documentType);
        navigateToDocFields(docMap.get("uploadmenu"), "" + docMap.get("attachbutton") + " Fields");
    }

    public void navigateToDocFields(String menu, String subMenu) {
        verifyAndSwitchFrame();
        By menuElement = By.xpath("//span[contains(text(),'" + menu + "')]");
        commonMethods.waitForElement(driver, menuElement, 20);
        $(menuElement).click();
        verifyAndSwitchFrame();
        $(By.xpath("//div[contains(text(),'" + subMenu + "')]")).click();
        switchProjectSettingsFrame();
        commonMethods.waitForElement(driver, copyFromProject, 10);
    }

    /**
     * Function to navigate to Doc Fields
     */

    public void navigateToDocFields() {
        verifyAndSwitchFrame();
        commonMethods.clickLinkToChange(driver, projectSettingsLabel, documentSettings);
        commonMethods.clickLinkToChange(driver, projectSettingsLabel, documentFields);
    }


    /**
     * Function to lock the document field labels for a project
     */
    public void lockDocFieldsBtn() {

        switchProjectSettingsFrame();
        String result = commonMethods.returnElementAttributeValue(lockDocFieldsBtn, "title");
        if (!result.equals("Cannot lock field names - already locked")) {
            $(lockDocFieldsBtn).click();
            $(lockFieldOkBtn).click();
        } else {
            System.out.println("Cannot lock the button as it is already locked");
        }
    }

    /**
     * Function to unlock the field labels
     */
    public void unlockDocFieldsBtn() {
        switchProjectSettingsFrame();
        commonMethods.waitForElement(driver, unlockDocFieldsBtn, 35);
        if ($(unlockDocFieldsBtn).isDisplayed()) {
            $(unlockDocFieldsBtn).click();
        }
    }

    /**
     * Function to click copy From Project
     */

    public void copyFromProject() {
        $(copyFromProject).click();
    }

    /**
     * Function to click on Preview button
     */

    public void preview() {

        $(previewBtn).click();
    }

    /**
     * Function to select Use fields  for a project
     *
     * @param flag
     * @param label
     */

    public void useField(String label, String flag) {
        WebElement useFieldChkBox = $(By.xpath("//table[@class='dataTable']//tr[" + getLabelRow(label) + "]//td[2]//input[@type='checkbox']"));
        setLabel(label, flag, useFieldChkBox);
        commonMethods.waitForElement(driver, lblSaveSuccess, 10);
        Assert.assertTrue($(lblSaveSuccess).isDisplayed());
    }

    /**
     * Function to select Use field labels for a project
     *
     * @param flag
     * @param label
     */

    public void setMandatory(String label, String flag) {
        By element = By.xpath("//*[contains(text(),'" + label + "')]//parent::td//parent::tr//input[@name='checkbox_mandatory']");
        if (flag.equals("true")) {
            $(element).setSelected(true);
        } else {
            $(element).setSelected(false);
        }
        $(saveButton).click();
//        verifyAlert("Field labels have been saved successfully");
    }


    /**
     * Function to select editableInline column for a project
     *
     * @param flag
     * @param label
     */

    public void setEditableInline(String label, String flag) {
        switchProjectSettingsFrame();
        commonMethods.waitForElement(driver, copyFromProject, 30);
        WebElement setEditableChkBox = $(By.xpath("//table[@class='dataTable']//tr[" + getLabelRow(label) + "]//td[7]//input[@type='checkbox']"));
        setLabel(label, flag, setEditableChkBox);
    }


    /**
     * Function to set Label for a project
     *
     * @param label
     * @param element
     * @param flagStr
     */


    public void setLabel(String label, String flagStr, WebElement element) {
        boolean flag = Boolean.parseBoolean(flagStr.toLowerCase());
        if (flag) {
            if (!element.isSelected()) {
                element.click();
            }
        } else {
            if (element.isSelected()) {
                element.click();
            }
        }
        $(saveButton).click();
    }


    /**
     * Function to edit List Values for a project
     *
     * @param label
     */


    public void editListValues(String label) {
        WebElement editLink = $(By.xpath("//table[@class='dataTable']//tr[" + getLabelRow(label) + "]//td[6]//a"));
        editLink.click();
        $(saveChanges).click();
    }

    /**
     * Function to get the particular row of the Label
     *
     * @param label
     */

    public int getLabelRow(String label) {
        switchProjectSettingsFrame();
        commonMethods.waitForElementExplicitly(5000);
        List<WebElement> labelLists;
        labelLists = driver.findElement(docTable).findElements(By.xpath("//tr"));
        int labelRow = 0;
        for (int i = 3; i < labelLists.size(); i++) {
            if (labelLists.get(i).getText().contains(label)) {
                labelRow = i;
                break;
            }
        }
        return labelRow - 2;
    }

    /**
     * Function to click on any link to configure any label
     *
     * @param labelToEdit
     */
    public void clickLabelToEdit(String labelToEdit) {
        commonMethods.switchToFrame(driver, By.xpath("//iframe[@id='project-settings-page']"));
        commonMethods.waitForElement(driver, copyFromProject, 20);
        By editLabelLink = By.xpath("//td[contains(text(),'" + labelToEdit + "')]//..//td[6]//a");
        if (!$(editLabelLink).isDisplayed()) {
            editLabelLink = By.xpath("//td//a[contains(text(),'" + labelToEdit + "')]//..//..//td[7]//a");
        }
        commonMethods.waitForElement(driver, copyFromProject, 20);
        $(editLabelLink).click();
        $(saveChangesBtn).click();

    }

    /**
     * Function to verify if the button lock fields in enabled
     *
     * @return enabled status
     */
    public boolean isLockFieldsBtnEnabled() {
        String result = commonMethods.returnElementAttributeValue(lockDocFieldsBtn, "title");
        if (result.equals("Cannot lock field names - already locked")) {
            return false;
        } else {
            return true;
        }
    }


    /**
     * Function to add a attribute for documents
     *
     * @return attribute name
     */
    public List<String> createNewDocumentAttributes(int numOfValues) {
        Faker faker = new Faker();
        String attribute = "";
        List<String> listOfValues = new LinkedList<>();
        for (int valueCount = 0; valueCount < numOfValues; valueCount++) {
            attribute = faker.commerce().department();
            $(attributeTextArea).sendKeys(attribute);
            $(addBtn).click();
            listOfValues.add(attribute);
            updateDocFieldValue(attribute);
        }
        commonMethods.waitForElementExplicitly(2000);
        $(saveBtn).click();
        return listOfValues;
    }

    /**
     * Method to create new document field attributes
     */
    public List<String> createNewDocumentAttributes(String values) {
        List<String> listOfValues = new LinkedList<>();
        String[] attributes = values.split(",");
        for (String value : attributes) {
            if (!$(By.xpath("//td[text()='" + value + "']")).isDisplayed()) {
                $(attributeTextArea).sendKeys(value);
                $(addBtn).click();
                listOfValues.add(value);
                commonMethods.waitForElementExplicitly(1000);
                updateDocFieldValue(value);
            }
        }
        commonMethods.waitForElementExplicitly(2000);
        $(saveBtn).click();
        return listOfValues;
    }

    /**
     * Method to verify whether copy From Project is enabled
     */

    public boolean verifyCopyFromProject() {
      return $(copyFromProject).isEnabled();
    }

    /**
     * Method to verify whether Lock Field Labels is enabled
     */

    public boolean verifyLockFieldLabels() {
        return $(lockFieldsLabel).isEnabled();
    }

    /**
     * Method to verify whether Preview is enabled
     */

    public boolean verifyPreviews() {
        return $(previewBtn).isEnabled();
    }

    /**
     * Method to verify whether Save is enabled
     */

    public boolean verifySaveBtn() {
        return $(saveButton).isEnabled();
    }

    /**
     * Method to verify the elements present on the page
     */

    public void verifyElements() {
        switchProjectSettingsFrame();
        Assert.assertTrue(verifyCopyFromProject());
        Assert.assertTrue(verifyLockFieldLabels());
        Assert.assertTrue(verifyPreviews());
        Assert.assertTrue(verifySaveBtn());
    }
    /**
     * Method to verify the default document field status in document field page
     */
    public void verifyDefaultStatusOfDocFields() {
        switchProjectSettingsFrame();
        Assert.assertTrue($(copyFromProjectStatus).getAttribute("class").contains("disabled"));
        Assert.assertTrue($(lockFieldsLabelStatus).getAttribute("class").contains("disabled"));
        Assert.assertTrue(verifyPreviews());
        Assert.assertTrue(verifySaveBtn());
    }

    /**
     * Method to verify the header data on the page
     *
     * @param data
     */

    public void verifyHeaders(List<String> data) {
        List<String> allHeaders = new ArrayList<>();
        List<WebElement> headers = driver.findElements(dataHeaders);
        for (WebElement e : headers) {
            allHeaders.add(e.getText());
        }
        Assert.assertTrue(data.equals(allHeaders));
    }

    /**
     * Method to verify the Document sub sections in project settings page
     *
     * @param data
     */

    public void verifyDocOptions(List<String> data) {
        for (String section : data) {
            Assert.assertTrue($(By.xpath("//div[contains(text(),'" + section + "')]")).isDisplayed());
        }
    }

    /**
     * Function to verify use Field labels of a project
     *
     * @param label
     */

    public boolean verifyUseField(String label) {
        WebElement useFieldChkBox = $(By.xpath("//table[@class='dataTable']//tr[" + getLabelRow(label) + "]//td[2]//input[@type='checkbox']"));
        return useFieldChkBox.isSelected();
    }
    /**
     * Function to verify mandatory Field labels of a project
     *
     * @param label
     */
    public boolean verifyMandatoryField(String label) {
        WebElement mandatoryChkBox =  $(By.xpath("//table[@class='dataTable']//tr[" + getLabelRow(label) + "]//td[3]//input[@type='checkbox']"));
        return mandatoryChkBox.isSelected();
    }
    /**
     * Function to edit field labels for a project
     *
     * @param label
     * @param newLabel
     */

    public void editLabel(String label, String newLabel) {
        By labelName = By.xpath("//table[@class='dataTable']//tr[" + getLabelRow(label) + "]//td[1]//a");
        commonMethods.waitForElement(driver, labelName, 45);
        $(labelName).click();
        $(labelName1).clear();
        $(labelName1).sendKeys(newLabel);
        $(labelName2).clear();
        $(labelName2).sendKeys(newLabel);
        $(editLabelOkBtn).click();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, saveButton, 60);
        commonMethods.scrollPageUp(driver);
        $(saveButton).click();
    }

    /**
     * Function to verify the new label added
     *
     * @param newLabel
     */
    public boolean verifyNewLabel(String newLabel) {
        return $(By.xpath("//table[@class='dataTable']//tr[" + getLabelRow(newLabel) + "]//td[1]")).isDisplayed();
    }

    /**
     * Function to verify Non Editable Fields of a project
     *
     * @param data
     */

    public void verifyNonEditableFields(List<String> data) {
        for (String field : data) {
            By fields = By.xpath("//table[@class='dataTable']//tr[" + getLabelRow(field) + "]//td[3]//input[@type='checkbox']");
            Assert.assertTrue($(fields).isSelected());
            Assert.assertFalse($(fields).isEnabled());
        }
    }

    /**
     * Function to verify Mandatory Fields for a project
     *
     * @param data
     */

    public void verifyMandatoryFields(List<String> data) {
        for (String field : data) {
            Assert.assertTrue($(By.xpath("//table[@class='dataTable']//tr[" + getLabelRow(field) + "]//td[3]//input[@type='checkbox']")).isSelected());
        }


    }

    /**
     * Method to retrieve the fields which have been selected for the document
     *
     * @return
     */
    public List<String> returnActiveFields() {
        commonMethods.waitForElementExplicitly(2000);
        List<String> values = new ArrayList<>();
        List<WebElement> elements = driver.findElements(By.xpath("//tr[@class='dataRow']"));
        for (int count = 1; count <= elements.size(); count++) {
            By checkedElement = By.xpath("//tr[@class='dataRow'][" + count + "]//td[2]//input[@name='checkbox_active']");
            if ($(checkedElement).getAttribute("checked") != null && $(checkedElement).getAttribute("checked").equals("true")) {
                By valueElement = By.xpath("//tr[@class='dataRow'][" + count + "]//td[1]");
                String text = $(valueElement).getText();
                values.add(text);
            }
        }
        return values;
    }

    /**
     * Retrieve some info about the document fields
     * As of now label, type and max length of the fields
     *
     * @return
     */
    public Map<String, Map<String, Object>> retrieveMetadata() {
        Map<String, Integer> columnIndexMap = retrieveColumns();
        int maxLengthIndex = columnIndexMap.get("Max Length");
        int typeIndex = columnIndexMap.get("Type");
        int labelIndex = columnIndexMap.get("Label");

        Map<String, Map<String, Object>> metaData = new HashMap<>();
        List<WebElement> elements = driver.findElements(By.xpath("//table[@class='dataTable']//td[" + labelIndex + "]"));
        for (WebElement element : elements) {
            WebElement maxLengthField = driver.findElement(By.xpath("//table[@class='dataTable']//td[contains(text(),'" + element.getText() + "')]//..//td[" + maxLengthIndex + "]"));
            WebElement typeField = driver.findElement(By.xpath("//table[@class='dataTable']//td[contains(text(),'" + element.getText() + "')]//..//td[" + typeIndex + "]"));
            Map<String, Object> cellData = new HashMap<>();
            cellData.put("type", typeField.getText());
            cellData.put("max_length", maxLengthField.getText());
            metaData.put(element.getText(), cellData);
        }
        return metaData;
    }

    /**
     * Method to retrieve the columns and their indexes
     *
     * @return
     */
    public Map<String, Integer> retrieveColumns() {
        List<WebElement> elements = driver.findElements(columnHeaders);
        int count = 1;
        Map<String, Integer> columnIndexMap = new HashMap<>();
        for (WebElement element : elements) {
            columnIndexMap.put(element.getText(), count);
            count++;
        }
        return columnIndexMap;
    }


    public void setMandatoryFields(String fieldName, String value) {
        By by = By.xpath("//table[@class='dataTable']//td[contains(text(),'" + fieldName + "')]//..//td[3]");
        $(by).setSelected(Boolean.getBoolean(value));
    }

    /**
     * Function to update document field value
     */
    public void updateDocFieldValue(String fieldValue) {
        List<WebElement> table = new ArrayList<>($$(By.xpath(xpath)));
        for (int i = 1; i <= table.size(); i++) {
            commonMethods.waitForElement(driver, By.xpath("//td[text()='" + fieldValue + "']"), 10);
            if ($(By.xpath(xpath + "[" + i + "]//td[1]")).getText().trim().equalsIgnoreCase(fieldValue)) {
                commonMethods.waitForElementExplicitly(1000);
                if (!$(By.xpath(xpath + "[" + i + "]//td[2]/input")).getAttribute("type").equalsIgnoreCase("hidden")) {
                    $(By.xpath(xpath + "[" + i + "]//td[2]/input")).sendKeys(fieldValue.substring(0, 2) + fieldValue.substring(fieldValue.length() - 1));
                    commonMethods.waitForElementExplicitly(1000);
                }
                break;
            }
        }
    }

    /**
     * Function to remove document field value
     */
    public void removeDocFieldValues(String fieldValue) {
        String xpath = "//table[@class='dataTable']/tbody/tr";
        List<WebElement> table = new ArrayList<>($$(By.xpath(xpath)));
        String[] values = fieldValue.split(",");
        for (String value : values) {
            for (int i = 1; i < table.size(); i++) {
                if ($(By.xpath(xpath + "[" + i + "]//td[1]")).getText().trim().equalsIgnoreCase(value)) {
                    $(By.xpath(xpath + "[" + i + "]//td[3]/input")).click();
                    break;
                }
            }
        }
        saveDocFieldChanges();
    }

    /**
     * Function to save document field value
     */
    public void saveDocFieldChanges() {
        clickSaveButton();
        $(loadingIcon).should(Condition.disappear);
        commonMethods.waitForElement(WebDriverRunner.getWebDriver(), By.xpath("//div[contains(text(),'Your changes have been saved')]"), 30);
    }

    /**
     * Method to edit values for document field.
     *
     * @param documentType
     * @param label
     * @param values
     */
    public void editListValues(String documentType, String label, List<String> values) {
        getMenuSubmenu("Setup", "Project Settings");
        $(loader).waitUntil(disappear, 60000, 3000);
        HashMap<String, String> docMap = commonMethods.getDocumentTypeDetail(documentType);
        navigateToDocFields(docMap.get("uploadmenu"), "" + docMap.get("supersedebutton") + " Fields");
        $(By.xpath("//table[@class='dataTable']//tr[" + getLabelRow(label) + "]//*[contains(text(),'edit')]")).waitUntil(appears, 5000).click();
        $(saveChanges).waitUntil(appears, 8000).click();
        ElementsCollection abbbreviations = $$(abbriviation);
        for (int index = 0; index < abbbreviations.size(); index++) {
            if (abbbreviations.get(index).getAttribute("value") == null || abbbreviations.get(index).getAttribute("value").isEmpty()) {
                abbbreviations.get(index).setValue(driver.findElement(By.xpath("(//*[@name='abbreviation'])[" + (index + 1) + "]/parent::td/preceding-sibling::td/input[@name='documentFieldValueId']/following-sibling::input")).getAttribute("value").substring(0, 3));
            }
        }
        for (String value : values) {
            $(newNameArea).sendKeys(value);
            $(addBtn).click();
            $(By.xpath("//input[@name='name'][@value='" + value + "']/parent::td/following-sibling::td/input[@type='text']")).sendKeys(value.substring(0, 3));
            $(saveBtn).click();
            $(saveSuccessMsg).waitUntil(appears, 8000);
        }
    }

    /**
     * Method to get all project field names
     */
    public List<String> getAllDocumentFields() {
        return commonMethods.getValues(labelNames);
    }

    /**
     * Method to get all values for document field
     */
    public List<String> getAllFieldValues() {
        commonMethods.waitForElement(driver, btnAdd, 30);
        return commonMethods.getValues(docFieldRows);
    }

    /**
     * Function to remove document field value
     */
    public void removeAllFieldsValues() {
        String xpath = "//table[@class='dataTable']/tbody/tr";
        List<WebElement> table = new ArrayList<>($$(By.xpath(xpath)));
        for (int i = 1; i <= table.size(); i++) {
            $(By.xpath(xpath + "[" + i + "]//td[3]/input")).click();
        }
        saveDocFieldChanges();
    }

    /**
     * Function to get document field is mandatory or not
     */
    public String getMandatoryField(String fieldName) {
        String value = $(By.xpath("(//td[contains(text(),'" + fieldName + "')]/../td[4]/input[2])[1]")).getValue();
        if (value.equalsIgnoreCase("true")) return "Yes";
        else return "No";
    }

    /**
     * Function to get document field type
     */
    public String getType(String fieldName) {
        return $(By.xpath("(//td[contains(text(),'" + fieldName + "')]/../td[4])[1]")).getText().trim();
    }

    /**
     * Function to get document field max length
     */
    public String getMaxLength(String fieldName) {
        return $(By.xpath("(//td[contains(text(),'" + fieldName + "')]/../td[5])[1]")).getText().trim();
    }

    /**
     * Function to get document field inline edit
     */
    public String getInlineEdit(String fieldName) {
        String value = $(By.xpath("(//td[contains(text(),'" + fieldName + "')]/../td[4]/input[4])[1]")).getValue();
        if (value.equalsIgnoreCase("true")) return "Yes";
        else return "No";
    }

    /**
     * Function to get document field use field
     */
    public String getUseField(String fieldName) {
        String value = $(By.xpath("(//td[contains(text(),'" + fieldName + "')]/../td[4]/input[3])[1]")).getValue();
        if (value.equalsIgnoreCase("true")) return "Yes";
        else return "No";
    }

    /**
     * Function to get document field searchable field
     */
    public String getSearchableField(String fieldName) {
        String value = $(By.xpath("(//td[contains(text(),'" + fieldName + "')]/../td[4]/input[5])[1]")).getValue();
        if (value.equalsIgnoreCase("true")) return "Yes";
        else return "No";
    }

    /**
     * Function to get document field identifier name
     */
    public String getIdentifier(String fieldName) {
        return $(By.xpath("(//td[contains(text(),'" + fieldName + "')]/../td[4]/input[1])[1]")).getValue();
    }

    /**
     * Function to get document field attributes of single and multi select list use fields
     */
    public Map<String, String> getDocAttributes() {
        Map<String, String> docAttributes = new LinkedHashMap<>();
        List<String> docFields = getAllDocumentFields();
        for (String docField : docFields) {
            if (getUseField(docField).equalsIgnoreCase("yes"))
                docAttributes.put(docField, getType(docField));
        }
        return docAttributes;
    }

    /**
     * Function to get select list single document attribute values
     */
    public Map<String, String> getDocSingleAttrValues(String docAttribute) {
        Map<String, String> docAttrValues = new LinkedHashMap<>();
        clickLabelToEdit(docAttribute);
        commonMethods.waitForElementExplicitly(3000);
        List<WebElement> table = new ArrayList<>($$(By.xpath(docFieldsTable)));
        for (int i = 1; i <= table.size(); i++) {
            docAttrValues.put($(By.xpath(docFieldsTable + "[" + i + "]//td[1]")).getText(), $(By.xpath(docFieldsTable + "[" + i + "]//td[2]//input[1]")).getValue());
        }
        $(saveBtn).click();
        return docAttrValues;
    }

    /**
     * Function to get select list multiple document attribute values
     */
    public List<String> getDocMultiAttrValues(String docAttribute) {
        List<String> docAttrValues = new LinkedList<>();
        clickLabelToEdit(docAttribute);
        commonMethods.waitForElementExplicitly(3000);
        List<WebElement> table = new ArrayList<>($$(By.xpath(xpath)));
        for (int i = 1; i <= table.size(); i++) {
            docAttrValues.add($(By.xpath(xpath + "[" + i + "]//td[1]//input[2]")).getValue());
        }
        $(saveBtn).click();
        return docAttrValues;
    }
}

