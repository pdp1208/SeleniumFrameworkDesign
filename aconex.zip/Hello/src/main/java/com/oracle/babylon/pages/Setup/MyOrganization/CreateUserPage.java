package com.oracle.babylon.pages.Setup.MyOrganization;

import com.codeborne.selenide.Condition;
import com.github.javafaker.Faker;
import com.oracle.babylon.Utils.helper.Navigator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

//Why check in a file that is not part of your requirement
public class CreateUserPage extends Navigator {
    private By givenName = By.cssSelector("#givenName-input");
    private By familyName = By.cssSelector("#familyName-input");
    private By email = By.xpath("//div[@id='email']//input[@class='uiTextField-input']");
    private By loginName = By.xpath("//div[@id='loginName']//input[@class='uiTextField-input']");
    private By selectLanguage = By.xpath("//select[@id='selLanguages']");
    private By division = By.xpath("//select[@id='selDivision']");
    private By password = By.xpath("//div[@id='password']//input[@class='uiPasswordField-input']");
    private By confirmPassword = By.xpath("//div[@id='passwordConfirm']//input[@class='uiPasswordField-input']");
    private By inviteButton = By.xpath("//div[@class='uiButton-label' and text()='Invite']");
    private By closeBtn = By.xpath("//*[@id=\"successPanel-cancel\"]//div[contains(text(),'Close')]");
    private By okBtn = By.xpath("//div[contains(text(),'OK')]");
    private By createUser=By.xpath("//div[@class='navBarPanel-menuItem' and text()='Create User']");
    private By createUser_AppHub=By.xpath("//a[@id='nav-bar-SETUP-SETUP-NEWORGMEMBER' and text()='Create User']");
    private By createANewUser=By.xpath("//button//div[contains(text(),'Create a New User')]");
    private By inviteBtn=By.xpath("//div[@class='uiButton-content']//div[text()='Invite']");
    private By mandatoryErrorMsg=By.xpath("//li[@class='auiMessage danger']//div[@class='auiMessage-content']");
    private By existingError=By.xpath("//td//div[@class='error']");
    private By existingError_AppHub=By.xpath("//*[@class='auiMessage-content']");
    private By passwordError=By.xpath("//td//*[text()='This password is not strong enough - follow the criteria shown below']");
    private By successMsg=By.xpath("//li[@class='message success']//h3");
    private By editUserDetailsBtn=By.xpath("//h4[contains(text(),'Edit this user')]");
    private By successMsg1=By.xpath("(//div[@class='actionGuide-primary']//ul//div)[1]");
    private By successMsg2=By.xpath("(//div[@class='actionGuide-primary']//ul//div)[2]");
    private By linkNameOnPopUp1=By.xpath("(//ul//li//h4)[1]");
    private By linkNameOnPopUp2=By.xpath("(//ul//li//h4)[2]");
    private By menuNames=By.xpath("//div[@id='nav-bar']//button//div[@class='uiButton-content']");
    private By menuNames_AppHub=By.xpath("//ul[@class='oj-tabbar-element']//li[contains(@class,'nav-item-container navBarButton')]");

    Faker faker = new Faker();

    public void navigateAndVerifyPage() {
        getMenuSubmenu("Setup", "Create User");
        commonMethods.waitForElementExplicitly(5000);
        verifyAndSwitchFrame();
//        verifyPageTitle("Invite a new user");
    }
    public Map<String, String> newUserDefaultDetail() {
        Faker faker = new Faker();
        Map<String, String> userDetail = new HashMap<>();
        String firstName = faker.name().firstName();
        userDetail.put("firstname", firstName);
        String lastName = faker.name().lastName();
        userDetail.put("lastname", lastName);
        String fullName = faker.name().fullName();
        userDetail.put("fullName", fullName);
        String email = configFileReader.getEmailId();
        userDetail.put("email", email);
        String loginName = firstName.charAt(0) + lastName +fullName.charAt(0) ;
        userDetail.put("loginName", loginName);
        return userDetail;
    }
    /**
     * Method to create user with User Details
     */
    public void createUser(Map<String, String> userDetail) {
        enterUserDetails(userDetail);
        $(inviteButton).click();
        clickCloseBtn();
    }
    /**
     * Method to create user with Password
     */
    public void createUserWithPassword(Map<String, String> userDetail) {
        //Password for fedRAMPhas more strict rules for password.
        String newPassword = "$" + faker.internet().password(8,10,true)+ faker.number().digits(4);
        $(password).sendKeys(newPassword);
        $(confirmPassword).sendKeys(newPassword);
        userDetail.put("password", newPassword);
        createUser(userDetail);
    }
    /**
     * Method to create user with Password and Project
     */
    public void createUserWithProjectAndPassword(Map<String, String> userDetail, String project) {
        fillProject(project);
        createUserWithPassword(userDetail);
    }
    /**
     * Method to create user without click on close button
     */
    public void createEditNewUser(Map<String, String> userDetail)
    {
        String newPassword = faker.internet().password() + "8";
        $(password).sendKeys(newPassword);
        $(confirmPassword).sendKeys(newPassword);
        userDetail.put("password", newPassword);
        enterUserDetails(userDetail);
        $(inviteButton).click();
    }
    /**
     * Method to verify the create user access
     */
    public boolean verifyCreateUserAccess()
    {
        clickSetupLink();
       if(configFileReader.getAppHubEnable())
        return $(createUser_AppHub).isDisplayed();
       else
        return $(createUser).isDisplayed();
    }
    /**
     * Method to click on Create A New User
     */
    public void clickCreateNewUser()
    {
        commonMethods.waitForElement(driver,createANewUser);
        $(createANewUser).click();
    }
    /**
     * Method to get whether the Create A New User Button is displayed
     */
    public boolean getCreateNewUser()
    {return $(createANewUser).isDisplayed();}
    /**
     * Method to click on Invite Button
     */
    public void clickInviteBtn()
    {
        commonMethods.waitForElement(driver,inviteBtn);
        $(inviteBtn).click();
    }
    /**
     * Method to get the Mandatory error message
     */
    public String getMandatoryErrorMsg()
    {return $(mandatoryErrorMsg).getText();}

    /**
     * Method to verify the Existing login message
     */
    public String getExisitingLoginMsg(String user)
    {
        $(loginName).sendKeys(user);
        $(inviteBtn).click();
        commonMethods.waitForElement(driver, existingError);
        return $(existingError).getText();
    }
    /**
     * Method to verify the password rules message
     */
    public void passwordConditionMsg()
    {
        $(password).sendKeys(faker.internet().password() + "5");
        $(passwordError).is(Condition.appear);
    }
    /**
     * Method to verify the password mismatch message
     */
    public String getPasswordMismatch()
    {
        $(password).sendKeys(faker.internet().password() + "10");
        $(confirmPassword).sendKeys(faker.internet().password() + "8");
        clickInviteBtn();
        return $(existingError).getText();
    }
    /**
     * Method to Enter the user details into the Create User Page
     */
    public void enterUserDetails(Map<String, String> userDetail) {
        for (String key : userDetail.keySet()) {
            switch (key.toLowerCase()) {
                case "firstname":
                    $(givenName).sendKeys(userDetail.get(key));
                    break;
                case "lastname":
                    $(familyName).sendKeys(userDetail.get(key));
                    break;
                case "email":
                    $(email).sendKeys(userDetail.get(key));
                    break;
                case "loginname":
                    $(loginName).sendKeys(userDetail.get(key));
                    break;
                case "division":
                    $(division).selectOption(1);
                    break;

            }
        }
    }
    /**
     * Method to click on close button
     */
    public void clickCloseBtn()
    {
        commonMethods.waitForElement(driver,closeBtn,120);
        $(closeBtn).click();
    }
    /**
     * Method to get the success message
     */
    public String getSuccessMessage()
    {
        commonMethods.waitForElement(driver,successMsg);
        return $(successMsg).getText();
    }
    /**
     * Method to get the success message based on index
     */
    public String validateSuccessMessage(String index)
    {
        commonMethods.waitForElement(driver,successMsg);
        return index.contains("1")? $(successMsg1).getText(): $(successMsg2).getText();
    }
    /**
     * Method to get the Link Names on success message
     */
    public String getSuccessLinkName(String index)
    {  return index.contains("1")? $(linkNameOnPopUp1).getText():$(linkNameOnPopUp2).getText();}
    /**
     * Method to click on Edit User Details on success message
     */
    public void clickEditUserDetails()
    {
        commonMethods.waitForElement(driver,editUserDetailsBtn);
        $(editUserDetailsBtn).click();
    }

    /**
     * Method to get the Menu Name as per the order
     */
    public ArrayList<String> getMenuName()
    {
        ArrayList<String> menuDisplayed=new ArrayList<>();
        By xpath;
        if(configFileReader.getAppHubEnable())
            xpath=menuNames_AppHub;
        else
            xpath=menuNames;
        List<WebElement> elements = new ArrayList<>($$(xpath));
        for(int iterator=0;iterator<elements.size();iterator++)
            menuDisplayed.add(elements.get(iterator).getAttribute("innerText"));
        return menuDisplayed;

    }

    /**
     * Method to create user without password
     */
    public void createUserWithoutPassword(Map<String, String> userDetail, String project) {
        enterUserDetails(userDetail);
        fillProject(project);
        $(inviteButton).click();
        clickCloseBtn();
    }

    /**
     * Method to select project to the new user
     */
    public void fillProject(String project) {
        $(By.cssSelector("#selProjects")).click();
        String leftBidiLocator = "//div[@class='uiBidi-left']//select[@class='null']";
        $(By.xpath(leftBidiLocator + "//option[contains(text(),'" + project + "')]")).doubleClick();
        $(okBtn).click();
    }



}