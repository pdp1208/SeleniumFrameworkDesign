package com.oracle.babylon.pages.Mail;

import org.openqa.selenium.By;

import java.util.Map;

import static com.codeborne.selenide.Selenide.$;

public class DraftMailPage extends MailPage {


    private By deleteDraftBtn = By.xpath("//button[contains(text(),'Delete Draft')]");
    private By deleteConfirmBtn = By.xpath("//button[@data-automation-id='mailSearch-btnDeleteDraftConfirm']");
    private By editButton = By.xpath("//button[text()='Edit']");
    /**
     * Function to verify Draft page
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Mail", "Drafts");
        verifyPageTitle("Search Mail");
    }
    /**
     * Function to delete draft
     */
    public void deleteDraft() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver,deleteDraftBtn,10);
        $(deleteDraftBtn).click();
        commonMethods.waitForElement(driver,deleteConfirmBtn,10);
        $(deleteConfirmBtn).click();
    }

    /**
     * Method to click on edit button, to edit the draft mail saved
     */
    public void clickEditBtn(){
        $(editButton).click();
    }


}
