package com.oracle.babylon.Utils.helper;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.oracle.babylon.Utils.setup.utils.ConfigFileReader;
import org.junit.Assert;
import org.openqa.selenium.*;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

import static com.codeborne.selenide.Selenide.$;

public class FileOperations extends Navigator {

    private String os = System.getProperty("os.name");
    ConfigFileReader configFileReader = new ConfigFileReader();
    LinuxOperations linuxOperations = new LinuxOperations();

    /* Get the latest file from a specific directory*/
    public File getLatestFilefromDir(String dirPath) {
        File dir = new File(dirPath);
        File[] files = dir.listFiles();
        if (files == null || files.length == 0) {
            return null;
        }

        File lastModifiedFile = files[0];
        for (int i = 1; i < files.length; i++) {
            if (lastModifiedFile.lastModified() < files[i].lastModified()) {
                lastModifiedFile = files[i];
            }
        }
        return lastModifiedFile;
    }

    /**
     * Method to verify downloaded file in browser downloads
     */
    public String verifyBrowserDownloads(String fileName) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        driver.get(configFileReader.getBrowserDownloadUrl());
        CommonMethods.captureExtentReportScreenShot(driver);
        if (configFileReader.getBrowser().equalsIgnoreCase("edge")) {
            Assert.assertTrue("Downloaded file is not displayed", $(By.xpath("//button[contains(text(),'" + fileName.split("\\.")[0] + "')]")).isDisplayed());
            return $(By.xpath("//button[contains(text(),'" + fileName.split("\\.")[0] + "')]")).getText();
        } else {
            Assert.assertTrue("Downloaded file is not displayed", (js.executeScript("return " + configFileReader.getDownloadQuery()).toString().contains(fileName.split("\\.")[0])));
            return js.executeScript("return " + configFileReader.getDownloadQuery()).toString();
        }
    }

    /**
     * Method to create a different extension of files
     */
    public void createFiles(String fileName) {
        try {
            String file = configFileReader.getTestDataPath() + fileName;
            Files.deleteIfExists(Paths.get(file));
//            Files.createFile(Paths.get(file));
            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            writer.append(faker.name().fullName());
            writer.flush();
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * Method to write data to a file
     */
    public void writeContent(String fileName, String content) {
        try {
            String file = configFileReader.getTestDataPath() + fileName;
            Files.deleteIfExists(Paths.get(file));
            Files.createFile(Paths.get(file));
            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            writer.append(content);
            writer.flush();
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Method to create CSV file  and fill details
     */
    public void createCsvFile(String fileName, List<String> values) {
        try {
            String filePath = configFileReader.getTestDataPath() + fileName;
            deleteFile(filePath);
            BufferedWriter writer = new BufferedWriter(new FileWriter(filePath));
            for (String rows : values) {
                writer.append(rows);
                writer.append("\n");
            }
            writer.flush();
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Method to copy file from source to destination
     */
    public void copyFile(String source, String destination, String fileName) {
        try {
            if (os.toLowerCase().contains("linux")) {
                deleteFile(source, configFileReader.copyDownloadedFiles(), fileName);
                linuxOperations.copyFiles(source, configFileReader.copyDownloadedFiles(), source + "/" + fileName);
            } else {
                createDirectory(configFileReader.getDownloadedFilePath(), configFileReader.copyDownloadedFiles());
                deleteFiles(fileName);
                Files.copy(Paths.get(new File(source).getAbsolutePath() + "/" + fileName), Paths.get(new File(destination).getAbsolutePath() + "/" + fileName));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Method to copy file from source to destination
     */
    public void copyAFile(String source, String destination, String sourceFileName, String destFileName) {
        try {
            if (os.toLowerCase().contains("linux")) {
                System.out.println(new File(source).getAbsolutePath());
                commonMethods.runCommands(LinuxOperations.removeFile + " " + new File(source).getAbsolutePath() + "/" + destFileName);
                commonMethods.runCommands(LinuxOperations.copyFile + " " + new File(source).getAbsolutePath() + "/" + sourceFileName + " " + new File(source).getAbsolutePath() + "/" + destFileName);
            } else {
                createDirectory(configFileReader.getDownloadedFilePath(), configFileReader.copyDownloadedFiles());
                deleteFiles(destFileName);
                Files.copy(Paths.get(new File(source + sourceFileName).getAbsolutePath()), Paths.get(new File(destination + destFileName).getAbsolutePath()));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * Method to copy file from source to destination
     */
    public void copyFile(String source, String destination, String sourceFileName, String destFileName) {
        try {
            deleteFile(destination + sourceFileName);
            Files.copy(Paths.get(new File(source + sourceFileName).getAbsolutePath()), Paths.get(new File(destination + destFileName).getAbsolutePath()));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Method to delete file
     */
    public void deleteFile(String source) {
        try {
            Files.deleteIfExists(Paths.get(new File(source).getAbsolutePath()));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Method to read the contents of the file in a string
     *
     * @param filePath
     * @return
     */

    public static String readAllBytes(String filePath) {
        String content = "";
        try {
            content = new String(Files.readAllBytes(Paths.get(filePath)));
        } catch (IOException e) {
            e.printStackTrace();
        }

        return content;
    }

    /**
     * Method to delete file if filename matches
     */
    public void deleteFile(String path, String folderName, String fileName) {
        try {
            if (os.toLowerCase().contains("linux")) {
                createDirectory(path, folderName);
                linuxOperations.changeFileOwner(path, folderName);
                linuxOperations.setFilePermissions(path, folderName);
            }
            File[] files = new File(path + "/" + folderName).listFiles();
            for (File file : files)
                if (file.getName().contains(fileName)) {
                    if (os.toLowerCase().contains("linux")) {
                        linuxOperations.removeFile(path, folderName, file.getName());
                    } else {
                        Files.deleteIfExists(Paths.get(new File(path + File.separator + file.getName()).getAbsolutePath()));
                    }
                }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Method to unzip files in a folder
     */
    public void unzipFile(String zipFilePath, String folderName, String destDirectory) {
        ZipInputStream zipIn;
        ZipEntry entry;
        try {
            if (os.toLowerCase().contains("linux")) {
                linuxOperations.changeFileOwner(destDirectory, folderName);
                linuxOperations.setFilePermissions(destDirectory, folderName);
                linuxOperations.copyZipFile(destDirectory, folderName, zipFilePath);
                linuxOperations.extractZipFile(destDirectory, zipFilePath.split("/")[zipFilePath.split("/").length - 1], folderName);
            } else {
                zipIn = new ZipInputStream(new FileInputStream(zipFilePath));
                entry = zipIn.getNextEntry();
                if (entry == null) Assert.fail("Zip file is empty");
                while (entry != null) {
                    String filePath = destDirectory + File.separator + entry.getName();
                    if (!entry.isDirectory())
                        extractFile(zipIn, filePath);
                    else {
                        File dir = new File(filePath);
                        dir.mkdirs();
                    }
                    zipIn.closeEntry();
                    entry = zipIn.getNextEntry();
                }
                zipIn.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Extracts a zip entry (file entry)
     *
     * @param zipIn
     * @param filePath
     * @throws IOException
     */
    private void extractFile(ZipInputStream zipIn, String filePath) {
        int BUFFER_SIZE = 4096;
        BufferedOutputStream bos;
        try {
            bos = new BufferedOutputStream(new FileOutputStream(filePath));
            byte[] bytesIn = new byte[BUFFER_SIZE];
            int read;
            while (true) {
                try {
                    if ((read = zipIn.read(bytesIn)) == -1) break;
                    bos.write(bytesIn, 0, read);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            bos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Method to verify file is present in downloaded folder or not
     */
    public boolean verifyFile(String fileDir, String folderName, String fileName) {
        if (os.equalsIgnoreCase("linux"))
            return new File(fileDir + "/" + folderName + "/" + fileName).exists();
        else return new File(fileDir + fileName).exists();
    }

    /**
     * Method to return filename based on the keyword passed in parameter
     */
    public String getFileNames(String path, String keyword) {
        try {
            File[] files = new File(path).listFiles();
            for (File file : files)
                if (file.getName().contains(keyword))
                    return file.getName();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Method to return files counts in zip file
     */
    public int getFilesCount(String zipFilePath) {
        try {
            ZipFile zipFile = new ZipFile(zipFilePath);
            return zipFile.size();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * Method to create a directory
     */
    public void createDirectory(String path, String directoryName) {
        if (os.equalsIgnoreCase("linux")) {
            linuxOperations.createFolder(path, directoryName);
        } else {
            File directory = new File(path, directoryName);
            if (!directory.exists()) {
                directory.mkdir();
            }
        }
    }

    /**
     * Method to delete file
     */
    public void deleteFiles(String fileName) {
        try {
            final File downloadDirectory = new File(configFileReader.getDownloadedFilePath() + configFileReader.copyDownloadedFiles());
            final File[] files = downloadDirectory.listFiles((dir, name) -> name.matches(fileName.split("\\.")[0] + "*"));
            Arrays.asList(files).stream().forEach(File::delete);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

     public static void saveProperties(File file,Properties properties) throws IOException
    {
        FileOutputStream fr = new FileOutputStream(file);
        properties.store(fr, "Properties");
        fr.close();
        System.out.println("After saving properties: " + properties);
    }

    public static void loadProperties(File file,Properties properties)throws IOException
    {
        FileInputStream fi=new FileInputStream(file);
        properties.load(fi);
        fi.close();
        System.out.println("After Loading properties: " + properties);
    }
    public void verifyZipDownload(String user)
    {
        commonMethods.waitForElementExplicitly(15000);
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
        userMap = jsonMapOfMap.get(user);
       /* DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();
       *///String fileName = userMap.get("org_name").toString() + "-" + userMap.get("project_name1").toString() + "-" + dateFormat.format(date);
        String fileName = userMap.get("org_name").toString() + "-" + userMap.get("project_name1").toString() + "-";
        verifyBrowserDownloads(fileName);
    }

    /* delete after demo*/
    protected synchronized static String addScreenshot(WebDriver driver) {
        String encodedBase64 = null;
        FileInputStream fileInputStreamReader = null;
        try {
            File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            fileInputStreamReader = new FileInputStream(srcFile);
            byte[] bytes = new byte[(int) srcFile.length()];
            fileInputStreamReader.read(bytes);
            encodedBase64 = new String(Base64.getEncoder().encode(bytes));
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return "data:image/png;base64," + encodedBase64;
    }

    /* delete after demo*/
    public static void captureExtentReportScreenShot(WebDriver driver) {
        try {
            ExtentCucumberAdapter.addTestStepScreenCaptureFromPath(addScreenshot(driver));
        } catch (Exception exception) {
            System.out.println("Extent Report plugin not initialised");
        }
    }
}
