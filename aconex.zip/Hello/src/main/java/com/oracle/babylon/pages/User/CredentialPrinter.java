package com.oracle.babylon.pages.User;

public class CredentialPrinter {

    private void printCreds(String username, String password){
        System.out.println("Username ---->" + username);
        System.out.println("Password ---->" + password);
    }

    public static void main(String[] args){
        CredentialPrinter credentialPrinter = new CredentialPrinter();
        credentialPrinter.printCreds(args[0], args[1]);
    }
}
