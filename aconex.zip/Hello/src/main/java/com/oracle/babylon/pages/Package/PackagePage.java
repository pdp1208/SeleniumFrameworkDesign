package com.oracle.babylon.pages.Package;

import com.github.javafaker.Faker;
import com.oracle.babylon.Utils.helper.Navigator;
import com.oracle.babylon.pages.Document.DocumentPage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.util.List;

import static com.codeborne.selenide.Selenide.$;

public class PackagePage extends Navigator {
    private By sendPackageBtn = By.xpath("//button[text()='Send Package']");
    private By startReviewBtn = By.xpath("//button[text()='Start a Review']");
    private By closePackage = By.xpath("//button[text()='Close Package']");
    private By moreBtn = By.xpath("//button[contains(text(),'More')]");
    private By exportBtn = By.xpath("//*[@class='auiModal-footer']//button[contains(text(),'Export')]");
    private By nliu = By.xpath("//a[text()='Mark As No Longer In Use']");
    private By exportPackage = By.xpath("//a[text()='Export Package']");
    private By packageRecipients = By.xpath("//div[text()='Send to']//..//div[2]//input");
    private By packageSubject = By.xpath("//div[text()='Subject']//..//div[2]//input");
    private By sendBtn = By.xpath("//button[text()='Send']");
    private By reviewTitleElement = By.xpath("//input[@data-automation-id='reviewTitle']");
    private By submitBtn = By.xpath("//button[text()='Submit']");
    private By documentsCount = By.xpath("//li[@id='packageViewDocuments']//span");
    private By documentsSection = By.xpath("//li[@id='packageViewDocuments']");
    private By attachmentsSection = By.xpath("//li[@id='packageViewAttachments']");
    private By attachFiles = By.xpath("//button[contains(text(),'Attach files')]");
    private By documentAttachPanel = By.xpath("//input[@name='qqfile']");
    private By selectCheckBoxOnExport = By.xpath("//td//input[@type='checkbox']");
    String filePath = System.getProperty("user.dir") + "/src/main/resources/data/files/";
    private By auiAttachFilesBtn = By.xpath("//div[@class='auiModal-footer']//button[contains(text(),'Attach files')]");
    private By uploadedTxt = By.xpath("//div[contains(@class,'progress-bar')]//span[contains(text(),'1 uploaded')]");
    private By auiCloseBtn = By.xpath("//div[@class='auiModal-footer']//button[contains(text(),'Close')]");
    private By attachmentFile = By.xpath("(//*[@options='attachmentsTableOptions']//td//div[contains(@class,'fileName')]//a)[1]");
    private By mailsCount = By.xpath("//li[@id='packageViewMail']//acx-count-pill//span");
    private By documentNumber = By.xpath("//table[@class='auiTable']//tbody//tr//td[3]//div//div");
    private By editBtn = By.xpath("//button[text()='Edit']");
    private By addDocumentsBtn = By.xpath("//button[text()='Add Documents']");
    private By eventsLog = By.xpath("//li[@id='packageViewEventLog']");
    private By mailsSections = By.xpath("//li[@id='packageViewMail']");
    private By btnNewMail = By.xpath("//button[text()='New Mail']");
    private By btnAttach = By.xpath("//button[@id='btnMailAttachments']");
    private By btnDocument = By.xpath("//ul[@id='MAIL_ATTACHMENTS']//a[text()='Document']");
    private By btnDocAttach = By.xpath("//div[@id='attachPanel']//button[@id='btnAttach_page']");
    private By btnSend = By.xpath("//button[@id='send']");
    private By firstMail = By.xpath("//table[@class='auiTable mailList']//tr[1]/td[4]/a");
    private By btnFullSearch = By.xpath("//span[@id='btnShowFullSearchMode']//button");
    private By btnAttachFile = By.xpath("//button[@id='btnAttach']");
    private By tabInbox = By.xpath("//div[@class='auiTabs']//a[text()='Inbox']");

    //Identifiers from package properties
    private By packageNo = By.xpath("//div[text()='Package No']//..//div[2]");
    private By packageTitle = By.xpath("//div[text()='Package Title']//..//div[2]");
    private By packageType = By.xpath("//div[text()='Package Type']//..//div[2]");
    private By revision = By.xpath("//div[text()='Revision']//..//div[2]");

    //Identifiers from top left section
    private By version = By.xpath("//div[text()='Ver']//..//b");
    //Identifiers from events log table
    private By packageVersion = By.xpath("//table[@class='auiTable']//tbody//tr//td[3]");
    private By addBtn = By.xpath("//button[text()='Add']");

    Actions actions = new Actions(driver);


    /**
     * Method to send a package to other users
     *
     * @param sendToUser
     * @return
     */
    public void sendPackage(String sendToUser) {
        commonMethods.waitForElement(driver, sendPackageBtn);
        $(sendPackageBtn).click();
        $(packageRecipients).clear();
        $(packageRecipients).sendKeys(sendToUser);
        commonMethods.waitForElementExplicitly(3000);
        $(packageRecipients).sendKeys(Keys.ENTER);
        Faker faker = new Faker();
        $(packageSubject).sendKeys(sendToUser + "-test email " + faker.number().digits(3));
        $(sendBtn).click();
    }

    /**
     * Method to start a package review.
     * We select a template, provide values to the necessary fields and submit it.
     *
     * @param packageName
     * @param templateName
     */
    public String startReview(String packageName, String templateName) {
        commonMethods.waitForElement(driver, startReviewBtn);
        $(startReviewBtn).click();
        $(By.xpath("//a[text()='" + templateName + "']")).click();
        String reviewTitle = packageName + "-" + faker.name().fullName();
        $(reviewTitleElement).sendKeys(reviewTitle);
        return reviewTitle;
    }

    /**
     * Method to close the package
     */
    public void closePackage() {
        $(closePackage).click();
    }

    /**
     * Method to return the number of documents attached
     */
    public int returnNumberOfDocuments() {
        commonMethods.waitForElement(driver, documentsCount);
        List<WebElement> documentCountList = driver.findElements(documentsCount);
        return Integer.parseInt(documentCountList.get(1).getText());
    }

    /**
     * Click on the documents section to view the documents attached
     */
    public void clickDocumentsSection() {
        commonMethods.waitForElement(driver, documentsSection, 60);
        $(documentsSection).click();
    }

    /**
     * Method to return the document number from the table
     *
     * @return
     */
    public String returnDocumentNo() {
        return $(documentNumber).getText();
    }

    /**
     * Method to click on edit button
     */
    public void clickEditBtn() {
        commonMethods.waitForElement(driver, editBtn);
        $(editBtn).click();
    }

    /**
     * Method to attach documents to package
     *
     * @param documentNo
     */
    public void attachDocuments(String documentNo) {
        $(addDocumentsBtn).click();
        verifyAndSwitchFrame("packageDocumentSearch");
        DocumentPage documentPage = new DocumentPage();
        documentPage.searchDocumentNo(documentNo);
        documentPage.selectFirstFile();
        documentPage.switchToOriginal();
        documentPage.verifyAndSwitchFrame();
        $(addBtn).click();
    }

    /**
     * Method to return the count of the mails attached
     *
     * @param count
     */
    public void numberOfMails(int count) {
        commonMethods.waitForElementExplicitly(1500);
        commonMethods.waitForElement(driver, mailsCount);
        String noOfMails = $(mailsCount).getText();
        Assert.assertEquals("Mails count is not matched", Integer.parseInt(noOfMails), count);
    }

    /**
     * Method to return the package number from the package properties
     *
     * @return
     */
    public String returnPackageNumber() {
        commonMethods.waitForElement(driver, packageNo);
        return $(packageNo).getText();
    }

    /**
     * Method to return the package title from the package properties
     *
     * @return
     */
    public String returnPackageTitle() {
        return $(packageTitle).getText();
    }

    /**
     * Method to return the revision from the package properties
     *
     * @return
     */
    public String returnRevision() {
        return $(revision).getText();
    }

    /**
     * Method to return the package type from the package properties
     *
     * @return
     */
    public String returnPackageType() {
        return $(packageType).getText();
    }

    /**
     * Method to return the revision from the top left panel
     *
     * @return
     */
    public String returnVersion() {
        return $(version).getText();
    }

    /**
     * Method to return the package version from the events log table
     *
     * @return
     */
    public String returnPackageVersion() {
        return $(packageVersion).getText();
    }

    /**
     * Method to click on events log
     */
    public void clickEventsLog() {
        $(eventsLog).click();
    }

    /**
     * Method to click on submit button
     */
    public void clickSubmitBtn() {
        commonMethods.waitForElement(driver, submitBtn);
        $(submitBtn).click();
        commonMethods.waitForElementExplicitly(4000);
    }

    public void clickAttachmentsSection() {
        commonMethods.waitForElement(driver, attachmentsSection, 30);
        $(attachmentsSection).click();
    }

    public void attachAndVerifyFile() {
        commonMethods.waitForElement(driver, attachFiles);
        $(attachFiles).click();
        commonMethods.waitForElementExplicitly(4000);
        verifyAndSwitchFrame("attachFiles-frame");
        $(documentAttachPanel).sendKeys(filePath + "street_plan.pdf");
        commonMethods.waitForElementExplicitly(4000);
        verifyAndSwitchFrame();
        $(auiAttachFilesBtn).click();
        commonMethods.waitForElementExplicitly(6000);
        verifyAndSwitchFrame("attachFiles-frame");
        commonMethods.waitForElement(driver, uploadedTxt);
        verifyAndSwitchFrame();
        $(auiCloseBtn).click();
        commonMethods.waitForElementExplicitly(3000);
        Assert.assertTrue("File attachment is not displayed", $(attachmentFile).isDisplayed());
    }

    public void exportPackageOnAll() {
        commonMethods.waitForElementExplicitly(5000);
        commonMethods.waitForElement(driver, moreBtn);
        $(moreBtn).click();
        commonMethods.waitForElement(driver, exportPackage);
        $(exportPackage).click();
        int select = driver.findElements(selectCheckBoxOnExport).size();
        boolean flag = false;
        for (int iterator = 1; iterator <= select; iterator++) {
            $(By.xpath("(//td//input[@type='checkbox'])[" + iterator + "]")).setSelected(true);
            flag = true;
        }
        Assert.assertTrue(flag);
        $(exportBtn).click();
        commonMethods.waitForElementExplicitly(4000);
    }

    /**
     * Method to switch frame to package document search
     */
    public void switchPackageDocSearch() {
        switchToOriginal();
        verifyAndSwitchFrame();
        verifyAndSwitchFrame("packageDocumentSearch");
    }

    /**
     * Method to attach documents to package
     *
     * @param documentNo
     */
    public void verifyDocInPackage(String documentNo) {
        $(addDocumentsBtn).click();
        verifyAndSwitchFrame("packageDocumentSearch");
        DocumentPage documentPage = new DocumentPage();
        documentPage.searchDocumentNo(documentNo);
        Assert.assertFalse("No records displayed", documentPage.checkEmptyRecords());
    }

    /**
     * Method to click on Add button in add documents window
     */
    public void clickAdd() {
        $(addBtn).click();
    }

    /**
     * Method to return the document numbers from the table
     *
     * @return
     */
    public List<String> returnDocuments() {
        return commonMethods.getValues(documentNumber);
    }

    /**
     * Click on the mails section to view the mails attached
     */
    public void clickMailsSection() {
        commonMethods.waitForElement(driver, mailsSections, 60);
        $(mailsSections).click();
    }

    /**
     * Method to click on New Mail button present in mails section
     */
    public void clickNewMail() {
        commonMethods.waitForElement(driver, btnNewMail, 60);
        $(btnNewMail).click();
    }

    /**
     * Method to click Attach button inside new mail tab
     */
    public void clickAttach() {
        commonMethods.waitForElement(driver, btnAttach, 60);
        $(btnAttach).click();
    }

    /**
     * Method to click on Document inside Attach button of new mail tab
     */
    public void clickDocument() {
        commonMethods.waitForElement(driver, btnDocument);
        $(btnDocument).click();
    }

    /**
     * Method to click on attach button after selecting documents
     */
    public void clickDocAttach() {
        commonMethods.waitForElement(driver, btnDocAttach);
        actions.moveToElement($(btnDocAttach)).click().build().perform();
    }

    /**
     * Method to click on Send button in compose mail tab
     */
    public void clickSend() {
        commonMethods.waitForElement(driver, btnSend, 30);
        $(btnSend).click();

    }

    /**
     * Method to click first mail present in the mail section of package
     */
    public void clickFirstMail() {
        commonMethods.waitForElement(driver, firstMail, 60);
        $(firstMail).click();
    }

    /**
     * Method to click on package title in view mail page
     */
    public void clickPackageTitle(String packageId) {
        By xpath = By.xpath("//div[@class='auiCollapsibleSection-body']//table//tr//td/span[text()='" + packageId + "']/../following-sibling::td//a");
        commonMethods.waitForElement(driver, xpath, 60);
        $(xpath).click();
    }

    /**
     * Method to click on Open in full search button
     */
    public void clickOnFullSearch() {
        commonMethods.waitForElement(driver, btnFullSearch, 60);
        $(btnFullSearch).click();
    }

    /**
     * Method to click on attach file button in full search screen of documents
     */
    public void attachFile() {
        commonMethods.waitForElement(driver, btnAttachFile, 60);
        $(btnAttachFile).click();
    }

    /**
     * Method to click on attach file button in full search screen of documents
     */
    public boolean returnPackageId(String packageId) {
        commonMethods.waitForElement(driver, btnNewMail, 30);
        commonMethods.waitForElementExplicitly(2000);
        return $(By.xpath("//div[@class='auiCollapsibleSection-body']//table//tr//td/span[text()='" + packageId + "']/../following-sibling::td//a")).isDisplayed();
    }

    /**
     * Method to click on Inbox
     */
    public void clickInbox() {
        commonMethods.waitForElement(driver, btnNewMail, 30);
        $(tabInbox).click();
    }
}

