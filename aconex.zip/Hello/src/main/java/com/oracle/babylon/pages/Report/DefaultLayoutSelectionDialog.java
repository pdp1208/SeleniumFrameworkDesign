package com.oracle.babylon.pages.Report;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import static com.codeborne.selenide.Condition.appear;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

/**
 * This is a page object class for Layout selection dialog.
 *
 */
public class DefaultLayoutSelectionDialog {

    String defaultLayoutSelectionPopupLocator = "//*[@id='select-default-layout']//ancestor::div[@class='auiModal-content']";
    private By defaultLayoutSelectionPopup = By.xpath(defaultLayoutSelectionPopupLocator);
    private By layoutListDropDown = By.xpath("//*[@id='select-default-layout-list']");
    private By layoutAvailableOptions = By.xpath("//*[@id='select-default-layout-list']//option");
    private Select layoutSelect;

    /**
     * Method to wait for layout selection dialog to appear.
     *
     */
    public void waitForPopupToOpean(){
        $(defaultLayoutSelectionPopup).waitUntil(appear, 10000);
    }

    /**
     * Method to select default layout from the dropdown.
     *
     * @param layoutName - Name of the layout to be selected.
     */
    public void selctDefaultlayout(String layoutName){
        layoutSelect = new Select($(layoutListDropDown));
        layoutSelect.selectByValue(layoutName);
    }

    /**
     * Method to save default layout selection.
     *
     */
    public void save(){
        $(By.xpath(defaultLayoutSelectionPopupLocator + "//*[@class='auiButton primary']")).click();
    }

    /**
     * Method to cancel default layout selection.
     *
     */
    public void cancel(){
        $(By.xpath(defaultLayoutSelectionPopupLocator + "//*[@class='auiButton']")).click();
    }

    /**
     * Method to verify list of available layouts.
     *
     */
    public void verifyListOfAvailableLayouts(List<String> expectedLayoutList){
        AtomicInteger index = new AtomicInteger();
        $$(layoutAvailableOptions).forEach(
                option -> $(option).shouldHave(Condition.exactValue(expectedLayoutList.get(index.getAndIncrement())))
        );
    }
}
