package com.oracle.babylon.pages.Document;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

import static com.codeborne.selenide.Selenide.$;

public class CreatePlaceholdersPage extends AddDocumentsPage {

    private By hdrCreatePlaceholders = By.xpath("//h3[contains(text(),'Create Placeholders')]");
    private By radiobtnFromExcel = By.xpath("//input[@value='fromExcel']");
    private By radiobtnManually = By.xpath("//input[@value='manual']");
    private By lnkTemplateMetadata = By.xpath("//a[text()='TemplateMetadata.xls']");
    private By lblCreatePlaceholders = By.xpath("//label[text()='Select how to create the placeholders']");
    private By btnX = By.xpath("//form[@name='uploadFilesModalForm']//div[@class='auiModal-close']");
    private By btnNext = By.xpath("//form[@name='uploadFilesModalForm']//button[text()='Next']");
    private By btnCancel = By.xpath("//form[@name='uploadFilesModalForm']//button[text()='Cancel']");
    private By pageTitle = By.xpath("//div[@id='header']//h1");
    private By txtBoxPlaceHoldersCount = By.xpath("//input[@id='numberOfPlaceholdersInput']");
    private By sltFile = By.xpath("//div[@class='files']//li//div[@class='placeholder ng-binding ng-scope']");

    /**
     * Method to navigate to Document and verify for the title of the page
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Documents", "Add/Update Placeholders");
        commonMethods.waitForElementExplicitly(3000);
        Assert.assertTrue(verifyPageTitle(hdrCreatePlaceholders));
    }

    /**
     * Method to verify create Placeholders popup window options
     */
    public void verifyCreatePlaceholdersOptions() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver,hdrCreatePlaceholders,60);
        Assert.assertTrue($(radiobtnFromExcel).isDisplayed());
        Assert.assertTrue($(radiobtnFromExcel).isSelected());
        Assert.assertTrue($(radiobtnManually).isDisplayed());
        Assert.assertTrue($(lnkTemplateMetadata).isDisplayed());
        Assert.assertTrue($(lblCreatePlaceholders).isDisplayed());
        Assert.assertTrue($(btnX).isDisplayed());
        Assert.assertTrue($(btnNext).isDisplayed());
    }

    /**
     * Method to click on Next button
     */
    public void clickNext() {
        commonMethods.waitForElement(driver, btnNext, 60);
        navigator.getElementInView(btnNext);
        $(btnNext).click();
    }

    /**
     * Method to select upload type
     */
    public void selectUploadType(String type) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, hdrCreatePlaceholders, 60);
        if(type.equalsIgnoreCase("manually")) {
            commonMethods.waitForElement(driver, radiobtnManually);
            $(radiobtnManually).click();
        }
        else if(type.equalsIgnoreCase("from excel")) {
            commonMethods.waitForElement(driver, radiobtnFromExcel);
            $(radiobtnFromExcel).click();
        }
    }

    /**
     * Method to verify create place holders number field
     */
    public void verifyCreatePlaceholders(int lowerValue1, int lowerValue2, int upperValue1, int upperValue2) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(1000);
        Assert.assertTrue($(txtBoxPlaceHoldersCount).isDisplayed());
        Assert.assertEquals("1", $(txtBoxPlaceHoldersCount).getValue());
        Assert.assertTrue($(btnNext).isEnabled());
        enterPlaceHolderCountField(String.valueOf(lowerValue1));
        Assert.assertFalse($(btnNext).isEnabled());
        enterPlaceHolderCountField(String.valueOf(lowerValue2));
        Assert.assertTrue($(btnNext).isEnabled());
        enterPlaceHolderCountField(String.valueOf(upperValue1));
        Assert.assertTrue($(btnNext).isEnabled());
        enterPlaceHolderCountField(String.valueOf(upperValue2));
        Assert.assertFalse($(btnNext).isEnabled());
    }

    /**
     * Method to enter value in place holders number field
     */
    public void enterPlaceHolderCountField(String value) {
        verifyAndSwitchFrame();
        $(txtBoxPlaceHoldersCount).clear();
        commonMethods.waitForElementExplicitly(500);
        $(txtBoxPlaceHoldersCount).sendKeys(value);
    }

    /**
     * Method to select files in LHP of create Placeholder page
     */
    public void selectFile(int index) {
        List<WebElement> list = driver.findElements(sltFile);
        list.get(index - 1).click();
    }

}

