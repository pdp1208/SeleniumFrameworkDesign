package com.oracle.babylon.pages.Report;

import com.codeborne.selenide.SelenideElement;
import com.oracle.babylon.Utils.helper.Navigator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Condition.appears;
import static com.codeborne.selenide.Selenide.*;

public class PrefilterPopup extends FilterContolPanel {

    By filterDialogLocator = By.xpath("//*[contains(@id,'filter-panel')]");
    public SelenideElement filterDialog = $(filterDialogLocator);
    public By filtersDisplayed = By.xpath("//*[contains(@id,'filter-panel')]//*[contains(@class,'label')]");
    public String filterFieldLocator = "//*[contains(.,'filter')]//*[contains(@id,'filter-panel')]//div[contains(text(),'COLUMN_NAME')]/following::*[1]";
    public String filterField = "//*[contains(@id,'filter-panel')]//div[contains(text(),'COLUMN_NAME')]/following::input[1]";
    public String multiValueSelector = "//*[contains(@class,'input')]";
    public String filterValueList = "//*[contains(@class,'input')]/following::ul[1]";
    public String filterValue =    "//*[contains(@class,'input')]/following::ul[1]/li";
    public By apply = By.xpath("//*[contains(text(),'Apply')]");
    public By cancel = By.xpath("//button[@type='button'][contains(text(),'Cancel')]");
    public By ok = By.xpath("//*[text()='OK']");
    public By exportFormats = By.xpath("//*[contains(@id, 'export-options')]//select/option");

    /**
     * Method to get available filters on pre-filter popup.
     *
     */
    public List<String> getAvailableFilters() {
        commonMethods.waitForElement(driver,filterDialogLocator, 40);
        return filterDialog.$$(filtersDisplayed).texts();
    }

    public List<String> getFilterValuesSelected(String columnName){
        switchTo().defaultContent();
        verifyAndSwitchFrame("frameMain");
        List<String> selectedFilterValues = new ArrayList<String>();
        String filterFieldLocatorWithColumnName = filterFieldLocator.replace("COLUMN_NAME", columnName);
        String elementType = $(By.xpath(filterField.replace("COLUMN_NAME", columnName))).getAttribute("class");
        if(elementType.contains("date") || elementType.contains("search")){
            $(By.xpath(filterFieldLocatorWithColumnName + multiValueSelector)).click();
            commonMethods.waitForElement(driver,By.xpath(filterFieldLocatorWithColumnName + filterValueList),4);
            for(int i=0;i<$$(By.xpath(filterFieldLocatorWithColumnName + filterValue)).size();i++){
                if(elementType.contains("date")){
                    if ($(By.xpath("(" + filterFieldLocatorWithColumnName + filterValue + ")[" + (i + 1) + "]")).getAttribute("class").equalsIgnoreCase("active")) {
                        selectedFilterValues.add($(By.xpath("(" + filterFieldLocatorWithColumnName + filterValue + ")[" + (i + 1) + "]")).getText());
                        $(ok).click();
                        break;
                    }
                } else {
                    if ($(By.xpath("(" + filterFieldLocatorWithColumnName + filterValue + "/input)[" + (i + 1) + "]")).isSelected()) {
                        selectedFilterValues.add($(By.xpath("(" + filterFieldLocatorWithColumnName + filterValue + ")[" + (i + 1) + "]")).getText());
                    }
                }
            }
            $(By.xpath(filterFieldLocatorWithColumnName + multiValueSelector)).click();
        } else {
            selectedFilterValues.add($(By.xpath(filterFieldLocatorWithColumnName + "/input")).getValue());
        }
        return selectedFilterValues;
    }

    /**
     * Method to apply filters on pre-filter popup.
     *
     */
    public void applyFilters() {
        $(apply).click();
    }

    /**
     * Method to cancel pre-filter popup.
     *
     */
    public void cancelFilters() {
        $(cancel).click();
    }

    /**
     * Method to get available export formats.
     *
     */
    public List<String> getExportFormats() {
        return $$(exportFormats).texts();
    }
}
