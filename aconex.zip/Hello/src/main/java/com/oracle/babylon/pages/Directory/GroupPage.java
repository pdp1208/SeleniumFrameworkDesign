package com.oracle.babylon.pages.Directory;

import static com.codeborne.selenide.Selenide.$;

import org.junit.Assert;
import org.openqa.selenium.By;

import java.util.List;

/**
 *
 */
public class GroupPage extends DirectoryPage {

    /**
     * Initialization of idenifiers
     */
    private By editUsersBtn = By.xpath("//button[@id='btnEditUsers']//div[text()='Edit Users']");
    private By pageTitle = By.xpath("//h1[contains(text(),'Edit Group')]");
    private By newGroupTitle = By.xpath("//h1[contains(text(),'New Group')]");
    private By noUsers = By.xpath("//td[text()='Verify to create Mailing Group']");
    private By groupNameElement = By.xpath("//input[@name='GROUP_NAME']");
    private By createdBy = By.xpath("//td[text()='Created By']");
    private By project = By.xpath("//td[text()='Project']");
    private By groupNameHeader = By.xpath("//td[text()='Group Name']");
    private By userCol = By.xpath("//th[text()='User']");
    private By orgCol = By.xpath("//th[text()='Organization']");
    private By lockGroup = By.xpath("//input[@name='LOCK_GROUP']");


    /**
     * Method to validate the buttons in the New Group page
     * @return
     */
    public boolean verifyNewGroupButtons() {
        Assert.assertTrue($(editUsersBtn).isDisplayed());
        Assert.assertTrue($(saveBtn).isDisplayed());
        return true;
    }

    /**
     * Method to validate the page title in Edit Group Page
     */
    public void verifyPageTitle() {
        commonMethods.waitForElement(driver, pageTitle);
        Assert.assertTrue($(pageTitle).isDisplayed());
    }

    /**
     * Method to validate the page title in New Group Page
     */
    public void verifyNewGroupTitle() {
        Assert.assertTrue($(newGroupTitle).isDisplayed());
    }


    /**
     * Method to validate the buttons in the Edit Group Page
     * @return
     */
    public boolean verifyButtons() {
        commonMethods.waitForElement(driver,editUsersBtn);
        Assert.assertTrue($(editUsersBtn).isDisplayed());
        Assert.assertTrue($(deleteBtn).isDisplayed());
        Assert.assertTrue($(saveBtn).isDisplayed());
        return true;
    }

    /**
     * Method to validate if the user is displayed in the results table
     * @param userId
     * @return
     */
    public boolean verifyUser(String userId) {
        commonMethods.waitForElementExplicitly(2000);
        By by = By.xpath("//table[@class='dataTable']//td[contains(text(),'" + userId + "')]");
        return $(by).isDisplayed();
    }

    /**
     * Method to delete the group
     * @return
     */
    public String deleteGroup() {
        $(deleteBtn).click();
        String text = commonMethods.returnAlertText(driver);
        commonMethods.acceptAlert(driver);
        return text;
    }

    /**
     * Method to lock the group
     * @param value
     */
    public void setLockGroup(boolean value) {
        $(lockGroup).setSelected(value);
    }

    /**
     * Method to verify the UI of the group page
     */
    public void verifyUI() {
        Assert.assertTrue($(groupNameElement).isDisplayed());
        Assert.assertTrue($(lockGroup).isDisplayed());
        Assert.assertTrue($(project).isDisplayed());
        Assert.assertTrue($(createdBy).isDisplayed());
        Assert.assertTrue($(groupNameHeader).isDisplayed());
        Assert.assertTrue($(userCol).isDisplayed());
        Assert.assertTrue($(orgCol).isDisplayed());
    }

    /**
     * Method to return and verify the group name present
     * @param groupName
     */
    public void verifyGroupName(String groupName) {
        Assert.assertTrue($(groupNameElement).getAttribute("value").equalsIgnoreCase(groupName));
    }


    /**
     * Method to click on the edit users button
     */
    public void editUsers() {
        $(editUsersBtn).click();
    }


    /**
     * Method to validate if the no users are displayed
     * @return
     */
    public boolean isNoUserMsgDisplayed() {
        return $(noUsers).isDisplayed();
    }
}
