package com.oracle.babylon.pages.Tasks;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.WebDriverRunner;
import com.oracle.babylon.Utils.helper.Navigator;
import com.oracle.babylon.pages.Mail.MailPage;
import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.util.ArrayList;
import java.util.List;

import static com.codeborne.selenide.Selenide.*;

public class TaskPage extends MailPage {

    public TaskPage() {
        this.driver = WebDriverRunner.getWebDriver();
    }

    //Initializing the web elements
    public By pageTitle = By.xpath("//h1[text()='My Tasks']");
    private By projectLogo = By.xpath("//div[@title='Click to view project details']");
    private By backButton = By.xpath("//button[@title='Back']");
    private By projectChangerArrow = By.xpath("//span[@class='oj-text-field-end' or @class='projectChanger-arrow']");
    private By unreadShareDocumentNumber = By.xpath("//tbody[@id='grid-group-body-unreadshare']//tr//td[1]");
    private By projectDetailsTitle = By.xpath("//div[@title='Click to view project details']");
    private By tasksMenu = By.xpath("//div[contains(text(),'Tasks')]");
    private By mailExpand = By.xpath("//div[@id='mail-header']//div[@class='podToggler podTogglerCollapsed']");
    private By documentsExpand = By.xpath("//div[@id='documents-header']//div[contains(@class,'podToggler')]");
    protected By loadingIcon = By.cssSelector(".loading_progress");
    private By allProjects = By.xpath("//div[@id='allProjects']");
    private By allProjectListTop = By.xpath("//ul[@class='oj-listbox-results']/li | //div[@class='projectChanger-list']//div");
    private By allProjectListLeft = By.xpath("//ul[@class='projectNodes']//li");
    private By supplierDocSection = By.xpath("//*[@id='supplierdocs-header']");
    private By submissionRequiredSupplierDoc = By.xpath("//*[@id='supplierdocssubmissionrequired']");
    private By assetsRegister = By.xpath("//li[text()='Asset Register']");
    private By projectDetails = By.xpath("//div[@class='projectDetailsPodDetails']");
    private By projectId = By.xpath("//td[contains(text(),'Project ID')]//following::td");
    private By viewAllInSubmittedSD = By.xpath("//*[@id='supplierdocssubmitted']//label[text()='View All']");
    private By insightsHeader = By.xpath("//*[@id='insights-header']//div[contains(text(),'Process Insights')]");
    private By lastUpdated = By.xpath("//div[contains(text(),'Last updated:')]");
    private By viewAllProcesses = By.xpath("//div[text()='View All Processes']");
    private By projectBannerHeading = By.xpath("//div[@class='project-banner-heading']");
    private By insightsFrame = By.xpath("//*[contains(@src,'insights')]");
    private By packagesReviewLinks = By.xpath("//div[@id='packages-portlet']//table//tbody//tr//span[@class='textlink']");
    private By mailsReviewLinks = By.xpath("//div[@id='mail-portlet']//table//tbody//tr//span[@class='textlink']");

    Navigator navigator = new Navigator();

    /**
     * Function to navigate to Task page
     */
    public void navigateAndVerifyPage() {
        commonMethods.waitForElementExplicitly(4000);
        getMenuSubmenu("Tasks", "My Tasks");
        verifyPageTitle(pageTitle);
    }

    /**
     * Function to click on link
     *
     * @linkname is the link name which has to be clicked
     */

    public void clickOnLink(String linkName) {
        By link = By.xpath("//li[contains(text(),'" + linkName + "')]");
        commonMethods.waitForElement(driver, link, 25);
        try {
            commonMethods.waitForElementExplicitly(2000);
            //$(By.xpath("//li[contains(text(),'" + linkName + "')]")).click();*/
            Actions action = new Actions(driver);
            action.moveToElement($(link)).click().perform();
        } catch (Exception e) {
            commonMethods.waitForElementExplicitly(2000);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", $(link));
            $(By.xpath("//li[contains(text(),'" + linkName + "')]")).click();
        }
    }

    /**
     * Function to click on Logo
     */
    public void clickOnLogo() {
        verifyAndSwitchFrame();
        commonMethods.clickOnElement(projectLogo);
    }

    /**
     * Function to navigate back
     */

    public void navigateBack() {
        commonMethods.clickOnElement(backButton);
    }

    /**
     * Function to verify mail or Document options displayed on task page
     *
     * @option refers to mail or Document options
     * @group1 refers to options available under mail or Document
     */

    public boolean verifyOptionDisplayed(String option, String group1) {
        verifyAndSwitchFrame();
        List<WebElement> unreadGroup = null;
        switch (option) {
            case "mail":
                unreadGroup = driver.findElements(By.xpath("//div[@id='mail-content']//td[contains(text(),'" + group1 + "')]"));
                break;
            case "transmittal":
                unreadGroup = driver.findElements(By.xpath("//div[@id='documents-content']//td[contains(text(),'" + group1 + "')]"));
                commonMethods.waitForElementExplicitly(1000);
                break;
        }
        if (unreadGroup.size() != 0) {
            return true;
        }
        return false;
    }

    /**
     * Function to return the count of each group under mail or Document
     *
     * @option refers to mail or Document options
     * @group refers to options available under mail or Document
     */

    public int returnOptionCount(String option, String group) {
        int count = 0;
        By unreadGroupValue = null;
        switch (option) {
            case "mail":
                if ($(mailExpand).exists()) {
                    $(mailExpand).click();
                }
                unreadGroupValue = By.xpath("//div[@id='mail-content']//td[contains(text(),'" + group + "')]//span");
                break;
            case "transmittal":
                if ($(mailExpand).exists()) {
                    $(mailExpand).click();
                }
                if ($(documentsExpand).exists()) {
                    $(documentsExpand).click();
                }
                unreadGroupValue = By.xpath("//div[@id='documents-content']//td[contains(text(),'" + group + "')]//span");
                commonMethods.waitForElementExplicitly(2000);
                break;
        }
        String value = $(unreadGroupValue).getText();
        String[] num = value.split("()");
        if (!(num.length > 1)) {
            return 0;
        }
        count = Integer.parseInt(num[1]);
        return count;
    }

    /**
     * Function to verify view All link available next to all groups
     *
     * @option refers to mail or Document options
     * @group refers to options available under mail or Document
     */

    public boolean verifyOptionViewAllAndClick(String option, String group) {
        By viewAll = null;
        switch (option) {
            case "mail":
                commonMethods.waitForElementExplicitly(2000);
                viewAll = By.xpath("//div[@id='mail-content']//td[contains(text(),'" + group + "')]//label[contains(text(),'View All')]");
                break;
            case "transmittal":
                viewAll = By.xpath("//div[@id='documents-content']//td[contains(text(),'" + group + "')]//label[contains(text(),'View All')]");
                break;
        }
        if (($(viewAll).isDisplayed())) {
            commonMethods.waitForElementExplicitly(2000);
            commonMethods.waitForElement(driver, viewAll, 25);
            $(viewAll).click();
            verifyPageTitle("Search Mail");
            return true;
        }
        return false;
    }

    /**
     * Function to verify list of projects on task page
     */
    public boolean verifyProjectList() {
        refresh();
        List<String> projectList1 = new ArrayList<>();
        List<String> projectList2 = new ArrayList<>();
        $(projectChangerArrow).click();
        List<WebElement> projectListTop = driver.findElements(allProjectListTop);
        for (WebElement project : projectListTop) {
            projectList1.add(project.getText());
        }
        verifyAndSwitchFrame();
        List<WebElement> projectListTaskPage = driver.findElements(allProjectListLeft);
        for (WebElement projectList : projectListTaskPage) {
            projectList2.add(projectList.getText());
        }
        if (projectList1.equals(projectList2)) {
            sleep(2000);
            return true;
        }
        return false;
    }

    /**
     * Function to click on Document Number of unread shares under Documents
     */

    public void clickOnDoumentLink() {
        $(unreadShareDocumentNumber).click();

    }

    /**
     * Function to verify number of rows under each options is not exceeding the count
     *
     * @count is the maximum number of rows that should be displayed
     */

    public boolean verifyCount(int count) {
        verifyAndSwitchFrame();
        List<WebElement> groupHead = driver.findElements(By.xpath("//thead[@class='grid-group-head ']"));
        for (WebElement element : groupHead) {
            String text = element.getText();
            String group = text.substring(0, text.indexOf("("));
            List<WebElement> rowList = driver.findElements(By.xpath("//thead//td[contains(text(),'" + group + "')]//..//..//following-sibling::tbody//tr"));
            if (rowList.size() > count) {
                return false;
            }
        }
        return true;
    }

    /**
     * Function to verify title is Displayed
     */

    public boolean verifyTitleDisplayed() {
        $(projectDetailsTitle).isDisplayed();
        return true;
    }

    /**
     * Function to verify Tasks Menu is present
     */
    public boolean verifyTasksMenuPresent() {
        return $(tasksMenu).isDisplayed();
    }

    public boolean verifyMenuOption(String menu, String submenu) {
        driver.switchTo().defaultContent();
        $(By.xpath("//button[@class='uiButton navBarButton']//div[text()='" + menu + "']")).click();
        return $(By.xpath("//div[@class='navBarPanel-menuItem' and contains(text(),'" + submenu + "' )]")).exists();
    }

    public void verifyDocTypeLabels(String instance) {
        verifyAndSwitchFrame();
        Assert.assertTrue($(documentsExpand).getText().contains(instance));
        Assert.assertTrue($(By.xpath("//div[@id='shortcuts-content']//li[contains(text(),'" + StringUtils.chop(instance) + " Register')]")).isDisplayed());
    }

    public void verifyAllProjectsLabel() {
        verifyAndSwitchFrame();
        $(allProjects).click();
        $(loadingIcon).should(Condition.disappear);

    }

    /**
     * Function to verify Multi file upload page title
     */

    public boolean verifyAddDocuments(String title) {
        commonMethods.waitForElement(driver, By.xpath("//button[contains(text(),'" + title + "')]"), 60);
        return $(By.xpath("//button[contains(text(),'" + title + "')]")).isDisplayed();
    }

	public boolean verifyUnreadMail(String mailNo) {
		By val = By.xpath("//tbody[@id='grid-group-body-unreadto']//span[contains(text(),'" + mailNo + "')]");
		for (int i = 0; i < 5; i++) {
			if ($(val).isDisplayed()) {
				break;
			} else {
				commonMethods.sleep(10000);
				refresh();
				verifyAndSwitchFrame();
			}
		}
		// commonMethods.waitForElement(driver,val,30);
		return $(val).isDisplayed();
	}

    /**
     * Function to click on view all
     *
     * @param group
     */
    public void clickOnViewAll(String group) {
        By link = By.xpath("//td[text()='" + group + "']//label[contains(text(),'View All')]");
        commonMethods.waitForElement(driver, link, 30);
        $(link).click();
    }

    public boolean verifyProjectPresent(String projectName) {
        List<String> projectList = new ArrayList<>();
        List<WebElement> projectListTaskPage = driver.findElements(By.xpath("//ul[@class='projectNodes']//li"));
        for (WebElement projectList1 : projectListTaskPage) {
            projectList.add(projectList1.getText());
        }
        if (projectList.contains(projectName)) {
            return true;
        } else {
            return false;
        }

    }

    public boolean verifyTaskOption() {
        driver.switchTo().defaultContent();
        return $(tasksMenu).isDisplayed();
    }

    public void navigateToReviewPackage(String reviewNo) {
        By awaitingReview = By.xpath("//div[text()=\"" + reviewNo + "\"]//..//..//*[@class='textlink']");
        commonMethods.waitForElement(driver, awaitingReview, 60);
        $(awaitingReview).click();
    }

    public void verifyInsightsSection() {
        commonMethods.waitForElement(driver, insightsHeader, 30);
        verifyAndSwitchFrame(insightsFrame);
        commonMethods.waitForElement(driver, lastUpdated, 30);
        commonMethods.waitForElement(driver, viewAllProcesses);
        $(viewAllProcesses).click();
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, projectBannerHeading, 80);
    }

    /**
     * Function to click on mailids, document numbers etc., hyperlinks from tasks page
     */
    public void clickOnLinks(String name) {
        verifyAndSwitchFrame();
        By xpath = By.xpath("//table[@class='grid-body-table dataTable']//td/div/span[contains(text(),'" + name + "')]");
        commonMethods.waitForElement(driver, xpath, 60);
        $(xpath).click();
    }

    /**
     * Function to verify awaiting workflow in tasks page
     */
    public boolean verifyAwaitingWF(String wfName) {
        return $(By.xpath("//tbody[@id='grid-group-body-awaitingreview']//span[contains(text(),'" + wfName + "')]")).isDisplayed();
    }

    public boolean verifySupplierDocLink(String supplierDocNo, String instance) {
        commonMethods.waitForElement(driver, supplierDocSection, 60);
        commonMethods.waitForElement(driver, submissionRequiredSupplierDoc);
        if (instance.equalsIgnoreCase("Submission Required"))
            return $(By.xpath("//tbody[@id='grid-group-body-supplierdocssubmissionrequired']//*[contains(text(),'" + supplierDocNo + "')]")).isDisplayed();
        else
            return $(By.xpath("//tbody[@id='grid-group-body-supplierdocssubmitted']//*[contains(text(),'" + supplierDocNo + "')]")).isDisplayed();
    }

    public void navigateToSubmittedSD(String supplierDocNo, String instance) {
        commonMethods.waitForElement(driver, supplierDocSection, 60);
        By submittedDoc;
        if (instance.equalsIgnoreCase("Submission Required"))
            submittedDoc = By.xpath("//tbody[@id='grid-group-body-supplierdocssubmissionrequired']//*[contains(text(),'" + supplierDocNo + "')]");
        else
            submittedDoc = By.xpath("//tbody[@id='grid-group-body-supplierdocssubmitted']//*[contains(text(),'" + supplierDocNo + "')]");
        commonMethods.waitForElement(driver, submittedDoc);
        $(submittedDoc).click();
    }

    /**
     * Method to click on asset register
     */
    public void clickAssetRegister() {
        commonMethods.waitForElement(driver, assetsRegister);
        $(assetsRegister).click();
    }

    /**
     * Method to click on the project details pane
     */
    public void clickProjectDetails() {
        $(projectDetails).click();
    }

    /**
     * Method to return the project id
     */
    public String returnProjectId() {
        return $(projectId).getText();
    }


    /**
     * Method to click View All under submitted supplier docs
     */
    public void clickViewAllUnderSubmitted() {
        commonMethods.waitForElement(driver, viewAllInSubmittedSD, 40);
        $(viewAllInSubmittedSD).click();
    }

    /**
     * Method to return sd submission required list size
     */
    public int getPackagesLink() {
        commonMethods.waitForElement(driver, supplierDocSection, 60);
        commonMethods.waitForElementExplicitly(3000);
        return $$(packagesReviewLinks).size();
    }

    /**
     * Method to click on sd submission required
     */
    public void clickOnPackagesLinks(int i) {
        $(By.xpath("(//div[@id='packages-portlet']//table//tbody//tr//span[@class='textlink'])[" + i +"]")).click();
    }

    /**
     * Method to return sd submission required list size
     */
    public int getMailsLink() {
        commonMethods.waitForElement(driver, supplierDocSection, 60);
        commonMethods.waitForElementExplicitly(3000);
        return $$(mailsReviewLinks).size();
    }

    /**
     * Method to click on sd submission required
     */
    public void clickOnMailsLinks(int i) {
        $(By.xpath("(//div[@id='mail-portlet']//table//tbody//tr//span[@class='textlink'])[" + i +"]")).click();
    }
}
