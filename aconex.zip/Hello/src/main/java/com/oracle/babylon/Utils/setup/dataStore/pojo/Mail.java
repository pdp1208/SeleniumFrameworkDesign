package com.oracle.babylon.Utils.setup.dataStore.pojo;

/**
 * Class which contains the fields related to mails, along with the respective setters and getters
 * Author : sai
 */
public class Mail {
    private String mailNumber;
    private String mailSubject;
    private String mailTypeId;
    private String responseRequired;
    private String responseRequiredDate;
    private String richMailText;
    private String attribute1;
    private String attribute2;
    private String totalAttachmentCount;
    private String mailBody;

    public String getMailNumber() {
        return mailNumber;
    }

    public void setMailNumber(String mailNumber) {
        this.mailNumber = mailNumber;
    }

    public String getMailSubject() {
        return mailSubject;
    }

    public void setMailSubject(String mailSubject) {
        this.mailSubject = mailSubject;
    }

    public String getMailTypeId() {
        return mailTypeId;
    }

    public void setMailTypeId(String mailTypeId) {
        this.mailTypeId = mailTypeId;
    }

    public String getResponseRequired() {
        return responseRequired;
    }

    public void setResponseRequired(String responseRequired) {
        this.responseRequired = responseRequired;
    }

    public String getResponseRequiredDate() {
        return responseRequiredDate;
    }

    public void setResponseRequiredDate(String responseRequiredDate) {
        this.responseRequiredDate = responseRequiredDate;
    }

    public String getAttribute1() {
        return attribute1;
    }

    public void setAttribute1(String attribute1) {
        this.attribute1 = attribute1;
    }

    public String getAttribute2() {
        return attribute2;
    }

    public void setAttribute2(String attribute2) {
        this.attribute2 = attribute2;
    }

    public String getRichMailText() {
        return richMailText;
    }

    public void setRichMailText(String richMailText) {
        this.richMailText = richMailText;
    }

    public void setTotalAttachments(String totalAttachmentCount) {
        this.totalAttachmentCount = totalAttachmentCount;
    }

    public String getTotalAttachments() {
        return totalAttachmentCount;
    }

    public void setMailBody(String mailBody) {
        this.mailBody = mailBody;
    }

    public String getMailBody() {
        return mailBody;
    }

}
