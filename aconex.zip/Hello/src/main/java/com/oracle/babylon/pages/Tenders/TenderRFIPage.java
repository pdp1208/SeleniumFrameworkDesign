package com.oracle.babylon.pages.Tenders;

import com.codeborne.selenide.Condition;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import java.io.File;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Selenide.$;

public class TenderRFIPage extends TenderPage {

    private By createRfiBtn = By.xpath("//div[contains(text(),'Create RFI')]");
    private By rfiSubject = By.xpath("//input[@name='subject']");
    private By rfiBody = By.xpath("//div[@id='cke_1_contents']");
    private By rfiSendBtn = By.xpath("//div[contains(text(),'Send')]");
    private By bodyFrame = By.xpath("//iframe[@class='cke_wysiwyg_frame cke_reset']");
    private By rfiMailNumber = By.xpath("//h2[@id='mailNumber']");
    private By actionDropDown = By.id("btnActionsMenu");
    private By attachDropDown = By.xpath("//div[contains(text(),'Attach')]");
    private By btnAttach = By.xpath("//button[@id='attachLocalFilePanel-commit']");
    private By txtBoxChooseFile = By.xpath("//div[@class='attachLocalFileRow']/input[@name='FILE_PATH_NAME']");
    private By noRfi = By.xpath("//div[text()='No RFI has been created']");
    private By submissionCheck = By.xpath("//div[text()='This tender is closed. You can no longer create a submission']");
    private By attachLocalFiles = By.xpath("//button[@id='btnAttachLocalFiles']");
    private By rfiHeader = By.xpath("//td[contains(text(),'Tender RFI')]//span[contains(text(),'(Confidential)')]");
    private By tenderNumberField = By.xpath("//td[contains(text(),'Tender No')]//..//td[2]");
    private By tenderTitleField = By.xpath("//td[contains(text(),'Tender Title')]//..//td[2]");
    private By toTxtBox = By.xpath("//td//span[contains(text(),'To')]//..//..//div//div");
    private By bccTxtBox = By.xpath("//td//span[contains(text(),'Bcc')]//..//..//div//div");
    private By subject = By.xpath("//span[@required='required' and text()='Subject']//..//..//td[2]");
    private By bodyField = By.xpath("//textarea[@class='uiTextAreaField-field ']");
    private By richTxtbodyField = By.xpath("//body[contains(@class,'cke_editable')]");
    private By attachLocalFileHeader = By.xpath("//div[@id='attachLocalFilePanel']//span[text()='Attach Local File']");
    private By attachAnotherFile = By.xpath("//div[@id='attachLocalFilePanel']//div[@id='attachAnotherFileLink']");
    private By attachLocalFile = By.xpath("//div[@id='attachLocalFilePanel']//div[@class='attachLocalFileRow']//input");
    private By fileName = By.xpath("//div[@id='attachLocalFilePanel']//div[@class='attachLocalFileRow']//input");
    private By deleteIcon = By.xpath("//div[@id='attachLocalFilePanel']//div[@class='attachLocalFileRow']//div[@class='auiIcon trash']");
    private By fileNameCell = By.xpath("//span[text()='Attachments']//..//..//td[2]//td[2]");
    private By tableDeleteIcon = By.xpath("//td//div[@class='auiIcon trash']");
    private By bccField = By.xpath("//*[text()='Bcc']//following::td");
    private By fromField = By.xpath("//td[text()='From']//following::td");
    private By toField = By.xpath("//*[text()='To']//following::td");
    private By titleField = By.xpath("//td[text()='Tender Title']//..//td[2]");
    private By viewMailList = By.xpath("//button[@id='btnViewMailList']");
    private By subjectMandatory = By.xpath("//span[text()='Subject']//following::span");
    private By tenderBodyFrame = By.xpath("//iframe[@class='cke_wysiwyg_frame cke_reset']");
    private By replyBtn = By.xpath("//button[@id='btnReply']");
    private By referenceNumber = By.xpath("//div[contains(text(),'Reference No')]//span");
    private By rfiCancelBtn = By.xpath("//button[@id='attachLocalFilePanel-cancel']//div[text()='Cancel']");


    /**
     * Method to click create RFI
     */
    public void clickCreateRfi() {
        $(createRfiBtn).click();
    }

    /**
     * Method to reply to RFI
     */
    public void clickReply() {
        commonMethods.waitForElementExplicitly(500);
        commonMethods.getElementInViewAndUp(replyBtn);
        $(replyBtn).click();
    }


    /**
     * common method used for both create RFI and reply RFI
     *
     * @param attribute
     */
    public void fillFields(String attribute) {
        commonMethods.waitForElementExplicitly(3000);
        Map<String, String> table = dataStore.getTable(attribute);
        //According to the keys passed in the table, we select the fields
        for (String tableData : table.keySet()) {
            switch (tableData) {
                case "Subject":
                    enterRfiSubject(table.get(tableData));
                    break;
                case "Body":
                    enterRfiBody(table.get(tableData));
                    break;
                case "Local Attachment":
                    attachLocalFile(table.get(tableData));
                    verifyAndSwitchFrame();
                    break;
            }
        }
    }

    /**
     * Method to enter create subject
     */
    public void enterRfiSubject(String subject) {
        $(rfiSubject).clear();
        $(rfiSubject).sendKeys(subject);
    }

    /**
     * Method to enter create Body
     */
    public void enterRfiBody(String body) {
        if ($(tenderBodyFrame).isDisplayed()) {
            commonMethods.switchToFrame(driver, tenderBodyFrame);
            $(richTxtbodyField).click();
            $(richTxtbodyField).sendKeys(body);
        } else {
            $(bodyField).sendKeys(body);
        }
    }

    /**
     * Method to send rfi
     */
    public String sendRfi() {
        commonMethods.waitForElement(driver,rfiSendBtn);
        $(rfiSendBtn).click();
        commonMethods.waitForElementExplicitly(3000);
        return $(rfiMailNumber).text();
    }

    /**
     * Method to click send rfi
     */
    public void clickSendRfi() {
        $(rfiSendBtn).click();
    }


    /**
     * Method to click view mail list button
     */
    public void clickViewMailList() {
        commonMethods.waitForElement(driver, viewMailList);
        commonMethods.scrollToTop(driver);
        $(viewMailList).click();
    }


    /**
     * Method to open rfi tender
     */
    public void openRfi(String rfiMailNumber) {
        verifyAndSwitchFrame();
        $(By.xpath("//table[@class='grid-body-table dataTable']//tr[td[contains(.,'" + rfiMailNumber + "')]]//td[2]//span")).click();
    }


    /**
     * Method to get rfi number
     */
    public String getRfiNumber() {
        commonMethods.scrollToTop(driver);
        return $(rfiMailNumber).text();
    }

    /**
     * Method to cancel tender
     *
     * @param action action to be performed on tender.
     */
    public void selectActionForTender(String action) {
        verifyAndSwitchFrame();
        $(actionDropDown).waitUntil(Condition.appears, 30000).click();
        switch (action) {
            case "CANCEL":
                $(By.xpath("//div[@id='cancelTenderItem']")).waitUntil(Condition.appears, 4000).click();
                $(By.id("pnlCancelTender-commit")).waitUntil(Condition.appears, 4000).click();
                break;
        }
    }

    /**
     * Function to Attach a Local File to tender invitation page
     *
     * @param fileName
     */
    public void attachLocalFile(String fileName) {
        verifyAndSwitchFrame();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,-1000)", "");
        commonMethods.waitForElement(driver, attachDropDown);
        commonMethods.getElementInViewAndUp(attachDropDown);
        $(attachDropDown).click();
        commonMethods.waitForElementExplicitly(500);
        commonMethods.waitForElement(driver, btnAttach, 30);
        $(txtBoxChooseFile).sendKeys(new File(configFileReader.getTestDataPath() + "/" + fileName).getAbsolutePath());
        $(btnAttach).click();
        commonMethods.waitForElementExplicitly(5000);
    }

    /**
     * Method to verify mail number present in tender rfi page.
     */
    public boolean verifyRFIMail(String mailId) {
        commonMethods.waitForElement(driver, rfiTab, 60);
        return $(By.xpath("//h2[contains(text(),'" + mailId + "')]")).isDisplayed();
    }

    /**
     * Method to return if the message no rfi has been created is displayed
     *
     * @return
     */
    public boolean returnNoRfi() {
        commonMethods.waitForElement(driver, noRfi);
        return $(noRfi).isDisplayed();
    }

    /**
     * Validate if the tender submission is allowed after closed date
     * @return
     */
    public boolean submissionMessage(){
        return $(submissionCheck).isDisplayed();
    }
    /**
     * Method to verify if the buttons are present in the UI
     */
    public void verifyUI() {
        commonMethods.waitForElementExplicitly(4000);
        Assert.assertTrue($(attachLocalFiles).isDisplayed());
        Assert.assertTrue($(sendBtn).isDisplayed());
        Assert.assertTrue($(rfiHeader).isDisplayed());
        if ($(bodyField).isDisplayed()) {
            Assert.assertTrue($(bodyField).isDisplayed());
        } else {
            commonMethods.switchToFrame(driver, tenderBodyFrame);
            Assert.assertTrue($(richTxtbodyField).isDisplayed());
            verifyAndSwitchFrame();
        }
        Assert.assertTrue($(subject).isDisplayed());
    }


    /**
     * Method to verify the tender number displayed
     *
     * @param tenderNumber
     */
    public void verifyTenderNumber(String tenderNumber) {
        Assert.assertTrue($(tenderNumberField).getText().equalsIgnoreCase(tenderNumber));
    }

    /**
     * Method to verify the tender title displayed
     *
     * @param tenderTitle
     */
    public void verifyTenderTitle(String tenderTitle) {
        Assert.assertTrue($(tenderTitleField).getText().equalsIgnoreCase(tenderTitle));
    }

    /**
     * Method to verify the recipient for "To" group
     * @param fullName
     * @param organization
     * @param recipientStr
     */
    public void verifyToRecipient(String fullName, String organization, String recipientStr) {
        String text = "";
        if (recipientStr.equals("to")) {
            text = $(toTxtBox).getText();
        } else if (recipientStr.equals("bcc")) {
            text = $(bccTxtBox).getText();
        }

        Assert.assertTrue(text.contains(fullName));
        Assert.assertTrue(text.contains(organization));
    }

    /**
     * Method to click on the attach button
     */
    public void clickAttachBtn() {
        $(attachLocalFiles).click();
    }

    /**
     * Method to validate the options present in attach window
     */
    public void verifyAttachOptions() {
        Assert.assertTrue($(attachLocalFileHeader).isDisplayed());
        Assert.assertTrue($(attachAnotherFile).isDisplayed());
        Assert.assertTrue($(attachLocalFile).isDisplayed());
        //Assert.assertTrue($(deleteIcon).isDisplayed());
    }

    /**
     * Verifies attach file operation
     * Enter the file name
     * Clicks attach file
     * Clicks attach another file
     * Enter the file name
     * Deletes both the file by clicking on trash icon
     *
     * @param list
     */
    public void verifyAttachFile(List<String> list) {
        String fileName = new File(configFileReader.getTestDataPath() + "/" + list.get(0)).getAbsolutePath();
        $(attachLocalFile).sendKeys(fileName);
        clickAttachAnotherFile();
        List<WebElement> filesList = driver.findElements(attachLocalFile);
        filesList.get(1).sendKeys(fileName);
        $(btnAttach).click();
        commonMethods.waitForElementExplicitly(10000);
        Assert.assertTrue($(fileNameCell).isDisplayed());
        List<WebElement> deleteIconList = driver.findElements(tableDeleteIcon);
        for (WebElement element : deleteIconList) {
            $(element).click();
        }
        Assert.assertFalse($(fileNameCell).isDisplayed());
    }

    /**
     * Method to cancel the file attach option
     *
     * @param list
     */
    public void cancelFileAttach(List<String> list) {
        String fileName = new File(configFileReader.getTestDataPath() + "/" + list.get(0)).getAbsolutePath();
        $(attachLocalFile).sendKeys(fileName);
        commonMethods.waitForElementExplicitly(1000);
        $(rfiCancelBtn).click();
    }

    /**
     * Method to attach a file by clicking on the attach button
     *
     * @param list
     */
    public void attachFile(List<String> list) {
        for (String fileName : list) {
            String file = new File(configFileReader.getTestDataPath() + "/" + fileName).getAbsolutePath();
            $(attachLocalFile).sendKeys(file);
            $(btnAttach).click();
        }
    }

    /**
     * Method to click on attach another file button
     */
    public void clickAttachAnotherFile() {
        $(attachAnotherFile).click();
    }

    /**
     * Method to return the RFI Title
     *
     * @return
     */
    public String returnRfiTitle() {
        return $(titleField).getText();
    }

    /**
     * Returns the name of the user and the organization it belongs to
     *
     * @return
     */
    public String returnBccRecipient() {
        return $(bccField).getText();
    }

    /**
     * Return the value of the To Field
     * @return
     */
    public String returnToRecipient(){
        return $(toField).getText();
    }

    /**
     * Return if field to field is displayed
     * @return
     */
    public boolean isToFieldDisplayed(){
        return $(toField).isDisplayed();
    }
    /**
     * Return Initiator user name and it's organization
     *
     * @return
     */
    public String returnInitiator() {
        return $(fromField).getText();
    }

    /**
     * Method to verify if bcc is displayed
     * @return
     */
    public boolean isBccDisplayed(){
        commonMethods.waitForElementExplicitly(1000);
        return $(bccField).isDisplayed();
    }

    /**
     * Method to verify if from field is displayed
     * @return
     */
    public boolean isFromDisplayed(){
        commonMethods.waitForElementExplicitly(1000);
        return $(fromField).isDisplayed();
    }

    /**
     * Method to validate if the subject is amandatory field
     * @return
     */
    public boolean validateSubjectMandatory() {
        return $(subjectMandatory).isDisplayed();
    }

    /**
     * Method to create RFI
     *
     * @param attribute
     * @param mailId
     */
    public void createRFI(String attribute, String mailId) {
        Map<String, Map<String, Object>> mapOfMap = new Hashtable<>();
        Map<String, Object> mailMap = new Hashtable<>();
        clickCreateRfi();
        commonMethods.waitForElementExplicitly(2000);
        Assert.assertTrue(validateSubjectMandatory());
        fillFields(attribute);
        verifyAndSwitchFrame();
        String rfiMailNumber = sendRfi();
        mailMap.put("mail_num", rfiMailNumber);
        mapOfMap.put(mailId, mailMap);
        dataSetup.fileWrite(mailId, mapOfMap, configFileReader.getMailDataPath());
    }

    /**
     * Method to reply to RFI
     *
     * @param attribute
     * @param mailId
     */
    public void replyRFI(String attribute, String mailId) {
        Map<String, Map<String, Object>> mapOfMap = new Hashtable<>();
        Map<String, Object> mailMap = new Hashtable<>();
        clickReply();
        fillFields(attribute);
        verifyAndSwitchFrame();
        String rfiMailNumber = sendRfi();
        mailMap.put("mail_num", rfiMailNumber);
        mapOfMap.put(mailId, mailMap);
        dataSetup.fileWrite(mailId, mapOfMap, configFileReader.getMailDataPath());
    }

    /**
     * Method to fetch the reference number and return it
     *
     * @return
     */
    public String returnReferenceNumber() {
        return $(referenceNumber).getText();
    }

    /**
     * Verify the table where rfi mails are listed
     * @param mailId
     * @param fromOrg
     * @param toOrg
     */
    public void verifyRfiTableFields(String mailId, String fromOrg, String toOrg) {
        By referenceNumber = By.xpath("//table//div[text()='" + mailId + "']");
        By fromOrgField = By.xpath("//table//div[text()='" + mailId + "']//following::td[2]");
        By toOrgField = By.xpath("//table//div[text()='" + mailId + "']//following::td[3]");
        commonMethods.waitForElement(driver, referenceNumber);
        Assert.assertTrue($(referenceNumber).isDisplayed());
        Assert.assertTrue($(fromOrgField).getText().equals(fromOrg));
        Assert.assertTrue($(toOrgField).getText().equals(toOrg));
    }
}
