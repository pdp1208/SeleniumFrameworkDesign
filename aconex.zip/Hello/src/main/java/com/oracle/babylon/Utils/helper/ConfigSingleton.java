package com.oracle.babylon.Utils.helper;

import com.oracle.babylon.Utils.setup.utils.ConfigFileReader;
import org.openqa.selenium.WebDriver;

public class ConfigSingleton {

    public static boolean apphubEnable = false;
    public static boolean aasEnable = false;
    protected WebDriver driver = null;
    CommonMethods commonMethods = new CommonMethods();
    ConfigFileReader configFileReader = new ConfigFileReader();

    ConfigSingleton(WebDriver driver) {
        commonMethods.loadPage(driver);
        String url = driver.getCurrentUrl();
        if (url.toLowerCase().contains(configFileReader.getAppHubURL())) {
            apphubEnable = true;
        }
        if(url.toLowerCase().contains(configFileReader.getAASURL())) {
            aasEnable = true;
        }
    }

}