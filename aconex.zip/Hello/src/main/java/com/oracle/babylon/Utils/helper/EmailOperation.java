package com.oracle.babylon.Utils.helper;

import org.junit.Assert;

import javax.mail.*;
import javax.mail.search.SearchTerm;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class EmailOperation {

    public String emailConfigFilePath = "src/main/resources/email.properties";
    Properties properties = new Properties();
    protected Session session;
    protected Store store;
    protected Message[] messages;
    protected Folder inbox;

    /**
     * Load the data from the config file and make it accessible to the Properties variable
     */
    public EmailOperation() {
        BufferedReader reader;
        try {
            reader = new BufferedReader(new FileReader(emailConfigFilePath));
            try {
                properties.load(reader);
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            throw new RuntimeException("email.properties not found at " + emailConfigFilePath);
        }
    }

    /**
     * Method to set the IMAP Properties
     */
    public void setImapProperties(String username) {
        properties.put("mail.imap.ssl.socketFactory", getImapSSLSocket());
        properties.put("mail.imap.ssl.socketFactory.fallback", getImapSSLSocketFallout());
        properties.put("mail.imap.ssl.socketFactory.port", getImapSSLPort());
        properties.setProperty("mail.imap.ssl.enable", getImapSSLEnable());
        properties.put("mail.imap.user", username);
        properties.put("mail.store.protocol", getMailStoreProtocol());
        properties.put("mail.imap.ssl.protocols", getImapSSLProtocols());
        //properties.put("mail.imap.port", 143);
    }

    /**
     * Method to create Mail Authenticator
     */
    public Authenticator createMailAuthenticator(String email, String password) {
        return new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(email, password);
            }
        };
    }

    /**
     * Method to create Mail connection
     */
    public void createMailConnection(String email, String password) {
        try {
            session = Session.getDefaultInstance(properties, createMailAuthenticator(email, password));
            store = session.getStore("imap");
            store.connect(getImapAccount(), email, password);
        } catch (NoSuchProviderException e) {
            e.printStackTrace();
            Assert.fail("No provider.");
        } catch (MessagingException e) {
            e.printStackTrace();
            Assert.fail("Could not connect to the message store.");

        }
    }

    /**
     * Method to filter the mails with provided subject parameter
     */
    public SearchTerm searchInboxMails(String subject) {
        return new SearchTerm() {
            @Override
            public boolean match(Message message) {
                try {
                    if (message.getSubject() != null && message.getSubject().contains(subject)) return true;
                } catch (MessagingException ex) {
                    Assert.fail("Failed to set Search Criteria");
                    ex.printStackTrace();
                }
                return false;
            }
        };
    }

    /**
     * Method to close connections
     */
    public void closeConnections() {
        try {
            if (inbox.isOpen()) inbox.close(false);
            store.close();
        } catch (MessagingException ex) {
            Assert.fail("Failed to close connections");
            ex.printStackTrace();
        }
    }

    /**
     * Method to get IMAP SSL Socket Port
     */
    public String getImapSSLPort() {
        String sslPort = properties.getProperty("IMAP_SSL_SOCKET_FACTORY_PORT");
        if (sslPort != null) return sslPort;
        else throw new RuntimeException("IMAP SSL Socket port is not specified in the email.properties file.");
    }

    /**
     * Method to get IMAP SSL Socket Factory
     */
    public String getImapSSLSocket() {
        String sslSocket = properties.getProperty("IMAP_SSL_SOCKET_FACTORY");
        if (sslSocket != null) return sslSocket;
        else throw new RuntimeException("IMAP SSL Socket Factory is not specified in the email.properties file.");
    }

    /**
     * Method to get IMAP SSL Socket Factory Fallout
     */
    public String getImapSSLSocketFallout() {
        String sslFallout = properties.getProperty("IMAP_SSL_SOCKET_FACTORY_FALLOUT");
        if (sslFallout != null) return sslFallout;
        else throw new RuntimeException("IMAP SSL Socket Fallout is not specified in the email.properties file.");
    }

    /**
     * Method to get IMAP SSL Enable
     */
    public String getImapSSLEnable() {
        String sslEnable = properties.getProperty("IMAP_SSL_ENABLE");
        if (sslEnable != null) return sslEnable;
        else throw new RuntimeException("IMAP SSL Enable is not specified in the email.properties file.");
    }

    /**
     * Method to get IMAP SSL Protocols
     */
    public String getImapSSLProtocols() {
        String sslProtocols = properties.getProperty("IMAP_SSL_PROTOCOLS");
        if (sslProtocols != null) return sslProtocols;
        else throw new RuntimeException("IMAP SSL Protocols is not specified in the email.properties file.");
    }

    /**
     * Method to get IMAP Account
     */
    public String getImapAccount() {
        String imapAccount = properties.getProperty("IMAP_ACCOUNT");
        if (imapAccount != null) return imapAccount;
        else throw new RuntimeException("IMAP Account is not specified in the email.properties file.");
    }

    /**
     * Method to get Mail Store Protocol
     */
    public String getMailStoreProtocol() {
        String mailStoreProtocol = properties.getProperty("MAIL_STORE_PROTOCOL");
        if (mailStoreProtocol != null) return mailStoreProtocol;
        else throw new RuntimeException("Mail Store Protocol is not specified in the email.properties file.");
    }

    /**
     * Method to get Email id for a given user
     */
    public String getEmailId(String user) {
        String email = properties.getProperty("NOTIFICATION_" + user.toUpperCase() + "_EMAIL");
        if (email != null) return email;
        else throw new RuntimeException("Notifications User Email is not specified in the email.properties file.");
    }

    /**
     * Method to get passwords for email address
     */
    public String getEmailPassword() {
        String password = properties.getProperty("NOTIFICATION_PASSWORD");
        if (password != null) return password;
        else throw new RuntimeException("Notifications User Email is not specified in the email.properties file.");
    }

}
