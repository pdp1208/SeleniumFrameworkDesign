package com.oracle.babylon.pages.Report;

import com.codeborne.selenide.SelenideElement;
import com.oracle.babylon.Utils.helper.Navigator;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Condition.visible;
import java.util.List;

public class TreeSelectionPanel extends Navigator {

    WebElement m_element;

    public TreeSelectionPanel(WebElement element){
        m_element = element;
    }

    public void expand(List<String> items) {
        for (String item : items) {
            SelenideElement element = $(By.xpath("//a[contains(text(),'" + item + "')]"));
            element.waitUntil(visible, 4000);
            if(($(By.xpath("//a[contains(text(),'" + item + "')]//parent::li"))).getAttribute("class").contains("jstree-leaf")){
                //leaf node
                element.click();
                break;
            } else if(($(By.xpath("//a[contains(text(),'" + item + "')]//parent::li"))).getAttribute("class").contains("jstree-closed")){
                //expand node
                element.find(By.xpath("//a[contains(text(),'" + item + "')]//preceding-sibling::i")).click();
            }
        }
    }
}
