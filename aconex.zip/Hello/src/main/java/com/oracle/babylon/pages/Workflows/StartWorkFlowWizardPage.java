package com.oracle.babylon.pages.Workflows;

import com.codeborne.selenide.Condition;
import com.oracle.babylon.Utils.helper.CommonMethods;
import com.oracle.babylon.Utils.helper.Navigator;
import com.oracle.babylon.pages.Document.DocumentPage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.interactions.Actions;

import java.util.Map;


import static com.codeborne.selenide.Selenide.$;

public class StartWorkFlowWizardPage extends Navigator {
    private By nextButton = By.xpath("//div[contains(text(),'Next')]");
    private By templateNameField = By.xpath("//div[@id='txtTemplateName']//input");
    private By searchBtn = By.xpath("//div[contains(text(),'Search')]");
    private By submitBtn = By.xpath("//button[@id='btnSubmit']//div[contains(text(),'Submit')]");
    private By docSearchQuery = By.xpath("//input[@id='search-keywords-id']");
    private CommonMethods commonMethods = new CommonMethods();
    private DocumentPage documentpage = new DocumentPage();
    private By addDocumentsBtn = By.xpath("//button[@id='btnAddDocuments']");
    private By okBtn = By.xpath("//button[@id='btnattachFileChoice_attachDocs_panel_ok']");
    private By linkSupplementaryTab = By.xpath("//li[@id='suppFileTabList']");
    private By attachFileBtn = By.xpath("//button[@id='btnAttach']");
    private By docRegister = By.xpath("//button[@id='attachFileChoice_fileChoicePanel_btnAttachFromControlledDocs_page']");
    private By supplementDocComment = By.xpath("//div[@id='divDisplay_cdoc_comments_0']");
    private By supplementOkBtn = By.xpath("//button[@id='btnattachFileChoice_fileChoicePanel_ok']");
    private By selectTemplateStep = By.xpath("//div[contains(text(),'Template Name')]");
    private By workflowName = By.xpath("//input[@id='name']");
    private By reasonForIssue = By.xpath("//select[@id='selectedReason']");
    private By confidentialBtn = By.xpath("//button[@id='btnSendAsConfidential']");
    private By unavailableMsg = By.xpath("//span[contains(text(),'Documents Unavailable')]");
    private By closeBtn = By.xpath("//button[@id='btnexcludedDocs_ok']");
    private By workflowNote = By.xpath("//textarea[@id='instructionNote']");
    private By showTemplateChkBox = By.xpath("//input[@id='showTemplateFromMyOrgOnly_chk']");
    private By confirmActionOkBtn = By.xpath("//button[@id='btnparentParticipantValidationPanel_ok']");
    private By supplementaryLink = By.xpath("//li[@id='SUPP_FILES_TABList']");
    private By infoModal = By.xpath("//div[@class='uiModal']");
    private Map<String, Object> mailMap;
    String mailFilePath = configFileReader.getMailDataPath();
    String workflowFilePath = configFileReader.getWorkflowDataPath();

    /**
     * Method to click next button
     */
    public void clickNext() {
        commonMethods.waitForElementExplicitly(2000);
        verifyAndSwitchFrame();
        try {
            commonMethods.waitForElement(driver, infoModal, 4);
            $(infoModal).waitUntil(Condition.disappears, 10000);
        }catch(TimeoutException e){
            //ignore
        }
        commonMethods.waitForElement(driver, nextButton, 40);
        $(nextButton).click();
    }

    /**
     * Method to search and select template
     *
     * @param template name
     */
    public void selectTemplate(String template) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(workflowFilePath);
        mailMap = jsonMapOfMap.get(template);
        String templateName = mailMap.get("template_name").toString();
        verifyAndSwitchFrame();
        $(templateNameField).clear();
        $(templateNameField).sendKeys(templateName);
        commonMethods.waitForElementExplicitly(500);
        $(templateNameField).sendKeys(Keys.ENTER);
        By templateAvailable = By.xpath("//table[@class='grid-body-table dataTable']//tr[td[contains(.,'" + templateName + "')]]//td[1]//span");
        commonMethods.waitForElement(driver, templateAvailable, 30);
        $(templateAvailable).click();
    }

    /**
     * Function to add documents for workflow from doc register
     *
     * @param document
     */
    public void attachDocument(String document) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(4000);
        $(addDocumentsBtn).click();
        commonMethods.waitForElementExplicitly(2000);
        searchDocumentWorkflow(document);
        documentpage.selectFirstWfDocChkBox();
        driver.switchTo().defaultContent();
        verifyAndSwitchFrame();
        $(okBtn).click();
    }

    /**
     * Function to search Document form Workflow wizard
     *
     * @param documentNumber
     */
    public void searchDocumentWorkflow(String documentNumber) {
        commonMethods.waitForElementExplicitly(2000);
        verifyAndSwitchFrame();
        verifyAndSwitchFrame("attachFileChoice_attachDocs_frame");
        documentpage.searchDocumentNo(documentNumber);
    }

    /**
     * Function to add document form supplementary
     *
     * @param document
     */
    public void addDocumentSupplementary(String document, String tab) {
        verifyAndSwitchFrame();
        if (tab.equalsIgnoreCase("subworkflow")) {
            $(supplementaryLink).click();
        } else {
            $(linkSupplementaryTab).click();
        }
        $(attachFileBtn).click();
        $(docRegister).click();
        searchDocumentWorkflow(document);
        documentpage.selectFirstWfDocChkBox();
        driver.switchTo().defaultContent();
        verifyAndSwitchFrame();
        $(okBtn).click();
    }

    /**
     * Function to add comments for supplementary Document
     *
     * @param comment
     */
    public void addCommentsSupplementary(String comment) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, supplementDocComment, 15);
        (new Actions(driver)).moveToElement($(supplementDocComment)).click($(supplementDocComment)).sendKeys(comment).build().perform();
        $(supplementOkBtn).click();
    }

    /**
     * Function to remove Document from workflow wizard
     *
     * @param document
     */
    public void removeWorkflowDocument(String document) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        $(By.xpath("//table[@class='dataTable']//td[text()='" + document + "']//..//img[@class='trash']")).click();
    }

    /**
     * Function to verify removed document
     *
     * @param document
     */
    public Boolean verifyRemovedDocument(String document) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(3000);
        if (!$(By.xpath("//table[@class='dataTable']//td[text()='" + document + "']")).isDisplayed()) {
            return true;
        }
        return false;
    }

    /**
     * Function to verify comment in supplemntary tab
     *
     * @param comment
     * @return
     */
    public Boolean verifyComments(String comment) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        return $(By.xpath("//table[@id='supplementaryFilesResultsTable']//td[contains(text(),'" + comment + "')]")).isDisplayed();
    }

    /**
     * Fnction to verify Workflow Template page
     *
     * @return
     */
    public boolean verifyWorkflowTemplatePage() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, selectTemplateStep, 40);
        return $(selectTemplateStep).isDisplayed();
    }

    /**
     * Function to verify Error Message for workflow name
     */
    public void verifyErrorMsgWorkflowName() {
        verifyAndSwitchFrame();
        $(workflowName).clear();
        clickSubmitVerifyConfidential();
        verifyMandatoryFieldErrorMsg();
        $(workflowName).sendKeys("Regression workflow Test");
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Function to verify Error Msg for Missing Mandatory Fields
     */
    public void verifyMandatoryFieldErrorMsg() {
        if (!commonMethods.isAlertPresent(driver)) {
            $(submitBtn).click();
        }

        String error = driver.switchTo().alert().getText();
        Assert.assertTrue(error.contains("A mandatory field is empty. Please complete all highlighted fields before submitting."));
        driver.switchTo().alert().accept();
    }

    /**
     * Function to verify Error message for reason for issue
     *
     * @param option
     */
    public void verifyErrorMsgReasonForIssue(String option) {
        verifyAndSwitchFrame();
        $(reasonForIssue).selectOptionContainingText("-- Select reason for issue --");
        clickSubmitVerifyConfidential();
        verifyMandatoryFieldErrorMsg();
        $(reasonForIssue).selectOptionContainingText(option);
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Method to click submit button
     */
    public void clickSubmitVerifyConfidential() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, submitBtn, 40);
        $(submitBtn).click();
        if ($(confidentialBtn).isDisplayed()) {
            $(confidentialBtn).click();
        }
    }

    /**
     * Method to click submit button
     */
    public void clickSubmit() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver,submitBtn,45);
        $(submitBtn).click();
    }

    /**
     * Method to set workflow setting
     *
     * @param attribute
     */
    public void setWorkflowSetting(String attribute) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, By.xpath("//input[@id='name']"), 30);
        Map<String, String> table = dataStore.getTable(attribute);
        //According to the keys passed in the table, we select the fields
        for (String tableData : table.keySet()) {
            switch (tableData) {
                case "Reason For Issue":
                    $(By.xpath("//select[@id='selectedReason']")).selectOptionContainingText(table.get(tableData));
                    break;
            }
        }
    }

    /**
     * Function to  verify unavailable msg
     *
     * @return
     */
    public boolean verifyUnavailableMsg() {
        commonMethods.waitForElement(driver, unavailableMsg, 40);
        return $(unavailableMsg).isDisplayed();
    }

    /**
     * Click on close button
     */
    public void clickClose() {
        commonMethods.waitForElement(driver, closeBtn, 40);
        $(closeBtn).click();
    }

    /**
     * Function to verify Doc reason
     *
     * @param reason
     * @return
     */
    public boolean verifyReason(String reason) {
        commonMethods.waitForElement(driver, closeBtn, 40);
        By reasonTxt = By.xpath("//td[contains(text(),'" + reason + "')]");
        commonMethods.waitForElement(driver, reasonTxt, 40);
        return $(reasonTxt).isDisplayed();
    }

    /**
     * Function to Edit workflow Note
     *
     * @param note
     */
    public void editWorkFlowNote(String note) {
        commonMethods.waitForElement(driver, workflowNote, 40);
        $(workflowNote).clear();
        $(workflowNote).sendKeys(note);
    }

    /**
     * Function to send workflow for confi docs
     *
     * @param option
     */
    public void sendWorkFlow(String option) {
        By optionElement = By.xpath("//div[text()='" + option + "']");
        commonMethods.waitForElementExplicitly(6000);
        if($(optionElement).isDisplayed())
            $(optionElement).click();
    }

    /**
     * Function to set show template
     *
     * @param value
     */
    public void setShowTemplate(boolean value) {
        commonMethods.waitForElement(driver, showTemplateChkBox, 40);
        $(showTemplateChkBox).setSelected(value);
    }

    /**
     * Confirm Action
     */
    public void confirmAction() {
        if ($(confirmActionOkBtn).isDisplayed()) {
            $(confirmActionOkBtn).click();
        }
    }

    /**
     * Method to click on Add Documents button in Start workflow wizard page
     */
    public void clickAddDocument() {
        commonMethods.waitForElement(driver, addDocumentsBtn, 60);
        $(addDocumentsBtn).click();
    }

    /**
     * Method to switch frame to attach file choice attach docs frame in start workflow wizard
     */
    public void switchAttachFileChoiceFrame() {
        switchToOriginal();
        verifyAndSwitchFrame();
        verifyAndSwitchFrame("attachFileChoice_attachDocs_frame");
    }
}
