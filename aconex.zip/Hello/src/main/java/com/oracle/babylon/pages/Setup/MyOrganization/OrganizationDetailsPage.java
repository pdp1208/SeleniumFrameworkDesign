package com.oracle.babylon.pages.Setup.MyOrganization;

import com.github.javafaker.Faker;
import com.oracle.babylon.Utils.helper.Navigator;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import java.util.Random;
import static com.codeborne.selenide.Selenide.$;

/**
 * Author : sushanth
 * Organization Details Page under Setup
 * Used for displaying organization information and perform operations on it
 */
public class OrganizationDetailsPage extends Navigator {
    /**
     * Identifiers for all the HTML attributes in the page
     */
    private By crnField = By.xpath("//label[text()='Company Registration Number']//..//..//td[2]//input");
    private By addDivisionField = By.xpath("//input[@name='NEW_DIVISION']");
    private By addDivisionBtn = By.xpath("//button[@title='Add a new division']//div[contains(text(),'Add')]");
    private By inactiveDivisions = By.xpath("//select[@id='ActiveDivisions_AVAIL']");
    private By rightArrow = By.xpath("//button[@id='btnActiveDivisions_ADD']");
    private By orgAbbreviation = By.xpath("//input[@id='ORGANIZATION_CODE']");


    /**
     * Method to navigate to the page in the ui
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Setup", "Organization Details");
        commonMethods.waitForElementExplicitly(5000);
        verifyAndSwitchFrame();
    }


    /**
     * Method to enter the company registration number
     */
    public void enterCRN(){
        Faker faker = new Faker();
        String crn = faker.name().fullName().substring(0,2).toUpperCase();
        Random random = new Random();
        int number = random.nextInt(1000);
        crn = crn + number;
        $(crnField).clear();
        $(crnField).sendKeys(crn);
    }

    /**
     * Method to create a division for the organization
     * @return
     */
    public String createDivision(){
        Faker faker = new Faker();
        String division = faker.commerce().department();
        $(addDivisionField).sendKeys(division);
        $(addDivisionBtn).click();
        $(saveBtn).click();
        return division;
    }

    /**
     * Method to activate a division.
     * Move it from the left select list to the right one.
     * @param division
     */
    public void activateDivision(String division){
        Select select = new Select($(inactiveDivisions));
        select.selectByVisibleText(division);
        $(rightArrow).click();
        $(saveBtn).click();

    }

    /**
     * Method to get the organization abbreviation
     */
    public String getOrgAbbreviation(){
       commonMethods.waitForElement(driver,orgAbbreviation,30);
       return $(orgAbbreviation).getAttribute("value");

    }

    /**
     * Method to set organization abbreviation code
     */
    public void enterOrgAbbreviationCode(String code){
         commonMethods.enterTextValue(orgAbbreviation,code);
         $(saveBtn).click();
    }
}
