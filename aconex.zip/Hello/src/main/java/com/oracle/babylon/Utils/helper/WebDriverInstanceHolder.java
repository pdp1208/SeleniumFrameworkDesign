package com.oracle.babylon.Utils.helper;

import org.openqa.selenium.WebDriver;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class WebDriverInstanceHolder {

    private WebDriver m_driver;
    private static WebDriverInstanceHolder INSTANCE;
    private static Map<Long, WebDriverInstanceHolder> INSTANCES = Collections.synchronizedMap(new HashMap<Long, WebDriverInstanceHolder>());

    /**
     * Get a static instance of webdriver.
     *
     * @return instance of webdriver.
     */
    public static synchronized WebDriverInstanceHolder getInstance() {
        return getInstance(false);
    }

    /**
     * Store webdriver instanc ealong with it's threas id. 1 webdriver instance per thread.
     *
     * @param forceNew need to create new instance of webdriver?
     */
    public static synchronized WebDriverInstanceHolder getInstance(boolean forceNew) {
        long threadId = Thread.currentThread().getId();
        if (forceNew || INSTANCES.get(threadId) == null) {
            INSTANCE = new WebDriverInstanceHolder();
            INSTANCES.put(threadId, INSTANCE);
        }
        return INSTANCES.get(threadId);
    }

    /**
     * Returns instance of webdriver
     *
     */
    public WebDriver getDriver() {
        return m_driver;
    }

    /**
     * Set instance of webdriver
     *
     */
    public void setDriver(WebDriver driver) {
        m_driver = driver;
    }
}
