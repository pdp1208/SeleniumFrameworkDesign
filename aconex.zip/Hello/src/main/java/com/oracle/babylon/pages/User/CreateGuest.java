package com.oracle.babylon.pages.User;

import com.codeborne.selenide.WebDriverRunner;
import com.oracle.babylon.Utils.helper.Navigator;
import com.oracle.babylon.pages.Directory.DirectoryPage;
import org.junit.Assert;
import org.openqa.selenium.By;

import java.util.Map;

import static com.codeborne.selenide.Selenide.$;

public class CreateGuest extends Navigator {

    public CreateGuest() {
        this.driver = WebDriverRunner.getWebDriver();
    }

    //Initializing the web elements
    private By pageTitle = By.xpath("//h1[contains(text(),'New Guest Information')]");
    private By firstName = By.xpath("//input[@name='USER_FIRST_NAME']");
    private By lastName = By.xpath("//input[@name='USER_LAST_NAME']");
    private By emailId = By.xpath("//input[@name='EMAIL']");
    private By navCreateGuest = By.xpath("//div[@class='navBarPanel-menuSubSection']//div[text()='Create Guest']");
    private By navCreateGuest_Apphub = By.xpath("//a[@id='nav-bar-SETUP-SETUP-NEWORGGUEST' and text()='Create Guest']");
    private By continueCreateGuest = By.xpath("//li//label[text()='Continue creating new Guest']");
    private By guestUserDisplay=By.xpath("//tr[@class='dataRow'][1]//td[1][@class='tight']//a");
    private By organizationElement = By.xpath("//input[@name='EXT_ORG_NAME']");
    DirectoryPage directoryPage = new DirectoryPage();

    /**
     * Function to navigate to Guest page
     */
    public void navigateAndVerifyPage() {
        commonMethods.waitForElementExplicitly(4000);
        getMenuSubmenu("Setup", "Create Guest");
        verifyPageTitle(pageTitle);
    }

    /**
     * Function to navigate to Guests based on instance page
     */
    public void navigateAndVerifyPage(String instance) {
        if (instance.equalsIgnoreCase("Setup"))
            navigateAndVerifyPage();
        else {
            directoryPage.navigateToGlobalDirAndVerify();
            verifyAndSwitchFrame();
            directoryPage.clickCreateGuest();
        }
    }

    /**
     * Default values in this method
     */
    public void fillDetails() {
        $(firstName).sendKeys("James");
        $(lastName).sendKeys("Hunt");
        $(emailId).sendKeys(configFileReader.getTestEmailId());
        $(pageSaveBtn).click();
    }
    /**
     * Function to Fill all the details on the Guest Page
     */
    public void fillDetails(Map<String, String> userDetail, String organization) {
        $(organizationElement).sendKeys(organization);
        $(firstName).sendKeys(userDetail.get("firstname"));
        $(lastName).sendKeys(userDetail.get("lastname"));
        $(emailId).sendKeys(userDetail.get("email"));
        $(pageSaveBtn).click();
    }


    /**
     *  Method to enter only the user details
     */
    public void fillDetails(Map<String, String> userDetail) {
        $(firstName).sendKeys(userDetail.get("firstname"));
        $(lastName).sendKeys(userDetail.get("lastname"));
        $(emailId).sendKeys(userDetail.get("email"));
        $(pageSaveBtn).click();
    }

    /**
     * Function to get whether Create Guest Button is Displayed
     */
    public boolean verifyCreateAccess() {
        clickSetupLink();
        if(configFileReader.getAppHubEnable())
            return $(navCreateGuest_Apphub).isDisplayed();
        else
            return $(navCreateGuest).isDisplayed();
    }
    /**
     * Function to navigate to mandatory error message
     */
    public String getMandatoryErrorMsg() {
        clickSaveButton();
        return getAlertText();
    }
    /**
     * Function to Click on Continue Create Guest Button
     */
    public void continueCreateGuest() {
        commonMethods.waitForElementExplicitly(2000);
        if($(continueCreateGuest).exists()) {
            $(continueCreateGuest).click();
            clickContinueBtn();
        }
    }
    /**
     * Function to Click Continue Button
     */
    public void clickContinueBtn() {
        commonMethods.waitForElement(driver, continueBtn);
        $(continueBtn).click();
    }
    /**
     * Function get the Guest created from the table
     */
    public String getCreatedGuest()
    {
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver,guestUserDisplay);
        return $(guestUserDisplay).getText();
    }

    /**
     * Method to select the same organization in the Confirm Organization screen
     */
    public void selectOrganization(String organization){
        By by = By.xpath("//label[contains(text(),'" + organization + "')]//..//input");
        $(by).setSelected(true);

    }
}
