package com.oracle.babylon.pages.Setup;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.back;

public class PreferenceProjectTab extends PreferencesPage {
    private By timeZoneReset = By.xpath("//input[@name='PREFERENCE_localtimezone_RESET']");
    private By localTimeZone = By.xpath("//select[@name='PREFERENCE_localtimezone']");
    private By backupEmail = By.xpath("//input[@name='PREFERENCE_mailbackupaddress_DISPLAY']");

    public void navigateAndVerifyPage() {
        getMenuSubmenu("Setup", "Preferences");
        verifyAndSwitchFrame();
        By tab = By.cssSelector("#project-tab");
        commonMethods.waitForElement(driver,tab,15);
        $(tab).click();
        verifyPageTitle("Edit Preferences");
    }

    public void checkDefaultSettingsForProject(String preference, Boolean flag) {
        selectDefaultSettings(preference,flag);
    }

    public void selectSettingForProject(String preference, String option) {
        selectSettingFrom(preference, option);
    }

    public void editSettingForProject(String preferences) {
        clickEditButtonForSetting(preferences);
    }

    public void checkNonDefaultSettingsForProject(String preference, String flag) {
        selectNonDefaultSettings(preference, flag);
    }

    /**
     * Function to configure default columns for Documents
     * @param preference
     */

    public void configureDefaultColumns(String preference, List<String> data){
        int prefRow = getPrefRow(preference);
        int settingColumn = 2;
        WebElement editButton =  driver.findElement(prefTable).findElement(By.xpath("//tr[" + prefRow + "]//td[" + settingColumn + "]//div[contains(text(),'Edit')]"));
        $(editButton).click();
        removeColumns();
        addSelectedColumns(preference,data);
        $(saveButton).click();

    }

    /**
     * Method to click on the edit time zone button
     */
    public void clickTimeZone() {
        int prefRow = getPrefRow("Set default time zone");
        int settingColumn = 2;
        WebElement editButton =  driver.findElement(prefTable).findElement(By.xpath("//tr[" + prefRow + "]//td[" + settingColumn + "]//div[contains(text(),'Edit')]"));
        $(editButton).click();
    }

    /**
     * Method to change the time zone
     * @param timeZone
     */
    public void setTimeZone(String timeZone) {
        $(timeZoneReset).setSelected(false);
        $(localTimeZone).selectOption(timeZone);
        clickSaveButton();
    }

    /**
     * Method to set the backup email address
     * @param email
     */
    public void setEmail(String email) {
        $(backupEmail).setValue(email);
        clickSaveButton();
    }
}
