package com.oracle.babylon.Utils.helper;

import java.util.Map;

public class ZephyrStatusSingleton {

    private static ZephyrStatusSingleton zephyrStatusSingleton;
    private static int PASS_STATUS;
    private static int FAIL_STATUS;
    private static String SESSION_ID;

    private ZephyrStatusSingleton(String jiraId){
        JIRAOperations jiraOperations =  new JIRAOperations();
        SESSION_ID = jiraOperations.createSession();
        String issueId = jiraOperations.returnIssueID(jiraId);
        Map<String, Integer> map = jiraOperations.returnExecutionStatusId(issueId);
        PASS_STATUS = map.get("PASS");
        FAIL_STATUS = map.get("FAIL");

    }

    public static ZephyrStatusSingleton getInstance(String jiraId){
        if(zephyrStatusSingleton == null){
            zephyrStatusSingleton = new ZephyrStatusSingleton(jiraId);
        }
        return zephyrStatusSingleton;
    }

    public static int returnPassStatusId(){
        return PASS_STATUS;
    }

    public static int returnFailStatusId(){
        return FAIL_STATUS;
    }

    public static String returnSessionId(){
        return SESSION_ID;
    }
}