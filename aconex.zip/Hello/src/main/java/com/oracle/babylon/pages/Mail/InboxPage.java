package com.oracle.babylon.pages.Mail;

import com.codeborne.selenide.WebDriverRunner;
import com.oracle.babylon.Utils.helper.Navigator;
import com.oracle.babylon.pages.Document.DocumentPage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.awt.*;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.switchTo;

/**
 * Class to hold the methods related to the the mail inbox page
 * Author : visinghsi
 */
public class InboxPage extends MailPage {

    public InboxPage() {
        this.driver = WebDriverRunner.getWebDriver();
    }

    //Initializing the web elements
    private By pageTitle = By.xpath("//h1//span[text()='Search Mail']");

    /**
     * Function to navigate to a sub menu from the Aconex home page
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Mail", "Inbox");
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, pageTitle, 30);
        verifyPageTitle(pageTitle);
    }
}




