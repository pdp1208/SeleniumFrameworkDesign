package com.oracle.babylon.pages.Package;

import com.oracle.babylon.Utils.helper.Navigator;
import com.oracle.babylon.pages.Tasks.TaskPage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import java.io.File;
import java.util.List;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.actions;

public class PackageReviewsPage extends Navigator {

    private By title = By.xpath("//div[text()='Package reviews']");
    private By assignedToMe = By.xpath("//a[text()='Assigned to me']");
    private By allPackageReviews = By.xpath("//a[text()='All package reviews']");
    private By packageDetailsRow = By.xpath("//td[@data-automation-id='packageDetails']");
    private By scheduleStatus = By.xpath("//td[@data-automation-id='stepScheduleStatus']//div");
    private By stepStatus = By.xpath("//td[@data-automation-id='stepStatus']");
    private By reviewOutcome = By.xpath("//select[@data-automation-id='reviewOutcome']");
    private By attachFiles = By.xpath("//button[text()='Attach files']");
    private By files = By.xpath("//input[@name='qqfile']");
    private By submitReview = By.xpath("//button[text()='Submit review']");
    private By searchPackage = By.xpath("//span[text()='Package']//..//input");
    private By reviewDetails = By.xpath("//span[text()='Review details']//..//input");
    private By stepName = By.xpath("//a[@data-automation-id='showStepsButton']");
    private By stepOutcome = By.xpath("//tr[@data-automation-id='stepRow']//td[7]");
    private By resultStepStatus = By.xpath("//tr[@data-automation-id='stepRow']//td[8]");
    private By assignedTo = By.xpath("//tr[@data-automation-id='stepRow']//td[6]");
    private By terminate = By.xpath("//a[text()='Terminate']");
    private By terminateBtn = By.xpath("//button[text()='Terminate']");
    private By skip = By.xpath("//a[text()='Skip']");
    private By inProgress = By.xpath("//a//span[contains(text(),'In progress')]");
    private By skipBtn = By.xpath("//button[text()='Skip']");
    private By downloadIcon = By.xpath("//*[@class='auiText-link reviewFileCount ng-scope']");


    public void navigateAndVerifyPage() {
        getMenuSubmenu("Packages", "Package Reviews");
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, title, 20);
        Assert.assertTrue($(title).isDisplayed());
    }


    public String returnScheduleStatus() {
        return $(scheduleStatus).getText();
    }

    /**
     * Method to return the step status in the assigned to me page
     *
     * @return
     */
    public String returnStepStatus() {
        return $(stepStatus).getText();
    }

    /**
     * Method to start the review process of the package.
     *
     * @param reviewId
     * @param outcome
     * @param fileName
     */
    public void reviewPackage(String reviewId, String outcome, String fileName) {
        $(assignedToMe).click();
        Actions actions = new Actions(driver);
        By reviewBtn = By.xpath("//td[@data-automation-id='reviewDetails' and contains(text(),'" + reviewId + "')]//..//td[8]");
        actions.moveToElement($(reviewBtn));
        $(reviewBtn).click();
        $(reviewOutcome).click();
        Select reviewOutcomeSelect = new Select($(reviewOutcome));
        reviewOutcomeSelect.selectByVisibleText(outcome);
        $(attachFiles).click();
        commonMethods.waitForElementExplicitly(1000);
        verifyAndSwitchFrame();
        verifyAndSwitchFrame("attachFiles-frame");
        String filePath = configFileReader.getTestDataPath() + fileName;
        File file = new File(filePath);
        filePath = file.getAbsolutePath();
        commonMethods.waitForElementExplicitly(1000);
        WebElement element = driver.findElement(files);
        element.sendKeys(filePath);
        switchToOriginal();
        verifyAndSwitchFrame();
        $(attachFiles).click();
        commonMethods.waitForElementExplicitly(10000);
        commonMethods.waitForElement(driver, submitReview);
        $(submitReview).click();
    }


    /**
     * Method to click the all package reviews tab
     */
    public void clickAllPackageReviewsTab() {
        commonMethods.waitForElement(driver, allPackageReviews);
        $(allPackageReviews).click();
    }

    /**
     * Method to search the package by review details
     *
     * @param packageNumber
     */
    public void searchReview(String packageNumber) {
        commonMethods.waitForElement(driver, reviewDetails);
        $(reviewDetails).clear();
        $(reviewDetails).sendKeys(packageNumber);
        $(reviewDetails).sendKeys(Keys.ENTER);
    }

    /**
     * Method to return the step name of a package review
     *
     * @return
     */
    public String returnStepName() {
        return $(stepName).getText();
    }

    /**
     * Method to return the step outcome
     *
     * @return
     */
    public String returnStepOutcome() {
        $(stepName).click();
        return $(stepOutcome).getText();
    }

    /**
     * Method to return the step status
     *
     * @return
     */
    public String returnResultStepStatus() {
        if (!$(resultStepStatus).isDisplayed()) {
            $(stepName).click();
        }
        return $(resultStepStatus).getText();
    }

    /**
     * Method to return the assigned To user name of the review
     *
     * @return
     */
    public String returnAssignedTo() {
        $(stepName).click();
        return $(assignedTo).getText();
    }

    /**
     * Method to terminate the package review
     */
    public void terminatePackage() {
        $(terminate).click();
        $(terminateBtn).click();
    }

    public void skipStep() {
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, inProgress);
        List<WebElement> elements = driver.findElements(inProgress);
        elements.get(0).click();
        commonMethods.scrollToBottom(driver);
        actions().moveToElement($(skip));
        commonMethods.waitForElement(driver, skip);
        $(skip).click();
        commonMethods.waitForElement(driver, skipBtn);
        $(skipBtn).click();
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Method to click on review button for a specific review package
     */
    public void clickReview(String reviewId) {
        $(assignedToMe).click();
        Actions actions = new Actions(driver);
        By reviewBtn = By.xpath("//td[@data-automation-id='reviewDetails' and contains(text(),\"" + reviewId + "\")]//..//td[8]");
        actions.moveToElement($(reviewBtn));
        $(reviewBtn).click();
    }

    /**
     * Method to click on package id inside review screen
     */
    public void clickOnPackageId(String packageId) {
        By xpath = By.xpath("//div[@class='packageDetails']//a//span[contains(text(),'" + packageId + "')]");
        commonMethods.waitForElement(driver, xpath, 30);
        $(xpath).click();
    }

    public void downloadAttachmentOnReview(String fileName) {
        commonMethods.waitForElement(driver, downloadIcon, 40);
        $(downloadIcon).click();
        By downloadFile = By.xpath("//*[text()='" + fileName + "']");
        commonMethods.waitForElement(driver, downloadFile);
        $(downloadFile).click();
        commonMethods.waitForElementExplicitly(10000);
    }

    public void clickReviewOutCome(String outcome) {
        commonMethods.waitForElement(driver, reviewOutcome, 60);
        $(reviewOutcome).click();
        Select reviewOutcomeSelect = new Select($(reviewOutcome));
        reviewOutcomeSelect.selectByVisibleText(outcome);
        $(attachFiles).click();
        commonMethods.waitForElementExplicitly(1000);
    }

    public void attachAndSubmitReview(String fileName) {
        verifyAndSwitchFrame("attachFiles-frame");
        String filePath = configFileReader.getTestDataPath() + fileName;
        File file = new File(filePath);
        filePath = file.getAbsolutePath();
        commonMethods.waitForElementExplicitly(1000);
        WebElement element = driver.findElement(files);
        element.sendKeys(filePath);
        switchToOriginal();
        verifyAndSwitchFrame();
        $(attachFiles).click();
        commonMethods.waitForElementExplicitly(10000);
        commonMethods.waitForElement(driver, By.xpath("//div[@class='auiForm-field attachedFile']//span[contains(text(),'" + fileName + "')]"));
        commonMethods.waitForElement(driver, submitReview);
        $(submitReview).click();
    }

    /**
     * Method to review all packages
     */
    public void reviewAllPackages(String outcome) {
        TaskPage taskPage = new TaskPage();
        int packagesLinks = taskPage.getPackagesLink();
        while (packagesLinks != 0) {
            verifyAndSwitchFrame();
            taskPage.clickOnPackagesLinks(1);
            verifyAndSwitchFrame();
            selectReviewOutCome(outcome);
            submitReview();
            commonMethods.waitForElementExplicitly(3000);
            taskPage.navigateAndVerifyPage();
            packagesLinks = taskPage.getPackagesLink();
        }
    }

    /**
     * Method to select review outcome
     */
    public void selectReviewOutCome(String outcome) {
        commonMethods.waitForElement(driver, reviewOutcome, 60);
        commonMethods.enterDropdownValue(reviewOutcome, outcome);
    }

    /**
     * Method to submit review
     */
    public void submitReview() {
        commonMethods.waitForElement(driver, submitReview);
        $(submitReview).click();
    }

}
