package com.oracle.babylon.Utils.setup.dataStore;

import com.beust.jcommander.JCommander;
import com.codeborne.selenide.WebDriverRunner;
import com.github.javafaker.Address;
import com.github.javafaker.Company;
import com.github.javafaker.Faker;
import com.oracle.babylon.Utils.helper.CommonMethods;
import com.oracle.babylon.Utils.setup.dataStore.pojo.Organization;
import com.oracle.babylon.Utils.setup.dataStore.pojo.User;
import com.oracle.babylon.Utils.setup.utils.ConfigFileReader;
import org.openqa.selenium.WebDriver;

import java.util.Locale;

/**
 * Class to convert the data tables from the test files to data store tables for a organization
 * Author : susgopal
 */
public class OrganizationUserCreator {

    private Organization organization = new Organization();
    private Faker faker = new Faker(new Locale("en-US"));
    private User user = new User();

    private String name = null;
    protected WebDriver driver = null;
    public OrganizationUserCreator() {
        this.driver = WebDriverRunner.getWebDriver();
    }

    /**
     * Function to set the values of the organization with data from Faker class
     */
    public void generateOrgData() {

        ConfigFileReader configFileReader = new ConfigFileReader();
        Company company = faker.company();
        String companyName = company.name().replaceFirst("'","");
        CommonMethods commonMethods = new CommonMethods();
        commonMethods.waitForElementExplicitly(2000);
        organization.setOrganizationName(companyName);
        organization.setCrn(faker.country().name() + "-" + faker.number().digits(10));
        Address address = faker.address();
        organization.setAddress(address.streetAddress());
        organization.setAddress2(faker.address().buildingNumber());
        organization.setCity(address.city());
        organization.setCounty(address.state());
        organization.setPostcode(address.zipCode());
        organization.setCountry(configFileReader.getCountryName());
        organization.setTradingName(companyName.substring(0, 3).toUpperCase());
        organization.setOrgAbbreviation(companyName.substring(0, 3).toUpperCase() + faker.number().digits(5));
        organization.setContactEmailAddress(configFileReader.getEmailId());
        String firstName = (faker.name().firstName()).replaceFirst("'","");
        String lastName = (faker.name().lastName()).replaceFirst("'","");
        name = firstName + " " + lastName;
        organization.setContactFirstName(firstName);
        organization.setContactLastName(lastName);
        organization.setContactPhone(faker.phoneNumber().phoneNumber());
        //Store the data in the data store
        new DataStore().storeOrganizationInfo("organization", organization);

    }

    /**
     * Function to create data and set in the User pojo
     */
    public void addUser() {
        user.setUsername(name.split(" ")[0] + "." + name.split(" ")[1]);
        user.setFullName(name);
        String password = faker.internet().password() + "823";
        user.setPassword(password);
        //Store the values in a data store with the name user
        new DataStore().addUser("user", user);
    }

    /**
     * Function to create data and set in the User pojo
     *
     *
     */
    public void addUser(User userData) {
        user.setUsername(faker.name().username());
        user.setFullName(userData.getFullName());
        //Password for fedRAMP has more strict rules.
        user.setPassword(faker.internet().password(12, 14, true, true, true) + "8");
        new DataStore().addUser("user", user);
    }
}
