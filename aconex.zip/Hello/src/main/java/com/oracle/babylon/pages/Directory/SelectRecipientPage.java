package com.oracle.babylon.pages.Directory;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.page;

import org.junit.Assert;
import org.openqa.selenium.By;

public class SelectRecipientPage  extends GroupPage {

    private By targetList = By.xpath("//h2[text()='Target List']");
    private By pageTitle = By.xpath("//h1[text()='Select Recipients']");


    /**
     * Method to validate the page title
     */
    public void verifyPageTitle(){
        commonMethods.waitForElement(driver, pageTitle);
        Assert.assertTrue($(pageTitle).isDisplayed());
    }

    /**
     * Method to verify if the target list text is present
     */
    public void verifyTargetList(){
        Assert.assertTrue($(targetList).isDisplayed());
    }


    /**
     * Method to delete the users from the group
     * @param fullName
     */
    public void deleteUser(String fullName){
        By by = By.xpath("//td[text()='" + fullName +"']//..//td[4]//div");
        $(by).click();
    }

}
