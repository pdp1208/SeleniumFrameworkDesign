package com.oracle.babylon.pages.Mail;

import com.codeborne.selenide.WebDriverRunner;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

/**
 * Class to hold the methods related to the the mail All Mails page
 * Author : Sai
 */
public class AllMailsPage extends MailPage {
    private By sltMailsPerpage = By.xpath("//label[@acx-mail-per-page]/select");
    private By btnExportToExcel = By.xpath("//button[contains(text(),'Export to Excel')]");

    public AllMailsPage() {
        this.driver = WebDriverRunner.getWebDriver();
    }

    //Initializing the web elements
    private By pageTitle = By.xpath("//h1//span[text()='Search Mail']");

    /**
     * Function to navigate to a sub menu from the Aconex home page
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Mail", "All");
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, pageTitle,30);
        verifyPageTitle(pageTitle);
    }

    /**
     * Function to navigate to a sub menu from the Aconex home page
     */
    public void verifyTitle() {
        verifyPageTitle(pageTitle);
    }

    /**
     * Function to verify active tab
     */
    public boolean verifyActiveTab(String tabName) {
        verifyAndSwitchFrame();
        return $(By.xpath("//a[text()='" + tabName + "']//ancestor::li")).getAttribute("ng-class").contains("active");
    }

    /**
     * Function to verify pagination
     */
    public void verifyPagination() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, sltMailsPerpage, 10);
        getRowPerColumn("mail");
        Assert.assertEquals("mail", $(showOneRowPerDropdown).getSelectedOption().getText());
        for (int i = 25; i <= 100; i += 25) {
            setResultsPerPage(Integer.toString(i));
            commonMethods.waitForElement(driver, firstMailNumber, 60);
            searchResultCount();
            Assert.assertTrue(searchResultCount() <= i);
        }
        setResultsPerPage("25");
        commonMethods.waitForElement(driver, firstMailNumber, 60);
        clickOnPagination("next");
        commonMethods.waitForElementExplicitly(2000);
        clickOnPagination("previous");
        commonMethods.waitForElementExplicitly(2000);
        if (getTotalCountMailPage() > 25) {
            navigateToPage(2);
            navigateToPage(1);
            commonMethods.waitForElementExplicitly(2000);
        }
    }

    /**
     * Function to verify fields in All tab
     */
    public void verifyFields() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver,mailCount,60);
        Assert.assertTrue($(addRemoveColumnBtn).isDisplayed());
        Assert.assertTrue($(btnExportToExcel).isDisplayed());
        Assert.assertTrue($(mailCount).isDisplayed());
        Assert.assertTrue($(reportsBtn).isDisplayed());
        Assert.assertTrue($(advancedSearchBtn).isDisplayed());
        Assert.assertTrue($(newMailBtn).isDisplayed());
        Assert.assertTrue($(myUnreadChkbox).isDisplayed());
        Assert.assertTrue($(myMailOnlyChkBox).isDisplayed());
        Assert.assertTrue($(anyMail).isDisplayed());
        Assert.assertTrue($(clearAllLink).isDisplayed());
        Assert.assertTrue($(searchBtn).isDisplayed());
    }

    /**
     * Function to get all column values of a row into string for mail search results
     */
    public Map<Integer, String> getRowSearchResults() {
        List<WebElement> elements = new ArrayList<>($$(resultTableRow));
        String row;
        int j = 0;
        Map<Integer, String> searchResults = new HashMap<>();
        for (int i = 0; i < elements.size(); i++) {
            row = elements.get(i).getAttribute("innerText");
            for (int k = i + 1; k < elements.size(); k++) {
                if (elements.get(k).getAttribute("innerText").substring(0, 6).equals("\t\t\t\t\t\t"))
                    row = row + elements.get(i + 1).getAttribute("innerText");
                else break;
                i = k;
            }
            searchResults.put(++j, row);
        }
        return searchResults;
    }

    /**
     * Function to set display of results per page
     */
    public void setResultsPerPage(String value) {
        verifyAndSwitchFrame();
        $(sltMailsPerpage).selectOption(value);
    }

}




