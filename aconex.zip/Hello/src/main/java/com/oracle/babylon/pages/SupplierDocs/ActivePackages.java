package com.oracle.babylon.pages.SupplierDocs;

import com.oracle.babylon.Utils.setup.utils.ConfigFileReader;
import com.oracle.babylon.pages.Document.DocumentPage;
import com.oracle.babylon.pages.Document.DrawingsPage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Selenide.$;

public class ActivePackages extends SupplierDocSearchPage {

    //Initialization of Web Elements
    private By pageTitle = By.xpath("//h1[contains(text(),'Search - Supplier Document Packages')]");
    private By inputPackageNumber = By.xpath("//input[@name='packageNo']");
    private By searchBtn = By.xpath("//button[@id='btnSearch_page']");
    private By addDocuments = By.xpath("//button[@title='Add Documents']");
    private By addDocRegisterLink = By.xpath("//a[contains(text(),'Add from Document Register')]");
    private By okBtn = By.xpath("//button[@id='btnattachDocs_panel_ok']");
    private By closeBtn = By.xpath("//button[@id='btnexcludedDocs_ok']");
    private By listView = By.xpath("//span[@id='viewList']");
    private By sdPckgSearchTable = By.xpath("//table[@class='dataTable']//tbody");
    private By InputDescription = By.xpath("//input[@name='description']");
    private By suppliedBy = By.xpath("//input[@id='suppliers_query']");
    private By requiredBy = By.xpath("//input[@id='requestors_query']");
    private By messageTip = By.xpath("//li[@class='message tip']");
    private By toggleModel = By.xpath("//img[@id='toggleModeIcon']");
    private By searchPkgTbleHeaders = By.xpath("//tr[@class='dataHeaders']/th");
    private By sdPackageData = By.xpath("//tbody/tr[@class='dataRow']");
    private By selectedColumnsSelect= By.xpath("//select[@id='bidi_configColumns']");
    private By btnOK = By.xpath("//button[@id='btnconfigColumns_ok']//div[@class='uiButton-label']");
    private By btnCancel = By.xpath("//button[@id='btnconfigColumns_cancel']//div[@class='uiButton-label']");
    private By sdPackageFourthColData = By.xpath("//tbody/tr[@class='dataRow']/td[4]");
    ConfigFileReader configFileReader = new ConfigFileReader();
    DrawingsPage drawingsPage = new DrawingsPage();
    DocumentPage documentPage = new DocumentPage();
    private String userDataPath = configFileReader.getUserDataPath();
    private String sdDataPath = configFileReader.getSDDataPath();
    private By activePkg = By.xpath("//table[@class='dataTable']/tbody//tr");


    /**
     * Method to navigate to create package page
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Supplier Documents", "Active Packages");
        $(loadingIcon).should(disappear);
        Assert.assertTrue(verifyPageTitle(pageTitle));
    }

    /**
     * Method to search active package present
     */
    public void searchActivePackage(String packageNumber) {
        verifyAndSwitchFrame();
        jsonMapOfMap = dataSetup.loadJsonDataToMap(sdDataPath);
        sdMap = jsonMapOfMap.get(packageNumber);
        String packageNo = sdMap.get("package_number").toString();
        $(inputPackageNumber).clear();
        $(inputPackageNumber).sendKeys(packageNo);
        commonMethods.waitForElement(driver, searchBtn, 25);
        $(searchBtn).click();
        commonMethods.waitForElementExplicitly(2000);
        $(By.xpath("//a[contains(text(),'" + packageNo + "')]")).click();
    }

    /**
     * Function to Attach a Document
     *
     * @param documentNum
     */
    public void attachDocument(String documentNum, String source) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, addDocuments);
        $(addDocuments).click();
        commonMethods.waitForElement(driver, addDocRegisterLink);
        $(addDocRegisterLink).click();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.switchToFrame(driver, "attachDocs_frame");
        if (source.equals("Drawings")) {
            drawingsPage.clickOnDrawings();
        }
        documentPage.searchDocumentNo(commonMethods.returnDocNumberInJson(documentNum));
        commonMethods.waitForElementExplicitly(1000);
        if (source.equals("Drawings")) {
            drawingsPage.clickOnListView();
        }
        commonMethods.waitForElementExplicitly(1500);
        documentPage.selectAllRecords();
        driver.switchTo().defaultContent();
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, okBtn, 30);
        $(okBtn).click();
        $(closeBtn).click();
    }

    /**
     * Method to click Add Remove Column Button
     */
    public void clickAddRemoveColumnBtn(){
        commonMethods.waitForElement(driver,addRemoveColumnsBtn);
        $(addRemoveColumnsBtn).click();
    }
    /**
     * Method to add a column in search
     */
    public void addAColumnValue(String columnName)
    {
        clickAddRemoveColumnBtn();
        By columnElement=By.xpath("//select[@id='bidi_configColumns_AVAIL']//option[text()='"+columnName+"']");
        getElementInView(columnElement);
        $(columnElement).doubleClick();
    }
    /**
     * Method to verify active package displayed
     */
    public boolean verifyNewSDInActivePkg(){
        return $(activePkg).isDisplayed();
    }
    /**
     * Method to enter package Number
     */
    public void enterSDPckgSearchFilter(String supplierPkgNo,String requiredBy,String suppliedBy) {
        enterPackageNumber(supplierPkgNo);
        enterRequiredBy(requiredBy);
        enterSuppliedBy(suppliedBy);
        searchPackage(suppliedBy);
    }
    /**
     * Method to enter package Number
     */
    public void enterPackageNumber(String packageNumber) {
        commonMethods.enterTextValue(inputPackageNumber, packageNumber);
    }
    /**
     * Method to enter required by
     */
    public void enterRequiredBy(String reqBy) {
        $(requiredBy).clear();
        $(requiredBy).sendKeys(reqBy+ Keys.ENTER);
        commonMethods.waitForElementExplicitly(5000);
        By xpath = By.xpath("//a[text()='" + reqBy + "']");
        if($(xpath).exists())
            $(xpath).click();
        commonMethods.waitForElement(driver,requiredBy);
        $(requiredBy).sendKeys(reqBy+Keys.ENTER);
        commonMethods.waitForElementExplicitly(5000);
    }
    /**
     * Method to enter supplied by
     */
    public void enterSuppliedBy(String supBy) {
        $(suppliedBy).clear();
        $(suppliedBy).sendKeys(supBy+ Keys.ENTER);
        commonMethods.waitForElementExplicitly(5000);
        By xpath = By.xpath("//a[text()='" + supBy + "']");
        if($(xpath).exists())
            $(xpath).click();
        commonMethods.waitForElement(driver,suppliedBy);
        $(suppliedBy).sendKeys(supBy+Keys.ENTER);
        commonMethods.waitForElementExplicitly(5000);
    }
    /**
     * Method to verify sticky data in SD package search filter
     */
    public void verifyStickyDataInSDPackage(String supplierPkgNo,String requiredBy,String suppliedBy){
        Assert.assertTrue(commonMethods.getTextFromInputField(driver, inputPackageNumber).contains(supplierPkgNo));
        Assert.assertTrue(commonMethods.getTextFromInputField(driver, searchQuery).contains(suppliedBy));
        Assert.assertTrue(($(By.xpath("//div[contains(text(),'"+suppliedBy+"')]")).isDisplayed()));
        Assert.assertTrue(($(By.xpath("//div[contains(text(),'"+requiredBy+"')]")).isDisplayed()));
    }
    /**
     * Method to enter Description Number
     */
    public void enterDescription(String requiredby) {
        commonMethods.enterTextValue(InputDescription, requiredby.substring(0,4));
    }
    /**
     * Method to sd package search result
     *
     */
    public boolean verifySDPckgSearchTable() {
        commonMethods.waitForElementExplicitly(3000);
        return $(searchPkgTbleHeaders).isDisplayed();
    }
    /**
     * Method to get toggle model
     */
    public void clickOnToggleModel() {
        $(toggleModel).click();
    }
    /**
     * Method to verify SD package search filter On toggle Icon
     */
    public void verifySDPckgFilterOnToggleIcon(boolean value){
        if (value) {
            Assert.assertTrue($(inputPackageNumber).isDisplayed());
            Assert.assertTrue($(InputDescription).isDisplayed());
            Assert.assertTrue($(suppliedBy).isDisplayed());
            Assert.assertTrue($(requiredBy).isDisplayed());
            Assert.assertTrue($(searchQuery).isDisplayed());
        }else
        {
            Assert.assertFalse($(inputPackageNumber).isDisplayed());
            Assert.assertFalse($(InputDescription).isDisplayed());
            Assert.assertFalse($(suppliedBy).isDisplayed());
            Assert.assertFalse($(requiredBy).isDisplayed());
            Assert.assertTrue($(searchQuery).isDisplayed());
        }

    }
    /**
     * Method to get SD Package Message tip
     */
    public String getMessageTip() {
        commonMethods.waitForElement(driver, messageTip);
        return $(messageTip).getText();
    }
    /**
     * Method to clear package Number
     */
    public void clearPackageNumber() {
        commonMethods.waitForElement(driver, inputPackageNumber);
        $(inputPackageNumber).clear();
    }
    /**
     * Function to get size of sd package data
     *
     * @return
     */
    public String getSize() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(3000);
        return String.valueOf(driver.findElements(sdPackageData).size());
    }
    /**
     * Method to verify required by
     */
    public boolean verifyReqByField(String reqBy) {
        Boolean isExist=false;
        $(suppliedBy).clear();
        $(suppliedBy).sendKeys(reqBy+ Keys.ENTER);
        commonMethods.waitForElementExplicitly(5000);
        By xpath = By.xpath("//a[text()='" + reqBy + "']");
        return $(xpath).exists();
    }
    /**
     * Method to verify required by
     */
    public boolean verifySupByField(String SupBy) {
        Boolean isExist=false;
        $(requiredBy).clear();
        $(requiredBy).sendKeys(SupBy+ Keys.ENTER);
        commonMethods.waitForElementExplicitly(5000);
        By xpath = By.xpath("//a[text()='" + SupBy + "']");
        if($(xpath).exists())
        {
            isExist=true;
        }
        return isExist;
    }
    /**
     * Function to get sd package table headerdata
     *
     * @return
     */
    public List<String> getPckgSearchTableHeader() {
        commonMethods.waitForElementExplicitly(1000);
        return commonMethods.getValues(searchPkgTbleHeaders);

    }
    /**
     * Method to move column header to 4th position
     */
    public void moveColToFourthPlace(String colName) {
        By element = By.xpath("//select[@id='bidi_configColumns']//option[contains(text(),'" + colName + "')]");
        $(addRemoveColumnsBtn).click();
        List<String> list = returnSelectedColumns();
        if (list.indexOf(colName) > 3) {
            $(element).click();
            for (int i = list.indexOf(colName); i >= 4; i--) {
                $(btnUpArrow).click();
            }
            clickOk();
        } else if (list.indexOf(colName) < 3) {
            $(element).click();
            for (int i = list.indexOf(colName); i < 3; i++) {
                $(btnDownArrow).click();
            }
            clickOk();
        } else {
            clickCancelBtn();
        }
        commonMethods.waitForElementExplicitly(1000);
        waitForResultsDisplay(sdPckgSearchTable);
    }
    /**
     * Function to get selected columns on SdPackage search page
     *
     * @return list of selected columns
     */
    public List<String> returnSelectedColumns() {
        switchToOriginal();
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, selectedColumnsSelect, 60);
        List<String> selectColumnsText= commonMethods.returnAllOptionsInDropDown(driver, selectedColumnsSelect);
        new Select($(selectedColumnsSelect)).deselectAll();
        return selectColumnsText;
    }
    /**
     * Function to accept column position in add and remove popup
     */
    public void clickOk() {
        commonMethods.waitForElement(driver, btnOK, 35);
        $(btnOK).click();
    }
    /**
     * Function to cancel column position in add and remove popup
     */
    public void clickCancelBtn() {
        commonMethods.waitForElement(driver, btnCancel, 35);
        $(btnCancel).click();
    }
    /**
     * Function to get sd package data
     *
     * @return
     */
    public List<String> SDPackageData() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(1000);
        return commonMethods.getValues(sdPackageFourthColData);
    }
    /**
     * Function to verify Package Super Search data with logical operator
     *
     */
    public void verifyResultsAsPerSearch(String data1, String data2, String operator) {
        switch (operator) {
            case "AND":
                Assert.assertTrue(SDPackageData().contains(data1));
                break;
            case "OR":
                verifySDPckgSearchData(data1,data2);
                break;
            case "NOT":
                Assert.assertFalse(SDPackageData().contains(data1));
                break;
        }
    }
    /**
     * Method to verify the Package search with OR operator through Super search
     *
     * @param Data1,Data2
     */
    public boolean verifySDPckgSearchData(String Data1,String Data2) {
        boolean isExisted=false;
        verifyAndSwitchFrame();
        List<WebElement> rows=$(sdPckgSearchTable).findElements(By.tagName("tr"));
        for(int rnum=1;rnum<=rows.size();rnum++)
        {
            isExisted= $(By.xpath("//table[@class='dataTable']//tbody/tr["+rnum+"]//td[contains(.,'"+Data1+"') or contains(.,'"+Data2+"')]")).isDisplayed();
            if(!isExisted) break;
        }
        return isExisted;
    }
    /**
     * Method to verify the Package search through Super search
     *
     * @param data
     */
    public boolean verifySuperResults(String data) {
        boolean isExisted=false;
        verifyAndSwitchFrame();
        List<WebElement> rows=$(sdPckgSearchTable).findElements(By.tagName("tr"));
        for(int rnum=1;rnum<=rows.size();rnum++)
        {
            isExisted= $(By.xpath("//table[@class='dataTable']//tbody/tr["+rnum+"]//td[contains(.,'"+data+"')]")).isDisplayed();
            if(!isExisted) break;
        }
        return isExisted;
    }
}

