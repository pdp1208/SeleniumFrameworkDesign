package com.oracle.babylon.pages.SupplierDocs;

import com.oracle.babylon.Utils.helper.CommonMethods;
import org.openqa.selenium.By;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import static com.codeborne.selenide.Selenide.$;

public class SupplierDocInitiateSubmissionPage extends SupplierDocPage{
    CommonMethods commonMethods=new CommonMethods();
    private By bulkEditBtn = By.xpath("//button[@id='btnBulkEdit']");
    private By commentsArea = By.xpath("//textarea[@id='bulkEditComments']");
    private By bulkDate = By.xpath("//input[@id='bulkPlannedSubmissionDate_da']");
    private By allDocuments = By.xpath("//input[@id='toAll']");
    private By bulkEditOkBtn = By.xpath("//button[@id='btnbulkEditPanel_ok']");
    public String returnSubmissionMessage(String docNum)
    {
        By docMess=By.xpath("//table[@id='excludedDocList']//td[contains(text(),'"+docNum+"')]//..//td[5]");
        commonMethods.waitForElement(driver,docMess);
        return $(docMess).getText();
    }


    /**
     * Method to click on bulk edit button
     */
    public void clickBulkEditBtn(){
        $(bulkEditBtn).click();
    }

    /**
     * Method to bulk edit the documents selected
     * @param comments
     */
    public void bulkEdit(String comments){
        $(commentsArea).sendKeys(comments);
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        Date tomorrow = calendar.getTime();
        commonMethods.enterTextValue(bulkDate,dateFormat.format(tomorrow));
        $(allDocuments).setSelected(true);
        $(bulkEditOkBtn).click();
    }

}
