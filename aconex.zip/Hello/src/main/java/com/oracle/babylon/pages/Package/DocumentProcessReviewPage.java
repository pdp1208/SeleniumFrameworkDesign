package com.oracle.babylon.pages.Package;

import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.Select;

import static com.codeborne.selenide.Selenide.$;

public class DocumentProcessReviewPage extends Navigator {

    public By startDocumentReviewHeader= By.xpath("//*[text()='Start Document Review Process']");
    private By nextBtn=By.xpath("//*[text()='Next']");
    private By participantsAndDuration=By.xpath("//*[text()='Confirm Participants and Durations']");
    private By reviewNameInput=By.xpath("//input[@id='reviewName|input']");
    private By startReview=By.xpath("//*[text()='Start Review']");
    private By successStartMsg=By.xpath("//*[text()='Review started successfully']");
    private By returnToDocRegister=By.xpath("//*[text()='Return to Document Register']");
    private By title = By.xpath("//div[text()='Review tasks']");
    private By docReviewsHeader=By.xpath("//*[@class='auiToolbar fixed']//div[text()='Document Reviews']");
    private By documentNumberInput=By.xpath("//input[contains(@aria-label,'umber Filter Input')]");
    private By titleFilterInput=By.xpath("(//input[contains(@aria-label,'Title Filter Input')])[1]");
    private By reviewBtn=By.xpath("//button[text()='Review']");
    private By reviewOutcome = By.xpath("//select[@data-automation-id='reviewOutcome']");
    private By viewIssues=By.xpath("//button[text()='View Issues']");
    private By newIssue=By.xpath("//button[text()='New Issue']");
    private By issueTitle=By.xpath("//input[@placeholder='Enter a title for the issue']");
    private By issueType=By.xpath("//option[text()='Select issue type']//..//..//select");
    private By backBtn = By.xpath("//button[@class='auiButton back']");
    private By selectDoc=By.xpath("//td//input[@type='checkbox']");
    private By submitBtn=By.xpath("//button[text()='Submit']");
    private By reviewSuccessMsg=By.xpath("//*[contains(text(),'were submitted successfully')]");
    private By startDocumentProcessBtn=By.xpath("//button[text()='Start Document Process']");
    private By btnClose = By.xpath("//button[contains(text(),'Close')]");
    private By reviewIssueCreatedMsg=By.xpath("//*[contains(text(),'New review issue created')]");
    private By reviewCompletedStatus=By.xpath("//*[@col-id='reviewStatusName']//*[contains(text(),'Completed')]");
    private By reviewApprovedStatus=By.xpath("//*[@col-id='finalOutcome']//*[contains(text(),'Approved')]");
    private By openReviewStatus=By.xpath("//*[@class='review-issue-status']//*[text()='Open']");

    public void navigateAndVerifyPage(){
        getMenuSubmenu("Document Processes", "Assigned to me");
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, title, 20);
        Assert.assertTrue($(title).isDisplayed());
    }
    public void clickReviewOutCome(String outcome)
    {
        $(reviewOutcome).click();
        Select reviewOutcomeSelect = new Select($(reviewOutcome));
        reviewOutcomeSelect.selectByVisibleText(outcome);
        commonMethods.waitForElementExplicitly(1000);
    }

    public void verifyIssueCreated(String issueName)
    {
        By reviewIssue=By.xpath("//div[@class='review-issues-table-container']//*[contains(text(),'"+issueName+"')]");
        commonMethods.waitForElement(driver,reviewIssue,60);
    }

    public void clickBackBtn()
    {
        commonMethods.waitForElement(driver,backBtn);
        $(backBtn).click();
    }

    public void navigateToDocReviews()
    {
        getMenuSubmenu("Document Processes", "Document Reviews");
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, docReviewsHeader, 20);
    }

    public void navigateToIssues()
    {
        getMenuSubmenu("Document Processes", "Issues");
        verifyAndSwitchFrame();
    }

    public void clickStartDocumentProcess()
    {
        commonMethods.waitForElement(driver,startDocumentProcessBtn);
        $(startDocumentProcessBtn).click();
    }


    public String completeDocumentReviewProcess(String reviewTemplate)
    {
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver,startDocumentReviewHeader,40);
        $(nextBtn).click();
        By reviewLoc=By.xpath("//tr//td[contains(text(),'"+reviewTemplate+"')]");
        commonMethods.waitForElement(driver,reviewLoc);
        $(reviewLoc).click();
        $(nextBtn).click();
        commonMethods.waitForElement(driver,participantsAndDuration);
        $(nextBtn).click();
        String reviewName=faker.name().firstName();
        commonMethods.waitForElement(driver,reviewNameInput);
        $(reviewNameInput).sendKeys(reviewName);
        commonMethods.waitForElementExplicitly(6000);
        $(startDocumentReviewHeader).click();
        commonMethods.waitForElement(driver,startReview);
        $(startReview).click();
        commonMethods.waitForElement(driver,successStartMsg);
        return reviewName;
    }

    public void clickReturnToDocRegister()
    {
        commonMethods.waitForElement(driver,returnToDocRegister);
        $(returnToDocRegister).click();
    }

    public void searchDoc(String docNo)
    {
        commonMethods.waitForElement(driver,documentNumberInput);
        $(documentNumberInput).sendKeys(docNo + Keys.ENTER);
    }

    public void selectReviewOnDoc(String docNo)
    {
        searchDoc(docNo);
        commonMethods.waitForElementExplicitly(3000);
        $(reviewBtn).click();
    }

    public String createIssue(String docNo)
    {
        commonMethods.waitForElement(driver,viewIssues);
        $(viewIssues).click();
        commonMethods.waitForElement(driver,newIssue);
        commonMethods.waitForElementExplicitly(3000);
        $(newIssue).click();
        String issueName=faker.name().lastName();
        commonMethods.waitForElement(driver,issueTitle);
        $(issueTitle).sendKeys(issueName);
        $(issueType).click();
        Select reviewOutcomeSelect = new Select($(issueType));
        reviewOutcomeSelect.selectByVisibleText("Information");
        commonMethods.waitForElementExplicitly(1000);
        clickSaveBtn();
        commonMethods.waitForElement(driver,reviewIssueCreatedMsg);
        $(btnClose).click();
        return issueName;
    }

    public void submitDocOnReview()
    {
        commonMethods.waitForElement(driver,selectDoc);
        $(selectDoc).click();
        commonMethods.waitForElement(driver,submitBtn);
        $(submitBtn).click();
        commonMethods.waitForElement(driver,reviewSuccessMsg);
        $(btnClose).click();
    }

    public void verifyReviewStatus(String docNo)
    {
        searchDoc(docNo);
        commonMethods.waitForElement(driver,reviewCompletedStatus);
        commonMethods.waitForElement(driver,reviewApprovedStatus);
    }

    public void verifyIssueStatus(String issueName)
    {
        commonMethods.waitForElement(driver,titleFilterInput);
        $(titleFilterInput).sendKeys(issueName+Keys.ENTER);
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver,openReviewStatus,60);
    }


}
