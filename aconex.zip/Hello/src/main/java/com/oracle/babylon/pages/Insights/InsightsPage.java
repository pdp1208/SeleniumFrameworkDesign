package com.oracle.babylon.pages.Insights;

import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.DateTimeException;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static com.codeborne.selenide.Selenide.$;

public class InsightsPage extends Navigator {

    private By lastUpdatedDateTime=By.xpath("//div[@class='last-updated']");

    /**
     * Function to navigate to Task page
     */
    public void navigateAndVerifyPage() {
        commonMethods.waitForElementExplicitly(4000);
        getMenuSubmenu("Insights", "Process Insights Beta");
        //verifyPageTitle(pageTitle);
    }

    public String getLastUpdated()
    {
        String lastUpdatedTimeValue=$(lastUpdatedDateTime).getText();
        lastUpdatedTimeValue=lastUpdatedTimeValue.replace("Last Updated: ","");
        lastUpdatedTimeValue=lastUpdatedTimeValue.replace(",","");
        lastUpdatedTimeValue=lastUpdatedTimeValue.replace(lastUpdatedTimeValue.substring(lastUpdatedTimeValue.length()-2),"").trim();
        String suffix;
        List<String> separate= Arrays.asList(lastUpdatedTimeValue.split(" "));
        if(separate.get(0).length()>3)
        {
            suffix=lastUpdatedTimeValue.substring(2,4);
        }else
        {
            suffix=lastUpdatedTimeValue.substring(1,3);
        }

        lastUpdatedTimeValue=lastUpdatedTimeValue.replace(suffix,"");
        System.out.println(lastUpdatedTimeValue);
        return lastUpdatedTimeValue;

/*

        if(lastUpdatedTimeValue.length()==21)
        {
             suffix=lastUpdatedTimeValue.substring(2,4);
        }else
        {
             suffix=lastUpdatedTimeValue.substring(1,3);
        }
*/
    }

    public void verifyDateTimeStamp()
    {
        int dayDifference;
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -4);
        Date leastDate = cal.getTime();
        SimpleDateFormat format=new SimpleDateFormat("dd MMM yyyy HH:mm:ss");
        String lastUpdateTime=getLastUpdated();
        try {
            Date currentValue=format.parse(lastUpdateTime);
            long difference_In_Time = currentValue.getTime() - leastDate.getTime();
            System.out.println((int)difference_In_Time);
            long difference_In_Days
                    = (difference_In_Time
                    / (1000 * 60 * 60 * 24))
                    % 365;
             dayDifference=(int)difference_In_Days;
            Assert.assertTrue(dayDifference>=0);
            Assert.assertTrue(dayDifference<=4);
        }
        catch (Exception e)
        {
            Assert.assertEquals(true,false);
        }

       // String  leastDateValue=format.format(leastDate);
        //System.out.println(leastDateValue);
    }
}
