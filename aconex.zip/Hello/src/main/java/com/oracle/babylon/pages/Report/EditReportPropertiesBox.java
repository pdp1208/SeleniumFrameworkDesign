package com.oracle.babylon.pages.Report;
import com.oracle.babylon.Utils.helper.Navigator;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.support.ui.Select;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;

/**
 * This is a page object class for report properties dialog box.
 *
 */
public class EditReportPropertiesBox extends Navigator {

    private By editPropertyBox = By.cssSelector("#saveAsDialog .auiModal-content");
    private By reportNameInput = By.cssSelector("#saveAsInputName");
    private By reportDescription = By.cssSelector("#saveAsInputDescription");
    private By shareWithDropDown = By.cssSelector("#select-share-with-list");
    private By saveButton = By.cssSelector("#saveAsBtnSave");
    private By cancelButton = By.cssSelector("#saveAsBtnCancel");
    private By reportLoader = By.xpath("//div[contains(text(),'Loading Reports.')]");
    private By saveAsSuccessMessage = By.cssSelector("#save-success");
    private By savePropertiesSuccessMessage = By.xpath("//div[contains(@class,'success')]/div[contains(text(),'Report properties updated successfully')]");

    /**
     * Method to wait untill report properties box appears.
     *
     */
    public void waitForEditPropertiesBoxToOpen(){
        $(editPropertyBox).waitUntil(appear, 6000);
    }

    /**
     * Method to edit report name.
     *
     * @param reportName - Name of the report.
     */
    public void editReportName(String reportName){
        $(reportNameInput).clear();
        $(reportNameInput).sendKeys(reportName);
    }

    /**
     * Method to edit description for the report.
     *
     * @param description - Description of the report.
     */
    public void editDescription(String description){
        $(reportDescription).clear();
        $(reportDescription).sendKeys(description);
    }

    /**
     * Method to 'share wtih' option for the report.
     *
     * @param value - 'Share with' option to be selected.
     */
    public void selectShareWithOption(String value){
        Select shareWith = new Select($(shareWithDropDown));
        shareWith.selectByValue(value);
    }

    /**
     * Method to save as report.
     *
     */
    public void save(){
        $(saveButton).click();
        $(saveAsSuccessMessage).waitUntil(appear, 90000);
        $(saveAsSuccessMessage).waitUntil(disappear, 50000);
        try {
            commonMethods.waitForElement(driver, reportLoader, 10);
            $(reportLoader).waitUntil(hidden, 60000, 6000);
        } catch(TimeoutException e){
            //ignore
        }
    }

    /**
     * Method to save report properties.
     *
     */
    public void saveReportProperties(){
        $(saveButton).click();
        $(savePropertiesSuccessMessage).waitUntil(appear, 20000);
        $(savePropertiesSuccessMessage).waitUntil(disappear, 20000);
        try {
            commonMethods.waitForElement(driver, reportLoader, 20);
            $(reportLoader).waitUntil(hidden, 30000, 3000);
        } catch(TimeoutException e){
            //ignore
        }
    }

    /**
     * Method to cancel report properties modifications.
     *
     */
    public void cancel(){
        $(cancelButton).click();
    }

}