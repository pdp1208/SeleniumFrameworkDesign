package com.oracle.babylon.pages.Package;

import com.codeborne.selenide.WebDriverRunner;
import com.github.javafaker.Faker;
import com.oracle.babylon.Utils.helper.Navigator;
import com.oracle.babylon.Utils.setup.utils.ConfigFileReader;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;

import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Selenide.$;

public class ManageReviewTemplate extends Navigator {

    private By createNewTemplateBtn = By.xpath("//*[text()='Create Template']");
    private By createTemplateBtn = By.xpath("//button//span[text()='Create Template']");
    private By title = By.xpath("//div[text()='Review Templates']");
    private By templateNameCells = By.xpath("//table[@class='auiTable']////table[@class='auiTable']//tbody//tr//td[1]");
    private By templateName = By.xpath("//div[@data-automation-id='templateName']");
    private By createTemplateName = By.xpath("//div//span[text()='Template Name']//following::input");
    private By createNewTemplateName = By.xpath("//input[@id='template-name|input']");
    private By newStep = By.xpath("//div[@id='newStepImage']");
    private By stepName = By.xpath("//span[text()='Step Name']//following::input");
    private By participants = By.xpath("//td[text()='Review Participants']//following::ul");
    private By participantsTxtBox = By.xpath("//td[text()='Review Participants']//following::input[@aria-controls='oj-listbox-results-1']");
    private By addStepBtn = By.xpath("//button//span[text()='Add Step']");
    private By participantsSearch=By.xpath("//input[@title='Search field']");
    private By participantHighlight= By.xpath("//span[@class='oj-highlighttext-highlighter']");
    private By addBtn=By.xpath("//*[@id='review-flow-step-modal-add-participants-button']//span[text()='Add']");
    private By addStepBtnOnStageOne=By.xpath("//div[@data-automation-id='stage-1']//span[text()='Add Step']");
    private By saveBtn = By.xpath("//button[text()='Save']");
    private By cancelBtn = By.xpath("//button[text()='Cancel']");
    private By duration = By.xpath("//div[@class='stageDuration-popoverButtons']//input");
    private By applyBtn = By.xpath("//button//span[text()='Update']");
    private ConfigFileReader configFileReader = new ConfigFileReader();
    private String userDataPath = configFileReader.getUserDataPath();
    private By startReviewOption = By.xpath("//input[@id='permission-starting-review|input']");
    private By duringReviewOption = By.xpath("//input[@id='permission-during-review|input']");

    private By noChanges_permission = By.xpath("//span[text()='Not make any changes']");
    private By participants_permission = By.xpath("//span[text()='Change the participants only']");
    private By durations_permission = By.xpath("//span[text()='Change the durations only']");
    private By anyAlerations_permission = By.xpath("//span[text()='Change the participants only']");
    private By orgSubmissions_permission = By.xpath("//span[contains(text(),'Only see the submissions from other reviewers if they belong to the organization initiating the review')]");
    private By anyOrgSubmissions_permission = By.xpath("//span[contains(text(),'See any other reviewer's submission')]");
    private By numberOfDays = By.xpath("//span[contains(text(),'Duration')]//following::input");
    private By activateBtn = By.xpath("//button//span[text()='Activate']");
    private By calender = By.xpath("//oj-button[@data-automation-id='stage-edit-1']");
    private By addStepDetails = By.xpath("//oj-button[@data-automation-id='step-add-1']");
    private By txtBoxSearchPackage = By.xpath("//div[@id='searchInputContainer_filter']//input");
    String templateNameStr = null;
    private By newActivateBtn = By.xpath("//span[contains(text(),'Activate')]");
    private By newStepName = By.xpath("//input[@id='review-flow-step-modal-step-name|input']");
    private By calender2 = By.xpath("//input[@id='duration-2|input']");
    private By serialAddStep = By.xpath("//oj-button[@data-automation-id='step-add-1']");
    private By serialAddStep2 = By.xpath("//oj-button[@data-automation-id='step-add-2']");
    private By addStage = By.xpath("//oj-button[@title='Add Stage']");
    private By reviewParticipantSearch = By.xpath("//ul[@class='oj-select-choices']");
    private By reviewParticipantInput = By.xpath("//input[@title='Search field']");
    private By reviewParticipantHighlight = By.xpath("//span[@class='oj-highlighttext-highlighter']");
    private By roleDropdownArrow = By.xpath("//table//tr//span[@class='oj-text-field-end']//a");
    private By leadReviewer = By.xpath("//span[contains(text(),'Lead Reviewer')]");
    private By reviewParticipantAdd = By.xpath("//table//tr//button//span[contains(text(),'Add')]");
    private By reviewParticipantAddStep = By.xpath("//div[@class='oj-dialog-footer']//span[contains(text(),'Add Step')]");
    private By startingReviewDropdown = By.xpath("//oj-select-single[@id='permission-starting-review']//a");
    private By duringReviewDropdown = By.xpath("//oj-select-single[@id='permission-during-review']//a");
    private By typeToFilter=By.xpath("//input[@placeholder='Type to filter']");


    public void navigateAndVerifyPage(){
        getMenuSubmenu("Packages", "Manage Review Templates");
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(8000);
        commonMethods.waitForElement(driver, title, 60);
        Assert.assertTrue("Manage Review templates page title is not displayed", $(title).isDisplayed());
    }

    /**
     * Method to create a review template. As of now, only single step is working
     * @param stepInfo
     */
    public void createReviewTemplate(Map<String, String> stepInfo){
        $(createTemplateBtn).click();
        Faker faker = new Faker();
        commonMethods.waitForElementExplicitly(2000);
        templateNameStr= faker.company().name();
        $(createTemplateName).sendKeys(templateNameStr);
        String[] userIds = stepInfo.get("User_ID").split(",");
        for(int count=0; count<userIds.length; count++) {
            Map<String, Map<String, Object>> mapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
            Map<String, Object> userMap = mapOfMap.get(userIds[count]);
            By dropZone = By.xpath("//div[@class='visualFlowEditor-stageSeparator dropzone' and @data-stageindex='" + count + "']");

            By addStepDetails = By.xpath("//div[@data-automation-id='visualFlowEditor-stageDropzone' and @data-stageindex='" + count + "']//button[text()='Add step details']");
            By calender = By.xpath("//div[@data-automation-id='visualFlowEditor-stageDropzone' and @data-stageindex='" + count + "']//span[@class='auiIcon calendar']");
            if(count>0) {
                //Actions actions = new Actions(driver);
                //driver = WebDriverRunner.getWebDriver();
                //actions.click($(newStep)).build().perform();
                commonMethods.waitForElementExplicitly(2000);
                dragAndDrop(newStep,dropZone);

                //actions.dragAndDropBy()
            }
            commonMethods.waitForElementExplicitly(4000);
            editCalender(calender,stepInfo.get("Number_Of_Days"));
            editStepDetails(addStepDetails, userMap.get("org_name").toString());
            addParticipant(userMap.get("full_name").toString());
            if(stepInfo.get("Parallel").equals("Yes"))
            {
                commonMethods.waitForElementExplicitly(4000);
                dragAndDrop(newStep,By.xpath("//div[@class='visualFlowEditor-stageDropzone dropzone']"));
                //JavascriptExecutor jss = (JavascriptExecutor) driver;
                //jss.executeScript("function createEvent(typeOfEvent) {\n" +"var event =document.createEvent(\"CustomEvent\");\n" +"event.initCustomEvent(typeOfEvent,true, true, null);\n" +"event.dataTransfer = {\n" +"data: {},\n" +"setData: function (key, value) {\n" +"this.data[key] = value;\n" +"},\n" +"getData: function (key) {\n" +"return this.data[key];\n" +"}\n" +"};\n" +"return event;\n" +"}\n" +"\n" +"function dispatchEvent(element, event,transferData) {\n" +"if (transferData !== undefined) {\n" +"event.dataTransfer = transferData;\n" +"}\n" +"if (element.dispatchEvent) {\n" + "element.dispatchEvent(event);\n" +"} else if (element.fireEvent) {\n" +"element.fireEvent(\"on\" + event.type, event);\n" +"}\n" +"}\n" +"\n" +"function simulateHTML5DragAndDrop(element, destination) {\n" +"var dragStartEvent =createEvent('dragstart');\n" +"dispatchEvent(element, dragStartEvent);\n" +"var dropEvent = createEvent('drop');\n" +"dispatchEvent(destination, dropEvent,dragStartEvent.dataTransfer);\n" +"var dragEndEvent = createEvent('dragend');\n" +"dispatchEvent(element, dragEndEvent,dropEvent.dataTransfer);\n" +"}\n" +"\n" +"var source = arguments[0];\n" +"var destination = arguments[1];\n" +"simulateHTML5DragAndDrop(source,destination);",$(newStep), $(By.xpath("//div[@class='visualFlowEditor-stage']//div[@class='visualFlowEditor-stageTitleContainer']")));
                //commonMethods.waitForElementExplicitly(4000);
                addStepDetails = By.xpath("//div[@data-automation-id='visualFlowEditor-stageDropzone' and @data-stageindex='0']//button[text()='Add step details']");
                editStepDetails(addStepDetails, userMap.get("org_name").toString());
                addParticipant(userMap.get("full_name").toString());
            }
        }
        $(addBtn).click();
        $(addStepBtn).click();
        commonMethods.waitForElement(driver, startReviewOption);
        $(startReviewOption).click();
            if(stepInfo.get("Initiator_Permission").equals("No")){
                $(noChanges_permission).click();
            } else if(stepInfo.get("Initiator_Permission").equals("Participants")){
                $(participants_permission).click();
            } else if(stepInfo.get("Initiator_Permission").equals("Durations")){
                $(durations_permission).click();
            } else if(stepInfo.get("Initiator_Permission").equals("Any")){
                $(anyAlerations_permission).click();
            }


            $(duringReviewOption).click();
            if(stepInfo.get("Reviewer_Permission").equals("Initiator_Org")){
                $(orgSubmissions_permission).click();
            } else if(stepInfo.get("Reviewer_Permission").equals("Any_Org")){
                $(anyOrgSubmissions_permission).click();
            }


            $(activateBtn).click();
            commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Method to write the review created into a json file
     * @param templateId
     */
    public void writePackageTemplate(String templateId){
        String packageTemplatePath = configFileReader.getPackageTemplateDataPath();
        String key = "template_name";
        Map<String, Map<String, Object>> mapOfMap = new Hashtable<>();
        Map<String, Object> mapToReplace = new Hashtable<>();
        mapToReplace.put(key, templateNameStr);
        mapOfMap.put(templateId, mapToReplace);
        dataSetup.fileWrite(templateId, mapOfMap, packageTemplatePath);
    }


    /**
     * Method to validate the review
     * @param templateName
     * @return
     */
    public Boolean validateReviewName(String templateName){
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, txtBoxSearchPackage, 60);
        commonMethods.enterTextValue(txtBoxSearchPackage, templateName);
        commonMethods.waitForElementExplicitly(5000);
        By element = By.xpath("//div[contains(text(),\"" + templateName + "\")]");
        return $(element).isDisplayed();
    }

    /**
     * Method to edit the calender details in the step
     * @param calender
     * @param noOfDays
     */
    public void editCalender( By calender, String noOfDays)
    {
        commonMethods.waitForElementExplicitly(1000);
        commonMethods.waitForElement(driver, calender,15);
        $(calender).click();
        commonMethods.waitForElement(driver, numberOfDays);
        $(numberOfDays).clear();
     //   $(numberOfDays).click();
        $(numberOfDays).sendKeys(noOfDays);
        $(applyBtn).click();
    }

    /**
     * Method to edit the details of the step
     * @param addStepDetails
     * @param stepNameStr
     */
    public void editStepDetails(By addStepDetails, String stepNameStr){
        $(addStepDetails).click();
        commonMethods.waitForElementExplicitly(2000);
        $(stepName).clear();
        $(stepName).sendKeys(stepNameStr);
    }

    public void addParticipant(String name)
    {
        commonMethods.waitForElementExplicitly(4000);
        commonMethods.waitForElement(driver,participants,40);
        $(participants).click();
        commonMethods.waitForElement(driver,participantsSearch);
        $(participantsSearch).sendKeys(name);
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver,participantHighlight);
        $(participantHighlight).click();
        commonMethods.waitForElement(driver, addBtn);
        $(addBtn).click();
        commonMethods.waitForElement(driver,addStepBtn);
        $(addStepBtn).click();
    }

    /**
     * Method to create a review template. As of now, only single step is working
     *
     * @param stepInfo
     */
    public void createNewReviewTemplate(Map<String, String> stepInfo) {
        $(createNewTemplateBtn).click();
        templateNameStr = commonMethods.getRandomString(5);
//        templateNameStr = templateNameStr.replaceAll("[-+^,' ]", "a");
        $(createNewTemplateName).sendKeys(templateNameStr);
        String[] userIds = stepInfo.get("User_ID").split(",");
        $(addStepBtnOnStageOne).click();
      //  $(calender).clear();
       // $(calender).sendKeys(stepInfo.get("Number_Of_Days"));
        getElementInView(serialAddStep);
        for (int count = 0; count < userIds.length; count++) {
            Map<String, Map<String, Object>> mapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
            Map<String, Object> userMap = mapOfMap.get(userIds[count]);
            if (count > 0 && stepInfo.get("Parallel").equals("Yes")) {
                commonMethods.waitForElementExplicitly(6000);
                editStepDetails(userMap.get("org_name").toString());
                addParticipant(userMap.get("full_name").toString());
                commonMethods.scrollPageUp(driver);
                $(addStage).click();
                //$(calender2).clear();
                //$(calender2).sendKeys(stepInfo.get("Number_Of_Days"));
                $(serialAddStep2).click();
                editStepDetails(userMap.get("org_name").toString());
                addParticipant(userMap.get("full_name").toString());
                commonMethods.scrollPageUp(driver);
            }
            commonMethods.waitForElementExplicitly(4000);
            editStepDetails(userMap.get("org_name").toString());
            addParticipant(userMap.get("full_name").toString());
            $(serialAddStep).click();
            editStepDetails(userMap.get("org_name").toString());
            addParticipant(userMap.get("full_name").toString());
        }
//        $(startingReviewDropdown).click();
//        $(By.xpath("//span[contains(text(),'" + stepInfo.get("Starting_A_Review") + " ')]"));
//        $(duringReviewDropdown).click();
//        $(By.xpath("//span[contains(text(),'" + stepInfo.get("During_The_Review") + " ')]"));
        $(newActivateBtn).click();
        commonMethods.waitForElementExplicitly(6000);
    }

    /**
     * Method to edit the details of the step
     *
     * @param stepNameStr
     */
    public void editStepDetails(String stepNameStr) {
        $(newStepName).clear();
        Faker faker = new Faker();
        String step = "step1 " + faker.number().digits(2);
        commonMethods.waitForElement(driver,newStepName);
        commonMethods.waitForElementExplicitly(3000);
        $(newStepName).sendKeys(step);
    }

}
