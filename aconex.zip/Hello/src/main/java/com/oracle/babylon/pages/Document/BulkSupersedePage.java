package com.oracle.babylon.pages.Document;

import com.github.javafaker.Faker;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class BulkSupersedePage extends DocumentPage {

    private By revision = By.xpath("//input[@name='revision']");
    private By type = By.xpath("//select[@id='doctype']");
    private By scaleFrom = By.xpath("//input[@name='scale_FROM_0']");
    private By scaleTo = By.xpath("//input[@name='scale_TO_0']");
    private By percentComplete = By.xpath("//input[@name='percentcomplete_0']");
    private By confidential = By.xpath("//input[contains(@id,'confidential')]");
    private By dateErrorMessage = By.xpath("//div[contains(text(),'This field must be in the format DD/MM/YYYY')]");

    private By status = By.xpath("//select[@id='docstatus']");
    protected By discipline = By.xpath("//select[@id='discipline']");
    private By revisionDate = By.xpath("//input[contains(@id,'revisiondate')]");
    private By excludeMarkup = By.xpath("//input[@id='excludeMarkups_0']");
    private By table = By.xpath("//div[@id='BulkSupersedeGrid']//table");
    private By updateDocumentsBtn = By.xpath("//button[contains(text(),'Update Documents')]");
    private By successMessage = By.xpath("//div[@class='auiMessage success']");

    private By noRecords = By.xpath("//div[@class='files']//ul//li");
    private By noChanges = By.xpath("//div[text()='There are still some unmodified documents. Please modify or remove them.']");
    private By attachFileHeader = By.xpath("//span[text()='Select a file from your temporary files']");
    private By cancelBtn = By.xpath("//button[@id='associatedfile_0_panel-cancel']");
    private By file = By.xpath("//span[@class='file']//img[@class='auiIcon-file small']");
    private By fileSelect = By.xpath("//select[@id='associatedfile_0_MultiSelectList']");
    private By okBtn = By.xpath("//button[@title='OK']");
    private By columnHeaders = By.xpath("//thead[@class='headerColBodySync']//tr//th//div");
    private By addMoreBtn = By.xpath("//button[@title='Add more']");
    private By viewCopyToPanelBtn = By.xpath("//button[@id='btnViewCopyToPanel']");
    private By hideCopyToPanelBtn = By.xpath("//div[text()='Hide Copy-To Panel']");
    private By copyToAllBtn = By.xpath("//button[@id='btnCopyToAll']");
    private By copyToSelectedBtn = By.xpath("//button[@id='btnCopyToSelected']");
    private By fileName = By.xpath("//span[@class='file clickable']//span[2]");
    private By firstCheckBox = By.xpath("//div[@class='files']//input[@type='checkbox']");
    private By removeBtn = By.xpath("//button[@title='Remove']");
    protected By bulkEditBtn = By.xpath("//button[contains(@title,'Bulk Edit')]");
    private By spanModified = By.xpath("//span[contains(text(),'Modified')]");
    private By btnApply = By.xpath("//button[contains(text(),'Apply')]");
    private By lblBulkEdit = By.xpath("//div[contains(text(),'Bulk Edit')]");
    private By btnBulkEditCancel = By.xpath("//div[contains(@class,'bulk-edit-container')]//button[contains(text(),'Cancel')]");
    private String tblViewFirstCheckBox = "//div[@class='ag-pinned-left-cols-container']//div//span[contains(@class,'ag-icon-checkbox')][2]";
    private By btnSubmit = By.xpath("//button[@id='btnSubmit']");
    private By allFilesSelect = By.xpath("//div[@id='MoveToRegisterGrid']//thead//div[@id='checkboxselect']");
    private By selectResults = By.xpath("//div[text()='Select All Results']");
    private By docMoveToRegisterGrid = By.xpath("//div[@id='MoveToRegisterGrid']//input[@title='Document Number']");

    public void setExcludeMarkup(Boolean value) {
        $(excludeMarkup).setSelected(value);
    }

    public void setRevision(String value) {
        commonMethods.waitForElement(driver, revision, 30);
        $(revision).clear();
        $(revision).sendKeys(value);
    }

    public void setStatus(String value) {
        commonMethods.waitForElement(driver, status, 30);
        $(status).click();
        $(status).selectOptionContainingText(value);
    }


    public void setDiscipline(String value) {
        $(discipline).click();
        $(discipline).selectOptionContainingText(value);
    }

    public void setTitle(String value) {
        $(titleName).click();
        Faker faker = new Faker();
        value = value + faker.number().digits(5);
        $(titleName).clear();
        $(titleName).sendKeys(value);
    }

    public void setDocumentNum(String value) {
        $(documentNumberField).click();
        Faker faker = new Faker();
        if (value != null && value.equalsIgnoreCase("random")) {

            String fieldValue = faker.number().digits(2);
            // $(documentNo).clear();
            $(documentNumberField).sendKeys(fieldValue);

        } else {
            $(documentNumberField).clear();
            $(documentNumberField).sendKeys(value);
        }
    }

    public void replaceDocIdField(String newValue) {
        // By oldValueBy = By.xpath("//div[text()='" + oldValue + "']");
        commonMethods.waitForElement(driver, documentNumberField, 60);
        $(editDocNum).click();
        $(documentNumberField).clear();
        $(documentNumberField).sendKeys(newValue);
        clickSupersedeDocuments();
    }

    /**
     * Method to set the revision date according to a time zone
     *
     * @param value
     */
    public void setRevisionDate(String value) {
        $(revisionDate).click();
        String date = commonMethods.getDate(configFileReader.getTimeZone(), value);
        $(revisionDate).clear();
        $(revisionDate).sendKeys(date);
        $(revisionDate).sendKeys(Keys.ENTER);
    }


    public void fillRevisionDateField(String value) {
        $(revisionDate).click();
        $(revisionDate).clear();
        $(revisionDate).sendKeys(value);
        $(revisionDate).sendKeys(Keys.ENTER);
    }


    public void setType(String value) {
        $(type).click();
        $(type).selectOptionContainingText(value);
    }

    /**
     * Method to set the scale field
     *
     * @param value
     */
    public void setScale(String value) {
        String[] strList = value.split(":");
        $(scaleFrom).click();
        $(scaleFrom).sendKeys(strList[0]);
        //$(scaleTo).click();
        $(scaleTo).sendKeys(strList[1]);
    }

    /**
     * Method to set the percent complete field
     *
     * @param value
     */
    public void setPercentComplete(String value) {
        // $(percentComplete).click();
        $(percentComplete).sendKeys(value);

    }

    /**
     * Method to set the percent complete field
     *
     * @param value
     */
    public void setConfidentiality(String value) {
        if (!$(confidential).isSelected() && value.equalsIgnoreCase("yes")) {
            $(confidential).setSelected(true);
        }

    }


    public boolean validateSuccessMessage() {
        commonMethods.waitForElementExplicitly(5000);
        commonMethods.waitForElement(driver, docUploadSuccess, 30);
        return $(docUploadSuccess).isDisplayed();
    }


    public void clickSupersedeDocuments() {
        commonMethods.waitForElementClickable(driver, updateDocumentsBtn, 30);
        commonMethods.waitForElement(driver, updateDocumentsBtn);
        $(updateDocumentsBtn).click();
    }

    public boolean validateErrorMessage(String message) {
        By by = By.xpath("//div[contains(text(),'" + message + "')]");
        return $(by).isDisplayed();
    }


    public int noRecords() {
        List<WebElement> elements = driver.findElements(noRecords);
        return elements.size();
    }

    public boolean validateNoChanges() {
        return $(noChanges).isDisplayed();
    }

    public boolean validateDocMsg(String message) {
        By by = By.xpath("//div/span[contains(text(),'" + message + "')]");
        return $(by).isDisplayed();
    }

    public String returnFileName(String documentNo) {
        commonMethods.waitForElementExplicitly(5000);
        By file = By.xpath("//div[text()='" + documentNo + "']");
        commonMethods.waitForElement(driver, file);
        driver.findElement(file).click();
        commonMethods.waitForElementExplicitly(2000);
        return $(fileName).getText();
    }

    public void clickFile() {
        $(file).click();
    }

    public boolean validateAttachFile() {
        return $(attachFileHeader).isDisplayed();
    }

    public void clickCancelBtn() {
        $(cancelBtn).click();
    }

    /**
     * Method to click on view copy to all panel
     */
    public void clickViewCopyToPanel() {
        By xpath = By.xpath("(//button[contains(@title,'Add more')])[" + $$(addMoreBtn).size() + "]");
        $(xpath).click();
    }

    /**
     * Method to click on view copy to all panel
     */
    public void clickHideCopyToPanel() {
        $(hideCopyToPanelBtn).click();
    }


    /**
     * Method to click on copy to all button
     */
    public void clickCopyToAllBtn() {
        commonMethods.waitForElement(driver,copyToAllBtn,30);
        getElementInView(copyToAllBtn);
        $(copyToAllBtn).click();
    }

    /**
     * Method to click on copy to selected documents button
     */
    public void clickCopyToSelectedBtn() {
        $(copyToSelectedBtn).click();
    }


    public void selectFile() {
        $(fileSelect).selectOption(1);
        $(okBtn).click();
    }

    public void clickDocument(String documentId) {
        By oldValueBy = By.xpath("//div[text()='" + documentId + "']");
        commonMethods.waitForElement(driver, oldValueBy, 20);
        $(oldValueBy).click();
    }

    /**
     * Method to return the columns
     *
     * @return
     */
    public boolean validateColumns(List<String> searchList) {
        commonMethods.waitForElementExplicitly(2000);
        for (String text : searchList) {
            if (!$(By.xpath("//div//label[contains(text(),'" + text + "')]")).exists()) {
                return false;
            }
        }
        return true;
    }


    public boolean verifyFieldTypes(Map<String, String> map) {
        commonMethods.waitForElementExplicitly(2000);
        for (String key : map.keySet()) {
            String modifiedKey = key.toLowerCase().replace(" ", "");
            if (map.get(key).equals("text_field")) {
                By by = By.xpath("//input[contains(@name,'" + modifiedKey + "')]");
                commonMethods.waitForElement(driver, by, 10);
                if (!$(by).exists()) {
                    return false;
                }
                break;
            } else if (map.get(key).equals("select_list")) {
                By by = By.xpath("//select[@id='" + modifiedKey + "']");
                commonMethods.waitForElement(driver, by, 10);
                if (!$(by).exists()) {
                    return false;
                }
                break;
            } else if (map.get(key).equals("check_box")) {
                By by = By.xpath("//input[contains(@id,'" + modifiedKey + "') and input[@type='checkbox']");
                commonMethods.waitForElement(driver, by, 10);
                if (!$(by).exists()) {
                    return false;
                }
                break;
            }
        }
        return true;
    }


    public boolean isAlertPresent() {
        return commonMethods.isAlertPresent(driver);
    }

    public void fillUpCopyFields(Map<String, String> map) {
        Set<String> keys = map.keySet();
        for (String key : keys) {
            switch (key) {
                case "Status":
                    setStatus(map.get(key));
                    break;
                case "Discipline":
                    setDiscipline(map.get(key));
                    break;
                case "Type":
                    setType(map.get(key));
                    break;
                case "Revision":
                    setRevision(map.get(key));
                    break;
                case "Revision Date":
                    setRevisionDate(map.get(key));
                case "Title":
                    setTitle(map.get(key));
            }
        }

    }

    public void validateEntries(Map<String, String> map, int index) {
        Set<String> keys = map.keySet();
        List<WebElement> elements = null;
        for (String key : keys) {
            switch (key) {
                case "Status":
                    elements = driver.findElements(status);
                    Assert.assertTrue(elements.get(index).getText().equalsIgnoreCase(map.get(key)));
                case "Discipline":
                    elements = driver.findElements(discipline);
                    Assert.assertTrue(elements.get(index).getText().equalsIgnoreCase(map.get(key)));
                case "Type":
                    elements = driver.findElements(type);
                    Assert.assertTrue(elements.get(index).getText().equalsIgnoreCase(map.get(key)));
                case "Revision":
                    elements = driver.findElements(revision);
                    Assert.assertTrue(elements.get(index).getText().equalsIgnoreCase(map.get(key)));

            }
        }

    }

    /**
     * Method to check if the supersede documents button is displayed
     */
    public boolean isSupersedeBtnDisplayed() {
        return $(updateDocumentsBtn).isDisplayed();
    }


    /**
     * Method to check if the back button is displayed
     */
    public boolean isBackBtnDisplayed() {
        return $(backButton).isDisplayed();
    }


    public Boolean isDateErrorDisplayed() {
        return $(dateErrorMessage).isDisplayed();
    }


    /**
     * Select the checkbox of the first file
     */
    public void setFirstCheckbox() {
        commonMethods.waitForElement(driver, firstCheckBox);
        $(firstCheckBox).setSelected(true);
    }

    /**
     * Remove the first file from the page
     */
    public void remove() {
        commonMethods.waitForElement(driver, firstCheckBox, 60);
        $(firstCheckBox).setSelected(true);
        $(removeBtn).click();
    }


    /**
     * Method to check if the bulk edit button is displayed
     */
    public boolean isBulkEditBtnDisplayed() {
        return $(bulkEditBtn).isDisplayed();
    }


    /**
     * Method to check if the bulk edit button is displayed
     */
    public boolean isRemoveBtnDisplayed() {
        return $(removeBtn).isDisplayed();
    }

    /**
     * Method to click on bulk edit button
     */
    public void clickOnBulkEdit() {
        By xpath = By.xpath("(//button[contains(@title,'Bulk Edit')])[" + $$(bulkEditBtn).size() + "]");
        commonMethods.waitForElement(driver, xpath);
        $(xpath).click();
        commonMethods.waitForElement(driver, lblBulkEdit, 30);
    }

    /**
     * Method to click on Apply button
     */
    public void clickOnApply() {
        commonMethods.waitForElement(driver, btnApply);
        $(btnApply).click();
    }

    /**
     * Method to get update documents button status
     */
    public String verifyUpdateDocuments() {
        return $(updateDocumentsBtn).getAttribute("disabled");
    }

    /**
     * Method to verify Bulk edit fields
     */
    public boolean verifyBulkEditFields(String fieldName, String type) {
        switch (type.toLowerCase()) {
            case "dropdown":
                return $(By.xpath("//acx-bulk-edit-field//acx-single-select-field//select[contains(@title, '" + fieldName + "')]")).isDisplayed();
            case "text":
                return $(By.xpath("//acx-bulk-edit-field//acx-text-field//input[contains(@title, '" + fieldName + "')]")).isDisplayed();
            case "checkbox":
                return $(By.xpath("//acx-bulk-edit-field//acx-checkbox-field//input[contains(@name, '" + fieldName + "')]")).isDisplayed();
            case "date":
                return $(By.xpath("//acx-bulk-edit-field//acx-date-field//input[contains(@title, '" + fieldName + "')]")).isDisplayed();
            case "multi select":
                return $(By.xpath("//acx-bulk-edit-field//acx-multi-select-field//aui-select[contains(@title, '" + fieldName + "')]")).isDisplayed();
            case "ratio":
                return $(By.xpath("//acx-bulk-edit-field//acx-ratio-field//input[contains(@title, '" + fieldName + "')]")).isDisplayed();
            case "text area":
                return $(By.xpath("//acx-bulk-edit-field//acx-text-area-field//textarea[contains(@title, '" + fieldName + "')]")).isDisplayed();
        }
        return false;
    }

    /**
     * Method to return revision field value
     */
    public String getRevision() {
        commonMethods.waitForElement(driver, revision, 30);
        return $(revision).getText();
    }

    /**
     * Method to click on Cancel button in Bulk edit window
     */
    public void clickOnCancel() {
        commonMethods.getElementInViewAndUp(btnBulkEditCancel);
        $(btnBulkEditCancel).click();
    }

    /**
     * Method to verify edit document number pencil icon displayed
     */
    public boolean verifyEditDocNum() {
        return $(editDocNum).isDisplayed();
    }

    /**
     * Method to fill fields in bulk edit window fields
     */
    public void fillUpCopyFields(String fieldName, String value, String type) {
        switch (type.toLowerCase()) {
            case "dropdown":
                commonMethods.enterDropdownValue(By.xpath("//acx-bulk-edit-field//acx-single-select-field//select[contains(@title, '" + fieldName + "')]"), value);
                break;
            case "text":
                commonMethods.enterTextValue(By.xpath("//acx-bulk-edit-field//acx-text-field//input[contains(@title, '" + fieldName + "')]"), value);
                break;
            case "checkbox":
                $(By.xpath("//acx-bulk-edit-field//acx-checkbox-field//input[contains(@name, '" + fieldName + "')]")).setSelected(Boolean.parseBoolean(value));
                break;
            case "date":
                updateDateField(value, By.xpath("//acx-bulk-edit-field//acx-date-field//input[contains(@title, '" + fieldName + "')]"));
                break;
            case "selectlist":
                updateSelectListField("//acx-bulk-edit-field//acx-multi-select-field/aui-select[contains(@title,'" + fieldName + "')]", value);
                break;
            case "pf-selectlist":
                updateSelectListField("//form[@name='form.bulkEditForm']//label[text()='" + fieldName + "']/../following-sibling::div//acx-multi-select-field/aui-select", value);
                break;
            case "pf-button":
                $(By.xpath("//form[@name='form.bulkEditForm']//label[text()='" + fieldName + "']/../following-sibling::div//acx-boolean-radio-field//span[text()='" + value + "']")).click();
                break;
            case "pf-dropdown":
                commonMethods.enterDropdownValue(By.xpath("//form[@name='form.bulkEditForm']//label[text()='" + fieldName + "']/../following-sibling::div//acx-single-select-field//select"), value);
                break;
            case "pf-text":
                commonMethods.enterTextValue(By.xpath("//form[@name='form.bulkEditForm']//label[text()='" + fieldName + "']/../following-sibling::div//div[@class='auiForm-field']/input"), value);
                break;
            case "pf-textarea":
                commonMethods.enterTextValue(By.xpath("//form[@name='form.bulkEditForm']//label[text()='" + fieldName + "']/../following-sibling::div//div[@class='auiForm-field']/textarea"), value);
                break;
            case "pf-date":
                updateDateField(value, By.xpath("//form[@name='form.bulkEditForm']//label[text()='" + fieldName + "']/../following-sibling::div//acx-date-field/input"));
                break;
            case "pf-number":
                commonMethods.enterTextValue(By.xpath("//form[@name='form.bulkEditForm']//label[text()='" + fieldName + "']/../following-sibling::div//acx-number-field/input"), value);
                break;
        }
    }

    /**
     * Method to click on view copy to all panel
     */
   public void copyToPanelSubmit(String fieldName, String value, String type) {
         verifyAndSwitchFrame();
        if(fieldName.equals("Type") && !value.isEmpty()) {
            List<String> docTypeValue = new ArrayList<>();
            docTypeValue.add(value);
            verifyDocTypeOption(docTypeValue);
        }
        fillUpCopyFields(fieldName,value,type);
    }

    /**
     * Method to verify doc type values
     */
    public boolean verifyDocTypeOption(List<String> expectedDocTypes){
        List<String> actualDocumentTypes= returnType();
        return actualDocumentTypes.containsAll(expectedDocTypes);
    }

    /**
     * Method to select first record in table view
     */
    public void selectFirstRecord() {
        By xpath = By.xpath("(" + tblViewFirstCheckBox + ")[" + $$(By.xpath(tblViewFirstCheckBox)).size() +"]" );
        if ($(xpath).getAttribute("class").contains("unchecked"))
            $(xpath).click();
    }

    /**
     * Method to click on remove button
     */
    public void clickRemove() {
        By xpath = By.xpath("(//button[contains(@title,'Remove')])[" + $$(removeBtn).size() + "]");
        $(xpath).click();
    }
    /**
     * Method to select all the document and clcik cop
     */
    public void selectViewCopyPanel(){
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        getElementInView(allFilesSelect);
        commonMethods.waitForElement(driver,allFilesSelect,30);
        $(allFilesSelect).click();
        commonMethods.waitForElement(driver,selectResults,30);
        $(selectResults).click();
        commonMethods.waitForElement(driver,viewCopyToPanelBtn,30);
        $(viewCopyToPanelBtn).click();
    }

    /**
     * Method to update the document number and submit the documents in view copy to panel
     */
    public void updateViewCopyPanelSubmit(String value){
         Faker faker = new Faker();
         int counter=1;
         List<WebElement> elements = new ArrayList<>($$(docMoveToRegisterGrid));
         for(WebElement element:elements){
            commonMethods.waitForElementExplicitly(2000);
             $(By.xpath("//div[@id='MoveToRegisterGrid']//tr["+counter+"]//td[2]")).click();
            commonMethods.waitForElementExplicitly(1000);
            element.clear();
            value = value + faker.number().digits(5);
            commonMethods.waitForElementExplicitly(2000);
            element.sendKeys(value);
            counter++;
        }
    }

    /**
     * Method to click on submit button in view copy to panel
     */
    public void clickSubmitBtnViewCpyPanel() {
        commonMethods.waitForElement(driver,btnSubmit,30);
        $(btnSubmit).click();
    }
}