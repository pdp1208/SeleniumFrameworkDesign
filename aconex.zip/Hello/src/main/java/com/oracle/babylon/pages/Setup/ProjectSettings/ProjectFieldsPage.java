package com.oracle.babylon.pages.Setup.ProjectSettings;

import com.oracle.babylon.Utils.helper.CommonMethods;
import com.oracle.babylon.pages.Setup.ProjectSettingsPage;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import java.util.*;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class ProjectFieldsPage extends ProjectSettingsPage {

    Map<String, Object> mapToReplace = new Hashtable<>();
    Map<String, Map<String, Object>> mapOfMap = new Hashtable<>();

    private By labelField = By.xpath("//th[contains(text(),'Label')]");
    private By inputLabel = By.xpath("//input[@type='text'][@name='label'][@maxlength='40']");
    private By typeField = By.xpath("//th[contains(text(),'Type')]");
    private By fieldName = By.xpath("//th[contains(text(),'Field Name')]");
    private By statusField = By.xpath("//th[contains(text(),'Status')]");
    private By newFieldBtn = By.xpath("//button[contains(text(),'+ New Field')]");
    private By newFieldInfo = By.xpath("//div[contains(text(),'Create a new project field by completing the fields')]");
    private By newFieldType = By.xpath("//label[contains(text(),'Type')]");
    private By newFieldLabel = By.xpath("//label[contains(text(),'Label')]");
    private By newFieldToolTip = By.xpath("//label[contains(text(),'Tool Tip')]");
    private By toolTipTextArea = By.xpath("//textarea[@name='hintText']");
    private By toolTipIcon = By.xpath("//button[@title='More information']");
    private By toolTipInfo = By.xpath("//span[contains(text(),'You can include a tooltip with this field to give users more information about how it should be used.')]");
    private By newFieldFieldName = By.xpath("//label[contains(text(),'Field Name')]");
    private By newFieldCancelBtn = By.xpath("//button[contains(text(),'Cancel')]");
    private By newFieldDisabledSave = By.xpath("//button[contains(text(),'Save') and @disabled='disabled']");
    private By labelErrorMsg = By.xpath("//div[contains(text(),'This label must contain at least one alphanumeric character.')]");
    //private By selectType = By.xpath("//select[@name='type']");
    private By selectType = By.name("type");
    private By saveButton = By.xpath("//button[contains(text(),'Save')]");
    private By message1 = By.xpath("//div[contains(text(),'Changes you make to this Project Field will')]");
    private By message2 = By.xpath("//li[contains(text(),'apply to any Field Issues that use')]");
    private By message3 = By.xpath("//li[contains(text(),'affect the following Mail Types')]");
    private By disableBtn = By.xpath("//button[contains(text(),'Disable')]");
    private By enableBtn = By.xpath("//button[contains(text(),'Enable')]");
    private By projectFields = By.xpath("//div[contains(text(),'Project Fields')]");
    private By minCharacterLimit = By.xpath("//label[contains(text(),'Min Character Limit')]");
    private By maxCharacterLimit = By.xpath("//label[contains(text(),'Max Character Limit')]");
    private By minLimitInput = By.xpath("//input[@name='minLength']");
    private By maxLimitInput = By.xpath("//input[@name='maxLength']");
    private By maxLimitMsg = By.xpath("//div[contains(text(),'The maximum limit cannot be less than the minimum limit.')]");
    private By minLimitMsg = By.xpath("//div[contains(text(),'The minimum limit cannot be more than the maximum limit.')]");
    private By dataTypeLabel = By.xpath("//label[contains(text(),'Data Type')]");
    private By unitLabel = By.xpath("//label[contains(text(),'Unit')]");
    private By dataTypeSelect = By.xpath("//select[@name='unitQuantity']");
    private By unitSelect = By.xpath("//select[@name='unitName']");
    private By selectOptionsLabel = By.xpath("//label[contains(text(),'Select Options')]");
    private By sortByLabel = By.xpath("//button[contains(text(),'Sort By')]");
    private By codesLabel = By.xpath("//label[contains(text(),'Codes')]");
    private By selectionAllowedLabel = By.xpath("//label[contains(text(),'Selections Allowed')]");
    private By selectOptionInfoMsg = By.xpath("//span[contains(text(),'The order of the options represents how they will be displayed in the select list')]");
    private By selectOptionInfoIcon = By.xpath("//textarea[@name='options']//..//..//div//button[@title='More information']");
    private By enableCodeInfoIcon = By.xpath("//input[@name='shortCodesEnabled']//..//..//button[@title='More information']");
    private By enableCodeInfoMsg = By.xpath("//span[contains(text(),'Codes are used for auto numbering')]");
    private By codeCheckbox = By.xpath("//input[@name='shortCodesEnabled']");
    private By addOption = By.xpath("//button[contains(text(),'+ Add Option')]");
    private By optionPlaceHolder = By.xpath("//input[@placeholder='Option']");
    private By codePlaceHolder = By.xpath("//input[@name='optionCode_0']");
    private By deleteIcon = By.xpath("//div[@class='auiIcon trash']");
    private By dots = By.xpath("//div[@class='auiIcon dragAffordance']");
    private By codeErrorMsg = By.xpath("//div[contains(text(),'Codes cannot be disabled after saving')]");
    private By selectOptionInput = By.xpath("//textarea[@name='options']");
    private By projectFieldsHeader = By.xpath("//h1[contains(text(),'Project Fields')]");
    private By txtMultiField = By.xpath("//div[@class='selectValue auiField-input user-options-container ng-isolate-scope']//input");
    private By sltOptions = By.xpath("//div[@class='form-section ng-scope']//select[@name='type']");
    private By chkBoxInlineEdit = By.xpath("//input[@name='inLineEditEnabled']");
    private By lblEditField = By.xpath("//h3[contains(text(),'Edit Field')]");
    private By txtBoxToolTip = By.xpath("//div[@class='form-field']/textarea");
    private By btnUserListRemove = By.xpath("//div[@class='form-field']//span[@class='close ui-select-match-close']");
    private String projectFieldsPath = configFileReader.getProjectFieldsDataPath();

    /**
     * Function to verify project fields header
     *
     * @return
     */
    public boolean verifyProjectFieldsHeader() {
        commonMethods.waitForElement(driver, projectFieldsHeader, 55);
        return $(projectFieldsHeader).isDisplayed();
    }

    /**
     * Function to verify project fields elements present on the page
     */
    public void verifyProjectFieldsElements() {
        Assert.assertTrue($(labelField).isDisplayed());
        Assert.assertTrue($(typeField).isDisplayed());
        Assert.assertTrue($(fieldName).isDisplayed());
        Assert.assertTrue($(statusField).isDisplayed());
        Assert.assertTrue($(newFieldBtn).isDisplayed());
    }

    /**
     * Function to click on New Field
     */
    public void clickNewField() {
        $(newFieldBtn).click();
    }

    /**
     * Function to verify New Field Elements
     */
    public void verifyNewFieldElements() {
        Assert.assertTrue($(newFieldInfo).isDisplayed());
        Assert.assertTrue($(newFieldType).isDisplayed());
        Assert.assertTrue($(newFieldLabel).isDisplayed());
        Assert.assertTrue($(newFieldToolTip).isDisplayed());
        Assert.assertTrue($(newFieldFieldName).isDisplayed());
        Assert.assertTrue($(newFieldDisabledSave).isDisplayed());
        Assert.assertTrue($(newFieldCancelBtn).isDisplayed());

    }

    /**
     * Function to verify Type dropdown
     *
     * @param data
     */
    public void verifyTypeDropdown(List<String> data) {
        for (String option : data) {
            $(By.xpath("//select[@name='type']//option[contains(text(),'" + option + "')]"));
        }
    }

    /**
     * Function to verify Label Field
     *
     * @return
     */
    public boolean verifyLabelField(String data) {
        $(inputLabel).sendKeys(data);
        $(inputLabel).clear();
        return $(labelErrorMsg).isDisplayed();
    }

    /**
     * Function to verify Tooltip
     */
    public void verifyToolTip() {
        Assert.assertTrue($(toolTipTextArea).isDisplayed());
        $(toolTipIcon).click();
        Assert.assertTrue($(toolTipInfo).isDisplayed());
    }

    /**
     * Function to select type
     *
     * @param value
     */
    public void selectType(String value) {
        commonMethods.waitForElement(driver, selectType);
        $(selectType).click();
        $(selectType).selectOptionContainingText(value);
    }

    /**
     * Function to validate label
     *
     * @param value1
     * @return
     */
    public boolean validateLabel(String value1) {
        $(inputLabel).sendKeys(value1);
        $(inputLabel).clear();
        return $(labelErrorMsg).isDisplayed();
    }

    /**
     * Function to create label
     *
     * @param value1
     */
    public void createLabel(String value1) {
        String label = faker.name().firstName() + faker.number().digits(2);
        $(inputLabel).sendKeys(label);
        commonMethods.writeToJson("field_name", value1, label, projectFieldsPath);
    }

    /**
     * Function to enter text in tool tip
     *
     * @param text
     */
    public void enterTextToolTip(String text) {
        $(toolTipTextArea).sendKeys(text);
        $(saveButton).click();
    }

    /**
     * Function to edit Label present in project fields
     *
     * @param label1
     * @param label3
     */
    public void editLabel(String label1, String label3) {
        String label = commonMethods.returnFromJson(label1, "field_name", projectFieldsPath);
        $(By.xpath("//span[contains(text(),'" + label + "')]")).click();
        $(inputLabel).clear();
        String newLabel = faker.name().firstName() + faker.number().digits(2);
        $(inputLabel).sendKeys(newLabel);
        commonMethods.writeToJson("field_name", label3, newLabel, projectFieldsPath);
    }

    /**
     * Function to click Label present in project fields
     *
     * @param labelName
     */
    public void clickLabel(String labelName) {
        String label = commonMethods.returnFromJson(labelName, "field_name", projectFieldsPath);
        By element = By.xpath("//span[contains(text(),'" + label + "')]");
        commonMethods.waitForElement(driver, element, 45);
        $(element).click();
    }

    /**
     * Function to click Label present in project fields
     *
     * @param labelName
     */
    public void clickOnLabel(String labelName) {
        By element = By.xpath("//span[contains(text(),'" + labelName + "')]");
        commonMethods.waitForElement(driver, element, 45);
        commonMethods.getElementInViewAndUp(element);
        $(element).click();
    }

    /**
     * Function to verify the Label info present
     */
    public void verifyLabelInfo() {
        commonMethods.waitForElement(driver, message1, 45);
        Assert.assertTrue($(message1).isDisplayed());
        Assert.assertTrue($(message2).isDisplayed());
    }

    /**
     * Function to click on save button
     */
    public void clickSave() {
        $(saveButton).click();
    }

    /**
     * Function to verify disable Button
     *
     * @return
     */
    public boolean verifyDisableButton() {
        return $(disableBtn).isEnabled();
    }

    /**
     * Function to click on Disable button
     */
    public void clickDisableBtn() {
        commonMethods.getElementInViewAndUp(disableBtn);
        $(disableBtn).click();
    }

    /**
     * Function to verify enable button is Enabled
     *
     * @return
     */
    public boolean verifyEnableButton() {
        return $(enableBtn).isEnabled();
    }

    /**
     * Function to click on Enable Button
     */
    public void clickEnableBtn() {
        commonMethods.getElementInViewAndUp(enableBtn);
        $(enableBtn).click();
    }

    /**
     * Function to verify Project Fields
     *
     * @return
     */
    public boolean verifyProjectFields() {
        return $(projectFields).isDisplayed();
    }

    /**
     * Function to verify Minimum and Maximum fields present
     */
    public void verifyMinMaxFields() {
        commonMethods.waitForElement(driver, minCharacterLimit, 45);
        Assert.assertTrue($(minCharacterLimit).isDisplayed());
        Assert.assertTrue($(maxCharacterLimit).isDisplayed());
    }

    /**
     * Function to enter Minimum and Maximum value
     *
     * @param num1
     * @param num2
     */
    public void enterMinMaxValue(String num1, String num2) {
        $(minLimitInput).sendKeys(num1);
        $(maxLimitInput).sendKeys(num2);
    }

    /**
     * Function to validate Minimum Maximum message
     */
    public void validateMinMaxMsg() {
        Assert.assertTrue($(minLimitMsg).isDisplayed());
        Assert.assertTrue($(maxLimitMsg).isDisplayed());
    }

    /**
     * Function to verify Data Type field
     *
     * @param options
     */
    public void verifyDataType(List<String> options) {
        for (String data : options) {
            By element = By.xpath("//select[@name='unitQuantity']//option[contains(text(),'" + data + "')]");
            commonMethods.waitForElement(driver, element, 45);
            Assert.assertTrue($(element).isDisplayed());
        }
    }

    /**
     * Function to select Data Type
     *
     * @param option
     */
    public void selectDataType(String option) {
        $(dataTypeSelect).selectOptionContainingText(option);
    }

    /**
     * Function to verify unit Type Field
     *
     * @param data
     */
    public void verifyUnitField(List<String> data) {
        for (String option : data) {
            Assert.assertTrue($(By.xpath("//select[@name='unitName']//option[contains(text(),'" + option + "')]")).isDisplayed());
        }
    }

    /**
     * Function to select unit type Field
     *
     * @param data
     */
    public void selectUnitField(String data) {
        $(unitSelect).selectOptionContainingText(data);
    }

    /**
     * Function to verify single List field
     */
    public void verifySingleList() {
        Assert.assertTrue($(selectOptionsLabel).isDisplayed());
        Assert.assertTrue($(sortByLabel).isDisplayed());
        Assert.assertTrue($(codesLabel).isDisplayed());
        Assert.assertTrue($(selectionAllowedLabel).isDisplayed());
        Assert.assertTrue($(selectOptionInfoIcon).isDisplayed());
        $(selectOptionInfoIcon).click();
        Assert.assertTrue($(selectOptionInfoMsg).isDisplayed());
        Assert.assertTrue($(enableCodeInfoIcon).isDisplayed());
        $(enableCodeInfoIcon).click();
        Assert.assertTrue($(enableCodeInfoMsg).isDisplayed());
    }

    /**
     * Function to verify Sort By option
     *
     * @param data
     */
    public void verifySortByOption(List<String> data) {
        for (String option : data) {
            Assert.assertTrue($(By.xpath("//li[contains(text(),'" + option + "')]")).isDisplayed());
        }
    }

    /**
     * Function to verify code checkbox field
     */
    public void verifyCodeCheckbox() {
        $(codeCheckbox).click();
        Assert.assertTrue($(addOption).isDisplayed());
        Assert.assertTrue($(optionPlaceHolder).isDisplayed());
        Assert.assertTrue($(codePlaceHolder).isDisplayed());
        Assert.assertTrue($(deleteIcon).isDisplayed());
        Assert.assertTrue($(dots).isDisplayed());
        Assert.assertTrue($(codeErrorMsg).isDisplayed());
        $(codeCheckbox).click();
    }

    /**
     * Function to click Sort By label
     */
    public void clickSortBy() {
        $(sortByLabel).click();
    }

    /**
     * Function to send select options data while creating New Field
     *
     * @param data
     */
    public void sendSelectOptions(List<String> data) {
        for (String option : data) {
            $(selectOptionInput).sendKeys(option);
            $(selectOptionInput).sendKeys(Keys.ENTER);
        }
    }

    /**
     * Function to verify sort by option while creating New Field
     *
     * @param option
     * @param data
     * @return
     */
    public boolean verifySortByOptions(String option, List<String> data) {
        $(By.xpath("//li[contains(text(),'" + option + "')]")).click();
        String[] actualValues = Arrays.copyOf(data.toArray(), data.size(), String[].class);
        String result = $(selectOptionInput).getValue();
        String[] finalResult = result.split("\n");
        String[] sortResult = commonMethods.sortAscending(actualValues);
        return Arrays.equals(sortResult, finalResult);
    }

    /**
     * Method to Add project fields
     */
    public void addProjectField(String type, String name, String selectOptions, String sort, String options, String label, String codes) {
        switchProjectSettingsFrame();
        clickNewField();
        selectType(type);
        $(inputLabel).sendKeys(name);
        if (type.equalsIgnoreCase("select list (single)")) enterSingleSelectField(selectOptions, codes);
        if (type.equalsIgnoreCase("select list (multiple)")) enterMultiSelectField(options, selectOptions);
        if (type.equalsIgnoreCase("number")) {
            selectDataType(selectOptions.split(",")[0].trim());
            selectUnitField(selectOptions.split(",")[1].trim());
            mapToReplace.put("unit_value", selectOptions.split(",")[1].trim().toLowerCase());
        }
        if (!sort.isEmpty()) {
            clickSortBy();
            commonMethods.waitForElementExplicitly(1000);
            $(By.xpath("//li[contains(text(),'" + sort + "')]")).click();
        }
        $(toolTipTextArea).sendKeys("This is a " + name + " " +  type + " field");
        $(saveButton).click();
        switchProjectSettingsFrame();
        commonMethods.waitForElementExplicitly(5000);
        mapToReplace.put("field_name", name);
        mapToReplace.put("field_type", type);
        mapOfMap.put(label, mapToReplace);
        dataSetup.fileWrite(label, mapOfMap, projectFieldsPath);
        mapToReplace.remove("unit_value");
    }

    /**
     * Method to update project field
     */
    public void updateProjectField(String type, String values, String sort, String option, String label, String inlineEdit, String codes) {
        mapOfMap = dataSetup.loadJsonDataToMap(projectFieldsPath);
        Map<String, Object> map = mapOfMap.get(label);
        switchProjectSettingsFrame();
        commonMethods.waitForElement(driver, newFieldBtn, 10);
        clickOnLabel(map.get("field_name").toString());
        commonMethods.waitForElement(driver, inputLabel, 30);
        if (type.equalsIgnoreCase("select list (single)")) enterSingleSelectField(values, codes);
        if (type.equalsIgnoreCase("select list (multiple)")) enterMultiSelectField(option, values);
        if (type.equalsIgnoreCase("text")) enterMinMaxValue(values.split(",")[0].trim(), values.split(",")[1].trim());
        if (!sort.isEmpty()) {
            clickSortBy();
            $(By.xpath("//li[contains(text(),'" + sort + "')]")).click();
        }
        if (!inlineEdit.isEmpty()) {
            $(chkBoxInlineEdit).setSelected(Boolean.parseBoolean(inlineEdit));
        }
        $(saveButton).click();
        switchProjectSettingsFrame();
        commonMethods.waitForElement(driver, By.xpath("//table[@class='auiTable']//tr/td/span[contains(text(),'" + map.get("field_name").toString() + "')]"), 10);
    }

    /**
     * Method to return whether project field is already exist or not
     */
    public boolean verifyProjectFields(String name) {
        commonMethods.waitForElementExplicitly(3000);
        return $(By.xpath("//table[@class='auiTable']//tr/td/span[contains(text(),'" + name + "')]")).isDisplayed();
    }

    /**
     * Method to add/update multi select field values
     */
    public void enterMultiSelectField(String option, String values) {
        if ($(sltOptions).isDisplayed()) $(sltOptions).selectOption(option);
        String[] value = values.split(",");
        for (String s : value) {
            if (option.equalsIgnoreCase("users")) {
                String userName = commonMethods.getUserData(s, "name");
                $(txtMultiField).click();
                if (!$(By.xpath("//div[@class='selectValue auiField-input user-options-container ng-isolate-scope']//span[contains(text(),\"" + userName + "\")]")).isDisplayed()) {
                    $(txtMultiField).sendKeys(userName);
                    commonMethods.waitForElementExplicitly(3000);
                    $(txtMultiField).sendKeys(Keys.ENTER);
                }
            } else {
                if (!$(selectOptionInput).getAttribute("value").contains(s))
                    $(selectOptionInput).sendKeys(s + Keys.ENTER);
            }
        }
    }

    /**
     * Method to add/update Single select field values
     */
    public void enterSingleSelectField(String values, String codes) {
        String[] value = values.split(",");
        if (codes.equalsIgnoreCase("no")) {
            for (String s : value) {
                if (!$(selectOptionInput).getAttribute("value").contains(s))
                    $(selectOptionInput).sendKeys(s + Keys.ENTER);
            }
        } else fillSingleSelectField(values);
    }

    /**
     * Method to add/update Single select field values
     */
    public void enterSingleSelectField(List<String> values) {
        for (String s : values) {
            if (!$(selectOptionInput).getAttribute("value").contains(s))
                $(selectOptionInput).sendKeys(s + Keys.ENTER);
        }
    }

    /**
     * Method to remove inline edit for project fields
     */
    public void removeInlineEdit(String field) {
        clickOnLabel(field);
        commonMethods.waitForElement(driver, inputLabel, 30);
        if ($(chkBoxInlineEdit).isSelected()) {
            $(chkBoxInlineEdit).setSelected(false);
            $(saveButton).click();
        } else
            $(btnCancel).click();
    }

    /**
     * Method to clear values for Single select field
     */
    public void clearSingleSelectField() {
        commonMethods.waitForElement(driver, selectOptionInput);
        $(selectOptionInput).setValue("");
    }

    /**
     * Method to fill single select field values when codes are enabled
     */
    public void fillSingleSelectField(String values) {
        List<String> fieldValues = Arrays.asList(values.split(","));
        $(codeCheckbox).setSelected(true);
        for (int i = 0; i < fieldValues.size(); i++) {
            $(By.xpath("(//div[@class='flex editcodefield expand w-embed'])[" + (i + 1) + "]/input[1]")).sendKeys(fieldValues.get(i));
            $(By.xpath("(//div[@class='flex editcodefield expand w-embed'])[" + (i + 1) + "]/input[2]")).sendKeys(fieldValues.get(i).substring(0, 2));
            if (i < fieldValues.size() - 1) $(addOption).click();
        }
    }

    /**
     * method to verify edit field options
     */
    public void verifyEditFields(String option) {
        commonMethods.waitForElement(driver, lblEditField);
        Assert.assertTrue($(lblEditField).isDisplayed());
        Assert.assertFalse($(selectType).isDisplayed());
        Assert.assertTrue($(inputLabel).isDisplayed());
        Assert.assertTrue($(txtBoxToolTip).isDisplayed());
        if(option.equalsIgnoreCase("disabled")) Assert.assertEquals("true", $(disableBtn).getAttribute("disabled"));
        else Assert.assertNull($(disableBtn).getAttribute("disabled"));
    }

    /**
     * Method to clear multiselect user list
     */
    public void clearMultiSelectUserField() {
        commonMethods.waitForElement(driver, txtMultiField);
        List<WebElement> elements = new ArrayList<>($$(btnUserListRemove));
        for (int i = elements.size(); i > 0; i--)
            $(By.xpath("(//div[@class='form-field']//span[@class='close ui-select-match-close'])[" + i + "]")).click();
    }

    /**
     * Function to verify disable Button
     *
     * @return
     */
    public boolean verifyDisableBtn() {
        return $(disableBtn).isDisplayed();
    }

    /**
     * Function to verify enable button is Enabled
     *
     * @return
     */
    public boolean verifyEnableBtn() {
        return $(enableBtn).isDisplayed();
    }

    /**
     * Function to cancel the edit field window
     *
     * @return
     */
    public void clickCancel() {
        $(newFieldCancelBtn).click();
    }


    /**
     *  Method to get a docType Value from the response
     * @param response
     *
     */
    public ArrayList<String> getListProjectFieldQualifiedName(StringBuffer response)
    {
        ArrayList<String> qualifiedFields=new ArrayList<>();
        JSONObject json=new JSONObject(response.toString());
        JSONArray jsonArray=json.getJSONArray("fields");
        for(int iterator=0;iterator<jsonArray.length();iterator++)
        {
            json=jsonArray.getJSONObject(iterator);
            String[] name=json.get("fullyQualifiedName").toString().split("_");
            qualifiedFields.add(name[1]);
        }
        return qualifiedFields;
    }

    /**
     * Method to verify the status of the Project Field
     */
    public boolean verifyStatusColumn(String labelname, String expectedStatus){
        By element = By.xpath("//*[text()='" + commonMethods.returnFromJson(labelname, "field_name", projectFieldsPath) + "']/following::td[3]/p[text()='" + expectedStatus +"']");
        commonMethods.waitForElement(driver, element, 30);
        return $(element).isDisplayed();
    }

    /**
     * Method to return the status of the project field
     */
    public String returnStatus(String labelName) {
        return $(By.xpath("//span[text()='"+ labelName +"']//..//..//td[4]//p")).getText();
    }

    /**
     * Function to verify info message is not displayed on project field dialog
     */
    public void verifyInfoMessageNotDisplayed() {
        commonMethods.waitForElementExplicitly(3000);
        Assert.assertFalse($(message1).isDisplayed());
        Assert.assertFalse($(message2).isDisplayed());
    }

    /**
     * Function to verify info message on Project Field Edit Dialog pop-up
     */
    public void verifyInfoMsgOnEditField(String infoMsg){
        By infoMsgElement = By.xpath("//*[contains(text(),'" + infoMsg + "')]");
        if(!infoMsg.toLowerCase().contains("access control")){
            commonMethods.waitForElement(driver, message1, 10);
            Assert.assertTrue($(message1).isDisplayed());
            Assert.assertTrue($(infoMsgElement).isDisplayed());
        }else {
            commonMethods.waitForElement(driver, infoMsgElement, 10);
            Assert.assertTrue($(infoMsgElement).isDisplayed());
        }
    }
}