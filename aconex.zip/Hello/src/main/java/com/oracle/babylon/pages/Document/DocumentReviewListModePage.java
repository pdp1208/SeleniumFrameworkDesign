package com.oracle.babylon.pages.Document;

import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

/**
 * Class to handle the actions in Document Review (List) mode
 * Required to handling viewer test cases for workflows
 * created by susgopal
 */
public class DocumentReviewListModePage extends Navigator {

    private By pageTitle = By.xpath("//h1[contains(text(),' Document Review')]");
    private By openViewerIcon = By.xpath("//*[@title='View and markup this document']");
    private By attachFileIcon = By.xpath("//img[contains(@id,'fileAttachIcon')]");
    private By temporaryFiles = By.xpath("//button[@title='Attach a file from your document register']");
    private By attachBtn = By.xpath("//button[@id='btnattachFileChoice_attachDocs_panel_ok']");
    private By firstDocChkBox = By.xpath("//input[@id='selectedQueueIds']");
    private By startSubWorkflowBtn = By.xpath("//button[@id='btnStartSubworkflow']");
    private By selectOutcome = By.xpath("//select[contains(@id,'reviewOutcome')]");
    private By comment = By.xpath("//div[contains(@id,'divDisplay_comments')]");
    private By textAreaComment = By.xpath("//div[contains(@id,'divDisplay_comments')]/..//textarea[@class='commentsTextArea']");
    private By submitSelectedDocumentsBtn = By.xpath("//button[@id='btnSubmitSelected']//div[@class='uiButton-label'][contains(text(),'Submit Selected Documents')]");
    private By summaryPanel = By.xpath("//*[@id='summaryPanel']");
    private By summaryPanelOKBtn = By.xpath("//button[@id='btnsummaryPanel_ok']//*[@class='uiButton-content']//*[contains(text(),'OK')]");
    private By submitDoc = By.xpath("//button[@id='btnsummaryPanel_ok']");
    private By successMsgOnReview = By.xpath("//*[@class='message success']//div[contains(text(),'Reviewed documents have been submitted to the next step in the workflow')]");
    private By viewDetails = By.xpath("//span[contains(text(),'(View Details)')]");
    private By delegateWindow = By.xpath("//div[@id='delegate_dialogPanel']");
    private By cancelBtn = By.xpath("//button[@id='btndelegate_dialogPanel_cancel']");
    private By openFileIcon = By.xpath("//div[@class='imgAlign']//img[@title='Open File']");
    private By docVersionWindow = By.xpath("//div[@id='subWorkflowFileVersionPanel']");
    private By currentVersion = By.xpath("//a[@id='currentFileVersionIcon']");
    private By originalVersion = By.xpath("//a[@id='originalFileVersionIcon']");
    private By closeBtn = By.xpath("//button[@id='btnsubWorkflowFileVersionPanel_cancel']");
    private By subWorkflowFileIcon = By.xpath("//div[@class='imgAlign']//img[@src='/html/Images/icons/ic_doc_insubworkflow.gif']");
    private By docOptions = By.xpath("//img[@src='/html/Images/tricolon.svg']");
    private By linkDocProperties = By.xpath("//a[text()='View document properties']");
    private By docPropWindow = By.xpath("//div[@id='docPropertiesPanel']");
    private By docPropCloseBtn = By.xpath("//button[@id='btndocPropertiesPanel_ok']");
    private By attachFileLocal = By.xpath("//button[@title='Attach a File from Local Computer/Network']");
    private By chooseFile = By.xpath("//input[@id='FILE_PATH_NAME']");
    private By okBtn = By.xpath("//button[@id='btnattachFileChoice_localFileAttachPanel_ok']");
    private By docReviewTab = By.xpath("//li[@id='DOC_REVIEW_TABList']");
    private By hdrTitle = By.xpath("//form[@id='form1']//div[@id='header']//h1");
    private By tabDocForReviews = By.xpath("//li[@id='DOC_REVIEW_TABList']");
    private By tabSupplimentaryFiles = By.xpath("//li[@id='SUPP_FILES_TABList']");
    private By btnBulkReview = By.xpath("//div[contains(text(),'Bulk Review')]");
    private By btnStartSubWorkflow = By.xpath("//div[contains(text(),'Start Subworkflow')]");
    private By btnDelegate = By.xpath("//div[text()='Delegate']");
    private By btnZipDownload = By.xpath("//div[contains(text(),'Zip Download')]");
    private By btnMoreOptions = By.xpath("//div[contains(text(),'More Options')]");
    private By btnPrintRequest = By.xpath("//div[contains(text(),'Print Request')]");
    private By btnUploadReplacements = By.xpath("//div[contains(text(),'Upload Replacements')]");
    private By lblInformation = By.xpath("//div[contains(text(),'Information')]");
    private By lblWorkflowNote = By.xpath("//b[contains(text(),'Workflow Note')]");
    private By tblHeaders = By.xpath("//table[@class='dataTable']//th");
    private String tblDocRows = "//table[@class='dataTable']//tbody/tr";
    private By lblBulkReviewOptions = By.xpath("//span[text()='Bulk Review Options']");
    private By sltReviewOutcome = By.xpath("//select[@id='bulkReviewReviewOutcome']");
    private By txtBoxComments = By.xpath("//textarea[@id='bulkReviewComment']");
    private By radioBtnSelectedDocs = By.xpath("//input[@id='toSelected']");
    private By radioBtnBlankDocs = By.xpath("//input[@id='toBlank']");
    private By radioBtnAllDocs = By.xpath("//input[@id='toAll']");
    private By btnOk = By.xpath("//div[@id='bulkReviewPanel']//div[contains(text(),'OK')]");
    private By btnCancel = By.xpath("//div[@id='bulkReviewPanel']//div[contains(text(),'Cancel')]");
    private By btnAttachFile = By.xpath("//button//div[contains(text(),'Attach File')]");
    private By lblAttachAFile = By.xpath("//div[@id='attachFileChoice_fileChoicePanel']//span[text()='Attach a file']");
    private By lblFrom = By.xpath("//div[contains(text(),'From')]");
    private By btnLocalComputer = By.xpath("//button//div[contains(text(),'Local Computer/Network')]");
    private By btnAttachFromDocs = By.xpath("//button[@id='attachFileChoice_fileChoicePanel_btnAttachFromControlledDocs_page']");
    private By btnDocumentRegister = By.xpath("//button//div[contains(text(),'Document Register')]");
    private By btnAttachFileOK = By.xpath("//button[@id='btnattachFileChoice_fileChoicePanel_ok']//div[contains(text(),'OK')]");
    private By btnAttachFileCancel = By.xpath("//button[@id='btnattachFileChoice_fileChoicePanel_cancel']//div[contains(text(),'Cancel')]");
    private By lblLocalAttachFile = By.xpath("//div[@id='localAttachPanel']//span[text()='Attach a file']");
    private By btnLocalAttach = By.xpath("//div[@id='uploaderHelperMsg']//input[@name='qqfile']");
    private By btnAttach = By.xpath("//button[@id='btnAttachLocalFile']//div[text()='Attach']");
    private By btnClose = By.xpath("//button[@id='btnCloseAttachments']//div[text()='Close']");
    private By btnAddFiles = By.xpath("//div[text()='Add Files']");
    private By btnClearAll = By.xpath("//div[contains(text(),'Clear All')]");
    private By lblUploaded = By.xpath("//div[@type='success']//span[contains(text(),'uploaded')]");
    private By txtBoxAttachComments = By.xpath("//form[@id='attachFileChoiceListForm']//table[@class='dataTable']//td[4]");
    private String txtAreaAttachComments = "//form[@id='attachFileChoiceListForm']//table[@class='dataTable']//td[4]//textarea";
    private By tblSFHeaders = By.xpath("//table[@id='supplementaryFilesResultsTable']//th");
    private By lblSFDocRegister = By.xpath("//span[contains(text(),'Select supplementary files from your document register')]");
    private By tabDocRegister = By.xpath("//li[@id='CDRegisteredList_list']");
    private By chkboxSelectAll = By.xpath("//div[@id='docsForReviewSearchResultsWrapper']//div[@class='selectAllMenu']");
    private By lnkSelectAllResults = By.xpath("//a[contains(text(),'Select All Results')]");
    private By btnDocRegAttach = By.xpath("//button[@id='btnattachFileChoice_attachDocs_panel_ok']//div[text()='Attach']");
    private By btnTemporaryFiles = By.xpath("//button//div[contains(text(),'Temporary Files')]");
    private By lblReplacementFile = By.xpath("//span[contains(text(),'Select a replacement from your temporary files')]");
    private By btnLocalAttachCancel = By.xpath("//button[@id='btnattachFileChoice_localFileAttachPanel_cancel']//div[contains(text(),'Cancel')]");
    private By lblErrorMessage = By.xpath("//div[@id='summaryValid']//span[contains(text(),'Click Cancel to go back and complete them')]");
    private By lblReplacementNotFound = By.xpath("//div[@id='summaryValid']//span[contains(text(),'Replacement Not Found')]");
    private By lblMissingOutcome = By.xpath("//div[@id='summaryValid']//span[contains(text(),'Your review outcome is missing')]");
    private By btnReviewSubmitDocsCancel = By.xpath("//button[@id='btnsummaryPanel_cancel']");
    public By hdrDelegateTask = By.xpath("//span[contains(text(),'Delegate Selected Tasks')]");
    public By lblDelegateTask = By.xpath("//div[contains(text(),'Delegate selected tasks')]");
    private By txtBoxWith = By.xpath("//div/input[@id='delegate_lookup_query']");
    private String tblSelectedTask = "//form[@name='summaryConfirmationSubmitForm']//table//tr";
    private By btnDelegateOk = By.xpath("//button[@id='btndelegate_dialogPanel_ok']");
    private By btnDelegateClose = By.xpath("//div[@id='btndelegate_dialogPanel_closeBox']");
    private By btnTrash = By.xpath("//div[@class='auiIcon trash']");
    private By lblSuccessTask = By.xpath("//div[contains(text(),'Tasks successfully delegated')]");
    private By lblDelegateSummary = By.xpath("//div[@class='summaryMessage']");
    private By btnDelegateSuccessClose = By.xpath("//button[@id='btndelegate_dialogPanel_close']");
    private String tblUnregisteredMessage = "//tr[@class='notregistered']/td[5]";
    /**
     * Print Request Page locators
     **/
    private By hdrPrintRequest = By.xpath("//h1[contains(text(),'Print Request')]");
    private By btnContinue = By.xpath("//div[contains(text(),'Continue')]");
    private By txtBoxUserReference = By.xpath("//input[@name='DOCCONTROL_USER_REFERENCE']");
    private By sltPrintShop = By.xpath("//select[@name='DOCCONTROL_PRINT_COMPANY']");
    private By sltDeliverBy = By.xpath("//select[@name='PRINT_DELIVERY_CATEGORY_METHOD']");
    private String lnkEdit = "//a[contains(text(),'Edit')]";
    private By chkBoxApplyChanges = By.xpath("//input[@name='APPLY_TO_ALL']");
    private By btnSave = By.xpath("//div[contains(text(),'Save')]");
    private By lblPrintOptionsSuccess = By.xpath("//div[contains(text(),'Document Print Options have been saved successfull')]");
    private By btnSendRequest = By.xpath("//div[contains(text(),'Send Request')]");
    private By lblConfirmation = By.xpath("//h1[contains(text(),'Confirmation')]");
    private By lblPrintSuccess = By.xpath("//div[@id='main']");
    private By hdrEditPrintOptions = By.xpath("//h1[contains(text(),'Edit Document Print Options')]");
    private By spanUpdatedMarkup = By.xpath("//span[text()='Viewer markups updated']");
    private By fileReplacedMsg = By.xpath("//div[text()='File replaced']");
    private By autoSaveMsg = By.xpath("//span[text()='Saved']");
    private By missingReviewOutcomeMsg = By.xpath("//span[contains(text(),'Your review outcome is missing')]");
    private By otherReviewerError = By.xpath("//span[text()='Other reviewers have unpublished markups']");
    private String attachFileFrame = "attachFiles-frame";
    private By unpublishedMsg = By.xpath("//span[contains(text(),'You have unpublished markups')]");

    DocumentPage documentPage = new DocumentPage();
    Actions actions = new Actions(driver);

    /**
     * Method to verify the title of the Document Review List mode page
     * @return
     */
    public boolean verifyTitle() {
        commonMethods.waitForElement(driver, pageTitle, 60);
        return $(pageTitle).isDisplayed();
    }

    /**
     * Method to click on the viewer icon
     */
    public void clickViewerIcon() {
        commonMethods.waitForElement(driver, openViewerIcon, 30);
        $(openViewerIcon).click();
        commonMethods.waitForElementExplicitly(15000);

    }

    /**
     * Method to click on the attach file icon
     */
    public void clickAttachFileIcon() {
        commonMethods.waitForElement(driver, attachFileIcon);
        $(attachFileIcon).click();
    }

    /**
     * Method to attach a temporary file to the workflow
     */
    public void attachTempFile() {
        clickAttachFileIcon();
        commonMethods.waitForElement(driver, temporaryFiles);
        $(temporaryFiles).click();

    }

    /**
     * Method to attach file from local
     */
    public void attachLocalFile() {
        clickAttachFileIcon();
        $(attachFileLocal).click();
    }

    /**
     * Method to click on the attach button after the document is selected
     */
    public void clickAttachBtn() {
        driver.switchTo().defaultContent();
        verifyAndSwitchFrame();
        $(attachBtn).click();
    }

    /**
     * Method to validate if the attach icon properly shows the replaced file name
     * @param replaceFileId
     * @return
     */
    public boolean validateFileReplaced(String replaceFileId) {
        verifyAndSwitchFrame();
        By by = By.xpath("//img[contains(@id,'fileAttachIcon')]");
        commonMethods.waitForElement(driver, by);
        return $(by).isDisplayed();
    }

    /**
     * Function to start sub workflow
     */
    public void startSubWorkflow(){
        commonMethods.waitForElement(driver,startSubWorkflowBtn,40);
        $(firstDocChkBox).click();
        $(startSubWorkflowBtn).click();
    }
    /**
     * Function to start sub workflow
     */
    public void startSubWorkflow(int num) {
        commonMethods.waitForElement(driver, startSubWorkflowBtn, 40);
        selectDocsChkBox(num);
        $(startSubWorkflowBtn).click();
    }

    /**
     * Function to select multiple docs for subworkflow
     *
     * @param num
     */
    public void selectDocsChkBox(int num) {
        commonMethods.waitForElementExplicitly(1000);
        List<WebElement> docs = driver.findElements((firstDocChkBox));
        for (int i = 0; i <= num - 1; i++) {
            docs.get(i).click();
        }
    }

    /**
     * Verify sub workflow button
     *
     * @return
     */
    public boolean verifySubWorkflowBtn() {
        return $(startSubWorkflowBtn).isDisplayed();
    }

    /**
     * Function to select review outcome
     *
     * @param value
     */
    public void reviewDocument(String value) {
        commonMethods.waitForElement(driver,firstDocChkBox);
        $(firstDocChkBox).click();
        $(selectOutcome).selectOption(value);
        submitDocuments();
    }

    /**
     * Function to verify review success msg
     *
     * @return
     */
    public boolean verifyReviewSuccessMsg() {
        commonMethods.waitForElement(driver, successMsgOnReview, 40);
        getElementInView(successMsgOnReview);
        return $(successMsgOnReview).isDisplayed();
    }

    /**
     * Function to add review outcome
     *
     * @param value
     */
    public void addReviewOutcome(String value) {
        commonMethods.waitForElementExplicitly(4000);
        commonMethods.waitForElement(driver, selectOutcome, 40);
        $(selectOutcome).selectOption(value);
        commonMethods.waitForElementExplicitly(4000);
    }

    /**
     * Function to verify sub WF outcome
     *
     * @param outcome
     * @return
     */
    public boolean verifySubWorkflowOutcome(String outcome) {
        commonMethods.waitForElementExplicitly(2000);
        return $(By.xpath("//td//span[contains(text(),'" + outcome + "')]")).isDisplayed();
    }

    /**
     * Click on Delegate Btn
     */
    public void clickDelegate() {
        commonMethods.waitForElement(driver, delegateBtn, 40);
        actions.moveToElement($(delegateBtn)).click().build().perform();
//        $(delegateBtn).click();
    }

    /**
     * Click view deatails
     */
    public void clickViewDetails() {
        commonMethods.waitForElement(driver, viewDetails, 40);
        $(viewDetails).click();
    }

    /**
     * Function to verify delegate window
     */
    public boolean verifyDelegateWindow() {
        commonMethods.waitForElement(driver, delegateWindow, 40);
        return $(delegateWindow).isDisplayed();
    }

    /**
     * Function to click on delegate cancel btn
     */
    public void clickDelegateCancel() {
        commonMethods.waitForElement(driver, cancelBtn, 40);
        $(cancelBtn).click();
    }

    /**
     * Function to verify file icon window
     */
    public void verifyFileIcon(String value) {
        if (value.equalsIgnoreCase("present")) {
            commonMethods.waitForElementExplicitly(1000);
            Assert.assertTrue($(subWorkflowFileIcon).isDisplayed());
        }
        commonMethods.waitForElement(driver, openFileIcon, 40);
        $(openFileIcon).click();
        commonMethods.waitForElementExplicitly(1000);
        commonMethods.waitForElement(driver, docVersionWindow, 40);
        Assert.assertTrue($(docVersionWindow).isDisplayed());
        Assert.assertTrue($(currentVersion).isDisplayed());
        Assert.assertTrue($(originalVersion).isDisplayed());
    }

    /**
     * Function to click on version panel close btn
     */
    public void closeVersionPanel() {
        commonMethods.waitForElement(driver, closeBtn, 40);
        $(closeBtn).click();
    }

    /**
     * Function to verify replaced file name
     *
     * @param fileName
     * @return
     */
    public boolean verifyFileName(String fileName) {
        $(firstDocChkBox).click();
        getElementInView(docOptions);
        $(docOptions).click();
        commonMethods.waitForElement(driver, linkDocProperties, 40);
        $(linkDocProperties).click();
        commonMethods.waitForElementExplicitly(1000);
        commonMethods.waitForElement(driver, docPropWindow, 40);
        return $(By.xpath("//td//div//a//img[contains(@alt,'Open File - " + fileName + "')]")).isDisplayed();
    }

    /**
     * Close doc properties window
     */
    public void clickCloseBtn() {
        commonMethods.waitForElement(driver, docPropCloseBtn, 40);
        $(docPropCloseBtn).click();
    }

    /**
     * REPLACE file from local for WF
     *
     * @param directoryPath
     * @param fileName
     */
    public void replaceLocalFile(String directoryPath, String fileName) {
        verifyAndSwitchFrame();
        $(chooseFile).sendKeys(new File(directoryPath + fileName).getAbsolutePath());
        commonMethods.waitForElementExplicitly(2000);
        $(okBtn).click();
    }

    /**
     * click on doc Number
     *
     * @param docName
     */
    public void clickDocNumber(String docName) {
        commonMethods.waitForElementExplicitly(2000);
        $(By.xpath("//a[text()='" + docName + "']")).click();
    }

    /**
     * click doc review tab
     */
    public void clickDocReviewTab() {
        commonMethods.waitForElement(driver, docReviewTab, 40);
        $(docReviewTab).click();
    }

    /**
     * Method to return the value from the review outcome select list
     *
     * @return
     */
    public String returnReviewOutcome() {
        Select select = new Select($(selectOutcome));
        WebElement option = select.getFirstSelectedOption();
        return option.getText();
    }

    /**
     * Method to return the comment present
     *
     * @return
     */
    public String returnComment() {
        return $(comment).getText();
    }

    /**
     * Function to select review outcome and provide comments and submit
     */
    public void reviewAndSubmitDocument(String outcome, String comments) {
        $(firstDocChkBox).click();
        $(selectOutcome).selectOption(outcome);
        if (!comments.isEmpty()) {
            $(comment).click();
            commonMethods.waitForElementExplicitly(1000);
            $(textAreaComment).setValue(comments);
        }
        submitDocuments();
    }

    /**
     * Method to assert the title of the Document Review List mode page
     *
     * @return
     */
    public String verifyPageTitle() {
        return $(hdrTitle).getText();
    }

    /**
     * Method to verify List Mode Options
     */
    public void verifyListModeOptions() {
        verifyAndSwitchFrame();
        Assert.assertTrue($(backBtn).isDisplayed());
        Assert.assertTrue($(submitSelectedDocumentsBtn).isDisplayed());
        Assert.assertTrue($(tabDocForReviews).isDisplayed());
        Assert.assertTrue($(tabSupplimentaryFiles).isDisplayed());
        verifyDocForReviewsOptions();
    }

    /**
     * Method to verify Document reviews Options
     */
    public void verifyDocForReviewsOptions() {
        Assert.assertTrue($(lblInformation).isDisplayed());
        Assert.assertTrue($(lblWorkflowNote).isDisplayed());
        Assert.assertTrue($(btnBulkReview).isDisplayed());
        Assert.assertTrue($(btnStartSubWorkflow).isDisplayed());
        Assert.assertTrue($(btnDelegate).isDisplayed());
        Assert.assertTrue($(btnZipDownload).isDisplayed());
        Assert.assertTrue($(btnMoreOptions).isDisplayed());
        $(btnMoreOptions).click();
        Assert.assertTrue($(btnPrintRequest).isDisplayed());
        Assert.assertTrue($(btnUploadReplacements).isDisplayed());
    }

    /**
     * Method to verify Document review list mode results headers
     */
    public List<String> verifyListModeTableHeaders() {
        return commonMethods.getValues(tblHeaders);
    }

    /**
     * Function to get document row number
     */
    public int getWFDocRow(String docName) {
        By xpath = By.xpath(tblDocRows + "/td[4]/a");
        return commonMethods.getDocumentRow(xpath, docName);
    }

    /**
     * Function to return document details
     */
    public String getDocDetails(String key, int row) {
        return $(By.xpath("//table[@class='dataTable']/tbody/tr[" + row + "]/td[" + getColumnIndex(key) + "]")).getText();
    }

    /**
     * Function to return document details
     */
    public String getFirstDocDetails(String key) {
        return $(By.xpath("//table[@class='dataTable']/tbody/tr[1]/td[" + getColumnIndex(key) + "]")).getText();
    }

    /**
     * Function to return column index
     */
    public int getColumnIndex(String colName) {
        return commonMethods.getColIndex(getTableHeaders(1), colName);
    }

    /**
     * Function to get report headers
     */
    public List<String> getTableHeaders(int headerRow) {
        return commonMethods.getValues(By.xpath("//table[@class='dataTable']//tr[@class='dataHeaders'][" + headerRow + "]/th"));
    }

    /**
     * Function to click on Bulk review button
     */
    public void clickOnBulkReview() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, btnBulkReview, 30);
        $(btnBulkReview).click();
    }

    /**
     * Function to verify Bulk review popup window options
     */
    public void verifyBulkReviewPopup() {
        commonMethods.waitForElement(driver, lblBulkReviewOptions, 10);
        Assert.assertTrue($(lblBulkReviewOptions).isDisplayed());
        Assert.assertTrue($(sltReviewOutcome).isDisplayed());
        Assert.assertTrue($(txtBoxComments).isDisplayed());
        Assert.assertTrue($(radioBtnSelectedDocs).isDisplayed());
        Assert.assertTrue($(radioBtnBlankDocs).isDisplayed());
        Assert.assertTrue($(radioBtnAllDocs).isDisplayed());
        Assert.assertTrue($(btnOk).isDisplayed());
        Assert.assertTrue($(btnCancel).isDisplayed());
    }

    /**
     * Function to return review outcomes dropdown values
     */
    public List<String> assertReviewOutcome() {
        return commonMethods.returnAllOptionsInDropDown(driver, sltReviewOutcome);
    }

    /**
     * Function to close bulk review popup window
     */
    public void closeBulkReview() {
        $(btnCancel).click();
    }

    /**
     * Function to click on Ok button
     */
    public void clickOk() {
        $(btnOk).click();
    }

    /**
     * Function to select the document
     */
    public void selectDocument(String docId, boolean value) {
        int rowId = getWFDocRow(docId);
        $(By.xpath(tblDocRows + "[" + (rowId + 1) + "]/td[1]/input[@name='selectedQueueIds']")).setSelected(value);
    }

    /**
     * Function to select review outcome from dropdown in bulk review popup window
     */
    public void setReviewOutcome(String outcome) {
        commonMethods.waitForElement(driver, sltReviewOutcome);
        $(sltReviewOutcome).selectOption(outcome);
    }

    /**
     * Function to select review comments in bulk review popup window
     */
    public void setReviewComments(String comments) {
        $(txtBoxComments).clear();
        commonMethods.waitForElementExplicitly(500);
        $(txtBoxComments).sendKeys(comments);
    }

    /**
     * Function to select selected documents radio button in bulk review popup window
     */
    public void setSelectedDocuments() {
        $(radioBtnSelectedDocs).click();
    }

    /**
     * Function to select blank documents radio button in bulk review popup window
     */
    public void setBlankDocuments() {
        $(radioBtnBlankDocs).click();
    }

    /**
     * Function to select all documents radio button in bulk review popup window
     */
    public void setAllDocuments() {
        $(radioBtnAllDocs).click();
    }

    /**
     * Function to get document review outcome
     */
    public String getDocOutcome(int docRow) {
        return $(By.xpath(tblDocRows + "[" + docRow + "]/td[8]/div/select")).getSelectedOption().getText();
    }

    /**
     * Function to get document comments
     */
    public String getDocComments(int docRow) {
        return $(By.xpath(tblDocRows + "[" + docRow + "]/td[9]/div/div/span")).getText();
    }

    /**
     * Function to click on tabs in List Mode page
     */
    public void clickTab(String tabName) {
        By xpath = By.xpath("//li[contains(text(),'" + tabName + "')]");
        commonMethods.getElementInViewAndUp(xpath);
        $(xpath).click();
    }

    /**
     * Function to verify Supplementary tab
     */
    public void verifySupplementaryTab() {
        commonMethods.waitForElement(driver, btnZipDownload, 30);
        Assert.assertTrue($(btnZipDownload).isDisplayed());
    }

    /**
     * Function to click on Attach file
     */
    public void clickAttachFile() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementClickable(driver, btnAttachFile, 30);
        commonMethods.getElementInViewAndUp(btnAttachFile);
        $(btnAttachFile).click();
    }

    /**
     * Function to verify attach file popup window options
     */
    public void verifyAttachFileTab() {
        commonMethods.waitForElement(driver, lblAttachAFile, 60);
        Assert.assertTrue($(lblAttachAFile).isDisplayed());
        Assert.assertTrue($(lblFrom).isDisplayed());
        Assert.assertTrue($(btnLocalComputer).isDisplayed());
        Assert.assertTrue($(btnAttachFromDocs).isDisplayed());
        //Assert.assertTrue($(btnAttachFileOK).isDisplayed());
        Assert.assertTrue($(btnAttachFileCancel).isDisplayed());
    }

    /**
     * Function to click local computer button
     */
    public void clickLocalNetwork() {
        $(btnLocalComputer).click();
    }

    /**
     * Function to verify Local computer or network tab
     */
    public void verifyLocalComputerTab() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, lblLocalAttachFile, 30);
        Assert.assertTrue($(lblLocalAttachFile).isDisplayed());
        Assert.assertTrue($(btnAttach).isDisplayed());
        Assert.assertTrue($(btnClose).isDisplayed());
    }

    /**
     * Function to upload local file
     */
    public void uploadLocalFile(String file) {
        verifyAndSwitchFrame(attachFileFrame);
        $(btnLocalAttach).sendKeys(new File(file).getAbsolutePath());
        commonMethods.waitForElement(driver, btnClearAll, 30);
        verifyAndSwitchFrame();
        getElementInView(btnAttach);
        $(btnAttach).click();
        verifyAndSwitchFrame(attachFileFrame);
        commonMethods.waitForElement(driver, lblUploaded, 60);
        verifyAndSwitchFrame();
        $(btnClose).click();
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Function to verify uploaded file
     */
    public void verifyUploadFile(String fileName) {
        commonMethods.waitForElement(driver, btnLocalComputer, 30);
        verifyAndSwitchFrame();
        Assert.assertTrue($(By.xpath("//td[contains(text(),'" + fileName + "')]")).isDisplayed());
    }

    /**
     * Function to add comments in attach a file tab
     */
    public void addComments(String comment) {
        By xpath = By.xpath("(" + txtAreaAttachComments + ")[" + $$(txtBoxAttachComments).size() + "]");
        verifyAndSwitchFrame();
        commonMethods.getElementInViewAndUp(txtBoxAttachComments);
        $(txtBoxAttachComments).click();
        commonMethods.waitForElement(driver, xpath, 60);
        $(xpath).clear();
        commonMethods.waitForElementExplicitly(200);
        $(xpath).sendKeys(comment);
    }

    /**
     * Function to click on Ok button in Attach a file popup window
     */
    public void clickAttachOkBtn() {
        $(btnAttachFileOK).click();
    }

    /**
     * Function to get report headers
     */
    public List<String> getSFTableHeaders() {
        commonMethods.getElementInViewAndUp(tblSFHeaders);
        commonMethods.waitForElement(driver,tblSFHeaders);
        return commonMethods.getValues(tblSFHeaders);
    }

    /**
     * Function to click document register button
     */
    public void clickDocumentRegister() {
        $(btnDocumentRegister).click();
    }

    /**
     * Function to verify document register popup window
     */
    public void verifyDocRegisterTab() {
        Assert.assertTrue($(lblSFDocRegister).isDisplayed());
        verifyAndSwitchFrame("attachFileChoice_attachDocs_frame");
        commonMethods.waitForElement(driver, documentPage.searchDocKeywords, 60);
        Assert.assertTrue($(documentPage.searchDocKeywords).isDisplayed());
    }

    /**
     * Function to attach document from doc register popup window
     */
    public void attachDocument(String docNo) {
        verifyAndSwitchFrame("attachFileChoice_attachDocs_frame");
        if ($(documentPage.clearAllFilter).isDisplayed()) {
            commonMethods.clickOnElement((documentPage.clearAllFilter));
            commonMethods.waitForElementExplicitly(1000);
        }
        documentPage.searchDocumentNo(docNo);
        commonMethods.waitForElement(driver, documentPage.selectFirstFile, 35);
        $(documentPage.selectFirstFile).click();
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, btnDocRegAttach, 20);
        $(btnDocRegAttach).click();
        commonMethods.waitForElementExplicitly(2000);
    }


    /**
     * Function to return SF column index
     */
    public int getSFColIndex(String colName) {
        List<String> headers = getSFTableHeaders();
        return headers.indexOf(colName) + 1;
    }

    /**
     * Function to return SF attached file details
     */
    public String getAttachFileDetails(String colName, int row) {
        return $(By.xpath("//table[@id='supplementaryFilesResultsTable']//tr[" + row + "]/td[" + getSFColIndex(colName) + "]")).getText();
    }

    /**
     * Function to submit all reviewed documents
     */
    public void submitAllDocuments() {
        selectAllDocuments();
        submitDocuments();
    }

    /**
     * Function to select All documents
     */
    public void selectAllDocuments() {
        verifyAndSwitchFrame();
        $(chkboxSelectAll).click();
        $(lnkSelectAllResults).click();
    }

    /**
     * Function to submit documents
     */
    public void submitDocuments() {
        clickSubmitSelectedDocuments();
        commonMethods.waitForElement(driver, summaryPanel, 60);
        commonMethods.waitForElementClickable(driver, submitDoc, 60);
        commonMethods.getElementInViewAndUp(submitDoc);
        commonMethods.waitForElementExplicitly(1000);
        $(submitDoc).click();
    }

    /**
     * Function to click on Upload replacement button for specific document
     */
    public void clickUploadReplacement(String docName) {
        $(By.xpath(tblDocRows + "[" + (getWFDocRow(docName) + 1) + "]/td[12]//button/img[contains(@id,'fileAttachIcon')]")).click();
    }

    /**
     * Function to click on Temporary Files button
     */
    public void clickTemporaryFiles() {
        $(btnTemporaryFiles).click();
    }

    /**
     * Function to verify replacement files from temporary files popup window
     */
    public void verifyTempFilesTab() {
        Assert.assertTrue($(lblReplacementFile).isDisplayed());
        verifyAndSwitchFrame("attachFileChoice_attachDocs_frame");
        commonMethods.waitForElement(driver, documentPage.searchDocKeywords, 60);
        Assert.assertTrue($(documentPage.searchDocKeywords).isDisplayed());
    }

    /**
     * Function to verify replacement files from temporary files popup window
     */
    public String verifyColumnValue(String colName, String docName) {
        return $(By.xpath(tblDocRows + "[" + (getWFDocRow(docName) + 1) + "]/td[" + getColumnIndex(colName) + "]")).getAttribute("innerText");
    }

    /**
     * Function to click on print request
     */
    public void clickPrintRequest() {
        commonMethods.waitForElement(driver, btnMoreOptions, 30);
        $(btnMoreOptions).click();
        $(btnPrintRequest).click();
    }

    /**
     * Function to verify Print Request Page
     */
    public boolean verifyPrintRequestPage() {
        commonMethods.waitForElement(driver, btnContinue, 60);
        return $(hdrPrintRequest).isDisplayed();
    }

    /**
     * Function to fill mandatory print request details
     */
    public void fillPrintDetails(String userRef, String shop, String deliverBy) {
        commonMethods.waitForElement(driver, txtBoxUserReference, 30);
        $(txtBoxUserReference).sendKeys(userRef);
        commonMethods.enterDropdownValue(sltPrintShop, shop);
        commonMethods.enterDropdownValue(sltDeliverBy, deliverBy);
    }

    /**
     * Function to click and Edit Page Options
     */
    public void editPage(boolean applyChanges) {
        $(By.xpath("(" + (lnkEdit) + ")[" + $$(By.xpath((lnkEdit))).size() + "]")).click();
        commonMethods.waitForElement(driver, hdrEditPrintOptions, 60);
        $(chkBoxApplyChanges).setSelected(applyChanges);
        $(btnSave).click();
        commonMethods.waitForElement(driver, lblPrintOptionsSuccess, 30);
        Assert.assertTrue($(lblPrintOptionsSuccess).isDisplayed());
    }

    /**
     * Function to click continue button
     */
    public void clickContinue() {
        commonMethods.waitForElement(driver, btnContinue, 30);
        $(btnContinue).click();
    }

    /**
     * Function to click send request button
     */
    public void clickSendRequest() {
        commonMethods.waitForElement(driver, btnSendRequest, 30);
        $(btnSendRequest).click();
    }

    /**
     * Function to verify success message
     */
    public void verifyPrintSuccess() {
        commonMethods.waitForElement(driver, lblConfirmation, 60);
        Assert.assertTrue($(lblConfirmation).isDisplayed());
        Assert.assertTrue($(lblPrintSuccess).isDisplayed());
    }

    /**
     * Function to verify success message
     */
    public void clickUploadReplacements() {
        commonMethods.waitForElement(driver, btnMoreOptions, 30);
        $(btnMoreOptions).click();
        $(btnUploadReplacements).click();
    }

    /**
     * Function to close Attach a File popup window
     */
    public void closeAttachAFile() {
        $(btnAttachFileCancel).click();
    }

    /**
     * Function to verify local network popup window
     */
    public void verifyLocalNetworkTab() {
        commonMethods.waitForElement(driver, okBtn, 30);
        Assert.assertTrue($(chooseFile).isDisplayed());
        Assert.assertTrue($(okBtn).isDisplayed());
        Assert.assertTrue($(btnLocalAttachCancel).isDisplayed());
    }

    /**
     * Function to verify error message when submitting invalid documents and click cancel button
     */
    public void verifyInvalidDocuments() {
        Assert.assertTrue($(lblReplacementNotFound).isDisplayed());
        Assert.assertTrue($(btnReviewSubmitDocsCancel).isDisplayed());
    }

    /**
     * Function to verify error message when submitting no outcome documents and click cancel button
     */
    public void verifyNoOutcome() {
        Assert.assertTrue($(lblMissingOutcome).isDisplayed());
        Assert.assertTrue($(btnReviewSubmitDocsCancel).isDisplayed());
    }

    public void verifyError() {
        commonMethods.waitForElement(driver, summaryPanel, 30);
        commonMethods.waitForElement(driver, lblErrorMessage, 30);
        Assert.assertTrue($(lblErrorMessage).isDisplayed());
    }

    /**
     * Function to click on Submit Selected Document button
     */
    public void clickSubmitSelectedDocuments() {
        commonMethods.waitForElement(driver, submitSelectedDocumentsBtn, 30);
        $(submitSelectedDocumentsBtn).click();
    }

    /**
     * Function to return all document names
     */
    public List<String> getDocumentNames() {
        List<String> docNames = new ArrayList<>();
        commonMethods.waitForElement(driver, By.xpath(tblDocRows));
        List<WebElement> elements = new ArrayList<>($$(By.xpath(tblDocRows)));
        for (int i = 1; i <= elements.size(); i++)
            docNames.add($(By.xpath(tblDocRows + "[" + i + "]/td[4]/a")).getText());
        return docNames;
    }

    /**
     * Function to return all document names
     */
    public void clickColHeader(String colName) {
        $(By.xpath("//table[@class='dataTable']//th/div[contains(text(),'" + colName + "')]")).click();
    }

    /**
     * Function to set review outcome for specific row of document
     */
    public void setReviewOutcome(int row, String outcome) {
        if (!outcome.isEmpty())
            $(By.xpath("//table[@class='dataTable']//tr[" + row + "]//select[contains(@id,'reviewOutcome')]")).selectOption(outcome);
    }

    /**
     * Function to set review comments for specific row of document
     */
    public void setReviewComments(int row, String comments) {
        String element = "//table[@class='dataTable']//tr[" + row + "]//div[contains(@id,'divDisplay_comments')]";
        if (!comments.isEmpty()) {
            $(By.xpath(element)).click();
            $(By.xpath(element + "/..//textarea[@class='commentsTextArea']")).setValue(comments);
        }
    }

    /**
     * Function to cancel submission panel
     */
    public void cancelSubmissionPanel() {
        commonMethods.waitForElement(driver, btnReviewSubmitDocsCancel, 60);
        commonMethods.waitForElementClickable(driver, btnReviewSubmitDocsCancel, 30);
        $(btnReviewSubmitDocsCancel).click();
    }

    /**
     * Function to submit valid and invalid documents
     */
    public void verifyReplaceNotFound() {
        commonMethods.waitForElement(driver, summaryPanel, 30);
        commonMethods.waitForElementClickable(driver, submitDoc, 30);
        Assert.assertTrue($(lblErrorMessage).isDisplayed());
        Assert.assertTrue($(lblReplacementNotFound).isDisplayed());
    }

    /**
     * Function to click on submit documents button in submit selected documents popup window
     */
    public void clickSubmitDocuments() {
        commonMethods.getElementInViewAndUp(submitDoc);
        $(submitDoc).click();
    }

    /**
     * Function to verify delegate tooltip
     */
    public void verifyDelegateToolTip(String message) {
        commonMethods.getElementInViewAndUp(delegateBtn);
        Assert.assertEquals(message, verifyToolTips(delegateBtn));
    }

    /**
     * Function to verify delegate popup window
     */
    public void verifyDelegatepopup() {
        commonMethods.waitForElement(driver, hdrDelegateTask, 30);
        Assert.assertTrue($(hdrDelegateTask).isDisplayed());
        Assert.assertTrue($(lblDelegateTask).isDisplayed());
        Assert.assertTrue($(txtBoxWith).isDisplayed());
        Assert.assertTrue($(cancelBtn).isDisplayed());
        Assert.assertTrue($(btnDelegateOk).isDisplayed());
        Assert.assertTrue($(By.xpath(tblSelectedTask)).isDisplayed());
    }

    /**
     * Function to close delegate window by clicking X button
     */
    public void closeDelegateWindow() {
        commonMethods.waitForElement(driver, btnDelegateClose, 60);
        $(btnDelegateClose).click();
    }

    /**
     * Function to delegate a task
     */
    public void delegateTask(String userName) {
        searchWithUser(userName);
        verifyDelegateUser(userName);
        clickDelegateOk();
    }

    /**
     * Function to verify delegate user
     */
    public void verifyDelegateUser(String user) {
        commonMethods.waitForElementExplicitly(5000);
        Assert.assertTrue($(By.xpath("//div[contains(text(),'" + user + "')]")).isDisplayed());
        Assert.assertTrue($(btnTrash).isDisplayed());
    }

    /**
     * Function to click ok in delegate popup window
     */
    public void clickDelegateOk() {
        commonMethods.waitForElement(driver, btnDelegateOk, 20);
        $(btnDelegateOk).click();
    }

    /**
     * Function to verify delegate task success message
     */
    public void verifyDelegateSuccess() {
        commonMethods.waitForElement(driver, lblSuccessTask, 60);
        Assert.assertTrue($(lblSuccessTask).isDisplayed());
        Assert.assertTrue($(lblDelegateSummary).isDisplayed());
        Assert.assertTrue($(btnDelegateSuccessClose).isDisplayed());
    }

    /**
     * Function to close delegate task success window
     */
    public void closeDelegateSuccess() {
        $(btnDelegateSuccessClose).click();
    }

    /**
     * Function to search for With user in delegate window
     */
    public void searchWithUser(String userName) {
        commonMethods.waitForElement(driver, txtBoxWith, 30);
        commonMethods.enterTextValue(txtBoxWith, userName);
        $(txtBoxWith).sendKeys(Keys.ENTER);
    }

    /**
     * Function to verify incorrect user in delegate window
     */
    public boolean verifyIncorrectUser(String userName) {
        commonMethods.waitForElementExplicitly(5000);
        return $(By.xpath("//div[contains(text(),'No match found for " + userName + ". Try a less specific query or')]")).isDisplayed();
    }

    /**
     * Function to verify unregisterd documents message
     */
    public String verifyUnRegDocMessage() {
        verifyAndSwitchFrame();
        return $(By.xpath(tblUnregisteredMessage)).getAttribute("innerText");
    }

    /**
     * Method to review the document
     *
     * @param outcome
     * @param comments
     */
    public void reviewDocument(String outcome, String comments) {
        $(selectOutcome).selectOption(outcome);
        if (!comments.isEmpty()) {
            $(comment).click();
            $(textAreaComment).setValue("");
            commonMethods.waitForElementExplicitly(500);
            $(textAreaComment).setValue(comments);
        }
    }

    /**
     * Method to validate if reviews can be submitted with unpublished markups
     */
    public void verifyUnPublishedMessage() {
        Assert.assertTrue($(unpublishedMsg).isDisplayed());
    }

    /**
     * Method to return the message when markup is updated
     *
     * @return
     */
    public boolean returnMarkupUpdated() {
        return $(spanUpdatedMarkup).isDisplayed();
    }


    /**
     * Method to return the message when file is displayed
     *
     * @return
     */
    public boolean returnFileReplacedMsg() {
        return $(fileReplacedMsg).isDisplayed();

    }

    /**
     * Method to check if auto save message is displayed
     *
     * @return
     */
    public boolean returnAutoSaveMsg() {
        return $(autoSaveMsg).exists();
    }

    /**
     * Method to check for the error message when review outcome is missing
     */
    public void verifyReviewOutcomeMessage() {
        Assert.assertTrue($(missingReviewOutcomeMsg).isDisplayed());
    }

    /**
     * Method to verify if the error message appears when
     * there are markups not published by other user
     *
     * @return
     */
    public boolean verifyOtherReviewerErrorMsg() {
        commonMethods.waitForElement(driver, otherReviewerError);
        return $(otherReviewerError).isDisplayed();
    }

    /**
     * Method to click on Zip download button
     */
    public void clickZipDownload() {
        commonMethods.waitForElement(driver, btnZipDownload);
        $(btnZipDownload).click();
    }

    /**
     * Method to select the documents,
     * when we have to select multiple documents for bulk review
     * @param document
     */
    public void selectDocument(String document){
        By by = By.xpath("//a[text()='"+ document +"']//..//preceding::td//input");
        $(by).setSelected(true);
    }

    /**
     * Method to click the sub workflow button
     */
    public void clickSubWorkflowBtn(){
        $(startSubWorkflowBtn).click();
    }
}
