package com.oracle.babylon.pages.Fields;

import com.codeborne.selenide.Condition;
import com.oracle.babylon.Utils.helper.Navigator;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.$;

public class FieldSettingsPage extends Navigator {

    private By pageTitle = By.xpath("//*[contains(@class,'auiToolbar-header')]");
    private By orgTextLoc = By.xpath("//*[text()='Your organization']");

    /**
     * Method to navigate to field settings page
     */
    public void navigateAndVerifyPage() {
        refresh();
        getMenuSubmenu("Field", "Settings");
        verifyAndSwitchFrame();
        $(pageTitle).waitUntil(Condition.appears,60000).isDisplayed();
        switchProjectSettingsFrame();
        $(orgTextLoc).waitUntil(Condition.appears,60000).isDisplayed();
    }
}
