package com.oracle.babylon.pages.Setup.ProjectSettings;

import com.oracle.babylon.pages.Setup.ProjectSettingsPage;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.$;

public class ProjectDetailsPage extends ProjectSettingsPage {

    private By projectMenu = By.xpath("//a[@class='auiCollapsibleSection-header']//span[contains(text(),'Project')]");
    private By projectDetails = By.xpath("//div[contains(text(),'Project Details')]");
    private By copyBtn = By.xpath("//div[contains(text(),'Copy')]");
    private By continueBtn = By.xpath("//div[contains(text(),'Continue')]");
    private By viewNewProject = By.xpath("//a[contains(text(),'View new project.')]");
    private By projectArrow = By.xpath("//span[contains(text(),'Project')]//..//..//span[@class='auiIcon auiCollapsibleSection-headerArrow chevronRight']");
    private By setAccessLevel = By.xpath("//div[text()='Set Access Level']");
    private By confirmAccessLevel = By.xpath("//button[@id='confirmAccessLevel-commit']");
    private By editAccessLevel = By.xpath("//button[@id='btnEditAccessLevel']");

    /**
     * method to navigate to project Details Page
     */

    public void navigateToProjectDetails() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, projectMenu, 35);
        $(projectMenu).click();
        if ($(projectArrow).isDisplayed()) {
            $(projectArrow).click();
        }
        commonMethods.waitForElement(driver, projectDetails, 35);
        $(projectDetails).click();
        verifyPageTitle("Project Settings");
    }

    /**
     * method to click on copy button to create another copy of same project
     */

    public void copyProject() {
        switchProjectSettingsFrame();
        commonMethods.waitForElement(driver, copyBtn, 30);
        $(copyBtn).click();
        $(continueBtn).click();
    }

    /**
     * method to click on link to view newly created project
     */

    public void clickViewNewProject() {
        commonMethods.waitForElement(driver, viewNewProject, 45);
        $(viewNewProject).click();
    }

    /**
     * Function to change org access level
     *
     * @param level
     */
    public void changeOrgAccessLevel(String org, String level) {
        commonMethods.waitForElementExplicitly(2000);
        switchProjectSettingsFrame();
        commonMethods.waitForElement(driver, editAccessLevel, 30);
        $(editAccessLevel).click();
        commonMethods.waitForElementExplicitly(5000);
        $(By.xpath("//div[contains(text(),'" + org + "')]//..//../td//input")).click();
        $(setAccessLevel).click();
        $(By.xpath("//ul[@id='setAccessLevelMenu']//li//div[text()='" + level + "']")).click();
        if (level.equalsIgnoreCase("Archive")) {
            $(confirmAccessLevel).click();
        } else {
            $(confirmAccessLevel).click();
        }
    }

}
