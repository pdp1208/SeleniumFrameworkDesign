package com.oracle.babylon.pages.Tenders;

import org.junit.Assert;
import org.openqa.selenium.By;

import java.io.File;
import java.util.Map;

import static com.codeborne.selenide.Selenide.*;

public class TenderSubmissionPage extends TenderPage {

    private By createSubmissionBtn = By.xpath("//div[contains(text(),'Create Submission')]");
    private By coverLetterField = By.xpath("//textarea[@id='coverLetter']");
    private By declineSubmissionBtn = By.xpath("//div[contains(text(),'Decline Invitation')]");
    private By sendBtn = By.xpath("//div[contains(text(),'Send')]");
    private By submissionStatus = By.xpath("//table[@class='grid-body-table dataTable']//tr[1]//td[4]//div");
    private By declineInvitation = By.xpath("//textarea[@name='declinedComment']");
    private By okBtn = By.xpath("//div[contains(text(),'OK')]");
    private By selectAllMenu = By.xpath("//div[@id='localFilesGrid']//thead//div[@id='checkboxselect']");
    private String selectAll = "//ul//li/div[text()='Select All']";
    private By attachAFile = By.xpath("//button[@title='Attach a File']");
    private By uploadFile = By.xpath("//input[@name='FILE_PATH_NAME']");
    String filePath = System.getProperty("user.dir") + "/src/main/resources/data/files/";
    private By attachLocalFile = By.id("attachLocalFile-commit");


    /**
     * Method to click create Submission
     */
    public void clickCreateSubmission() {
        verifyAndSwitchFrame();
        $(createSubmissionBtn).click();
    }


    /**
     * Method to send Submission
     */
    public void sendSubmission() {
        verifyAndSwitchFrame();
        $(sendBtn).click();
        commonMethods.waitForElementExplicitly(3000);
        driver.switchTo().alert().accept();
    }


    /**
     * Method to create tender submission
     */
    public void createSubmission(String attribute) {
        switchTo().defaultContent();
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(3000);
        Map<String, String> table = dataStore.getTable(attribute);
        //According to the keys passed in the table, we select the fields
        for (String tableData : table.keySet()) {
            switch (tableData.toLowerCase()) {
                case "cover letter":
                    enterCoverLetter(table.get(tableData));
                    break;
                case "local attachment":
                    attachLocalFile(table.get(tableData));
                    break;
                case "Attachment":
                    uploadAttachment(table.get(tableData));
                    break;
            }
        }
        commonMethods.waitForElementExplicitly(6000);
    }

    /**
     * Method to enter submission cover letter
     */
    public void enterCoverLetter(String coverLetter) {
        verifyAndSwitchFrame();
        $(coverLetterField).clear();
        $(coverLetterField).sendKeys(coverLetter);
    }


    /**
     * Method to verify tender status
     *
     * @param status of submission
     */
    public void verifySubmissionStatus(String status) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(5000);
        Assert.assertTrue($(submissionStatus).text().contains(status));
    }

    /**
     * Method to decline tender invitation
     */
    public void declineTenderInvitation(String message) {
        verifyAndSwitchFrame();
        $(declineSubmissionBtn).click();
        $(declineInvitation).sendKeys(message);
        commonMethods.waitForElementExplicitly(1000);
        $(okBtn).click();
        commonMethods.waitForElementExplicitly(1000);
    }

    /**
     * Method to verify tender submission page is displayed.
     */
    public boolean verifySubmission() {
        commonMethods.waitForElement(driver, submissionTab, 60);
        return $(submissionStatus).isDisplayed();
    }

    /**
     * Function to Attach a Local File to tender invitation page
     *
     * @param fileName
     */
    public void attachLocalFile(String fileName) {
        getElementInView(attachDropDown);
        commonMethods.waitForElement(driver, attachDropDown);
        $(attachDropDown).click();
        commonMethods.waitForElement(driver, btnAttach, 30);
        $(txtBoxChooseFile).sendKeys(new File(configFileReader.getTestDataPath() + "/" + fileName).getAbsolutePath());
        $(btnAttach).click();
        commonMethods.waitForElementExplicitly(5000);
    }

    /**
     * Method to select all attached documents
     */
    public void selectAllDocs() {
        commonMethods.waitForElement(driver, selectAllMenu, 60);
        $(selectAllMenu).click();
        $(By.xpath("(" + selectAll + ")[" + $$(By.xpath(selectAll)).size() + "]")).click();
    }

    public void uploadAttachment(String fileName) {
        commonMethods.waitForElement(driver, attachAFile);
        $(attachAFile).click();
        commonMethods.waitForElement(driver, uploadFile);
        $(uploadFile).sendKeys(filePath + fileName);
        commonMethods.waitForElementExplicitly(4000);
        commonMethods.waitForElement(driver, attachLocalFile);
        $(attachLocalFile).click();
    }
}
