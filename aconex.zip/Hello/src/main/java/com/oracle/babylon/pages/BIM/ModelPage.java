package com.oracle.babylon.pages.BIM;

import com.codeborne.selenide.Condition;
import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import static com.codeborne.selenide.Selenide.$;

public class ModelPage extends Navigator {
    private String bimModelPath = configFileReader.getBimModelDataPath();
    String filePath = System.getProperty("user.dir") + "/src/main/resources/data/files/";
    private By bimIcon = By.xpath("//*[@class='bim-icon']");
    private By addANewModel = By.xpath("//*[@title='Add a new model stack']");
    private By frameBim = By.xpath("//iframe[contains(@src,'bim')]");
    private By localFile = By.xpath("//span[text()='Local file']");
    private By headerAddNewModelStack = By.xpath("//h3[text()='Add new model stack']");
    private By nameForThisModel = By.xpath("//input[@placeholder='Enter a name for this model stack']");
    private By addButton = By.xpath("//footer//button[text()='Add']");
    private By uploadLink = By.xpath("//div//*[text()='Upload a model']");
    private By newRevision = By.xpath("//h4[text()='New revision']");
    private By uploadInput = By.xpath("//input[@class='native-file-input']");
    private By fileName = By.xpath("//div[@class='file-name ng-binding']");
    private By uploadButton = By.xpath("//footer//button[text()='Upload']");
    private By search = By.xpath("//input[@placeholder='Search']");
    private By threeDots = By.xpath("//*[@title='Show/hide tools for this model stack']");
    private By settings = By.xpath("//li[contains(text(),'Settings')]");
    private By settingsHeader = By.xpath("//h3[contains(text(),'Settings for')]");
    private By removeModel = By.xpath("//button[text()='Remove from model stack list']");
    private By navMode = By.xpath("(//div[@class='navbar']//li[@title='Choose a navigation mode'])[1]");
    private By removeBtn = By.xpath("//button[text()='Remove']");
    private By successMsg = By.xpath("//*[contains(text(),'model was successfully uploaded.')]");
    private By removeMsg = By.xpath("//*[contains(text(),'model has been removed successfully.')]");
//    private By headerSection = By.xpath("(//div[@class='panel border blank-slate panel-padded ng-scope']//h1)[1]");

    public void navigateAndVerifyPage() {
        String bimMenu = getBIMMenu();
//        getMenuSubmenu(bimMenu, "Explore");
        doubleClickMenu(bimMenu);
        $(loadingIcon).should(Condition.disappear);
        verifyAndSwitchFrame();
//        driver.switchTo().frame(0);
        commonMethods.waitForElementExplicitly(15000);
        switchToFrameBim();
        commonMethods.waitForElementExplicitly(5000);
        switchToFrameBim();
//        switchToFrameBim();
        commonMethods.waitForElement(driver, headerSection, 120);
        Assert.assertTrue($(headerSection).getText().contains("Welcome to Models"));
    }

    public void writeModelNumToJson(String modelId, String modelName) {
        //Write the data to the json file
        Map<String, Object> map = new Hashtable<>();
        Map<String, Map<String, Object>> mapOfMap = new HashMap<>();
        map.put("model_number", modelName);
        mapOfMap.put(modelId, map);
        dataSetup.fileWrite(modelId, mapOfMap, bimModelPath);
    }

    public String getModelNoFromJSON(String modelId) {
        Map<String, Map<String, Object>> jsonData = new HashMap<>();
        Map<String, Object> map = new HashMap<>();
        jsonData = dataSetup.loadJsonDataToMap(bimModelPath);
        map = jsonData.get(modelId);
        return map.get("model_number").toString();
    }

    public boolean verifyAddNewModel() {
        return $(addANewModel).isDisplayed();
    }

    public void clickAddAModel() {
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, addANewModel);
        $(addANewModel).click();
        commonMethods.waitForElement(driver, localFile);
        $(localFile).click();
    }

    public String uploadModel() {
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, headerAddNewModelStack);
        String modelName = faker.file().fileName().substring(0, 5) + " " + faker.number().digits(3);
        $(nameForThisModel).sendKeys(modelName);
        $(addButton).click();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, uploadLink, 60);
        $(uploadLink).click();
        commonMethods.waitForElement(driver, newRevision);
        $(uploadInput).sendKeys(filePath + "duplex.ifczip");
        Assert.assertTrue($(fileName).getText().contains("duplex"));
        $(uploadButton).click();
        commonMethods.waitForElement(driver, successMsg, 180);
        return modelName;
    }

    public void switchToFrameBim() {
        commonMethods.waitForElementExplicitly(3000);
        driver.switchTo().frame($(frameBim));
    }

    public void clickModel(String modelName) {
        commonMethods.waitForElementExplicitly(3000);
        By model = By.xpath("//div[@class='list model-list']//*[text()='" + modelName + "']");
        $(model).click();
        //$(By.xpath("//*[@title='"+modelName+"']")).click();
        commonMethods.waitForElementExplicitly(4000);
    }

    public void selectVerifyModel(String modelName) {
        commonMethods.waitForElementExplicitly(8000);
        clickModel(modelName);
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, navMode, 120);
        Assert.assertTrue($(navMode).isDisplayed());
    }

    public boolean modelPresence(String modelName) {
        commonMethods.waitForElementExplicitly(3000);
        By model = By.xpath("//div[@class='list model-list']//*[text()='" + modelName + "']");
        return $(model).isDisplayed();
    }

    public boolean verifyModel() {
        commonMethods.waitForElementExplicitly(2000);
        ArrayList<WebElement> numModels = (ArrayList<WebElement>) driver.findElements(By.xpath("//div[@class='list model-list']//div[@tabindex='0']"));
        if (numModels.size() >= 1) {
            return true;
        } else {
            return false;
        }
    }


    public void searchModel(String modelName) {
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, search);
        $(search).clear();
        commonMethods.sleep(2000);
        $(search).sendKeys(modelName + Keys.ENTER);
    }

    public void navigateSettings() {
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, threeDots);
        $(threeDots).click();
        commonMethods.waitForElement(driver, settings);
        $(settings).click();
        commonMethods.waitForElement(driver, settingsHeader);
    }

    public void removeModel() {
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, removeModel);
        $(removeModel).click();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, removeBtn);
        $(removeBtn).click();
        commonMethods.waitForElement(driver, removeMsg, 80);
    }

    public boolean verifySpatialName(String modelId) {
        By spatialName = By.xpath("//*[@class='md-virtual-repeat-container md-orient-vertical']//*[text()='" + modelId + "']");
        commonMethods.waitForElementExplicitly(6000);
        commonMethods.waitForElement(driver, navMode, 60);
        return $(spatialName).isDisplayed();
    }
}
