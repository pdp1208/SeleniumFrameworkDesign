package com.oracle.babylon.pages.Fields;

import com.codeborne.selenide.Condition;
import com.github.javafaker.Faker;
import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;

import java.util.Map;

import static com.codeborne.selenide.Selenide.*;
import static com.codeborne.selenide.Condition.*;


public class FieldIssuePage extends Navigator {
    private By areasDropDown = By.xpath("//div[contains(@class,'dropdown open')]");
    private By closeOptionInAreaMenu = By.xpath("//ul[@class='dropdown-menu']//div[@class='close-btn ng-binding']");
    private By manageSubscriptionPopupCloseBtn = By.xpath("//*[contains(@class,'cross')]");
    private By addIssueBtn = By.xpath("//button[contains(@class, 'add-issue')]");
    private By loader = By.xpath("//*[contains(@class,'uiLoadingBlocker')]");
    private By issueTypeSelector = By.xpath("//div[@class='field issue-type']");
    private By issueTypeSearch = By.xpath("//div[contains(@class,'issuetype-field-search')]/following-sibling::input[@type='search']");
    private By activeElementInDropDown = By.xpath("//div[@class='ui-select-choices-row ng-scope active']");
    private By descritption = By.xpath("//label[(text()='Description')]/following-sibling::div/textarea");
    private By assigneeSelector = By.xpath("//div[contains(@class,'assignee-field-search')]");
    private By assigneeSearch = By.xpath("//div[contains(@class,'assignee-field-search')]/following-sibling::input[@type='search']");
    private By calendarBtn = By.xpath("//div[contains(@datepicker-options, 'NewIssue')]//div[@class='input-group date-picker']//button");
    private By todaysDate = By.xpath("//td[@ng-repeat='dt in row']//button[contains(@class, 'active')]");
    private By save = By.xpath("//div[contains(@class,'new-issue')]//button[contains(@ng-click,'NewIssueCtrl.save()')]");
    private By rootArea = By.xpath("//div[contains(@class,'fm-areas-panel-header')]//div[contains(@class,'selected-areas')]//li[1]");
    private By subarea = By.xpath("//*[contains(@class,'fm-areas-panel')]//*[contains(@class,'dropdown-btn-group')]");
    private By successMessage = By.xpath("//div[contains(@class,'success')]/descendant::div[(text()='Issue captured')]");
    private By dateInput = By.xpath("//input[contains(@class,'date-input')]");
    private By issueId = By.xpath("//*[contains(@class,'issue-metadata')]//span[contains(@class,'issue-number')]");
    private By searchInput = By.xpath("//input[contains(@class,'search-input')]");
    private By searchButton = By.xpath("//input[contains(@class,'search-input')]/parent::div/following-sibling::button");
    private By statusDropDown = By.xpath("//div[contains(@class,'status-selector')]");
    private By pageLoader = By.xpath("//*[contains(@class,'auiLoaderOverlay')]");
    private String areaSelector = "//ul[@class='dropdown-menu']//a[@data-areaid and text()='AREA_NAME']";
    private String statusLocator = "//div[contains(@class,'status-selector')]//li//strong[contains(text(),'STATUS')]";
    private By infoBox = By.xpath("//*[contains(@class,'cross')]");
    private By chkBoxSelectAll = By.xpath("//input[@aria-label='Select alll custom fields']");
    private By removeBtn = By.xpath("//button[text()='Remove']");
    private By fieldIssueTypes = By.xpath("//div[contains(text(),'Issue types')]");
    private By issues = By.xpath("//span[text()='Issues']");
    private By issueTypesHeader = By.xpath("//h1[contains(text(),'Issue types')]");
    private By issueTypeInput = By.xpath("//input[@id='add-more-issue-types']");
    private By issueAddBtn = By.xpath("//button[text()='Add']");
    private By issueTypeTxt = By.xpath("//p[text()='Select fields from the left to add to this issue type.']");

    /**
     * Method to navigate to field page
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Field", "Issues");
        verifyAndSwitchFrame();
        if($(manageSubscriptionPopupCloseBtn).isDisplayed()) {
            $(manageSubscriptionPopupCloseBtn).click();
        }
    }

    /**
     * Method to select area.
     *
     * @param areasPath Path to the area.
     */
    public void navigateToAreaByPath(String areasPath) {
        // areasPath is like "Hotel VIP > Zeta Area > Level 1 > Apartment 1"
        String[] fieldAreas = areasPath.split(" > ");
        int startLevel = 1;
        if (fieldAreas[1].equalsIgnoreCase(fieldAreas[0])) startLevel = 2;
        if (fieldAreas[1].equalsIgnoreCase("Oracle")) startLevel = 2;
        for (int i = startLevel; i < fieldAreas.length; i++) {
            String nodeName = fieldAreas[i].trim();
            subareaByName(nodeName);
        }
        waitForLoaderToDisappear();
    }

    /**
     * Method to select subarea link.
     *
     * @param areaName Name of area to select.
     */
    public void subareaByName(String areaName) {
        $(By.xpath(areaSelector.replaceAll("AREA_NAME", areaName))).click();
    }

    /**
     * Method to close dropdown.
     *
     */
    public void closeDropDown(){
        if ($(closeOptionInAreaMenu).isDisplayed()) {
            $(closeOptionInAreaMenu).click();
        }
    }

    /**
     * Method to add new field issue.
     *
     * @param issueDetails Details of the issue to be added.
     */
    public void addIssue(Map<String, String> issueDetails){
        $(addIssueBtn).waitUntil(appears,6000).click();
        if($(loader).isDisplayed()) {
            $(loader).waitUntil(disappears, 10000);
        }
        selectIssueType(issueDetails.get("Issue type"));
        setIssueDescription(issueDetails.get("Description"));
        setAssignee(issueDetails.get("Assign to"));
        selectDueDate(issueDetails.get("Due date"));
        saveIssueDetails();
        verifySuccessMessage();
    }

    /**
     * Method to select issue type.
     *
     * @param type Type of the issue to be added.
     */
    public void selectIssueType(String type){
        $(issueTypeSelector).click();
        $(issueTypeSearch).setValue(type);
        $(activeElementInDropDown).waitUntil(appears,5000).click();
    }

    /**
     * Method to add description.
     *
     * @param description Description of the issue to be added.
     */
    public void setIssueDescription(String description){
        $(descritption).setValue(description);
    }

    /**
     * Method to set assignee.
     *
     * @param assignee name of the assignee.
     */
    public void setAssignee(String assignee){
        $(assigneeSelector).click();
        $(assigneeSearch).setValue(assignee);
        $(activeElementInDropDown).waitUntil(appears,5000).click();
    }

    /**
     * Method to select due date for the issue.
     *
     * @param dueDate Due date of the issue to be added.
     */
    public void selectDueDate(String dueDate){
        switch(dueDate){
            case "Today":
                $(calendarBtn).click();
                $(todaysDate).click();
                break;
            default:
                $(dateInput).sendKeys(dueDate);
                break;
        }
    }

    /**
     * Method to save issue details.
     */
    public void saveIssueDetails(){
        $(save).click();
    }

    /**
     * Method to select root area.
     */
    public void selectRootArea(){
        verifyAndSwitchFrame();
        try{
            commonMethods.waitForElement(driver, infoBox, 5);
            $(infoBox).click();
        } catch(TimeoutException e){
            //ignore
        }
        $(rootArea).waitUntil(appears, 6000).click();
    }

    /**
     * Method to select subarea link.
     */
    public void selectSubArea(){
        waitForLoaderToDisappear();
        $(subarea).click();
        $(areasDropDown).shouldBe(visible);
    }

    /**
     * Method to verify success message.
     */
    public void verifySuccessMessage(){
        $(successMessage).waitUntil(appears, 10000);
        $(successMessage).waitUntil(disappears, 10000);
    }

    /**
     * Method to search issue with descritpion.
     *
     * @param descritpion description for the issue.
     */
    public String searchIssue(String descritpion){
        $(searchInput).waitUntil(appears, 10000).setValue(descritpion);
        $(searchButton).click();
        waitForLoaderToDisappear();
        return $(issueId).waitUntil(appears,5000).getText();
    }

    /**
     * Method to update the status of issue.
     *
     * @param status status of the issue.
     */
    public void updateIssue(String status){
        $(statusDropDown).waitUntil(appears,3000).click();
        $(By.xpath(statusLocator.replaceAll("STATUS", status))).waitUntil(appears, 4000).click();
    }

    /**
     * Method to wait until loader disappears.
     */
    public void waitForLoaderToDisappear(){
        try{
            commonMethods.waitForElement(driver, pageLoader, 5);
            $(pageLoader).waitUntil(disappears, 15000);
        } catch(TimeoutException e){
            //ignore
        }
    }

    /**
     * Function to navigate to Field Issue Types.
     */
    public void navigateToFieldIssueTypes(){
        commonMethods.waitForElement(driver, issues, 60);
        commonMethods.getElementInViewAndUp(issues);
        $(issues).click();
        commonMethods.clickLinkToChange(driver, issues, fieldIssueTypes);
        switchProjectSettingsFrame();
        commonMethods.waitForElement(driver, issueTypesHeader, 60);
    }

    /**
     * Function to create new/Add Issue Type
     */
    public String addIssueType(){
        Faker faker = new Faker();
        String issueTypeName = faker.address().firstName() + faker.number().digits(3);
        $(issueTypeInput).sendKeys(issueTypeName);
        $(issueAddBtn).click();
        return issueTypeName;
    }

    /**
     * Function to edit Issue Type
     */
    public void editIssue(String issueTypeName){
        commonMethods.waitForElement(driver, By.xpath("//td[@fm-display-value='" + issueTypeName + "']/../td[2]/a"), 60);
        $(By.xpath("//td[@fm-display-value='" + issueTypeName + "']/../td[2]/a")).click();
        commonMethods.waitForElement(driver, By.xpath("//span[text()='" + issueTypeName + "']"), 60);
    }

    /**
     * Function to delete an Issue Type
     */
    public void deleteIssueType(String issueTypeName){
        commonMethods.waitForElement(driver, By.xpath("//td[@fm-display-value='" + issueTypeName + "']/../td[3]"), 60);
        $(By.xpath("//td[@fm-display-value='" + issueTypeName + "']/../td[3]")).click();
        commonMethods.waitForElementExplicitly(2000);
        Assert.assertFalse($(By.xpath("//td[@fm-display-value='" + issueTypeName + "']/../td[3]")).isDisplayed());
    }

    /**
     * Function to add project field to issue type applied fields
     */
    public void associateProjectField(String projectField){
        By element = By.xpath("//div[text()='" + projectField +"']//..//div[@class='add-button']");
        commonMethods.waitForElement(driver, element, 45);
        $(element).click();
    }

    /**
     * Function to remove all project fields from Issue Type applied fields
     */
    public void removeAllProjectFields() {
        commonMethods.getElementInViewAndUp(chkBoxSelectAll);
        $(chkBoxSelectAll).click();
        $(removeBtn).click();
        commonMethods.waitForElement(driver, issueTypeTxt, 15);
    }

}