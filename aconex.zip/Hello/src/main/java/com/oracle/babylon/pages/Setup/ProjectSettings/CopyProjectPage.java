package com.oracle.babylon.pages.Setup.ProjectSettings;

import com.github.javafaker.Faker;
import com.oracle.babylon.pages.Setup.ProjectSettingsPage;
import org.junit.Assert;
import org.openqa.selenium.By;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static com.codeborne.selenide.Selenide.$;

public class CopyProjectPage extends ProjectSettingsPage {
    private By msg1 = By.xpath("//div[@class='message check']//div[text()='Project settings and preferences will be copied to the new project This may take a while.']");
    private By msg2 = By.xpath("//div[text()=' Please note: Users, documents & mail items will not be copied.']");
    private By continueBtn = By.xpath("//button[@title='Continue']");
    private By cancelBtn = By.xpath("//button[contains(text(),'Copy')]//following-sibling::button[contains(text(),'Cancel')]");
    private By oldCancelBtn = By.xpath("//button[@title='Cancel']");
    private By copyBtn = By.xpath("//button[@id='btnCopy']");
    private By projectName = By.xpath("//input[@name='ProjectName']");
    private By projectShortName = By.xpath("//input[@name='ProjectShortName']");
    private By projectCode = By.xpath("//input[@name='ProjectCode']");
    private By projectType = By.xpath("//input[@name='ProjectType']");
    private By registerType = By.xpath("//select[@id='RegisterType']");
    private By projectStartDate = By.xpath("//input[@name='ProjectStartDate_da']");
    private By projectStopDate = By.xpath("//input[@name='ProjectStopDate_da']");
    private By newProjDetailsHeader = By.xpath("//h4[text()='New Project Details']");
    private By estimateCompleteDate = By.xpath("//input[@id='projectCompletionDate']");
    private By currencyTxt = By.xpath("//input[@id='currency']");
    private By projectVal = By.xpath("//input[@id='projectValue']");
    private By nextBtn = By.xpath("//button[contains(text(),'Next')]");
    private By copyBtnFooter = By.xpath("//button[contains(text(),'Copy')]");
    private By projectNameLbl = By.xpath("//label[contains(text(),'Project Name')]");
    private By projectShortNameLbl = By.xpath("//label[contains(text(),'Project Short Name')]");
    private By projectCodeLbl = By.xpath("//label[contains(text(),'Project Code')]");
    private By projectTypeLbl = By.xpath("//label[contains(text(),'Project Type')]");
    private By primaryRegTypeLbl = By.xpath("//label[contains(text(),'Primary Register Type')]");
    private By startDateLbl = By.xpath("//label[contains(text(),'Project Start Date')]");
    private By estCompletionDateLbl = By.xpath("//label[contains(text(),'Estimated Completion Date')]");
    private By projectNameId = By.xpath("//input[@id='projectName']");
    private By projectShortNameId = By.xpath("//input[@id='projectShortName']");

    /**
     * Function to verify copy button present
     */
    public boolean verifyCopyBtn() {
        return $(copyBtn).isDisplayed();
    }

    /**
     * Function to click copy button
     */
    public void clickCopyBtn() {
        $(copyBtn).click();
    }

    /**
     * Function to click continue button
     */
    public void clickContinueBtn() {
        $(continueBtn).click();
    }

    /**
     * Function to verify copy Popup details
     */
    public void verifyCopyPopUpDetails() {
        commonMethods.waitForElement(driver,msg1,30);
        Assert.assertTrue($(msg1).isDisplayed());
        Assert.assertTrue($(msg2).isDisplayed());
        Assert.assertTrue("Continue btn is displayed", $(continueBtn).isDisplayed());
        if($(cancelBtn).isDisplayed()) {
            System.out.println("Cancel button is displayed");
        } else if($(oldCancelBtn).isDisplayed()){
            System.out.println("Legacy cancel button was displayed");
        }
    }

    /**
     * Function to verify new project details
     */
    public void verifyNewProjectDetails() {
        Assert.assertTrue("The project name is displayed", $(projectName).isDisplayed());
        Assert.assertTrue("The project short name is displayed", $(projectShortName).isDisplayed());
        Assert.assertTrue("The project code is displayed", $(projectCode).isDisplayed());
        Assert.assertTrue("Register type is displayed", $(registerType).isDisplayed());
        Assert.assertTrue("Project start date is displayed", $(projectStartDate).isDisplayed());
        Assert.assertTrue("Project stop date is displayed", $(projectStopDate).isDisplayed());
        verifyCopyBtn();
    }

    /**
     * Function to get the header of the pop window displayed while clicking the
     */
    public boolean getNewProjPopTitle() {
        commonMethods.waitForElementExplicitly(5000);
        return $(newProjDetailsHeader).isDisplayed();
    }

    /**
     * Function to enter the estimation complete date
     */
    public void enterEstimateCompleteDate() {
        $(estimateCompleteDate).scrollTo();
        commonMethods.waitForElementExplicitly(2000);
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        Date tomorrow = calendar.getTime();
        DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
        formatter.format(tomorrow);
        commonMethods.enterTextValue(estimateCompleteDate, formatter.format(tomorrow));
        commonMethods.waitForElementExplicitly(2000);
        $(estimateCompleteDate).click();
        }

    /**
     * Function to enter the currency
     */
    public void enterCurrency() {
        commonMethods.waitForElement(driver,currencyTxt,30);
        $(currencyTxt).click();
        commonMethods.enterTextValue(currencyTxt,"Dollar");
    }

    /**
     * Function to enter the project value
     */
    public void enterProjVal() {
        commonMethods.waitForElement(driver,projectVal,30);
        $(projectVal).click();
        commonMethods.enterTextValue(projectVal,"30000");
    }


    /**
     * Function to click on the Next button
     */
    public void clickNextBtn() {
        commonMethods.waitForElement(driver,nextBtn,30);
        $(nextBtn).click();
    }

    /**
     * Function to click on the copy button in the footer of the poup
     */
    public void clickCopyBtnFooter() {
        commonMethods.waitForElement(driver,copyBtnFooter,30);
        $(copyBtnFooter).click();
    }

    /**
     * Method to verify if the labels and the input fields are present
     */
    public void verifyFields() {
        commonMethods.waitForElement(driver, projectNameLbl);
        Assert.assertTrue($(projectNameLbl).isDisplayed());
        Assert.assertTrue($(projectShortNameLbl).isDisplayed());
        Assert.assertTrue($(projectCodeLbl).isDisplayed());
        Assert.assertTrue($(projectTypeLbl).isDisplayed());
        Assert.assertTrue($(primaryRegTypeLbl).isDisplayed());
        Assert.assertTrue($(estCompletionDateLbl).isDisplayed());
        Assert.assertTrue($(startDateLbl).isDisplayed());
        Assert.assertTrue($(projectName).isDisplayed());
        Assert.assertTrue($(projectShortName).isDisplayed());
        Assert.assertTrue($(projectCode).isDisplayed());
        Assert.assertTrue($(projectType).isDisplayed());
        Assert.assertTrue($(registerType).isDisplayed());
        Assert.assertTrue($(estimateCompleteDate).isDisplayed());
        Assert.assertTrue($(projectStartDate).isDisplayed());
    }

    /**
     * Method to verify the buttons in the screen
     */
    public void verifyBtn(){
        enterEstimateCompleteDate();
        clickNextBtn();
        Assert.assertTrue($(copyBtnFooter).isDisplayed());
        Assert.assertTrue($(cancelBtn).isDisplayed());
    }

    /**
     * Method to create the project name and give it to the newly created project
     * @return
     */
    public String enterProjectName() {
        Faker faker = new Faker();
        String projectName = faker.name().firstName() + faker.number().digit();
        $(projectNameId).clear();
        $(projectNameId).sendKeys(projectName);
        $(projectShortNameId).clear();
        $(projectShortNameId).sendKeys(projectName);
        return projectName;
    }
}