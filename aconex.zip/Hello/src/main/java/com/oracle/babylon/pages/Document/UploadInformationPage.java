package com.oracle.babylon.pages.Document;

import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;

import static com.codeborne.selenide.Selenide.*;

public class UploadInformationPage extends Navigator {

    private By hdrUploadInformation = By.xpath("//h1[contains(text(),'Upload Information')]");
    private By txtboxProfileName = By.xpath("//input[@name='ImportName']");
    private By txtboxDescription = By.xpath("//input[@name='ImportDescription']");
    private By radiobtnOrganization = By.xpath("//table[@id='profileDetails']//tbody/tr[3]/td[@class='contentcell']/label[1]");
    private By radiobtnProject = By.xpath("//table[@id='profileDetails']//tbody/tr[3]/td[@class='contentcell']/label[2]");
    private By chkboxDefaultDocValue = By.xpath("//input[@name='UseDocumentDefaults']");
    private By chkboxExtractDocFileName = By.xpath("//input[@name='UseFilenameAsDocId']");
    private By radiobtnSystemRuleset = By.xpath("(//div[@class='filenameRuleSelection']/label/input[@name='FilenameRule'])[1]");
    private By radiobtnCustomRuleset = By.xpath("(//div[@class='filenameRuleSelection']/label/input[@name='FilenameRule'])[2]");
    private By btnSave = By.xpath("//div[contains(text(),'Save')]");
    private By btnBack = By.xpath("//button[@id='btnBack']");
    private By lblDefaultDocValues = By.xpath("//td[contains(text(),'Default Document Values')]");
    private By lblMapFieldValues = By.xpath("//td[contains(text(),'Map field values to file paths')]");
    private By btnRemoveField = By.xpath("//div[@class='auiIcon remove close']");
    private By sltExtractField = By.xpath("//acx-extract-metadata//li//select[contains(@name,'extractMetadata.fieldName')]");
    private By sltExtractFieldOptions = By.xpath("(//acx-extract-metadata//li//select[contains(@name,'extractMetadata.fieldName')])[1]/option");
    private By sltExtractSeparator = By.xpath("//acx-extract-metadata//li//select[contains(@name,'extractMetadata.separator')]");
    private By sltExtractSeparatorOptions = By.xpath("(//acx-extract-metadata//li//select[contains(@name,'extractMetadata.separator')])[1]/option");
    private By txtboxFixedLength = By.xpath("//acx-extract-metadata//li//input[@id='fixedLength']");
    private By chkBoxUseInDocNum = By.xpath("//acx-extract-metadata//li//input[contains(@class,'uiField-input docNumber')]");
    private By createFileUpload = By.xpath("//*[contains(text(),'Create Upload Profile')]");
    private By inputProfileName = By.xpath("//input[@name='ImportName']");
    private By profileDescription = By.xpath("//input[@name='ImportDescription']");
    private By docTypeSelect = By.xpath("//select[@id='doctype_01']");
    private By selectUploadProfile = By.xpath("//select[@name='documentImportDefaultsId']");
    private By oldEditProfile = By.xpath("//a[text()='View / Edit Profile']");
    private By extractZips = By.xpath("//input[@name='ExpandZips']");

    /**
     * Method to navigate to Document and verify for the title of the page
     */
    public void verifyPage() {
        commonMethods.waitForElement(driver, hdrUploadInformation, 60);
        Assert.assertTrue($(hdrUploadInformation).isDisplayed());
    }

    /**
     * Method to verify fields in Upload Information page
     */
    public void verifyUploadInformationPage(String profileName) {
        Assert.assertTrue($(txtboxProfileName).isDisplayed());
        Assert.assertEquals(profileName, $(txtboxProfileName).getValue());
        Assert.assertTrue($(txtboxDescription).isDisplayed());
        Assert.assertTrue($(chkboxDefaultDocValue).isDisplayed());
        Assert.assertTrue($(chkboxExtractDocFileName).isDisplayed());
        Assert.assertTrue($(radiobtnSystemRuleset).isDisplayed());
        Assert.assertTrue($(radiobtnCustomRuleset).isDisplayed());
        Assert.assertTrue($(btnSave).isDisplayed());
        Assert.assertTrue($(btnBack).isDisplayed());
        Assert.assertTrue($(lblDefaultDocValues).isDisplayed());
        Assert.assertTrue($(lblMapFieldValues).isDisplayed());
    }

    /**
     * Method to verify profile name
     */
    public String verifyProfileName() {
        commonMethods.waitForElement(driver, txtboxProfileName);
        return $(txtboxProfileName).getValue();
    }

    /**
     * Method to verify new upload information page from Multiple file upload window
     */
    public void verifyNewUploadInfoPage() {
        Assert.assertTrue($(txtboxProfileName).isDisplayed());
        Assert.assertTrue($(txtboxDescription).isDisplayed());
        Assert.assertTrue($(chkboxDefaultDocValue).isDisplayed());
        Assert.assertTrue($(chkboxExtractDocFileName).isDisplayed());
        Assert.assertTrue($(radiobtnSystemRuleset).isDisplayed());
        Assert.assertTrue($(radiobtnCustomRuleset).isDisplayed());
        Assert.assertTrue($(btnSave).isDisplayed());
        Assert.assertTrue($(btnBack).isDisplayed());
        Assert.assertTrue($(lblDefaultDocValues).isDisplayed());
        Assert.assertTrue($(lblMapFieldValues).isDisplayed());
    }

    /**
     * Method to save profile
     */
    public void saveProfile() {
        $(btnSave).click();
    }

    /**
     * Method to select Extract Document type radio button
     */
    public void selectExtractDocType(String type) {
        if (type.equalsIgnoreCase("system ruleset") && !$(radiobtnSystemRuleset).isSelected())
            $(radiobtnSystemRuleset).click();
        else if (type.equalsIgnoreCase("custom ruleset") && !$(radiobtnCustomRuleset).isSelected())
            $(radiobtnCustomRuleset).click();
    }

    /**
     * Method to fill custom rule set fields
     */
    public void fillCustomRuleSet(String field, String separator, String length, String useInDocNum) {
        selectExtractField(field);
        selectExtractSeparator(separator);
        if (!length.equalsIgnoreCase(""))
            enterFixedLength(length);
        if(!useInDocNum.equalsIgnoreCase("") && !field.equalsIgnoreCase("document no"))
            selectUseInDocField(Boolean.parseBoolean(useInDocNum));
    }

    /**
     * Method to Delete custom ruleset fields
     */
    public void deleteAllCustomRuleset() {
        commonMethods.waitForElementExplicitly(2000);
        List<WebElement> elements = new ArrayList<>($$(btnRemoveField));
        for(int i=0; i < elements.size() - 1; i++) {
            $(elements.get(0)).click();
        }
    }

    /**
     * Method to select custom ruleset field name
     */
    public void selectExtractField(String fieldName) {
        List<WebElement> elements = new ArrayList<>($$(sltExtractField));
        $(elements.get(elements.size() - 1)).selectOptionContainingText(fieldName);
    }

    /**
     * Method to select custom ruleset separator name
     */
    public void selectExtractSeparator(String separator) {
        List<WebElement> elements = new ArrayList<>($$(sltExtractSeparator));
        $(elements.get(elements.size() - 1)).selectOptionContainingText(separator);
    }

    /**
     * Method to enter fixed length
     */
    public void enterFixedLength(String length) {
        List<WebElement> elements = new ArrayList<>($$(txtboxFixedLength));
        $(elements.get(elements.size() - 1)).clear();
        commonMethods.waitForElementExplicitly(500);
        $(elements.get(elements.size() - 1)).sendKeys(length);
    }

    /**
     * Method to select custom ruleset separator name
     */
    public void selectUseInDocField(boolean value) {
        List<WebElement> elements = new ArrayList<>($$(chkBoxUseInDocNum));
        if(elements.get(elements.size() - 1).isEnabled())
            $(elements.get(elements.size() - 1)).setSelected(value);
    }

    /**
     * Method to check or uncheck extract doc values checkbox
     */
    public void selectExtractDocValuesChkbox(String option) {
        $(chkboxExtractDocFileName).setSelected(option.equalsIgnoreCase("check"));
    }

    /**
     * Method to created Random profile
     */
    public void createRandomProfile(String shareWith, String ruleSet) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver,txtboxProfileName, 60);
        $(txtboxProfileName).sendKeys(commonMethods.getRandomString(10));
        $(txtboxDescription).sendKeys(faker.book().title());
        selectShareWith(shareWith);
        selectExtractDocType(ruleSet);
    }

    /**
     * Method to created Random profile
     */
    public void selectShareWith(String shareWith) {
        if (shareWith.equalsIgnoreCase("organization")) {
            if ($(radiobtnOrganization).exists())
                $(radiobtnOrganization).click();
        } else if (shareWith.equalsIgnoreCase("project")) {
            if ($(radiobtnProject).exists())
                $(radiobtnProject).click();
        }
    }

    /**
     * Method to get extract field dropdown values
     */
    public List<String> returnExtractFields() {
        List<WebElement> elements = new ArrayList<>($$(sltExtractFieldOptions));
        List<String> values = new ArrayList<>();
        for(WebElement element:elements)
            values.add(element.getText());
        return values;
    }

    /**
     * Method to get extract separator dropdown values
     */
    public List<String> returnExtractSeparators() {
        List<WebElement> elements = new ArrayList<>($$(sltExtractSeparatorOptions));
        List<String> values = new ArrayList<>();
        for(WebElement element:elements)
            values.add(element.getText());
        return values;
    }

    /**
     * Function create upload profile
     */
    public void fillUploadProfile(String profileName,String docType) {
        commonMethods.waitForElement(driver, createFileUpload, 60);
        $(createFileUpload).scrollTo();
        $(createFileUpload).click();
        $(inputProfileName).sendKeys(profileName);
        $(profileDescription).sendKeys(profileName);
        if(!docType.isEmpty()) {
            $(docTypeSelect).scrollTo();
            $(docTypeSelect).selectOption(docType);
            $(saveBtn).click();
        }
    }

    /**
     * Function to edit the profile page of the old doc
     */
    public void editProfileOld(String profileName,String docType){
        commonMethods.waitForElement(driver, selectUploadProfile);
        $(selectUploadProfile).click();
        By profile = By.xpath("//select[@name='documentImportDefaultsId']//option[text()='"+profileName+"']");
        commonMethods.waitForElement(driver, profile, 60);
        $(profile).click();
        $(oldEditProfile).click();
        $(docTypeSelect).scrollTo();
        commonMethods.enterDropdownValue(docTypeSelect, docType);
        $(saveBtn).click();
    }

    /**
     * Function to select the doctype option in profile page
     */
    public void docTypeSelect(String docType){
        commonMethods.waitForElement(driver,docTypeSelect,30);
        commonMethods.getElementInViewAndUp(docTypeSelect);
        commonMethods.waitForElementExplicitly(1000);
        $(docTypeSelect).scrollTo();
        $(docTypeSelect).selectOption(docType);
    }

    /**
     * Function to select the extract zip file option in profile page
     */
    public void selectExtractZip(boolean value) {
        if($(extractZips).isDisplayed())
            $(extractZips).setSelected(value);
    }

    /**
     * Function to edit the profile page of the old doc
     */
    public void editOldUploadProfile(String profileName){
        commonMethods.waitForElement(driver, selectUploadProfile);
        $(selectUploadProfile).click();
        By profile = By.xpath("//select[@name='documentImportDefaultsId']//option[text()='"+profileName+"']");
        commonMethods.waitForElement(driver, profile, 60);
        $(profile).click();
        $(oldEditProfile).click();
    }

    /**
     * Method to created a named profile
     */
    public void createNewProfile(String profileName, String shareWith, String ruleSet) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver,txtboxProfileName, 60);
        $(txtboxProfileName).sendKeys(profileName);
        $(txtboxDescription).sendKeys(faker.book().title());
        selectShareWith(shareWith);
        selectExtractDocType(ruleSet);
    }

}

