package com.oracle.babylon.Utils.helper;


import com.oracle.babylon.Utils.setup.FakeData;
import com.oracle.babylon.Utils.setup.dataStore.DocumentTableConverter;
import com.oracle.babylon.Utils.setup.dataStore.pojo.Document;
import com.oracle.babylon.Utils.setup.utils.ConfigFileReader;
import io.cucumber.datatable.DataTable;
import io.restassured.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;
import org.junit.Assert;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class DocumentsAPI extends APIHelper {

    ConfigFileReader configFileReader = new ConfigFileReader();
    protected Map<String, Map<String, Object>> jsonMapOfMap = null;
    protected Map<String, Object> userMap = null;
    protected String userDataPath = configFileReader.getUserDataPath();
    protected String directoryPath = configFileReader.getTestDataPath();
    protected FakeData fakeData = new FakeData();
    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    SchemaHelperPage schemaHelperPage = new SchemaHelperPage();
    DirectoryAPI directoryAPI = new DirectoryAPI();

    /**
     * Method to upload/register a document through api using httpclient library
     * Document will show up in Document register
     *
     * @param userId    for authentication
     * @param dataTable request body data
     * @param projectId required in the url
     */
    public Map<String, String> registerDocumentAPI(String userId, DataTable dataTable, String projectId) {
        HttpResponse response;
        Boolean projectFields = false;
        String responseString = "", docId;
        Map<String, String> documentNames = new LinkedHashMap<>();
        List<Map<String, String>> documentDataTable = dataTable.asMaps(String.class, String.class);
        //The data is taken from userData.json file and we search for the project in admin tool
        Map<String, Document> documentData = new DocumentTableConverter().createDocumentData(userId, dataTable, projectId);
        String basicAuth = basicAuthCredentialsProvider(userId);

        //Collecting the data for files to be uploaded
        List<String> fileNames = new ArrayList<>();
        List<String> documentType = new ArrayList<>();
        List<String> documentStatus = new ArrayList<>();
        for (Map<Object, Object> documentHashMap : dataTable.asMaps(String.class, String.class)) {
            fileNames.add(documentHashMap.get("FileToUpload").toString());
            //If we need document type to be passed from the feature file
            if (documentHashMap.containsKey("Type")) {
                documentType.add(documentHashMap.get("Type").toString());
            } else {
                documentType.add(null);
            }
            if (documentHashMap.containsKey("Status")) {
                documentStatus.add(documentHashMap.get("Status").toString());
            } else {
                documentStatus.add(null);
            }

        }
        Iterator<Map.Entry<String, Document>> docDatawithName = documentData.entrySet().iterator();
        for (int i = 0; i < documentData.size(); i++) {
            Map.Entry<String, Document> entry = docDatawithName.next();
            Document document = entry.getValue();
            document = setMandatoryFields(document, userId, projectId, documentType.get(i), documentStatus.get(i));

            //getting project fields data
            Map<String, String> additionalFields = addAdditionalDocFields(dataTable, i, projectId);

            //Creating the request body template
            StringBuilder documentRequestBody = new StringBuilder(CommonMethods.convertMaptoJsonString(document));

            //Updating the request body according to the required template
            for (String fields : documentDataTable.get(i).keySet())
                if (fields.startsWith("label_")) {
                    projectFields = true;
                    break;
                }
            //Updating the request body according to the required template
            String requestBodyXML;
            if (projectFields) {
                documentRequestBody.insert(documentRequestBody.length() - 1, "," + CommonMethods.convertMaptoJsonString(additionalFields).replace("{", "").replace("}", ""));
                documentRequestBody.insert(0, "{ \"document\":");
                documentRequestBody.append("}");
                requestBodyXML = commonMethods.convertJsonStringToXMLString(documentRequestBody.toString());
                requestBodyXML = requestBodyXML.split("</document>")[0] + addAdditionMultiField(dataTable, i, projectId) + "</document>";
            } else {
                documentRequestBody.insert(0, "{ \"document\":");
                documentRequestBody.append("}");
                requestBodyXML = commonMethods.convertJsonStringToXMLString(documentRequestBody.toString());
            }
            if (document.getHasFile().equals("true")) {
                requestBodyXML = "--myboundary\n\n" + requestBodyXML + "\n--myboundary\n"
                        + "\nX-Filename: " + fileNames.get(i)
                        + "\n\n" + commonMethods.getEncodedBase64(fileNames.get(i))
                        + "\n\n--myboundary--";
            } else {

                requestBodyXML = "--myboundary\n\n" + requestBodyXML + "\n--myboundary";

            }
            requestBodyXML = capitalizeXMLTags(requestBodyXML, "<");
            requestBodyXML = capitalizeXMLTags(requestBodyXML, "</");
            if (requestBodyXML.contains("AccessList")) {
                requestBodyXML = fixAccessList(requestBodyXML);
            }
            //Forming the url
            String url = ConfigFileReader.getApplicationUrl() + "api/projects/" + projectId + "/register";
            response = postRequest(url, basicAuth, "multipart/mixed; boundary=\"myboundary\"", requestBodyXML);
            try {
                HttpEntity entity = response.getEntity();
                responseString = EntityUtils.toString(entity);
                // Read the contents of an entity and return it as a String. Needed for debugging
                System.out.println(responseString);
            } catch (Exception e) {
                System.out.println("Coming inside");
                try {
                    response = postRequest(url, basicAuth, "multipart/mixed; boundary=\"myboundary\"", requestBodyXML);
                    HttpEntity entity1 = response.getEntity();
                    responseString = EntityUtils.toString(entity1);
                    System.out.println(responseString);
                } catch (Exception e1) {
                    System.out.println(response.getEntity());
                }
            }
            Assert.assertEquals(200, response.getStatusLine().getStatusCode());
            if (response.getStatusLine().getStatusCode() == 200) {
                docId = schemaHelperPage.getValueFromResponse(responseString, "RegisterDocumentResult", "RegisterDocument");
                documentNames.put(document.getDocumentNumber(), docId);
            }
        }
        return documentNames;
    }

    /**
     * Method to add multiple project fields for a document
     */
    private String addAdditionMultiField(DataTable dataTable, int counter, String projectId) {
        List<Map<String, String>> projectFieldData = dataTable.asMaps(String.class, String.class);
        List<String> headers = new ArrayList<>(projectFieldData.get(counter).keySet());
        StringBuilder multiField = new StringBuilder();
        String type = "";
        for (String header : headers) {
            if (header.startsWith("label_")) {
                if (commonMethods.getLabelType(header).equalsIgnoreCase("select list (multiple)")) {
                    List<String> values = Arrays.asList(projectFieldData.get(counter).get(header).split(","));
                    for (String value : values) {
                        if (value.startsWith("user")) type = commonMethods.getLabelName(header) + "_user";
                        else type = commonMethods.getLabelName(header) + "_multiSelect";
                        break;
                    }
                    multiField.append(",").append(getProjectFieldData(type, values, projectId));
                }
            }
        }
        return multiField.toString();
    }

    /**
     * Method to convert multiple project fields in a xml format
     */
    public String getProjectFieldData(String key, List<String> values, String projectId) {
        StringBuilder multiField = new StringBuilder();
        for (String value : values) {
            if (value.startsWith("user")) {
                values = directoryAPI.searchProjectDirectory(value, projectId);
                value = values.get(0);
            }
            multiField.append("<").append(key).append(">").append(value).append("</").append(key).append(">");
        }
        return multiField.toString();
    }

    /**
     * Method to upload temporary files through api using httpclient library
     * Document will show up in Temporary files
     *
     * @param userId    for authentication
     * @param projectId required in the url
     */
    public void addTemporaryFile(String userId, String projectId) {
        List<String> fileNames = commonMethods.getFileNames(directoryPath);
        HttpResponse response;
        String basicAuth = basicAuthCredentialsProvider(userId);

        for (int i = 0; i < 5; i++) {
            //getting project fields data
            Map<String, String> confidentialField = new HashMap<>();
            confidentialField.put("DocumentNumber", fakeData.getDocumentNumber().replace("\\", "").replace("/", ""));

            //Creating the request body template
            StringBuilder documentRequestBody = new StringBuilder(CommonMethods.convertMaptoJsonString(confidentialField));

            //Updating the request body according to the required template
            documentRequestBody.insert(0, "{ \"UnregisteredDocument\":");
            documentRequestBody.append("}");
            String requestBodyXML;
            requestBodyXML = "--myboundary\n\n" + commonMethods.convertJsonStringToXMLString(documentRequestBody.toString()) + "\n--myboundary\n"
                    + "\nContent-Disposition: attachment; filename= " + fileNames.get(i)
                    + "\n\n" + commonMethods.getEncodedBase64(fileNames.get(i))
                    + "\n\n--myboundary--";
            requestBodyXML = capitalizeXMLTags(requestBodyXML, "<");
            requestBodyXML = capitalizeXMLTags(requestBodyXML, "</");
            //Forming the url
            String url = ConfigFileReader.getApplicationUrl() + "api/projects/" + commonMethods.getProjectId(userId, projectId) + "/temporaryFile";
            response = postRequest(url, basicAuth, "multipart/mixed; boundary=\"myboundary\"", requestBodyXML);
            try {
                // Read the contents of an entity and return it as a String. Needed for debugging
                System.out.println(EntityUtils.toString(response.getEntity()));
            } catch (Exception e) {
                System.out.println("Coming inside");
                try {
                    response = postRequest(url, basicAuth, "multipart/mixed; boundary=\"myboundary\"", requestBodyXML);
                    System.out.println(EntityUtils.toString(response.getEntity()));
                } catch (Exception e1) {
                    System.out.println(response.getEntity());
                }
            }
            Assert.assertEquals(200, response.getStatusLine().getStatusCode());
        }
    }

    /**
     * Method to upload temporary files through api using httpclient library
     * Document will show up in Temporary files
     *
     * @param userId    for authentication
     * @param projectId required in the url
     */
    public List<String> addTemporaryFile(String userId, String projectId, DataTable dataTable) {
        HttpResponse response;
        List<String> documentNames = new ArrayList<>();
        Boolean projectFields = false;
        List<Map<String, String>> documentDataTable = dataTable.asMaps(String.class, String.class);
        //The data is taken from userData.json file and we search for the project in admin tool
        Map<String, Document> documentData = new DocumentTableConverter().createDocumentData(userId, dataTable, projectId);
        String basicAuth = basicAuthCredentialsProvider(userId);

        //Collecting the data for files to be uploaded
        List<String> fileNames = new ArrayList<>();
        List<String> documentType = new ArrayList<>();
        List<String> documentStatus = new ArrayList<>();
        for (Map<Object, Object> documentHashMap : dataTable.asMaps(String.class, String.class)) {
            fileNames.add(documentHashMap.get("FileToUpload").toString());
            //If we need document type to be passed from the feature file
            if (documentHashMap.containsKey("Type")) {
                documentType.add(documentHashMap.get("Type").toString());
            } else {
                documentType.add(null);
            }
            if (documentHashMap.containsKey("Status")) {
                documentStatus.add(documentHashMap.get("Status").toString());
            } else {
                documentStatus.add(null);
            }

        }
        Iterator<Map.Entry<String, Document>> docDatawithName = documentData.entrySet().iterator();
        for (int i = 0; i < documentData.size(); i++) {
            Map.Entry<String, Document> entry = docDatawithName.next();
            Document document = entry.getValue();
            document = setMandatoryFields(document, userId, projectId, documentType.get(i), documentStatus.get(i));

            //getting project fields data
            Map<String, String> additionalFields = addAdditionalDocFields(dataTable, i, projectId);

            //Creating the request body template
            StringBuilder documentRequestBody = new StringBuilder(CommonMethods.convertMaptoJsonString(document));

            //Updating the request body according to the required template
            for (String fields : documentDataTable.get(i).keySet())
                if (fields.startsWith("label_")) {
                    projectFields = true;
                    break;
                }
            //Updating the request body according to the required template
            String requestBodyXML;
            if (projectFields) {
                documentRequestBody.insert(documentRequestBody.length() - 1, "," + CommonMethods.convertMaptoJsonString(additionalFields).replace("{", "").replace("}", ""));
                documentRequestBody.insert(0, "{ \"UnregisteredDocument\":");
                documentRequestBody.append("}");
                requestBodyXML = commonMethods.convertJsonStringToXMLString(documentRequestBody.toString());
                requestBodyXML = requestBodyXML.split("</UnregisteredDocument>")[0] + addAdditionMultiField(dataTable, i, projectId) + "</UnregisteredDocument>";
            } else {
                documentRequestBody.insert(0, "{ \"UnregisteredDocument\":");
                documentRequestBody.append("}");
                requestBodyXML = commonMethods.convertJsonStringToXMLString(documentRequestBody.toString());
            }
                requestBodyXML = "--myboundary\n\n" + requestBodyXML + "\n--myboundary\n"
                        + "\nContent-Disposition: attachment; filename= " + fileNames.get(i)
                        + "\n\n" + commonMethods.getEncodedBase64(fileNames.get(i))
                        + "\n\n--myboundary--";
            requestBodyXML = capitalizeXMLTags(requestBodyXML, "<");
            requestBodyXML = capitalizeXMLTags(requestBodyXML, "</");
            //Forming the url
            String url = ConfigFileReader.getApplicationUrl() + "api/projects/" + projectId + "/temporaryFile";
            response = postRequest(url, basicAuth, "multipart/mixed; boundary=\"myboundary\"", requestBodyXML);
            try {
                // Read the contents of an entity and return it as a String. Needed for debugging
                System.out.println(EntityUtils.toString(response.getEntity()));
            } catch (Exception e) {
                System.out.println("Coming inside");
                try {
                    response = postRequest(url, basicAuth, "multipart/mixed; boundary=\"myboundary\"", requestBodyXML);
                    System.out.println(EntityUtils.toString(response.getEntity()));
                } catch (Exception e1) {
                    System.out.println(response.getEntity());
                }
            }
            Assert.assertEquals(200, response.getStatusLine().getStatusCode());
            documentNames.add(document.getDocumentNumber());
        }
        return documentNames;
    }

    /**
     * Method to supersede a document through api using httpclient library
     * Document will supersede and show up updated document in Document register
     *
     * @param userId    for authentication
     * @param dataTable request body data
     * @param projectId required in the url
     */
    public Map<String, String> supersedeDocument(String userId, DataTable dataTable, String projectId) {
        HttpResponse response;
        Boolean projectFields = false;
        String docId = "", responseString = "";
        Map<String, String> documentNames = new HashMap<>();
        List<Map<String, String>> documentTable = dataTable.asMaps(String.class, String.class);
        //The data is taken from userData.json file and we search for the project in admin tool
        List<Map<String, Document>> documentData = new DocumentTableConverter().getDocumentData(userId, dataTable, projectId);
        String basicAuth = basicAuthCredentialsProvider(userId);

        for (int i = 0; i < documentData.size(); i++) {
            Iterator<Map.Entry<String, Document>> docDatawithName = documentData.get(i).entrySet().iterator();
            Map.Entry<String, Document> entry = docDatawithName.next();
            Document document = entry.getValue();
            document = setMandatoryFields(document, userId, projectId);

            //getting project fields data
            Map<String, String> additionalFields = addAdditionalDocFields(dataTable, i, projectId);

            //Creating the request body template
            StringBuilder documentRequestBody = new StringBuilder(CommonMethods.convertMaptoJsonString(document));

            for (String fields : documentTable.get(i).keySet())
                if (fields.startsWith("label_")) {
                    projectFields = true;
                    break;
                }
            //Updating the request body according to the required template
            String requestBodyXML;
            if (projectFields) {
                documentRequestBody.insert(documentRequestBody.length() - 1, "," + CommonMethods.convertMaptoJsonString(additionalFields).replace("{", "").replace("}", ""));
                documentRequestBody.insert(0, "{ \"document\":");
                documentRequestBody.append("}");
                requestBodyXML = commonMethods.convertJsonStringToXMLString(documentRequestBody.toString());
                requestBodyXML = requestBodyXML.split("</document>")[0] + addAdditionMultiField(dataTable, i, projectId) + "</document>";
            } else {
                documentRequestBody.insert(0, "{ \"document\":");
                documentRequestBody.append("}");
                requestBodyXML = commonMethods.convertJsonStringToXMLString(documentRequestBody.toString());
            }
            requestBodyXML = "--myboundary\n\n" + requestBodyXML + "\n--myboundary\n";
            requestBodyXML = capitalizeXMLTags(requestBodyXML, "<");
            requestBodyXML = capitalizeXMLTags(requestBodyXML, "</");
            String url = ConfigFileReader.getApplicationUrl() + "api/projects/" + projectId + "/register/" + commonMethods.returnDocNumberInJson(entry.getKey(), "doc_id") + "/supersede";
            response = postRequest(url, basicAuth, "multipart/mixed; boundary=\"myboundary\"", requestBodyXML);
            try {
                HttpEntity entity = response.getEntity();
                responseString = EntityUtils.toString(entity);
                // Read the contents of an entity and return it as a String. Needed for debugging
                System.out.println(responseString);
            } catch (Exception e) {
                System.out.println("Coming inside");
                try {
                    response = postRequest(url, basicAuth, "multipart/mixed; boundary=\"myboundary\"", requestBodyXML);
                    HttpEntity entity1 = response.getEntity();
                    responseString = EntityUtils.toString(entity1);
                    System.out.println(responseString);
                } catch (Exception e1) {
                    System.out.println(response.getEntity());
                }
            }
            Assert.assertEquals(200, response.getStatusLine().getStatusCode());
            if (response.getStatusLine().getStatusCode() == 200) {
                docId = schemaHelperPage.getValueFromResponse(responseString, "RegisterDocumentResult", "RegisterDocument");
                documentNames.put(commonMethods.returnDocNumberInJson("document" + documentTable.get(i).get("serial_num")), docId);
            }
        }
        return documentNames;
    }

    /**
     * Method to set the mandatory fields for Document API by retieving it from Document Schema
     *
     * @param document  document fields object
     * @param userId    generate auth credentials
     * @param projectId projectid to retieve the schema
     */
    public Document setMandatoryFields(Document document, String userId, String projectId, String documentType, String documentStatus) {
        //Basic Mandatory fields for Document are Document Status ID, Document Type ID, Attribute 1 and Discipline
        //API response for Document Schema
        String responseString = getDocumentSchema(userId, projectId);
        List<String> mandatoryList;
        commonMethods.waitForElementExplicitly(300);
        //Return the response body from the HTTP Response
        SchemaHelperPage schemaHelper = new SchemaHelperPage();
        //Check if the document fields are not set in Document object. If not set, then retrieve from Document Schema response body and set it.
        if (document.getDiscipline() == null) {
            mandatoryList = schemaHelper.retrieveValuesFromSchema(responseString, "Discipline", "Value", document.getDiscipline());
            document.setDiscipline(mandatoryList.get(0));
        }
        if (document.getAttribute1() != null)
            document.setAttribute1(document.getAttribute1());
        if (document.getAttribute2() != null)
            document.setAttribute2(document.getAttribute2());
        mandatoryList = schemaHelper.retrieveValuesFromSchema(responseString, "DocumentStatusId", "Id", documentStatus);
        document.setDocumentStatusId(mandatoryList.get(0));

        mandatoryList = schemaHelper.retrieveValuesFromSchema(responseString, "DocumentTypeId", "Id", documentType);
        document.setDocumentTypeId(mandatoryList.get(0));

        return document;
    }

    /**
     * Method to set the mandatory fields for Document API by retieving it from Document Schema
     *
     * @param document  document fields object
     * @param userId    generate auth credentials
     * @param projectId projectid to retieve the schema
     */
    public Document setMandatoryFields(Document document, String userId, String projectId) {
        //Basic Mandatory fields for Document are Document Status ID, Document Type ID, Attribute 1 and Discipline
        //API response for Document Schema
        String responseString = getDocumentSchema(userId, projectId);
        List<String> mandatoryList;
        commonMethods.waitForElementExplicitly(300);
        //Return the response body from the HTTP Response
        SchemaHelperPage schemaHelper = new SchemaHelperPage();
        //Check if the document fields are not set in Document object. If not set, then retrieve from Document Schema response body and set it.
        if (document.getDiscipline() == null) {
            mandatoryList = schemaHelper.retrieveValuesFromSchema(responseString, "Discipline", "Value", document.getDiscipline());
            document.setDiscipline(mandatoryList.get(0));
        }
        if (document.getAttribute1() != null)
            document.setAttribute1(document.getAttribute1());
        if (document.getAttribute2() != null)
            document.setAttribute2(document.getAttribute2());
        mandatoryList = schemaHelper.retrieveValuesFromSchema(responseString, "DocumentStatusId", "Id", document.getDocumentStatusId());
        document.setDocumentStatusId(mandatoryList.get(0));

        mandatoryList = schemaHelper.retrieveValuesFromSchema(responseString, "DocumentTypeId", "Id", document.getDocumentTypeId());
        document.setDocumentTypeId(mandatoryList.get(0));

        return document;
    }

    /**
     * Method to get additional document project field values
     */
    public Map<String, String> addAdditionalDocFields(DataTable dataTable, int counter, String projectId) {
        String name, value;
        Map<String, String> additionalData = new HashMap<>();
        List<Map<String, String>> documentData = dataTable.asMaps(String.class, String.class);
        List<String> headers = new ArrayList<>(documentData.get(counter).keySet());
        for (String header : headers)
            if (header.startsWith("label_") && !documentData.get(counter).get(header).isEmpty()) {
                name = getFieldName(header, documentData.get(counter).get(header));
                if (documentData.get(counter).get(header).equalsIgnoreCase("yesterday") || documentData.get(counter).get(header).equalsIgnoreCase("today") || documentData.get(counter).get(header).equalsIgnoreCase("tomorrow"))
                    value = dateFormat.format(commonMethods.getDate(documentData.get(counter).get(header)));
                else value = documentData.get(counter).get(header);
                if (!name.isEmpty())
                    additionalData.put(name, value);
            }
        return additionalData;
    }

    /**
     * Method to get project field names for api
     */
    public String getFieldName(String header, String value) {
        switch (commonMethods.getLabelType(header)) {
            case "Select List (Single)":
                return commonMethods.getLabelName(header) + "_singleSelect";
            case "Text":
                return commonMethods.getLabelName(header) + "_singleLineText";
            case "Text Area":
                return commonMethods.getLabelName(header) + "_multiLineText";
            case "Date":
                return commonMethods.getLabelName(header) + "_date";
            case "Yes/No":
                return commonMethods.getLabelName(header) + "_boolean";
            case "Number":
                if (commonMethods.getUnitValue(header).equalsIgnoreCase("celsius") || commonMethods.getUnitValue(header).equalsIgnoreCase("Fahrenheit"))
                    return commonMethods.getLabelName(header) + "_number_temperature_" + commonMethods.getUnitValue(header);
                else if (commonMethods.getUnitValue(header).equalsIgnoreCase("inch"))
                    return commonMethods.getLabelName(header) + "_number_length_" + commonMethods.getUnitValue(header);
        }
        return "";
    }

    /**
     * Method to change the format of Access list when they are multiple values
     *
     * @param xmlString http response
     */
    public String fixAccessList(String xmlString) {
        String startTag = "<AccessList>";
        String endTag = "</AccessList>";
        int startPos = xmlString.indexOf(startTag) + startTag.length();
        int endPos = xmlString.indexOf(endTag);
        String content = xmlString.substring(startPos, endPos);
        String[] accessListString = content.split(",");
        StringBuilder replaceString = new StringBuilder();
        for (String accessList : accessListString) {
            replaceString.append("<AccessList>").append(accessList).append("</AccessList>");
        }
        xmlString = xmlString.replace(startTag + content + endTag, replaceString.toString());
        return xmlString;
    }

    /**
     * Method to retrieve the document schema through a api call
     */
    public String getDocumentSchema(String userId, String projectId) {
        HttpResponse response;
        String xmlResponse, basicAuth;
        int counter = 0;
        basicAuth = basicAuthCredentialsProvider(userId);
        String url = ConfigFileReader.getApplicationUrl() + "api/projects/" + projectId + "/register/schema";
        System.out.println("Url--->" + url);
        new Header("Authorization", basicAuth);
        response = getRequest(url, basicAuth);
        try {
            HttpEntity entity = response.getEntity();
            xmlResponse = EntityUtils.toString(entity);
            if (xmlResponse.isEmpty() || xmlResponse.contains("experiencing technical difficulty")) {
                while (counter < 2) {
                    basicAuth = basicAuthCredentialsProvider(userId);
                    response = getRequest(url, basicAuth);
                    try {
                        HttpEntity entity1 = response.getEntity();
                        xmlResponse = EntityUtils.toString(entity1);
                        if (response.getStatusLine().getStatusCode() == 200) break;
                    } catch (Exception e) {
                        counter++;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return xmlResponse;
    }

}
