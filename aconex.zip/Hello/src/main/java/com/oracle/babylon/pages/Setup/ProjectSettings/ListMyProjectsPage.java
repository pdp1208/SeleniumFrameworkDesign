package com.oracle.babylon.pages.Setup.ProjectSettings;

import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.util.ArrayList;
import java.util.List;

import static com.codeborne.selenide.Selenide.$;

public class ListMyProjectsPage extends Navigator {

    private By pageTitle = By.xpath("//h1[contains(text(),'Projects')]");
    private By projectParticipants = By.xpath("//ul[not(@style='visibility: hidden;')]//div[contains(text(),'Project Participants')]");
    private By organizationTab = By.xpath("//span[contains(text(),'Organization')]");
    private By searchInput = By.xpath("//div[@class='auiToolbar-right']//input");
    private By inviteUserBtn = By.xpath("//button[contains(text(),'Invite user')]");
    private By removeBtn = By.xpath("//button[contains(text(),'Remove')]");
    private By changePrjVisibilityBtn = By.xpath("//button[contains(text(),'Change Project Visibility')]");
    private By checkBox = By.xpath("//div[@class='ag-header-select-all ag-labeled ag-label-align-right ag-checkbox']");
    private By permissionDenied = By.xpath("//h1[contains(text(),'Permission denied')]");
    private By namesList = By.xpath("//span[@class='user-name-cell ng-scope']");
    private By visibleChecked = By.xpath("//input[@checked and @name='visible']");
    private By visibleCheckBox = By.xpath("//input[@name='hidden']");
    private By hiddenChkbox = By.xpath("//input[@name='hidden']");
    private By pageLinks = By.xpath("//div[@class='paging flow-right']");
    private By projectNameInput = By.xpath("//input[@name='projectName']");
    private By prjShortName = By.xpath("//input[@name='projectShortName']");
    private By searchBtn = By.xpath("//button[@title='Search']");
    private By zeroProjects = By.xpath("//div[@id='numResults']//b[contains(text(),'0-0')]");
    private By projectChkBox = By.xpath("//input[@name='tag']");
    private By hideBtn = By.xpath("//button[@title='Hide From Directory']");
    private By showBtn = By.xpath("//button[@title='Make selected projects visible']");
    private By hideAllBtn = By.xpath("//button[@title='Hide all projects']");
    private By selectAllPrj = By.xpath("//th[@class='tight']//a");
    private By editPrjDetails = By.xpath("//ul[not(@style='visibility: hidden;')]//div[contains(text(),'Edit Project Details')]");
    private By projectInfo = By.xpath("//div[contains(text(),'Project Information')]");
    private By copyProject = By.xpath("//ul[not(@style='visibility: hidden;')]//div[contains(text(),'Copy Project')]");
    private By newPrjLink = By.xpath("//a[contains(text(),'View new project.')]");
    private By showAllPrj = By.xpath("//div[contains(text(),'Show all projects in all organizations')]");
    private By showAllPrjChkBox = By.xpath("//input[@name='allProjects']");
    private By projectOwner = By.xpath("//table[@id='resultTable']//tbody//tr//td[7]");
    private By newProjectName = By.xpath("//ul[@class='projectNodes']//li[contains(@class,'active')]");
    Actions action = new Actions(driver);
    public static String projectName="";
    private By projectCode = By.xpath("//table[@class='formTable']//tr[1]/td[2]");
    private By rows = By.xpath("//table[@id='resultTable']//tbody//tr");
    private By contractMetaData = By.xpath("//div[text()='Contract Meta-data']");
    private By firstRow = By.xpath("//tr[contains(@class,'dataRow')]//input");
    public static String copiedProjCode;
    private By txtBoxSuburb = By.xpath("//input[@name='suburb']");
    private By txtBoxAddress = By.xpath("//input[@name='address']");
    private By nextPage = By.xpath("//div[@id='searchResultsContainer']//a[text()='next>>']");
    private By previousPage = By.xpath("//div[@id='searchResultsContainer']//a[text()='<<previous']");
    private By tblFirstProjectRow = By.xpath("//div[@id='searchResultsContainer']//table//tbody/tr[1]");
    private By prjtSettingsReport = By.xpath("//div[text()='Project Settings Report']");

    /**
     * Function to navigate to the project settings page under Setup
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Setup", "List My Projects");
        Assert.assertTrue(verifyPageTitle(pageTitle));
    }

    /**
     * Function to click on dots
     *
     * @param project
     */

    public void clickDots(String project) {
        commonMethods.waitForElementExplicitly(4000);
        By projectXpath = By.xpath("//td[contains(text(),'" + project + "')]//..//input[@name='tag']");
        By element = By.xpath("//td[contains(text(),'" + project + "')]//..//span[@name='TOGGLE_SELECT']");
        commonMethods.waitForElementHidden(driver, element);
        $(projectXpath).click();
        $(element).click();
    }

    /**
     * Function to verify the options after clicking on three dots
     *
     * @param data
     */

    public void verifyOptions(List<String> data) {
        for (String option : data) {
            By element = By.xpath("//ul[not(@style='visibility: hidden;')]//div[contains(text(),'" + option + "')]");
            getElementInView(element);
            Assert.assertTrue($(By.xpath("//ul[not(@style='visibility: hidden;')]//div[contains(text(),'" + option + "')]")).isDisplayed());
        }
    }

    /**
     * Function to verify the project participants option is present after clicking on three dots
     *
     * @return
     */

    public boolean verifyParticipants() {
        return $(projectParticipants).isDisplayed();
    }

    /**
     * Function to click on project participants
     */

    public void clickParticipants() {
        action.moveToElement($(projectParticipants)).build().perform();
        $(projectParticipants).click();
    }

    /**
     * Function to verify the different tabs present
     *
     * @param data
     */

    public void verifyTabs(List<String> data) {
        for (String option : data) {
            By element = By.xpath("//span[contains(text(),'" + option + "')]");
            commonMethods.waitForElement(driver, element, 45);
            Assert.assertTrue($(element).isDisplayed());
        }
    }

    /**
     * Function to verify the buttons present
     */

    public void verifyButtons() {
        Assert.assertTrue($(searchInput).isDisplayed());
        Assert.assertTrue($(inviteUserBtn).isDisplayed());
        Assert.assertTrue($(removeBtn).isDisplayed());
        Assert.assertTrue($(changePrjVisibilityBtn).isDisplayed());
        Assert.assertTrue($(checkBox).isDisplayed());
    }

    /**
     * Function to verify the columns present in User tab
     *
     * @param data
     */

    public void verifyColumns(List<String> data) {
        for (String field : data) {
            Assert.assertTrue($(By.xpath("//span[contains(text(),'" + field + "')]")).isDisplayed());
        }
    }

    /**
     * Function to verify search Input is displayed
     *
     * @return
     */

    public boolean verifySearch() {
        return $(searchInput).isDisplayed();
    }

    /**
     * Function to click on organisation tab
     */

    public void clickOrganizationTab() {
        $(organizationTab).click();
    }

    /**
     * Method to click get All Names present in User tab
     *
     * @return
     */

    public List<String> getAllNames() {
        List<String> allNames = new ArrayList<>();
        List<WebElement> names = driver.findElements(namesList);
        for (int i = 0; i < names.size(); i++) {
            String cname = driver.findElement(By.xpath("//div[@row-index='" + i + "']//span[@class='user-name-cell ng-scope']")).getText();
            allNames.add(cname);

        }
        return allNames;
    }

    /**
     * Function to get the count of all users
     *
     * @return
     */

    public int getAllUsersCount() {
        List<String> allUsers = getAllNames();
        return allUsers.size();
    }

    /**
     * Function to verify the user count
     *
     * @param count
     * @return
     */

    public boolean verifyUserCount(int count) {
        return $(By.xpath("//div[contains(text(),'" + count + " User(s)')]")).isDisplayed();
    }

    /**
     * Function to verify Fields
     * @param data
     */

    public void verifyFields(List<String> data) {
        for (String field : data) {
            Assert.assertTrue($(By.xpath("//td[contains(text(),'" + field + "')]")).isDisplayed());
        }
    }

    /**
     * Function to verify Page Buttons
     * @param data
     */

    public void verifyPageButtons(List<String> data) {
        for (String button : data) {
            Assert.assertTrue($(By.xpath("//div[contains(text(),'" + button + "')]")).isDisplayed());
        }
    }

    /**
     * Function to verify checkbox present on page
     */

    public void verifyCheckbox() {
        Assert.assertTrue($(visibleChecked).isDisplayed());
        Assert.assertTrue($(hiddenChkbox).isDisplayed());
    }

    /**
     * Function to verify Page Links
     * @return
     */

    public boolean verifyPageLinks() {
        return $(pageLinks).isDisplayed();
    }

    /**
     * Function to search project
     * @param projectName
     */

    public void searchProject(String projectName) {
        $(projectNameInput).clear();
        $(projectNameInput).sendKeys(projectName);
    }

    /**
     * Function to search project short Name
     * @param projectName
     */

    public void searchPrjShortName(String projectName) {
        $(prjShortName).clear();
        $(prjShortName).sendKeys(projectName);
    }

    /**
     * Function to click Search button
     */

    public void clickSearchBtn(){
        $(searchBtn).click();
    }

    /**
     * Function to verify Search columns
     * @param data
     */

    public void verifySearchColumns(List<String> data){
        for(String column: data){
            Assert.assertTrue($(By.xpath("//th[contains(text(),'"+column+"')]")).isDisplayed());
        }
    }

    /**
     * Function to verify project displayed
     * @param projectName
     * @return
     */

    public boolean verifyProject(String projectName){
        return $(By.xpath("//td[contains(text(),'"+projectName+"')]")).isDisplayed();
    }

    /**
     * Function to verify that no project is displayed
     * @return
     */

    public boolean verifyNoProject(){
        commonMethods.waitForElement(driver, zeroProjects);
        return $(zeroProjects).isDisplayed();
    }

    /**
     * Function to select project checkbox
     */

    public void selectPrjChkBox(){
        $(projectChkBox).setSelected(true);
    }

    /**
     * Function to click Hide Button
     */

    public void clickHideBtn(){
        $(hideBtn).click();
    }

    /**
     * Function to click Hide All Button
     */

    public void clickHideAllBtn(){
        $(hideAllBtn).click();
    }

    /**
     * Function to click show Button
     */

    public void clickShowBtn(){
        $(showBtn).click();
    }

    /**
     * Function to click Hidden checkbox
     */

    public void clickHiddenChkBox(){
        $(hiddenChkbox).click();
    }

    /**
     * Function to select All project
     */

    public void selectAllPrj(){
        $(selectAllPrj).click();
    }

    /**
     * Function to click Edit project Details
     */

    public void clickEditPrjDetails(){
        action.moveToElement($(editPrjDetails)).build().perform();
        $(editPrjDetails).click();
    }

    /**
     * Function to click Project Information
     */

    public void clickProjectInformation(){
        $(projectInfo).click();
    }

    /**
     * Function to verify Project Information
     * @param data
     */

    public void verifyPrjInfo(List<String> data){
        for(String field:data){
            Assert.assertTrue(commonMethods.tableFieldIsDisplayed(driver,field));
        }
    }

    /**
     * Function to verify Link Present
     * @param linkName
     * @return
     */

    public boolean verifyLinkPresent(String linkName){
        return  $(By.xpath("//a[contains(text(),'"+linkName+"')]")).isDisplayed();
    }

    /**
     * Function to click Copy Project
     */

    public void clickCopyProject(){
        action.moveToElement($(copyProject)).build().perform();
        $(copyProject).click();
    }

    /**
     * Function to verify Copy project Message
     * @param projName
     * @return
     */

    public boolean verifyCopyPrjMsg(String projName){
        By element = By.xpath("//div[contains(text(),'A copy of "+projName+" was successfully created.')]");
        commonMethods.waitForElement(driver,element,45);
        return $(element).isDisplayed();
    }

    /**
     * Function to verify New project Link
     * @return
     */

    public boolean verifyNewPrjLink(){
        commonMethods.waitForElement(driver, newPrjLink);
        return  $(newPrjLink).isDisplayed();
    }

    /**
     * Function to click New project Link
     */

    public void clickNewPrjLink(){
        $(newPrjLink).click();
    }

    /**
     * Function to verify New project created
     * @param prjName
     * @return
     */

    public boolean verifyPrjCreated(String prjName){
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(1000);
        commonMethods.waitForElement(driver,newProjectName,30);
        String actualProjectName = $(newProjectName).getText();
        return (actualProjectName.contains(prjName));
    }

    /**
     * Function to click show All Project
     */
    public void clickShowAllPrj(boolean value){
        commonMethods.waitForElement(driver, showAllPrj);
        $(showAllPrjChkBox).setSelected(value);
    }

    /**
     * Function to get the project owner
     */
    public String getProjectOwner(){
        return $(projectOwner).getText();
    }

    /**
     * Function to verify the options not present after clicking on three dots
     *
     * @param data
     */

    public void verifyOptionsNotPresent(List<String> data) {
        for (String option : data) {
           Assert.assertFalse("The "+option+" is not present", $(By.xpath("//ul//div[contains(text(),'" + option + "')]")).isDisplayed());
        }
    }
    /**
     * Function to get the project code
     */
    public void getProjectCode(){
        copiedProjCode=$(projectCode).getText();
    }


    /**
     * Function to get the copied project name
     */
    public String getCopiedProjName(){
        return $(projectNameInput).getAttribute("value");
    }

    /**
     * Method to return the number of projects
     * @return
     */
    public int returnRowsCount(){
        List<WebElement> list = driver.findElements(rows);
        return list.size();
    }

    /**
     * Method to return if rows are displayed
     * @return
     */
    public boolean returnRowsDisplayed(){
        commonMethods.waitForElementExplicitly(500);
        return $(rows).isDisplayed();
    }


    /**
     * Method to show the projects for all organizations
     */
    public void showAllOrgProjects(){
        $(allOrgPrjChkBox).setSelected(true);
    }

    /**
     * Method to return if the show all project checkbox is present
     * @return
     */
    public boolean showAllOrgProjectsDisplayed(){
        return $(allOrgPrjChkBox).isDisplayed();
    }

    /**
     * Method to select contract meta data option
     */
    public void clickContractMetaData(String user) {
        clickDots(commonMethods.getUserData(user,"projectName1"));
        $(contractMetaData).click();
    }

    /**
     * Select the first project
     */
    public void selectFirstRow() {
        $(firstRow).setSelected(true);
    }
    /**
     * Function to search with suburb
     */
    public void searchSuburb(String suburb) {
        $(projectNameInput).clear();
        $(prjShortName).clear();
        $(txtBoxAddress).clear();
        commonMethods.enterTextValue(txtBoxSuburb,suburb);
    }

    /**
     * Function to search with address
     */
    public void searchAddress(String address) {
        $(projectNameInput).clear();
        $(prjShortName).clear();
        $(txtBoxSuburb).clear();
        commonMethods.enterTextValue(txtBoxAddress,address);
    }

    /**
     * Function to verify pagination
     */
    public void verifyPagination() {
        commonMethods.waitForElement(driver, nextPage);
        $(nextPage).click();
        Assert.assertTrue(verifyProjectsTable());
        $(previousPage).click();
        Assert.assertTrue(verifyProjectsTable());
    }

    /**
     * Function to verify pagination
     */
    public boolean verifyProjectsTable() {
        commonMethods.waitForElement(driver, tblFirstProjectRow, 60);
        return $(tblFirstProjectRow).isDisplayed();
    }

    /**
     * Function to verify list all projects for all organizations option
     */
    public boolean verifyListAllProjects() {
        commonMethods.waitForElement(driver, projectNameInput, 60);
        return $(showAllPrj).isDisplayed() && $(showAllPrjChkBox).isDisplayed();
    }

    /**
     * Function to verify project visibility
     */
    public String verifyProjectVisibility(String projectName) {
        commonMethods.waitForElement(driver, tblFirstProjectRow, 60);
        return $(By.xpath("//table//tr/td[text()='" + projectName + "']/../td/a/div")).getAttribute("title");

    }

    /**
     * Function to verify show projects that are visible checkbox
     */
    public boolean verifyVisibleProjectsChkBox() {
        return $(visibleChecked).isDisplayed();
    }

    /**
     * Function to verify show projects that are hidden checkbox
     */
    public boolean verifyHiddenProjectsChkBox() {
        return $(hiddenChkbox).isDisplayed();
    }

    /**
     * Function to click on Project settings report option
     */
    public void clickProjectSettingsReport() {
        $(prjtSettingsReport).click();
    }
}
