package com.oracle.babylon.pages.Document;

import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import java.util.List;
import java.util.Map;
import java.util.Random;

import static com.codeborne.selenide.Selenide.$;

/**
 * Class to handle the actions in Document Review (Doc) Mode.
 * Required for handling viewer test cases for documents and workflows
 * created by susgopal
 */
public class DocumentReviewDocModePage extends Navigator {

    private final By reviewOutcomeSelect = By.xpath("//form[@class='current-review-form']//select");
    private final By commentsTxtArea = By.xpath("//form[@class='current-review-form']//textarea");
    private final By publishMarkups = By.xpath("//button[@aria-label='saveButton']");
    private final By submitReviewBtn = By.xpath("//button//span[text()='Submit Review']");
    private final By closeBtn = By.xpath("//div[contains(@class,'ReviewSaveAsDraft_success')]//button[@class='auiButton close']//span[text()='Close']");
    private final By submitCloseBtn = By.xpath("//div[@class='SingleReviewSubmission_success']//button[@class='auiButton close']");
    private By documentNumber = By.xpath("//div[contains(@title,'Document Number')]//span");
    private By docRevisionNumber = By.xpath("//span[contains(@title,'Document Revision Number')]");
    private By docTitle = By.xpath("//span[contains(@title,'Document Title')]");
    private By panelBtn = By.xpath("//span[@title='Toggle Notes Panel']");
    private By commentsSpan = By.xpath("//div[@class='Header Tools']//button[@aria-label='Note']");
    private By commentNoteContainer = By.xpath("//div[@class='Note expanded']");
    private By commentsList = By.xpath("//div[@class='note-wrapper']");
    private By commentsHeader = By.xpath("//div[@class='Note']");
    private By closedCommentNoteContainer = By.xpath("//div[@class='Note']");
    private By stampNoteContainer = By.xpath("//span[contains(text(),'Stamp')]//ancestor::div[@class='noteContainer']");
    private By commentNotesTextArea = By.xpath("//div[contains(@data-placeholder,'Comment.')] | //textarea[contains(@placeholder,'Comment.')]");
    private By replyNotesTextArea = By.xpath("//div[contains(@class,'reply-area')]//textarea");

    private By stampNotesTxtArea = By.xpath("div[@class='noteContainer']//textarea[@class='panelElementFont']");
    private By saveBtn = By.xpath("//button[text()='Save']");
    private By toggleNotesPanel = By.xpath("//button[@aria-label='Comments']");
    private By addStamps = By.xpath("//span[@title='Stamps']");
    private By basicStamp = By.xpath("//div[@id='BasicReviewStamp']");
    private By noteHeader = By.xpath("//span[contains(text(),'Comment')]//ancestor::div[@class='noteContainer']//div[@class='noteHeader']");
    private By staticNoteContents = By.xpath("//div[contains(@class,'NoteContent')]");
    private By deleteBtn = By.xpath("//button[@data-element='annotationDeleteButton']");
    private By successMessage = By.xpath("//section[@id='modal-dialog']//div[@class='SingleReviewSubmission_success']//span[text()='Your review has been submitted']");
    private By annotationStampsBtn = By.xpath("//div[@class='ribbons']//button[text()='Annotations & Stamps']");
    private By notePopUpBtn = By.xpath("//div[@class='NotePopup']//div[@class='Icon ']");
    private By backToListBtn = By.xpath("//button[@aria-label='backButton']");
    private By imageStampBtn = By.xpath("//button[@aria-label='Image Stamp']");
    private By basicRubberStampBtn = By.xpath("//button[@aria-label='Rubber Stamp']");
    private By dynamicRubberStampBtn = By.xpath("//button[@aria-label='Dynamic stamp']");
    private By notesPanelIcon = By.xpath("//div[@class='HeaderItems']//button[@aria-label='Comments']");
    private By currentStamp = By.xpath("//img[@alt='Current Stamp']");
    private By postBtn = By.xpath("//button[text()='Post']");
    private By replyNote = By.xpath("//div[@class='replies']");
    private By filterBtn = By.xpath("//button//span[text()='Filter']");
    private By applyBtn = By.xpath("//button//span[text()='Apply']");
    private By clearBtn = By.xpath("//button//span[text()='Clear']");
    private By fileDropDown = By.xpath("//div[@class='document-list']");
    private By documentNumberHeader = By.xpath("//div[contains(@title,'Document Number')]//span[contains(@data-bind,'documentNumber')]");
    private By nextBtn = By.xpath("//button[@class='next-button']");
    private By previousBtn = By.xpath("//button[@class='previous-button']");
    private By reviewNextDoc = By.xpath("//span[text()='Review next document']");
    private By notesGroup = By.xpath("//button[@class='Button active tool-button hasStyles']");
    private By defaultPageWidgetContainer = By.xpath("//div[@id='pageContainer1']");

    private By txtCommentsCount = By.xpath("//button[@aria-label='Comments']//span");
    private By sltViewDocDropdown = By.xpath("//div[@class='document-list']");
    private By btnFirstRecord = By.xpath("(//ul[@class='document-list-content']/li/div)[1]");
    private By btnRight = By.xpath("//button[@class='next-button']");
    private By btnLeft = By.xpath("//button[@class='previous-button']");
    private By txtDocumentTitle = By.xpath("//div[contains(@title,'Document Number')]/span");
    private By lnkConsolidateMarkups = By.xpath("//a/span[text()='Consolidate markups']");
    private By btnDownload = By.xpath("//div[@class='HeaderItems']//button[@aria-label='Download']");
    private By txtboxSearchComments = By.xpath("//input[@id='NotesPanel__input']");
    private By btnLeftPanel = By.xpath("//div[@class='HeaderItems']//button[@aria-label='Panel']");
    private By btnThumbnails = By.xpath("//div[@class='left-panel-header']//button[@aria-label='Thumbnails']");
    private By pageContainer = By.xpath("//div[contains(@id,'pageWidgetContainer')]");
    private By txtWFNum = By.xpath("//span[@class='wf-number']");
    private By lnkTellUs = By.xpath("//a[@class='feedback-link']//span[text()='Tell us what you think']");
    private By lnkSupplimentaryDocs = By.xpath("//a//span[text()='Supplementary Files']");
    private By lnkFileComparison = By.xpath("//a//span[text()='File Comparison']");
    private By tabReview = By.xpath("//div[@class='tab-navs']//div[text()='Review']");
    private By tabDocProperties = By.xpath("//div[@class='tab-navs']//div[text()='Document Properties']");
    private By btnViewControls = By.xpath("//div[@class='HeaderItems']//button[@aria-label='View Controls']");
    private By btnZoomControls = By.xpath("//div[@class='HeaderItems']//button[@aria-label='Zoom Controls']");
    private By btnZoomOut = By.xpath("//div[@class='HeaderItems']//button[@aria-label='Zoom out']");
    private By btnZoomIn = By.xpath("//div[@class='HeaderItems']//button[@aria-label='Zoom in']");
    private By btnPan = By.xpath("//div[@class='HeaderItems']//button[@aria-label='Pan']");
    private By btnSelect = By.xpath("//div[@class='HeaderItems']//button[@aria-label='Select']");
    private By btnMarqueeZoom = By.xpath("//div[@class='HeaderItems']//button[@aria-label='Marquee Zoom']");
    private By btnFullScreen = By.xpath("//div[@class='HeaderItems']//button[@aria-label='Full screen']");
    private By btnUndo = By.xpath("//div[@class='HeaderItems']//button[@aria-label='Undo']");
    private By btnRedo = By.xpath("//div[@class='HeaderItems']//button[@aria-label='Redo']");
    private By btnSearch = By.xpath("//div[@class='HeaderItems']//button[@aria-label='Search']");
    private By btnPrint = By.xpath("//div[@class='HeaderItems']//button[@aria-label='Print']");
    private By txtNoPresets = By.xpath("//div[@class='ToolsOverlayContainer']//div[text()='No Presets']");
    private By btnFreeText = By.xpath("//div[@class='HeaderItems']//button[@aria-label='Free Text']");
    private By btnHighlight = By.xpath("//div[@class='HeaderItems']//button[@aria-label='Highlight']");
    private By btnCallout = By.xpath("//div[@class='HeaderItems']//button[@aria-label='Callout']");
    private By btnArrow = By.xpath("//div[@class='HeaderItems']//button[@aria-label='Arrow']");
    private By btnLine = By.xpath("//div[@class='HeaderItems']//button[@aria-label='Line']");
    private By btnCloud = By.xpath("//div[@class='HeaderItems']//button[@aria-label='Cloud']");
    private By btnRectangle = By.xpath("//div[@class='HeaderItems']//button[@aria-label='Rectangle']");
    private By btnEllipse = By.xpath("//div[@class='HeaderItems']//button[@aria-label='Ellipse']");
    private By btnFileAttachment = By.xpath("//div[@class='HeaderItems']//button[@aria-label='File Attachment']");
    private By btnSignature = By.xpath("//div[@class='HeaderItems']//button[@aria-label='Signature']");
    private By btnAnnotationStamps = By.xpath("//div[@class='Dropdown__items hide']//button[text()='Annotations & Stamps']");
    private By distance = By.xpath("//button[@aria-label='Distance']");

    /**
     * Method to add the outcomes of a review and save it for a document
     *
     * @param reviewOutcome
     * @param comments
     */
    public void fillReviewOutcome(String reviewOutcome, String comments) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(30000);
        commonMethods.waitForElement(driver, commentsTxtArea, 60);
        $(commentsTxtArea).clear();
        $(commentsTxtArea).sendKeys(comments);
        $(reviewOutcomeSelect).click();
        Select select = new Select($(reviewOutcomeSelect));
        select.selectByVisibleText(reviewOutcome);
    }

    /**
     * Method to click on the save button
     */
    public void publishMarkups() {
        commonMethods.waitForElementExplicitly(5000);
        commonMethods.waitForElement(driver, publishMarkups, 14);
        $(publishMarkups).click();
        //verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(5000);
        List<WebElement> closeBtnList = driver.findElements(closeBtn);
        closeBtnList.get(closeBtnList.size() - 1).click();
    }

    /**
     * Method to click on publish markup button
     */
    public void clickPublishMarkup() {
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, publishMarkups, 14);
        $(publishMarkups).click();

    }

    /**
     * Method to click on  submit button. Appears in the WF modules of document viewer
     */
    public void clickSubmitBtn() {
        commonMethods.waitForElementExplicitly(10000);
        commonMethods.waitForElement(driver, submitReviewBtn, 40);
        $(submitReviewBtn).click();
        commonMethods.waitForElementExplicitly(5000);
        validateSuccessMessage();
        List<WebElement> closeBtnList = driver.findElements(submitCloseBtn);
        closeBtnList.get(1).click();
        commonMethods.waitForElementExplicitly(5000);
    }

    /**
     * Method to validate if the correct values are updated
     *
     * @param documentId
     * @param data
     * @return
     */
    public boolean validateFields(String documentId, List<String> data) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(docDataPath);
        Map<String, Object> map = jsonMapOfMap.get(documentId);
        String actualValue;
        String expectedValue;
        boolean flag = true;
        for (int count = 0; count < data.size(); count++) {
            if (data.get(count).equalsIgnoreCase("Document number")) {
                actualValue = $(documentNumber).getText();
                expectedValue = map.get("doc_num").toString();
                if (!actualValue.equalsIgnoreCase(expectedValue)) flag = false;
            } else if (data.get(count).equalsIgnoreCase("Title")) {
                actualValue = $(docTitle).getText();
                expectedValue = map.get("title").toString();
                if (!actualValue.equalsIgnoreCase(expectedValue)) flag = false;
            } else if (data.get(count).equalsIgnoreCase("Revision")) {
                actualValue = $(docRevisionNumber).getText();
                expectedValue = "A";
                if (!actualValue.contains(expectedValue)) flag = false;
            } else {
                System.out.println("Not evaluating this value");
                flag = false;
            }

        }
        return flag;
    }

    /**
     * Method to click on the right panel. Needed for opening comments panel for WF
     */
    public void displayNotes() {
        commonMethods.waitForElementExplicitly(25000);
        switchToOriginal();
        verifyAndSwitchFrame();
        webViewerFrame();
        if (!$(closedCommentNoteContainer).isDisplayed()) {
            $(notesPanelIcon).click();
        }

    }

    /**
     * Method to click on the left panel. Needed to open the outline/thumbnail options
     */
    public void clickLeftPanel() {
        List<WebElement> webElements = driver.findElements(panelBtn);
        webElements.get(0).click();
    }

    /**
     * Method to add the comments to the documents
     *
     * @param pageNumber
     * @param comments
     */
    public void addNotes(int pageNumber, String comments) {
        commonMethods.waitForElementExplicitly(30000);
        Random random = new Random();
        switchToOriginal();
        verifyAndSwitchFrame();
        webViewerFrame();
        int xOffset, yOffset;
        commonMethods.waitForElement(driver, commentsSpan, 180);
        Actions actions = new Actions(driver);
        $(commentsSpan).click();
        By by = By.xpath("//div[@id='pageWidgetContainer" + (pageNumber) + "']");

        xOffset =  random.nextInt(150);
        yOffset = random.nextInt(150);
        actions.moveToElement($(by), 0,0).build().perform();
        actions.moveByOffset(xOffset, yOffset).click().release().build().perform();

        addComments(comments);
        clickSaveBtn();
        switchToOriginal();
    }


    /**
     * Method to add the comments to the documents
     *
     * @param comments
     */
    public void addNotes(String comments) {
        commonMethods.waitForElementExplicitly(8000);
        switchToOriginal();
        verifyAndSwitchFrame();
        webViewerFrame();
        commonMethods.waitForElement(driver, commentsSpan, 120);
        $(commentsSpan).click();
        $(defaultPageWidgetContainer).click();
        addComments(comments);
        switchToOriginal();
    }

    /**
     * Method to add comments after markups tools are added
     *
     * @param comments
     */
    public void addComments(String comments) {
        commonMethods.waitForElementExplicitly(3000);
        List<WebElement> notesList = driver.findElements(commentNoteContainer);
        int size = notesList.size() - 1;
        notesList.get(size).click();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.getElementInViewAndUp(commentNotesTextArea);
        commonMethods.waitForElement(driver, commentNotesTextArea);
        List<WebElement> notes = driver.findElements(commentNotesTextArea);
        notes.get(size).sendKeys(comments);
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Method to click on the notes
     */
    public void clickNotes(){
        List<WebElement> notesList = driver.findElements(commentNoteContainer);
        int size = notesList.size() - 1;
        notesList.get(size).click();
    }
    /**
     * Method to add a reply to the comment
     *
     * @param reply
     */
    public void addReply(String reply) {
        if ($(closedCommentNoteContainer).isDisplayed()) {
            $(closedCommentNoteContainer).click();
        }

        List<WebElement> notes = driver.findElements(replyNotesTextArea);
        notes.get(0).sendKeys(reply);
        $(postBtn).click();

    }

    /**
     * Method to return if the comments option is present in the header tools
     *
     * @return
     */
    public boolean isCommentsOptionDisplayed() {
        return $(commentsSpan).isDisplayed();
    }

    public void clickBackToList() {
        commonMethods.waitForElementExplicitly(3000);
        switchToOriginal();
        verifyAndSwitchFrame();
        $(backToListBtn).click();
    }

    /**
     * Method to validate if the notes container is present
     *
     * @return
     */
    public boolean validateNotesContainer() {
        commonMethods.waitForElementExplicitly(5000);
        webViewerFrame();
        clickToggleNotes();
        commonMethods.waitForElement(driver, closedCommentNoteContainer, 15);
        return $(closedCommentNoteContainer).isDisplayed();
    }

    /**
     * Method to add rubber stamps to the document
     *
     * @param pageNumber
     */
    public void addRubberStamps(int pageNumber, String comment) {
        webViewerFrame();
        commonMethods.waitForElementExplicitly(5000);
        $(basicRubberStampBtn).click();
        $(currentStamp).click();
        By by = By.xpath("//div[@id='pageWidgetContainer" + (pageNumber) + "']");
        int xOffset, yOffset;
        Random random = new Random();
        Actions actions = new Actions(driver);
        xOffset =  random.nextInt(20);
        yOffset = random.nextInt(20);
        actions.moveToElement($(by), 0,0).build().perform();
        actions.moveByOffset(xOffset, yOffset).click().release().build().perform();

        clickNodeContainer();
        addComments(comment);
        clickSaveBtn();
        commonMethods.waitForElementExplicitly(2000);
        driver.switchTo().defaultContent();
    }

    /**
     * Method to add dynamic stamps to the document
     *
     * @param pageNumber
     */
    public void addDynamicStamps(int pageNumber, String comment, String type) {
        commonMethods.waitForElementExplicitly(5000);
        webViewerFrame();
        $(dynamicRubberStampBtn).click();
        $(By.xpath("//div[text()='" + type + "']//..//img")).click();

        driver.findElement(By.xpath("//div[@id='pageWidgetContainer" + pageNumber + "']")).click();
        commonMethods.waitForElementExplicitly(4000);
        clickToggleNotes();
        clickNodeContainer();
       // clickDefaultPageWidget();
        addComments(comment);
        clickSaveBtn();
        driver.switchTo().defaultContent();
    }

    /**
     * Method to add the notes to a stamp
     *
     * @param note
     */
    public void addStampNotes(String note) {
        webViewerFrame();
        if (!validateNotesContainer()) {
            $(toggleNotesPanel).click();
        }
        List<WebElement> notesList = driver.findElements(stampNoteContainer);
        notesList.get(0).click();
        List<WebElement> notes = driver.findElements(stampNotesTxtArea);
        notes.get(0).sendKeys(note);
        List<WebElement> okBtnList = driver.findElements(saveBtn);
        okBtnList.get(0).click();
        driver.switchTo().defaultContent();
    }

    /**
     * Method to return the contents of the notes header
     *
     * @return
     */
    public String returnNotesHeader(String comment) {
        switchToOriginal();
        verifyAndSwitchFrame();
        webViewerFrame();
        By by = By.xpath("//div[contains(text(),'" + comment + "')]//ancestor::div//div[@class='author-and-date']//div[@class='author-and-time']");
        return $(by).getText();
    }

                                                                                                                    //
    /**
     * Method to select static note
     *
     * @return
     */
    public String returnStaticNote() {
        return $(staticNoteContents).getText();
    }

    /**
     * Method to return count of static notes
     *
     * @return
     */
    public int returnStaticNotesCount() {
        List<WebElement> list = driver.findElements(staticNoteContents);
        return list.size();
    }

    /**
     * Method to click on the notes
     *
     * @return
     */
    public void clickStaticNote() {
        $(staticNoteContents).click();
    }

    /**
     * Method to click the back button
     */
    public void clickBackBtn() {
        $(backButton).click();
    }

    /**
     * Method to click the toggle notes option on the right side of the page
     */
    public void clickToggleNotes() {
        webViewerFrame();
        commonMethods.waitForElement(driver, toggleNotesPanel, 90);
        commonMethods.waitForElementExplicitly(2000);
        if(!$(toggleNotesPanel).getAttribute("class").contains("active")) {
            $(toggleNotesPanel).click();
        }

    }

    /**
     * Method to click the nodes container
     */
    public void clickNodeContainer() {
        webViewerFrame();
        commonMethods.waitForElementExplicitly(5000);
        List<WebElement> commentsNote = driver.findElements(commentNoteContainer);
        List<WebElement> closedCommentsNote = driver.findElements(closedCommentNoteContainer);
        if (commentsNote.size() != 0 && commentsNote.get(commentsNote.size() - 1).isDisplayed()) {
            $(commentsNote.get(commentsNote.size() - 1)).click();
        } else if (closedCommentsNote.size() != 0 && closedCommentsNote.get(closedCommentsNote.size() - 1).isDisplayed()) {
            $(closedCommentsNote.get(closedCommentsNote.size() - 1)).click();
        }
    }

    /**
     * Method to click on the note pop up button in the note container element.
     * Edit and delete are the 2 options present
     */
    public void clickNotePopUpBtn() {
        webViewerFrame();

        $(notePopUpBtn).click();
    }


    /**
     * Method to delete the comments added in the mark up tools
     */
    public void clickDeleteButton() {
        $(deleteBtn).click();
    }

    /**
     * Return true if success message is present
     *
     * @return
     */
    public Boolean validateSuccessMessage() {
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, successMessage, 90);
        return $(successMessage).isDisplayed();
    }

    public Boolean validateComments(int pageNumber, String comments) {
        commonMethods.waitForElementExplicitly(5000);
        int count = pageNumber - 1;
        webViewerFrame();
        driver.findElement(By.xpath("//div[@id='pageWidgetContainer" + (count + 1) + "']")).click();
        if (!returnStaticNote().equals(comments)) {
            return false;
        }
        return true;
    }

    /**
     * verify comments
     *
     * @param comments
     * @return
     */
    public boolean verifyComments(String comments) {
        displayNotes();
        commonMethods.waitForElementExplicitly(2000);
        return $(By.xpath("//span[text()='" + comments + "']")).isDisplayed();

    }


    /**
     * Method to verify if image stamp is displayed in markup mode page
     *
     * @return
     */
    public boolean isImageStampDisplayed() {
        return $(imageStampBtn).isDisplayed();
    }


    /**
     * Method to verify if basic stamp is displayed in markup mode page
     *
     * @return
     */
    public boolean isBasicStampDisplayed() {
        return $(basicRubberStampBtn).isDisplayed();
    }

    /**
     * Method to verify if dynamic stamps are available in markup mode page
     *
     * @return
     */
    public boolean isDynamicStampDisplayed() {
        return $(dynamicRubberStampBtn).isDisplayed();
    }

    /**
     * Method to verify if comments panel is displayed
     *
     * @return
     */
    public boolean displayCommentContainer() {
        commonMethods.waitForElementExplicitly(2000);
        if(!$(toggleNotesPanel).getAttribute("class").contains("active")){
            $(toggleNotesPanel).click();
             commonMethods.waitForElementExplicitly(2000);
             $(closedCommentNoteContainer).click();
        }
        return $(commentNoteContainer).isDisplayed();
    }

    /**
     * Method to verify if comments panel is displayed
     *
     * @return
     */
    public boolean hideCommentContainer() {
        commonMethods.waitForElementExplicitly(2000);
        if($(toggleNotesPanel).getAttribute("class").contains("active")){
            $(toggleNotesPanel).click();
            commonMethods.waitForElementExplicitly(2000);
        }
        return $(commentsHeader).isDisplayed();
    }


    /**
     * Method to check if the reply note is displayed
     *
     * @return
     */
    public boolean isReplyDisplayed() {
        if ($(closedCommentNoteContainer).isDisplayed())
            $(closedCommentNoteContainer).click();
        return $(replyNote).isDisplayed();
    }

    /**
     * Method to click on the filter button
     */
    public void clickFilterBtn() {
        $(filterBtn).click();
    }

    /**
     * Method to set the types of tools
     *
     * @param typeName
     */
    public void setTypes(String typeName) {
        switchToOriginal();
        verifyAndSwitchFrame();
        webViewerFrame();
        $(clearBtn).click();
        Actions actions = new Actions(driver);
        By by = By.xpath("//label[text()='" + typeName + "']//..//div");
        actions.moveToElement($(by)).click().build().perform();
        $(applyBtn).click();
    }

    /**
     * Method to return the filtered types
     *
     * @param userName
     * @return
     */
    public boolean returnTypesDisplayed(String userName) {
        By by = By.xpath("//div[@class='author-and-date']//div[contains(text(),'" + userName + "')]");
        return $(by).isDisplayed();
    }


    /**
     * Method to click on the file
     *
     * @param fileName
     */
    public void selectFile(String fileName) {
        commonMethods.waitForElementExplicitly(8000);
        commonMethods.waitForElement(driver, fileDropDown, 60);
        $(fileDropDown).click();
        commonMethods.waitForElementExplicitly(4000);
        By by = By.xpath("//div[@class='document-list']//div[text()='" + fileName + "']");

//        actions.moveToElement($(by)).perform();
        $(by).click();
    }

    /**
     * Method to return the document number header value
     *
     * @return
     */
    public String returnDocNumberHeaderText() {
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, documentNumberHeader);
        return $(documentNumberHeader).getText();
    }

    /**
     * Method to click on next button
     */
    public void clickNextBtn() {
        $(nextBtn).click();

    }

    /**
     * Method to click on the arrow button
     */
    public void clickArrowBtn() {
        commonMethods.waitForElementExplicitly(10000);
        commonMethods.waitForElement(driver, nextBtn);
        if ($(nextBtn).getAttribute("disabled") == null) {
            $(nextBtn).click();
        } else {
            $(previousBtn).click();
        }
    }

    /**
     * Method to click on the submit review button
     */
    public void clickSubmitReviewBtn() {
        commonMethods.waitForElementExplicitly(5000);
        commonMethods.waitForElement(driver, submitReviewBtn, 4);
        $(submitReviewBtn).click();

    }

    /**
     * Method to review the next document, this is after you submit the first one when
     * multiple documents are present
     */
    public void reviewNextDoc() {
        commonMethods.waitForElementExplicitly(15000);
        List<WebElement> list = driver.findElements(reviewNextDoc);
        list.get(list.size() - 1).click();
    }

    /**
     * Method to return the value present by default in doc review list page
     *
     * @return
     */
    public String getReviewOutcome() {
        Select select = new Select($(reviewOutcomeSelect));
        WebElement option = select.getFirstSelectedOption();
        return option.getText();
    }


    /**
     * Method to click on the comments span
     */
    public void clickCommentsSpan() {
        commonMethods.waitForElement(driver, commentsSpan);
        $(commentsSpan).click();
    }

    /**
     * Method to verify if the note group is displayed
     *
     * @return
     */
    public boolean isNoteGroupDisplayed() {
        return $(notesGroup).isDisplayed();
    }


    /**
     * Method to click on the page widget container
     */
    public void clickDefaultPageWidget() {
        Actions actions = new Actions(driver);
        actions.moveToElement($(defaultPageWidgetContainer)).click().build().perform();
        // $(defaultPageWidgetContainer).click();
    }

    /**
     * select first viewer document from dropdown present in viewer screen
     */
    public void selectFirstFile() {
        commonMethods.waitForElementExplicitly(4000);
        commonMethods.waitForElement(driver, sltViewDocDropdown);
        $(sltViewDocDropdown).click();
        commonMethods.waitForElement(driver, btnFirstRecord);
        $(btnFirstRecord).click();
        commonMethods.waitForElementExplicitly(3000);
    }

    /**
     * Method to navigate between multiple documents in viewer page
     */
    public void verifyMultipleDocsNavigation(List<String> docs) {
        verifyAndSwitchFrame();
        selectFirstFile();
        commonMethods.waitForElement(driver, btnRight, 30);
        for (int i = 1; i < docs.size(); i++) {
            $(btnRight).click();
            commonMethods.waitForElementExplicitly(3000);
            Assert.assertTrue(docs.contains($(txtDocumentTitle).getText()));
            commonMethods.waitForElementExplicitly(3000);
        }
        for (int i = docs.size(); i > 1; i--) {
            $(btnLeft).click();
            commonMethods.waitForElementExplicitly(3000);
            Assert.assertTrue(docs.contains($(txtDocumentTitle).getText()));
            commonMethods.waitForElementExplicitly(3000);
        }
    }

    /**
     * Method to click on Consolidate mark ups link
     */
    public void clickConsolidateMarkups() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, lnkConsolidateMarkups, 30);
        $(lnkConsolidateMarkups).click();
    }

    /**
     * Method to click on Consolidate mark ups link
     */
    public void verifyMarkupsCount(int count) {
        verifyAndSwitchFrame();
        webViewerFrame();
        commonMethods.waitForElementExplicitly(10000);
        commonMethods.waitForElement(driver, notesPanelIcon, 60);
        Assert.assertEquals(count, Integer.parseInt($(txtCommentsCount).getText()));
    }

    /**
     * Method to download file from viewer mode
     */
    public void downloadFile() {
        verifyAndSwitchFrame();
        webViewerFrame();
        commonMethods.waitForElement(driver, btnDownload, 60);
        $(btnDownload).click();
    }

    /**
     * Method to verify expand and collapse of LHP and RHP
     */
    public void verifyPanels() {
        commonMethods.waitForElementExplicitly(30000);
        verifyAndSwitchFrame();
        webViewerFrame();
        if(!$(txtboxSearchComments).isDisplayed()){
            $(notesPanelIcon).click();
        }
        Assert.assertTrue($(txtboxSearchComments).isDisplayed());
        $(notesPanelIcon).click();
        Assert.assertFalse($(txtboxSearchComments).isDisplayed());
        $(btnLeftPanel).click();
        commonMethods.waitForElementExplicitly(2000);
        Assert.assertTrue($(btnThumbnails).isDisplayed());
        $(btnLeftPanel).click();
        commonMethods.waitForElementExplicitly(2000);
        Assert.assertFalse($(btnThumbnails).isDisplayed());
    }

    /**
     * Method to verify viewer mode page
     */
    public boolean verifyViewerModePage() {
        commonMethods.waitForElementExplicitly(10000);
        commonMethods.waitForElement(driver, pageContainer);
        return $(pageContainer).isDisplayed();
    }

    /**
     * Method to verify viewer mode markup options
     */
    public boolean verifyViewerOptions(String option) {
        return $(By.xpath("//div[@class='HeaderItems']//button[@aria-label='" + option + "']")).isDisplayed();
    }

    /**
     * Method to verify viewer mode page options
     */
    public void verifyDocModePageOptions() {
        commonMethods.waitForElement(driver, submitReviewBtn, 40);
        Assert.assertTrue($(documentNumber).isDisplayed());
        Assert.assertTrue($(docRevisionNumber).isDisplayed());
        Assert.assertTrue($(docTitle).isDisplayed());
        Assert.assertTrue($(backToListBtn).isDisplayed());
        Assert.assertTrue($(publishMarkups).isDisplayed());
        Assert.assertTrue($(submitReviewBtn).isDisplayed());
    }

    /**
     * Method to verify viewer mode Right panel doc outcome options
     */
    public void verifyRightPanelOptions() {
        commonMethods.waitForElement(driver, txtWFNum, 120);
        Assert.assertTrue($(txtWFNum).isDisplayed());
        Assert.assertTrue($(lnkTellUs).isDisplayed());
        Assert.assertTrue($(fileDropDown).isDisplayed());
        Assert.assertTrue($(btnLeft).isDisplayed());
        Assert.assertTrue($(btnRight).isDisplayed());
        Assert.assertTrue($(lnkSupplimentaryDocs).isDisplayed());
        Assert.assertTrue($(lnkFileComparison).isDisplayed());
        Assert.assertTrue($(tabReview).isDisplayed());
        Assert.assertTrue($(tabDocProperties).isDisplayed());
    }


    /**
     * Method to click on the left button for changing document
     */
    public void clickLeftButton() {
        commonMethods.waitForElement(driver, btnLeft);
        $(btnLeft).click();

    }

    /**
     * Method to add distance markup
     *
     * @param pageNumber
     */
    public void addDistance(int pageNumber) {
        $(distance).click();
        WebElement element = driver.findElement(By.xpath("//div[@id='pageWidgetContainer" + pageNumber + "']"));
        Actions actions = new Actions(driver);
        actions.dragAndDropBy(element, 10, 10).build().perform();
    }
}
