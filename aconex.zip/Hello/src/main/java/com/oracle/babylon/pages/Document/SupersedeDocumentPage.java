package com.oracle.babylon.pages.Document;

import com.oracle.babylon.Utils.helper.CommonMethods;
import com.oracle.babylon.Utils.helper.CommonMethods;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Selenide.*;

public class SupersedeDocumentPage extends DocumentPage {

    private By pageTitle = By.xpath("//h2[text()='Update Documents']");
    private By revision = By.xpath("//input[@name='revision']");
    private By version = By.xpath("//input[@title='Asset Version Number/Letter']");
    private By title = By.xpath("//input[@title='Title']");
    private By type = By.xpath("//select[@title='Type']");
    private By discipline = By.xpath("//select[@title='Discipline']");
    private By revisionDate = By.xpath("//input[@title='Revision Date']");
    private By supersedeDocumentBtn = By.xpath("//button[contains(text(),'Update Document')]");
    private By bulkSupersedeDocumentsBtn=By.xpath("//button//*[contains(text(),'Supersede Documents')]");
    private By editAccessList = By.xpath("//button[@id='btnEditAccessList']");
    private By supersedeDocBtn = By.xpath("//button[contains(text(),'Update')]");
    private By supersedeCloseBtn = By.xpath("//button[text()='Close']");
    public static String transmittedRevision = null;
    private By confidentialChkBox = By.xpath("//input[contains(@id,'confidential')]");
    private By attribute2 = By.xpath("//aui-select[@title='Attribute 2 List']");
    protected By userAccessList = By.xpath("//div[@class='auiDetails-value access-list']//span[@class='ng-binding ng-scope']");
    private final By accessListInput = By.xpath("//button[@id='btnEditAccessList']");
    private By clickToUploadLink = By.xpath("//div[@class='customFileUploadField ']/input[contains(@title,'File')]");
    private By successMessage = By.xpath("//div[@class='auiMessage success']");
    private By bulkSupersedeSuccessMsg=By.xpath("//li[@class='message success']//div[contains(text(),'The following assets have been superseded and moved to your register.')]");
    private By noChangesMessage = By.xpath("//div[text()='No changes were made to the document']");
    private By errorMessage = By.xpath("//div[text()='The document could not be superseded. Please check the highlighted fields.']");
    //private By clickToUploadLink = By.xpath("//div[@id='customFileField']//div//span[@class='clickToUpload ng-binding']");
    String filePath = System.getProperty("user.dir") + "/src/main/resources/data/files/";
    private By dateCreated = By.xpath("//input[@title='Date Created']");
    private By documentNumber = By.xpath("//label[text()='Document No']//..//..//div[2]//label");
    private By lockedMessage = By.xpath("//div[contains(text(),'This document is currently locked')]");
    private By editAccessOkBtn = By.xpath("//div[contains(text(),'OK')]");
    private By dropZoneFrame = By.xpath("//iframe[@class='smallDropZone supersedeDropZone']");
    private By documentAttachPanel = By.xpath("//div[@class='wrapper']//input[@name='qqfile']");
    private By btnSupersedeDocument = By.xpath("//div[text()='Supersede Document']");

    /**
     * Method to supersede the document according to the data values passed from the feature files
     * @param data
     * @return
     */
    public List<String> supersedeDocument(String data) {
        Map<String, String> table = dataStore.getTable(data);
        //According to the keys passed in the table, we select the fields
        commonMethods.waitForElement(driver, type, 60);
        for (String tableData : table.keySet()) {
            switch (tableData.toLowerCase()) {
                case "revision":
                    $(revision).clear();
                    $(revision).sendKeys(table.get(tableData));
                    break;
                case "type":
                    Select selectObj = new Select($(type));
                    selectObj.selectByVisibleText(table.get(tableData));
                    break;
                case "title":
                    $(title).clear();
                    $(title).sendKeys(table.get(tableData));
                    break;
                case "status":
                    $(status).click();
                    $(status).selectOptionContainingText(table.get(tableData));
                    break;
                case "discipline":
                    $(discipline).click();
                    $(discipline).selectOptionContainingText(table.get(tableData));
                    break;
                case "version":
                    $(version).clear();
                    $(version).sendKeys(table.get(tableData));
                    break;
                case "hasfile":
                    String fileName="";
                    if(table.containsKey("FileToUpload")){
                        fileName = table.get("FileToUpload");
                    } else{
                        fileName = "sample.png";
                    }

                    String[] docAttribute = table.get(tableData).split(",");
//                    verifyAndSwitchFrame(dropZoneFrame);
                    if (Boolean.parseBoolean(docAttribute[0])) {
                        if ((docAttribute.length) < 2) {
                            String document = filePath + fileName;
                            $(documentAttachPanel).sendKeys(document);
                        } else {
                            String document = filePath + docAttribute[1];
                            $(documentAttachPanel).sendKeys(document);
                        }
                    }
                    switchToOriginal();
                    verifyAndSwitchFrame();
                    break;
                case "confidential":
//                    getElementInView(attribute2);
                    String[] confidential = table.get(tableData).split(",");
                    $(confidentialChkBox).setSelected(Boolean.parseBoolean(confidential[0]));
                    if (confidential.length > 1) {
                        for (int i = 1; i < confidential.length; i++) {
                            jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
                            userMap = jsonMapOfMap.get(confidential[i]);
                            $(userField).sendKeys((userMap.get("full_name").toString()) + Keys.ENTER);
                            $(userField).sendKeys(Keys.ENTER);
                        }
                    }
                    break;
            }
        }
        List<String> accessList = verifyUserConfidentialList();
        HashMap<String, String> button = CommonMethods.getDocumentTypeDetail(getDocumentMenuName());
        commonMethods.waitForElementExplicitly( 8000);
        verifyAndSwitchFrame();
        By supersedeBtn = By.xpath("//button[contains(text(),'Update " + button.get("supersedebutton").trim() +"')]");
        commonMethods.waitForElement(driver, supersedeBtn, 30);
        commonMethods.waitForElementExplicitly(2000);
        $(supersedeBtn).click();
        commonMethods.waitForElementExplicitly(5000);
//        $(supersedeDocBtn).click();
        return accessList;
    }

    /**
     * Method to supersede the document according to the field identifiers passed.
     * Here we don't pass the values for the fields. Dynamically field values are generated
     * WIP, more code will be added
     * @param list
     * @return
     */
    public void supersedeMaxLength(List<Map<String, String>> list) {
        super.enterMaxFieldValues(list);
        commonMethods.waitForElementExplicitly(4000);
        $(supersedeDocBtn).click();
    }

    /**
     * Method to supersede the document revision
     */
    public void supersedeRevision() {
        if (DocumentPropertiesPage.lastRevision.equals("A")) {
            $(revision).clear();
            $(revision).sendKeys("B");
        } else if (DocumentPropertiesPage.lastRevision.equals("B")) {
            $(revision).clear();
            $(revision).sendKeys("A");
        }
        $(supersedeDocBtn).click();
    }

    /**
     * Function to set document functionality
     *
     * @param flag true or false
     */
    public void setConfidentiality(String flag) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        $(confidentialChkBox).setSelected(Boolean.parseBoolean(flag));
    }

    /**
     * Function to click supersede button
     */
    public void clickSupersedeBtn() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver,supersedeDocumentBtn);
        $(supersedeDocumentBtn).click();
    }

    /**
     * Method to click on the edit the access list
     */
    public void clickEditAccessList() {
        verifyAndSwitchFrame();
        $(editAccessList).click();
    }


    /**
     * Function to get list of user added to the list
     */
    public List<String> verifyUserConfidentialList() {
        verifyAndSwitchFrame();
        List<String> users = new ArrayList<>();
//        getElementInView(attribute2);
        if ($(userField).isDisplayed()) {
            sleep(2000);
           List<WebElement> element = driver.findElements(userAccessList);
            for(int i=0;i<element.size();i++){
            users.add(element.get(i).getText());}
            return users;
        } else return null;
    }

    /*
     * Function to remove confidentiality while supersede
     */
    public void removeConfidentiality() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, revision,30);
        $(revision).clear();
        $(revision).sendKeys("B");
        commonMethods.waitForElement(driver,attribute2,35);
//        getElementInView(attribute2);
        $(confidentialChkBox).setSelected(false);
        verifyAlert("This action will make this document visible to all");
        verifyAndSwitchFrame();
        $(supersedeDocBtn).click();
    }

    /**
     * Function to upload file while superseding a document
     */

    public void uploadFile(String fileLocation, String fileName) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, btnSupersedeDocument,60);
        $(clickToUploadLink).sendKeys(new File(fileLocation + "/" + fileName).getAbsolutePath());
    }

    /**
     * Method to click the supersede done button.
     * Separated it as we had to retrieve the superseded document number
     */
    public void clickSupersedeClose() {
        commonMethods.waitForElement(driver, supersedeCloseBtn, 35);
        $(supersedeCloseBtn).click();
    }



    /**
     * Method to return the superseded document number
     *
     * @return
     */
    public Boolean validateDocNumberField() {
        return $(documentNumberField).isDisplayed();
    }


    /**
     * Method to return the revision
     *
     * @return
     */
    public String returnRevision() {
        commonMethods.waitForElementExplicitly(500);
        commonMethods.waitForElement(driver, revision, 60);
        return $(revision).getAttribute("value");
    }

    /**
     * Method to return the title
     *
     * @return
     */
    public String returnTitle() {
        return $(title).getText();
    }
    /**
     * Method to validate superseded success message
     *
     * @return
     */

    /**
     * Method to return the selected status
     *
     * @return
     */
    public String returnSelectedStatus() {
        return $(status).getSelectedText();
    }

    /**
     * Method to validate if supersede operation is successful
     * @return
     */
    public void validateSuccessMessage() {
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, docUploadSuccess, 30);
        Assert.assertTrue("Document is not upload successfully", $(docUploadSuccess).isDisplayed());
    }
    /**
     * Method to validate if bulk supersede operation is successful
     *
     */
    public void validateBulkSuccessMessage() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver,bulkSupersedeSuccessMsg);
        Assert.assertTrue($(bulkSupersedeSuccessMsg).isDisplayed());
    }


    /**
     * Method to validate the doucment Number
     *
     * @return
     */

    public boolean validateDocumentNo(String docNo) {
        return $(By.xpath("//div[@class='auiMessage success']//strong[contains(text(),'"+docNo+"')]")).isDisplayed();
    }

    /**
     * Method to validate when no changes are done to the values, we
     * get the appropriate message
     * @return
     */
    public boolean validateNoChanges() {
        return $(noChangesMessage).isDisplayed();

    }

    /**
     * Method to validate if the done button exists after supersede is complete
     * @return
     */
    public boolean validateDoneBtn(){
        return $(supersedeCloseBtn).isDisplayed();
    }

    /**
     * Method to validate if appropriate messages are displayed when
     * mandatory fields are missing
     * @param label name of the mandatory field
     * @return
     */
    public boolean missingMandatoryField(String label) {
        By by = By.xpath("//label[text()='" + label + "']//parent::div//parent::div//acx-validation-hint");
        return $(by).getText().contains("This field is required.");
    }

    /**
     * Method to return the created date for the page
     * @return
     */
    public String returnRevisionDateFormat(){
        return $(revisionDate).getAttribute("format");
    }

    public void enterRevisionDate(String value){
        commonMethods.waitForElement(driver, revisionDate, 60);
        $(revisionDate).sendKeys(value);
        $(revisionDate).pressEnter();
    }



    /**
     * Method to validate the page title for the supersede page
     * @return
     */
    public boolean validatePageTitle(){
        return $(pageTitle).isDisplayed();
    }

    /**
     * Method to validate the page title for the supersede page
     * @return
     */
    public boolean verifyLockedErrorMessage(String user){
        String userName = commonMethods.getUserData(user,"name");
        Assert.assertTrue($(By.xpath("//div[contains(text(),'"+userName+"')]")).isDisplayed());
        return $(lockedMessage).isDisplayed();
    }


    /**
     * Duplicate method from Add Documents page as identifier is different
     * @param fileName
     */
    public void attachDocument(String fileName) {
        String filePath = configFileReader.getTestDataPath() + fileName;
        File file = new File(filePath);
        filePath = file.getAbsolutePath();
        $(documentAttachPanel).sendKeys(filePath);

    }

    /**
     * Method to click on Supersede document button for legacy update document page
     *
     */
    public void clickSupersedeDocument() {
        commonMethods.waitForElement(driver, btnSupersedeDocument, 10);
        $(btnSupersedeDocument).click();
    }

}