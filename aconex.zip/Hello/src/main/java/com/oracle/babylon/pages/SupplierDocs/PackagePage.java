package com.oracle.babylon.pages.SupplierDocs;

import com.github.javafaker.Faker;
import com.oracle.babylon.Utils.helper.Navigator;
import com.oracle.babylon.Utils.setup.dataStore.DataSetup;
import com.oracle.babylon.Utils.setup.utils.ConfigFileReader;
import com.oracle.babylon.pages.Document.DocumentPage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.Random;

import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Selenide.$;

public class PackagePage extends Navigator {
    ConfigFileReader configFileReader = new ConfigFileReader();
    private String userDataPath = configFileReader.getUserDataPath();
    private String sdDataPath = configFileReader.getSDDataPath();
    //Initialization of Web Elements
    private By sdNumber = By.xpath("//input[@id='number']");
    private By description = By.xpath("//input[@id='description']");
    private By suppliedByOrg = By.xpath("//input[@id='supplierOrgId_query']");
    private By suppliedByUser = By.xpath("//input[@id='supplierUsers_query']");
    private By turnAroundDays = By.xpath("//input[@id='supplierTurnaround']");
    private By activateBtn = By.xpath("//button[@id='btnActivate']");
    private By saveToDraftBtn = By.xpath("//button[@id='btnSaveToDraft']");
    private By pageTitle = By.xpath("//h1[contains(text(),'New Supplier Document Package')]");
    private By addDocumentsBtn = By.xpath("//button[@id='btnAddDocumentsMenu']");
    private By docRegisterLink = By.xpath("//a[text()='Add from Document Register']");
    private By addViaBulkProcessing = By.xpath("//a[text()='Add via Bulk Processing']");
    private By successMsg = By.xpath("//div[contains(text(),'document has been successfully added to this package')]");
    private By closeBtn = By.xpath("//button[@id='btnexcludedDocs_ok']");

    /**
     * Method to navigate to create package page
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Supplier Documents", "Package");
        $(loadingIcon).should(disappear);
        commonMethods.waitForElementExplicitly(2000);
        Assert.assertTrue(verifyPageTitle(pageTitle));
    }

    /**
     * Create a basic package for requesting supplier documents
     * @param fromUserId
     * @param toUserId
     * @return
     */
    public String createPackage(String fromUserId, String toUserId, String sdId)
    {
        verifyAndSwitchFrame();
        String supplierDocNo=enterMandatoryFields(fromUserId,toUserId);
        $(activateBtn).click();
        commonMethods.waitForElementExplicitly(500);
        driver.switchTo().alert().accept();
        commonMethods.waitForElementExplicitly(2000);
        writeSdNumToJson(sdId,supplierDocNo);
        return supplierDocNo;
    }

    /**
     * Method to click the add documents button
     */
    public void clickAddDocuments(){
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver,addDocumentsBtn,30);
        $(addDocumentsBtn).click();
    }

    /**
     * Method to select document register link
     */
    public void clickDocRegisterLink(){
        commonMethods.waitForElement(driver,docRegisterLink,30);
        $(docRegisterLink).click();
    }
    /**
     * Method to select document register link
     */
    public void clickAddViaBulkProcessing(){
        $(addViaBulkProcessing).click();
    }
    public void attachDocsFrame(){
        verifyAndSwitchFrame("attachDocs_frame");
    }

    public void attachDocument(String documentNumber){
        attachDocsFrame();
        DocumentPage documentPage = new DocumentPage();
        commonMethods.waitForElementExplicitly(3000);
        documentPage.searchDocumentNo(documentNumber);
        documentPage.selectAllRecords();
        documentPage.switchToOriginal();
        documentPage.verifyAndSwitchFrame();
        documentPage.clickAttachBtn();
        commonMethods.waitForElementExplicitly(3000);
    }

    public boolean validateDocAddition(){
        commonMethods.waitForElement(driver,successMsg);
        return $(successMsg).isDisplayed();
    }
    /**
     * Method to get summary count based on the progress name
     */
    public String getSummaryCount (String progressName)
    {
        return $(By.xpath("//tr[@class='"+progressName+"']//td[2]")).getText();
    }
    public String getProgressPercent(String progressName)
    {
        return $(By.xpath("//tr[@class='"+progressName+"']//td[3]")).getText();
    }
    public void clickCloseBtn(){
        $(closeBtn).click();
    }

    public String getPackageNumber(String sdNumber){
        Map<String, Map<String, Object>> jsonData = new HashMap<>();
        Map<String, Object> map = new HashMap<>();
        jsonData = dataSetup.loadJsonDataToMap(sdDataPath);
        map = jsonData.get(sdNumber);
        return map.get("package_number").toString();
    }

    public String enterMandatoryFields(String fromUserId,String toUserId)
    {
        DataSetup dataSetup = new DataSetup();
        Map<String, Object> fromUserMap = dataSetup.loadJsonDataToMap(userDataPath).get(fromUserId);
        Map<String, Object> toUserMap = dataSetup.loadJsonDataToMap(userDataPath).get(toUserId);
        //Generating values required
        String fromOrgName = fromUserMap.get("org_name").toString();
        String toOrgName = toUserMap.get("org_name").toString();
        String toUserName = toUserMap.get("full_name").toString();
        Random random = new Random();
        Faker faker = new Faker();
        String supplierDocNo = faker.name().firstName() + "-" + random.nextInt();
        $(sdNumber).clear();
        $(sdNumber).sendKeys(supplierDocNo);
        $(suppliedByOrg).clear();
        $(suppliedByOrg).sendKeys(toOrgName+Keys.ENTER);
        commonMethods.waitForElementExplicitly(5000);
        By xpath = By.xpath("//a[text()='" + toOrgName + "']");
        if($(xpath).exists())
            $(xpath).click();
        commonMethods.waitForElement(driver,suppliedByUser);
        $(suppliedByUser).sendKeys(toUserName+Keys.ENTER);

        commonMethods.waitForElementExplicitly(2000);
        //$(suppliedByUser).sendKeys(Keys.ENTER);
        $(description).sendKeys("Documents required for : " + fromOrgName);
        commonMethods.waitForElement(driver, turnAroundDays);
        $(turnAroundDays).clear();
        $(turnAroundDays).sendKeys("8");
        return supplierDocNo;
    }

    public String saveDraft(String fromUserId, String toUserId, String sdId)
    {
        verifyAndSwitchFrame();
        String draftSupplierDocNo=enterMandatoryFields(fromUserId,toUserId);
        clickSaveToDraft();
        writeSdNumToJson(sdId,draftSupplierDocNo);
        return draftSupplierDocNo;
    }

    public void clickSaveToDraft()
    {
        commonMethods.waitForElement(driver,saveToDraftBtn);
        $(saveToDraftBtn).click();
    }

    public void writeSdNumToJson(String sdId,String supplierDocNo)
    {
        //Write the data to the json file
        Map<String, Object> map = new Hashtable<>();
        Map<String, Map<String, Object>> mapOfMap = new HashMap<>();
        map.put("package_number", supplierDocNo);
        mapOfMap.put(sdId, map);
        dataSetup.fileWrite(sdId, mapOfMap, sdDataPath);
    }
}
