package com.oracle.babylon.pages.User;

import com.github.javafaker.Faker;
import com.oracle.babylon.Utils.helper.Navigator;
import com.oracle.babylon.pages.Tasks.TaskPage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import java.util.Hashtable;
import java.util.Locale;
import java.util.Map;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.sleep;

/**
 * Class to fill the details of the user during organization registration page
 * Author : susgopal
 */
public class NewAccountDetails extends Navigator {

    //Initialization of the Web Elements
    private By titleDrpDwn = By.id("userTitle");
    private By jobFunctionDrpDwn = By.id("jobFunction");
    private By language = By.xpath("//select[@id='selLanguages']");
    private By job_title_txt_box = By.xpath("//div[@id='position']//input");
    private By saveBtn = By.id("btnSave");
    private By password = By.xpath("//div[@id='password']//input[@class='uiPasswordField-input']");
    private By confirmPassword = By.xpath("//div[@id='passwordConfirm']//input[@class='uiPasswordField-input']");
    private By directoryListing = By.xpath("//input[@id='globalDirectoryOptIn_radio']");
    private Faker faker = new Faker(new Locale("en-US"));
    private By newPassword = By.xpath("//input[@id='NEW_PASSWORD']");
    private By confirmNewPassword = By.xpath("//input[@id='CONFIRM_PASSWORD']");
    Map<String, Map<String, Object>> mapOfMap = new Hashtable<>();
    Map<String, Object> mapToReplace = new Hashtable<>();
    private By enterAconexLink = By.xpath("//a[contains(text(),'Enter Aconex')]");
    private By passwordChangeMsg = By.xpath("//div[@id='messagePanel']");
    private By header = By.xpath("//h1[@class='nav-barRow']");
    private By welcomeHeader = By.xpath("//h1[@class='nav-barRow']");

    TaskPage taskPage = new TaskPage();


    public void verifyPage() {
        //Added the code directly because page does not have a frame
        commonMethods.waitForElement(driver, welcomeHeader, 30);
        sleep(1500);
        String headerName = $(welcomeHeader).text();
        Assert.assertTrue(headerName.contains("Welcome to your new account"));

    }

    /**
     * Function to fill the details of the user
     *
     * @param userDetailsMap
     */
    public void fillUserDetails(Map<String, String> userDetailsMap, String userId) {
        if ($(titleDrpDwn).isDisplayed()) {
            Select select = new Select($(titleDrpDwn));
            select.selectByValue(userDetailsMap.get("Title"));
            select = new Select($(jobFunctionDrpDwn));
            $(jobFunctionDrpDwn).click();
            select.selectByVisibleText(userDetailsMap.get("Job_Function"));
            $(jobFunctionDrpDwn).pressEscape();
            $(job_title_txt_box).click();
            $(job_title_txt_box).sendKeys(userDetailsMap.get("Job_Title"));
            $(language).selectOptionContainingText(userDetailsMap.get("Language"));
            String newPasswordValue = null;
            if ($(password).exists()) {
                //Password for fedRAMP has more strcut rules.
                newPasswordValue = "$" + faker.internet().password(8, 10, true) + faker.number().digits(4);
                $(password).sendKeys(newPasswordValue);
                $(confirmPassword).sendKeys(newPasswordValue);


            }

            String[] keys = {"username", "password", "full_name", "job_title"};
            Map<String, Map<String, Object>> mapOfMap = new Hashtable<>();
            Map<String, Object> valueMap = new Hashtable<>();
            if (newPasswordValue != null) {
                valueMap.put(keys[1], newPasswordValue);
            }
            valueMap.put(keys[3], userDetailsMap.get("Job_Title"));
            mapOfMap.put(userId, valueMap);
            dataSetup.fileWrite(userId, mapOfMap, userDataPath);
            if ($(directoryListing).exists()) {
                $(directoryListing).click();
            }
            $(saveBtn).click();
            commonMethods.waitForElementExplicitly(2000);

        } else {
            System.out.println("User details are already filled");
        }
    }

    /**
     * Function to change password
     *
     * @param user
     */
    public void changePassword(String user) {
        replacePassword(user, resetPassword(user));
        navigate();
    }

    /**
     * Function reset new password
     *
     * @param user
     * @return
     */
    public String resetPassword(String user) {
        //commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, newPassword, 40);
        String password = faker.internet().password(8, 12, true);
        password = password + "@08";
        $(newPassword).sendKeys(password);
        $(confirmNewPassword).sendKeys(password);
        $(saveBtn).click();
        commonMethods.waitForElement(driver, passwordChangeMsg, 40);
        Assert.assertTrue($(passwordChangeMsg).text().contains("Your password has been successfully updated"));
        return password;
    }

    /**
     * Function to replace password with new
     *
     * @param user
     */
    public void replacePassword(String user, String password) {
        mapToReplace.put("password", password);
        mapOfMap.put(user, mapToReplace);
        dataSetup.fileWrite(user, mapOfMap, configFileReader.getUserDataPath());
        $(enterAconexLink).click();
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Function to navigate to Task page and verify
     */
    public void navigate() {
        commonMethods.waitForElementExplicitly(3000);
        verifyAndSwitchFrame();
        taskPage.navigateAndVerifyPage();
    }


}
