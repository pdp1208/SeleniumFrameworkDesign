package com.oracle.babylon.Utils.setup.dataStore;

import com.oracle.babylon.Utils.setup.dataStore.pojo.*;
import io.cucumber.datatable.DataTable;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Class that ensures we have a copy of the data from the data tables across test case files in a execution
 * Author : vsinghsi
 */
public class DataStore {

    //Object initialization and assigning references to it
    public static Map<String, Map<String, String>> hashDataTable = new HashMap<>();
    private static Map<String, List<String>> hashSingleTable = new HashMap<>();
    private static Map<String, User> userHashMap = new HashMap<>();
    private static Map<String, Ticket> ticketHashMap = new HashMap<>();
    private static Map<String, Document> documentHashMap = new HashMap<>();
    private static Map<String, Organization> organizationHashMap = new HashMap<>();
    private static Map<String, Project> projectHashMap = new HashMap<>();
    private static Map<String, Object> attributeList = new HashMap<>();
    private static Map<String, Object> attributeHashMap = new HashMap<>();
    private static Map<String,Object> mailtypeHashMap = new HashMap<>();
    private static Map<String,List<Map<String,String>>> hashmapList = new HashMap<>();
    /**
     * Function to add the user details in a hash map
     *
     * @param username name of the table
     * @param user     user information pojo
     */
    public void addUser(String username, User user) {
        if (userHashMap.containsKey(username)) {
            userHashMap.remove(username);
        }
        userHashMap.put(username, user);
    }

    /**
     * Function to return a hash map of the user details
     *
     * @param username name of the table in data store
     * @return
     */
    public User getUser(String username) {
        return userHashMap.get(username);
    }

    /**
     * Function to create a hash map of the ticket details
     *
     * @param name   name of the table in data store
     * @param ticket
     * @return hash map containing ticket details
     * @ticket ticket details pojo
     */
    public void addTicket(String name, Ticket ticket) {
        if (ticketHashMap.containsKey(ticket)) {
            ticketHashMap.remove(name);
        }
        ticketHashMap.put(name, ticket);
    }

    /**
     * Function that returns the ticket details in hash map
     *
     * @param name name of the table in the data store
     * @return
     */
    public Ticket getTicket(String name) {
        return ticketHashMap.get(name);
    }


    /**
     * Function to create a hash map from a data table
     *
     * @param name      name of the data table
     * @param dataTable the contents of the data table
     */
    public void setTable(String name, DataTable dataTable) {
        Map<String, String> hashTable = dataTable.asMap(String.class, String.class);
        hashDataTable.put(name, hashTable);
        if (hashTable.containsKey(name)) {
            hashTable.remove(name);
        }
        getTable(name);
    }

    /**
     * Function to create a hash map from a data table
     *
     * @param name      name of the data table
     * @param dataTable the contents of the data table
     */
    public void setSingleTable(String name, List<String> dataTable) {
        List<String> hashTable = dataTable;
        hashSingleTable.put(name, hashTable);
        if (hashTable.contains(name)) {
            hashTable.remove(name);
        }
        getSingleTable(name);
    }

    /**
     * Function to create a hash map from a data table
     *
     * @param name      name of the data table
     * @param hashTable the contents of the data table
     */
    public void setTable(String name, Map<String, String> hashTable) {
        hashDataTable.put(name, hashTable);
        if (hashTable.containsKey(name)) {
            hashTable.remove(name);
        }
        getTable(name);
    }

    /**
     * Function to return the hash map of the table
     */
    public Map<String, String> getTable(String tableName) {
        return hashDataTable.get(tableName);
    }

    /**
     * Function to return the hash map of the table
     */
    public List<String> getSingleTable(String tableName) {
        return hashSingleTable.get(tableName);
    }

    /**
     * Create a hash map for the Organization data
     *
     * @param name         key value in the data store
     * @param organization Pojo of the organization that contains the values
     */
    public void storeOrganizationInfo(String name, Organization organization) {
        if (organizationHashMap.containsKey(name)) {
            organizationHashMap.remove(name);
        }
        organizationHashMap.put(name, organization);
    }

    /**
     * Function to return the Organization details in a hash map
     *
     * @param name name of the table in data store
     * @return
     */
    public Organization getOrganizationInfo(String name) {
        return organizationHashMap.get(name);
    }

    /**
     * Function to create a Project hash map
     *
     * @param name    name of the data table
     * @param project pojo of the Project that contains values
     */
    public Map<String, Project> storeProjectInfo(String name, Project project) {
        if (projectHashMap.containsKey(name)) {
            projectHashMap.remove(name);
        }
        projectHashMap.put(name, project);
        return projectHashMap;
    }

    /**
     * Function to return the project details in a hash map
     *
     * @param name
     * @return
     */
    public Project getProjectInfo(String name) {
        return projectHashMap.get(name);
    }

    /**
     * Function to store the attribute value in a data store
     *
     * @param key
     * @param valuesList
     */
    public void storeAttributeInfo(String key, List<String> valuesList) {
        if (key.contains(" ")) {
            key = key.replace(" ", "");
        }
        attributeHashMap.put(key, valuesList);
    }

    /**
     * Function to return the Attributes in a hash map
     *
     * @return
     */

    public Map<String, Object> getAttributeHashMap() {
        return attributeHashMap;
    }

    /**
     * Function to store the Mail Types in a data store
     *
     * @param key
     * @param valuesList
     */
    public void storeMailTypeInfo(String key, List<String> valuesList) {
        if (key.contains(" ")) {
            key = key.replace(" ", "");
        }
        mailtypeHashMap.put(key, valuesList);
    }

    /**
     * Function to return Mail Types in a hash map
     *
     * @return
     */

    public Map<String, Object> getMailTypeHashMap() {
        return mailtypeHashMap;
    }

    /**
     * Function to create a list with hash map from a data table
     *
     * @param name      name of the data table
     * @param dataTable the contents of the data table
     */
    public void setListTable(String name, DataTable dataTable) {
        List<Map<String, String>> list = dataTable.asMaps(String.class, String.class);
        hashmapList.put(name,list);
        getListTable(name);
    }

    /**
     * Function to return the list which has map of the table
     */
    public List<Map<String, String>> getListTable(String tableName) {
        return hashmapList.get(tableName);
    }

}

