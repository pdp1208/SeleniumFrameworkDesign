package com.oracle.babylon.pages.Report;

import com.codeborne.selenide.Condition;
import com.oracle.babylon.Utils.helper.Navigator;
import org.openqa.selenium.By;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Condition.*;

public class WaitOptionDialog extends Navigator {

    public By waitingOption = By.xpath("//div[@id='waitOptionsDialog']");
    private By keepWaiting = By.xpath("//button[text()='Keep waiting']");

    public void keepWaiting(){
        $(keepWaiting).waitUntil(appears,10000).click();
    }
}

