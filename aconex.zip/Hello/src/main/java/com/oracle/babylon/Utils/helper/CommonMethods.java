package com.oracle.babylon.Utils.helper;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.WebDriverRunner;
import com.github.javafaker.Faker;
import com.google.gson.Gson;
import com.oracle.babylon.Utils.setup.dataStore.DataSetup;
import com.oracle.babylon.Utils.setup.utils.ConfigFileReader;
import com.oracle.babylon.pages.Admin.AdminSearch;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.XML;
import org.junit.Assert;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.*;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.*;
import java.net.HttpURLConnection;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.codeborne.selenide.Selenide.*;

/**
 * Class containing all the common methods required for the framework
 * Author : susgopal, vsingsi
 */
public class CommonMethods {

    protected Map<String, Map<String, Object>> jsonMapOfMap = null;
    private ConfigFileReader configFileReader = new ConfigFileReader();
    protected Map<String, Object> mailMap = null;
    protected WebDriver driver = null;
    protected Map<String, Object> docMap = null;
    private DataSetup dataSetup = new DataSetup();
    String mailFilePath = configFileReader.getMailDataPath();
    String docFilePath = configFileReader.getDocumentDataPath();
    private String groupPath = configFileReader.getGroupManagementDataPath();
    Map<String, Map<String, Object>> mapOfMap = new Hashtable<>();
    Map<String, Object> mapToReplace = new Hashtable<>();
    String userDataPath = configFileReader.getUserDataPath();
    String workflowPath = configFileReader.getWorkflowDataPath();
    String tenderDataPath = configFileReader.getTenderDataPath();
    public By btnTrash = By.xpath("//div[@class='auiIcon trash']");
    protected Map<String, Object> userMap = null;
    protected Map<String, Object> tenderMap = null;
    protected Map<String, Object> wfMap = null;
    protected Map<String, Object> sdMap = null;
    protected Map<String, Object> packageMap = null;
    public static String randomString = null;
    Faker faker = new Faker();
    String projectFieldsPath = configFileReader.getProjectFieldsDataPath();
    String docNumberingpath = configFileReader.getDocNumberingDataPath();
    String sdDataPath = configFileReader.getSDDataPath();
    String packageDataPath = configFileReader.getPackageDataPath();
    String packageTemplatePath = configFileReader.getPackageTemplateDataPath();
    By selectList = By.xpath("//div[@class='selectize-dropdown-content ng-scope']/div//div");

    /**
     * Takes the screenshot of the current browser window
     */
    public static byte[] takeSnapshot(WebDriver driver) {
        TakesScreenshot screenshot = ((TakesScreenshot) driver);
        final byte[] screenshotBytes = screenshot.getScreenshotAs(OutputType.BYTES);
        return screenshotBytes;
    }

    /**
     * Wait for a element to be visible for 5 seconds
     *
     * @param driver
     * @param by
     * @return
     */
    public WebDriver waitForElement(WebDriver driver, By by) {
        $(by).waitUntil(Condition.visible, 15000);
        return driver;
    }

    /**
     * Method to wait for the element to be visible for param seconds
     *
     * @param driver
     * @param by      attribute identifier
     * @param seconds
     * @return
     */
    public WebDriver waitForElement(WebDriver driver, By by, int seconds) throws TimeoutException {
        try {
            WebDriverWait wait = new WebDriverWait(driver, seconds);
            wait.until(ExpectedConditions.or(ExpectedConditions.visibilityOfElementLocated(by)));
        } catch (TimeoutException e) {
            throw new TimeoutException("Locator Not Found :" + by);
        }
        return driver;
    }

    /**
     * Method to switch the frame
     *
     * @param driver
     * @param frameId
     * @return
     */
    public WebDriver switchToFrame(WebDriver driver, String frameId) {
        By frame = By.xpath("//iframe[@id='" + frameId + "']");
        waitForElement(driver, frame, 30);
        try {
            driver.switchTo().frame(driver.findElement(frame));
        } catch (WebDriverException e) {
            try {
                if (e.toString().contains("cannot determine loading status")) {
                    sleep(4000);
                }
                sleep(2000);
                driver.switchTo().frame(driver.findElement(frame));
            } catch (NoSuchElementException nsee) {
                throw new NoSuchElementException(nsee.toString());
            }
        }
        return driver;
    }

    /**
     * Function to switch the frame with the element attribute insted of the id
     * If we do not have a id attribute for the frame, we need to use other attributes
     *
     * @param driver
     * @param by
     * @return
     */
    public WebDriver switchToFrame(WebDriver driver, By by) {
        driver.switchTo().frame(driver.findElement(by));
        return driver;
    }

    /**
     * Method to wait for a element explicitly for the millis provided
     *
     * @param millis
     */
    public void waitForElementExplicitly(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * public void waitForSearchLoadingToComplete(WebDriver driver, By by, String searchText) {
     * WebDriverWait wait = new WebDriverWait(driver, 30);
     * wait.until(ExpectedConditions.invisibilityOfElementWithText(by, searchText));
     * }
     */


    /**
     * Method to convert the API response to the string that can be parsed
     *
     * @param entity
     * @return
     * @throws IOException
     */
    public static String entityToString(HttpEntity entity) throws IOException {
        InputStream is = entity.getContent();
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(is));
        //Using string builder to read the entity and convert to string
        StringBuilder str = new StringBuilder();
        String line = null;
        try {
            while ((line = bufferedReader.readLine()) != null) {
                str.append(line + "\n");
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            try {
                is.close();
            } catch (IOException e) {

            }
        }
        return str.toString();
    }

    public static String convertMaptoJsonString(Object src) {
        return new Gson().toJson(src);
    }

    /**
     * Function to convert map into json string
     * @param src
     * @return
     */
    public static String convertMaptoJsonString(Map<String, String> src) {
        return new Gson().toJson(src);
    }

    /**
     * Function to search the project and return the project id
     *
     * @param projectName
     * @return project id
     */
    public String searchProject(String projectName) {
        AdminSearch adminSearch = new AdminSearch();
        return adminSearch.returnResultId(projectName);
    }

    /**
     * Function to convert the json string to xml string. Helps in building api request body for Aconex API.
     * Standard format required is XML based
     *
     * @param jsonString
     * @return
     */
    public String convertJsonStringToXMLString(String jsonString) {
        JSONObject jsonObject = new JSONObject(jsonString);
        return XML.toString(jsonObject);
    }

    /**
     * Function to convert UI table from the search to a Hash Map
     * Single result ui table
     *
     * @param driver
     * @param tableElement table identifier
     * @param rowElement   row identifier
     * @return
     */
    public Map<Integer, Map<String, String>> convertUITableToHashMap(WebDriver driver, By tableElement, By
            rowElement) {

        List<String> columns = returnColumnHeaders(driver, tableElement);
        Map<Integer, List<String>> rowsMap = returnRows(driver, rowElement);
        Map<Integer, Map<String, String>> tableOfMaps = new Hashtable<>();
        for (int key : rowsMap.keySet()) {
            Map<String, String> tableHashMap = new HashMap<>();
            int i = 0;
            for (String columnHeader : columns) {
                tableHashMap.put(columnHeader, rowsMap.get(key).get(i));
                i++;
            }
            tableOfMaps.put(key, tableHashMap);
        }
        return tableOfMaps;

    }

    /**
     * Function to fetch the column headers and store it in a list
     *
     * @param driver
     * @param tableElement table identifier
     * @return list of column headers
     */
    public List<String> returnColumnHeaders(WebDriver driver, By tableElement) {
        List<WebElement> listOfColumns = driver.findElement(tableElement).findElements(By.xpath("//thead//tr//th"));
        List<String> columnHeaders = new ArrayList<String>();
        for (WebElement element : listOfColumns) {

            columnHeaders.add(element.getText());

        }
        return columnHeaders;
    }

    /**
     * Method to return the list of list of rows.
     * Used when multiple results are visible in the ui
     *
     * @param driver
     * @param rowIdentifier
     * @return
     */
    public Map<Integer, List<String>> returnRows(WebDriver driver, By rowIdentifier) {
        List<WebElement> listOfRows = driver.findElements(rowIdentifier);
        String identifier = rowIdentifier.toString().substring(rowIdentifier.toString().indexOf('/'));

        Map<Integer, List<String>> rowCellData = new Hashtable<>();
        for (int i = 0; i < listOfRows.size(); i++) {
            List<String> individualCellData = new ArrayList<String>();
            //Storing individual cell of a row in a list
            int index = i + 1;
            List<WebElement> cellElements = driver.findElements(By.xpath(identifier + "[" + index + "]//td"));
            for (WebElement individualCellElements : cellElements) {
                individualCellData.add(individualCellElements.getText());
            }
            //Storing individual row in a list
            rowCellData.put(i, individualCellData);
        }
        return rowCellData;
    }

    /**
     * Function to validate if the attribute with a certain value is present
     *
     * @param by        element to validate
     * @param attribute attribute to validate
     * @return the status of the validation
     */
    public boolean isElementAttributePresent(By by, String attribute) {
        String value = $(by).getAttribute(attribute);
        if (value != null && value.equals("true")) {
            return true;
        }
        return false;
    }

    /**
     * Function to return the value of an attribute from a Web Element
     *
     * @param by
     * @param attribute
     * @return
     */
    public String returnElementAttributeValue(By by, String attribute) {
        return $(by).getAttribute(attribute);
    }


    /**
     * Function to select the attribute 'li' that we need to change the settings for
     *
     * @param linkText
     */
    public void clickListToChange(By pageHeader, String linkText) {
        $(pageHeader).isDisplayed();
        $(By.xpath("//li[text()='" + linkText + "']")).click();

    }

    /**
     * Function to select the link that we need to change the settings for
     */
    public void clickLinkToChange(WebDriver driver, By pageHeader, By by) {
        waitForElement(driver, by, 30);
        $(pageHeader).isDisplayed();
        $(by).click();
    }

    /**
     * Method to fetch the values of the rows for a table column
     *
     * @param driver
     * @param rowNumber
     * @param columnName
     * @return
     */
    public String getColumnValue(WebDriver driver, Map<Integer, Map<String, String>> tableData,
                                 int rowNumber, String columnName) {
        Map<String, String> tableRow = tableData.get(rowNumber);
        String columnValue = tableRow.get(columnName);
        driver.switchTo().defaultContent();
        return columnValue;

    }

    /**
     * Verifying scrollbar in dropdown
     *
     * @driver driver obj
     * @element is the element inside which scrollbar is present
     */
    public boolean verifyScrollbar(WebDriver driver, WebElement element) {
        String JS_ELEMENT_IS_SCROLLABLE = "return arguments[0].scrollHeight > arguments[0].offsetHeight;";
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        Boolean isScrollable = (Boolean) jse.executeScript(JS_ELEMENT_IS_SCROLLABLE, element);
        return isScrollable;

    }

    /**
     * Getting the values from dropdown
     *
     * @driver driver obj
     * @columnName is the column from where the values has to be retrived
     */

    public List<String> getDropdownValues(WebDriver driver, String columnName) {
        $(By.xpath("//div[contains(text(),'" + columnName + "')]//..//div[2]")).click();
        List<String> dropdownValues = new ArrayList<>();
        List<WebElement> allElements = driver.findElements(selectList);
        for (WebElement e : allElements) {
            dropdownValues.add(e.getText());
        }
        return dropdownValues;
    }

    public String returnAttributeValue(WebDriver driver, By element, String attributeName) {
        waitForElement(driver, element);
        return $(element).getAttribute(attributeName);
    }

    public ArrayList<String> returnAllOptionsInDropDown(WebDriver driver, By element) {
        ArrayList<String> dropDownValues = new ArrayList<>();
        Select select = new Select(driver.findElement(element));
        List<WebElement> op = select.getOptions();
        int totalElements = op.size();
        for (int i = 0; i < totalElements; i++) {
            String options = op.get(i).getText();
            if (options.length() > 1)
                dropDownValues.add(options);
        }
        return dropDownValues;
    }

    /**
     * Method to fetch the values of the rows for a table column
     *
     * @param timeZone
     * @return get timezones available in TimeZone class "https://www.tutorialspoint.com/get-all-the-ids-of-the-time-zone-in-java"
     */

    public String getTodayDate(String timeZone) {
        Date date = new Date();
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        formatter.setTimeZone(TimeZone.getTimeZone(timeZone));
        return formatter.format(date);
    }
    /**
     * Method to get the Text from input field
     */
    public String getTextFromInputField(WebDriver driver, By element) {
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
       return (String) jsExecutor.executeScript("return arguments[0].value", $(element));
    }

    /**
     * Method to sort the Elements of an array in Ascending order
     *
     * @arr is the String array which needs to be sorted
     */

    public String[] sortAscending(String[] arr) {
        Arrays.sort(arr, Comparator.naturalOrder());
        return arr;
    }

    /**
     * Method to sort the Elements of an array in Descending order
     *
     * @arr is the String array which needs to be sorted
     */

    public String[] sortDescending(String[] arr) {
        Arrays.sort(arr, Comparator.reverseOrder());
        return arr;
    }

    /**
     * Method to get date based on the Timezone
     *
     * @day refers to the day which has to be returned
     * @timeZone timezones available in TimeZone class "https://www.tutorialspoint.com/get-all-the-ids-of-the-time-zone-in-java"
     */

    public String getDate(String timeZone, String day) {
        String today = getTodayDate(timeZone);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Calendar c = Calendar.getInstance();
        try {
            c.setTime(sdf.parse(today));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        switch (day.toLowerCase()) {
            case "tomorrow":
                c.add(Calendar.DAY_OF_MONTH, 1);
                break;
            case "today":
                c.add(Calendar.DAY_OF_MONTH, 0);
                break;
            case "yesterday":
                c.add(Calendar.DAY_OF_MONTH, -1);
                break;
            case "old":
                c.add(Calendar.DAY_OF_MONTH, -10);
                break;
            //Enter date as it is.
            default:
                return day;
        }
        return sdf.format(c.getTime());
    }

    /**
     * Method to get date based on the Timezone
     *
     * @day send day as +/-
     * @timeZone timezones available in TimeZone class "https://www.tutorialspoint.com/get-all-the-ids-of-the-time-zone-in-java"
     */
    public String getDate(String timeZone, int day) {
        String today = getTodayDate(timeZone);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Calendar c = Calendar.getInstance();
        try {
            c.setTime(sdf.parse(today));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        c.add(Calendar.DAY_OF_MONTH, day);
        return sdf.format(c.getTime());
    }

    /**
     * Method to get day based on the Timezone
     *
     * @day send day as +/-
     */
    public String getDay(String timeZone) {
        String today = getTodayDate(timeZone);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat sdfDay = new SimpleDateFormat("EEEE");
        Calendar c = Calendar.getInstance();
        try {
            c.setTime(sdf.parse(today));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        c.add(Calendar.DAY_OF_MONTH, 0);
        return sdfDay.format(c.getTime());
    }

    /**
     * Method to convert HTTPResponse to string value
     *
     * @param response
     * @return
     */
    public String returnResponseBody(HttpResponse response) {
        // ResponseHandler<String> handler = new BasicResponseHandler();
        try {
            HttpEntity entity = response.getEntity();
            return EntityUtils.toString(entity);
        } catch (IOException | NullPointerException e) {
            e.printStackTrace();
            try {
                //System.out.println(handler.handleResponse(response));
                //return handler.handleResponse(response);
                HttpEntity entity = response.getEntity();
                return EntityUtils.toString(entity);
            } catch (IOException | NullPointerException e1) {
                e1.printStackTrace();
                System.out.println("Unable to complete the response body conversion process");
                Assert.fail();
            }
        }
        return null;
    }

    public String getEncodedBase64(String file) {
        ConfigFileReader configFileReader = new ConfigFileReader();
        String filePath = configFileReader.getTestDataPath();
        File originalFile = new File(filePath + file);
        String encodedBase64 = null;
        try {
            FileInputStream fileInputStreamReader = new FileInputStream(originalFile);
            byte[] bytes = new byte[(int) originalFile.length()];
            fileInputStreamReader.read(bytes);
            encodedBase64 = new String(Base64.encodeBase64(bytes));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return encodedBase64;
    }

    /**
     * Function to verify links are Displayed
     *
     * @linkname is the name which has to be verified
     */

    public boolean verifyLinkDisplayed(String linkName) {
        By shortcutLink = By.xpath("//li[contains(.,'" + linkName + "')]");
        waitForElementExplicitly(2000);
        return ($(shortcutLink).isDisplayed());
    }

    /**
     * Function to click on Logo
     */
    public void clickOnElement(By by) {
        $(by).click();
    }


    /**
     * Function to get mail number stored in json
     *
     * @param key tag present in the json for mail
     */
    public String getMailNumFromJson(String key) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(mailFilePath);
        mailMap = jsonMapOfMap.get(key);
        return mailMap.get("mail_num").toString();
    }

    /**
     * Function to set mail number stored in json
     *
     * @param key        tag present in the json for mail
     * @param mailNumber new mail identifier to be stored
     */
    public void setMailNumInJson(String key, String mailNumber) {
        mapToReplace.put("mail_num", mailNumber);
        mapOfMap.put(key, mapToReplace);
        dataSetup.fileWrite(key, mapOfMap, configFileReader.getMailDataPath());
    }

    /**
     * Function to set document number stored in json
     *
     * @param parentKey tag present in the json for document.json
     */
    public String returnDocNumberInJson(String parentKey) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(docFilePath);
        docMap = jsonMapOfMap.get(parentKey);
        return docMap.get("doc_num").toString();
    }

    /**
     * Function to set document number stored in json
     *
     * @param parentKey tag present in the json for document.json
     */
    public String getValueFromDocJson(String parentKey, String childKey) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(docFilePath);
        docMap = jsonMapOfMap.get(parentKey);
        return docMap.get(childKey).toString();
    }

    /**
     * Function to set Document number  in json
     *
     * @param key            tag present in the json for document
     * @param documentNumber new document identifier to be stored
     */
    public void setDocumentNumInJson(String key, String documentNumber) {
        mapToReplace.put("doc_num", documentNumber);
        mapOfMap.put(key, mapToReplace);
        dataSetup.fileWrite(key, mapOfMap, configFileReader.getDocumentDataPath());
    }


    /**
     * Function to get user data from json
     *
     * @param userKey username present in json
     * @param query   parameter to be fetched
     */

    public String getUserData(String userKey, String query) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
        userMap = jsonMapOfMap.get(userKey);
        userMap.get("full_name").toString();
        HashMap<String, String> user = new HashMap<>();
        user.put("name", userMap.get("full_name").toString());
        user.put("organisation", userMap.get("org_name").toString());
        user.put("username", userMap.get("username").toString());
        user.put("password", userMap.get("password").toString());
        user.put("projectName1", userMap.get("project_name1").toString());
        user.put("projectId", userMap.get("project_id1").toString());
        return user.get(query);
    }

    /**
     * Function to verify cell elements are present
     *
     * @param cellElements
     * @param rowIndex
     */

    public boolean cellElementDisplayed(List<WebElement> cellElements, int rowIndex) {
        return cellElements.get(rowIndex - 1).isDisplayed();
    }

    /**
     * Method to validate if the alert is present in the page
     *
     * @param driver
     * @return
     */
    public boolean isAlertPresent(WebDriver driver) {
        try {
            driver.switchTo().alert();
            return true;
        }   // try
        catch (NoAlertPresentException Ex) {
            return false;
        }
    }

    /**
     * Method to accept the alert
     *
     * @param driver
     */
    public void acceptAlert(WebDriver driver) {
        if (isAlertPresent(driver)) {
            driver.switchTo().alert().accept();
        }

    }

    /**
     * Method to return the text of the alert box
     *
     * @param driver
     * @return
     */
    public String returnAlertText(WebDriver driver) {
        return driver.switchTo().alert().getText();
    }

    /**
     * Method to wait for the page to load
     *
     * @param driver
     */
    public void loadPage(WebDriver driver) {
        ExpectedCondition<Boolean> pageLoadCondition = new
                ExpectedCondition<Boolean>() {
                    public Boolean apply(WebDriver driver) {
                        return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
                    }
                };
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(pageLoadCondition);

    }

    public static HashMap<String, String> getDocumentTypeDetail(String docType) {
        HashMap<String, String> docTypeMap = new HashMap<>();
        if (docType.toLowerCase().contains("asset")) {
            docTypeMap.put("registermenu", "Assets");
            docTypeMap.put("registersubmenu", "Assets");
            docTypeMap.put("registertitle", "Registered Assets");
            docTypeMap.put("uploadtitle", "Upload Asset");
            docTypeMap.put("uploadmenu", "Assets");
            docTypeMap.put("attachbutton", "Asset");
            docTypeMap.put("uploadsubmenu", "Add/Update Assets");
            docTypeMap.put("supersedebutton", "Assets");
            docTypeMap.put("projectname", "assetTypeProject_name");
            docTypeMap.put("projectid", "assetTypeProject_id");
        } else if (docType.toLowerCase().contains("defect")) {
            docTypeMap.put("registermenu", "Defects");
            docTypeMap.put("registersubmenu", "Defects");
            docTypeMap.put("registertitle", "Registered Defects");
            docTypeMap.put("uploadtitle", "Upload Defect");
            docTypeMap.put("uploadmenu", "Defects");
            docTypeMap.put("supersedebutton", "Defects");
            docTypeMap.put("attachbutton", "Defect");
            docTypeMap.put("uploadsubmenu", "Add/Update Defects");
            docTypeMap.put("projectname", "defectTypeProject_name");
            docTypeMap.put("projectid", "defectTypeProject_id");
        } else if (docType.toLowerCase().contains("issue")) {
            docTypeMap.put("registermenu", "Issues");
            docTypeMap.put("registersubmenu", "Issues");
            docTypeMap.put("registertitle", "Registered Issues");
            docTypeMap.put("uploadtitle", "Upload Issue");
            docTypeMap.put("uploadmenu", "Issues");
            docTypeMap.put("attachbutton", "Issue");
            docTypeMap.put("uploadsubmenu", "Add/Update Issues");
            docTypeMap.put("supersedebutton", "Issues");
            docTypeMap.put("projectname", "issueTypeProject_name");
            docTypeMap.put("projectid", "issueTypeProject_id");
        } else if (docType.toLowerCase().contains("item")) {
            docTypeMap.put("registermenu", "Items");
            docTypeMap.put("registersubmenu", "Items");
            docTypeMap.put("registertitle", "Registered Item");
            docTypeMap.put("uploadtitle", "Upload Item");
            docTypeMap.put("uploadmenu", "Items");
            docTypeMap.put("uploadsubmenu", "Add/Update Items");
            docTypeMap.put("attachbutton", "Item");
            docTypeMap.put("supersedebutton", "Items");
            docTypeMap.put("projectname", "itemTypeProject_name");
            docTypeMap.put("projectid", "itemTypeProject_id");
        } else if (docType.toLowerCase().contains("interface")) {
            docTypeMap.put("registermenu", "Interfaces");
            docTypeMap.put("registersubmenu", "Interfaces");
            docTypeMap.put("registertitle", "Registered Interfaces");
            docTypeMap.put("uploadtitle", "Upload Interface");
            docTypeMap.put("uploadmenu", "Interfaces");
            docTypeMap.put("uploadsubmenu", "Add/Update Interfaces");
            docTypeMap.put("attachbutton", "Interface");
            docTypeMap.put("supersedebutton", "Interfaces");
            docTypeMap.put("projectname", "interfaceTypeProject_name");
            docTypeMap.put("projectid", "interfaceTypeProject_id");
        } else {
            docTypeMap.put("registermenu", "Documents");
            docTypeMap.put("registersubmenu", "Document Register");
            docTypeMap.put("registertitle", "Document Register");
            docTypeMap.put("uploadtitle", "Upload Documents");
            docTypeMap.put("uploadmenu", "Documents");
            docTypeMap.put("uploadsubmenu", "Add/Update Documents");
            docTypeMap.put("attachbutton", "Document");
            docTypeMap.put("supersedebutton", "Documents");
            docTypeMap.put("projectname", "project_name");
            docTypeMap.put("projectid", "project_id");
        }
        return docTypeMap;
    }

    /**
     * Method to wait for a new window to open.
     *
     * @param driver      webdriver instance
     * @param windowTitle title of the window
     */
    public void waitForWindowToOpen(WebDriver driver, String windowTitle) {
        boolean windowFound;
        Set<String> windows;

        Date startDate = new Date();
        long startTime = startDate.getTime();

        while (new Date().getTime() - startTime <= 50000) {
            windowFound = false;
            windows = driver.getWindowHandles();
            if (!(windows.size() < 2)) {
                while (new Date().getTime() - startTime <= 50000) {
                    windowFound = false;
                    windows = driver.getWindowHandles();
                    for (String window : windows) {
                        if (driver.switchTo().window(window).getTitle().toLowerCase().contains(windowTitle.toLowerCase())) {
                            windowFound = true;
                            break;
                        }
                    }
                    if (windowFound) {
                        break;
                    }
                }
            }
            if (windowFound) {
                break;
            }
        }
    }

    /**
     * Method to wait for the page to load
     *
     * @param driver
     */
    public void waitForPageLoad(WebDriver driver) {
        WebDriverWait wait = new WebDriverWait(driver, 60);
        wait.until(webDriver -> ((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete"));
    }

    /**
     * Method to validate the time if of the required pattern
     *
     * @param format
     * @param value
     * @return
     */
    public static boolean isValidFormat(String format, String value) {
        Date date = null;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(format);
            date = sdf.parse(value);
            if (!value.equals(sdf.format(date))) {
                date = null;
            }
        } catch (ParseException ex) {
            ex.printStackTrace();
        }
        return date != null;
    }

    /**
     * Method to get the current time in the pattern that we want
     *
     * @param pattern
     * @return
     */
    public static String getCurrentDate(String pattern) {
        SimpleDateFormat sdfDate = new SimpleDateFormat(pattern);
        Date now = new Date();
        String strDate = sdfDate.format(now);
        return strDate;
    }

    /**
     * Function to get Title stored in json
     *
     * @param key tag present in the json for title
     */
    public String getTitleFromJson(String key) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(docFilePath);
        docMap = jsonMapOfMap.get(key);
        return docMap.get("doc_title").toString();
    }

    /**
     * Function to set Title stored in json
     *
     * @param key   tag present in the json for Title
     * @param title new title identifier to be stored
     */
    public void setTitleInJson(String key, String title) {
        mapToReplace.put("doc_title", title);
        mapOfMap.put(key, mapToReplace);
        dataSetup.fileWrite(key, mapOfMap, configFileReader.getDocumentDataPath());
    }

    /**
     * Function to set  value  in json
     *
     * @param key     tag present in the json for user
     * @param keyType is the tag for which value should be assigned
     */
    public void writeToJson(String keyType, String key, String value, String dataPath) {
        mapToReplace.clear();
        mapOfMap.clear();
        mapToReplace.put(keyType, value);
        mapOfMap.put(key, mapToReplace);
        dataSetup.fileWrite(key, mapOfMap, dataPath);
    }

    /**
     * Function to return  value from json
     *
     * @param parentKey tag present in the json for project_participants.json
     */
    public String returnFromJson(String parentKey, String childKey, String path) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(path);
        docMap = jsonMapOfMap.get(parentKey);
        return docMap.get(childKey).toString();
    }

    /**
     * Function to get count stored in json
     *
     * @param path is the path of file from where the count has to be retrived
     * @param key  tag present in the json for Inbox mailcount
     */
    public String getCountFromJson(String key, String path) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(path);
        mailMap = jsonMapOfMap.get(key);
        return mailMap.get("count1").toString();
    }

    /**
     * Function to set count stored in json
     *
     * @param path  is the path of file from where the count has to be retrived
     * @param key   tag present in the json for count
     * @param count new count
     */
    public void setCountInJson(String key, String count, String path) {
        mapToReplace.put("count1", count);
        mapOfMap.put(key, mapToReplace);
        dataSetup.fileWrite(key, mapOfMap, path);
    }

    /**
     * Function to verify the links present
     *
     * @param linkName
     */
    public void verifyLinks(List<String> linkName) {
        for (String link : linkName) {
            Assert.assertTrue($(By.xpath("//a[contains(text(),'" + link + "')]")).isDisplayed());
        }
    }

    /**
     * Function to scroll to the page top
     */

    public void scrollPageUp(WebDriver driver) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,-1000)", "");

    }

    /**
     * Method to check if the table field is displayed in the UI page
     *
     * @param text
     * @return
     */
    public boolean tableFieldIsDisplayed(WebDriver driver, String text) {
        By by = By.xpath("//td[contains(text(),'" + text + "')]");
        waitForElement(driver, by, 60);
        return driver.findElement(by).isDisplayed();
    }

    public void enterDropdownValue(By element, String option) {
        if ($(element).isDisplayed() && $(element).exists()) {
            $(element).click();
            $(element).selectOption(option);
        }
    }

    public void enterTextValue(By element, String value) {
        if ($(element).isDisplayed() && $(element).exists()) {
            $(element).click();
            $(element).clear();
            waitForElementExplicitly(2000);
            $(element).sendKeys(value);
        }

    }

    /**
     * Method to change date format to yyyy/mm/dd
     */
    public String changeDateFormat(String timeZone, String day) {
        String date = getDate(timeZone, day);
        return date.split("/")[2] + "/" + date.split("/")[1] + "/" + date.split("/")[0];
    }

    /**
     * Method to take screenshot
     */
    protected synchronized static String addScreenshot(WebDriver driver) {
        String encodedBase64 = null;
        FileInputStream fileInputStreamReader = null;
        try {
            File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            fileInputStreamReader = new FileInputStream(srcFile);
            byte[] bytes = new byte[(int) srcFile.length()];
            fileInputStreamReader.read(bytes);
            encodedBase64 = new String(java.util.Base64.getEncoder().encode(bytes));
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return "data:image/png;base64," + encodedBase64;
    }

    /**
     * Method to add screenshot for extent report
     */
    public static void captureExtentReportScreenShot(WebDriver driver) {
        try {
            ExtentCucumberAdapter.addTestStepScreenCaptureFromPath(addScreenshot(driver));
        } catch (Exception exception) {
            System.out.println("Extent Report plugin not initialised");
        }
    }

    /**
     * Method to wait for the element to be clickable
     *
     * @param driver
     * @param by      attribute identifier
     * @param seconds
     * @return
     */
    public WebDriver waitForElementClickable(WebDriver driver, By by, int seconds) throws TimeoutException {
        try {
            WebDriverWait wait = new WebDriverWait(driver, seconds);
            wait.until(ExpectedConditions.or(ExpectedConditions.elementToBeClickable(by)));
        } catch (TimeoutException e) {
            throw new TimeoutException("Locator Not Found :" + by);
        }
        return driver;
    }

    /**
     * Method to return random string
     *
     * @return
     */
    public String getRandomString(int length) {
        if (randomString == null || randomString.isEmpty()) {
            randomString = faker.lorem().fixedString(length).trim();
        }
        return randomString;
    }

    /**
     * Method to get project name from any project Id from user.json (project1,project2,project3)
     */
    public String getProjectName(String userId, String projectId) {
        Map<String, Map<String, Object>> jsonMapOfMap;
        Map<String, Object> userMap;
        ConfigFileReader configFileReader = new ConfigFileReader();
        jsonMapOfMap = dataSetup.loadJsonDataToMap(configFileReader.getUserDataPath());
        userMap = jsonMapOfMap.get(userId);
        return userMap.get("project_name" + projectId.substring(projectId.length() - 1)).toString();
    }

    /**
     * Method to get Project Label name from Project Fields json file
     */
    public String getLabelName(String labelName) {
        DataSetup dataSetup = new DataSetup();
        mapOfMap = dataSetup.loadJsonDataToMap(projectFieldsPath);
        Map<String, Object> map = mapOfMap.get(labelName);
        return map.get("field_name").toString().replaceAll("_","");
    }
    /**
     * Method to get auto numbering label from documentNumbering json file
     */
    public String getAutoNumbering(String labelName) {
        mapOfMap = dataSetup.loadJsonDataToMap(docNumberingpath);
        Map<String, Object> map = mapOfMap.get(labelName);
        return map.get("doc_num_preview").toString();
    }
    /**
     * Method to get Project Label Type from Project Fields json file
     */
    public String getLabelType(String labelName) {
        DataSetup dataSetup = new DataSetup();
        mapOfMap = dataSetup.loadJsonDataToMap(projectFieldsPath);
        Map<String, Object> map = mapOfMap.get(labelName);
        return map.get("field_type").toString();
    }

    /**
     * Method to get Project unit value from Project Fields json file
     */
    public String getUnitValue(String labelName) {
        DataSetup dataSetup = new DataSetup();
        mapOfMap = dataSetup.loadJsonDataToMap(projectFieldsPath);
        Map<String, Object> map = mapOfMap.get(labelName);
        return map.get("unit_value").toString();
    }

    /**
     * Function to get user full name from user data json
     *
     * @param value is the user Id present in Json
     */
    public String getUserName(String value) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
        userMap = jsonMapOfMap.get(value);
        return userMap.get("full_name").toString();
    }

    /**
     * Method to scroll page based on window height
     */
    public void scrollToBottom(WebDriver driver) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
    }

    /**
     * Method to scroll page based on window height
     */
    public void scrollToTop(WebDriver driver) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, 0)");
    }

    /**
     * Method to return the workflow id, name from the json file
     */
    public String getWFTemplateDetails(String wfId, String key) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(workflowPath);
        wfMap = jsonMapOfMap.get(wfId);
        return wfMap.get(key).toString();
    }

    /**
     * function to get element in the view
     *
     * @param element to make visible
     */
    public void getElementInViewAndUp(By element) {
        WebDriver driver = WebDriverRunner.getWebDriver();
        WebElement e = $(element);
        waitForElement(driver, element, 30);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", e);
        ((JavascriptExecutor) driver).executeScript("window.scrollBy(0,-100)", "");
    }

    /**
     * Function to get Background color of an element
     */
    public String getBGColor(By xpath) {
        return $(xpath).getCssValue("background-color");
    }

    /**
     * function to get rgb color codes in hex color code
     */
    public String getBGColorInHex(String rgb) {
        return Color.fromString(rgb).asHex().toUpperCase();
    }

    /**
     * Function to get mail details stored in json
     *
     * @param key   tag present in the json for mail
     * @param query tag which you data from mail json file
     */
    public String getMailDetailsFromJson(String key, String query) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(mailFilePath);
        mailMap = jsonMapOfMap.get(key);
        return mailMap.get(query).toString();
    }

    /**
     * Function to return list of values from webelements
     */
    public List<String> getValues(By xpath) {
        return $$(xpath).texts();
    }

    /**
     * Function to return column index
     */
    public int getColIndex(List<String> headers, String colName) {
        return headers.indexOf(colName) + 2;
    }

    /**
     * Function to return document row index
     */
    public int getDocumentRow(By xpath, String docName) {
        List<WebElement> elements = new ArrayList<>($$(xpath));
        for (int i = 0; i < elements.size(); i++)
            if ($(elements.get(i)).getText().trim().equalsIgnoreCase(docName)) return i;
        return 1;
    }

    public void mouseHoverElement(WebDriver driver, WebElement element) {
        try {
            String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover',true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject) { arguments[0].fireEvent('onmouseover');}";
            ((JavascriptExecutor) driver).executeScript(mouseOverScript, element);
        } catch (Exception e) {
            System.out.println("No Mouse event happened");
        }
    }

    public String getBorderColor(By xpath) {
        if (configFileReader.getBrowser().equalsIgnoreCase("chrome"))
            return $(xpath).getCssValue("border-color");
        else if (configFileReader.getBrowser().equalsIgnoreCase("firefox"))
            return $(xpath).getCssValue("border-bottom-color");
        return null;
    }

    /**
     * Method to fetch the values of the rows for a table column
     *
     * @param timeZone
     */

    public String getTodayDateTime(String timeZone) {
        Date date = new Date();
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        formatter.setTimeZone(TimeZone.getTimeZone(configFileReader.getTimeZone()));
        return formatter.format(date);
    }

    /**
     * Method to verify the list elements present
     */
    public void verifyElementsPresent(List<WebElement> elements) {
        for (WebElement singeElement : elements) {
            Assert.assertTrue(singeElement.isDisplayed());
        }
    }

    /**
     * Method to fetch column index from a table
     *
     * @param xpath   - this should pass the xpath of a table headers
     * @param colName - column name of the table for which you need col index
     */
    public int getColumnIndex(By xpath, String colName) {
        List<WebElement> elements = new ArrayList<>($$(xpath));
        for (int i = 0; i < elements.size(); i++)
            if (elements.get(i).getText().equals(colName)) return i;
        return 1;
    }

    /**
     * Method to return the values for a particular column in the table
     *
     * @param driver
     * @param elementId
     * @return
     */

    public List<String> columnValues(WebDriver driver, By elementId) {
        getElementInViewAndUp(elementId);
        List<WebElement> list = driver.findElements(elementId);
        List<String> values = new ArrayList<>();
        for (WebElement element : list) {
            values.add(element.getText());
        }
        return values;
    }

    /**
     * Method to return the SD Package details
     */
    public String getSDPackageNumber(String sdPackage) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(sdDataPath);
        sdMap = jsonMapOfMap.get(sdPackage);
        return sdMap.get("package_number").toString();
    }

    /**
     * Method to return the Package details
     */
    public String getPackageNumber(String packageNum, String query) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(packageDataPath);
        packageMap = jsonMapOfMap.get(packageNum);
        return packageMap.get(query).toString();
    }

    /**
     * Method to return the Package template details
     */
    public String getPackageTemplate(String packageTemplate) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(packageTemplatePath);
        packageMap = jsonMapOfMap.get(packageTemplate);
        return packageMap.get("template_name").toString();
    }

    /**
     * Method to return the Tender number
     */
    public String getTenderDetails(String tenderNum) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(tenderDataPath);
        tenderMap = jsonMapOfMap.get(tenderNum);
        return tenderMap.get("tender_num").toString();
    }

    /**
     * Method to switch to current tab in a browser
     */
    public List<String> switchToCurrentTab() {
        Set<String> handlesSet = WebDriverRunner.getWebDriver().getWindowHandles();
        List<String> handlesList = new ArrayList<>(handlesSet);
        WebDriverRunner.getWebDriver().switchTo().window(handlesList.get(handlesList.size() - 1));
        return handlesList;
    }

    /**
     * Method to close the current tab
     */
    public void closeCurrentTab() {
        switchToCurrentTab();
        WebDriverRunner.getWebDriver().close();
    }

    /**
     * Method to switch to original tab
     */
    public void switchToOriginalTab() {
        List<String> handlesList = switchToCurrentTab();
        WebDriverRunner.getWebDriver().switchTo().window(handlesList.get(0));
    }


    /**
     * Method to get the JSON response from XML
     *
     * @param xml
     */
    public JSONObject getJSONValueOnXML(String xml) {
        JSONObject json = XML.toJSONObject(xml);
        return json;
    }

    /**
     * Method to get the response body based on urlconnection
     *
     * @param urlConnection
     */
    public StringBuffer getResponseBody(HttpURLConnection urlConnection) throws Exception {
        BufferedReader in = new BufferedReader(new InputStreamReader(
                urlConnection.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();
        System.out.println(response.toString());
        return response;
    }

    /**
     * Method to select multiple dropdown values
     */
    public void enterMultipleDropdownValues(By element, String option) {
        List<WebElement> elements = new ArrayList<>($$(element));
        if ($(element).isDisplayed() && $(element).exists()) {
            for (WebElement values : elements) {
                $(values).click();
                $(values).selectOption(option);
            }
        }
    }

    /**
     * write group name to json
     *
     * @param groupId
     * @param groupName
     */
    public void writeGroupToJson(String groupId, String groupName) {
        //Write the data to the json file
        Map<String, Object> map = new Hashtable<>();
        Map<String, Map<String, Object>> mapOfMap = new HashMap<>();
        map.put("group_name", groupName);
        mapOfMap.put(groupId, map);
        dataSetup.fileWrite(groupId, mapOfMap, groupPath);
    }

    /**
     * Get group name from json
     *
     * @param groupId
     * @return
     */
    public String getGroupFromJSON(String groupId) {
        Map<String, Map<String, Object>> jsonData;
        Map<String, Object> map;
        jsonData = dataSetup.loadJsonDataToMap(groupPath);
        map = jsonData.get(groupId);
        return map.get("group_name").toString();
    }

    /**
     * Method to get a json array on response by passing the parent node
     *
     * @param response
     * @param parentNode
     */
    public JSONArray getJSONArrayOnResponse(StringBuffer response, String parentNode) {
        JSONObject object = new JSONObject(response.toString());
        JSONArray array = object.getJSONArray(parentNode);
        return array;
    }

    /**
     * Method to wait until element is hidden
     */
    public void waitForElementHidden(WebDriver driver, By by) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, 60);
            wait.until(ExpectedConditions.or(ExpectedConditions.invisibilityOfElementLocated(by)));
        } catch (TimeoutException e) {
            throw new TimeoutException("Loader does not disappear :" + by);
        }
    }

    /**
     * Method to get absolute path of the files
     */
    public List<String> returnFileNames(String directoryPath) {
        List<String> results = new ArrayList<>();
        File[] files = new File(directoryPath).listFiles();
        //If this pathname does not denote a directory, then listFiles() returns null.
        for (File file : files) {
            if (file.isFile()) {
                results.add(file.getAbsolutePath());
            }
        }
        return results;
    }

    /**
     * Method to get files names
     */
    public List<String> getFileNames(String directoryPath) {
        List<String> results = new ArrayList<>();
        File[] files = new File(directoryPath).listFiles();
        for (File file : files) {
            if (file.isFile()) {
                results.add(file.getName());
            }
        }
        return results;
    }

    /**
     * Method to get project Id
     */
    public String getProjectId(String userId, String projectId) {
        Map<String, Map<String, Object>> jsonMapOfMap;
        Map<String, Object> userMap;
        ConfigFileReader configFileReader = new ConfigFileReader();
        jsonMapOfMap = dataSetup.loadJsonDataToMap(configFileReader.getUserDataPath());
        userMap = jsonMapOfMap.get(userId);
        return userMap.get(getDocumentTypeDetail(projectId).get("projectid") + projectId.substring(projectId.length() - 1)).toString();
    }

    /**
     * Method to return the value to date format "Thu Jul 21 16:59:40 IST 2022"
     */
    public Date getDate(String value) {
        switch (value.toLowerCase()) {
            case "yesterday":
                return DateUtils.addDays(new Date(), -1);
            case "tomorrow":
                return DateUtils.addDays(new Date(), +1);
            default:
                return DateUtils.addDays(new Date(), 0);
        }
    }

    /**
     * Method to return the value to date format "Thu Jul 21 16:59:40 IST 2022"
     * @param days pass the days as integer. If future days pass the positive numbers and past days pass the negative numbers
     */
    public Date getDate(int days) {
        return DateUtils.addDays(new Date(), days);
    }

    /**
     * Function to get document details stored in json
     *
     * @param parentKey tag present in the json for document.json
     */
    public String returnDocNumberInJson(String parentKey, String childKey) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(docFilePath);
        docMap = jsonMapOfMap.get(parentKey);
        return docMap.get(childKey).toString();
    }

    /**
     * Function to get mail number stored in json
     *
     * @param parentKey tag present in the json for mail
     */
    public String getMailNumFromJson(String parentKey, String childKey) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(mailFilePath);
        mailMap = jsonMapOfMap.get(parentKey);
        return mailMap.get(childKey).toString();
    }


    /**
     * Function to run Linux commands
     *
     */
    public void runCommands(String cmd) {
        Process process = null;
        System.out.println(cmd);
        try {
            process = Runtime.getRuntime().exec(cmd);
            process.waitFor();
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            BufferedReader errorReader = new BufferedReader(new InputStreamReader(process.getErrorStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
            line = "";
            while ((line = errorReader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            process.destroy();
        }
    }
    /**
     * Method to click on delete
     */
    public void clickOnDeleteIcon() {
        waitForElement(driver, btnTrash);
        $(btnTrash).click();
    }

    /**
     * Function to run Linux array commands
     *
     */
    public void runCommands(String[] cmd) {
        Process process = null;
        System.out.println(cmd);
        try {
            process = Runtime.getRuntime().exec(cmd);
            process.waitFor();
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            BufferedReader errorReader = new BufferedReader(new InputStreamReader(process.getErrorStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
            line = "";
            while ((line = errorReader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            process.destroy();
        }
    }

    /**
     * Method to verify the message
     */
    public boolean verifyMessage(String Message) {
        return $(By.xpath("//div[contains(text(),'" + Message + "')]")).isDisplayed();
    }

    /**
     * Method to check Doc Search column is displayed or not
     *
     */
    public boolean isColumnVisible(String colId) {
        By element = By.xpath("//div[@col-id='" + colId + "' and not(@role='presentation')]");
        waitForElement(WebDriverRunner.getWebDriver(), element, 30);
        return $(element).isDisplayed();
    }
    
    
    public WebDriver setText(By by, String text) {
    	if(driver.findElement(by).getText().isEmpty()) {
    		sleep(3000);
    		driver.findElement(by).sendKeys(text);
    	}else {
    		driver.findElement(by).clear();
    		sleep(3000);
    		driver.findElement(by).sendKeys(text);
    	}
        return driver;
    }
    
    public void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}
