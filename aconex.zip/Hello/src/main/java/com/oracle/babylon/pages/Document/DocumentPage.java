package com.oracle.babylon.pages.Document;

import com.codeborne.selenide.WebDriverRunner;
import com.github.javafaker.Faker;
import com.oracle.babylon.Utils.helper.CommonMethods;
import com.oracle.babylon.Utils.helper.Navigator;
import com.oracle.babylon.Utils.helper.SchemaHelperPage;
import com.oracle.babylon.Utils.setup.dataStore.pojo.Document;
import com.oracle.babylon.pages.Mail.MailPage;
import io.cucumber.datatable.DataTable;
import io.restassured.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.util.*;

import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Selenide.*;

/**
 * Class file that contains methods related to the operations for Documents
 * Author : susgopal
 */
public class DocumentPage extends Navigator {

    //Initialization of web elements
    private By transmitBtn = By.xpath("//button[contains(text(),'Transmit')]");
    private By resultTable = By.xpath("//table[@class='auiTable']");
    private By searchBtn = By.xpath("//button[@id='searchButton']");
    private By resultTableRow = By.xpath("//table[@id='auiTable']//tbody//tr");
    protected By status = By.xpath("//select[contains(@title,'Current status of')]");
    protected By type = By.xpath("//select[@title='Type']");
    private By resultSummary = By.xpath("//span[@id='selectResultSummary']");
    private By leftSectionHeaders = By.xpath("//div[@class='ag-pinned-left-header']//*//div[@class='customHeaderLabel']");
    private By scrollBarBy = By.xpath("//div[@class='ag-body-horizontal-scroll-viewport']");
    private By scrollBarEnd = By.xpath("//div[@class='ag-horizontal-right-spacer ag-scroller-corner']");
    //private By scrollBarEnd= By.xpath("//div[@class='ag-body-horizontal-scroll-viewport']");
    private By tableLeftRows = By.xpath("//div[@class='ag-pinned-left-cols-container']/div/div");
    protected By pageTitle = By.xpath("//span[contains(text(),'Document Register')]");
    private By reasonTxt = By.xpath("//table[@id='excludedDocList']//td[5]");
    private By documentLoader = By.xpath("//div[@class='auiLoaderOverlay-loader']");
    private By documentHistoryCheckBox = By.xpath("//input[@id='isShowDocumentHistory']");
    protected By tableRows = By.xpath("//table//tbody//tr");
    private By attribute2 = By.xpath("//label[contains(text(),'Attribute 2')]//..//..//input");
    private By showPerPage = By.xpath("//button[@title='Show per page']");
    private By copyToProject = By.xpath("//div[@class='auiMenuButton-dropdownContents']//a[text()='Copy to Project']");
    protected By description = By.xpath("//input[@title='Description']");
    protected By version = By.xpath("//input[@title='Asset Version Number/Letter']");

    //Row identifiers of the search results - New doc search
    private By revisionDate = By.xpath("//div[@col-id='revisiondate']");
    private By revision = By.xpath("//div[@col-id='revision']");
    private By confidential = By.xpath("//div[@col-id='confidential']");
    private By title = By.xpath("//div[@col-id='title']");
    private By docStatus = By.xpath("//div[@col-id='docstatus']");
    private By docReviewStatus = By.xpath("//div[@col-id='reviewstatus']");
    private By discipline = By.xpath("//div[@col-id='discipline']");
    private By hyperLink = By.xpath("//div[@col-id='dochyperlink']");
    private By docType = By.xpath("//div[@col-id='doctype']");
    private By docTitle = By.xpath("//div[@col-id='title']");
    private By documentTitle = By.xpath("//div[@col-id='title']//a");
    private By documentTitleLatest = By.xpath("(//div[@col-id='title']//a)[last()]");
    private By docHyperLink = By.xpath("//div[@col-id='dochyperlink']/div/a");
    private By dateModified = By.xpath("//div[@col-id='registered']");
    private By firstDocumentChkBox = By.xpath("//div[@class='ag-pinned-left-cols-container']/div/div[1]/div/span[1]");
    private By documentNumber = By.xpath("//div[(@col-id='docno' or @col-id='candidateno') and not(@role='presentation')]");
    private By forwardMailNum = By.xpath("//div[text()='Forwarded Mail No.']");
    private By lockImage = By.xpath("//div[@col-id='lock']//img[@src='/html/Images/ic_lock.gif']");
    private By workflowLockImg = By.xpath("//div[@col-id='lock']//img[@src='/html/Images/ic_wflock.png']");
    private By sharedImage = By.xpath("//img[@src='/html/Images/doc_share_publ.gif']");
    private By sharedInIcon = By.xpath("//img[@src='/html/Images/doc_share_co.gif']");
    private By sharedOutIcon = By.xpath("//img[@src='/html/Images/doc_share_out.gif']");
    protected By searchDocKeywords = By.xpath("//input[@id='search-keywords-id']");
    private By toolsBtn = By.xpath("//button[contains(text(),'Tools')]");
    private By printRequest = By.xpath("//a[contains(text(),'Submit a Print Request')]");
    static List<String> attributes = new ArrayList<>();
    private By candidateNumber = By.xpath("//div[@col-id='candidateno']");
    private By fileName = By.xpath("//div[@col-id='filename']");
    private By dateUploaded = By.xpath("//div[@col-id='uploaddate']");
    private final By accessListUsers = By.xpath("//label[contains(text(),'Confidential')]//..//..//span[@uis-transclude-append]//span");
    public By linkSelectAll = By.xpath("//span[text()='Select All']");
    private By linkClearAll = By.xpath("//span[text()='Clear All']");
    protected By clearAllFilter = By.xpath("//div[@class='searchActions']//div[text()='Clear all filters']");
    private By backBtn = By.xpath("//div[contains(text(),'<')]");
    private By transmittalHistoryBackBtn = By.xpath("//button[@title='Back']");

    private By transmittalHistoryTxt = By.xpath("//h1[contains(text(),'Transmittal History')]");
    private By exportToExcel = By.xpath("//div[contains(text(),'Export to Excel')]");
    private By printButton = By.xpath("//button[@title='Print this item']");
    private By optionButton = By.xpath("//button[@title='View Options']");
    private By openFullSearch = By.xpath("//div[contains(text(),'Open Full Search Page')]");
    protected By selectFirstFile = By.xpath("//div[@class='ag-pinned-left-cols-container']/div/div[1]/div/span");
    protected By selectLastFile = By.xpath("(//div[@class='ag-pinned-left-cols-container']/div/div[1]/div/span)[last()-1]");
    protected By selectLastFileDots = By.xpath("(//div[@class='ag-pinned-left-cols-container']/div/div[1]/div/span)[last()]");
    protected By attachFile = By.xpath("//div[contains(text(),'Attach File')]");
    private By hideFilters = By.xpath("//span[contains(text(),'Hide filters')]");
    private By noResultsFound = By.xpath("//*[text()='No results found matching your search criteria.']");
    private By docResultsLink=By.xpath("//div[@role='row']//a");
    private By restoreDefault = By.xpath("//a[contains(text(),' Restore defaults ')]");
    protected By tableHead = By.xpath("//div[@class='ag-header ag-pivot-off']");
    private By noResultsMessage = By.xpath("//p[contains(text(),'No results found matching your search criteria.')]");
    public By addRemoveColumnBtn = By.xpath("//div[@id='addRemoveColumns']//button[text()='Add/Remove Columns']");
    protected By cancelBtn = By.xpath("//button[text()='Cancel']");
    private By closeBtn = By.xpath("//button[@id='alertPanel-cancel']");
    private By okBtn = By.xpath("//button[@id='ok']");
    private By wildCardMessage = By.xpath("//div[contains(text(),'The query entered was not valid.')]");
    private By addButton = By.xpath("//button[@title='Add item to list']");
    private By removeBtn = By.xpath("//button[@title='Remove item from list']");
    private By resetBtn = By.xpath("//button[@title='Cancel your current changes']");
    private By moveUpBtn = By.xpath("//div[@class='updown-container']//button[@title='Move selected items one position up the list']");
    private By moveDownBtn = By.xpath("//div[@class='updown-container']//button[@title='Move selected items one position down the list']");
    private By availableFilter = By.xpath("//div[@class='bidi']//div[1]/../select[1]");
    private By selectedFilter = By.xpath("//div[@class='bidi']//div[2]/select[1]");
    private By filterSearch = By.xpath("//input[@placeholder='- Filter -']");
    private By documentActivity = By.xpath("//button[contains(text(),'Document Activity')]");
    private By viewRecentDocActivity = By.xpath("//h3[contains(text(),'View Recent Document Activity')]");
    private By addFilterBtn = By.xpath("//button[contains(text(),'Add Filter')]");
    private By addMoreFilters = By.xpath("//span[contains(text(),'More filters')]");
    private By expandFilter = By.xpath("//a[@aria-expanded='true']");
    private By allFilters = By.xpath("//span[contains(text(),'All filters')]");
    private By moreFilters = By.xpath("//span[contains(.,'More filters ')]");
    private By dateUploadedDropdown = By.xpath("//div[text()='Date Uploaded']");
    private By dateModifiedDropdown = By.xpath("//div[text()='Date Modified']");
    private By dateUploadedDropdownValue = By.xpath("//div[@class='dateRangePicker']//select");
    Actions action = new Actions(driver);
    private By selectHistoryOrganisation = By.xpath("//table[@id='OrganizationSelector']//tbody//tr[2]/td[3]/select[@name='ORGS']/option");
    private By selectFirstOrganisation = By.xpath("//select[@name='ORGS']//option[1]");
    private By selectedCheckBox = By.xpath("//div[@class='ag-pinned-left-cols-container']//span[@class='ag-icon ag-icon-checkbox-checked']");
    protected By unSelectedCheckBox = By.xpath("//div[@class='ag-pinned-left-cols-container']//span[@class='ag-icon ag-icon-checkbox-unchecked']");
    private By collapsibleFilter = By.xpath("//div[@class='collapsibleFilters']");
    private By showFilters = By.xpath("//span[text()='Show filters']");
    private By showAllFilter = By.xpath("//span[contains(text(),'All filters')]");
    private By hiddenFilterPanel = By.xpath("//div[@class='collapsibleFilters ng-hide']");
    private By expandDFilters = By.xpath("//div[@ng-show='expandSearchFilters']");
    static String revisionSize = "//div[@class='ag-center-cols-container']/div//div[@col-id='revision']//span";
    public By listView = By.xpath("//button[@id='viewList']");
    private By gridView = By.xpath("//button[@title='Grid View' and @class='auiButton checkbox-select-top']");
    private By editViewAccessList = By.xpath("//div[contains(text(),'Edit/View Access List')]");
    private By attachBtn = By.xpath("//button[@id='btnattachDocs_panel_ok']");
    private By allSelectedItems = By.xpath("//div[@class='manual-sort']//select[@add-titles-on-change='selectedItems']//option");
    private By allFilteredItems = By.xpath("//select[@add-titles-on-change='filteredItems']//option");
    private By enterSearchCriteria = By.xpath("//span[contains(text(),'Enter your search criteria above, then click the Search button.')]");
    private By inputEventLogType = By.xpath("//th[text()='Type']//input");
    private By eventLog = By.xpath("//table[@class='auiTable']//td//a");
    private By eventStatus = By.xpath("//table[@class='auiTable']//td//span");
    private By eventLogUser = By.xpath("//table[@class='auiTable']//td[6]");
    private By eventLogOrg = By.xpath("//table[@class='auiTable']//td[7]");
    private By addRemoveColumnsOkBtn = By.xpath("//div[@class='auiModal-dialog ']//button[@title='OK and close window']");
    private By okButton = By.xpath("//button[@title='OK and close window']");
    protected By dots = By.xpath("//span[@class='ag-icon ag-icon-checkbox-checked']//..//..//span//button");
    private By downloadLink = By.xpath("//div[@class='auiMenuButton-dropdownContents']//a[text()='Download']");
    private By pageNumberBox = By.xpath("//div[@class='auiPagination-manualPage']//input");
    private By nextArrow = By.xpath("//div[@class='auiPagination-list ng-scope']//button[contains(text(),'Next')]");
    private By prevArrow = By.xpath("//div[@class='auiPagination-list ng-scope']//button[contains(text(),'Previous')]");
    private By inputEvent = By.xpath("//th[text()='Event']//input");
    private By eventTableRows = By.xpath("//table[@class='auiTable']//tbody//tr");
    private By eventCell = By.xpath("//td[@data-automation-id='eventlog-eventMessageCell']");
    protected By selectFile = By.xpath("//div[@col-id='rowMenuButtons']//span[@class='ag-icon ag-icon-checkbox-unchecked']");
    private By viewInRegisterLink = By.xpath("//div[contains(@class,'auiModal-dialog')]//a[contains(text(),'View') and contains(text(),'register')]");
    private By eventBackBtn = By.xpath("//button[@class='auiButton back']");
    private By rows = By.xpath("//div[contains(@class,'auiForm-label auiDetails-label')]//label");
    private By docCount = By.xpath("//span[@id='selectResultSummary']");
    public By searchHeader = By.xpath("//div[@id='toolbar_left']//h1");
    public By activityBtn = By.xpath("//div[@id='toolbar_left']//button");
    public By registeredLabel = By.xpath("//ul//li[@id='CDRegisteredList']");
    public By docNoLabel = By.xpath("(//div[@class='auiForm-label ng-binding ng-scope'])[1]");
    public By showHistoryCheckBox = By.xpath("//span[@id='regSpecificConfig_1']//label");
    public By sortByDropDown = By.xpath("//select[@id='sortBy']");
    private By resultsGrid = By.xpath("//div[@class='resultsGrid ng-scope']");
    private By sortDateUploaded = By.xpath("//div[@class='resultsGrid ng-scope']//div[contains(text(),'Date Uploaded')]");
    private By tickSymbol = By.xpath("//div[@col-id='transmitted']//a");
    //print request page
    private By attachFileBtn = By.xpath("//button[@id='btnAttach']");
    private By addRecipientBtn = By.xpath("//button[@id='btnAddRecipient']");
    private By printBtn = By.xpath("//button[@id='btnPrint']");
    private By saveDraftBtn = By.xpath("//button[@id='btnSaveToDraft']");
    private By continueBtn = By.xpath("//button[@id='btnContinue']");
    private By userReference = By.xpath("//td[contains(text(),'User Reference')]");
    private By printShop = By.xpath("//td[contains(text(),'Print Shop')]");
    private By useAddress = By.xpath("//td[contains(text(),'Use Address')]");
    private By deliveryBy = By.xpath("//td[contains(text(),'Deliver by')]");
    private By paymentBy = By.xpath("//td[contains(text(),'Payment by')]");
    private By selectProject = By.xpath("//select[@name='PROJECT_ID']");
    private By copyBtn = By.xpath("//button[@id='btnCopy']");
    private By unLockImage = By.xpath("//div[@col-id='lock']//img[@src='/html/Images/ic_unlock.gif']");

    private By transmitDocument = By.xpath("//a[contains(text(),' Transmit these documents')]");
    protected By userField = By.xpath("//label[text()='Confidential']//..//..//input[@type='search']");
    private String docFieldsDataPath = configFileReader.getDocFieldPath();
    private By updatedVersions = By.xpath("//div[text()='Updated versions exist']");
    private By goBackLink = By.xpath("//a[contains(text(),'Go back')]");
    private By reviewStatus = By.xpath("//div[@col-id='reviewstatus']");
    private By reviewStatusValue = By.xpath("//div[@col-id='reviewstatus']//a");
    protected By documentNumberField = By.xpath("//input[@id='docno']");
    private By documentNumberText = By.xpath("//div[@id='docno']//div[1]");
    protected By saveTempFiles = By.xpath("//button[contains(text(),'Save in Temporary Files')]");
    protected By uploadBtn = By.xpath("//button[contains(text(),'Register')]");
    protected By btnUploadDocument=By.id("btnUploadDocument");
    protected By uniqueDocumentMessage = By.xpath("//span[text()='This document number is already taken. Enter a unique document number.']");
    protected By spanReadyToRegister = By.xpath("//span[contains(text(),'Ready to register')]");
    private By autoNumbering = By.xpath("//input[@id='autonumber']");
    private By downloadImage = By.xpath("//div[@class='fileTypeTemplate']//img[@title='Download File']");
    protected By documentSupersedeCheck = By.xpath("//span[text()='Current version:']");
    protected By btnUpload = By.xpath("//div[text()='Upload']");
    private By viewInTemporaryFiles = By.xpath("//div[contains(@class,'auiModal-dialog')]//a[contains(text(),'View') and contains(text(),'Temporary Files')]");
    private By docVersion = By.xpath("(//div[@col-id='version'])[2]");
    protected By editDocNum = By.xpath("//acx-unified-upload-document-number-field//span[@class='icon icon-edit-pencil ng-scope']");
    private By gridViewResults = By.xpath("//div[@class='searchNav clearfix']//ul/li");
    private By revisionFilter = By.xpath("//input[contains(@title,'Revision')]");
    private By docNoFilter = By.xpath("//input[@name='docno']");
    private By dateFilterQuery = By.xpath("//select[@class='drp_query']");
    private By dateQualifier = By.xpath("//select[@class='drp_qualifier']");
    private By btnUpArrow = By.xpath("//div[@class='updown-container']/button[@title='Move selected items one position up the list']");
    private By btnDownArrow = By.xpath("//div[@class='updown-container']/button[@title='Move selected items one position down the list']");
    private By chkboxFileContent = By.xpath("//input[@id='isSearchDocContent']");
    private By grid = By.xpath("//div[@role='grid']");
    private By docRegCancelBtn = By.xpath("//button[@id='btnattachDocs_panel_cancel']");
    private By docFileNames = By.xpath("//div[@class='files']//li//div[@class='filename ng-binding']");
    protected By docUploadSuccess = By.xpath("//div[@class='auiMessage success']");
    protected By btnMoreFiltersArrow = By.xpath("//span[@class='auiIcon auiCollapsibleSection-headerArrow chevronRight']");
    protected String pinFilters = "//div[@class='hbox pinnedFilters']//acx-document-search-field//div[@class='auiForm-field ng-scope']";
    protected By lnkAllFilters = By.xpath("//div[@class='auiButton link searchActionButton filterCollapseToggle']/span[contains(text(),'All filters')]");
    protected By fileNames = By.xpath("//div[not(@role='presentation') and @col-id='filename']");
    private By eventLogLink = By.xpath("//a[contains(.,'Event Log')]");
    private String btnConfirmPanelOk = "//button[contains(@id,'_panel-commit')]//div[text()='OK']";
    private By dateTypePicker = By.xpath("//div[@class='auiForm-field']//acx-date-type-picker");
    private By dateRangePicker = By.xpath("//div[@class='auiForm-field ng-scope']//acx-date-range-picker");
    private By resetPinnedFilters = By.xpath("//button[text()='Reset pinned filters']");
    private By confirmReset = By.xpath("//button[contains(text(),'Reset to default')]");
    private By totalNoOfPages = By.xpath("//div[@class='auiPagination-manualPage']/span[2]");
    private By currentSortIcon=By.xpath("//div[contains(text(),'Date Uploaded')]//..//*[contains(@class,'auiIcon arrowUp')]//..");
    private By downSortIcon=By.xpath("//div[contains(text(),'Date Uploaded')]//..//*[contains(@class,'customSortDownLabel customHeader-sorting active hideElement showElement')]");
    String upSortIconClass="customSortUpLabel customHeader-sorting active hideElement showElement";

    /**
     * Method to navigate to Document and verify for the title of the page
     */
    public void navigateAndVerifyPage(String page) {
        switch (page) {
            case "Document Register":
                new DocumentRegisterPage().navigateAndVerifyPage();
                break;
            case "Assets":
                new DocumentRegisterPage().navigateAndVerifyPage("Assets");
                break;
            case "Temporary Files":
                new TemporaryFilesPage().navigateAndVerifyPage();
                break;
            case "Drawings":
                new DrawingsPage().navigateAndVerifyPage();
                break;
            case "Multiple File Upload":
            case "Add Documents":
                new MultiFileUploadPage().navigateAndVerifyPage();
                break;
            case "Add Placeholders":
                new CreatePlaceholdersPage().navigateAndVerifyPage();
                break;
        }
    }

    /**
     * Method to navigate to Document and verify for the title of the page
     */
    public void navigateAndVerifyPage(String page, String docType) {
        switch (page) {
            case "Document Register":
                new DocumentRegisterPage().navigateAndVerifyPage(docType);
                break;
            case "Temporary Files":
                new TemporaryFilesPage().navigateAndVerifyPage(docType);
                break;
            case "Drawings":
                new DrawingsPage().navigateAndVerifyPage(docType);
                break;
            case "Multiple File Upload":
                new MultiFileUploadPage().navigateAndVerifyPage(docType);
                break;
        }
    }

    /**
     * Function to search document with Doc Number
     *
     * @param documentNumberVar
     */
    public void searchDocumentNo(String documentNumberVar) {
        $(loadingIcon).should(disappear);
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, searchDocKeywords, 60);
        $(searchDocKeywords).clear();
        commonMethods.waitForElementExplicitly(1000);
        $(searchDocKeywords).sendKeys(documentNumberVar + Keys.ENTER);
//        for (int i = 0; i < 5; i++) {
            commonMethods.waitForElementExplicitly(5000);
            if (!$(documentNumber).isDisplayed()) {
                $(searchDocKeywords).clear();
                commonMethods.waitForElementExplicitly(2000);
                $(searchDocKeywords).sendKeys(documentNumberVar + Keys.ENTER);
                $(loadingIcon).should(disappear);
//            } else {
//                break;
//            }
        }
    }

    /**
     * Function to refresh search Document field
     */
    public void refreshSearchDocument() {
        commonMethods.waitForElement(driver, searchDocKeywords, 30);
        $(searchDocKeywords).clear();
        $(searchDocKeywords).pressEnter();
        commonMethods.waitForElementExplicitly(1000);
        verifyAndSwitchFrame();
        clickDocumentSearch();
    }


    /**
     * Function to submit print request for document
     */
    public void submitPrintRequest() {
        $(toolsBtn).click();
        commonMethods.waitForElement(driver, printRequest, 15);
        $(printRequest).click();
    }

    /**
     * Select the document checkbox for the row number specified
     *
     * @param row
     */

    public void selectDocumentCheckBox(int row) {
        verifyAndSwitchFrame();
        By checkBox = By.xpath("//div[@row-id='" + row + "']//span[@class='ag-selection-checkbox']");
//        try {
//            commonMethods.waitForElement(driver, checkBox, 10);
//        } catch (TimeoutException e) {
//            clickDocumentSearch();
//        }
//        try {
//            commonMethods.waitForElement(driver, checkBox, 10);
//        } catch (TimeoutException e) {
//            clickDocumentSearch();
//        }
        commonMethods.waitForElement(driver, checkBox, 30);
        $(checkBox).click();
    }

    /**
     * Select all documents in page
     */

    public void selectAllRecords() {
        commonMethods.waitForElementExplicitly(5000);
        commonMethods.waitForElement(driver, linkSelectAll, 60);
        Actions actions = new Actions(driver);
        actions.moveToElement($(linkSelectAll)).click().perform();
        if ($(linkSelectAll).isDisplayed()) {
            $(linkSelectAll).click();
        }
    }

    /**
     * UnSelect all documents in page
     */

    public void clearAllRecords() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, linkClearAll, 15);
        $(linkClearAll).click();
    }

    /**
     * Function to return the table size
     *
     * @return
     */
    public int getTableSize() {
        $(resultTable).scrollTo();
        String sizeStr = $(resultSummary).getText();
        return (Integer.parseInt(sizeStr.split(" ")[0]));
    }

    /**
     * Function to return the table contents
     *
     * @param driver
     * @return
     */
    public Map<Integer, Map<String, String>> returnDocumentTableData(WebDriver driver) {

        return commonMethods.convertUITableToHashMap(driver, resultTable, resultTableRow);

    }

    /**
     * Method to return the values present in the left section of the table.
     * Within the visibility range, hence easier to fetch the values
     * Get document number from UI
     *
     * @return
     */
    //Need to test it and scale it to multiple rows. WIP
    public String returnDocumentNumber(int index) {
        return returnCellValues(documentNumber, index);
    }

    public String returnForwardedMailNumber(WebDriver driver) {
        return returnCellValues(forwardMailNum, 1);
    }


    /**
     * @return
     */
    //Need to test it and scale it to multiple rows. WIP
    public void clickHyperLink(int index) {
        verifyAndSwitchFrame();
        List<WebElement> list = driver.findElements(hyperLink);
        $(docHyperLink).click();
    }

    /**
     * Method to return manual lock if present
     *
     * @param driver
     * @return
     */

    public boolean returnManualLock(WebDriver driver) {
        return returnCellValue(lockImage, 1);
    }

    /**
     * Method to return manual lock if present
     *
     * @param driver
     * @return
     */

    public boolean returnManualUnLock(WebDriver driver) {
        return returnCellValue(unLockImage, 1);
    }

    /**
     * Method to return shared lock if present
     *
     * @param driver
     * @return
     */

    public boolean returnWorkflowLock(WebDriver driver) {
        return returnCellValue(workflowLockImg, 1);

    }

    /**
     * Method to return shared lock if present
     *
     * @param driver
     * @return
     */

    public boolean returnSharedLock(WebDriver driver) {
        return returnCellValue(sharedImage, 1);

    }

    /**
     * Method to return the values of candidate Document Number
     *
     * @param driver
     * @return
     */

    public String returnCandidateDocumentNumber(WebDriver driver) {
        return returnCellValues(candidateNumber, 2);
    }

    /**
     * Method to return the values of file name
     *
     * @param driver
     * @return
     */

    public String returnFileName(WebDriver driver) {
        return returnCellValues(fileName, 2);
    }

    /**
     * Method to return the revision date from the table
     *
     * @return
     */
    public String returnRevisionDate() {
        return returnCellValues(revisionDate, 2);
    }

    /**
     * Method to return the revision value from the table
     *
     * @return
     */
    public String returnRevision(int rowIndex) {
        return returnCellValues(revision, rowIndex);
    }

    /**
     * Method to return the revision value from the table
     *
     * @return
     */
    public String returnDiscipline(WebDriver driver) {
        return returnCellValues(discipline, 2);
    }

    /**
     * Function to return Confidential value
     *
     * @param driver
     * @return
     */
    public String returnConfidentialValue(WebDriver driver) {
        return returnCellValues(confidential, 2);
    }

    /**
     * Function to return title of the Document
     *
     * @return
     */
    public String returnTitle() {
        return returnCellValues(title, 2);
    }

    /**
     * Method to return the value of discipline from the table
     *
     * @param headersList Using it to scroll
     * @param rowIndex    index of the rows when multiple rows exist
     * @return
     */
    public String returnDiscipline(List<String> headersList, int rowIndex) {
        return returnCellValues(headersList, discipline, rowIndex);
    }

    /**
     * Method to return the value of the doc status from the table
     *
     * @return
     */
    public String returnDocumentStatus(WebDriver driver) {
        return returnCellValues(docStatus, 2);
    }

    /**
     * Method to return the value of the doc status from the table
     *
     * @return
     */
    public String returnReviewStatus(int row) {
        return returnCellValues(docReviewStatus, row);
    }

    /**
     * Method to return the value of the doc version from the table
     *
     * @return
     */
    public String returnDocumentVersion() {
        return $(docVersion).getText();
    }


    /**
     * Method to return the value of the date modified from the table
     *
     * @param headersList Using it to scroll
     * @param rowIndex    index of the rows when multiple rows exist
     * @return
     */
    public String returnDateModified(List<String> headersList, int rowIndex) {
        return returnCellValues(headersList, dateModified, rowIndex);
    }

    /**
     * Method to return the value present under Date Uploaded
     *
     * @param driver
     * @return
     */
    public String returnDateUploaded(WebDriver driver) {
        commonMethods.waitForElementExplicitly(2000);
        return returnCellValues(dateUploaded, 2);
    }

    /**
     * Method to return the value present under Document Type
     *
     * @return
     */

    public String returnDocumentType() {
        commonMethods.waitForElementExplicitly(2000);
        return returnCellValues(docType, 2);
    }

    /**
     * Method to return value present under doc title
     *
     * @param driver
     * @return
     */
    public String returnDocumentTitle(WebDriver driver) {
        return returnCellValues(docTitle, 2);
    }

    /**
     * Method to return the value present under HyperLink
     *
     * @param driver
     * @return
     */

    public String returnHyperLink(WebDriver driver) {
        return returnCellValues(docHyperLink, 2);
    }

    /**
     * Method to return the value if visible in the page, else scroll and search again
     *
     * @param headersList
     * @param by          of the scrollable item
     * @param rowIndex    index of the rows when multiple rows exist
     * @return
     */
    public String returnCellValues(List<String> headersList, By by, int rowIndex) {

        //Scroll index is 6 as the index of the first scrollable item in the table is usually either 6 or 7
        int scrollIndex = 6;

        for (int i = 0; i < (headersList.size() / 4); i++) {
            try {
                //Try to locate the cell from the required row
                List<WebElement> cellElements = driver.findElements(by);
                return cellElements.get(rowIndex).getText();
            } catch (Exception e) {
                //Locate the scroll and scroll to the last available header cell
                locateScrollBar();
                By scrollToBy = By.xpath("//div[@class='ag-header-viewport']//*//div[@class='customHeaderLabel' and text()='" + headersList.toArray()[scrollIndex] + "']");
                moveScrollBar(driver, scrollToBy);
                scrollIndex += 4;
            }
        }
        return null;
    }

    /**
     * Method to scroll to the end of the table
     */
    public void scrollToEnd() {
        commonMethods.waitForElementExplicitly(2000);
        verifyAndSwitchFrame();
        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(scrollBarBy)).clickAndHold().moveByOffset(325, 0).perform();
    }

    /**
     * Method to return the value if visible in the page, used for left section table cells
     *
     * @param by of the scrollable item
     * @param rowIndex index of the rows when multiple rows exist
     * @return
     */
    public String returnCellValues(By by, int rowIndex) {
        commonMethods.waitForElementExplicitly(3000);
        List<WebElement> cellElements = driver.findElements(by);
        return cellElements.get(rowIndex - 1).getText();
    }

    /**
     * Method to locate the scroll bar element
     */
    public void locateScrollBar() {
        //Scrolling the other elements into view
        commonMethods.waitForElementExplicitly(2000);
        WebElement scrollBarElement = $(scrollBarBy);
        //Move the mouse to the scroll bar element
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", scrollBarElement);
    }

    /**
     * Method that identifies the last visible header, uses offset and scroll the page towards the right
     *
     * @param driver
     * @param by
     */
    public void moveScrollBar(WebDriver driver, By by) {
        Actions actions = new Actions(driver);
        WebElement tableElement = $(by);
        actions.moveToElement(tableElement).perform();
        //Move to the scroll bar and click on it
        actions.moveByOffset(0, 30).click().perform();
        actions.click().perform();
    }

    /**
     * Function to verify unavailable error window
     */
    public boolean verifyDocUnavailableErrorMsg() {
        commonMethods.waitForElementExplicitly(2000);
        return $(reasonTxt).isDisplayed();

    }

    public String returnDocumentDiscipline(WebDriver driver) {
        return returnCellValues(discipline, 2);
    }

    /**
     * Function to select first check box
     */
    public void selectFirstWfDocChkBox() {
        $(firstDocumentChkBox).click();
    }

    public void navigateBack() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, backBtn, 30);
        $(backBtn).click();
    }

    public void attachDocument(String docNo) {
        verifyAndSwitchFrame();
        if ($(openFullSearch).exists()) {
            $(openFullSearch).click();
        }
        commonMethods.waitForElementExplicitly(2000);
        clearAllFilters();
        commonMethods.waitForElementExplicitly(1000);
        searchDocumentNo(docNo);
        attachFirstFile();
        switchToOriginal();
    }

    /**
     * Method to click on attach button of Document Register open full search page
     */

    public void clickAttachFile() {
        $(attachFile).click();
    }

    public void attachDocument(String docNo, String revision) {
        verifyAndSwitchFrame();
        if ($(openFullSearch).exists()) {
            $(openFullSearch).click();
        }
        commonMethods.waitForElementExplicitly(2000);
        showAllFilters();
        clearAllFilters();
        clickShowDocumentHistory(true);
        searchDocumentNo(docNo);
        clickDocumentSearch();
        commonMethods.waitForElement(driver, By.xpath(revisionSize), 10);
        int size = driver.findElements(By.xpath(revisionSize)).size();
        int count = 0;
        for (int i = 1; i <= size; i++) {
            count++;
            if ($(By.xpath("//div[@class='ag-center-cols-container']/div[" + i + "]//div[@col-id='revision']//span")).text().equalsIgnoreCase(revision)) {
                break;
            }
        }
        selectDocumentCheckBox(count - 1);
        $(attachFile).click();
    }

    /**
     * Function to click on show filters link
     */

    public void showAllFilters() {
        verifyAndSwitchFrame();
        if (!$(expandDFilters).isDisplayed()) {
            $(showAllFilter).click();
        }
    }


    /**
     * Function to click on checkbox show document history
     */

    public void clickShowDocumentHistory(boolean value) {
        $(documentHistoryCheckBox).setSelected(value);
    }

    /**
     * Method to click on full search
     */

    public void clickFullSearch() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, openFullSearch, 50);
        commonMethods.clickOnElement(openFullSearch);
    }

    /**
     * Method to attach the document in Document Register page
     */
    public void attachFirstFile() {
        commonMethods.waitForElement(driver, selectFirstFile, 35);
        $(selectFirstFile).click();
        commonMethods.waitForElement(driver, attachFile, 20);
        $(attachFile).click();
    }


    /**
     * Method to click the First File
     */

    public void selectFirstFile() {
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, selectFirstFile, 60);
        $(selectFirstFile).scrollTo();
        commonMethods.sleep(3000);
        $(selectFirstFile).click();
    }

    /**
     * Method to click the Last File
     */

    public void selectLastFile() {
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, selectLastFile, 60);
        $(selectLastFile).scrollTo();
        $(selectLastFile).click();
    }

    /**
     * Method to click the event log for Last File
     * selectLastFile
     */

    public void selectEventLogForLastFile() {
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, selectLastFileDots, 60);
        $(selectLastFileDots).scrollTo();
        $(selectLastFileDots).click();
        commonMethods.clickOnElement((eventLogLink));
    }

    /**
     * Method to return the document number from the json file
     *
     * @param docId
     * @return
     */
    public String returnDocumentNumber(String docId) {
        String docDataPath = configFileReader.getDocumentDataPath();
        Map<String, Map<String, Object>> mapOfMap = dataSetup.loadJsonDataToMap(docDataPath);
        Map<String, Object> map = mapOfMap.get(docId);
        return map.get("doc_num").toString();
    }

    /**
     * Method to refresh page and navigate to Doc Register and search Document
     *
     * @param documentNumber
     */

    public void refreshAndSearchDoc(String documentNumber) {
        refresh();
        navigateAndVerifyPage("Document Register");
        verifyAndSwitchFrame();
        clearAllFilters();
        searchDocumentNo(documentNumber);
    }

    /**
     * Function to click on show filters link
     */
    public void clickAllFilters() {
        if (!$(collapsibleFilter).exists()) {
            commonMethods.waitForElementExplicitly(2000);
            commonMethods.waitForElement(driver, allFilters, 45);
            $(allFilters).click();
        }
    }

    /**
     * Function to click on show filters link
     */
    public void clickHideFilters() {
        verifyAndSwitchFrame();
        if ($(collapsibleFilter).exists()) {
            $(allFilters).click();
        }
    }


    /**
     * Method to return boolean value of locks present
     *
     * @param by
     * @param rowIndex
     * @return
     */

    public boolean returnCellValue(By by, int rowIndex) {
        commonMethods.waitForElementExplicitly(3000);
        List<WebElement> cellElements = driver.findElements(by);
        return commonMethods.cellElementDisplayed(cellElements, rowIndex);
    }

    /**
     * Function to verify the message which is displayed when no data is present
     *
     * @return
     */

    public boolean checkEmptyRecords() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        if ($(noResultsFound).isDisplayed() || $(enterSearchCriteria).isDisplayed()) {
            return true;
        } else {
            return false;
        }
    }
    /**
     * Function to verify the documents are present in the register
     *
     * @return
     */

    public boolean verifyDocumentsPresence() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        if ($$(docResultsLink).size()>=1) {
            return true;
        } else {
            return false;
        }
    }
    /**
     * Function click on Doc search button
     */
    public void clickDocumentSearch() {
        commonMethods.waitForElement(driver, searchBtn, 20);
        $(searchBtn).click();
        sleep(1000);
        $(searchDocKeywords).sendKeys(Keys.ENTER);
        Actions actionProvider = new Actions(driver);
        actionProvider.clickAndHold($(searchBtn)).build().perform();
        sleep(1500);
        actionProvider.release($(searchBtn)).build().perform();
        actionProvider.click($(searchBtn)).build().perform();
    }

    /**
     * Function to send value to filter
     *
     * @param filter
     * @param value
     */
    public void sendValueToFilter(String filter, String value) {
        commonMethods.scrollPageUp(WebDriverRunner.getWebDriver());
        clickMoreFilters();
        commonMethods.scrollPageUp(WebDriverRunner.getWebDriver());
        commonMethods.waitForElementExplicitly(2000);
        By element = By.xpath("//div[text()='" + filter + "']//..//input");
        commonMethods.waitForElement(driver, element, 30);
        $(element).clear();
        $(element).sendKeys(value);
        commonMethods.waitForElementExplicitly(2000);
        $(element).sendKeys(Keys.ENTER);
        $(searchDocKeywords).sendKeys(Keys.ENTER);
    }

    /**
     * Function to return the number of rows in a page
     *
     * @return
     */

    public int returnNumberOfRows() {
        verifyAndSwitchFrame();
        String docName = getDocumentMenuName();
        addColumns(docName.substring(0, docName.length() - 1) + " No");
        getElementInView(documentNumber);
        commonMethods.waitForElement(driver, documentNumber, 60);
        return $$(documentNumber).size();
    }

    /**
     * Function to add column if not present
     *
     * @param columnName is the column name which has to be added
     */
    public List<String> addColumnIfNotPresent(String columnName, String page) {
        MailPage mailPage = new MailPage();
        commonMethods.waitForElementExplicitly(2000);
        List<String> columnHeader = returnColumnHeaders(driver);
        if (!columnHeader.contains(columnName)) {
            clickAddRemoveColumns();
            mailPage.addColumns(Collections.singletonList(columnName));
            mailPage.clickOk();
        }
        return columnHeader;
    }

    /**
     * Function to remove column present
     *
     * @param columnName is the column name which has to be added
     */
    public void removeColumn(String columnName, String page) {
        MailPage mailPage = new MailPage();
        commonMethods.waitForElementExplicitly(2000);
        resetToDefault();
        List<String> columnHeader = returnColumnHeaders(driver);
        if (columnHeader.contains(columnName)) {
            verifyAndSwitchFrame();
            clickAddRemoveColumns();
            mailPage.removeColumns(Collections.singletonList(columnName));
            $(addRemoveColumnsOkBtn).click();
        }
    }


    /**
     * Method to return all the headers values of the column in the table
     *
     * @param driver
     * @return
     */
    public List<String> returnColumnHeaders(WebDriver driver) {

        //We click on the add/remove columns button. Fetch all the selected columns
        clickAddRemoveColumns();
        MailPage mailPage = new MailPage();
        List<String> list = mailPage.returnSelectedColumns();
        list.add(0, "");
        //Load it into a list and click on cancel button.
        // A empty value is added in the start because an empty value is present in the start of the results
        clickCancelBtn();
        return list;
    }

    /**
     * Method to click on Cancel button
     */
    public void clickCancelBtn() {
        // commonMethods.waitForElement(driver, saveTempFiles, 60);
        commonMethods.waitForElementExplicitly(2000);
        List<WebElement> list = driver.findElements(cancelBtn);
        list.get(list.size() - 1).click();
    }

    /**
     * Method to click on Close button
     */
    public void clickCloseBtn() {
        $(closeBtn).click();
    }

    /**
     * Method to click on Restore Defaults link
     */
    public void restoreDefaults() {
        commonMethods.waitForElement(driver, restoreDefault, 60);
        $(restoreDefault).click();
        $(addRemoveColumnsOkBtn).click();
    }

    /**
     * Method to click on Add and Remove Columns button
     */
    public void clickAddRemoveColumns() {
        commonMethods.waitForElementExplicitly(4000);
        verifyAndSwitchFrame();
        commonMethods.waitForPageLoad(driver);
        commonMethods.waitForElement(driver, addRemoveColumnBtn, 60);
        commonMethods.waitForElementClickable(driver, addRemoveColumnBtn, 60);
        commonMethods.waitForElementExplicitly(3000);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", $(addRemoveColumnBtn));
    }

    /**
     * Method to verify the default columns configured in preference page
     */

    public boolean verifyDefaultColumns(List<String> data) {
        List<String> allItems = getAllSelectedItems();
        System.out.println(allItems.containsAll(data));
        return allItems.containsAll(data);
    }

    /**
     * Method to verify the default columns configured in preference page
     */

    public void verifyColumnHeaders(List<String> data) {
        List<String> colHeader = returnColumnHeaders(driver);
//        for (int i = 1; i < colHeader.size(); i++) {
//            Assert.assertTrue(data.contains(colHeader.get(i)));
//        }
        Assert.assertTrue(colHeader.containsAll(data));
    }

    /**
     * Method to click on OK button in Add Remove columns pop up
     */

    public void clickOkBtn() {
        commonMethods.waitForElement(driver, addRemoveColumnsOkBtn, 30);
        $(addRemoveColumnsOkBtn).click();
    }


    /**
     * Function to verify show doc History chkBox
     *
     * @return
     */
    public boolean verifyShowDocHistory() {
        verifyAndSwitchFrame();
        return $(documentHistoryCheckBox).isDisplayed();
    }

    /**
     * Function to reset columns selected
     */

    public void resetToDefault() {
        verifyAndSwitchFrame();
        getElementInView(addRemoveColumnBtn);
        commonMethods.waitForElement(driver, addRemoveColumnBtn, 3);
        $(addRemoveColumnBtn).click();
        restoreDefaults();
    }

    /**
     * Function to verify special characters or wildcards message
     *
     * @return
     */

    public boolean verifyWildcardsMessage() {
        commonMethods.waitForElement(driver, wildCardMessage, 6);
        return $(wildCardMessage).isDisplayed();
    }

    /**
     * Function to get the text present in supersearch
     *
     * @return
     */

    public String returnSearchText() {
        verifyAndSwitchFrame();
        driver = WebDriverRunner.getWebDriver();
        $(searchDocKeywords).click();
        return $(searchDocKeywords).getAttribute("value");
    }

    /**
     * Function to verify the elements in Add remove column pop up
     */

    public void verifyElementAddRemoveColumns() {
        driver.switchTo().defaultContent();
        verifyAndSwitchFrame();
        $(availableFilter).exists();
        $(selectedFilter).exists();
        $(restoreDefault).exists();
        $(addRemoveColumnsOkBtn).exists();
        $(cancelBtn).exists();
        $(resetBtn).exists();
        $(filterSearch).exists();
        $(addButton).exists();
        $(removeBtn).exists();
    }

    /**
     * Function to click on Document Activity Button
     */

    public void clickDocumentActivity() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, documentActivity, 5);
        commonMethods.clickOnElement(documentActivity);
    }

    /**
     * Function to verify Document Present in Document Activity
     */

    public boolean verifyDocumentActivity(String documentNum) {
        By document = By.xpath("//div[contains(text(),'" + documentNum + "')]");
        commonMethods.waitForElement(driver, document, 35);
        return $(document).isDisplayed();
    }

    /**
     * Function to verify Document Activity pop up
     */

    public boolean verifyDocumentActivity() {
        commonMethods.waitForElement(driver, viewRecentDocActivity, 5);
        return $(viewRecentDocActivity).isDisplayed();
    }

    /**
     * Function add filter in Document register
     *
     * @param filter
     */
    public void addFilter(String filter) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.loadPage(driver);
        if (!$(By.xpath("//div[text()='" + filter + "']//..//input")).isDisplayed()) {
            if (!checkFilterExpand()) {
                commonMethods.waitForElement(driver, addMoreFilters, 20);
                getElementInView(addMoreFilters);
                $(addMoreFilters).click();
            }
            commonMethods.waitForElementExplicitly(3000);
            js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
            getElementInView(By.xpath("//div[text()='" + filter + "']//..//input"));
            action.moveToElement($(By.xpath("//div[text()='" + filter + "']//..//input"))).click($(By.xpath("//div[@class='filter-wrapper ng-scope']//div//div[text()='" + filter + "']//..//..//..//a[@title='Pin']"))).build().perform();
        }
    }

    /**
     * check for More filer expand
     *
     * @return
     */
    public boolean checkFilterExpand() {
        return $(expandFilter).isDisplayed();
    }

    /**
     * Function to clear all filters applied
     */

    public void clearAllFilters() {
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.scrollPageUp(driver);
        clickOnDocSearchField();
        commonMethods.waitForElementExplicitly(2000);
        if ($(clearAllFilter).isDisplayed()) {
            commonMethods.waitForElementExplicitly(1000);
            $(clearAllFilter).click();
        }
    }

    /**
     * Function to select the option for the date uploaded field
     *
     * @param option
     */

    public void selectDateUploaded(String option) {
        By dateUploadedValue = By.xpath("//div[text()='" + option + "']");
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, dateTypePicker, 30);
        $(dateTypePicker).click();
        commonMethods.waitForElement(driver, dateUploadedDropdown, 30);
        $(dateUploadedDropdown).click();
        commonMethods.waitForElementExplicitly(1000);
        $(dateRangePicker).click();
        $(dateUploadedValue).click();
    }

    /**
     * Function to verify selected records
     *
     * @return
     */
    public boolean verifySelectedRecords(String flag) {
        verifyAndSwitchFrame();
        if (flag.equalsIgnoreCase("selected")) {
            commonMethods.waitForElement(driver, selectedCheckBox, 35);
            return $(selectedCheckBox).isDisplayed();
        } else {
            return $(unSelectedCheckBox).isDisplayed();
        }
    }

    /**
     * Function to verify Added column in Add Remove column pop up
     *
     * @return
     */

    public boolean addColumnsToSelected() {
        verifyAndSwitchFrame();
        $(addRemoveColumnBtn).click();
        List<String> allFilteredEle = getAllFilteredItems();
        $(By.xpath("//option[@label='" + allFilteredEle.get(0) + "']")).click();
        commonMethods.waitForElement(driver, addButton, 3);
        $(addButton).click();
        return checkForElement(allFilteredEle.get(0), true);
    }

    /**
     * Function to verify Removed column in Add Remove column pop up
     *
     * @return
     */

    public boolean removeColumnsFromSelected() {
        List<String> allSelectItems = getAllSelectedItems();
        $(By.xpath("//div[@class='manual-sort']/select[@add-titles-on-change='selectedItems']//option[@label='" + allSelectItems.get(0) + "']")).click();
        commonMethods.waitForElement(driver, removeBtn, 3);
        $(removeBtn).click();
        return checkForElement(allSelectItems.get(0), false);

    }

    /**
     * Function to move columns up in Add Remove column pop up
     *
     * @return
     */

    public boolean moveColumnsUp() {
        int i = 1;
        List<String> allSelItemsInitial = getAllSelectedItems();
        $(By.xpath("//div[@class='manual-sort']/select[@add-titles-on-change='selectedItems']//option[@label='" + allSelItemsInitial.get(i) + "']")).click();
        commonMethods.waitForElement(driver, moveUpBtn, 3);
        $(moveUpBtn).click();
        List<String> allSelItemsFinal = getAllSelectedItems();
        if (allSelItemsInitial.get(i).equals(allSelItemsFinal.get(i - 1))) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Function to move columns down in Add Remove column pop up
     *
     * @return
     */

    public boolean moveColumnsDown() {
        int i = 1;
        List<String> allSelItemsInitial = getAllSelectedItems();
        $(By.xpath("//div[@class='manual-sort']//select[@add-titles-on-change='selectedItems']//option[@label='" + allSelItemsInitial.get(i) + "']")).click();
        commonMethods.waitForElement(driver, moveDownBtn, 3);
        $(moveDownBtn).click();
        List<String> allSelItemsFinal = getAllSelectedItems();
        if (allSelItemsInitial.get(i).equals(allSelItemsFinal.get(i + 1))) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Function to get all filtered column names in Add Remove column pop up
     *
     * @return
     */

    public List<String> getAllFilteredItems() {
        List<String> allText = new ArrayList<>();
        List<WebElement> allItems = driver.findElements(allFilteredItems);
        for (WebElement items : allItems) {
            allText.add(items.getText());
        }
        return allText;
    }

    /**
     * Function to check whether column name is present in selected Items of Add Remove column pop up
     *
     * @return
     */

    public boolean checkForElement(String elementName, Boolean elementPresent) {
        if (elementPresent == true) {
            List<String> allele = getAllSelectedItems();
            for (int i = 0; i <= allele.size() - 1; i++) {
                if (allele.get(i).equals(elementName)) {
                    return true;
                }
            }
            return false;
        } else {
            List<String> allele = getAllFilteredItems();
            for (int i = 0; i <= allele.size() - 1; i++) {
                if (allele.get(i).equals(elementName)) {
                    return true;
                }
            }
            return false;
        }
    }

    /**
     * Function to get all selected Items in Add Remove column pop up
     *
     * @return
     */

    public List<String> getAllSelectedItems() {
        List<String> allSelText = new ArrayList<>();
        List<WebElement> allItems = driver.findElements(allSelectedItems);
        for (WebElement items : allItems) {
            allSelText.add(items.getText());
        }
        return allSelText;
    }


    /**
     * Function to click Enter on super search Input text box
     */

    public void clickEnterOnSearch() {
        commonMethods.waitForElement(driver, searchDocKeywords, 30);
        ((JavascriptExecutor) driver).executeScript(
                "arguments[0].scrollIntoView();", $(searchDocKeywords));
        commonMethods.waitForElementExplicitly(1000);
        $(searchDocKeywords).sendKeys(Keys.ENTER);
    }

    /**
     * Function to enter Document No in search text box and press enter
     */

    public void searchDocUsingEnter(String documentNo) {
        commonMethods.waitForElement(driver, searchDocKeywords, 30);
        ((JavascriptExecutor) driver).executeScript(
                "arguments[0].scrollIntoView();", $(searchDocKeywords));
        commonMethods.waitForElementExplicitly(1000);
        $(searchDocKeywords).sendKeys(documentNo + Keys.ENTER);
    }

    /**
     * Function to select organisation from transmitted list
     *
     * @organisations list of organisation
     */
    public void selectOrganisation(ArrayList<String> organisations) {
        verifyAndSwitchFrame();
        int size = driver.findElements(selectHistoryOrganisation).size();
        if (size > 0) {
            for (int i = 1; i <= size; i++) {
                $(selectFirstOrganisation).doubleClick();
            }
        }
        for (String org : organisations) {
            $(By.xpath("//select[@name='ORGS_AVAIL']//option[contains(.,'" + org + "')]")).doubleClick();
        }
    }

    /**
     * Function to verify options under Transmit button
     *
     * @return
     */

    public boolean verifyTransmitOption(String option) {
        commonMethods.waitForElementExplicitly(2000);
        return $(By.xpath("//div[@class='auiMenuButton-dropdownContents']//a[contains(text(),'" + option + "')]")).isDisplayed();
    }

    /**
     * Function to click options under Transmit button
     */

    public void clickTransmitOption(String option) {
        commonMethods.waitForElementExplicitly(3000);
        $(By.xpath("//div[@class='auiMenuButton-dropdownContents']//a[contains(text(),'" + option + "')]")).click();
        if (commonMethods.isAlertPresent(driver)) {
            commonMethods.acceptAlert(driver);
        }
    }

    /**
     * Function to click on More Filters
     */

    public void clickMoreFilters() {
        if ($(btnMoreFiltersArrow).isDisplayed()) {
            commonMethods.scrollPageUp(driver);
            List<String> filterNames = commonMethods.getValues(By.xpath(pinFilters + "/../div[1]"));
            if (filterNames.size() > 4)
                commonMethods.getElementInViewAndUp(By.xpath("//acx-document-search-field//div[text()='" + filterNames.get(filterNames.size() - 4) + "']/../div[@class='auiForm-field ng-scope']"));
            else commonMethods.getElementInViewAndUp(lnkAllFilters);
            $(moreFilters).click();
        }
    }

    /**
     * Function to check if document is present or not
     */
    public boolean presenceOfDocument(String document) {
        commonMethods.waitForElementExplicitly(2000);
        $(loadingIcon).should(disappear);
        commonMethods.waitForElement(driver, resultTable, 60);
        getElementInView(resultTable);
        switchToListView();
        return $(firstDocumentChkBox).isDisplayed();
    }

    /**
     * Function to check if Search Result table exists
     */

    public boolean resultTable() {
        $(loadingIcon).should(disappear);
        try {
            commonMethods.waitForElement(driver, tableHead, 60);
            switchToListView();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return $(tableHead).isDisplayed();
    }

    /**
     * Method to click on attach button
     */
    public void clickAttachBtn() {
        $(attachBtn).click();
    }

    /**
     * method to select the document according to the doc number passed
     *
     * @param docNo
     */
    public void selectDocument(String docNo) {
        By xpathStr = By.xpath("//td[text()='" + docNo + "']//..//td[1]//input");
        $(xpathStr).setSelected(true);
    }

    /**
     * Function to verify document event log
     *
     * @param data as attribute
     */
    public void verifyDocumentEventLog(String event, String data) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, inputEventLogType, 60);
        $(inputEventLogType).sendKeys(event);
        hitEnter();
        Map<String, String> table = dataStore.getTable(data);
        for (String tableData : table.keySet()) {
            switch (tableData) {
                case "Type":
                    Assert.assertTrue(verifyEventType(table.get(tableData)));
                    break;
                case "Event":
                    Assert.assertTrue(verifyEvent(table.get(tableData)));
                    break;
                case "User":
                    Assert.assertTrue(verifyUserEventLog(table.get(tableData)));
                    break;
                case "Status":
                    Assert.assertTrue(verifyStatus(table.get(tableData)));
                    break;
                case "Organization":
                    Assert.assertTrue(verifyOrgEventLog(table.get(tableData)));
                    break;
                case "Document Event":
                    Assert.assertTrue(verifyDocEvent(table.get(tableData)));
                    break;
                case "Revision":
                    Assert.assertTrue(verifyEventLogField(table.get(tableData)));
                    break;
                case "Version":
                    Assert.assertTrue(verifyEventLogField(table.get(tableData)));
                    break;
                case "Date":
                    Assert.assertTrue(verifyDateEventLog(table.get(tableData)));
                    break;
            }
        }
    }

    /**
     * Function to verify doc event log type
     *
     * @param type
     * @return
     */
    public boolean verifyEventType(String type) {
        By typeTxt = By.xpath("//table[@class='auiTable']//td[text()='" + type + "']");
        commonMethods.waitForElement(driver, typeTxt, 20);
        return $(typeTxt).isDisplayed();
    }

    /**
     * Function to verify doc event log
     *
     * @param mailNum
     * @return
     */
    public boolean verifyEvent(String mailNum) {
        commonMethods.waitForElement(driver, eventLog, 20);
        return $(eventLog).getText().contains(commonMethods.getMailNumFromJson(mailNum));
    }

    /**
     * Function to verify doc event log
     *
     * @param status
     * @return
     */
    public boolean verifyStatus(String status) {
        verifyAndSwitchFrame();
        By statusTxt = By.xpath("//table[@class='auiTable']//td//span[contains(text(),'" + status + "')]");
        commonMethods.waitForElement(driver, statusTxt, 30);
        return $(statusTxt).isDisplayed();
    }

    /**
     * @param eventName
     * @return
     */

    public boolean verifyDocEvent(String eventName) {
        return $(By.xpath("//span[contains(text(),'" + eventName + "')]")).isDisplayed();
    }

    /**
     * Function to verify doc event log User
     *
     * @param user
     * @return
     */
    public boolean verifyUserEventLog(String user) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
        userMap = jsonMapOfMap.get(user);
        commonMethods.waitForElement(driver, eventLogUser, 20);
        return $(eventLogUser).getText().contains(userMap.get("full_name").toString());
    }

    /**
     * Function to verify Revision event log
     *
     * @return
     */
    public boolean verifyEventLogField(String logField) {
        return commonMethods.tableFieldIsDisplayed(driver, logField);
    }

    /**
     * Function to verify Date event log
     *
     * @return
     */
    public boolean verifyDateEventLog(String date) {
        String d = commonMethods.getDate(configFileReader.getTimeZone(), date);
        return $(By.xpath("//td[contains(text(),'" + d.substring(d.length() - 2) + "')]")).isDisplayed();
    }

    /**
     * Function to verify doc event log Org
     *
     * @param user
     * @return
     */
    public boolean verifyOrgEventLog(String user) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
        userMap = jsonMapOfMap.get(user);
        commonMethods.waitForElement(driver, eventLogUser, 40);
        return $(eventLogOrg).getText().contains(userMap.get("org_name").toString());
    }

    /**
     * Function to download file
     */
    public void downloadFile() {
        commonMethods.waitForElement(driver, dots);
        $(dots).click();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        commonMethods.clickOnElement((downloadLink));
        CommonMethods.captureExtentReportScreenShot(driver);
    }

    /**
     * Return the file name of the downloaded file
     *
     * @param path
     * @param filename
     * @return
     */
    public File fetchFile(String path, String filename) {
        File file = new File(path + filename);
        return file;
    }


    /**
     * Return the number of files present in the temporary files page
     *
     * @return
     */
    public int returnFileCount() {
        List<WebElement> fileList = driver.findElements(candidateNumber);
        return fileList.size();
    }

    /**
     * Function to click on search
     */
    public void clickSearchBtn() {
        commonMethods.waitForElement(driver, searchBtn, 30);
        $(searchBtn).click();
    }

    /**
     * Function to click on show per page option
     */

    public void selectShowPerPage(String number) {
        $(showPerPage).click();
        $(By.xpath("//a[contains(text(),'" + number + "')]")).click();
    }

    /**
     * Function to click on Document Title
     */

    public void clickDocTitle() {
        commonMethods.waitForElement(driver, documentTitle, 30);
        $(documentTitle).click();
    }

    /**
     * Function to click on Document Title
     */

    public void clickLatestDocTitle() {
        commonMethods.waitForElement(driver, documentTitleLatest, 30);
        $(documentTitleLatest).click();
    }

    /**
     * Function to navigate page on search result table
     */

    public void navigateToPage(String pageNumber) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, pageNumberBox, 40);
        $(pageNumberBox).sendKeys(Keys.CONTROL + "a");
        $(pageNumberBox).sendKeys(Keys.DELETE);
        $(pageNumberBox).sendKeys(pageNumber);
        if ($(nextArrow).isDisplayed()) {
            $(nextArrow).click();
        }
    }

    /**
     * Function to verify Empty search Box
     *
     * @return
     */

    public String getSuperSearchText() {
        commonMethods.waitForElement(driver, searchDocKeywords, 35);
        return $(searchDocKeywords).getText();
    }

    /**
     * Function to click Forward arrow of the page
     */

    public void clickForwardArrow() {
        commonMethods.waitForElementExplicitly(2000);
        $(nextArrow).click();
    }

    /**
     * Function to click backward arrow of the page
     */

    public void clickBackwardArrow() {
        commonMethods.waitForElementExplicitly(2000);
        $(prevArrow).click();
    }

    /**
     * Function to get the page Number
     *
     * @return
     */

    public String getPageNumber() {
        commonMethods.waitForElementExplicitly(2000);
        return $(pageNumberBox).getValue();
    }

    /**
     * Function to verify sorting of column Status
     *
     * @return
     */

    public boolean verifyStatusSorting() {
        addColumnIfNotPresent("Status", "Document");
        int tableSize = driver.findElements(docStatus).size();
        List<WebElement> allStatus = new ArrayList<>();
        List<String> listOfStatus = new ArrayList<>();
        for (int i = 1; i <= tableSize - 2; i++) {
            commonMethods.waitForElementExplicitly(500);
            allStatus.add(driver.findElement(By.xpath("//div[@row-id='" + i + "']//div[@col-id='docstatus']")));
        }
        for (WebElement e : allStatus) {
            listOfStatus.add(e.getText());
        }
        String[] actualValues = Arrays.copyOf(listOfStatus.toArray(), listOfStatus.size(), String[].class);
        if (actualValues.equals(commonMethods.sortAscending(actualValues)) || actualValues.equals(commonMethods.sortDescending(actualValues))) {
            return true;
        }
        return false;

    }

    public void verifyEventLog(List<Map<String, String>> list) {
        for (Map<String, String> map : list) {
            $(inputEventLogType).sendKeys(map.get("Type"));
            $(inputEvent).sendKeys(map.get("Event"));
            commonMethods.waitForElementExplicitly(2000);
            List<WebElement> elements = driver.findElements(eventTableRows);
            if (map.get("Enabled").equalsIgnoreCase("true")) {
                Assert.assertTrue(elements.size() == 1 || elements.size() > 1);
            } else {
                Assert.assertTrue(elements.size() == 0);
            }

            $(inputEventLogType).clear();
            $(inputEvent).clear();
        }
    }


    /**
     * Method to view the view in register link in the pop up window
     */
    public void clickViewInRegisterLink() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, viewInRegisterLink, 60);
        commonMethods.waitForElementExplicitly(2000);
        if ($(viewInRegisterLink).isDisplayed()) {
            commonMethods.waitForElementExplicitly(1000);
            $(viewInRegisterLink).click();
        }
    }

    /**
     * Method returns if the view in register link is present
     *
     * @return
     */
    public boolean validateViewInRegisterLink() {
        commonMethods.waitForElement(driver, viewInRegisterLink);
        return $(viewInRegisterLink).isDisplayed();
    }


    /**
     * Method returns if the view in register link is present
     *
     * @return
     */
    public boolean validateTransmitLink() {
        return $(transmitDocument).isDisplayed();
    }

    /**
     * Method to return the unique id for each document
     *
     * @return
     */
    public String returnSearchedDocumentId() {
        String value = $(searchDocKeywords).getValue();
        return value.split(":")[1];
    }

    /**
     * Click on event back button
     */
    public void clickEventBackBtn() {
        verifyAndSwitchFrame();
        $(eventBackBtn).click();
    }

    /**
     * Function  to verify page
     *
     * @param page
     */
    public void verifyPage(String page) {
        verifyAndSwitchFrame();
        Assert.assertTrue($(By.xpath("//span[contains(text(),'" + page + "')]")).isDisplayed());
    }

    /**
     * Function to verify Print req fields page
     */
    public void verifyPrintReqFields() {
        ;
        commonMethods.waitForElement(driver, attachFileBtn, 30);
        Assert.assertTrue($(attachFileBtn).isDisplayed());
        Assert.assertTrue($(addRecipientBtn).isDisplayed());
        Assert.assertTrue($(printBtn).isDisplayed());
        Assert.assertTrue($(saveDraftBtn).isDisplayed());
        Assert.assertTrue($(continueBtn).isDisplayed());
        Assert.assertTrue($(userReference).isDisplayed());
        Assert.assertTrue($(useAddress).isDisplayed());
        Assert.assertTrue($(paymentBy).isDisplayed());
        Assert.assertTrue($(deliveryBy).isDisplayed());
        Assert.assertTrue($(printShop).isDisplayed());
    }

    /**
     * Method to validate if the fields in supersede/document upload page are present in the document fields in setup tab
     *
     * @param documentFields
     * @param pageFields
     * @s/return
     */
    public boolean validateFields(List<String> documentFields, List<String> pageFields) {
        boolean flag = true;
        for (String value : pageFields) {
            if (!documentFields.contains(value)) {
                flag = false;

            }
        }
        return flag;
    }


    /**
     * Method to return the fields label in the supersede/upload page
     *
     * @return
     */
    public List<String> returnFields() {
        commonMethods.waitForElement(driver, rows, 60);
        List<String> values = new ArrayList<>();
        List<WebElement> rowsElement = driver.findElements(rows);
        for (WebElement element : rowsElement) {
            values.add(element.getText());
        }
        return values;
    }

    /**
     * Method to verify the elements on clicking Transmittal History
     */

    public void verifyElements(List<String> data) {
        commonMethods.waitForElement(driver, transmittalHistoryTxt);
        for (String name : data) {
            Assert.assertTrue($(By.xpath("//th[contains(text(),'" + name + "')]")).isDisplayed());
        }
        Assert.assertTrue($(transmittalHistoryBackBtn).isDisplayed());
        Assert.assertTrue($(exportToExcel).isDisplayed());
        Assert.assertTrue($(printButton).isDisplayed());
        Assert.assertTrue($(optionButton).isDisplayed());
    }

    /**
     * Method to return the document count
     *
     * @return
     */

    public String getDocumentCount() {
        return $(docCount).getText();
    }

    public void verifySearchAssetsLabels() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, searchHeader);
        commonMethods.waitForElementExplicitly(2000);
        Assert.assertEquals("Search - Registered Assets", $(searchHeader).getText());
        Assert.assertEquals("Asset Activity", $(activityBtn).getText());
        Assert.assertEquals("Registered Assets", $(registeredLabel).getText());
        Assert.assertEquals("Asset No", $(docNoLabel).getText());
        Assert.assertEquals("Show asset history", $(showHistoryCheckBox).getText());
        Assert.assertEquals("Asset No", $(sortByDropDown).getSelectedText());
        refresh();
    }

    /**
     * Function to sort with date uploaded column
     */
    public void sortDateUploaded() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, resultsGrid, 60);
        addColumns("Date Uploaded");
        commonMethods.waitForElement(driver, sortDateUploaded, 60);
        $(sortDateUploaded).click();
        String currentSort=$(currentSortIcon).getAttribute("class");
        if(currentSort.equalsIgnoreCase(upSortIconClass))
            $(sortDateUploaded).click();
        commonMethods.waitForElementExplicitly(3000);
        Assert.assertTrue($(downSortIcon).isDisplayed());
    }

    /**
     * Function to verify msg in Copy project page
     *
     * @param msg
     * @return
     */
    public boolean verifyDocMsg(String msg) {
        return commonMethods.tableFieldIsDisplayed(driver, msg);
    }

    /**
     * Function to click the transmit button to create a transmittal
     */
    public void clickTransmitBtn() {
        commonMethods.waitForElement(driver, transmitBtn, 40);
        getElementInView(transmitBtn);
        $(transmitBtn).click();
    }

    /**
     * Function to select multiple docs
     *
     * @param docs
     */
    public void selectMultipleDocs(List<String> docs) {
        for (int i = 0; i <= docs.size() - 1; i++) {
            commonMethods.waitForElementExplicitly(1000);
            $(By.xpath("//td[text()='" + returnDocumentNumber(docs.get(i)) + "']//..//input[1]")).click();
        }
    }

    /**
     * Function to switch copy doc page
     *
     * @param userId
     * @param projectNumber
     */
    public void selectCopyProject(String userId, String projectNumber) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
        userMap = jsonMapOfMap.get(userId);
        String projectName = userMap.get("project_name" + projectNumber.substring(projectNumber.length() - 1)).toString();
        verifyAndSwitchFrame();
        clickTransmitBtn();
        $(copyToProject).click();
        $(selectProject).selectOption(projectName);
    }

    /**
     * Method to return the tick symbol for transmitted
     *
     * @return
     */

    public boolean verifyTickSymbol() {
        //scrollToEnd();
        return $(tickSymbol).isDisplayed();
    }

    /**
     * Method to return the document number from the success message
     *
     * @return
     */
    public String returnDocNumber() {
        commonMethods.waitForElementExplicitly(5000);
        clickSearchBtn();
        clickSearchBtn();
        String docName = getDocumentMenuName();
        addColumns(docName.substring(0, docName.length() - 1) + " No");
        commonMethods.waitForElement(driver, documentNumber, 60);
        List<WebElement> list = driver.findElements(documentNumber);
        return list.get(0).getText();
    }

    /**
     * Function to verify that user cannot be removed
     */
    public Boolean cannotRemoveCurrentUser() {
        verifyAndSwitchFrame();
        //getElementInView(attribute2);
        // $(editViewAccessList).click();
        String user = getLoggedInUser();
        return $(By.xpath("//span[contains(.,'" + user + "')]//..//..//span[@class='close ui-select-match-close']")).isDisplayed();
    }

    /**
     * Function to remove user form access list
     */
    public void removeUser(String full_name) {
        verifyAndSwitchFrame();
        By element = By.xpath("//span[contains(text(),'" + full_name + "')]//..//..//span[@class='close ui-select-match-close']");
        commonMethods.waitForElement(driver, element, 55);
        $(element).click();
    }

    /**
     * Function to remove user form access list
     */
    public boolean userRemoveBtn(String full_name) {
        verifyAndSwitchFrame();
        return $(By.xpath("//span[contains(.,'" + full_name + "')]/span[@ng-hide='$select.disabled']")).isDisplayed();
    }

    /**
     * Function to get user form access list
     */
    public String getAddedUser() {
        verifyAndSwitchFrame();
        return $(accessListUsers).text();
    }

    /**
     * Method to return all the status from the select list for a document
     *
     * @return
     */
    public List<String> returnStatus() {
        commonMethods.waitForElement(driver, status);
        Select select = new Select($(status));
        List<String> list = new ArrayList<String>();
        for (WebElement element : select.getOptions()) {
            if (!element.getText().contains("Select")) {
                list.add(element.getText());
            }

        }
        return list;
    }

    /**
     * Method to return all the document types from the select list
     *
     * @return
     */
    public List<String> returnType() {
        commonMethods.waitForElement(driver, type);
        Select select = new Select($(type));
        List<String> list = new ArrayList<String>();
        for (WebElement element : select.getOptions()) {
            if (!element.getText().contains("Select")) {
                list.add(element.getText());
            }
        }
        return list;
    }


    /**
     * Method to enter data into fields to test max length of the field
     *
     * @param list
     */
    public void enterMaxFieldValues(List<Map<String, String>> list) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(docFieldsDataPath);
        //According to the keys passed in the table, we select the fields

        for (Map<String, String> map : list) {
            String key = map.get("field_name");
            Map<String, Object> fields = jsonMapOfMap.get(key);
            String type = fields.get("type").toString();
            if (type.equals("Text") || type.equals("Textarea")) {
                Faker faker = new Faker();
                int number = Integer.parseInt(fields.get("max_length").toString());
                String value = faker.company().name().substring(0, 6) + "-" + faker.number().digits(number);
                value = value.substring(0, number);
                By by = By.xpath("//label[text()='" + key + "']//parent::div//parent::div//input");
                $(by).clear();
                $(by).sendKeys(value);
            }
        }
    }

    /**
     * Method to click on OK if we get the error that updated version of
     * document is present in the document register
     */

    public void updatedVersionActions() {
        if ($(updatedVersions).isDisplayed()) {
            $(okButton).click();
        }
    }

    /**
     * Function verify permission denied msg
     *
     * @param user
     * @return
     */
    public boolean verifyDeniedMsg(String user) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
        userMap = jsonMapOfMap.get(user);
        commonMethods.waitForElement(driver, goBackLink, 40);
        return $(By.xpath("//h1[contains(text(),'Permission denied for " + userMap.get("full_name").toString() + "')]")).isDisplayed();
    }


    /**
     * Function verify value of doc review status
     *
     * @param value
     */
    public boolean verifyReviewStatus(String value) {
        getElementInView(reviewStatus);
        return $(reviewStatusValue).getText().equalsIgnoreCase(value);
    }

    /**
     * Function to click on save Template
     */
    public void clickSaveTempFiles() {
        switchToOriginal();
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(5000);
        commonMethods.waitForElement(driver, saveTempFiles, 40);
        $(saveTempFiles).click();
    }

    public void clickRegisterBtn() {
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, uploadBtn, 40);
        commonMethods.waitForElementExplicitly(3000);
        $(uploadBtn).click();
    }

    public void clickUploadBtn() {
        commonMethods.waitForElementExplicitly(5000);
        commonMethods.waitForElement(driver, btnUploadDocument, 40);
        $(btnUploadDocument).click();
    }
    /**
     * Method to validate if the message document number must be unique is displayed
     *
     * @return
     */
    public boolean validateUniqueMessage() {
        return $(uniqueDocumentMessage).isDisplayed();
    }

    public boolean isCancelBtnDisplayed() {
        List<WebElement> list = driver.findElements(cancelBtn);
        return list.get(list.size() - 1).isDisplayed();
    }

    public boolean isCancelBtnEnabled() {
        List<WebElement> list = driver.findElements(cancelBtn);
        return list.get(list.size() - 1).isEnabled();
    }

    public void clickAutoNumbering() {
        $(autoNumbering).click();
    }

    public boolean docTitlePresent(String docNo)
    {
        $(loadingIcon).should(disappear);
        commonMethods.waitForElementExplicitly(8000);
        //commonMethods.waitForElement(driver,By.xpath("//div[@col-id='title']"));
        return $(By.xpath("//div[@col-id='title']//p[contains(text(),'"+docNo+"')]")).isDisplayed();
    }
    public void clickDownloadIcon() {
        commonMethods.waitForElement(driver, downloadImage);
        $(downloadImage).doubleClick();
    }

    /**
     * Method to switch to list view
     */
    public void switchToListView() {
        if ($(listView).exists()) {
            commonMethods.waitForElementExplicitly(2000);
            if (!$(addRemoveColumnBtn).isDisplayed()) {
                $(listView).click();
                commonMethods.waitForElementExplicitly(1000);
            }
        }
    }

    /**
     * Method to click on view in Temporary files link in the pop up window
     */
    public void clickViewInTemporaryFiles() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, viewInTemporaryFiles, 60);
        if ($(viewInTemporaryFiles).isDisplayed()) {
            $(viewInTemporaryFiles).click();
        }
    }

    /**
     * Method to verify badge name displayed in upload document page
     */
    public boolean verifyBadge(String badge) {
        By xpath = By.xpath("//div[@class='fileRightIcons']//span[contains(text(),'" + badge + "')]");
        commonMethods.waitForElement(driver, xpath);
        return $(xpath).isDisplayed();
    }

    /**
     * Method to verify the table view page in Upload Documents page
     */
    public void verifyTableView() {
        Assert.assertTrue($(docType).isDisplayed());
        Assert.assertTrue($(docTitle).isDisplayed());
        Assert.assertTrue($(revision).isDisplayed());
        Assert.assertTrue($(docStatus).isDisplayed());
        moveScrollBar(driver, discipline);
        Assert.assertTrue($(discipline).isDisplayed());

    }

    /**
     * Method to verify the grid view page in Upload Documents page
     */
    public void verifyGridView() {
        verifyAndSwitchFrame();
        $(loadingIcon).should(disappear);
        try {
            commonMethods.waitForElement(driver, gridViewResults, 60);
        } catch (Exception e) {
            System.out.println("No Grid");
        }
    }

    /**
     * Function to send value to filter in old document search
     *
     * @param filter
     * @param value
     */
    public void sendValuesToFilter(String filter, String value) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        switch (filter.toLowerCase()) {
            case "type":
            case "discipline":
                By xpath = By.xpath("//select[@title='" + filter + "']");
                commonMethods.enterDropdownValue(xpath, value);
                break;
            case "revision":
                commonMethods.getElementInViewAndUp(revisionFilter);
                commonMethods.enterTextValue(revisionFilter, value);
                break;
            case "document no":
                commonMethods.getElementInViewAndUp(docNoFilter);
                commonMethods.enterTextValue(docNoFilter, value);
                break;
            case "date uploaded":
                commonMethods.enterDropdownValue(dateFilterQuery, filter);
                commonMethods.waitForElementExplicitly(500);
                commonMethods.enterDropdownValue(dateQualifier, value);
                break;
        }
    }

    /*
     * Method to verify badge name displayed in upload document page
     */
    public boolean verifyTableViewBadge(String badge) {
        By xpath = By.xpath("//div[@ref='eBodyViewport']//div[@col-id='badges']//span[contains(text(),'" + badge + "')]");
        commonMethods.waitForElement(driver, xpath);
        return $(xpath).isDisplayed();
    }

    /**
     * Method to verify whether results are displayed and add required column in results table
     */
    public void addColumns(String filterName) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        moveColToFourthPlace(filterName);
        resultTable();
        verifyAndSwitchFrame();
    }

    /**
     * Method to move column header to 4th position
     */
    public void moveColToFourthPlace(String colName) {
        MailPage mailPage = new MailPage();
        By element = By.xpath("//div[@class='manual-sort']//option[@title='" + colName + "']");
        switchToListView();
        clickAddRemoveColumns();
        List<String> list = mailPage.returnSelectedColumns();
        if (!list.contains(colName)) {
            mailPage.addColumns(Collections.singletonList(colName));
        }
        List<String> newList = mailPage.returnSelectedColumns();
        if (newList.indexOf(colName) > 3) {
            $(element).click();
            for (int i = newList.indexOf(colName); i >= 4; i--) {
                $(btnUpArrow).click();
            }
            mailPage.clickOk();
        } else if (newList.indexOf(colName) < 3) {
            $(element).click();
            for (int i = newList.indexOf(colName); i < 3; i++) {
                $(btnDownArrow).click();
            }
            mailPage.clickOk();
        } else {
            mailPage.clickCancelBtn();
        }
        commonMethods.waitForElementExplicitly(1000);
        waitForResultsDisplay(linkSelectAll);
        commonMethods.waitForElementExplicitly(1000);
    }

    /**
     * Method to update date fields in add/update document document screen
     */
    public void updateDateField(String dateValue, By dateField) {
        commonMethods.waitForElement(driver, dateField, 20);
        $(dateField).clear();
        commonMethods.waitForElementExplicitly(1000);
        if (dateValue.equalsIgnoreCase("yesterday") || dateValue.equalsIgnoreCase("today") || dateValue.equalsIgnoreCase("tomorrow")) {
            $(dateField).sendKeys(commonMethods.getDate(configFileReader.getTimeZone(), dateValue) + Keys.ENTER);
        } else {
            $(dateField).sendKeys(dateValue + Keys.ENTER);
        }
    }

    /**
     * Method to update select list field in add/update document screen
     */
    public void updateSelectListField(String xpath, String fieldValues) {
        String[] arrayValues = fieldValues.split(",");
        for (String fieldValue : arrayValues) {
            commonMethods.enterTextValue(By.xpath(xpath + "//input"), fieldValue.trim());
            commonMethods.waitForElementExplicitly(500);
            $(By.xpath(xpath + "//input")).sendKeys(Keys.ENTER);
        }
    }

    /**
     * Method to verify the document grid displayed
     */
    public boolean verifyDocumentGrid() {
        return $(grid).isDisplayed();
    }

    /**
     * Method to search document and verify the grid displayed
     */
    public boolean verifyDocGrid(String docNo) {
        clickFullSearch();
        clearAllFilters();
        commonMethods.waitForElementExplicitly(1000);
        searchDocumentNo(docNo);
        driver = WebDriverRunner.getWebDriver();
        String documentNo = returnDocumentNumber(2);
        return docNo.contains(commonMethods.returnDocNumberInJson(documentNo));
    }

    /**
     * Method to verify file contents
     */
    public boolean verifyFileContent() {
        commonMethods.waitForElement(driver, chkboxFileContent);
        return $(chkboxFileContent).isDisplayed();
    }

    /**
     * Method to set file content option
     */
    public void setFileContent(boolean option) {
        $(chkboxFileContent).setSelected(option);
    }

    public void docRegCancelBtn() {
        $(docRegCancelBtn).click();
    }

    /**
     * Methhod to select the data modified
     */
    public void selectDateModified(String option) {
        By dateModifiedValue = By.xpath("//div[text()='" + option + "']");
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, dateTypePicker, 30);
        $(dateTypePicker).click();
        commonMethods.waitForElement(driver, dateModifiedDropdown, 30);
        $(dateModifiedDropdown).click();
        commonMethods.waitForElementExplicitly(1000);
        $(dateRangePicker).click();
        $(dateModifiedValue).click();
    }

    /**
     * Method to return shared out icon if present
     *
     * @param
     * @return
     */

    public boolean returnSharedOutIcon() {
        commonMethods.waitForElementExplicitly(2000);
        return $(sharedOutIcon).isDisplayed();
    }

    /**
     * Method to return shared in icon if present
     *
     * @param
     * @return
     */
    public boolean returnSharedInIcon() {
        commonMethods.waitForElementExplicitly(2000);
        return $(sharedInIcon).isDisplayed();
    }

    /**
     * Function to return all document names in the upload document page
     */
    public List<String> getDocNameUploadPage() {
        commonMethods.waitForElement(driver, docFileNames);
        return commonMethods.getValues(docFileNames);
    }

    /**
     * Method to return files names in the doc register page
     *
     * @param
     * @return
     */
    public List<String> returnFileNames() {
        commonMethods.waitForElementExplicitly(2000);
        return commonMethods.getValues(fileNames);
    }

    /**
     * Method to fill attribute values in legacy document upload page
     */
    public void fillLegacySelectListField(String fieldName, String fieldValue) {
        By xpath = By.xpath("//table//td//div[contains(@title,'" + fieldName + "')]");
        $(xpath).click();
        commonMethods.waitForElement(driver, By.xpath("//div[@class='uiPanel-titleBar']//span[text()='" + fieldName + "']"));
        for (String value : fieldValue.split(","))
            $(By.xpath("//div[contains(@id,'_bidi')]//select/option[text()='" + value + "']")).doubleClick();
        commonMethods.waitForElementExplicitly(1000);
        $(By.xpath("(" + btnConfirmPanelOk + ")[" + $$(By.xpath(btnConfirmPanelOk)).size() + "]")).click();
    }

    public void selectDocumentAndMoveToDotsIcon() {
        commonMethods.waitForElement(driver, firstDocumentChkBox, 30);
        selectFirstWfDocChkBox();
        action.moveToElement($(dots)).build().perform();
    }

    /**
     * method to verify the alert message for the locked document(by user A) update by user B
     */
    public void verifySupersedeAlert(String user) {
        String userName = commonMethods.getUserData(user, "name");
        String alertMessage = "";
        if (commonMethods.isAlertPresent(driver)) {
            alertMessage = commonMethods.returnAlertText(driver);
            Assert.assertTrue(alertMessage.contains(userName));
            commonMethods.waitForElementExplicitly(2000);
            commonMethods.acceptAlert(driver);
        } else {
            Assert.assertTrue("Supersede Alert popup is not displayed", false);
        }
    }

    /**
     * Function to sort with date modified column
     */
    public void sortColumn(String colName) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, resultsGrid, 60);
        addColumns(colName);
        resultTable();
        commonMethods.waitForElementExplicitly(2000);
        By xpath = By.xpath("//div[@class='resultsGrid ng-scope']//div[contains(text(),'" + colName + "')]");
        commonMethods.waitForElement(driver, xpath, 60);
        $(xpath).click();
    }

    /**
     * Function to sort with date modified column
     */
    public String getColumnSort(String colName) {
        commonMethods.waitForElement(driver, resultsGrid, 60);
        return $(By.xpath("//div[contains(text(),'" + colName + "')]/..//div[contains(@class,'customSort' ) and contains(@class,'showElement')]/span")).getAttribute("class");
    }

    /**
     * Function to Reset Pinned Filters
     */
    public void resetPinnedFilters() {
        $(resetPinnedFilters).click();
        commonMethods.waitForElementExplicitly(500);
        commonMethods.waitForElement(driver, confirmReset, 15);
        commonMethods.clickOnElement(confirmReset);
    }

    /**
     * Method to return no of pages in Search Results
     *
     * @return
     */
   public int getNoOfPagesCount(){
        return Integer.parseInt($(totalNoOfPages).getText());
   }

    /**
     * Method to click on Page Inc next Arrow (>)
     *
     */
   public void clickOnPageIncrement(){
       commonMethods.waitForElement(driver, nextArrow, 30);
       Assert.assertTrue("Increment element is not enabled", $(nextArrow).isEnabled());
       $(nextArrow).click();
   }

    /**
     * Method to Validate Doc Super Search Results
     *
     */
   public void validateSearchResults(String colId, String validationText, int noOfPages, String searchText, String colName){
       List<String> cellValues = new ArrayList<>();
       String[] valText=null;
       String[] s=null;
       List<WebElement> cellElements = null;
       Set<String> unMatchCellValues = new HashSet<>();
       if(validationText.contains(",")) valText = validationText.split(",");
       int p = 1;
       while(p<=noOfPages){
               if(p>1) clickOnPageIncrement();
               commonMethods.waitForElement(driver, documentNumber, 60);
               cellElements = new ArrayList<>($$(By.xpath("//div[@col-id='" + colId + "']")));
               if(cellElements.isEmpty()){
                   moveColToFourthPlace(colName);
                   cellElements = new ArrayList<>($$(By.xpath("//div[@col-id='" + colId + "']")));
               }
               boolean match;
               for (int i = 1; i < cellElements.size(); i++) {
                       if (validationText.contains(",")) {
                           match = false;
                           for (String val : valText) {
                               if (val.contains("*")) {
                                   if (cellElements.get(i).getText().trim().toLowerCase().startsWith(val.substring(0, val.length() - 1).toLowerCase())) {
                                       cellValues.add(cellElements.get(i).getText().trim());
                                       match = true;
                                       break;
                                   } else {
                                       if (colId.equals("filename")) {
                                           if (cellElements.get(i).getText().trim().toLowerCase().contains(val.substring(0, val.length() - 1).toLowerCase()) || cellElements.get(i).getText().trim().toLowerCase().startsWith(val.substring(0, val.length() - 1).toLowerCase())) {
                                               cellValues.add(cellElements.get(i).getText().trim());
                                               match = true;
                                               break;
                                           }
                                       }
                                   }
                               } else if (colId.equals("doctype")) {
                                   if (cellElements.get(i).getText().trim().equalsIgnoreCase(val)) {
                                       cellValues.add(cellElements.get(i).getText().trim());
                                       match = true;
                                       break;
                                   }
                               } else if (val.contains(">=1")) {
                                   if (Integer.parseInt(cellElements.get(i).getText().trim()) >= 1) {
                                       cellValues.add(cellElements.get(i).getText().trim());
                                       match = true;
                                       break;
                                   }
                               } else if (!colId.equals("doctype")) {
                                   if (cellElements.get(i).getText().trim().toLowerCase().contains(val.toLowerCase())) {
                                       cellValues.add(cellElements.get(i).getText().trim());
                                       match = true;
                                       break;
                                   }
                               }
                           }
                       } else {
                           match = false;
                           List<String> actualList = null, valList = null;
                           if (validationText.contains("*")) {
                               if (cellElements.get(i).getText().trim().toLowerCase().startsWith(validationText.substring(0, validationText.length() - 1).toLowerCase())) {
                                   cellValues.add(cellElements.get(i).getText().trim());
                                   match = true;
                               } else {
                                   if (colId.equals("filename")) {
                                       if (cellElements.get(i).getText().trim().toLowerCase().contains(validationText.substring(0, validationText.length() - 1).toLowerCase()) || cellElements.get(i).getText().trim().toLowerCase().startsWith(validationText.substring(0, validationText.length() - 1).toLowerCase())) {
                                           cellValues.add(cellElements.get(i).getText().trim());
                                           match = true;
                                       }
                                   }
                               }
                           } else if ((!colId.equals("doctype")) && cellElements.get(i).getText().trim().toLowerCase().contains(validationText.toLowerCase())) {
                               cellValues.add(cellElements.get(i).getText().trim());
                               match = true;
                           } else if (validationText.contains(">=1")) {
                               if (Integer.parseInt(cellElements.get(i).getText().trim()) >= 1) {
                                   cellValues.add(cellElements.get(i).getText().trim());
                                   match = true;
                               }
                           } else if (validationText.contains("AND")) {
                               s = validationText.split("AND");
                               valList = new ArrayList<>();
                               for (int j = 0; j < s.length; j++) {
                                   valList.add(s[j].trim().toLowerCase());
                               }
                               s = cellElements.get(i).getText().trim().split(",");
                               actualList = new ArrayList<>();
                               for (int j = 0; j < s.length; j++) {
                                   actualList.add(s[j].trim().toLowerCase());
                               }
                               if (actualList.containsAll(valList)) {
                                   cellValues.add(cellElements.get(i).getText().trim());
                                   match = true;
                               }
                           } else if (validationText.contains("?")) {
                               String[] str = validationText.split("\\?");
                               if (cellElements.get(i).getText().trim().toLowerCase().startsWith(str[0]) && cellElements.get(i).getText().trim().toLowerCase().endsWith(str[1])) {
                                   cellValues.add(cellElements.get(i).getText().trim());
                                   match = true;
                               }
                           } else if (colId.equals("doctype")) {
                               if (cellElements.get(i).getText().trim().equalsIgnoreCase(validationText)) {
                                   cellValues.add(cellElements.get(i).getText().trim());
                                   match = true;
                               }
                           } else if (validationText.contains("NOT")) {
                               if (!cellElements.get(i).getText().trim().equalsIgnoreCase(validationText.split(" ")[1].trim())) {
                                   cellValues.add(cellElements.get(i).getText().trim());
                                   match = true;
                               }
                           }
                       }
                       if (!match) unMatchCellValues.add(cellElements.get(i).getText().trim());
               }
               p++;
       }
       String searchResultsCount = $(resultSummary).getText().split(" ")[0];
       Assert.assertTrue(searchText + ": Search results are not correct - [searchResultsSummaryCount = " + searchResultsCount + ", Matched Values Count = " + cellValues.size() + "], un matched values : " + unMatchCellValues, searchResultsCount.equals(String.valueOf(cellValues.size())));
   }

    /**
     * Method to Validate Doc Super Search Results (search with OR operator using different fields)
     *
     */
    public void validateORSearchResults(String colId, String validationText, int noOfPages, String searchText){
        List<String> cellValues = getAllColValues(noOfPages, colId);
        boolean match;
        validationText = validationText.replace("LOR", ",");
        for(String cellValue : cellValues) {
            match = false;
           for(String valText : validationText.split(",")){
               if(cellValue.toLowerCase().contains(valText.trim().toLowerCase())){
                   match = true;
                   break;
               }
           }
            if (!match && validationText.contains(">=1")){
                for(String val : cellValue.split("#")){
                    try{
                       if(Integer.parseInt(val.trim())>=1){
                           match = true;
                           break;
                       }
                    }catch (Exception e){
                    }
                }
            }
           if (!match){
               Assert.fail("[" + searchText + " ] - " + cellValue + " - data not matched");
           }
        }
        String searchResultsCount = $(resultSummary).getText().split(" ")[0];
        Assert.assertTrue(searchResultsCount.equals(String.valueOf(cellValues.size())));
    }

    /**
     * Method to Validate No Results Found in Doc Super Search
     *
     */
   public void validateNoResultsFound(String documentNumberVar){
       searchDocs(documentNumberVar);
       commonMethods.waitForElement(driver,noResultsMessage,30);
       Assert.assertTrue($(noResultsMessage).isDisplayed());
       clearAllFilters();
       clickSearchBtn();
   }

    /**
     * Method to Validate Invalid Query search in Doc Super Search
     *
     */
    public void searchDocumentWithInvalidQuery(String documentNumberVar){
        searchDocs(documentNumberVar);
        verifyWildcardsMessage();
        clearAllFilters();
        clickSearchBtn();
    }

    /**
     * Method to search document by passing super search code
     *
     */
    public void searchDocs(String documentNumberVar) {
        $(loadingIcon).should(disappear);
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, searchDocKeywords, 60);
        $(searchDocKeywords).clear();
        commonMethods.waitForElementExplicitly(1000);
        $(searchDocKeywords).sendKeys(documentNumberVar + Keys.ENTER);
        commonMethods.waitForElementExplicitly(1000);
    }

    /**
     * Method to get All column values in Doc Super Search
     *
     */
    public List<String> getAllColValues(int noOfPages, String colIds){
        List<String> cellValues = new ArrayList<>();
        List<WebElement>[] cellElements = (ArrayList<WebElement>[])new ArrayList[colIds.split("OR").length];
        StringBuilder value;
        for(int p=1; p<=noOfPages; p++){
            if(p>1) clickOnPageIncrement();
            commonMethods.waitForElement(driver, documentNumber, 60);
            for(int i=0;i<cellElements.length;i++){
                cellElements[i] = new ArrayList<>($$(By.xpath("//div[@col-id='" + colIds.split("OR")[i].trim() + "']")));
            }
            for(int j=1;j<cellElements[0].size();j++) {
                value = new StringBuilder("");
                for (int k = 0; k < cellElements.length; k++) {
                    value.append(cellElements[k].get(j).getText().trim() + "#");
                }
                cellValues.add(value.toString());
            }
        }
        return cellValues;
    }


    /**
     * Function click on Doc search button
     */
    public void clickOnDocSearchField() {
        commonMethods.waitForElement(driver, searchDocKeywords, 20);
        $(searchDocKeywords).click();
    }
}
