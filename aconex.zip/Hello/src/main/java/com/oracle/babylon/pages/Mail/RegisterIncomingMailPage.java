package com.oracle.babylon.pages.Mail;

import com.codeborne.selenide.Selenide;
import com.oracle.babylon.pages.Directory.DirectoryPage;
import com.oracle.babylon.pages.Document.DocumentPage;
import com.oracle.babylon.pages.Document.DocumentRegisterPage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.io.File;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Condition.appear;
import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Selenide.*;
import static com.codeborne.selenide.Selenide.sleep;

public class RegisterIncomingMailPage extends MailPage {

    By registerBtn = By.xpath("//button[@id='btnRegisterMail']");
    By commonMailError = By.xpath("//div[@class='auiMessage danger']");
    private By loadingIcon = By.cssSelector(".loading_progress");
    private By mailNo = By.xpath("//div[@class='mailHeader-numbers']//div[2]//div[2]");
    String userFilePath = configFileReader.getUserDataPath();
    private By referenceNumber = By.xpath("//div[@class='mailHeader-numbers']//div[3]//div[2]");
    private By attachBtn = By.id("btnMailAttachments");
    private By responseRequired = By.xpath("//select[@id='Correspondence_responseDate-responseTypes']");
    private By mailNumberField = By.xpath("//div[@class='mailHeader-numbers']//div[2]//div[2]");
    private By attachDoc = By.id("btnAttach_page");
    private By optionsBtn = By.id("btnMailOptions");
    private By previewBtn = By.id("btnPreview");
    private By saveToDraftBtn = By.id("btnSaveToDraft");
    private By savedToDraftMessage=By.xpath("//div[contains(text(),'Saved to draft')]");
    private By linkSentFrom = By.xpath("//a[@id='lblFrom']");
    private By linkSentTo = By.xpath("//a[@id='lblTo']");
    private By linkCc = By.xpath("//a[@id='lblCc']");
    private By okBtn = By.xpath("//button[@id='btnOk']");
    private By attributeOkBtn = By.xpath("//button[@id='attributePanel-commit']");
    private By useAutoNumbering = By.xpath("//input[@id='radAutoMailNo']");
    private By ownMailNumber = By.xpath("//input[@id='radSpecifyMailNoManually']");
    private By mailNumberTxtBox = By.xpath("//input[@id='Correspondence_documentNo']");
    private By sendConfidential = By.xpath("//input[@id='Correspondence_confidentialFlag']");
    private By resetReference = By.xpath("//input[@id='Correspondence_resetInRefTo']");
    private By cancelBtn = By.xpath("//div[@class='uiButton-label' and text()='Cancel']");
    private By optionsOkBtn = By.xpath("//div[@class='uiButton-label' and text()='OK']");
    private By linkSentToUser = By.xpath("//label[contains(text(),'Jeffry Romaguera')]");
    private By mailRegisteredMsg = By.xpath("//span[contains(text(),'Mail manually registered')]");
    private By attachBtnOptions = By.xpath("//div[@class='uiMenu-label']//a");
    private By responseRequiredOptions = By.xpath("//select[@id='Correspondence_responseDate-responseTypes']//option");
    private By fileUploadInput = By.xpath("//input[@title='file input']");
    private By userNames = By.xpath("//table[@id='resultTable']//tbody//tr//td[2]//a");
    private By localUploadFilesAttachFrame=By.id("attachFiles-frame");
    private By localUploadChooseFiles=By.xpath("//div[@id='uploaderHelperMsg']//input[@title='file input']");
    private By localAttachButton=By.xpath("//button[@id='btnAttachLocalFile']//div[contains(text(),'Attach')]");
    private By localCloseButton=By.xpath("//*[@id='btnCloseAttachments']//div[contains(text(),'Close')]");
    private By uploadedLocalFileName=By.xpath("//div[@class='file-info']//span[starts-with(@class,'file-name')]");
    private By addFilesOnLocalFileUpload=By.xpath("//div[@class='actions']//*[contains(text(),'Add Files')]");
    private By uploadIndicator=By.xpath("//div[@class='upload-indicator']");
    private By deleteUploadedFile=By.xpath("//div[contains(text(),'Clear All')]");
    private By deleteIconinAttachment=By.xpath("//td[@id='corrAttachmentsContainer']//td//div[@class='auiIcon trash remove']");
    private DirectoryPage directoryPage = new DirectoryPage();
    private DocumentRegisterPage documentRegisterPage = new DocumentRegisterPage();
    private DocumentPage documentPage = new DocumentPage();
    public static String mailNumber = null;
    private ComposeMailPage composeMailPage = new ComposeMailPage();
    Map<String, Map<String, Object>> mapOfMap = new Hashtable<>();
    Map<String, Object> mapToReplace = new Hashtable<>();
    private By registerMailBtn = By.xpath("//div[contains(text(),'Register')]");
    private ViewMail viewMail = new ViewMail();

    public void navigateAndVerifyPage() {
        getMenuSubmenu("Mail", "Register Incoming Mail");
        verifyPageTitle("Register Incoming Mail");
    }

    /**
     * Function to click register button and return generated mail number
     *
     * @return generated mail number
     */
    public String registerIncomingMail() {
        verifyAndSwitchFrame();
        $(registerBtn).click();
        $(loadingIcon).should(disappear);
        commonMethods.waitForElementExplicitly(4000);
        commonMethods.waitForElement(driver, mailNo,45);
        return $(mailNo).getText();
    }

    /**
     * Function to verify common mail number cannot be used for registering mail
     */
    public void verifyCommonMailNumber() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        Assert.assertTrue($(commonMailError).text().contains("already exists and can't be used to send this mail. Please enter a unique mail number to continue."));

    }

    /**
     * Function to click register button
     */
    public void clickRegisterButton() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, registerBtn, 30);
        $(registerBtn).click();
    }

    /**
     * Function to register mail and get mail number
     */
    public String clickRegisterGetMailNumber() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, registerMailBtn);
        $(registerMailBtn).click();
        return viewMail.getMailNumber();

    }


    /**
     * Function to remove user from recipient group
     *
     * @param user  which is to be removed
     * @param group from which user is to be removed
     */
    public void removeUser(String user, String group) {
        verifyAndSwitchFrame();
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userFilePath);
        userMap = jsonMapOfMap.get(user);
        String userToRemove = userMap.get("full_name").toString();
        switch (group.toLowerCase()) {
            case "cc":
                $(By.xpath("//table[@id='recipientList_CC']//tr[td[contains(.,'" + userToRemove + "')]]//td[div[@class='auiIcon trash remove']]")).click();
                break;
            case "sent from":
                $(By.xpath("//table[@id='recipientList_FROM']//tr[td[contains(.,'" + userToRemove + "')]]//td[div[@class='auiIcon trash remove']]")).click();
                break;
            case "sent to":
                $(By.xpath("//table[@id='recipientList_TO']//tr[td[contains(.,'" + userToRemove + "')]]//td[div[@class='auiIcon trash remove']]")).click();
                break;
        }
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Method to verify Fields In Register Mail Page
     */
    public void verifyFieldsRegisterMail() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        Assert.assertTrue($(registerBtn).isDisplayed());
        Assert.assertTrue($(attachBtn).isDisplayed());
        Assert.assertTrue($(previewBtn).isDisplayed());
        Assert.assertTrue($(saveToDraftBtn).isDisplayed());
    }

    /**
     * Click on sent From
     */
    public void clickSentFrom() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        $(linkSentFrom).click();
    }
    /**
     * Click on sent TO
     */
    public void clickSentTo() {
        verifyAndSwitchFrame();
        $(linkSentTo).click();
    }

    /**
     * Click on CC
     */
    public void clickCc() {
        verifyAndSwitchFrame();
        $(linkCc).click();
    }

    /**
     * Click ok button
     */
    public void clickOkBtn() {
        verifyAndSwitchFrame();
        $(okBtn).click();

    }

    /**
     * Method to verify sent from
     *
     * @param changeUser
     */
    public boolean verifySender(String sentFrom, String changeUser) {
        composeMailPage.addRecipient(sentFrom, changeUser);
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
        userMap = jsonMapOfMap.get(changeUser);
        String name = (userMap.get("full_name").toString());
        return verifyUsers(name);
    }

    /**
     * Function to verify sent from Directory with multiple Recipients
     *
     * @param changeUser
     * @return
     */
    public boolean verifySentFromDirectory(String changeUser) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
        userMap = jsonMapOfMap.get(changeUser);
        verifyAndSwitchFrame();
        clickSentFrom();
        String name = directoryPage.getFirstUser(userMap);
        directoryPage.selectMultipleRecipients(2);
        return verifyUsers(name);
    }

    /**
     * Method to verify Mail registered WaterMark
     *
     * @return
     */
    public boolean verifyMailRegistration() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, mailRegisteredMsg, 10);
        return $(mailRegisteredMsg).isDisplayed();
    }

    /**
     * Method to register Mail with mail Type
     *
     * @param mailType
     */
    public void registerMail(String mailType) {
        verifyAndSwitchFrame();
        selectMailType(mailType);
        clickRegisterButton();
    }

    /**
     * Method to verify attach button options
     *
     * @param attachBtnValues
     * @return
     */
    public boolean verifyAttachButtonOptions(List<String> attachBtnValues) {
        ArrayList attachBtnOptionsText = new ArrayList();
        verifyAndSwitchFrame();
        $(attachBtn).click();
        List<WebElement> options = driver.findElements(attachBtnOptions);
        for (int i = 0; i <= options.size() - 1; i++) {
            String optionsText = options.get(i).getText();
            attachBtnOptionsText.add(optionsText);
        }
        return attachBtnValues.equals(attachBtnOptionsText);
    }

    /**
     * Method to attach document
     *
     * @param documentNumber
     * @param option
     */
    public void attachDocument(String documentNumber, String option) {
        selectAttachOption(option);
        jsonMapOfMap = dataSetup.loadJsonDataToMap(docFilePath);
        docMap = jsonMapOfMap.get(documentNumber);
        String docNum = docMap.get("doc_num").toString();
        documentPage.attachDocument(docNum);
    }

    /**
     * Method to select attach options
     *
     * @param option
     */
    public void selectAttachOption(String option) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, attachBtn, 10);
        $(attachBtn).click();
        commonMethods.waitForElementExplicitly(1000);
        $(By.xpath("//div[@class='uiMenu-label']//a[text()='" + option + "']")).click();
    }

    /**
     * Method to attach project Mail
     *
     * @param projectMail
     * @param type
     */
    public void attachProjectMail(String projectMail, String type) {
        selectAttachOption(type);
        String docNum = returnMailNumber(projectMail);
        searchAttachedMail(docNum);
        clickPanelAttachBtn();
    }

    /**
     * Method to attach local file on Mail
     *
     * @param localMail
     * @param type
     */
    public void attachLocalMail(String localMail, String type){
        selectAttachOption(type);
        commonMethods.waitForElementExplicitly(2000);
        verifyAndSwitchFrame(localUploadFilesAttachFrame);
        uploadLocalFile(localMail);
        $(localAttachButton).click();
        commonMethods.waitForElementExplicitly(2000);
        verifyAndSwitchFrame(localUploadFilesAttachFrame);
        commonMethods.waitForElement(driver,uploadIndicator);
        verifyAndSwitchFrame();
        $(localCloseButton).click();
    }
    /**
     * Method to upload local file and verify the whether the file got attached
     *
     * @param fileName
     */
    public void uploadLocalFile(String fileName)
    {
        File file=new File(configFileReader.getTestDataPath()+fileName);
        commonMethods.waitForElementExplicitly(2000);
        $(localUploadChooseFiles).sendKeys(file.getAbsolutePath());
        commonMethods.waitForElementExplicitly(2000);
        Assert.assertEquals($(uploadedLocalFileName).getText(),fileName);
        Assert.assertTrue($(addFilesOnLocalFileUpload).isDisplayed());
        Assert.assertTrue($(deleteUploadedFile).isDisplayed());
        verifyAndSwitchFrame();

    }
    /**
     * Method to verify attachment in the Register Incoming Mail
     *
     * @param attachmentName
     * @return
     */
     public void  verifyAttachmentNameandIcon(String attachmentName)
     {
         commonMethods.waitForElement(driver,By.xpath("//td[contains(text(),'"+attachmentName+"')]"),30);
         Assert.assertTrue($(deleteIconinAttachment).isDisplayed());
     }
    /**
     * Method to verify users list
     *
     * @param users
     * @return
     */
    public ArrayList verifyUsersList(String users) {
        verifyAndSwitchFrame();
        if (users.equalsIgnoreCase("Sent From")) {
            clickSentFrom();
        } else if (users.equalsIgnoreCase("Sent To")) {
            clickSentTo();
        } else {
            clickCc();
        }
        return getNumberOfUsers();
    }

    /**
     * Method to get Number of Users
     *
     * @return
     */
    public ArrayList getNumberOfUsers() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(1000);
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(1000);
        ArrayList usersList = new ArrayList();
        List<WebElement> users = driver.findElements(userNames);
        for (int i = 0; i <= users.size() - 1; i++) {
            String optionsText = users.get(i).getText();
            usersList.add(optionsText);
        }
        return usersList;
    }

    /**
     * Method to add attribute
     *
     * @param attribute
     */
    public void addAttribute(String attribute) {
        verifyAndSwitchFrame();
        selectMailAttribute("Attribute 1", attribute);
    }

    /**
     * Method to get mail number of registered Mail
     *
     * @return
     */
    public String getRegisteredMailNumber() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(5000);
        $(loadingIcon).should(disappear);
        commonMethods.waitForElement(driver, mailNumberField, 15);
        mailNumber = $(mailNumberField).getText();
        driver.switchTo().defaultContent();
        return mailNumber;
    }

    /**
     * Method to verify elements of options Button
     */
    public void verifyOptions() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, useAutoNumbering, 15);
        Assert.assertTrue($(useAutoNumbering).isDisplayed());
        Assert.assertTrue($(ownMailNumber).isDisplayed());
        Assert.assertTrue($(sendConfidential).isDisplayed());
        Assert.assertTrue($(resetReference).isDisplayed());
        Assert.assertTrue($(optionsOkBtn).isDisplayed());
        Assert.assertTrue($(cancelBtn).isDisplayed());
    }

    /**
     * Method to move attribute right and left from attribute list
     *
     * @param attribute
     * @param value
     */
    public void verifyAttributes(String attribute, String value) {
        verifyAndSwitchFrame();
        $(By.xpath("//tr//td//label[contains(text(),'" + attribute + "')]//..//..//td[2]//div")).click();
        if ($(By.xpath("//div[@id='attributeBidi_PRIMARY_ATTRIBUTE']//div[@class='uiBidi-right']//select//option[text()='" + value + "']")).isDisplayed()) {
            $(By.xpath("//select//option[text()='" + value + "']")).doubleClick();
            Assert.assertTrue($(By.xpath("//div[@id='attributeBidi_PRIMARY_ATTRIBUTE']//div[@class='uiBidi-left']//select//option[text()='" + value + "']")).isDisplayed());
            $(By.xpath("//select//option[text()='" + value + "']")).doubleClick();
            Assert.assertTrue($(By.xpath("//div[@id='attributeBidi_PRIMARY_ATTRIBUTE']//div[@class='uiBidi-right']//select//option[text()='" + value + "']")).isDisplayed());
        }
        $(attributeOkBtn).click();
    }


    /**
     * Method to verify Sent TO functionality
     *
     * @param directory
     * @param toUser
     * @return
     */
    public Boolean verifySentToCc(String directory, String toUser) {
        composeMailPage.addRecipient(directory, toUser);
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
        userMap = jsonMapOfMap.get(toUser);
        String name = (userMap.get("full_name").toString());
        return verifyUsers(name);
    }

    public void clickDirectory(String directory) {
        verifyAndSwitchFrame();
        $(By.xpath("//label//a[text()='" + directory + "']//../../..//div[text()='Directory']")).click();
    }

    /**
     * Method to verify response required options
     *
     * @param responseRequiredListValues
     * @return
     */
    public boolean verifyResponseRequiredList(List<String> responseRequiredListValues) {
        ArrayList responseRequiredListText = new ArrayList();
        verifyAndSwitchFrame();
        $(responseRequired).click();
        List<WebElement> options = driver.findElements(responseRequiredOptions);
        for (int i = 0; i <= options.size() - 1; i++) {
            String optionsText = options.get(i).getText();
            responseRequiredListText.add(optionsText);
        }
        return responseRequiredListValues.equals(responseRequiredListText);
    }

    /**
     * Method to verify response error msg with out date
     *
     * @param value
     * @return
     */
    public boolean verifyResponseErrorMsg(String value) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, responseRequired, 10);
        $(responseRequired).selectOptionContainingText(value);
        registerMail("Internal Memorandum");
        return verifyErrorMsg();
    }

    public boolean verifyResponseDate() {
        verifyAndSwitchFrame();
        $(responseRequired).click();
        String errorMsg = driver.switchTo().alert().getText();
        commonMethods.acceptAlert(driver);
        return errorMsg.contains("Please enter a date in the future to continue");
    }

    /**
     * Function to get Attribute value
     *
     * @param attributes
     * @param data
     * @return
     */
    public String getAttribute(String attributes, String data) {
        Map<String, String> table = dataStore.getTable(attributes);
        verifyAndSwitchFrame();
        for (String tableData : table.keySet()) {
            if (tableData.equalsIgnoreCase("Mail Type")) {
                return table.get(tableData);
            } else if (tableData.equalsIgnoreCase("Subject")) {
                return table.get(tableData);
            } else if (tableData.equalsIgnoreCase("Attachment")) {
                return table.get(tableData);
            } else if (tableData.equalsIgnoreCase("Attribute")) {
                return table.get(tableData);
            }
        }
        return null;
    }

    /**
     * Function to verify Auto Save to Draft feature
     */
    public void verifyAutoSave()
    {
        //commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver,savedToDraftMessage,180);
    }

    public void clickDeleteIcon()
    {
        commonMethods.waitForElement(driver,deleteIconinAttachment,120);
        $(deleteIconinAttachment).click();
    }
}