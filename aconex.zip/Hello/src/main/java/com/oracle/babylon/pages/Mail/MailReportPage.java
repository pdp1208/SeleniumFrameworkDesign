package com.oracle.babylon.pages.Mail;

import org.junit.Assert;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.$;

public class MailReportPage extends MailPage{

    private By startMsg = By.xpath("//div[contains(text(),'Your export to excel has begun')]");
    private By backgroundMsg = By.xpath("//div[contains(text(),'It will run as a background process. When the export completes an email notification will be sent to')]");
    private By tempFilesLink = By.xpath("//a[text()='Go to the Temporary Files List']");
    private By mailSearchLink = By.xpath("//a[text()='Go back to Mail Search']");

    /**
     * Method to click on the reports button on the mail page
     */
    public void clickReportBtn(){
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, reportsBtn, 20);
        $(reportsBtn).click();
    }

    /**
     * Method to select the report type options
     * @param reportType
     * @param typeOfExport
     */
    public void selectReportType(String reportType, String typeOfExport){
        if(typeOfExport.equalsIgnoreCase("Export to Excel")){
            if (typeOfExport != null) {
                $(By.xpath("//a[text()='" + typeOfExport + "']")).click();
            }
            selectReportType(reportType);
        } else {
            if (typeOfExport != null) {
                $(By.xpath("//a[text()='" + typeOfExport + "']")).click();
            }
        }

    }

    /**
     * Method to validate the messages in report generation pop up
     */
    public void validateSuccessMsg(){
        commonMethods.waitForElement(driver, startMsg);
        Assert.assertTrue($(startMsg).isDisplayed());
        Assert.assertTrue($(backgroundMsg).isDisplayed());
    }

    /**
     * Method to validate the buttons in report generation pop up
     */
    public void validateUI(){
        Assert.assertTrue($(tempFilesLink).isDisplayed());
        Assert.assertTrue($(mailSearchLink).isDisplayed());
    }

    /**
     * Method to click on the temporary files link
     */
    public void clickTempFiles(){
        $(tempFilesLink).click();
    }


    /**
     * Method to click on the return to mail search page link
     */
    public void clickMailSearch(){
        $(mailSearchLink).click();
    }
}
