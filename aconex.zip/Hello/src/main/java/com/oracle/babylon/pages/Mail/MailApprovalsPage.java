package com.oracle.babylon.pages.Mail;

import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.codeborne.selenide.Selenide.*;


/**
 * Class that contains common methods related to Mail Approvals
 * Author : sunilvve
 */
public class MailApprovalsPage extends Navigator {

    //Initializing the web elements

    //Mail Approval Page
    private By hdrAwaitingYourApproval = By.xpath("//h1[contains(text(),'Items Awaiting your Approval')]");
    private By hdrApprovalRequest = By.xpath("//h1[contains(text(),'Approval Requests Made by you')]");
    private By tabForYourApproval = By.xpath("//li[@id='forYourApproval_list']");
    private By tabAwaitingApproval = By.xpath("//li[@id='awaitingApprovalOn_list']");
    private By txtboxRequestNo = By.xpath("//input[@name='SEARCH_REQUEST_NO']");
    private By txtboxSubmitter = By.xpath("//input[@name='SEARCH_NAME']");
    private By sltTasks = By.xpath("//select[@name='SEARCH_APPROVABLE_ITEM_ID']");
    private By sltStatus = By.xpath("//select[@name='SEARCH_APPROVAL_STATUS']");
    private By txtboxDate = By.xpath("//input[@id='SEARCH_DATE_da']");
    private By btnSearch = By.xpath("//button//div[contains(text(),'Search')]");
    private By lblRequestNo = By.xpath("//td[contains(text(),'Request No.')]");
    private By lblSubmitter = By.xpath("//td[contains(text(),'Submitter')]");
    private By lblTasks = By.xpath("//td[contains(text(),'Task')]");
    private By lblStatus = By.xpath("//td[contains(text(),'Status')]");
    private By lblDate = By.xpath("//td[contains(text(),'Date')]");
    private By lblReqNo = By.xpath("//td[contains(text(),'Req. No.')]");
    private By lblSearchResults = By.xpath("//div[contains(text(),'Search Results')]");
    private By lblNoResultsFound = By.xpath("//table[@class='dataTable']/tbody/tr[1]");
    private String tblResultsHeader = "//table[@class='dataTable']//thead/tr/th";
    private String tblResults = "//table[@class='dataTable']//tbody/tr";
    private By txtFirstRecordReqNo = By.xpath("//table[@class='dataTable']//tbody//tr[1]//td[1]/span");
    private By lblConfirm = By.xpath("//span[contains(text(),'Confirm')]");
    private By btnApprove = By.xpath("//button[@title='Approve']");
    private By hdrApproved = By.xpath("//h2[@class='message success']//div[text()='Approved']");
    private By lblApprovedMessage = By.xpath("//div[@id='main']");
    private By btnReject = By.xpath("//button[contains(text(),'Reject')]");
    private By btnRejectCancel = By.xpath("//button[text()='Cancel']");
    protected By txtBoxComments = By.xpath("//div[text()='Comments']/following-sibling::div/textarea");
    private By hdrRejectMail = By.xpath("//h3[contains(text(),'Reject Mail')]");
    private By txtBoxAddSender = By.xpath("//span//input[@title='Add person from your organization on the current project']");
    protected By hdrCannotApprove = By.xpath("//h3[contains(text(),'This mail cannot be approved')]");

    //Configure Approval Page
    public By hdrConfigureApproval = By.xpath("//h1[contains(text(),'Configure Mail Approvals')]");
    private By tabProject = By.xpath("//li[@id='project']");
    private By tabOrganization = By.xpath("//li[@id='organization']");
    private By configureApproverBtn = By.xpath("//button//div[contains(text(),'Configure Approvals')]");
    private By addBtn = By.xpath("//button[@id='btnAdd']");
    private By approverSearchBox = By.xpath("//input[@id='lookupApprovers_query']");
    private By searchBtn = By.xpath("//span[@id='lookupApprovers']//div[@class='bicon ic-search']");
    private By approverSearchchkBox = By.xpath("//input[@id='approver']");
    private By createdBychkBox = By.xpath("//input[@id='orgAuthor']");
    private By addApproverOkBtn = By.xpath("//div[@class='uiButton-label' and text()='OK']");
    private By approvalSaveBtn = By.xpath("//div[contains(text(),'Save')]");
    private By textSavedChanges = By.xpath("//div[text()='Changes have been saved']");
    private By successMsgPanel = By.xpath("//ul[@class='messagePanel']");
    private By acceptBtn = By.xpath("//img[@src='/html/Images/ic_appr_add.gif']");
    private By confirmApproveBtn = By.xpath("//div[@class='uiButton-label' and text()='Approve']");
    private By confirmRejectBtn = By.xpath("(//button[contains(.,'Reject')])[1]");
    private By backBtnOnRejection = By.xpath("//*[@id='btnBack']");
    private By textApproved = By.xpath("//div[text()='Approved']");
    private By rejectBtn = By.xpath("//img[@src='/html/Images/ic_appr_remv.gif']");
    private By linkMultipleMailType = By.xpath("//a[@id='lnkMailTypeSingle']");
    private By addMailTypeBtn = By.xpath("//button[@id='btnbidi_addApprovableItem_ADD']");
    private By addLinkForTenders = By.xpath("//table[@id='tblApprovabieItemList']//tbody[@id='tbdNoTenderItems']//a");
    private By addLinkForMail = By.xpath("//table[@id='tblApprovabieItemList']//tbody[@id='tbdNoMailItems']//a");
    private By tableColumn = By.xpath("//table[@class='dataTable']//tbody//tr[1]//td");
    private By tableRow = By.xpath("//table[@class='dataTable']//tbody//tr");
    private By rejectMailButton = By.xpath("//button[@id='modal-reject']");
    private By backBtn = By.xpath("//button[@id='btnBack']");
    private By rejectBtnOnModal = By.xpath("//button[contains(.,'Reject')]");
    private By lblViewOnlyMode = By.xpath("//span[contains(text(),'View only mode')]");
    private By lblTenders = By.xpath("//td[contains(text(),'Tenders')]");
    private By lblMails = By.xpath("//td[contains(text(),'Mail')]");
    private By tblNoTenders = By.xpath("//tbody[@id='tbdNoTenderItems']");
    private By tblNoMails = By.xpath("//tbody[@id='tbdNoMailItems']");
    private By btnAdd = By.xpath("//div[contains(text(),'Add')]");
    private By btnSave = By.xpath("//div[contains(text(),'Save')]");
    private By sltMailType = By.xpath("//select[@id='selApprovableItems']");
    private By sltMultiMailType = By.xpath("//select[@id='bidi_addApprovableItem_AVAIL']");
    private By hdrAddMailTypes = By.xpath("//span[@id='bidiPanel_addApprovableItem_title']");
    private By lblChooseMailType = By.xpath("//strong[contains(text(),'Choose Mail Type')]");
    private By lblAddApprovers = By.xpath("//strong[contains(text(),'Add Approvers')]");
    private By lblMarkAsSentBy = By.xpath("//strong[contains(text(),'Mark as Sent By')]");
    private String btnTrash = "//table[@id='lookupApprovers_container']//a/div[@class='auiIcon trash']";
    private By btnCancel = By.xpath("//div[contains(text(),'Cancel')]");
    private By tblTendersHeaders = By.xpath("//table[@id='tblApprovabieItemList']/thead[@id='thdTender']/tr/th");
    private By tblMailHeaders = By.xpath("//table[@id='tblApprovabieItemList']/thead[@id='thdMailItem']/tr/th");
    private By sltMarkAsSentBy = By.xpath("//select[contains(@name,'selMailSentFrom')]");
    private String chkBoxRemove = "//tbody//td/input[contains(@name,'removeApprovableItem')]";
    private By sltTendersApprovers = By.xpath("//tbody[@id='tbdTenderItems']//tr/td[2]/div");
    private By sltMailApprovers = By.xpath("//tbody[@id='tbdMailItems']//tr/td[2]/div");
    private By lblChangesSaved = By.xpath("//div[contains(text(),'Changes have been saved')]");
    private By txtBoxApproverList = By.xpath("//div[@id='lookupApprovers_list']");
    private By chkBoxDisableRemove = By.xpath("//td[@title='This item cannot be removed as there are messages pending approval']/input");
    private By lblPending = By.xpath("//td[@title='This item cannot be removed as there are messages pending approval']");
    private String tblApprovers = "//table[@id='lookupApprovers_container']//tr";

    Actions actions = new Actions(driver);

    /**
     * Function to verify the page
     */
    public void navigateAndVerifyPage() {
        commonMethods.waitForElementExplicitly(3000);
        getMenuSubmenu("Mail", "Mail Approvals");
    }

    /**
     * Function to create Approver For Organization or Peoject level
     *
     * @param organization
     */
    public void selectLevelOfApprover(Boolean organization) {
        if (organization) {
            commonMethods.waitForElement(driver, tabOrganization);
            $(tabOrganization).click();
        }
    }

    /**
     * Function to Create Approver
     *
     * @param approverName
     * @param mailTypes
     * @param single
     */
    public void configureMailApprover(String approverName, List<String> mailTypes, String single, String approver) {
        commonMethods.waitForElementExplicitly(3000);
        if (single.equalsIgnoreCase("single")) {
            addSingleMailType(mailTypes);
        } else {
            addMultipleMailTypes(mailTypes);
        }
        addApprover(approverName, approver);
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, approvalSaveBtn);
        $(approvalSaveBtn).click();
    }

    /**
     * Function to create Approver for Tenders
     *
     * @param approverNames
     * @param single
     * @param mailTypes
     */
    public void createApproverForTenders(List<String> mailTypes, String single, String approver, String approverNames) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, addLinkForTenders);
        $(addLinkForTenders).click();
        configureMailApprover(approverNames, mailTypes, single, approver);
    }

    /**
     * Function to create Approver For Mail
     *
     * @param approverName
     * @param mailTypes
     * @param single
     */
    public void createApproverForMail(String approverName, List<String> mailTypes, String single, String approver) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, btnAdd, 20);
        $(btnAdd).click();
        configureMailApprover(approverName, mailTypes, single, approver);
    }

    /**
     * Function to create Approver
     *
     * @param approverName
     * @param single
     * @param mailTypes
     */
    public void createApproverWithAdd(String approverName, List<String> mailTypes, String single, String approver) {
        $(addBtn).click();
        configureMailApprover(approverName, mailTypes, single, approver);
    }

    /**
     * Function to Add Single Mail Type
     *
     * @param mailTypes
     */
    public void addSingleMailType(List<String> mailTypes) {
        selectSingleMailType(mailTypes.get(0));
    }

    /**
     * Function to Add Multiple Mail Types
     *
     * @param mailTypes
     */
    public void addMultipleMailTypes(List<String> mailTypes) {
        $(linkMultipleMailType).click();
        for (String mailType : mailTypes) {
            selectMultiMailType(mailType);
            $(addMailTypeBtn).click();
        }
    }

    /**
     * Function to Add Aprrover
     */
    public void addApprover(String approverName, String approver) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, approverSearchBox);
        String[] approverNames = approverName.split(",");
        for (String approvers : approverNames) {
            $(approverSearchBox).clear();
            $(approverSearchBox).sendKeys(commonMethods.getUserData(approvers, "name"));
            commonMethods.waitForElementExplicitly(1000);
            $(searchBtn).click();
            commonMethods.waitForElementExplicitly(2000);
        }
        if (approver.equalsIgnoreCase("approver")) {
            $(approverSearchchkBox).click();
        } else {
            $(createdBychkBox).click();
        }
        commonMethods.waitForElementExplicitly(2000);
        $(addApproverOkBtn).click();
    }

    /**
     * Function to click on Configure Approvals
     */
    public void clickOnConfigureApprovals() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, configureApproverBtn, 20);
        $(configureApproverBtn).click();
    }

    /**
     * Function to select Mail Type
     *
     * @param mailType
     */
    public void selectSingleMailType(String mailType) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2500);
        commonMethods.waitForElement(driver, sltMailType);
        $(sltMailType).selectOption(mailType);
    }

    /**
     * Function to Select Multi Mail TYpe
     *
     * @param mailType
     */
    public void selectMultiMailType(String mailType) {
        $(sltMultiMailType).selectOption(mailType);
    }

    /**
     * Function to Accept or Reject Mail from Approver
     *
     * @param accept
     */
    public void acceptOrReject(String accept) {
        verifyAndSwitchFrame();
        if (accept != null) {
            $(acceptBtn).click();
            $(confirmApproveBtn).click();
        } else {
            $(rejectBtn).click();
            $(confirmRejectBtn).click();
        }
    }

    /**
     * Function to verify the after approving mail
     */
    public Boolean verifyMailApproval() {
        commonMethods.waitForElement(driver, textApproved);
        return $(textApproved).isDisplayed();
    }

    /**
     * Function to remove approver
     */
    public Boolean removeApprover(String userId, String approverName) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
        userMap = jsonMapOfMap.get(userId);
        approverName = userMap.get("full_name").toString();
        try {
            commonMethods.waitForElement(driver, By.xpath("//tbody[@id='tbdMailItems']//tr//td"), 7);
        } catch (TimeoutException e) {
            System.out.println(e.getMessage());
        }
        List<WebElement> listOfColumns = driver.findElements(By.xpath("//tbody[@id='tbdMailItems']//tr//td"));
        int columnSize = listOfColumns.size();
        if ($(By.xpath("//tbody[@id='tbdMailItems']//tr[contains(., '" + approverName + "')]//td[" + columnSize + "]//input")).isDisplayed()) {
            $(By.xpath("//tbody[@id='tbdMailItems']//tr[contains(., '" + approverName + "')]//td[" + columnSize + "]//input")).click();
            commonMethods.waitForElement(driver, approvalSaveBtn);
            $(approvalSaveBtn).click();
            commonMethods.waitForElement(driver, textSavedChanges);
            return $(textSavedChanges).isDisplayed();
        }
        return false;
    }

    /**
     * Method to reject all mail present in awaiting state
     */
    public void rejectAllAwaitingMail() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, tableColumn, 20);
        int size = driver.findElements(tableColumn).size();
        int rowSize = driver.findElements(tableRow).size();
        if (rowSize > 0 && size > 4) {
            for (int i = 1; i <= rowSize; i++) {
                $(By.xpath("//table[@class='dataTable']//tbody//tr[" + i + "]//td[" + size + "]//a")).click();
                commonMethods.waitForElement(driver, rejectMailButton, 120);
                getElementInView(rejectMailButton);
                $(rejectMailButton).click();
            }
        }
    }

    /**
     * Method to assert for your approval tab
     */
    public void verifyMailApprovalPage(String tabName) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, configureApproverBtn, 30);
        if (tabName.equalsIgnoreCase("for your approval")) {
            switchMailApprovalsTab(tabName);
            Assert.assertTrue($(hdrAwaitingYourApproval).isDisplayed());
            commonMethods.waitForElement(driver, hdrAwaitingYourApproval, 30);
            Assert.assertTrue($(tabForYourApproval).getAttribute("class").contains("active"));
            Assert.assertTrue($(lblRequestNo).isDisplayed());
            Assert.assertTrue($(lblSubmitter).isDisplayed());
            Assert.assertTrue($(txtboxSubmitter).isDisplayed());
        } else if (tabName.equalsIgnoreCase("awaiting approval")) {
            switchMailApprovalsTab(tabName);
            commonMethods.waitForElement(driver,hdrApprovalRequest, 30);
            Assert.assertTrue($(hdrApprovalRequest).isDisplayed());
        }
        Assert.assertTrue($(tabForYourApproval).isDisplayed());
        Assert.assertTrue($(tabAwaitingApproval).isDisplayed());
        Assert.assertTrue($(txtboxRequestNo).isDisplayed());
        Assert.assertTrue($(lblTasks).isDisplayed());
        Assert.assertTrue($(sltTasks).isDisplayed());
        Assert.assertTrue($(lblStatus).isDisplayed());
        Assert.assertTrue($(sltStatus).isDisplayed());
        Assert.assertTrue($(lblDate).isDisplayed());
        Assert.assertTrue($(txtboxDate).isDisplayed());
        Assert.assertTrue($(btnSearch).isDisplayed());
        Assert.assertTrue($(lblSearchResults).isDisplayed());
        Assert.assertTrue($(By.xpath(tblResultsHeader)).isDisplayed());
    }

    /**
     * Method to switch tabs in mail approval page
     */
    public void switchMailApprovalsTab(String tabName) {
        verifyAndSwitchFrame();
        By element = By.xpath("//li[contains(text(),'" + tabName + "')]");
        commonMethods.waitForElement(driver, element, 30);
        $(element).click();
    }

    /**
     * Method to get mail approval results tab headers
     */
    public List<String> verifyTableHeaders() {
        verifyAndSwitchFrame();
        List<String> values = new ArrayList<>();
        List<WebElement> headers = new ArrayList<>($$(By.xpath(tblResultsHeader)));
        for (WebElement header : headers) values.add(header.getText());
        return values;
    }

    /**
     * Method to get configure approvers tenders and mail tables headers
     */
    public List<String> verifyApprovalTableHeaders(String type) {
        By element;
        List<String> headers = new ArrayList<>();
        if (type.equalsIgnoreCase("tenders")) element = tblTendersHeaders;
        else element = tblMailHeaders;
        commonMethods.waitForElement(driver, element);
        List<WebElement> elements = new ArrayList<>($$(element));
        for (WebElement header : elements) headers.add(header.getText());
        return headers;
    }

    /**
     * Method to verify configure approval page
     */
    public void verifyConfigureApprovalPage(String tabName, String mode) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, hdrConfigureApproval, 30);
        switchMailApprovalsTab(tabName);
        commonMethods.waitForElementExplicitly(2000);
        if (mode.equalsIgnoreCase("view only"))
            Assert.assertTrue($(lblViewOnlyMode).isDisplayed());
        else {
            Assert.assertTrue($(addLinkForTenders).isDisplayed());
            Assert.assertTrue($(addLinkForMail).isDisplayed());
            Assert.assertTrue($(btnAdd).isDisplayed());
            Assert.assertTrue($(btnSave).isDisplayed());
        }
        Assert.assertTrue($(lblTenders).isDisplayed());
        Assert.assertTrue($(lblMails).isDisplayed());
        Assert.assertTrue($(tblNoTenders).isDisplayed());
        Assert.assertTrue($(tblNoMails).isDisplayed());
    }

    /**
     * Method to verify Add Mail Types Tab
     */
    public void verifyAddMailTypeTab(String mailTypes, String approver) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, btnAdd, 30);
        $(btnAdd).click();
        commonMethods.waitForElement(driver, addApproverOkBtn, 10);
        Assert.assertTrue($(hdrAddMailTypes).isDisplayed());
        Assert.assertTrue($(sltMailType).isDisplayed());
        Assert.assertTrue($(linkMultipleMailType).isDisplayed());
        Assert.assertTrue($(lblChooseMailType).isDisplayed());
        Assert.assertTrue($(lblAddApprovers).isDisplayed());
        Assert.assertTrue($(lblMarkAsSentBy).isDisplayed());
        Assert.assertTrue($(approverSearchBox).isDisplayed());
        Assert.assertTrue($(approverSearchchkBox).isDisplayed());
        Assert.assertTrue($(createdBychkBox).isDisplayed());
        verifyAddMailTypeValues(mailTypes, approver);
    }

    /**
     * Method to verify Add Mail Types fields
     */
    public void verifyAddMailTypeValues(String mailTypes, String user) {
        List<String> types = Arrays.asList(mailTypes.split(","));
        addSingleMailType(types);
        addMultipleMailTypes(types);
        $(approverSearchBox).clear();
        $(approverSearchBox).sendKeys(commonMethods.getUserData(user, "name") + Keys.ENTER);
        commonMethods.waitForElementExplicitly(2000);
        Assert.assertTrue($(By.xpath(btnTrash)).isDisplayed());
        $(By.xpath(btnTrash)).click();
        $(approverSearchchkBox).click();
        $(createdBychkBox).click();
        $(btnCancel).click();
    }

    /**
     * Method to verify Mail type
     */
    public boolean verifyMailType(String type) {
        return $(By.xpath("//td[contains(text(),'" + type + "')]")).isDisplayed();
    }

    /**
     * Method to verify marked as sent by field
     */
    public String verifyMarkedAsSentBy() {
        return $(sltMarkAsSentBy).getSelectedOption().getText();
    }

    /**
     * Method to verify remove checkbox default value
     */
    public boolean verifyRemove() {
        return $(By.xpath(chkBoxRemove)).isSelected();
    }

    /**
     * Method to verify remove checkbox disabled
     */
    public boolean verifyRemoveChkBox() {
        $(chkBoxDisableRemove).isDisplayed();
        Assert.assertEquals("Pending", $(lblPending).getText().trim());
        return Boolean.parseBoolean($(By.xpath(chkBoxRemove)).getAttribute("disabled"));
    }

    /**
     * Method to verify approver names are present
     */
    public boolean verifyApproverName(String name) {
        return $(By.xpath("//div/span[contains(text(),'" + name + "')]")).isDisplayed();
    }

    /**
     * Method to update approver type
     */
    public void updateMarkAsSentBy(String value) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, sltMarkAsSentBy, 30);
        commonMethods.enterDropdownValue(sltMarkAsSentBy, value);
    }

    /**
     * Method to update approvers
     */
    public void updateApprovers(String type, String approvers) {
        verifyAndSwitchFrame();
        String[] approverNames = approvers.split(",");
        By element;
        if (type.equalsIgnoreCase("tenders")) element = sltTendersApprovers;
        else element = sltMailApprovers;
        $(element).click();
        commonMethods.waitForElement(driver, addApproverOkBtn, 10);
        addApprover(approverNames);
    }

    /**
     * Method to remove approvers
     */
    public void removeApprovers(String type, String approvers) {
        verifyAndSwitchFrame();
        String[] approverNames = approvers.split(",");
        By element;
        if (type.equalsIgnoreCase("tenders")) element = sltTendersApprovers;
        else element = sltMailApprovers;
        $(element).click();
        commonMethods.waitForElement(driver, addApproverOkBtn, 10);
        for (String name : approverNames) {
            $(By.xpath("//div[contains(text(),'" + commonMethods.getUserData(name, "name") + "')]/../../td/a/div[@class='auiIcon trash']")).click();
            commonMethods.waitForElementExplicitly(1000);
        }
        $(addApproverOkBtn).click();
    }

    /**
     * Method to remove mail approvals
     */
    public void removeMailApproval(String mailType) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(5000);
        int column = $$(By.xpath("//td[contains(text(),'" + mailType + "')]/../td")).size();
        $(By.xpath("//td[contains(text(),'" + mailType + "')]/../td[" + column + "]/input")).setSelected(true);
        $(btnSave).click();
        commonMethods.waitForElement(driver, lblChangesSaved, 30);
        Assert.assertTrue($(lblChangesSaved).isDisplayed());
    }

    /**
     * Method to remove all configured mail approvals
     */
    public void removeConfiguredApprovals() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, btnAdd, 30);
        List<WebElement> elements = new ArrayList<>($$(By.xpath(chkBoxRemove)));
        for (int i = 1; i <= elements.size(); i++) {
            $(By.xpath("(" + chkBoxRemove + ")[" + i + "]")).setSelected(true);
        }
        $(btnSave).click();
        commonMethods.waitForElement(driver, lblChangesSaved, 30);
    }

    /**
     * Method to get first records request number
     */
    public String getFirstRecordReqNo() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, txtFirstRecordReqNo, 20);
        return $(txtFirstRecordReqNo).getText();
    }

    /**
     * Method to verify no results found message
     */
    public String verifyNoResults() {
        commonMethods.waitForElement(driver, lblNoResultsFound, 30);
        return $(lblNoResultsFound).getText();
    }

    /**
     * Method to search results with various search filters
     */
    public void enterFilterValues(String filter, String value) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, sltStatus, 20);
        switch (filter) {
            case "Request No.":
            case "Req. No.":
            case "Request No":
            case "Req No":
                $(txtboxRequestNo).sendKeys(value);
                break;
            case "Submitter":
                commonMethods.enterTextValue(txtboxSubmitter, value);
                break;
            case "Task":
                commonMethods.enterDropdownValue(sltTasks, value);
                break;
            case "Status":
                commonMethods.enterDropdownValue(sltStatus, value);
                break;
            case "Date":
            case "Date Req.":
                $(txtboxDate).sendKeys(value);
                break;
        }
        commonMethods.waitForElementExplicitly(1000);
    }

    public void clickSearch() {
        verifyAndSwitchFrame();
        $(btnSearch).click();
    }

    /**
     * Method to get the column values from the results table
     */
    public List<String> verifyResults(String filter) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, By.xpath(tblResultsHeader), 60);
        List<String> a = verifyTableHeaders();
        int columnIndex = a.indexOf(filter) + 1;
        int tableSize = $$(By.xpath(tblResults)).size();
        List<String> colValues = new ArrayList<>();
        for (int i = 1; i <= tableSize; i++) {
            commonMethods.waitForElementExplicitly(500);
            By xpath = By.xpath(tblResults + "[" + i + "]//td[" + columnIndex + "]");
            if (!colValues.contains($(xpath).getText()))
                colValues.add($(xpath).getText());
        }
        return colValues;
    }

    /**
     * Method to click on links
     */
    public void clickOnLink(int i) {
        verifyAndSwitchFrame();
        By xpath = By.xpath("//table[@class='dataTable']//tbody/tr[1]/td[" + i + "]");
        commonMethods.waitForElement(driver, xpath, 30);
        $(xpath).click();
    }

    /**
     * Method to approve mail approval request
     */
    public void approveRequest(String requestId) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, By.xpath(tblResultsHeader), 10);
        List<String> a = verifyTableHeaders();
        int columnIndex = a.indexOf("Apr.") + 1;
        $(By.xpath(tblResults + "[1]/td[" + columnIndex + "]/a")).click();
        commonMethods.waitForElement(driver, btnApprove, 30);
        verifyApproveTab(requestId);
        $(btnApprove).click();
    }

    /**
     * Method to verify approve popup window
     */
    public void verifyApproveTab(String requestId) {
        Assert.assertTrue($(lblConfirm).isDisplayed());
        Assert.assertTrue($(By.xpath("//div[contains(text(),'Approve request number " + requestId + "?')]")).isDisplayed());
        Assert.assertTrue($(btnApprove).isDisplayed());
        Assert.assertTrue($(btnCancel).isDisplayed());
    }

    /**
     * Method to verify approve page
     */
    public void verifyApprovePage(String requestId, String type, String sender) {
        String text = "The request '" + type + "' (Request No: " + requestId + ") from Professor. " + commonMethods.getUserData(sender, "name") + " item has been approved";
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, hdrApproved, 60);
        Assert.assertTrue($(hdrApproved).isDisplayed());
        Assert.assertTrue($(lblApprovedMessage).getAttribute("innerText").contains(text));
    }

    /**
     * Method to reject mail approval request
     */
    public void rejectRequest(String requestId, String type, String sender) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, By.xpath(tblResultsHeader), 10);
        List<String> a = verifyTableHeaders();
        int columnIndex = a.indexOf("Rej.") + 1;
        $(By.xpath(tblResults + "[1]/td[" + columnIndex + "]/a")).click();
        commonMethods.waitForElement(driver, btnReject, 30);
        verifyRejectTab(commonMethods.returnFromJson(requestId, "request_num", configFileReader.getMailDataPath()), type, commonMethods.getUserData(sender, "name"));
        $(txtBoxComments).sendKeys("Mail Rejected");
        $(btnReject).click();
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Method to verify reject popup window
     */
    public void verifyRejectTab(String requestId, String type, String sender) {
        commonMethods.waitForElement(driver, hdrRejectMail, 30);
        Assert.assertTrue($(hdrRejectMail).isDisplayed());
        Assert.assertTrue($(txtBoxAddSender).isDisplayed());
        Assert.assertTrue($(txtBoxComments).isDisplayed());
        Assert.assertTrue($(btnReject).isDisplayed());
        Assert.assertTrue($(btnRejectCancel).isDisplayed());
        Assert.assertTrue($(By.xpath("//div[text()='Request Number']/following-sibling::div[text()='" + requestId + "']")).isDisplayed());
        Assert.assertTrue($(By.xpath("//div[text()='Type']/following-sibling::div[text()='" + type + "']")).isDisplayed());
        Assert.assertTrue($(By.xpath("//div[text()='Submitter']/following-sibling::div[contains(text(),'" + sender + "')]")).isDisplayed());
        Assert.assertTrue($(By.xpath("//table[@class='grid-body-table dataTable']//div[contains(text(),'" + sender + "')]")).isDisplayed());
    }

    /**
     * Method to click on Add button
     */
    public void clickAddButton() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, btnAdd, 30);
        $(btnAdd).click();
    }

    /**
     * Method to click Cancel
     */
    public void clickCancel() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, btnCancel, 10);
        $(btnCancel).click();
    }

    /**
     * Method to get all values from mail types drop down field
     */
    public List<String> getAllMailTypes() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, sltMailType, 30);
        return commonMethods.returnAllOptionsInDropDown(driver, sltMailType);
    }

    /**
     * Method to verify alert message when no approvers present
     */
    public String verifyNoApproversAlert() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, approverSearchBox, 10);
        $(addApproverOkBtn).click();
        commonMethods.waitForElementExplicitly(2000);
        return getAlertText();
    }

    /**
     * Method to verify Add approvers field
     */
    public boolean verifyAddGuestApprover(String guestUser) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, approverSearchBox, 10);
        $(approverSearchBox).clear();
        commonMethods.enterTextValue(approverSearchBox, commonMethods.getUserName(guestUser));
        $(approverSearchBox).sendKeys(Keys.ENTER);
        commonMethods.waitForElementExplicitly(2000);
        return $(By.xpath("//div[contains(text(),'No match found for " + commonMethods.getUserName(guestUser) + ". Try a less specific query or ')]")).isDisplayed();
    }

    /**
     * Method to verify approvers name in awaiting approval tab
     */
    public void verifyApprovalName(String userId) {
        verifyAndSwitchFrame();
        By xpath = By.xpath(tblResults + "[1]//td[9]/img");
        actions.moveToElement($(xpath)).perform();
        Assert.assertEquals(commonMethods.getUserData(userId, "name"), $(xpath).getAttribute("title"));
    }

    /**
     * Method to approvers all pending requests
     */
    public void approveAllRequests() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, btnSearch, 30);
        List<WebElement> elements = new ArrayList<>($$(By.xpath(tblResults)));
        for (int i = 0; i < elements.size(); i++) {
            if (!($(lblNoResultsFound).getText().contains("No items"))) {
                $(btnSearch).click();
                commonMethods.waitForElement(driver, By.xpath(tblResults + "[1]"), 30);
                approveRequest(getFirstRecordReqNo());
                commonMethods.waitForElement(driver, hdrApproved, 60);
                $(backBtn).click();
                commonMethods.waitForElement(driver, btnSearch, 30);
            }
        }
    }

    /**
     * Method to save configure approval
     */
    public void saveConfigureApprover() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, approvalSaveBtn);
        $(approvalSaveBtn).click();
        commonMethods.waitForElement(driver, textSavedChanges);
    }

    /**
     * Method to change approvers
     */
    public void changeApprover(String user, String type) {
        verifyAndSwitchFrame();
        By element;
        commonMethods.waitForElement(driver, btnAdd, 60);
        if (type.equalsIgnoreCase("tenders")) element = sltTendersApprovers;
        else element = sltMailApprovers;
        if ($(element).isDisplayed()) {
            $(element).click();
            commonMethods.waitForElement(driver, addApproverOkBtn, 10);
            List<WebElement> elements = new ArrayList<>($$(By.xpath(tblApprovers)));
            for (int i = 1; i <= elements.size(); i++) {
                $(By.xpath(tblApprovers + "[1]/td/div/../../td/a/div[@class='auiIcon trash']")).click();
                commonMethods.waitForElementExplicitly(1000);
            }
            String[] approvers = user.split(",");
            addApprover(approvers);
        }
    }

    /**
     * Method to add approvers
     */
    private void addApprover(String[] approvers) {
        for (String name : approvers) {
            $(approverSearchBox).clear();
            $(approverSearchBox).sendKeys(commonMethods.getUserData(name, "name"));
            commonMethods.waitForElementExplicitly(1000);
            $(approverSearchBox).sendKeys(Keys.ENTER);
            commonMethods.waitForElement(driver, By.xpath("//div[contains(text(),'" + commonMethods.getUserData(name, "name") + "')]"), 10);
        }
        $(addApproverOkBtn).click();
    }
}
