package com.oracle.babylon.pages.Setup.ProjectSettings;

import com.oracle.babylon.pages.Setup.ProjectSettingsPage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;


public class ProjectFieldHierarchiesPage extends ProjectSettingsPage {

    private By hdrHierarchies = By.xpath("//h1[text()='Hierarchies']");
    private By btnAddHierarchies = By.xpath("//button[contains(@class,'upload-box') and contains(text(),'Add Hierarchies')]");
    private By btnRemove = By.xpath("//acx-hierarchy-result-list//div[@title='Delete']");
    private By removeBtn = By.xpath("(//acx-hierarchy-result-list//div[@title='Delete'])[1]");
    private By hdrUploadHierarchy = By.xpath("//h3[contains(text(),'Upload Hierarchy')]");
    private By uploadFile = By.xpath("//input[@name='customFileName']");
    private By btnUpload = By.xpath("//input[@value='Upload']");
    private By hdrDeleteConfirmation = By.xpath("//h3[contains(text(),'Delete Confirmation')]");
    private By btnDelete = By.xpath("//button[contains(text(),'Delete')]");
    private By btnDownloadSample = By.xpath("//button[text()='Download Sample']");
    private By lnkHdrLearnMore = By.xpath("//a[@class='auiMessage sampleFile ng-binding' and text()='Learn more about the Hierarchies']");
    private By lnkBodyLearnMore = By.xpath("//a[@class='ng-binding' and text()='Learn more about the Hierarchies']");
    private By txtNoHierarchies = By.xpath("//h1[text()='No hierarchies added']");
    private By btnAddHierarchy = By.xpath("//button[contains(@class,'hierarchyButton') and contains(text(),'Add Hierarchies')]");
    private By txtClickAdd = By.xpath("//h1[contains(text(),'Click on \"Add Hierarchies\" button to upload')]");
    private By txtProjectCascadingMetadata = By.xpath("//h1[contains(text(),'Using Cascading Metadata with your project')]");
    private By btnCloseUploadHierarchy = By.xpath("//div[@id='uploadFilesModal']//div[@class='auiModal-close']");
    private By txtFileName = By.xpath("//div[@id='selected_file_name']");
    private By txtInvalidFileError = By.xpath("//div[contains(@class,'auiMessage')]/div");
    private By closeError = By.xpath("//div[contains(@class,'auiMessage')]/button");
    private By hdrPreview = By.xpath("//b[contains(text(),'Preview')]");
    private By btnClosePreview = By.xpath("//div[@class='preview-label']//span[@class='auiIcon close close-icon']");
    private By btnInfo = By.xpath("//div[@class='preview-label']//button[@title='More information']");
    private By lstFieldNames = By.xpath("//div[@class='preview-content']/span");

    String testDataPath = configFileReader.getTestDataPath();

    /**
     * Function to click on Add Hierarchy button
     */
    public void clickAddHierarchy() {
        $(btnAddHierarchies).click();
    }

    /**
     * Function to verify upload hierarchy popup window
     */
    public void verifyUploadHierarchy() {
        commonMethods.waitForElement(driver, hdrUploadHierarchy);
        Assert.assertTrue($(hdrUploadHierarchy).isDisplayed());
        Assert.assertTrue($(btnUpload).isDisplayed());
    }

    /**
     * Function to upload hierarchy file
     */
    public void uploadHierarchy(String fileName) {
        commonMethods.waitForElement(driver, btnAddHierarchies, 60);
        clickAddHierarchy();
        verifyUploadHierarchy();
        uploadFile(fileName);
        commonMethods.waitForElementExplicitly(3000);
        clickUpload();
    }

    /**
     * Function to upload a file
     */
    public void uploadFile(String fileName) {
        $(uploadFile).sendKeys(new File(testDataPath + "/" + fileName).getAbsolutePath());
        commonMethods.waitForElementExplicitly(1000);
    }

    /**
     * Function to click on upload button
     */
    public void clickUpload() {
        $(btnUpload).click();
    }

    /**
     * Function to verify uploaded file
     */
    public boolean verifyProjectHierarchy(String fileName) {
        By xpath = By.xpath("//span[text()='" + fileName + "']");
        commonMethods.waitForElement(driver, xpath);
        return $(xpath).isDisplayed();
    }

    /**
     * Function to delete all hierarchies
     */
    public void deleteAllHierarchies() {
        commonMethods.waitForElement(driver, btnAddHierarchies, 60);
        List<WebElement> elements = new ArrayList<>($$(btnRemove));
        for (int i = 0; i < elements.size(); i++) {
            deleteHierarchy(removeBtn);
            commonMethods.waitForElementExplicitly(2000);
        }
    }

    /**
     * Function to delete specific hierarchy
     */
    public void deleteSingleHierarchy(String hierarchyName) {
        commonMethods.waitForElement(driver, btnAddHierarchies, 60);
        deleteHierarchy(By.xpath("//span[text()='" + hierarchyName + "']/ancestor::div//div[@title='Delete']"));
    }

    /**
     * Function to delete hierarchy
     */
    public void deleteHierarchy(By element) {
        $(element).click();
        commonMethods.waitForElement(driver, hdrDeleteConfirmation);
        $(By.xpath("(//button[contains(text(),'Delete')])[" + $$(btnDelete).size() + "]")).click();
    }

    /**
     * Function to verify options on project Hierarchies page
     */
    public void verifyProjectHierarchiesPage() {
        List<WebElement> hierarchies = Arrays.asList($(hdrHierarchies), $(lnkHdrLearnMore), $(btnDownloadSample), $(btnAddHierarchies), $(txtNoHierarchies), $(txtClickAdd), $(lnkBodyLearnMore), $(btnAddHierarchy));
        commonMethods.verifyElementsPresent(hierarchies);
    }

    /**
     * Function to verify Learn More option in project hierarchies page
     */
    public void verifyLearnMore() {
        $(lnkHdrLearnMore).click();
        verifyLearnMorePage();
        verifyAndSwitchFrame();
        switchProjectSettingsFrame();
        $(lnkBodyLearnMore).click();
        verifyLearnMorePage();
    }

    /**
     * Function to verify Learn More help page
     */
    public void verifyLearnMorePage() {
        commonMethods.switchToCurrentTab();
        switchToOriginal();
        commonMethods.waitForElement(driver, txtProjectCascadingMetadata, 60);
        Assert.assertTrue($(txtProjectCascadingMetadata).isDisplayed());
        commonMethods.closeCurrentTab();
        commonMethods.switchToOriginalTab();
    }

    /**
     * Function to download sample file
     */
    public void downloadSample() {
        commonMethods.waitForElement(driver, btnDownloadSample);
        $(btnDownloadSample).click();
    }

    /**
     * Function to close upload hierarchy popup window
     */
    public void closeUploadHierarchy() {
        $(btnCloseUploadHierarchy).click();
    }

    /**
     * Function to click Add Hierarchies button
     */
    public void clickAddHierarchyBtn() {
        $(btnAddHierarchy).click();
    }

    /**
     * Function to verify upload hierarchy
     */
    public String verifyUploadButton() {
        commonMethods.waitForElement(driver, btnUpload);
        return $(btnUpload).getAttribute("disabled");
    }

    /**
     * Function to verify added files count in upload hierarchy window
     */
    public int verifyFileCount() {
        return $$(txtFileName).size();

    }

    /**
     * Function to verify Invalid file upload error
     */
    public String verifyInvalidFileError() {
        commonMethods.waitForElement(driver, txtInvalidFileError);
        return $(txtInvalidFileError).getText();
    }

    /**
     * Function to close error message
     */
    public void closeErrorMessage() {
        commonMethods.waitForElementExplicitly(2000);
        $(closeError).click();
    }

    /**
     * Function to click on eye icon for a given hierarchy
     */
    public void clickEyeIcon(String hierarchyName) {
        $(By.xpath("//span[text()='" + hierarchyName + "']/ancestor::div//div[@title='Preview']")).click();
    }

    /**
     * Function to verify preview window
     */
    public void verifyPreview(List<String> projectFields) {
        commonMethods.waitForElement(driver, hdrPreview);
        commonMethods.verifyElementsPresent(Arrays.asList($(hdrPreview), $(btnClosePreview), $(btnInfo)));
        Assert.assertTrue(commonMethods.getValues(lstFieldNames).containsAll(projectFields));
        $(btnClosePreview).click();
    }

    /**
     * Function to click on download icon for a given hierarchy
     */
    public void clickDownload(String hierarchyName) {
        $(By.xpath("//span[text()='" + hierarchyName + "']/ancestor::div//div[@title='Download']")).click();
    }

}