package com.oracle.babylon.pages.Setup;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.switchTo;

/**
 * Function that contains the methods related to configure user/role org tab
 * Author : kukumavi
 */

public class ConfigureUserRoleOrgtab extends ConfigureUserRoleSettingsPage {

    private By txtSaveSuccess = By.xpath("//li//div[text()='Saved successfully']");

    public void navigateAndVerifyPage() {
        getMenuSubmenu("Setup", "User Role Configuration");
        verifyPageTitle("User Role Configuration");
    }

    public void setAsset(String parentAsset, String assetName, String roleName, String flag) {
        String[] assets = null;
        if (assetName.contains(",")) {
            assets = assetName.split(",");
            commonMethods.waitForElementExplicitly(5000);
            for (String asset : assets) {
                String rowIndex = Integer.toString(getAssetRow(parentAsset, asset));
                String columnIndex = Integer.toString(getRoleColumn(roleName));
                WebElement grantOption = driver.findElement(assetTable).findElement(By.xpath("//tr[" + rowIndex + "]//td[" + columnIndex + "]/select"));
                $(grantOption).selectOption(flag);
            }
        } else {
            String rowIndex = Integer.toString(getAssetRow(parentAsset, assetName));
            String columnIndex = Integer.toString(getRoleColumn(roleName));
            WebElement grantOption = driver.findElement(assetTable).findElement(By.xpath("//tr[" + rowIndex + "]//td[" + columnIndex + "]/select"));
            $(grantOption).selectOption(flag);
        }
        commonMethods.scrollToTop(driver);
        $(saveButton).click();
    }

    /**
     * Method to setr assets for specified role.
     *
     * @param parentAsset parent asset name.
     * @param assets      names of assets to be assigned to the role.
     * @param roleName    name of the role.
     * @param flag        flag.
     */
    public void setAssets(String parentAsset, List<String> assets, String roleName, String flag) {
        for (String asset : assets) {
            String rowIndex = Integer.toString(getAssetRow(parentAsset, asset));
            String columnIndex = Integer.toString(getRoleColumn(roleName));
            WebElement grantOption = driver.findElement(assetTable).findElement(By.xpath("//tr[" + rowIndex + "]//td[" + columnIndex + "]/select"));
            $(grantOption).selectOptionByValue(flag);
        }
        $(saveButton).click();
    }

    public void deleteRole(String role) {
        switchTo().defaultContent();
        verifyAndSwitchFrame();
        List<WebElement> roleLists = driver.findElement(assetTable).findElements(By.xpath("//td"));
        List<WebElement> assetLists;
        assetLists = driver.findElement(assetTable).findElements(By.xpath("//tr"));
        int assetSize = assetLists.size();
        int roleIndex = getRoleColumn(role);
        WebElement trashIcon = driver.findElement(assetTable).findElement(By.xpath("//tr[" + assetSize + "]//td[" + roleIndex + "]//a[1]//img[1]"));
        $(trashIcon).click();
        acceptAlert();
    }

    /**
     * Function to verify Asset dropdown options
     * @param parentAsset
     * @param assetName
     * @param roleName
     * @param assetValues
     */
    public void verifyAssetOptions(String parentAsset, String assetName, String roleName, List<String> assetValues) {
        String[] assets = null;
        String rowIndex = Integer.toString(getAssetRow(parentAsset, assetName));
        String columnIndex = Integer.toString(getRoleColumn(roleName));
        List<WebElement> grantOption = driver.findElement(assetTable).findElements(By.xpath("//tr[" + rowIndex + "]//td[" + columnIndex + "]//select//option"));
        for (int i = 0; i <= grantOption.size() - 1; i++) {
            String optionsText = grantOption.get(i).getText();
            Assert.assertTrue(optionsText.contains(assetValues.get(i)));
        }
    }

    /**
     * Function to verify Asset dropdown options
     *
     * @param parentAsset
     * @param assetName
     */
    public boolean verifyAssetOptions(String parentAsset, String assetName) {
        int rowIndex = getAssetRow(parentAsset, assetName);
        if (rowIndex > 0) return true;
        else return false;
    }

    /**
     * Function to verify Asset is saved successfully
     *
     * @return
     */
    public boolean verifySuccessMessage() {
        commonMethods.waitForElement(driver, txtSaveSuccess);
        return $(txtSaveSuccess).isDisplayed();
    }
}
