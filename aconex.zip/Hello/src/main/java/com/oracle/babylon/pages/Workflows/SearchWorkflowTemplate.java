package com.oracle.babylon.pages.Workflows;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;

import static com.codeborne.selenide.Selenide.$;

public class SearchWorkflowTemplate extends WorkflowsPage {


    private By pageTitle = By.xpath("//h1[text()='Search Workflow Templates']");
    private By templateName = By.xpath("//input[@id='WORKFLOW_NAME']");
    private By selectTemplatesBtn = By.xpath("//th[@id='selectMenuColumn']//div");
    private By selectAllPageTemplates = By.xpath("//a[text()='Select All On This Page']");
    private By selectAllTemplates = By.xpath("//a[text()='Select All Results']");
    private By actionsBtn = By.xpath("//button[@id='btnActionsMenu']");
    private By deleteLink = By.xpath("//a[text()='Delete']");
    private By okBtn = By.xpath("//button[@id='btnshowSelected_panel_ok']");
    private By noRecordsFound = By.xpath("//div[text()='No templates matched your request.']");
    private By newWfTemplate = By.xpath("//button[@id='btnNewWorkflowTemplate']");
    private By clearBtn = By.xpath("//button[@id='btnClear_page']");
    private By activeTab = By.xpath("//li[contains(text(),'Active')]");
    private By draftTab = By.xpath("//li[contains(text(),'Drafts')]");
    private By inactiveTab = By.xpath("//li[contains(text(),'Inactive')]");
    private By selectCreatorOrg = By.xpath("//select[@id='ORGANIZATION_ID']");
    private By sortBy = By.xpath("//select[@id='sortField']");
    private By showPerPage = By.xpath("//select[@id='PAGE_SIZE']");
    private By organizationName = By.xpath("//table[@id='resultsTable']//td[4]");
    private By numberOfRecords = By.xpath("//table[@id='resultsTable']//input[@type='checkbox']");
    private By actionOptions = By.xpath("//ul[@id='ActionsMenu']//a");
    private By confirmAction = By.xpath("//span[@id='showSelected_panel_title']");
    private By deactivationSuccessMsg = By.xpath("//div[contains(text(),'Selected templates have been deactivated successfully')]");
    private By noLongerInactive = By.xpath("//div[contains(text(),'Some of the selected templates are no longer inactive')]");
    private By actionMsg = By.xpath("//div[contains(text(),'Please run the search and try the action again')]");
    private By permissionErrorMsg = By.xpath("//div[contains(text(),'You do not have permission to modify some of the templates')]");
    private By deleteSuccessMsg = By.xpath("//div[contains(text(),'Selected templates have been deleted successfully')]");
    private By copyTemplateName = By.xpath("//input[@id='name']");
    private By statusTxt = By.xpath("//td[text()='Draft']");
    private By activateBtn = By.xpath("//button[@id='btnActivate']");
    private By activateSuccessMsg = By.xpath("//div[contains(text(),'Template activated successfully')]");
    private By selectProject = By.xpath("//select[@name='copyToProjectId']");
    private By copyToProjSuccsMsg = By.xpath("//div[contains(text(),'Selected templates have been successfully copied as draft to the destination proje')]");
    private By editDetailBtn = By.xpath("//a[@class='wf-stepprop']");
    private By participant = By.xpath("//input[@id='builder_stepto_query']");
    private By addedParticipant = By.xpath("//div[@class='lookup-assignee lookup-user truncated']");
    private By participantsMsg = By.xpath("//div[contains(text(),'Participants have not been set for some steps. Please assign participants to all steps.')]");
    private By tempActivatedMsg = By.xpath("//div[contains(text(),'Selected templates have been activated successfully')]");
    private By saveToDraftsBtn = By.xpath("//button[@id='btnSaveToDraft']");
    private By savedSuccesMsg = By.xpath("//div[contains(text(),'Template saved to draft successfully')]");
    String workflowFilePath = configFileReader.getWorkflowDataPath();

    /**
     * Function to navigate to a sub menu from the Aconex home page
     */
    public void navigateAndVerifyPage() {
        commonMethods.waitForElementExplicitly(2000);
        getMenuSubmenu("Workflows", "Search", "Templates");
        commonMethods.waitForElementExplicitly(2000);
        verifyAndSwitchFrame();
        Assert.assertTrue($(pageTitle).isDisplayed());
    }
    /**
     * Method to select of the searched templates
     */
    public void selectAllPageTemplate() {
        $(selectTemplatesBtn).click();
        commonMethods.waitForElement(driver, selectAllPageTemplates, 30);
        $(selectAllPageTemplates).click();
    }

    /**
     * Method to select of the searched templates
     */
    public void selectAllTemplate() {
        $(selectTemplatesBtn).click();
        commonMethods.waitForElement(driver, selectAllTemplates, 30);
        $(selectAllTemplates).click();
    }

    /**
     * Method to delete the selected templates
     */
    public void deleteTemplates() {
        commonMethods.waitForElement(driver, actionsBtn, 40);
        $(actionsBtn).click();
        $(deleteLink).click();
        $(okBtn).click();

    }

    /**
     * Method to check if search results return empty
     *
     * @return
     */
    public boolean checkEmptyRecords() {
        commonMethods.waitForElementExplicitly(1000);
        return $(noRecordsFound).isDisplayed();
    }

    /**
     * Function to verify fields in page
     */
    public void verifyPageFields() {
        Assert.assertTrue($(newWfTemplate).isDisplayed());
        Assert.assertTrue($(clearBtn).isDisplayed());
        Assert.assertTrue($(searchBtn).isDisplayed());
        Assert.assertTrue($(templateName).isDisplayed());
        Assert.assertTrue($(activeTab).isDisplayed());
        Assert.assertTrue($(draftTab).isDisplayed());
        Assert.assertTrue($(inactiveTab).isDisplayed());
        Assert.assertTrue($(selectCreatorOrg).isDisplayed());
        Assert.assertTrue($(sortBy).isDisplayed());
        Assert.assertTrue($(showPerPage).isDisplayed());
    }

    /**
     * Function to search workflow template
     *
     * @param template
     */
    public void searchWorkflowTemplate(String template) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver,templateName,40);
        $(templateName).clear();
        $(templateName).sendKeys(getTemplateName(template));
        commonMethods.waitForElementExplicitly(500);
        $(searchBtn).click();
    }

    /**
     * Function to verify Org Name
     *
     * @param userName
     * @return
     */
    public boolean verifyOrgName(String userName) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
        userMap = jsonMapOfMap.get(userName);
        commonMethods.waitForElementExplicitly(2000);
        return $(organizationName).getText().equalsIgnoreCase(userMap.get("org_name").toString());
    }

    /**
     * Click on clear button
     */
    public void clickClearBtn() {
        $(clearBtn).click();
    }

    /**
     * select show per page
     *
     * @param count
     */
    public void setRecordsCount(String count) {
        commonMethods.waitForElement(driver, showPerPage, 40);
        $(showPerPage).selectOption(count);
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Function to verify number of records
     *
     * @param number
     * @return
     */
    public boolean verifyNumberOfTemplates(int number) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, numberOfRecords, 40);
        List<WebElement> records = driver.findElements((numberOfRecords));
        return records.size() > number;
    }

    /**
     * Select sort by option
     *
     * @param value
     */
    public void selectSortBy(String value) {
        $(sortBy).selectOption(value);
    }

    /**
     * Function to verify Action options
     *
     * @param actionValues
     * @return
     */
    public boolean verifyActionOptions(List<String> actionValues) {
        ArrayList actionOptionsText = new ArrayList();
        clickSearch();
        $(actionsBtn).click();
        List<WebElement> options = driver.findElements(actionOptions);
        for (int i = 0; i <= options.size() - 1; i++) {
            String optionsText = options.get(i).getText();
            actionOptionsText.add(optionsText);
        }
        return actionValues.equals(actionOptionsText);
    }

    /**
     * Function to select action option
     *
     * @param action
     */
    public void selectAction(String action) {
        commonMethods.getElementInViewAndUp(actionsBtn);
        $(actionsBtn).click();
        $(By.xpath("//ul[@id='ActionsMenu']//a[text()='" + action + "']")).click();

    }

    /**
     * Function to select number of records
     *
     * @param count
     */
    public void selectTemplate(int count) {
        commonMethods.waitForElement(driver, numberOfRecords, 40);
        List<WebElement> records = driver.findElements((numberOfRecords));
        for (int i = 0; i <= count - 1; i++) {
            records.get(i).click();
        }

    }

    /**
     * Function to confirm action
     */
    public void confirmAction() {
        commonMethods.waitForElement(driver, confirmAction, 40);
        if ($(confirmAction).isDisplayed()) {
            $(okBtn).click();
        }
    }

    /**
     * Function to verify deactivation
     *
     * @return
     */
    public boolean verifyDeactivateTemplate() {
        confirmAction();
        commonMethods.waitForElement(driver, deactivationSuccessMsg, 40);
        return $(deactivationSuccessMsg).isDisplayed();
    }

    /**
     * Function to verify Activation
     *
     * @return
     */
    public boolean verifyTemplateActivation() {
        confirmAction();
        commonMethods.waitForElement(driver, noLongerInactive, 40);
        Assert.assertTrue($(actionMsg).isDisplayed());
        return $(noLongerInactive).isDisplayed();
    }

    /**
     * Function to verify template Activation error msd for drafts
     *
     * @return
     */
    public boolean verifyActivationErrorMsg() {
        confirmAction();
        commonMethods.waitForElement(driver, participantsMsg, 40);
        return $(participantsMsg).isDisplayed();
    }

    /**
     * Function to verify template Activation for Drafts
     *
     * @return
     */
    public boolean verifyTemplateActivatedMsg() {
        confirmAction();
        commonMethods.waitForElement(driver, tempActivatedMsg, 40);
        return $(tempActivatedMsg).isDisplayed();
    }

    /**
     * Function to verify Delete
     *
     * @return
     */
    public boolean verifyDeleteTemplate() {
        confirmAction();
        commonMethods.waitForElement(driver, deleteSuccessMsg, 40);
        return $(deleteSuccessMsg).isDisplayed();
    }

    /**
     * Function to verify Activation
     *
     * @return
     */
    public boolean verifyPermissionErrorMsg() {
        confirmAction();
        commonMethods.waitForElement(driver, permissionErrorMsg, 40);
        return $(permissionErrorMsg).isDisplayed();
    }

    /**
     * Function to verify copy template
     *
     * @return
     */
    public boolean verifyCopyTemplate() {
        Assert.assertTrue($(copyTemplateName).getValue().contains("Copy"));
        Assert.assertTrue($(statusTxt).isDisplayed());
        commonMethods.waitForElementExplicitly(2000);
        $(activateBtn).click();
        commonMethods.waitForElement(driver, activateSuccessMsg, 40);
        return $(activateSuccessMsg).isDisplayed();
    }

    /**
     * Function to verify copy template
     *
     * @return
     */
    public boolean verifyCopyToProjectTemplate(String userName) {
        commonMethods.waitForElement(driver, confirmAction, 40);
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
        userMap = jsonMapOfMap.get(userName);
        if ($(confirmAction).isDisplayed()) {
            $(selectProject).selectOption(userMap.get("project_name1").toString());
            $(okBtn).click();
            commonMethods.waitForElement(driver, copyToProjSuccsMsg, 40);
            return $(copyToProjSuccsMsg).isDisplayed();
        }
        return false;
    }

    /**
     * Click on Tab
     *
     * @param tabName
     */
    public void clickTab(String tabName) {
        By tab = By.xpath("//li[contains(text(),'" + tabName + "')]");
        commonMethods.waitForElement(driver, tab, 40);
        $(tab).click();
    }

    /**
     * Function to click on template
     *
     * @param templateName
     */
    public void clickTemplate(String templateName) {
        By template = By.xpath("//a[contains(text(),'" + getTemplateName(templateName) + "')]");
        commonMethods.waitForElement(driver, template, 40);
        $(template).click();

    }

    /**
     * Function to return template name
     *
     * @param template
     * @return
     */
    public String getTemplateName(String template) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(workflowFilePath);
        mailMap = jsonMapOfMap.get(template);
        return mailMap.get("template_name").toString();
    }

    /**
     * Function to verify Edit copy template
     *
     * @param template
     */
    public boolean verifyEditCopyTemp(String template) {
        commonMethods.waitForElement(driver, copyTemplateName, 40);
        Assert.assertTrue($(copyTemplateName).getValue().equalsIgnoreCase(getTemplateName(template)));
        Assert.assertTrue($(statusTxt).isDisplayed());
        commonMethods.waitForElement(driver,editDetailBtn,40);
        getElementInView(editDetailBtn);
        commonMethods.waitForElementExplicitly(1000);
        $(editDetailBtn).click();
        commonMethods.waitForElement(driver, participant, 40);
        return $(addedParticipant).isDisplayed();

    }

    /**
     * Function verify grayed out value
     *
     * @param option
     */
    public boolean verifyGrayedOutOption(String option) {
        return $(By.xpath("//div[@class='uiMenu-label uiMenu-fake']//a[text()='" + option + "']")).isDisplayed();
    }

    /**
     * Function Select  Template based on Org
     *
     * @param userName
     * @param template
     */
    public void selectOrgTemplate(String userName, String template) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
        userMap = jsonMapOfMap.get(userName);
        $(By.xpath("//td[text()='" + userMap.get("org_name").toString() + "']//..//a[text()='" + getTemplateName(template) + "']//..//..//input")).click();
    }

    /**
     * Function to save to drafts copy template
     *
     * @return
     */
    public boolean verifySavedToDrafts() {
        Assert.assertTrue($(copyTemplateName).getValue().contains("Copy"));
        Assert.assertTrue($(statusTxt).isDisplayed());
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, saveToDraftsBtn, 40);
        $(saveToDraftsBtn).click();
        commonMethods.waitForElement(driver, savedSuccesMsg, 40);
        return $(savedSuccesMsg).isDisplayed();
    }

    /**
     * Select creator org
     * @param userName
     */
    public void selectCreatorOrg(String userName){
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
        userMap = jsonMapOfMap.get(userName);
        commonMethods.waitForElement(driver, selectCreatorOrg, 40);
        $(selectCreatorOrg).selectOption(userMap.get("org_name").toString());
    }

    /**
     * Function to Delete All templates
     *
     * @param userName
     */
    public boolean deleteAllTemplates(String userName) {
        selectCreatorOrg(userName);
        clickSearch();
        commonMethods.waitForElementExplicitly(5000);
        if (!$(noRecordsFound).isDisplayed()) {
            selectAllTemplate();
            deleteTemplates();
        }
        commonMethods.waitForElement(driver, noRecordsFound, 40);
        if ($(noRecordsFound).isDisplayed()) {
            return true;
        }
        return false;
    }

    /**
     * Function to search template
     * @param template
     */
    public void searchTemplate(String template){
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver,templateName,40);
        $(templateName).clear();
        $(templateName).sendKeys(template);
        commonMethods.waitForElementExplicitly(1000);
        $(searchBtn).click();
    }
}
