package com.oracle.babylon.pages.Report;

import com.codeborne.selenide.SelenideElement;
import com.oracle.babylon.Utils.helper.Navigator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;

import static com.codeborne.selenide.Condition.appear;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

/**
 * Class for selecting specific dropdown and values from dropdown.
 *
 */
public class MenuDropDown extends Navigator {

    private String menuButtonLocatorString = "//button[@id='identifier']";
    private static final String menuListLocatorString = "//following-sibling::div[@class='templateElements' or @id='templateElements']";
    private String itemLocatorString = "//li/p[contains(@title,'item')]//parent::li";
    private By dropDown;
    private By menuList;
    private By item;

    /**
     * Constructor to initialize locators based on the values to select.
     *
     * @param identifier - Identifier of the dropdown.
     */
    public MenuDropDown(String identifier) {
        verifyAndSwitchFrame();
        menuButtonLocatorString = menuButtonLocatorString.replace("identifier",identifier);
        dropDown = By.xpath(menuButtonLocatorString);
        menuList = By.xpath(menuButtonLocatorString + menuListLocatorString);
    }

    /**
     * Method to select layout for report.
     *
     * @param itemName Name of the layout to be selcted.
     */
    public void selectItem(String itemName){
        itemLocatorString = itemLocatorString.replace("item", itemName);
        item = By.xpath(menuButtonLocatorString + menuListLocatorString + itemLocatorString);
        $(dropDown).waitUntil(appear, 10000).click();
        $(menuList).waitUntil(appear, 6000, 1000);
        $(item).click();
    }

    /**
     * Method to gete list of available options under drop down.
     *
     */
    public List<String> getAvailableOptions() {
        List<String> options = new ArrayList<>();
        $(dropDown).click();
        $(menuList).waitUntil(appear, 4000, 1000);
        for (SelenideElement element : $$($(menuList).findElements(By.xpath("//ul[@id='saveAsMenuList']/li[not(contains(@class,'hidden'))]/p")))) {
            options.add(element.getAttribute("id"));
        }
        $(dropDown).click();
        return options;
    }
}