package com.oracle.babylon.pages.Notifications;

import com.oracle.babylon.Utils.helper.EmailOperation;
import org.junit.Assert;

import javax.mail.*;
import javax.mail.internet.ContentType;
import javax.mail.internet.MimeMultipart;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Notifications extends EmailOperation {

    /**
     * Method to create a connection to gmail account
     */
    public void createGMailConnection(String email, String password) {
        setImapProperties(email.split("@")[0]);
        createMailConnection(email, password);
    }

    /**
     * Method to get Emails from Inbox
     */
    public String getEmailBody(Message message) {
        return getTextFromMessage(message);
    }

    /**
     * Method to get and verify Inbox Mails for a specified search criteria
     */
    public boolean verifyInboxMails(String filterText) {
        try {
            inbox = store.getFolder("INBOX");
            inbox.open(Folder.READ_ONLY);
            messages = inbox.getMessages();
            Message[] foundMessages = inbox.search(searchInboxMails(filterText));
            if (foundMessages.length > 0)
                return true;
        } catch (MessagingException e) {
            System.out.println("Could not connect to the Inbox");
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Method to get email from Inbox
     */
    public Message getMailBody(String subject) {
        try {
            inbox = store.getFolder("INBOX");
            inbox.open(Folder.READ_ONLY);
            messages = inbox.getMessages();
            Message[] foundMessages = inbox.search(searchInboxMails(subject));
            if (foundMessages.length > 0)
                return foundMessages[foundMessages.length - 1];
        } catch (MessagingException e) {
            System.out.println("Could not connect to the Inbox");
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Method to delete all emails in Inbox for Gmail
     */
    public void deleteAllMails() {
        try {
            inbox = store.getFolder("INBOX");
            inbox.open(Folder.READ_WRITE);
            messages = inbox.getMessages();
            if (messages.length > 0) {
                Folder trash = store.getFolder("[Gmail]/Trash");
                inbox.copyMessages(messages, trash);
            }
            inbox.close(true);
        } catch (MessagingException e) {
            System.out.println("Could not connect to the Inbox");
            e.printStackTrace();
        }
    }

    /**
     * Method to get body of an email
     */
    public String getTextFromMessage(Message message) {
        try {
            String result = "";
            if (message.isMimeType("text/plain")) {
                result = message.getContent().toString();
            } else if (message.isMimeType("multipart/*")) {
                MimeMultipart mimeMultipart = (MimeMultipart) message.getContent();
                result = getTextFromMimeMultipart(mimeMultipart);
            }
            return result;
        } catch (MessagingException | IOException e) {
            System.out.println("Could not access body of email");
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Method to get multipart body of an email
     */
    public String getTextFromMimeMultipart(MimeMultipart mimeMultipart) {
        try {
            int count = mimeMultipart.getCount();
            if (count == 0)
                throw new MessagingException("Multipart with no body parts not supported.");
            boolean multipartAlt = new ContentType(mimeMultipart.getContentType()).match("multipart/alternative");
            if (multipartAlt)
                return getTextFromBodyPart(mimeMultipart.getBodyPart(count - 1));
            StringBuilder result = new StringBuilder();
            for (int i = 0; i < count; i++) {
                BodyPart bodyPart = mimeMultipart.getBodyPart(i);
                result.append(getTextFromBodyPart(bodyPart));
                if (null != bodyPart.getDisposition() && bodyPart.getDisposition().equalsIgnoreCase(Part.ATTACHMENT))
                    result.append(bodyPart.getFileName());
            }

            return result.toString();
        } catch (MessagingException e) {
            System.out.println("Could not access body of email");
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Method to get text body part of an email
     */
    public String getTextFromBodyPart(BodyPart bodyPart) {
        try {
            String result = "";
            if (bodyPart.isMimeType("text/plain") || bodyPart.isMimeType("text/html")) {
                result = (String) bodyPart.getContent();
            } else if (bodyPart.getContent() instanceof MimeMultipart) {
                result = getTextFromMimeMultipart((MimeMultipart) bodyPart.getContent());
            }
            return result;
        } catch (MessagingException | IOException e) {
            Assert.fail("Could not access body of email");
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Method to extract url from message body
     */
    public String getUrl(String subject) {
        try {
            List<String> links = new ArrayList<>();
            MimeMultipart mimeMultipart = (MimeMultipart) getMailBody(subject).getContent();
            String html = getTextFromMimeMultipart(mimeMultipart);
            Pattern linkPattern = Pattern.compile("<a\\b[^>]*href=\"[^>]*>(.*?)</a>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
            Matcher pageMatcher = linkPattern.matcher(html);
            while (pageMatcher.find()) {
                links.add(pageMatcher.group());
            }
            for (String temp : links) {
                if (temp.contains(subject)) {
                    return temp.split("a href=")[1].split(" ")[0].replace("\"", "");
                }
            }
        } catch (MessagingException | IOException e) {
            e.printStackTrace();
        }
        return null;
    }

}
