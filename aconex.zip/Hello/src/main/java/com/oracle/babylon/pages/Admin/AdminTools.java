package com.oracle.babylon.pages.Admin;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.WebDriverRunner;
import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static com.codeborne.selenide.Selenide.*;

/**
 * Class that contains methods to manage configurations
 * Author : susgopal
 */
public class AdminTools extends Navigator{

    //Web element initialization
    private By adminToolsLabel = By.xpath("//h1[text()='Aconex Admin Tools']");
    private By configureComponentsForProjectLink = By.xpath("//a[text()='Configure Components for Project']");
    private By configureAccessibleComponentsLabel = By.xpath("//h1[contains(text(),'Configure Accessible Components for')]");
    private By projectIdTextBox = By.name("SELECTED_PROJECT_ID");
    private By lookupBtn = By.xpath("//button[@title='Search for this Project']");
    private By saveButton =  By.xpath("//button[@title='Commit the feature settings']");
    private By successMsg = By.xpath("//div[text()='Success: Feature settings successfully updated.']");
    private By controlledDocuments = By.xpath("//a[text()='Controlled Document Processing']");
    private By projectIdTxtBox = By.xpath("//input[@name='PROJ_ID']");
    private By documentNumberTxtBox = By.xpath("//input[@name='DOC_NO']");
    private By orgIdTxtBox = By.xpath("//input[@name='ORG_ID']");
    private By getListBtn = By.xpath("//button[@title='Get List for this document no and org']");
    private By rowsCount = By.xpath("//table[@class='dataTable']//tbody//tr");
    private By removeUserFromProject=By.xpath("//a[text()='Remove User From Project']");
    private By removeUserFromProjectHeader=By.xpath("//h1['Remove User From Project']");
    private By projectNameInput=By.id("remove-user-typeahead");
    private By removeSelectedUsers=By.xpath("//button[@title='Remove the selected user from the selected project']");
    private By selectProjectName=By.xpath("//div[@class='content-data']//ul//li");
    private By removedMsgSuccess=By.xpath("//*[contains(text(),'User successfully removed from project')]");
    private By loginSearchName=By.xpath("//input[@name='SRCH_USER_NAME']");
    private By btnHideInGlobalDirectory=By.xpath("//button[@id='btnHideInGlobalDirectory']//*[text()='Hide in Global']");
    private By btnShowInGlobalDirectory=By.xpath("//button[@id='btnShowInGlobalDirectory']//*[text()='Show in Global']");
    private By configureIDP = By.xpath("//a[text()='Configure IDP for Organization']");
    private By lblConfigureIDP = By.xpath("//h1[text()='Configure Identity Provider']");
    private By txtboxOrgId = By.xpath("//input[@id='orgId']");
    private By txtboxIdPartnerId = By.xpath("//input[@id='partnerId']");
    private By lnkPrjtDisconnectReconnect = By.xpath("//a[text()='Project Disconnect/Reconnect']");
    private By selectProject = By.xpath("//div[@id='configuringProjectId']/input");
    private By dropDownTask = By.xpath("//select[@id='projectDisconnectionActionSelect']");
    private By btnNext = By.xpath("//button[@id='btnProjectDisconnectionNext']");
    private By sltPurposeCategory = By.xpath("//select[@id='purposeSelect']");
    private By sltPayingOrg = By.xpath("//select[@id='orgSelect']");
    private String sltPayingOrganization = "//select[@id='orgSelect']/option";
    private By txtBoxPayingOrgMsg = By.xpath("//textarea[@name='orgWarningMessage']");
    private By txtBoxNonPayingOrgMsg = By.xpath("//textarea[@name='projectWarningMessage']");
    private By btnActivateWarning = By.xpath("//button[@id='btnActivateProjectWarning']");
    private By btnDisconnectProject = By.xpath("//button[@id='btnDisconnectProject']");
    private By lnkHidePrjtsFromOrgs = By.xpath("//a[text()='Hide Project From Organization(s)']");
    private By txtBoxProjectName = By.xpath("//input[@id='searchText']");
    private By btnSearch = By.xpath("//button[@id='btnSearch']");
    private String tblOrgRows = "//form[@id='form1']//table//tbody/tr";
    private By txtHidePrjSuccess = By.xpath("//li[@class='message success']//div[text()='Status has been updated']");
    private By sltOrganizations = By.xpath("//select[@id='orgSelect']/option");


    /**
     * Function to select the link we want to update in the project settings page
     * @param by
     */
    public void selectOptionToConfigure(By by){
        commonMethods.waitForElement(driver, by);
        $(by).click();
    }

    /**
     * Function to configure the components for a project
     * @param setElements elements that need to be configured
     * @param projectId project id to be configured
     */
    public void configureComponentsForProject(Set<String> setElements, String projectId, Boolean value){
        driver = WebDriverRunner.getWebDriver();
        verifyAndSwitchFrame();
        $(adminToolsLabel).isDisplayed();
        selectOptionToConfigure(configureComponentsForProjectLink);
        $(configureAccessibleComponentsLabel).isDisplayed();
        $(projectIdTextBox).sendKeys(projectId);
        commonMethods.waitForElementExplicitly(2000);
        $(lookupBtn).click();

        $(configureAccessibleComponentsLabel).isDisplayed();
        for(String optionToConfigure : setElements){
            By elementToCheck = By.xpath("//td[contains(text(), '" + optionToConfigure + "')]//input");
            $(elementToCheck).setSelected(value);
        }
        $(saveButton).click();
        driver.switchTo().defaultContent();
    }

    /**
     * Enabling web services api for a project
     * @param projectId project id that needs to be configured
     */
    public void enableWebServicesAPI(String projectId){
        Set<String> featuresToEnable = new HashSet<>();
        featuresToEnable.add("Web Services API");
        configureComponentsForProject(featuresToEnable, projectId,true);
    }

    /**
     * Enabling workflow api for a project
     * @param projectId project id that needs to be configured
     */
    public void enableWorkflow(String projectId){

        Set<String> featuresToEnable = new HashSet<>();
        featuresToEnable.add("Workflows");
        configureComponentsForProject(featuresToEnable, projectId,true);
    }

    /**
     * Navigate to the tools page
     * @return
     */
    public WebDriver navigateToTools() {

        return getMenuSubmenu( "Setup", "Tools");
    }


    /**
     * Function to verify if success message
     * @return
     */
    public boolean isFeatureSettingsSaved(){
        return $(successMsg).isDisplayed();
    }

    /**
     * Method to navigate and verify for the title of the page
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Setup", "Tools");
        Assert.assertTrue(verifyPageTitle("Aconex Admin Tools"));
    }

    public void searchControlledDocument(String projectId, String documentId){
        commonMethods.waitForElement(driver, controlledDocuments);
        selectOptionToConfigure(controlledDocuments);
        $(projectIdTxtBox).sendKeys(projectId);
        $(documentNumberTxtBox).sendKeys(documentId);
        commonMethods.waitForElementExplicitly(500);
        $(getListBtn).click();

    }


    public int returnRowCount(){
        List<WebElement> elements = driver.findElements(rowsCount);
        return elements.size();

    }

    /**
     * Method to click Remove User from project
     */
    public void clickRemoveUser()
    {
        commonMethods.waitForElement(driver,removeUserFromProject);
        $(removeUserFromProject).click();
        $(removeUserFromProjectHeader).shouldBe(Condition.appear);
    }
    /**
     * Function to search project
     * @return
     */
    public void searchProject(String projectId)
    {
        commonMethods.waitForElement(driver,projectNameInput);
        $(projectNameInput).sendKeys(projectId + Keys.ENTER);
        commonMethods.waitForElement(driver,selectProjectName);
        $(selectProjectName).click();
    }
    /**
     * Function to select user
     * @return
     */
    public void selectUser(String fullName)
    {
        $(By.xpath("//td[text()='"+fullName+"']//..//td//input[@type='checkbox']")).scrollTo();
        $(By.xpath("//td[text()='"+fullName+"']//..//td//input[@type='checkbox']")).setSelected(true);
    }
    /**
     * Function to click remove selected user
     * @return
     */
    public void clickRemovedSelectedUsers()
    {
        commonMethods.waitForElement(driver,removeSelectedUsers);
        $(removeSelectedUsers).click();
        $(removedMsgSuccess).shouldBe(Condition.appear);

    }
    public void searchUserOnLoginName(String loginName)
    {
        $(loginSearchName).shouldBe(Condition.appear);
        $(loginSearchName).sendKeys(loginName);
        searchButton();
    }

    public void clickHideinGlobal()
    {
        commonMethods.waitForElement(driver,btnHideInGlobalDirectory);
        $(btnHideInGlobalDirectory).click();
    }

    public void chooseUser(String userName)
    {
        $(By.xpath("//td//a[contains(text(),'"+userName+"')]//..//..//td//input[@type='checkbox']")).click();
    }
    public void clickShowinGlobal()
    {
        commonMethods.waitForElement(driver,btnShowInGlobalDirectory);
        $(btnShowInGlobalDirectory).click();
    }

    /**
     * Function to click on tool by passing admin tools name
     */
    public void clickOnTool(String name) {
        verifyAndSwitchFrame();
        By element = By.xpath("//div/a[text()='" + name + "']");
        commonMethods.clickOnElement(element);
    }

    /**
     * Function to verify project hierarchy tool
     */
    public boolean verifyProjectHierarchyTool(String xpath) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver,By.xpath(xpath), 30);
        return $(By.xpath(xpath)).isDisplayed();
    }

    /**
     * Function to remove the components for a project
     * @param setElements elements that need to be removed
     * @param projectId project id to be configured
     */
    public void removeComponentsForProject(Set<String> setElements, String projectId){
        driver = WebDriverRunner.getWebDriver();
        verifyAndSwitchFrame();
        $(adminToolsLabel).isDisplayed();
        selectOptionToConfigure(configureComponentsForProjectLink);
        $(configureAccessibleComponentsLabel).isDisplayed();
        $(projectIdTextBox).sendKeys(projectId);
        $(lookupBtn).click();
        $(configureAccessibleComponentsLabel).isDisplayed();
        for(String optionToConfigure : setElements){
            By elementToCheck = By.xpath("//td[contains(text(), '" + optionToConfigure + "')]//input");
            if(commonMethods.isElementAttributePresent(elementToCheck, "checked") && !commonMethods.isElementAttributePresent(elementToCheck, "disabled")){
                $(elementToCheck).click();
            }
        }
        $(saveButton).click();
        driver.switchTo().defaultContent();
    }

    /**
     * Method to click on Configure IDP for Organization link
     */
    public void clickConfigureIDP() {
        commonMethods.waitForElement(driver, configureIDP);
        $(configureIDP).click();
    }

    /**
     * Method to configure Identity provider
     */
    public void configureIdp(String orgId) {
        commonMethods.waitForElement(driver, lblConfigureIDP);
        commonMethods.enterTextValue(txtboxOrgId, orgId);
        commonMethods.enterTextValue(txtboxIdPartnerId, configFileReader.getPartnerId());
        $(saveBtn).click();
    }

    /**
     * Method to verify IDP is created
     */
    public boolean verifyIDPConfigured(String organization) {
        By xpath = By.xpath("//div[text()=\"Organization " + organization + " successfully updated.\"]");
        commonMethods.waitForElement(driver, xpath);
        return $(xpath).isDisplayed();
    }

    /**
     * Function to verify configuration components set for a project
     * @param setElements elements that need to be verified
     * @param projectId project id to be verified for configuration
     */
    public void verifyComponentsForProject(Set<String> setElements, String projectId){
        driver = WebDriverRunner.getWebDriver();
        $(adminToolsLabel).isDisplayed();
        selectOptionToConfigure(configureComponentsForProjectLink);
        $(configureAccessibleComponentsLabel).isDisplayed();
        $(projectIdTextBox).sendKeys(projectId);
        $(lookupBtn).click();
        $(configureAccessibleComponentsLabel).isDisplayed();
        for(String optionToConfigure : setElements){
            By elementToCheck = By.xpath("//td[contains(text(), '" + optionToConfigure + "')]//input");
            if(commonMethods.isElementAttributePresent(elementToCheck, "checked") && !commonMethods.isElementAttributePresent(elementToCheck, "disabled")){
            Assert.assertTrue("The configuration is set for the component",true);
            }
        }
    }

    /**
     * Method to click on Project Disconnect/Reconnect  link
     */
    public void clickPrjDisConnectReConnect() {
        commonMethods.waitForElement(driver, lnkPrjtDisconnectReconnect);
        $(lnkPrjtDisconnectReconnect).click();
    }

    /**
     * Method to activate/deactivate warning message
     */
    public boolean activateWarningMessage(String userId, String projectName, String task, String purpose) {
        enterPrjDisconnectDetails(projectName, task);
        createWarningMessage(userId, purpose);
        return verifyWarningSuccess(userId);
    }

    /**
     * Method to enter project details for disconnection
     */
    public void enterPrjDisconnectDetails(String projectId, String task) {
        commonMethods.waitForElement(driver, selectProject, 60);
        commonMethods.enterTextValue(selectProject, projectId);
        commonMethods.waitForElementExplicitly(2000);
        $(selectProject).sendKeys(Keys.ENTER);
        commonMethods.enterDropdownValue(dropDownTask, task);
        $(btnNext).click();
    }

    /**
     * Method to create deactivate warning message
     */
    public void createWarningMessage(String userId, String purpose) {
        commonMethods.waitForElement(driver, sltPurposeCategory, 60);
        commonMethods.enterDropdownValue(sltPurposeCategory, purpose);
        List<String> organizations = commonMethods.getValues(sltOrganizations);
        for (int i = 1; i <= organizations.size(); i++)
            if (organizations.get(i).contains(commonMethods.getUserData(userId, "organisation"))) {
                $(sltPayingOrg).selectOption(i);
                break;
            }
        if (purpose.equalsIgnoreCase("custom")) {
            commonMethods.enterTextValue(txtBoxPayingOrgMsg, faker.book().title());
            commonMethods.enterTextValue(txtBoxNonPayingOrgMsg, faker.book().title());
        }
        $(btnActivateWarning).click();
    }

    /**
     * Method to verify warning message success
     */
    public boolean verifyWarningSuccess(String user) {
         return $(By.xpath("//li[@class='message success']//div[contains(text(),'The warning message for project') and contains(text(),'organization " + commonMethods.getUserData(user, "organisation")+ "') ]")).isDisplayed();
    }

    /**
     * Method to disconnect or reconnect project
     */
    public void disconnectProject(String projectName, String task) {
        enterPrjDisconnectDetails(projectName, task);
        commonMethods.waitForElement(driver, btnDisconnectProject, 60);
        $(btnDisconnectProject).click();
    }

    /**
     * Method to verify disconnect success
     */
    public boolean verifyDisconnectSuccess(String user) {
        return $(By.xpath("//li[@class='message success']//div[contains(text(),'has been successfully disconnected for organization') and contains(text(),'" + commonMethods.getUserData(user, "organisation")+ "') ]")).isDisplayed();
    }

    /**
     * Method to click on Hide Project from organizations link
     */
    public void clickHideProjectsFromOrgs() {
        commonMethods.waitForElement(driver, lnkHidePrjtsFromOrgs);
        $(lnkHidePrjtsFromOrgs).click();
    }

    /**
     * Method to hide or show projects from Hide Project from organizations tab
     */
    public void hideProjectForAllOrgs(String projectName, String option) {
        searchProjectToHide(projectName);
        By xpath = By.xpath("//a[text()='" + projectName + "']");
        commonMethods.waitForElement(driver, xpath, 60);
        $(xpath).click();
        commonMethods.waitForElement(driver, saveBtn, 60);
        hideShowForAllOrgs(option);
        $(saveBtn).click();
    }

    /**
     * Method to select hide or show radio buttons
     */
    public void searchProjectToHide(String projectName) {
        commonMethods.waitForElement(driver, txtBoxProjectName, 60);
        commonMethods.enterTextValue(txtBoxProjectName, projectName);
        $(btnSearch).click();
    }

    /**
     * Method to select hide or show radio buttons
     */
    public void hideShowForAllOrgs(String option) {
        List<WebElement> elements = new ArrayList<>($$(By.xpath(tblOrgRows)));
        for(int i = 1; i<=elements.size(); i++) {
            if(option.equalsIgnoreCase("hide"))
                $(By.xpath("(" + tblOrgRows + "/td[4]/input)[" + i + "]")).click();
            else $(By.xpath("(" + tblOrgRows + "/td[3]/input)[" + i + "]")).click();
        }
        commonMethods.waitForElementExplicitly(1000);
    }

    /**
     * Method to verify hide project success message
     */
    public boolean verifyHidePrjtSuccess() {
        commonMethods.waitForElement(driver, txtHidePrjSuccess, 60);
        return $(txtHidePrjSuccess).isDisplayed();
    }
}
