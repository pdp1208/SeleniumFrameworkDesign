package com.oracle.babylon.Utils.helper;


import com.oracle.babylon.Utils.setup.dataStore.DataStore;
import com.oracle.babylon.Utils.setup.dataStore.pojo.Ticket;
import com.oracle.babylon.Utils.setup.utils.ConfigFileReader;
import io.restassured.http.Header;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;

import java.io.IOException;
import java.util.*;


/**
 * Class that contains all the method related to the operations that can be performed in JIRA
 * Author : susgopal
 */
public class JIRAOperations {
    private ConfigFileReader configFileReader = new ConfigFileReader();
    private DataStore dataStore = new DataStore();
    private Ticket ticket = new Ticket();
    private APIHelper apiHelper = new APIHelper();
    String basicAuth = "Basic " + configFileReader.getSSOAuthString();
    public static HttpResponse httpResponse;
    public static JSONObject extractor;

    /**
     * Get the details of the jira ticket
     *
     * @param ticketId id of the ticket
     * @return the response with the details of the ticket
     */
    public synchronized String getJiraTicketDetails(String ticketId) {
        String url = configFileReader.getJiraIssueUrl() + ticketId;
        System.out.println("URL--->" + url);

        Header authHeader = setCookieHeader();
//        Header contentTypeHeader = new Header("Content-Type", configFileReader.getContentType());
        List<Header> headersList = new ArrayList<>();
        headersList.add(authHeader);
       // headersList.add(contentTypeHeader);
        Response response = apiHelper.execRequest(Method.GET, url, headersList,"" );
        return response.getBody().asString();
//        return apiRequest.getRequest(url, basicAuth);

    }

    /**
     * Method to return all the information about the test executions for a issue id
     *
     * @param issueId
     * @return
     */
    public String getTestExecResults(String issueId) {
        String url = configFileReader.getJiraExecutionUrl() + "?issueId=" + issueId;
        Header authHeader = setCookieHeader();
        List<Header> headersList = new ArrayList<>();
        headersList.add(authHeader);
        // headersList.add(contentTypeHeader);
        Response response = apiHelper.execRequest(Method.GET, url, headersList,"" );
        return response.getBody().asString();
        //return apiRequest.getRequest(url, basicAuth);

    }

    /**
     * Method to return the test execution id of a JIRA issue
     *
     * @param issueId
     * @return
     */
    public int returnExecutionId(String issueId) {
         String jsonString = getTestExecResults(issueId);
        extractor = new JSONObject(jsonString);
        JSONArray jsonArray = (JSONArray) extractor.get("executions");
        JSONObject jsonObject = (JSONObject) jsonArray.get(0);
        return Integer.parseInt(jsonObject.get("id").toString());
    }


    /**
     * Function only declared, will write the implementation in the future
     *
     * @param ticketTableName name of the ticket table in the data store
     * @return
     */
    public HttpResponse updateJiraTicket(String ticketTableName) {
        return null;
    }

    /**
     * Method to return the test execution id of a JIRA issue for a specific test execution version
     *
     * @param issueId
     * @param versionName release version for which test will be executed
     * @return
     */
    public int returnExecutionId(String issueId, String versionName) {
        String jsonString = getTestExecResults(issueId);
        extractor = new JSONObject(jsonString);
        JSONArray jsonArray = (JSONArray) extractor.get("executions");
        for (int index = 0; index < jsonArray.length(); index++) {
            JSONObject jsonObject = (JSONObject) jsonArray.get(index);
            if (jsonObject.get("versionName").equals(versionName) && jsonObject.get("cycleName").toString().replace(" ","").equals(versionName + "_" + configFileReader.getTestCycleName())) {
                return Integer.parseInt(jsonObject.get("id").toString());
            }
        }
        return -1;
    }


    /**
     * Updates the result of the test execution
     *
     * @param executionid
     * @param statusId
     * @return
     */
    public Response updateExecutionStatus(int executionid, int statusId) {
        Map<String, Object> updateBody = new Hashtable<String, Object>();
        updateBody.put("status", statusId);
        String requestBody = CommonMethods.convertMaptoJsonString(updateBody);
        String url = configFileReader.getJiraExecutionUrl() + "/" + executionid + "/execute";
        Header authHeader = setCookieHeader();
        Header contentTypeHeader = new Header("Content-Type", configFileReader.getContentType());
        List<Header> headersList = new ArrayList<>();
        headersList.add(authHeader);
        headersList.add(contentTypeHeader);
        return apiHelper.execRequest(Method.PUT, url, headersList, requestBody);
    }

    /**
     * Function to add a comment to a Jira id provided
     * We use the encoded string to protect the password
     *
     * @param ticketId name of the ticket table in the data store
     * @return
     */
    public HttpResponse addComment(String ticketId, String comment) {


        String url = configFileReader.getJiraIssueUrl() + ticketId + "/comment";

        String basicAuth = "Basic " + configFileReader.getSSOAuthString();
        String jsonString = "{ \"body\": " + comment + " }";
        HttpResponse response = apiHelper.postRequest(url, basicAuth, jsonString);
        return response;
    }

    /**
     * Method to convert a http response to json object
     *
     * @param httpResponse
     * @return
     */
    public JSONObject returnJsonObj(HttpResponse httpResponse) {
        try {
            String jsonStr = EntityUtils.toString(httpResponse.getEntity());
            return new JSONObject(jsonStr);
        } catch (IOException e) {
            Assert.fail("IO Exception");
        } catch (NullPointerException e1) {
            throw new NullPointerException(e1.toString());
        }
        return null;
    }

    /**
     * Method to return the status id of pass, fail and other execution states
     *
     * @param issueId
     * @return
     */
    public Map<String, Integer> returnExecutionStatusId(String issueId) {

        String jsonString = getTestExecResults(issueId);
        extractor = new JSONObject(jsonString);
        Map<String, Integer> finalMap = new LinkedHashMap<>();

        System.out.println(extractor.get("status"));
        JSONObject jsonObject = (JSONObject) extractor.get("status");
        JSONObject statusJson;

        for (String key : jsonObject.keySet()) {
            statusJson = (JSONObject) jsonObject.get(key);
            int statusCode = Integer.parseInt(statusJson.get("id").toString());
            finalMap.put(statusJson.get("name").toString(), statusCode);
        }
        return finalMap;
    }

    /**
     * Method to return the issue id of the ticket
     *
     * @param ticketId
     * @return
     */
    public String returnIssueID(String ticketId) {
        String jsonString = getJiraTicketDetails(ticketId);
        extractor = new JSONObject(jsonString);
//        try {
//
//            extractor = returnJsonObj(httpResponse);
//        } catch (NullPointerException e) {
//            extractor = returnJsonObj(httpResponse);
//        }
        String issueId = extractor.get("id").toString();
        return issueId;
    }

    public void updateResult(String jiraId, int statusId) {

        String issueId = returnIssueID(jiraId);
        ConfigFileReader configFileReader = new ConfigFileReader();
        int executionId = returnExecutionId(issueId, configFileReader.getTestVersionNumber());
        updateExecutionStatus(executionId, statusId);
    }

    public static void main(String[] args) {
        JIRAOperations jira = new JIRAOperations();
        jira.updateResult("ACONEXQA-568", 1);
        // jira.addComment("ACONEXQA-568", "TEST COMMENT");
    }


    public String createSession(){
        Map<String, Object> updateBody = new Hashtable<String, Object>();
        updateBody.put("username", configFileReader.getJiraUsername());
        updateBody.put("password", "3U5n)XVM8rXw");
        String requestBody = CommonMethods.convertMaptoJsonString(updateBody);
        //Header authHeader = new Header("Authorization", basicAuth);
        Header contentTypeHeader = new Header("Content-Type", configFileReader.getContentType());
        //Header contentLength = new Header("Content-Length", String.valueOf(requestBody.length()));
        Header appToken = new Header("X-Atlassian-Token", "no-check");
        Header cookie = new Header("os_cookie", "true");
        List<Header> headersList = new ArrayList<>();
        //headersList.add(authHeader);
        headersList.add(contentTypeHeader);
        headersList.add(appToken);
        headersList.add(cookie);
        Response response = apiHelper.execRequest(Method.POST, configFileReader.getJiraSessionUrl(), headersList, requestBody);
        JsonPath jp = new JsonPath( response.asString() );
        return jp.getString( "session.value" );
    }

    public Header setCookieHeader(){
        String sessionStr = "JSESSIONID=" + ZephyrStatusSingleton.returnSessionId();
        return new Header("Cookie", sessionStr);
    }

}
