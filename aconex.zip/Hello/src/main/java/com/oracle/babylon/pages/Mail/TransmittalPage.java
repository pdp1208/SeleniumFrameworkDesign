package com.oracle.babylon.pages.Mail;

public class TransmittalPage extends MailPage {


    /**
     * Function to navigate to a sub menu from the Aconex home page
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Mail", "Transmittal");
        verifyPageTitle("Transmittal");
    }
}
