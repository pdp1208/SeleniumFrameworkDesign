package com.oracle.babylon.pages.Setup;

import com.oracle.babylon.Utils.helper.Navigator;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import static com.codeborne.selenide.Selenide.$;


/**
 * Author : sushanth
 * Account Details Page under Setup
 * Used for displaying account information and perform operations on it
 */
public class AccountDetailsPage extends Navigator {


    /**
     * Identifiers for all the HTML attributes in the page
     */
    By divisionSelect = By.xpath("//select[@name='division']");
    /**
     * Method to navigate to the page in the ui
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Setup", "Account Details");
        commonMethods.waitForElementExplicitly(5000);
        verifyAndSwitchFrame();
    }

    /**
     * Method to associate user to division
     * @param division
     */
    public void associateDivision(String division){
        Select divisionElement = new Select($(divisionSelect));
        $(divisionSelect).click();
        divisionElement.selectByVisibleText(division);
        $(saveBtn).click();
    }
}
