package com.oracle.babylon.pages.Fields;

import static com.codeborne.selenide.Condition.appears;
import static com.codeborne.selenide.Condition.disappears;

import com.oracle.babylon.Utils.helper.Navigator;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;

import static com.codeborne.selenide.Condition.hidden;
import static com.codeborne.selenide.Selenide.$;

public class TemplateSettingPage extends Navigator {

    private By addTemplate = By.xpath("//button[contains(@class, 'new-template auiButton primary' )]");
    private By checklist = By.xpath("//li[contains(@class,'new-template-list-item') and text()='Checklist']");
    private By titleInput = By.xpath("//input[contains(@class,'title-input')]");
    private By questionInput = By.xpath("//textarea[contains(@id,'add-more-items')]");
    private By typeDropDown = By.xpath("//div[contains(@class,'item-type')]");
    private By add = By.xpath("//button[contains(@class,'add-item')]");
    private By publish = By.xpath("//button[text()='Publish']");
    private By successMessage = By.xpath("//*[text()='Checklist template has been saved successfully.']");
    private By descriptionInput = By.xpath("//textarea[contains(@class,'description')]");
    private By loader = By.xpath("//div[@class='uiLoadingBlocker']");
    private By close = By.xpath("//div[@class='cross']");
    private String configListItemDialogLocator = "//*[@class='checklist-multi-list-options-modal']//div[contains(@class,'auiModal-content')]";
    private  By templates = By.xpath("//h2[text()='Inspections']/parent::div//a[text()='Templates']");

    /**
     * Method to Inspection Template page.
     *
     */
    public void navigateAndVerifyPage(){
        $(templates).click();
        waitForLoaderToDisapper();
        $(close).click();
    }

    /**
     * Method to add checklist Inspection Template.
     *
     * @param title Title of the template.
     * @param question question.
     * @param type type od the template.
     * @param description description of the template.
     */
    public void addCheckListTemplate(String title, String question, String type, String description){
        String listItems[] = {"High", "Medium", "Low"};
        $(addTemplate).waitUntil(appears,6000).click();
        $(checklist).waitUntil(appears, 3000).click();
        $(titleInput).setValue(title);
        $(descriptionInput).setValue(description);
        $(descriptionInput).setValue(description);
        $(questionInput).setValue(question);
        $(typeDropDown).click();
        type = type.replaceAll("#","|");
        $(By.xpath("//li/strong[text()='" + type + "']")).click();
        $(add).click();
        if(type.equalsIgnoreCase("Select list")){
            for(String item : listItems){
                $(By.xpath(configListItemDialogLocator + "//textarea[contains(@class,'form-control')]")).setValue(item);
                commonMethods.waitForElementExplicitly(2000);
                $(By.xpath(configListItemDialogLocator + "//button[@type='submit']")).click();
                $(By.xpath("//div[contains(@class,'item-list')]//td[text()='" + item + "']")).waitUntil(appears,3000);
            }
            $(By.xpath(configListItemDialogLocator + "//button[contains(@class,'primary')]")).click();
        }
        $(publish).click();
        $(successMessage).waitUntil(appears, 10000);
        $(successMessage).waitUntil(disappears, 10000);
    }

    /**
     * Method to until loader disappers.
     *
     */
    public void waitForLoaderToDisapper(){
        try {
            commonMethods.waitForElement(driver, loader, 10);
            $(loader).waitUntil(hidden, 25000);
        } catch(TimeoutException | NoSuchElementException e){
            //ignore
        }
    }
}
