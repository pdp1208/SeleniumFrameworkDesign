package com.oracle.babylon.pages.Document;

import com.codeborne.selenide.WebDriverRunner;
import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.util.List;

import static com.codeborne.selenide.Selenide.$;

public class BulkProcessingPage extends Navigator {

    //Initialization of Web Elements
    private By newBulkProcessing = By.xpath("//div[text()='New Bulk Process']");
    private By documentsMenu = By.xpath("//button[@class='uiButton navBarButton']//div[text()='Documents']");
    private By bulkProcessingSubMenu = By.xpath("//div[@class='navBarPanel-menuItem' and text()='Bulk Processing' ]");
    private By metadataFile = By.xpath("//span[text()='Please select or upload your metadata file']//../../../../../..//div");
    private By localComputerBtn = By.xpath("//div[contains(text(),'Local Computer/Network')]");
    private By chooseFile = By.xpath("//input[@type='file']");
    private By attachBtn = By.xpath("//div[contains(text(),'Attach')]");
    private By attachPanelOkBtn = By.xpath("//button[@id='btnbulkProcessing_afc_localFileAttachPanel_ok']//div[text()='OK']");
    private By errorMsgPanel = By.xpath("//ul[@class='messagePanel']");
    private By validationErrorMsg = By.xpath("//div[contains(text(),'Could not access')]");
    private By uploadBtn = By.xpath("//div[@class='uiButton-label' and text()='Upload']");
    private By pageTitle = By.xpath("//h1[contains(text(),'Search - Bulk Processing Jobs')]");
    private By createdDesc = By.xpath("//table[@id='resultTable']//div[@class='sortDESC']");
    private By draftTab = By.xpath("//li[text()='Drafts']");
    private By showOnlyMyJobs = By.xpath("//input[@id='showingUserOnly']");
    private By tableRows = By.xpath("//table[@id='resultTable']//tbody//tr");
    private By JobPage = By.xpath("//h1[contains(text(),'View Bulk Processing Job')]");
    private By EditPage = By.xpath("//h1[contains(text(),'Edit Bulk Processing Job')]");
    private By btnUpload = By.xpath("//div[text()='Upload']");
    private By superSearchTextBox = By.xpath("//input[@name='rawQuery']");
    private By logFile = By.xpath("//a[contains(text(),'BulkImport')]");
    private By searchBtn = By.xpath("//div[@class='uiButton-label' and text()='Search']");
    private By testBtn = By.xpath("//div[@class='uiButton-label' and text()='Test']");
    private By refreshBtn = By.xpath("//button[@id='btnRefresh']");
    private By saveBtn = By.xpath("//div[text()='Save']");
    private By runBtn = By.xpath("//div[text()='Run']");
    private By clearBtn = By.xpath("//div[@class='uiButton-label' and text()='Clear']");
    private By noResults = By.xpath("//div[@id='loadingMessage' and contains(text(),'No results')]");
    private By clearBtnTxt = By.xpath("//div[contains(text(),'Enter your search criteria above')]");

    private By fromDate = By.xpath("//input[@id='dateRunFrom_da']");
    private By toDate = By.xpath("//input[@id='dateRunTo_da']");

    private By fromCreatedDate = By.xpath("//input[@id='dateCreatedFrom_da']");
    private By toCreatedDate = By.xpath("//input[@id='dateCreatedTo_da']");

    private By selectSortBy = By.xpath("//select[@id='jobSortField']");
    private By draftSortBy = By.xpath("//select[@id='drafSortField']");
    private By checkboxMyJobsOnly = By.xpath("//input[@id='showingUserOnly']");

    private By bulkProcessTitle = By.xpath("//input[@name='importTitle']");
    private By selectStatus = By.xpath("//select[@id='importStatus_jobs']");
    private By selectType = By.xpath("//select[@id='importTypeId']");
    private By tabDrafts = By.xpath("//li[@id='1_list']");
    private By showOrHideSearchFields = By.xpath("//img[@id='toggleModeIcon']");

    //New Bulk processing Job
    private By matadataTemplate = By.xpath("//div[@class='uiButton-label' and text()='Metadata Template ']");
    private By copyBtn = By.xpath("//div[@class='uiButton-label' and text()='Copy']");
    private By backBtn = By.xpath("//button[@id='btnBack']");

    private By localOrComputer = By.xpath("//div[@class='uiButton-label' and text()='Local Computer/Network']");
    private By temporaryFiles = By.xpath("//div[@class='uiButton-label' and text()='Temporary Files']");
    private By attachFileCancelBtn = By.xpath("//button[@id='btnchooseManifestSource_cancel']");
    private By metaDataTemplate = By.xpath("//div[contains(text(),'Metadata Template')]");
    private By deleteMetaDataFile = By.xpath("//img[@title='Remove']");
    private By invalidFile = By.xpath("//span[text()='Invalid file']");
    private By selectFirstFile = By.xpath("//div[@class='ag-pinned-left-cols-container']//div[1]//span");
    private By attachFile = By.xpath("//div[contains(text(),'Attach File')]");
    private By closeBtn = By.xpath("//button[@id='btnbulkProcessing_ok']//div[text()='Close']");
    private TemporaryFilesPage temporaryFilesPage = new TemporaryFilesPage();
    private DocumentPage documentPage = new DocumentPage();

    public BulkProcessingPage() {
        this.driver = WebDriverRunner.getWebDriver();
    }

    /**
     * Method to navigate to Document and verify for the title of the page
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Documents", "Bulk Processing");
        commonMethods.waitForElementExplicitly(3000);
        Assert.assertTrue(verifyPageTitle(pageTitle));
    }

    /**
     * Method to navigate to Document and verify for the title of the page
     */
    public void navigateAndVerifyPage(String instance) {
        getMenuSubmenu(instance, "Bulk Processing");
        commonMethods.waitForElementExplicitly(3000);
        Assert.assertTrue(verifyPageTitle(pageTitle));
    }

    /**
     * Function to click om New Bulk processing
     */
    public void clickNewBulkProcessing() {
        verifyAndSwitchFrame();
        $(newBulkProcessing).click();
    }

    /**
     * click on Test Button
     */
    public void clickTest() {
        verifyAndSwitchFrame();
        $(testBtn).click();
    }

    /**
     * click on Run Button
     */
    public void clickRun() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, runBtn, 40);
        $(runBtn).click();
    }

    /**
     * Click on Refresh Button
     */
    public void clickRefresh() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, refreshBtn, 40);
        $(refreshBtn).click();
    }

    /**
     * Click on Drafts
     */
    public void clickDraft() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, draftTab, 40);
        $(draftTab).click();

    }

    /**
     * Function to verify text fields
     *
     * @param button
     * @return
     */
    public boolean verifyButtonFields(String button) {
        verifyAndSwitchFrame();
        return $(By.xpath("//div[@class='uiButton-label' and text()='" + button + "']")).isDisplayed();
    }

    /**
     * Function to verify Text Fields
     *
     * @param text
     * @return
     */
    public boolean verifyTextFields(String text) {
        verifyAndSwitchFrame();
        return $(By.xpath("//input[@name='" + text + "']")).isDisplayed();
    }

    /**
     * Function to verify Dropdown fields
     *
     * @param name
     * @return
     */
    public boolean verifyDropDownFields(String name) {
        verifyAndSwitchFrame();
        return $(By.xpath("//select[@name='" + name + "']")).isDisplayed();
    }

    /**
     * Function to verify permission error Msg
     *
     * @return
     */
    public boolean verifyPermissionErrorMsg() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, errorMsgPanel);
        return $(errorMsgPanel).isDisplayed();
    }

    /**
     * Function to upload Meta data file
     *
     * @param fileName
     */
    public void uploadMetaDataFile(String fileName, String uploadType) {
        verifyAndSwitchFrame();
        $(metadataFile).click();
        if (uploadType.equalsIgnoreCase("local")) {
            $(localComputerBtn).click();
            String path = configFileReader.getTemplateDataPath() + fileName;
            File file = new File(path);
            path = file.getAbsolutePath();
            $(chooseFile).sendKeys(path);
            $(attachBtn).click();
        } else {
            $(temporaryFiles).click();
            verifyAndSwitchFrame();
            documentPage.searchDocumentNo(fileName);
            $(selectFirstFile).click();
            $(attachFile).click();
        }

    }

    /**
     * Function to upload Meta data file from Panel
     *
     * @param fileName
     */
    public void uploadMetaDataFileOnPanel(String fileName, String uploadType) {
        commonMethods.waitForElement(driver, metadataFile);
        $(metadataFile).click();
        if (uploadType.equalsIgnoreCase("local")) {
            $(localComputerBtn).click();
            File file = new File(configFileReader.getTemplateDataPath() + fileName);
            $(chooseFile).sendKeys(file.getAbsolutePath());
            clickAttachOkButton();
        } else {
            $(temporaryFiles).click();
            verifyAndSwitchFrame();
            documentPage.searchDocumentNo(fileName);
            $(selectFirstFile).click();
            clickAttachOkButton();
        }

    }

    /**
     * Functin to search Title
     *
     * @param title
     */
    public void searchTitle(String title) {
        verifyAndSwitchFrame();
        $(bulkProcessTitle).clear();
        $(bulkProcessTitle).sendKeys(title);
        $(searchBtn).click();
    }

    /**
     * Function to verify title search results
     *
     * @param title
     * @return
     */
    public boolean verifyTitleSearch(String title) {
        searchTitle(title);
        checkDescending();
        commonMethods.waitForElementExplicitly(2000);
        return $(By.xpath("//table[@id='resultTable']//tbody//td//a[text()='" + title + "']")).isDisplayed();
    }

    /**
     * Function to verify No search results for title
     *
     * @param title
     * @return
     */
    public boolean verifyNoTitleResults(String title) {
        searchTitle(title);
        return verifyNoResults();
    }

    /**
     * Function to verify status search
     *
     * @param status
     * @return
     */
    public boolean verifyStatusSearch(String status) {
        selectStatus(status);
        commonMethods.waitForElementExplicitly(2000);
        return $(By.xpath("//table[@id='resultTable']//tbody//tr[1]//td[text()='" + status + "']")).isDisplayed();
    }

    /**
     * Function to verify no results for status
     *
     * @param status
     * @return
     */
    public boolean verifyNoStatusResults(String status) {
        selectStatus(status);
        return verifyNoResults();
    }

    /**
     * Function to select status
     *
     * @param status
     */
    public void selectStatus(String status) {
        verifyAndSwitchFrame();
        $(selectStatus).selectOption(status);
        $(searchBtn).click();
    }

    /**
     * Function to create New Bulk processing
     *
     * @param fileName
     * @param title
     * @param action
     */
    public void createBulkProcessing(String fileName, String title, String action) {
        clickNewBulkProcessing();
        $(bulkProcessTitle).clear();
        $(bulkProcessTitle).sendKeys(title);
        uploadMetaDataFile(fileName, "local");
        if (action.equalsIgnoreCase("Run")) {
            $(runBtn).click();
            verifyPageTitle(JobPage);
        }else if (action.equalsIgnoreCase("Test")){
            $(testBtn).click();
            verifyPageTitle(JobPage);
        }
        else {
            $(saveBtn).click();
            verifyPageTitle(EditPage);
        }


    }

    /**
     * Function to verify run date search
     *
     * @param from
     * @param to
     * @return
     */
    public boolean verifyRunDateSearch(String from, String to) {
        selectDateRun(from, to);
        checkDescending();
        String today = commonMethods.getDate(configFileReader.getTimeZone(), to);
        commonMethods.waitForElementExplicitly(2000);
        return $(By.xpath("//table[@id='resultTable']//tbody//tr[1]//td[3][contains(text(),'" + today + "')]")).isDisplayed();
    }

    /**
     * Function to verify no results for Run date
     *
     * @param from
     * @param to
     * @return
     */
    public boolean verifyNoRunDateResults(String from, String to) {
        verifyAndSwitchFrame();
        selectDateRun(from, to);
        return verifyNoResults();
    }

    /**
     * Function to select Run date
     *
     * @param from
     * @param to
     */
    public void selectDateRun(String from, String to) {
        verifyAndSwitchFrame();
        $(fromDate).clear();
        $(toDate).clear();
        $(fromDate).sendKeys(commonMethods.getDate(configFileReader.getTimeZone(), from));
        $(toDate).sendKeys(commonMethods.getDate(configFileReader.getTimeZone(), to));
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, searchBtn, 5);
        $(searchBtn).click();
    }

    /**
     * Function to verify clear button functionality
     *
     * @return
     */
    public boolean verifyClearButton() {
        verifyAndSwitchFrame();
        $(clearBtn).click();
        commonMethods.waitForElement(driver, clearBtn);
        return $(clearBtnTxt).isDisplayed();
    }

    /**
     * Function to verify created date
     *
     * @param from
     * @param to
     * @return
     */
    public boolean verifyDateCreated(String from, String to) {
        selectCreatedDate(from, to);
        String today = commonMethods.getDate(configFileReader.getTimeZone(), to);
        commonMethods.waitForElementExplicitly(2000);
        return $(By.xpath("//table[@id='resultTable']//tbody//tr[1]//td[3][contains(text(),'" + today + "')]")).isDisplayed();
    }

    /**
     * Function to verify no results for created date
     *
     * @param from
     * @param to
     * @return
     */
    public boolean verifyNoCreatedDateResults(String from, String to) {
        selectCreatedDate(from, to);
        return verifyNoResults();
    }

    /**
     * Function to select created date
     *
     * @param from
     * @param to
     */
    public void selectCreatedDate(String from, String to) {
        verifyAndSwitchFrame();
        $(fromCreatedDate).clear();
        $(toCreatedDate).clear();
        $(fromCreatedDate).sendKeys(commonMethods.getDate(configFileReader.getTimeZone(), from));
        $(toCreatedDate).sendKeys(commonMethods.getDate(configFileReader.getTimeZone(), to));
        commonMethods.waitForElementExplicitly(2000);
        $(searchBtn).click();
    }

    /**
     * verify No results
     *
     * @return
     */
    public boolean verifyNoResults() {
        commonMethods.waitForElementExplicitly(2000);
        return $(noResults).isDisplayed();
    }

    /**
     * Function select value from filters
     *
     * @param filter
     * @param value
     */
    public void sendValueToFilter(String filter, String value) {
        verifyAndSwitchFrame();
        switch (filter) {
            case "Title":
                searchTitle(value);
                break;
            case "Status":
                selectStatus(value);
                break;
            case "Date Run":
                selectDateRun(value, value);
                break;
        }
    }

    /**
     * Function to send values to Sort
     *
     * @param tab
     * @param value
     */
    public void sendValueToSort(String tab, String value) {
        verifyAndSwitchFrame();
        switch (value) {
            case "Title":
                selectSortValue(tab, value);
                break;
            case "Date Created":
                selectSortValue(tab, value);
                break;
            case "Date Run":
                selectSortValue(tab, value);
                break;
        }
    }

    /**
     * Function to select value from sort By
     *
     * @param tab
     * @param value
     */
    public void selectSortValue(String tab, String value) {
        verifyAndSwitchFrame();
        if (tab.equalsIgnoreCase("drafts")) {
            $(draftSortBy).selectOption(value);
        } else {
            $(selectSortBy).selectOption(value);
        }
        $(searchBtn).click();
    }

    public boolean verifyResultValues(String column, String value) {
        String date = null;
        verifyAndSwitchFrame();
        switch (column) {
            case "Title":
                commonMethods.waitForElementExplicitly(2000);
                return $(By.xpath("//table[@id='resultTable']//tbody//td//a[text()='" + value + "']")).isDisplayed();
            case "Status":
                checkDescending();
                commonMethods.waitForElementExplicitly(2000);
                return $(By.xpath("//table[@id='resultTable']//tbody//tr[1]//td[text()='" + value + "']")).isDisplayed();
            case "Date Run":
            case "Date Created":
                checkDescending();
                date = commonMethods.getDate(configFileReader.getTimeZone(), value);
                commonMethods.waitForElementExplicitly(2000);
                return $(By.xpath("//table[@id='resultTable']//tbody//tr[1]//td[3][contains(text(),'" + date + "')]")).isDisplayed();
        }
        return false;
    }

    /**
     * click on Descending order
     */
    public void checkDescending() {
        verifyAndSwitchFrame();
        if ($(createdDesc).isDisplayed()) {
            $(createdDesc).click();
        }
    }

    /**
     * Function to verify show only my process
     *
     * @return
     */
    public void clickShowMyProcess() {
        verifyAndSwitchFrame();
        if (!$(showOnlyMyJobs).isSelected()) {
            $(showOnlyMyJobs).click();
        }
        $(searchBtn).click();
    }

    /**
     * Function to delete created Bulk process
     *
     * @param processName
     */
    public void deleteBulkProcess(String processName) {
        verifyAndSwitchFrame();
        searchTitle(processName);
        if (!verifyNoResults()) ;
        {
            List<WebElement> rows = driver.findElements(tableRows);
            for (int i = 0; i <= rows.size(); i++) {
                commonMethods.waitForElementExplicitly(2000);
                if ($(By.xpath("//a[text()='" + processName + "']//../..//img[@title='Remove']")).isDisplayed()) {
                    $(By.xpath("//a[text()='" + processName + "']//../..//img[@title='Remove']")).click();
                }
            }
        }
    }

    /**
     * Function to find number of rows in table based on table Id
     *
     * @param tableId
     * @return
     */
    public int findNumberOfRows(String tableId) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        List<WebElement> rowsCount = driver.findElements(By.xpath("//table[@id='" + tableId + "']//tbody//tr"));
        return rowsCount.size() - 1;
    }

    /**
     * Function to Verify result table
     *
     * @return
     */
    public int verifyResultTable() {
        verifyAndSwitchFrame();
        $(clearBtn).click();
        $(searchBtn).click();
        return findNumberOfRows("resultTable");
    }

    /**
     * Function to verify records per page
     *
     * @param size
     * @return
     */
    public int verifyRecordsPerPage(String size) {
        verifyAndSwitchFrame();
        selectPageSize(size);
        return findNumberOfRows("resultTable");

    }

    /**
     * Function to verify Uploaded mata data file
     *
     * @param fileName
     * @return
     */
    public boolean verifyMetaDataFile(String fileName) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        return $(By.xpath("//a[contains(text(),'" + fileName + "')]")).isDisplayed();
    }

    /**
     * Function to Delete Meta data file
     */
    public void deleteMetaDataFile() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        $(deleteMetaDataFile).click();
    }

    /**
     * Method to verify Invalid File Error Message
     *
     * @return
     */
    public boolean verifyFile() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, invalidFile, 5);
        return $(invalidFile).isDisplayed();
    }

    /**
     * Method to verify Bulk processing status
     *
     * @param status
     * @return
     */
    public boolean verifyStatus(String status, String statusTwo) {
        verifyAndSwitchFrame();
        if ($(By.xpath("//td[contains(text(),'" + status + "')]")).isDisplayed() || $(By.xpath("//td[contains(text(),'" + statusTwo + "')]")).isDisplayed()) {
            return true;
        }
        return false;

    }

    /**
     * Method to verify Log file
     *
     * @return
     */
    public boolean verifyLogFile() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, logFile);
        $(logFile).click();
        return $(logFile).isDisplayed();
    }

    /**
     * Method to click on close button
     */
    public void clickCloseBtn() {
        commonMethods.waitForElement(driver, closeBtn);
        $(closeBtn).click();
    }

    /**
     * Method to click on ok button on the attach screen
     */
    public void clickAttachOkButton() {
        commonMethods.waitForElement(driver, attachPanelOkBtn);
        $(attachPanelOkBtn).click();
    }

    /**
     * Method to click on upload button
     */
    public void clickUpload() {
        commonMethods.waitForElement(driver, btnUpload);
        $(btnUpload).click();
    }

    /**
     * Method to enter the title in the text box
     */
    public void enterBulkProcessTitle(String title) {
        commonMethods.enterTextValue(bulkProcessTitle,title);
    }
}
