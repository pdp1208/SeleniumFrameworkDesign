package com.oracle.babylon.pages.Project;

import com.codeborne.selenide.WebDriverRunner;
import com.oracle.babylon.Utils.helper.Navigator;
import com.oracle.babylon.Utils.setup.dataStore.pojo.Project;
import com.oracle.babylon.Utils.setup.dataStore.pojo.User;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.clearBrowserCookies;

/**
 * Class to perform some operations on the Project page
 */
public class CreateProjectPage extends Navigator {

    //Initialization of web elements
    private By projectNameTxtBox = By.name("ProjectName");
    private By projectShortNameTxtBox = By.name("ProjectShortName");
    private By projectCodeTxtBox = By.name("ProjectCode");
    private By projectTypeTxtBox = By.name("ProjectType");
    private By primaryRegisterTypeDrpDwn = By.name("RegisterType");
    private By defaultAccessLevel = By.name("defaultAccessLevel");
    private By addressTxtBox = By.name("ProjectAddress1");
    private By cityTxtBox = By.name("ProjectSuburb");
    private By countyTxtBox = By.name("ProjectState");
    private By postCodeTxtBox = By.name("ProjectPostcode");
    private By countryDrpDwn = By.name("ProjectCountry");
    private By projectStartDateTxtBox = By.xpath("//div//input[@name='ProjectStartDate_da']");
    private By estimatedCompletionDateTxtBox = By.xpath("//div//input[@name='ProjectStopDate_da']");
    private By projectValueTxtBox = By.name("ProjectValue");
    private By projectDescriptionTxtArea = By.name("ProjectDescription");
    private By saveBtn = By.id("btnSave");
    private By errorMessage = By.xpath("//div[text()='Please complete the highlighted mandatory fields before saving']");
    private By docTypeChange = By.xpath("//button[@id='btnconfirmRegisterTypeChange_panel_ok']");
    private By termsOfService = By.id("acceptTermsOfService");
    private By submitBtn = By.id("btnSubmit");

    public void navigateToPage() {
        getMenuSubmenu("Setup", "Create Project");
    }

    /**
     * Method to fill up the project fields in the ui
     */
    public void fillUpProjectFields(Project project) {
        commonMethods.waitForElementExplicitly(5000);
        commonMethods.switchToFrame(WebDriverRunner.getWebDriver(), "frameMain");
        if($(termsOfService).isDisplayed()){
            $(termsOfService).setSelected(true);
        }
        commonMethods.waitForElement(driver, projectNameTxtBox, 15);
        $(projectNameTxtBox).sendKeys(project.getProjectName());
        $(projectShortNameTxtBox).sendKeys(project.getProjectShortName());
        $(projectCodeTxtBox).sendKeys(project.getProjectCode());
        $(projectTypeTxtBox).sendKeys(project.getProjectType());
        Select select = new Select($(primaryRegisterTypeDrpDwn));
        select.selectByValue(project.getPrimaryRegisterType().toUpperCase());
        commonMethods.waitForElementExplicitly(2000);
        if ($(docTypeChange).isDisplayed()) {
            $(docTypeChange).click();
        }
        select = new Select($(defaultAccessLevel));
        select.selectByValue(project.getDefaultAccessLevel().toUpperCase());
        $(addressTxtBox).sendKeys(project.getProjectAddress());
        $(cityTxtBox).sendKeys(project.getCity());
        $(countyTxtBox).sendKeys(project.getCounty());
        select = new Select($(countryDrpDwn));
        select.selectByValue(project.getCountry());
        $(projectStartDateTxtBox).sendKeys(project.getProjectStartDate());
        $(estimatedCompletionDateTxtBox).sendKeys(project.getEstimatedCompletionDate());
        $(projectValueTxtBox).clear();
        $(projectValueTxtBox).sendKeys(project.getProjectValue());
        $(projectDescriptionTxtArea).sendKeys(project.getProjectDescription());
        $(saveBtn).click();
    }

    /**
     * Store the details of a project in the json data file for future references
     */
    public void enterProjectDetailsToFile(String userId, String projectNumber, User user) {
        Map<String, Map<String, Object>> mapOfMap = new Hashtable<>();
        int number = Integer.parseInt(projectNumber.substring(projectNumber.length() - 1));
        HashMap<String, String> docMap = commonMethods.getDocumentTypeDetail(projectNumber);
        String projectId = docMap.get("projectid") + number;
        String projectName = docMap.get("projectname") + number;
        String[] keys = {projectId, projectName};
        Map<String, Object> valueMap = new Hashtable<>();
        valueMap.put(keys[0], user.getProjectId());
        valueMap.put(keys[1], user.getProjectName());
        mapOfMap.put(userId, valueMap);
        dataSetup.fileWrite(userId, mapOfMap, userDataPath);
    }
}
