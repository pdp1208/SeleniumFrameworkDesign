package com.oracle.babylon.Utils.helper;


import com.oracle.babylon.Utils.setup.dataStore.MailTableConverter;
import com.oracle.babylon.Utils.setup.dataStore.pojo.Mail;
import com.oracle.babylon.Utils.setup.utils.ConfigFileReader;
import io.cucumber.datatable.DataTable;
import io.restassured.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;
import org.junit.Assert;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class MailsAPI extends APIHelper {

    ConfigFileReader configFileReader = new ConfigFileReader();
    protected Map<String, Map<String, Object>> jsonMapOfMap = null;
    protected Map<String, Object> userMap = null;
    protected String userDataPath = configFileReader.getUserDataPath();
    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    SchemaHelperPage schemaHelperPage = new SchemaHelperPage();
    DirectoryAPI directoryAPI = new DirectoryAPI();

    /**
     * Method to upload/register a document through api using httpclient library
     * Document will show up in Document register
     *
     * @param userId    for authentication
     * @param dataTable request body data
     * @param projectId required in the url
     */
    public Map<String, String> createMail(String userId, DataTable dataTable, String projectId) {
        HttpResponse response;
        String responseString = "", mailId;
        Map<String, String> mailNumbers = new LinkedHashMap<>();
        //The data is taken from userData.json file and we search for the project in admin tool
        Map<String, Mail> mailData = new MailTableConverter().createMailData(userId, dataTable, projectId);
        String basicAuth = basicAuthCredentialsProvider(userId);

        Iterator<Map.Entry<String, Mail>> mailDatawithName = mailData.entrySet().iterator();
        for (int i = 0; i < mailData.size(); i++) {
            Map.Entry<String, Mail> entry = mailDatawithName.next();
            Mail mail = entry.getValue();
            mail = setMandatoryFields(mail, userId, projectId);

            //getting project fields data
            Map<String, String> additionalFields = addAdditionalMailFields(dataTable, i, projectId);

            //Creating the request body template
            StringBuilder mailRequestBody = new StringBuilder(CommonMethods.convertMaptoJsonString(mail));

            mailRequestBody.insert(mailRequestBody.length() - 1, getRecipients(dataTable, i));

            String attachment = getAttachment(dataTable, i);
            if (!additionalFields.isEmpty())
                mailRequestBody.insert(mailRequestBody.length() - 1, "," + CommonMethods.convertMaptoJsonString(additionalFields).replace("{", "").replace("}", ""));

            //Updating the request body according to the required template
            mailRequestBody.insert(0, "{ \"mail\":");
            mailRequestBody.append("}");
            String requestBodyXML;
            if (attachment.split(",")[1].equalsIgnoreCase("document"))
                requestBodyXML = "--myboundary\n\n" + commonMethods.convertJsonStringToXMLString(mailRequestBody.toString()) + "\n--myboundary\n"
                        + "\nX-DocumentId: " + commonMethods.returnDocNumberInJson(attachment.split(",")[0], "doc_id")
                        + "\n\n--myboundary--";
            else if (attachment.split(",")[1].equalsIgnoreCase("mail"))
                requestBodyXML = "--myboundary\n\n" + commonMethods.convertJsonStringToXMLString(mailRequestBody.toString()) + "\n--myboundary\n"
                        + "\nX-MailId: " + commonMethods.getMailNumFromJson(attachment.split(",")[0], "mail_id")
                        + "\n\n--myboundary--";
            else if (attachment.split(",")[1].equalsIgnoreCase("local"))
                requestBodyXML = "--myboundary\n\n" + commonMethods.convertJsonStringToXMLString(mailRequestBody.toString()) + "\n--myboundary\n"
                        + "\nX-Filename: " + attachment.split(",")[0]
                        + "\n\n" + commonMethods.getEncodedBase64(attachment.split(",")[0])
                        + "\n\n--myboundary--";
            else
                requestBodyXML = "--myboundary\n\n" + commonMethods.convertJsonStringToXMLString(mailRequestBody.toString()) + "\n--myboundary";

            requestBodyXML = capitalizeXMLTags(requestBodyXML, "<");

            requestBodyXML = capitalizeXMLTags(requestBodyXML, "</");

            //Forming the url
            String url = ConfigFileReader.getApplicationUrl() + "api/projects/" + projectId + "/mail";
            response = postRequest(url, basicAuth, "multipart/mixed; boundary=\"myboundary\"", requestBodyXML);
            try {
                HttpEntity entity = response.getEntity();
                responseString = EntityUtils.toString(entity);
                // Read the contents of an entity and return it as a String. Needed for debugging
                System.out.println(responseString);
            } catch (
                    Exception e) {
                System.out.println("Coming inside");
                try {
                    response = postRequest(url, basicAuth, "multipart/mixed; boundary=\"myboundary\"", requestBodyXML);
                    HttpEntity entity1 = response.getEntity();
                    responseString = EntityUtils.toString(entity1);
                    System.out.println(responseString);
                } catch (Exception e1) {
                    System.out.println(response.getEntity());
                }
            }
            Assert.assertEquals(200, response.getStatusLine().getStatusCode());
            if (response.getStatusLine().getStatusCode() == 200) {
                mailId = schemaHelperPage.getValueFromResponse(responseString, "SendMailResult", "NewMailId");
                mailNumbers.put(mail.getMailNumber(), mailId);
            }
        }
        return mailNumbers;
    }

    /**
     * Method to set the mandatory fields for mail API by retieving it from mail Schema
     *
     * @param mail      mail fields object
     * @param userId    generate auth credentials
     * @param projectId projectid to retieve the schema
     */
    public Mail setMandatoryFields(Mail mail, String userId, String projectId) {
        String responseString = getMailSchema(userId, projectId);
        List<String> mandatoryList;
        commonMethods.waitForElementExplicitly(300);
        SchemaHelperPage schemaHelper = new SchemaHelperPage();
        mandatoryList = schemaHelper.retrieveValuesFromSchema(responseString, "MailTypeId", "Id", mail.getMailTypeId());
        mail.setMailTypeId(mandatoryList.get(0));

        return mail;
    }

    /**
     * Method to get additional document project field values
     */
    public Map<String, String> addAdditionalMailFields(DataTable dataTable, int counter, String projectId) {
        String name, value;
        Map<String, String> additionalData = new HashMap<>();
        List<Map<String, String>> documentData = dataTable.asMaps(String.class, String.class);
        List<String> headers = new ArrayList<>(documentData.get(counter).keySet());
        List<String> values;
        for (String header : headers)
            if (header.startsWith("label_") && !documentData.get(counter).get(header).isEmpty()) {
                name = getFieldName(header, documentData.get(counter).get(header));
                if (documentData.get(counter).get(header).startsWith("user")) {
                    values = directoryAPI.searchProjectDirectory(documentData.get(counter).get(header), projectId);
                    value = values.get(0);
                } else if (documentData.get(counter).get(header).equalsIgnoreCase("yesterday") || documentData.get(counter).get(header).equalsIgnoreCase("today") || documentData.get(counter).get(header).equalsIgnoreCase("tomorrow"))
                    value = dateFormat.format(commonMethods.getDate(documentData.get(counter).get(header)));
                else value = documentData.get(counter).get(header);
                additionalData.put(name, value);
            }
        return additionalData;
    }

    /**
     * Method to get project field names for api
     */
    public String getFieldName(String header, String value) {
        switch (commonMethods.getLabelType(header)) {
            case "Select List (Single)":
                return commonMethods.getLabelName(header) + "_singleSelect";
            case "Text":
                return commonMethods.getLabelName(header) + "_singleLineText";
            case "Text Area":
                return commonMethods.getLabelName(header) + "_multiLineText";
            case "Date":
                return commonMethods.getLabelName(header) + "_date";
            case "Yes/No":
                return commonMethods.getLabelName(header) + "_boolean";
            case "Number":
                if (commonMethods.getUnitValue(header).equalsIgnoreCase("celsius") || commonMethods.getUnitValue(header).equalsIgnoreCase("Fahrenheit"))
                    return commonMethods.getLabelName(header) + "_number_temperature_" + commonMethods.getUnitValue(header);
            case "Select List (Multiple)":
                if (value.startsWith("user")) return commonMethods.getLabelName(header) + "_user";
                else return commonMethods.getLabelName(header) + "_multiSelect";
        }
        return "";
    }

    /**
     * Method to retrieve the document schema through an api call
     */
    public String getMailSchema(String userId, String projectId) {
        HttpResponse response;
        String xmlResponse, basicAuth;
        int counter = 0;
        basicAuth = basicAuthCredentialsProvider(userId);
        String url = ConfigFileReader.getApplicationUrl() + "api/projects/" + projectId + "/mail/schema/creation";
        System.out.println("Url--->" + url);
        new Header("Authorization", basicAuth);
        response = getRequest(url, basicAuth, "application/vnd.aconex.mail.v2+xml");
        try {
            HttpEntity entity = response.getEntity();
            xmlResponse = EntityUtils.toString(entity);
            if (xmlResponse.isEmpty() || xmlResponse.contains("experiencing technical difficulty")) {
                while (counter < 2) {
                    basicAuth = basicAuthCredentialsProvider(userId);
                    response = getRequest(url, basicAuth);
                    try {
                        HttpEntity entity1 = response.getEntity();
                        xmlResponse = EntityUtils.toString(entity1);
                        if (response.getStatusLine().getStatusCode() == 200) break;
                    } catch (Exception e) {
                        counter++;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return xmlResponse;
    }

    public String getRecipients(DataTable dataTable, int counter) {
        List<Map<String, String>> mailData = dataTable.asMaps(String.class, String.class);
        List<String> headers = new ArrayList<>(mailData.get(counter).keySet());
        StringBuilder recipients = new StringBuilder();
        for (String header : headers) {
            if (header.equalsIgnoreCase("to_user")) {
                List<String> toUsers = directoryAPI.viewUserInformation(mailData.get(counter).get(header));
                recipients.append(",").append(getAllRecipents("ToUserId", toUsers));
            }
            if (header.equalsIgnoreCase("cc_user")) {
                List<String> ccUsers = directoryAPI.viewUserInformation(mailData.get(counter).get(header));
                recipients.append(",").append(getAllRecipents("CcUserId", ccUsers));
            }
            if (header.equalsIgnoreCase("bcc_user")) {
                List<String> bccUsers = directoryAPI.viewUserInformation(mailData.get(counter).get(header));
                recipients.append(",").append(getAllRecipents("BccUserId", bccUsers));
            }
        }
        return recipients.toString();
    }

    public String getAllRecipents(String key, List<String> values) {
        StringBuilder recipients = new StringBuilder();
        for (String value : values)
            recipients.append("\"").append(key).append("\"").append(":").append("\"").append(value).append("\",");
        return recipients.substring(0, recipients.length() - 1);
    }

    public String getAttachment(DataTable dataTable, int index) {
        List<Map<String, String>> mailData = dataTable.asMaps(String.class, String.class);
        return mailData.get(index).get("Attachment") + "," + mailData.get(index).get("AttachmentType");

    }
}
