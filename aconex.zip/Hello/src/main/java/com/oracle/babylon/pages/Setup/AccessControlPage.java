package com.oracle.babylon.pages.Setup;


import com.codeborne.selenide.Condition;
import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;

import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class AccessControlPage extends Navigator {

    private By pageTitle = By.xpath("//h1[contains(text(),'Configure Access Control')]");
    private By createGroupBtn = By.xpath("//button[@id='btnCreateAccessControlGroup']//div[text()='Create Group']");
    private By createRuleBtn = By.xpath("//button[@id='btnCreateAccessControlRule']//div[text()='Create Rule']");
    private String saveBtn = "//button[contains(@id,'btnSaveAccessControl')]//div[text()='Save']";
    private By saveGroupBtn = By.xpath("//button[@id='btnSaveAccessControlGroup']");
    private By createGrpPageTitle = By.xpath("//h1[contains(text(),'Create Group')]");
    private By mandatoryName = By.xpath("//label[text()='Name']//following-sibling::span[text()='*']");
    private By defaultChkBox = By.xpath("(//label[input[@name='defaultGroup'] and text()='Add new project users to this group (Default)'])");
    private By availableUser = By.xpath("//div[@class='uiBidi-leftHeader']//span[text()='Available Users']");
    private By selectedUser = By.xpath("//div[@class='uiBidi-rightHeader' and (text()='Selected Users')]");
    private By selectOption = By.xpath("//select//option");
    private By addItemLeftBtn = By.xpath("//button[@title='Add item to list']");
    private By removeItemBtn = By.xpath("//button[@title='Remove item from list']");
    private By addNewUserChk = By.xpath("//input[@id='Default_Group_chk']");
    private By nameTxt = By.xpath("//input[@name='name']");
    private By meetingMinutes = By.xpath("//div[text()='Meeting Minutes']");
    private By groupName = By.xpath("//table[@id='accessControlConfiguration-matrix-table']//thead//tr[1]//th//a");
    private By groupNames = By.xpath("//table[@id='accessControlConfiguration-matrix-table']//th/a");
    private By deleteGroup = By.xpath("//button[@id='btnDeleteAccessControlGroup']");
    private By ruleNameTxt = By.xpath("//input[@name='name']");
    private By createBtn = By.xpath("//button[@id='btnSaveAccessControlRule']");
    private By addRuleSelectBtn = By.xpath("//form[@id='accessControlRule-form']//table//td[@class='addcontentcell']//button");
    private By ruleArrangement = By.xpath("//table[@class='formTable']//tbody//tr//a");
    private By groupArrangement = By.xpath("//table[@class='formTable']//thead//tr//th//a");
    private By deleteRule = By.xpath("//button[@id='btnDeleteAccessControlRule']");
    private By btnOK = By.xpath("//button[@title='OK']");
    private By docTypeTxtBx = By.xpath("//input[@class='selected-input']");
    private By acesssRuleErrMsg = By.xpath("//div[@class='fileRightIcons']//span[contains(text(),'Rule Violation')]");
    private By acessRuleViolateMsg = By.xpath("//div[contains(text(),'Access rule violated.')]");
    private By registerDisabled = By.xpath("//div[@class='auiToolbar-right']//button[(@ng-disabled='!canRegister()') and contains(text(),'Register')]");
    private By settingSuccessMsg = By.xpath("//div[text()='Your selections have been saved']");
    private By docTypeDelete = By.xpath("//span[@class='auiIcon trash']");
    private By addAttributeBtn = By.xpath("//div[@class='uiPanel ']//button[@title='Add document field from the dropdown']");
    private By documentFieldTxt = By.xpath("//div[@class='auiForm-section'][2]//input[@class='selected-input']");
    private By orBtnDocTypeDocField = By.xpath("//div[@class='bidiSeparatorForOperator'][1]");
    private By orBtnDocFields = By.xpath("//div[@class='bidiSeparatorForOperator'][2]");
    private By saveTempFileDisabled = By.xpath("//div[@class='auiToolbar-right']//button[(@ng-disabled='!canSaveToTempRegister()') and contains(text(),'Save in Temporary Files')]");
    private By editDocFieldSave = By.xpath("//button[@id='editValuesPromptPanel_btnSaveChanges_page']");
    private By docFieldChk = By.xpath("//input[@type='checkbox']");
    private By docFieldSaveBtn = By.xpath("//button[@title='Save']");
    private By ruleLink = By.xpath("//table[@class='formTable']//tbody//tr[1]//td[1]//a");
    private By groupLink = By.xpath("//table[@id='accessControlConfiguration-matrix-table']//thead//tr[1]//th[2]//a");
    private By docFieldSelect = By.xpath("//div[@id='accessControlRule-page']//following-sibling::ul[@class='uiMenu']//li[2]");
    private By andBtn = By.xpath("//button[@id='btnAccessControlRuleAndOperator']");
    private By orBtn = By.xpath("//button[@id='btnAccessControlRuleOrOperator']");
    private By uploadProfileError = By.xpath("//span[@id='errorBox']//span");
    private By documentTypeTxt = By.xpath("//span[text()='Document Types']");
    private By groupDrpDown = By.xpath("//table[@id='accessControlConfiguration-matrix-table']//tr//select");
    private By projectFieldSelect = By.xpath("//div[@id='accessControlRule-page']//following-sibling::ul[@class='uiMenu']//li[3]");
    private By addDcoFields = By.xpath("//div[@class='uiPanel '][last()]//button[@title='Add document field from the dropdown']");
    private By ruleFields = By.xpath("//div[@class='auiForm-section'][last()]//input[@class='selected-input']");
    private By addProjectFields = By.xpath("//div[@class='uiPanel '][last()]//button[@title='Add project field from the dropdown']");
    private By selectDocField = By.xpath("//select[@id='selectInlineDocumentField']");
    private By selectProjectField = By.xpath("//select[@id='selectInlineProjectField']");
    private By ruleTypes = By.xpath("//ul[@id='typeMenu']");
    private String projectFieldsFrame = "//div/span[text()='Add Project Field']/ancestor::div//iframe";
    private String documentFieldsFrame = "//div/span[text()='Add Document Field']/ancestor::div//iframe";
    private By updateDocDisabled = By.xpath("//div[@class='auiToolbar-right']//button[(@ng-disabled='!canRegister()') and contains(text(),'Update Documents')]");
    private By tblAccessControl = By.xpath("//table[@id='accessControlConfiguration-matrix-table']");
    private String deleteCnfrmPanel = "//div[@id='pnlConfirmDeletePanel']//button[@id='pnlConfirmDeletePanel-commit']";

    /**
     * Function to navigate to the Access Control page under Setup
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Setup", "Configure Access Control");
        $(loadingIcon).should(disappear);
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, pageTitle, 80);
        Assert.assertTrue($(pageTitle).isDisplayed());
    }

    /**
     * Function to navigate to the access control page under Setup and verify the page
     */
    public void verifyAccessCntrlPage() {
        commonMethods.waitForElement(driver, createGroupBtn, 30);
        Assert.assertTrue("Create group button is displayed", $(createGroupBtn).isDisplayed());
        Assert.assertTrue("Create rule button is displayed", $(createRuleBtn).isDisplayed());
        Assert.assertTrue("Save button is displayed", $(By.xpath(saveBtn)).isDisplayed());
    }

    /**
     * Function to click on create group button
     */
    public void clickCreateGroup() {
        commonMethods.waitForElement(driver, createGroupBtn, 30);
        $(createGroupBtn).click();
    }

    /**
     * Function to verify the create group page
     */
    public void verifyCreateGroup(List<String> expectedList) {
        List<String> actualList = new ArrayList<>();
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, createGrpPageTitle, 30);
        Assert.assertTrue("Create group page is displayed", $(createGrpPageTitle).isDisplayed());
        Assert.assertTrue("Name field is displayed with mandatory sign", $(mandatoryName).isDisplayed());
        Assert.assertTrue("Check box to enable on or off for new users for to project is displayed", $(defaultChkBox).isDisplayed());
        Assert.assertTrue("Available user column is displayed", $(availableUser).isDisplayed());
        Assert.assertTrue("Select user column is displayed", $(selectedUser).isDisplayed());
        actualList = commonMethods.getValues(selectOption);
        for (String userName : expectedList) {
            Assert.assertTrue("Available users showing the users added to the project and belong to same organization", actualList.contains(commonMethods.getUserData(userName, "name")));
        }
        for (String rightUserList : expectedList) {
            $(By.xpath("//div[@class='uiBidi-left']//select//option[text()='" + commonMethods.getUserData(rightUserList, "name") + "']")).click();
            $(addItemLeftBtn).click();
            Assert.assertTrue("Users are moved from Available list to Selected list", $(By.xpath("//div[@class='uiBidi-right']//select//option[text()='" + commonMethods.getUserData(rightUserList, "name") + "']")).isDisplayed());
        }
        for (String leftUserList : expectedList) {
            $(By.xpath("//div[@class='uiBidi-right']//select//option[text()='" + commonMethods.getUserData(leftUserList, "name") + "']")).click();
            $(removeItemBtn).click();
            Assert.assertTrue("Users are moved from selected list to available list", $(By.xpath("//div[@class='uiBidi-left']//select//option[text()='" + commonMethods.getUserData(leftUserList, "name") + "']")).isDisplayed());
        }
    }

    /**
     * Function to verify the new user added exist in the access control group
     */
    public void verifyNewUser(List<String> expectedList) {
        clickGroupName();
        List<String> actualList = new ArrayList<>();
        for (WebElement element : $$(selectOption)) {
            actualList.add(element.getText());
        }
        commonMethods.waitForElement(driver, createGrpPageTitle, 30);
        Assert.assertTrue("New project user created as part of organization is added to the newly group created", expectedList.containsAll(actualList));
    }

    /**
     * Function to verify meeting minutes in access control displayed
     */
    public boolean verifyDocumentType(String docType) {
        commonMethods.waitForElementExplicitly(5000);
        return $(By.xpath("//div[text()='" + docType + "']")).isDisplayed();
    }

    /**
     * Function to enter the group name
     */
    public void enterGroupName(String groupName) {
        $(nameTxt).sendKeys(groupName);
    }

    /**
     * Function to check the add new user to project checkbox
     */
    public void checkAddNewProjectUser() {
        commonMethods.waitForElementExplicitly(2000);
        $(addNewUserChk).setSelected(true);
    }

    /**
     * Function to save the group
     */
    public void clickSaveGroup() {
        $(saveGroupBtn).click();
    }

    /**
     * Function to click group name
     */
    public void clickGroupName() {
        $(groupName).click();
    }

    /**
     * Function to delete the group
     */
    public void deleteGroup() {
        $(deleteGroup).click();
    }

    /**
     * Function to click on create rule
     */
    public void clickCreateRule() {
        commonMethods.waitForElement(driver,createRuleBtn, 30);
        $(createRuleBtn).click();
    }

    /**
     * Function to enter the rule name
     */
    public void enterRuleName(String ruleName) {
        commonMethods.waitForElement(driver, ruleNameTxt, 30);
        commonMethods.waitForElementExplicitly(2000);
        $(ruleNameTxt).sendKeys(ruleName);

    }

    /**
     * Function to click on create button
     */
    public void clickCreateBtn() {
        commonMethods.waitForElementExplicitly(2000);
        $(createBtn).click();
    }

    /**
     * Function to select the add rule
     */
    public void selectAddRule() {
        commonMethods.waitForElement(driver, addRuleSelectBtn, 60);
        commonMethods.getElementInViewAndUp(addRuleSelectBtn);
        $(addRuleSelectBtn).click();
    }

    /**
     * Function to select the rule type
     */
    public void selectRuleType(String ruleType) {
        commonMethods.waitForElementExplicitly(2000);
        $(By.xpath("//ul[@id='typeMenu'][" + $$(ruleTypes).size() + "]//li//div[text()='" + ruleType + "']")).click();
    }

    /**
     * Function to select the doc field under rule
     */
    public void selectDocFieldInRule() {
        commonMethods.getElementInViewAndUp(docFieldSelect);
        commonMethods.waitForElementExplicitly(1000);
        $(docFieldSelect).click();
    }

    /**
     * Function to select the doc type under rule
     */
    public void selectDocType(String docType) {
        commonMethods.waitForElementExplicitly(2000);
        $(docTypeTxtBx).click();
        enterDocTypeName(docType);
        $(documentTypeTxt).click();
        $(ruleNameTxt).click();
    }

    /**
     * Function to verify the rule arrangement
     */
    public List<String> verifyRuleArrangement() {
        commonMethods.waitForElement(driver, ruleArrangement, 30);
        return commonMethods.getValues(ruleArrangement);
    }

    /**
     * Function to verify the group arrangement
     */
    public List<String> verifyGroupArrangement() {
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, groupArrangement, 30);
        List<String> actualGroup = new ArrayList<>();
        for (WebElement element : $$(groupArrangement)) {
            String[] text = element.getText().split("\n");
            actualGroup.add(text[0]);
        }
        return actualGroup;
    }

    /**
     * Function to get the dropdown value
     */
    public List<String> getRuleDropdownValue() {
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, selectOption, 30);
        return commonMethods.getValues(selectOption);
    }

    /**
     * Function to select the dropdown value
     */
    public void selectAllDropdownValues(String value) {
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.enterDropdownValue(groupDrpDown, value);
        clickSaveSettings();
    }

    /**
     * Function to delete all groups
     */
    public void deleteAllGroups(int number) {
        int counter = number + 1;
        for (WebElement group : $$(groupName)) {
            commonMethods.waitForElementExplicitly(3000);
            $(groupLink).click();
            commonMethods.waitForElementExplicitly(3000);
            commonMethods.waitForElement(driver, deleteGroup, 30);
            $(deleteGroup).click();
            commonMethods.waitForElementExplicitly(3000);
            $(By.xpath("//div[@id='pnlConfirmDeletePanel'][" + counter + "]//button[@title='OK']")).click();
            loadingIconDone();
            counter++;
        }
    }

    /**
     * Function to delete all groups
     */
    public void deleteAllGroups() {
        int totalGroups = $$(groupNames).size();
        for (int i = 1; i <= totalGroups; i++) {
            commonMethods.waitForElement(driver, groupLink, 60);
            commonMethods.waitForElementExplicitly(2000);
            $(groupLink).click();
            commonMethods.waitForElement(driver, deleteGroup, 30);
            $(deleteGroup).click();
            commonMethods.waitForElementExplicitly(2000);
            $(By.xpath("(" + deleteCnfrmPanel + ")[" + $$(By.xpath(deleteCnfrmPanel)).size() + "]")).click();
            commonMethods.waitForElementExplicitly(3000);
        }
    }

    /**
     * Function to delete all rules
     */
    public void deleteAllRules() {
        int totalRules = $$(ruleArrangement).size();
        for (int i = 1; i <= totalRules; i++) {
            commonMethods.waitForElement(driver, ruleLink, 60);
            commonMethods.waitForElementExplicitly(2000);
            $(ruleLink).click();
            commonMethods.waitForElement(driver, deleteRule, 30);
            $(deleteRule).click();
            commonMethods.waitForElementExplicitly(2000);
            $(By.xpath("(" + deleteCnfrmPanel + ")[" + $$(By.xpath(deleteCnfrmPanel)).size() + "]")).click();
            commonMethods.waitForElementExplicitly(3000);
        }
    }

    /**
     * Function to click on ok button
     */
    public void clickButtonOK() {
        commonMethods.waitForElement(driver, btnOK, 30);
        $(btnOK).click();
    }

    /**
     * Function to click on save access control settings
     */
    public void clickSaveSettings() {
        commonMethods.waitForElement(driver, By.xpath(saveBtn));
        $(By.xpath(saveBtn)).click();
    }

    /**
     * Function to verify the error message
     */
    public boolean verifyErrorMsg() {
        commonMethods.waitForElementExplicitly(5000);
        commonMethods.waitForElement(driver, registerDisabled, 30);
        return $(acesssRuleErrMsg).isDisplayed() && $(acessRuleViolateMsg).isDisplayed() && $(registerDisabled).isDisplayed() && $(saveTempFileDisabled).isDisplayed();
    }

    /**
     * Function to delete the doc types from the rule in access control page
     */
    public void deleteDocTypes(List<String> docTypes) {
        for (String element : docTypes) {
            commonMethods.waitForElementExplicitly(3000);
            $(ruleLink).click();
            commonMethods.waitForElementExplicitly(2000);
            $(By.xpath("//div[@class='selected-wrapper']//span[text()='" + element + "']//following-sibling::a")).click();
        }
    }

    /**
     * Function to verify the success message
     */
    public boolean verifySettingSucess() {
        commonMethods.waitForElement(driver, settingSuccessMsg, 30);
        return $(settingSuccessMsg).isDisplayed();
    }

    /**
     * Function to click on doc type delete
     */
    public void clickDocTypeDelete() {
        $(docTypeDelete).click();
    }

    /**
     * Function to enter the doctype name
     */
    public void enterDocTypeName(String docType) {
        commonMethods.waitForElementExplicitly(2000);
        $(docTypeTxtBx).sendKeys(docType);
    }

    /**
     * Function to select the user in the group
     */
    public void selectGroupUsr(List<String> userName) {
        commonMethods.waitForElementExplicitly(3000);
        for (String userList : userName) {
            $(By.xpath("//div[@class='uiBidi-left']//select//option[text()='" + commonMethods.getUserData(userList, "name") + "']")).click();
            $(addItemLeftBtn).click();
        }
    }

    /**
     * Function to select document field
     */
    public void selectDocumentField(String attributeName) {
        commonMethods.waitForElement(driver, selectDocField, 60);
        commonMethods.enterDropdownValue(selectDocField, attributeName);
        commonMethods.waitForElementExplicitly(2000);
        verifyAndSwitchFrame();
        $(addDcoFields).click();
    }

    /**
     * Function to select the attribute value under rule
     */
    public void selectAttributeVal(String attributeName, String attributeValue) {
        selectDocumentField(attributeName);
        $(loadingIcon).should(disappear);
        $(ruleFields).scrollTo();
        getElementInView(ruleFields);
        $(ruleFields).click();
        commonMethods.waitForElementExplicitly(2000);
        $(ruleFields).sendKeys(attributeValue + Keys.ENTER);
    }

    /**
     * Function to select the attribute value under rule
     */
    public void selectAttributeVal(String attributeName, List<String> attributeValues) {
        selectDocumentField(attributeName);
        $(loadingIcon).should(disappear);
        $(ruleFields).scrollTo();
        getElementInView(ruleFields);
        $(ruleFields).click();
        commonMethods.waitForElementExplicitly(2000);
        for (String attributeValue : attributeValues)
            $(ruleFields).sendKeys(attributeValue + Keys.ENTER);
        commonMethods.scrollPageUp(driver);
         $(ruleNameTxt).click();
    }

    /**
     * Function to click edit rule
     */
    public void clickEditRole() {
        commonMethods.waitForElementExplicitly(3000);
        $(ruleLink).click();
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, deleteRule, 30);
    }

    /**
     * Function to click edit rule
     */
    public void clickEditRole(String ruleName) {
        By xpath = By.xpath("//table[@class='formTable']//tbody//tr//td//a[text()='" + ruleName + "']");
        commonMethods.waitForElement(driver, xpath, 60);
        $(xpath).click();
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, deleteRule, 30);
    }

    /**
     * Function to verify or condition formed in the doctype
     */
    public boolean verifyOrDocTypeDocField(String condition) {
        return $(orBtnDocTypeDocField).getText().equals(condition);
    }

    /**
     * Function to verify the Or condition formed in the doc fields
     */
    public boolean verifyOrDocFields(List<String> condition) {
        return $(orBtnDocFields).getText().equals(condition.get(0));
    }

    /**
     * Function to verify the specific doctype present under rule
     */
    public boolean verifyDocCategoryPresent(String docTypeName) {
        return $(By.xpath("//span[text()='" + docTypeName + "']")).isDisplayed();
    }

    /**
     * Function to delete the doc field
     */
    public void deleteDocField(String attributeName) {
        $(By.xpath("//table[@class='dataTable']//tr//td[contains(text(),'" + attributeName + "')]//following-sibling::td/a")).click();
        commonMethods.waitForElementExplicitly(3000);
        $(editDocFieldSave).click();
        $(docFieldChk).click();
        commonMethods.waitForElementExplicitly(3000);
        $(docFieldSaveBtn).click();
    }

    /**
     * Function to click on the OR button in access control page
     */
    public void clickOrBtn() {
        $(orBtn).click();
    }

    /**
     * Function to click on the AND button in access control page
     */
    public void clickAndBtn() {
        $(andBtn).click();
    }

    /**
     * Function to verify the error message in upload profile page for restricted field at access control
     */
    public void verifyUploadProfileError() {
        commonMethods.waitForElement(driver, uploadProfileError, 30);
        Assert.assertTrue("Error message is displayed", $(uploadProfileError).isDisplayed());
    }

    /**
     * Function to verify the access control error message in document page
     */
    public boolean verifyErrMsgAccessCntrl(String errMsgCount, String flag) {
        commonMethods.waitForElementExplicitly(5000);
        if (flag.equalsIgnoreCase("true"))
            return $(acesssRuleErrMsg).isDisplayed() && $$(acessRuleViolateMsg).size() == Integer.parseInt(errMsgCount) && $(registerDisabled).isDisplayed() && $(saveTempFileDisabled).isDisplayed();
        else
            return !$(acessRuleViolateMsg).isDisplayed();
    }


    /**
     * Function to get the name of the rule
     */
    public String getRuleName() {
        return $(ruleLink).getText();
    }

    /**
     * Function to get the name of the group
     */
    public String getGroupName() {
        return $(groupLink).getText();
    }

    /**
     * Function to select the dropdown value
     */
    public void selectMultipleDropDownVal(String value) {
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.enterMultipleDropdownValues(groupDrpDown, value);
        clickSaveSettings();
    }

    /**
     * Function to select the project field under rule
     */
    public void selectProjectFieldInRule() {
        commonMethods.getElementInViewAndUp(projectFieldSelect);
        commonMethods.waitForElementExplicitly(1000);
        $(projectFieldSelect).click();
    }

    /**
     * Function to select the attribute value under rule
     */
    public void selectProjectFieldValues(String fieldName, List<String> attributeValues) {
        commonMethods.enterDropdownValue(selectProjectField, fieldName);
        commonMethods.waitForElementExplicitly(2000);
        verifyAndSwitchFrame();
        $(addProjectFields).click();
        $(loadingIcon).should(disappear);
        $(ruleFields).scrollTo();
        getElementInView(ruleFields);
        $(ruleFields).click();
        commonMethods.waitForElementExplicitly(2000);
        for (String attributeValue : attributeValues)
            $(ruleFields).sendKeys(attributeValue + Keys.ENTER);
        commonMethods.scrollPageUp(driver);
        $(ruleNameTxt).click();
    }

    /**
     * Function to switch to document or project fields rule selection frame
     */
    public void switchToFieldsFrame(String type) {
        verifyAndSwitchFrame();
        if (type.equalsIgnoreCase("document fields"))
            verifyAndSwitchFrame(By.xpath("(" + documentFieldsFrame + ")[" + $$(By.xpath(documentFieldsFrame)).size() + "]"));
        else
            verifyAndSwitchFrame(By.xpath("(" + projectFieldsFrame + ")[" + $$(By.xpath(projectFieldsFrame)).size() + "]"));
    }

    /**
     * Function to select the access type value for a specific rule
     */
    public void selectAccessType(String rule, String value) {
        commonMethods.waitForElementExplicitly(3000);
        By xpath = By.xpath("//a[text()='" + rule + "']/../following-sibling::td/select");
        commonMethods.enterDropdownValue(xpath, value);
        clickSaveSettings();
    }

    /**
     * Function to verify document type rule is disabled
     */
    public boolean verifyDocTypeOption() {
       return $(By.xpath("//ul[@id='typeMenu'][" + $$(ruleTypes).size() + "]//div[text()='Document Types']/..")).getAttribute("class").contains("disabled");
    }

    /**
     * Method to click on save button
     */
    public void clickSave() {
        $(By.xpath("(" + saveBtn + ")[" + $$(By.xpath(saveBtn)).size() + "]")).click();
    }

    /**
     * Function to verify the error message in supersede screen
     */
    public boolean verifySupersedeErrorMsg() {
        commonMethods.waitForElementExplicitly(5000);
        commonMethods.waitForElement(driver, updateDocDisabled, 30);
        return $(acesssRuleErrMsg).isDisplayed() && $(acessRuleViolateMsg).isDisplayed() && $(updateDocDisabled).isDisplayed();
    }

    /**
     * Function to set access control rules for a specific group and role
     */
    public void setAccessRole(String group, String rule, String value) {
        int index = 0;
        commonMethods.waitForElementExplicitly(3000);
        List<String> headers = commonMethods.returnColumnHeaders(driver, tblAccessControl);
        for (String header : headers)
            if (header.contains(group)) {
                index = headers.indexOf(header);
                break;
            }
        By xpath = By.xpath("//a[text()='" + rule + "']/../following-sibling::td[" + index + "]/select");
        commonMethods.enterDropdownValue(xpath, value);
        clickSaveSettings();
    }
}