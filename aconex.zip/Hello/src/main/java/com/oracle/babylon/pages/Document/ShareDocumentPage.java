package com.oracle.babylon.pages.Document;

import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.$;

public class ShareDocumentPage extends DocumentPage{

    private By editPermission = By.xpath("//img[contains(@name,'Edit')]");
    private By notifyPermission = By.xpath("//img[contains(@name,'Notify')]");


    public void provideEditPermission(){
        $(editPermission).click();
    }

    public void provideNotifyPermission(){
        $(notifyPermission).click();
    }
}
