package com.oracle.babylon.pages.Tenders;

import org.junit.Assert;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Selenide.$;

public class DraftsPage extends TenderPage{

    //Initializing the HTML elements
    private By editBtn = By.xpath("//button[@id='btnEditTender']//div[contains(text(),'Edit')]");
    private By emptyDraft = By.xpath("//a[contains(text(),'-')]");

    public void verifyButtons(){
        commonMethods.waitForElement(driver, editBtn);
        Assert.assertTrue($(editBtn).isDisplayed());
        Assert.assertTrue($(actionsBtn).isDisplayed());
    }


    /**
     * Method to navigate to create tender invitation page
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Tenders", "Drafts");
        $(loadingIcon).should(disappear);
        Assert.assertTrue(verifyPageTitle(pageTitle));
        commonMethods.waitForElementExplicitly(5000);
    }

    public void clickEditBtn() {
        $(editBtn).click();
    }


    public void selectEmptyDraft() {
        $(emptyDraft).click();
    }

}
