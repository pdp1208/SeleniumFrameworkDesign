package com.oracle.babylon.pages.Setup.ProjectSettings;

import com.github.javafaker.Faker;
import com.oracle.babylon.pages.Setup.ProjectSettingsPage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Selenide.*;

public class PackageType extends ProjectSettingsPage {

    private By createPackageTypeBtn = By.xpath("//button[text()='Create Package Type']");
    private By name = By.xpath("//input[@id='name']");
    private By code = By.xpath("//input[@id='code']");
    private By saveBtn = By.xpath("//button[text()='Save']");
    private By coreFieldsTableRows = By.xpath("//table[@class='auiTable editPackageType-coreFields']//tbody//tr");
    private By editSettingsToolTip = By.xpath("//edit-icon[@title='Package Type Settings']");
    private By autoNumberingToolTip = By.xpath("//edit-icon[@title='Auto Numbering Settings']");
    private By autoNumEnable = By.xpath("//label[text()=' Enable Auto Numbering']//..//input");
    private By header = By.xpath("//div[text()='This action cannot be reversed.']");
    private By schemaSelect = By.xpath("//div[text()='Scheme']//..//select");
    private By addField = By.xpath("//button[contains(text(),'Add Field')]");
    private By packageTypeTable = By.xpath("//table[@class='auiTable']");
    private By backBtn = By.xpath("//button[@class='auiButton back']");
    private By allowMail = By.xpath("//label[contains(text(),'Allow creation of mail')]//input");
    private By allowAttachments = By.xpath("//label[contains(text(),'Allow Attachments')]//input");

    private By chkBoxSelectAll = By.xpath("//div[@class='customFieldsApplied-tableContent']//table[@class='auiTable']//th[1]");
    private By removeBtn = By.xpath("//button[text()='Remove']");
    private By deleteBtn = By.xpath("//button[text()='Delete']");
    private By deletedToolTipLoc = By.xpath("//div[contains(text(),'Package Type deleted')]");
    private By packageTypeLoc = By.xpath("//span[contains(text(),'Package Type')]");

    /**
     * Method to create a package type in Setup -> SearchPackage Type page
     * @return
     */
    public String createPackageType(){
        switchProjectSettingsFrame();
        commonMethods.waitForElement(driver, createPackageTypeBtn, 30);
        $(createPackageTypeBtn).click();
        Faker faker = new Faker();
        String number = faker.number().digits(3);
        String title = faker.address().firstName() + number;

        $(name).sendKeys(title);
        $(code).sendKeys(title.substring(0,3) + number);

        $(saveBtn).click();
        driver.switchTo().defaultContent();
        return title;
    }

    public void selectPackageType(String packageType){
        switchProjectSettingsFrame();
        By element = By.xpath("//a[contains(text(),'"+ packageType +"')]");
        commonMethods.waitForElement(driver, element);
        $(element).click();
        commonMethods.waitForElement(driver, packageTypeLoc, 45);
        driver.switchTo().defaultContent();
    }

    public void validateMandatoryFields(List<String> mandatoryFields){
        switchProjectSettingsFrame();
        commonMethods.waitForElement(driver, coreFieldsTableRows);
        List<WebElement> rowElements = driver.findElements(coreFieldsTableRows);
        List<String> cells = new ArrayList<>();

        for(int count=0;count<rowElements.size(); count++){
            cells.add(driver.findElement(By.xpath("//table[@class='auiTable editPackageType-coreFields']//tbody//tr[" + (count+1)+ "]//td[1]")).getText());
        }
        for(String fields:mandatoryFields){
            int index = cells.indexOf(fields);
            By element = By.xpath("//table[@class='auiTable editPackageType-coreFields']//tbody//tr[" + (index+1) + "]//td[2]//input");
            Assert.assertFalse($(element).isEnabled());
            Assert.assertEquals($(element).getAttribute("checked"), "true");

        }
        driver.switchTo().defaultContent();
    }

    public void associateProjectField(String projectField){
        switchProjectSettingsFrame();
        By element = By.xpath("//div[text()='" + projectField +"']//..//button");
        $(element).click();
        driver.switchTo().defaultContent();
    }

    public void mandatoryProjectField(String projectField){
        switchProjectSettingsFrame();
        By element = By.xpath("//span[text()='" + projectField +"']//ancestor::tr//td[3]//input");
        $(element).setSelected(true);
        $(saveBtn).click();
        driver.switchTo().defaultContent();

    }

    public void validateSettingsFields(List<String> fields){
        switchProjectSettingsFrame();
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(document.body.scrollHeight, 0)");
        for(String value:fields){
            By element = By.xpath("//settings-section[@class='auiDetails']//span[text()='"+ value + "']");
            Assert.assertTrue($(element).isDisplayed());
        }
        driver.switchTo().defaultContent();
    }

    /**
     * Method to click on the edit icon next to Settings.
     */
    public void clickSettingsEditIcon(){
        switchProjectSettingsFrame();
        $(editSettingsToolTip).click();
        driver.switchTo().defaultContent();
    }

    /**
     * Method to check if the edit Package type icon is present
     * @return
     */
    public boolean returnSettingsEditIcon(){
        return $(editSettingsToolTip).isDisplayed();
    }

    /**
     * Method to click on the edit icon next to Settings.
     */
    public void clickAutoNumEditIcon(){
        switchProjectSettingsFrame();
        $(autoNumberingToolTip).click();
        driver.switchTo().defaultContent();
    }

    /**
     * Method to click on the edit icon next to Settings.
     */
    public boolean validateSettingsEditIcon(){
        switchProjectSettingsFrame();
        Boolean displayed = $(editSettingsToolTip).isDisplayed();
        driver.switchTo().defaultContent();
        return displayed;
    }

    /**
     * Method to set the fields available in the settings pop up screen
     * @param option
     * @param value
     */
    public void setOption(String option, Boolean value){
        By element = By.xpath("//label[contains(text(),'" + option + "')]//..//input");
        $(element).setSelected(value);
    }

    /**
     * Method to validate if text This action cannot be reversed is displayed
     * @return
     */
    public boolean validateSettingsHeader(){
        switchProjectSettingsFrame();
        Boolean value = $(header).isDisplayed();
        driver.switchTo().defaultContent();
        return value;
    }

    /**
     * Method for auto numbering pattern for package type
     * @return
     */
    public String enableAutoNum(){
        //basic order of auto numbering is enabled with package code - sequence number - project code
        //used as the order
        switchProjectSettingsFrame();
        $(autoNumEnable).setSelected(true);
        Select selectElement = new Select($(schemaSelect));
        selectElement.selectByValue("FIELD_PACKAGE_TYPE_CODE");
        $(addField).click();
        List<WebElement> elements = driver.findElements(schemaSelect);
        int count = elements.size();
        selectElement = new Select(elements.get(count-1));
        selectElement.selectByValue("FIELD_PROJECT_CODE");
        String pattern = $(By.xpath("//span[contains(text(),'Preview:')]")).getText();
        pattern = pattern.split("Preview: ")[1];
        $(saveBtn).click();
        driver.switchTo().defaultContent();
        return pattern;
    }

    public void validateActiveFields(String packageType, List<String> fields){
        List<WebElement> columnValues = driver.findElements(By.xpath("//table[@class='auiTable']//thead//tr//th//div"));
        int count=1;
        Map<String, Integer> map = new HashMap<>();
        for(WebElement element :columnValues){
            map.put(element.getText(), count);
            count++;
        }
        for(String field:fields){
            if(map.containsKey(field)){
                By cell = By.xpath("//a[text()='" + packageType + "']//ancestor::tr//td[" + map.get(field) + "]//div");
                Assert.assertTrue($(cell).getAttribute("class").equals("tick ng-scope"));
            }

            if(map.containsKey("Status")){
                By cell = By.xpath("//a[text()='" + packageType + "']//ancestor::tr//td[" + map.get("Status") + "]");
                Assert.assertTrue($(cell).getText().equals("Active"));
            }
        }
    }

    public void clickBackBtn(){
        $(backBtn).click();
    }


    public boolean verifyPackageType(String packageTypeStr) {
        By by = By.xpath("//td//a[text()='"+ packageTypeStr + "']");
        return $(by).isDisplayed();
    }

    /**
     * method to get package code
     * @param packageName
     * @return
     */
    public String getCode(String packageName) {
        return $(By.xpath("//td/a[text()='" + packageName + "']/../..//td[2]")).getText();
    }

    /**
     * Function to remove all project fields associated to Package type
     */
    public void removeAllProjectFields() {
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.getElementInViewAndUp(chkBoxSelectAll);
        $(chkBoxSelectAll).click();
        commonMethods.waitForElementExplicitly(1000);
        $(removeBtn).click();
    }

    /**
     * Function to delete Package type
     */
    public void deletePackageType(String packTypeId) {
        Actions actions = new Actions(driver);
        actions.moveToElement($(By.xpath("//td/a[text()='" + packTypeId + "']/../../td[7]"))).perform();
        commonMethods.waitForElementClickable(driver, By.xpath("//td/a[text()='" + packTypeId + "']/../../td[7]"), 10);
        $($(By.xpath("//td/a[text()='" + packTypeId + "']/../../td[7]"))).click();
        commonMethods.waitForElement(driver, deleteBtn, 30);
        $(deleteBtn).click();
        commonMethods.waitForElement(driver, deletedToolTipLoc, 30);
        Assert.assertTrue("Package Type is not deleted", $(deletedToolTipLoc).isDisplayed());
    }

}
