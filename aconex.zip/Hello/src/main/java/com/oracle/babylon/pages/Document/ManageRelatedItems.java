package com.oracle.babylon.pages.Document;

import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import static com.codeborne.selenide.Selenide.$;

public class ManageRelatedItems extends RelatedItemsPage {

    private By addBtn = By.xpath("//button[text()='Add']");
    private By addRelatedItemsLink = By.xpath("//a[text()='Add New Related Items']");
    private By copyOtherDocLink = By.xpath("//a[text()='Copy from Other Document']");
    private By addRelatedItemsTitle = By.xpath("//h3[text()='Add Related Items']");
    private By chooseRelationship = By.xpath("//h2[contains(text(),'Choose a relationship')]//..//select");
    private By attachDocFrame = By.xpath("//div[@class='docAttach']//iframe");
    private By addRelatedItemsBtn = By.xpath("//button[text()='Add Related Items']");
    private By relationshipCell = By.xpath("//div[@class='editRelatedDocsTable']//table//tbody//tr[1]//td[2]");
    private By documentNumberCell = By.xpath("//div[@class='editRelatedDocsTable']//table//tbody//tr[1]//td[4]");
    private By saveBtn = By.xpath("//button[text()='Save']");
    private By savedMessage = By.xpath("//div[text()='Related items saved successfully.']");
    private By changeRelationshipBtn = By.xpath("//button[text()='Change Relationships']");
    private By removeBtn = By.xpath("//button[text()='Remove']");
    private By removeAllVersionBtn = By.xpath("//input[@id='removeAllVersion']");
    private By removeCurrentVersionBtn = By.xpath("//input[@id='removeCurrentVersion']");
    private By removeLinksBtn = By.xpath("//button[text()='Remove Links']");
    private By copyBtn  = By.xpath("//button[text()='Copy Related Items']");


    /**
     * Method to add a relationship
     * End to end to cover all the steps required to configure/add related items
     * @param relationship
     * @param documentNumber
     */
    public void addNewRelatedItems(String relationship, String documentNumber){
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver,addBtn);
        $(addBtn).click();
        $(addRelatedItemsLink).click();
        if(!verifyAddRelatedItems()){
            System.out.println("Error in loading the Add Related Items page");
        }
        $(chooseRelationship).click();
        Select select = new Select($(chooseRelationship));
        select.selectByVisibleText(relationship);
        verifyAndSwitchFrame(attachDocFrame);
        DocumentRegisterPage documentRegisterPage = new DocumentRegisterPage();
        documentRegisterPage.searchDocumentNo(documentNumber);
        documentRegisterPage.selectAllRecords();
        switchToOriginal();
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        $(addRelatedItemsBtn).click();
        commonMethods.waitForElementExplicitly(2000);
        $(saveBtn).click();
        commonMethods.waitForElement(driver, savedMessage, 15);
        if($(savedMessage).isDisplayed()){
            clickOkBtn();
        }

    }

    /**
     * Method to copy the related items of a document to another
     * @param documentNumber
     */
    public void copyRelatedItem(String documentNumber){
        verifyAndSwitchFrame();
        $(addBtn).click();
        $(copyOtherDocLink).click();
        verifyAndSwitchFrame(attachDocFrame);
        DocumentRegisterPage documentRegisterPage = new DocumentRegisterPage();
        documentRegisterPage.searchDocumentNo(documentNumber);
        documentRegisterPage.selectFirstFile();
        switchToOriginal();
        verifyAndSwitchFrame();
        $(copyBtn).click();
        $(saveBtn).click();
        commonMethods.waitForElementExplicitly(1000);
        commonMethods.waitForElement(driver, savedMessage);
        if($(savedMessage).isDisplayed()){
            clickOkBtn();
        }



    }

    /**
     * Method to validate if the relationship is added or not
     * @return
     */
    public Boolean verifyAddRelatedItems(){
        commonMethods.waitForElement(driver, addRelatedItemsTitle);
        return $(addRelatedItemsTitle).isDisplayed();
    }

    /**
     * Method to verify documents that are attached
     * @param relationship
     * @param documentNumber
     * @return
     */
    public Boolean verifyAttachedDocument(String relationship, String documentNumber){
        verifyAndSwitchFrame();
        Assert.assertEquals(relationship, relationshipCell);
        Assert.assertEquals(documentNumber, documentNumberCell);
        return true;
    }

    /**
     * Method to verify if save operation is successful
     * @return
     */
    public Boolean verifySavedChanges(){
        commonMethods.waitForElement(driver, savedMessage);
        if($(savedMessage).isDisplayed()){
            return true;
        }
        return false;
    }

    /**
     * Method to change the relationship of the document
     * @param relationship
     */
    public void changeRelationship(String relationship){
        $(changeRelationshipBtn).click();
        WebElement element = driver.findElement(By.xpath("//li//a[text()='" + relationship + "']"));
        element.click();
        $(saveBtn).click();
        commonMethods.waitForElementExplicitly(1000);
        commonMethods.waitForElement(driver, savedMessage);
        if($(savedMessage).isDisplayed()){
            clickOkBtn();
        }
    }

    /**
     * Method to remove RI from instance
     */
    public void removeRelatedItem(){
        $(removeBtn).click();
        $(removeAllVersionBtn).click();
        commonMethods.waitForElementExplicitly(500);
        $(removeLinksBtn).click();
        $(saveBtn).click();
        commonMethods.waitForElementExplicitly(2000);
    }

}
