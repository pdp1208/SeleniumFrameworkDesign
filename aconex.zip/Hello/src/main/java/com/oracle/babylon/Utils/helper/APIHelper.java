package com.oracle.babylon.Utils.helper;


import com.oracle.babylon.Utils.setup.dataStore.DataSetup;
import com.oracle.babylon.Utils.setup.utils.ConfigFileReader;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustAllStrategy;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.DefaultProxyRoutePlanner;

import java.io.DataOutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.*;

//Rest assured imports
import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.http.ssl.SSLContextBuilder;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;

import javax.net.ssl.*;


/**
 * Helper class where we create methods required to carry out api operations
 * Author : susgopal, visingsi
 */
public class APIHelper {

    private CloseableHttpClient client = HttpClients.createDefault();
    public static RequestSpecification httpRequest;
    public static Response response;
    public static JsonPath extractor;
    ConfigFileReader configFileReader=new ConfigFileReader();
    HashMap<String,String> ownUserInfo=new HashMap<>();
    public final String auth="Authorization";
    Boolean ownUserFlag=false;
    DataSetup dataSetup=new DataSetup();
    CommonMethods commonMethods=new CommonMethods();
    String docFilePath = configFileReader.getDocumentDataPath();

    /**
     * Method to set the proxy to the HTTP Client
     */
    public void setHttpClient(){
        ConfigFileReader configFileReader = new ConfigFileReader();
        String proxyStr = configFileReader.getProxyURL();
        String proxyUrl = proxyStr.split(":")[0];
        int proxyPort = Integer.parseInt(proxyStr.split(":")[1]);
        Boolean checkProxy = configFileReader.getAPIProxyStatus();
        //if proxy is enabled
        if (checkProxy && !configFileReader.getApplicationUrl().contains("oracle") ) {
            HttpHost proxy = new HttpHost(proxyUrl, proxyPort, "http");
            DefaultProxyRoutePlanner routePlanner = new DefaultProxyRoutePlanner(proxy);
            try {
                client = HttpClients.custom()
                        .setSSLContext(new SSLContextBuilder().loadTrustMaterial(null, TrustAllStrategy.INSTANCE).build())
                        .setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE)
                        .setRoutePlanner(routePlanner)
                        .build();
            } catch (NoSuchAlgorithmException | KeyManagementException | KeyStoreException e) {
                e.printStackTrace();
            }
        } else {
            SSLContext sslContext = null;
            try {
                sslContext = SSLContextBuilder
                        .create()
                        .loadTrustMaterial(new TrustSelfSignedStrategy())
                        .build();
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            } catch (KeyManagementException e) {
                e.printStackTrace();
            } catch (KeyStoreException e) {
                e.printStackTrace();
            }
            //disable hostname verification.
            HostnameVerifier allowAllHosts = new NoopHostnameVerifier();
            // create an SSL Socket Factory to use the SSLContext with the trust self signed certificate strategy and allow all hosts verifier.
            SSLConnectionSocketFactory connectionFactory = new SSLConnectionSocketFactory(sslContext, allowAllHosts);
            //create the HttpClient using HttpClient factory methods and assign the ssl socket factory
            client = HttpClients
                    .custom()
                    .setSSLSocketFactory(connectionFactory)
                    .build();
        }
        //RestAssured.proxy = ProxySpecification.host(proxyUrl).withPort(proxyPort);
    }

    /**
     * HTTPClient and HTTP Get clients are used to create a method for constructing and executing GET API Request
     *
     * @param url           target server
     * @param authorization Header to gain access
     * @return response
     */
    public HttpResponse getRequest(String url, String authorization) {
        return getRequest(url,authorization, null);
    }

    /**
     * Method to be used when we want the output to be in a specific format
     * @param url
     * @param authorization
     * @param acceptType
     * @return
     */
    public HttpResponse getRequest(String url, String authorization, String acceptType){
        try {
            setHttpClient();
            HttpGet getRequest = new HttpGet(url);
            getRequest.setHeader("Authorization", authorization);
            if(acceptType!=null){
                getRequest.setHeader("Accept", acceptType);
            }
            return client.execute(getRequest);
        } catch (ClientProtocolException cpe) {
            System.out.println("Error in client protocol");
            cpe.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    /**
     * HTTPClient and HTTP Post clients are used to create a method for constructing and executing POST API Request
     *
     * @param url           target server
     * @param authorization Header to gain access
     * @param body          request body that needs to be sent
     * @return response
     */
    public HttpResponse postRequest(String url, String authorization, String body) {
        return postRequest(url, authorization, configFileReader.getContentType(), body);
    }

    /**
     * HTTPClient and HTTP Post clients are used to create a method for constructing and executing POST API Request
     *
     * @param url           target server
     * @param authorization Header to gain access
     * @param body          request body that needs to be sent
     * @param contentType   the format of the request body
     * @return response
     */

    public HttpResponse postRequest(String url, String authorization, String contentType, String body) {
        try {
            setHttpClient();
            HttpPost postRequest = new HttpPost(url);
            postRequest.setHeader("Authorization", authorization);
            postRequest.setHeader("Content-Type", contentType);
            StringEntity stringEntity = new StringEntity(body);
            postRequest.getRequestLine();
            postRequest.setEntity(stringEntity);
            return client.execute(postRequest);
        } catch (ClientProtocolException cpe) {
            System.out.println("Error in client protocol");
            cpe.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * HTTPClient and HTTP Delete clients are used to create a method for constructing and executing DELETE API Request
     *
     * @param url           target server
     * @param authorization Header to gain access
     * @return response
     */
    public HttpResponse deleteRequest(String url, String authorization) {
        try {
            setHttpClient();
            HttpDelete deleteRequest = new HttpDelete(url);
            deleteRequest.setHeader("Authorization", authorization);
            return client.execute(deleteRequest);
        } catch (ClientProtocolException cpe) {
            System.out.println("Error in client protocol");
            cpe.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Convert username and password to a 64 bit string
     *
     * @param username Value is fetched from config file
     * @param password Value is fetched from config file
     * @return encoded string
     */
    public String base64Encoder(String username, String password) {
        String authString = username + ":" + password;
        Base64.Encoder encoder = Base64.getEncoder();
        String encodedString = encoder.encodeToString(authString.getBytes());
        return encodedString;

    }

    public String base64Encoder( String password) {
        String authString = password;
        Base64.Encoder encoder = Base64.getEncoder();
        String encodedString = encoder.encodeToString(authString.getBytes());
        return encodedString;

    }
    /**
     * Function to create the basic auth token string
     *
     * @param username Value is fetched from config file
     * @param password Value is fetched from config file
     * @return basic auth token string
     */
    public String basicAuthGenerator(String username, String password) {
        String authorization = "Basic " + base64Encoder(username, password);
        if (authorization != null) {
            return authorization;
        }
        return null;
    }

    /**
     * Function to execute http methods using rest assured code
     * @param url of the web service api
     * @param headersList headers to authenticate
     * @param body only specific to put and post methods
     * @return response of the api call
     */
    public Response execRequest(Method method, String url, List<Header> headersList, String body){
        httpRequest = RestAssured.given();
       return execRequest(httpRequest, method, url, headersList, body);
    }

    /**
     * Overloaded method to handle a custom httpRequest
     * @param httpRequest custom httprequest to handle multipart/mixed request body
     * @param method http method
     * @param url request url
     * @param headersList headers to authenticate
     * @param body only specific to put and post methods
     * @return response of the api call
     */
    public Response execRequest(RequestSpecification httpRequest, Method method, String url, List<Header> headersList, String body){

        setHttpClient();
        Headers header = new Headers(headersList);
        httpRequest.headers(header);
        if((method.equals(Method.PUT) || method.equals(Method.POST)) && body != null){
            httpRequest.body(body);
        }
        response = httpRequest.request(method, url);
        return response;
    }

    /**
     * Set API Proxy settings to execute on network
     */
    public Proxy setAPIProxy()
    {
        String proxyHost[]=configFileReader.getProxyURL().split(":");
        Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyHost[0], Integer.valueOf(proxyHost[1])));
        return proxy;
    }
    /**
     * Set Trust-manager -  to ignore the PKIX path building exception
     */
    public void setTrustManager() throws CertificateException {
        TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
            //Implements the method in X509 Trustmanager
            public X509Certificate[] getAcceptedIssuers() {
                return null;
            }
            //Implements method in X509TrustManager (javax.net.ssl)
            public void checkClientTrusted(X509Certificate[] certs, String authType) {
            }
            //Implements method in X509TrustManager (javax.net.ssl)
            public void checkServerTrusted(X509Certificate[] certs, String authType) {
            }
        }};

        // Install the all-trusting trust manager
        try {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, trustAllCerts, new SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        } catch (Exception e) {
            throw new CertificateException("Certificate not valid or trusted.");
        }
    }


    /**
     * Method to Execute the API request by configuring the list of headers for the given URL
     * @param url
     * @param headers
     * @param method
     */
    public HttpURLConnection execRequest(String url, String method, Map<String,String> headers) throws Exception
    {
        System.out.println(url);
        setTrustManager();
        URL obj = new URL(url);
        HttpURLConnection urlConnection =(HttpURLConnection) obj.openConnection();
        urlConnection.setRequestMethod(method);
        Set<String> headerKeys=headers.keySet();
        for(String headerValue:headerKeys)
            urlConnection.setRequestProperty(headerValue,headers.get(headerValue));
        return urlConnection;
    }

    /**
     * Method to Execute the API request by configuring the list of headers for the given URL along with Request Body
     * @param url
     * @param headers
     * @param method
     * @param Body
     */
    public HttpURLConnection execRequest(String url, String method, Map<String,String> headers,String Body) throws Exception
    {
        System.out.println(url);
        setTrustManager();
        URL obj = new URL(url);
        HttpURLConnection urlConnection =(HttpURLConnection) obj.openConnection();
        urlConnection.setRequestMethod(method);
        urlConnection.setDoOutput(true);
        Set<String> headerKeys=headers.keySet();
        headers.put("Content-Length",Integer.toString(Body.length()));
        for(String headerValue:headerKeys) {
            urlConnection.setRequestProperty(headerValue, headers.get(headerValue));
        }
        try (DataOutputStream dos = new DataOutputStream(urlConnection.getOutputStream())) {
            dos.writeBytes(Body);
        }
        return urlConnection;
    }

    /**
     * Method to get the Default Header values
     *
     */
    public HashMap<String,String> getDefaultHeaders()
    {
        HashMap<String,String> headers=new HashMap<>();
        headers.put("Connection","keep-alive");
        headers.put("Content-Type",configFileReader.getContentType());
        headers.put("User-Agent", "Mozilla/5.0");
        headers.put("Accept","*/*");
        return headers;
    }
    /**
     * Method to get the response code based on urlconnection
     * @param urlConnection
     */
    public int getResponseCode(HttpURLConnection urlConnection) throws Exception
    {
        return urlConnection.getResponseCode();
    }


    /**
     *  Method to verify the response value based on the key from the JSON Array Response
     * @param response
     * @param key
     * @param value
     * @param parentName
     */
    public boolean verifyValueOnJsonArray(StringBuffer response,String parentName,String key,String value) throws Exception
    {
        boolean executionFlag=false;
        JSONArray array=commonMethods.getJSONArrayOnResponse(response,parentName);
        for(int iterator=0;iterator<array.length();iterator++) {
            JSONObject jsonArrayResponse = (JSONObject) array.get(iterator);
            String jsonArray=jsonArrayResponse.get(key).toString();
            if(jsonArray.equalsIgnoreCase(value)) {
                executionFlag = true;
                break;
            }
        }
        return executionFlag;
    }

    /**
     *  Method to get a value from the response by passing the key
     */
    public String getValueFromResponseBody(StringBuffer response,String key) throws Exception {
        JSONObject jsonResponse=new JSONObject(response.toString());
        return jsonResponse.get(key).toString();
    }

    /**
     *  Method to get json request body by passing file name
     * @param fileName
     */
    public JSONObject getRequestBody(String fileName) throws Exception {
        String request = dataSetup.loadJSONAsString(configFileReader.getRequestBodyDataPath()+fileName+".json");
        JSONObject requestBody=new JSONObject(request);
        return requestBody;
    }



    /**
     *  Method to get a docType Value from the response
     * @param response
     * @param docTypeValue
     */

    public String getSchmeaIdFromResponse(StringBuffer response, String docTypeValue) {
        String docTypeId=null;
        JSONObject responseValue= commonMethods.getJSONValueOnXML(response.toString());
        responseValue=responseValue.getJSONObject("RegisterSchema");
        responseValue=responseValue.getJSONObject("SearchSchemaFields");
        JSONArray jsonArray = (JSONArray) responseValue.get("MultiValueSchemaField");
        for(int iterator=0;iterator<jsonArray.length();iterator++) {
            responseValue = jsonArray.getJSONObject(iterator);
            String identifier=responseValue.get("Identifier").toString();
            if(identifier.equalsIgnoreCase("doctype"))
            {
                responseValue = responseValue.getJSONObject("SchemaValues");
                jsonArray = (JSONArray) responseValue.get("SchemaValue");
                for (int iterator1 = 0; jsonArray.length() > iterator1; iterator1++) {
                    responseValue = jsonArray.getJSONObject(iterator1);
                    if (responseValue.get("Value").toString().equals(docTypeValue)) {
                        docTypeId = responseValue.get("Id").toString();
                        break;
                    }
                }
                break;
            }
        }
        return docTypeId;
    }

    /**
     * Generate the basic auth credentials for api requests
     *
     * @param userId userId to retireve the password and generate the auth credentials
     * @return basic auth string
     */
    public String basicAuthCredentialsProvider(String userId) {
        return basicAuthGenerator(commonMethods.getUserData(userId, "username"), commonMethods.getUserData(userId, "password"));
    }

    /**
     * The tags have to capitalized to meet the format for the API request body
     *
     * @param input      XML String to be capitalized
     * @param searchChar the patterns after which the character is capitalized
     * @return the converted capitalized string
     */
    public String capitalizeXMLTags(String input, String searchChar) {
        char[] convertedCharArr = input.toCharArray();
        int index = input.indexOf(searchChar);
        //Iterating through the string and converting a character to capital letter afer matching
        while (index >= 0) {
            int replacePos = index + searchChar.length();
            convertedCharArr[replacePos] = Character.toUpperCase(convertedCharArr[replacePos]);
            index = input.indexOf(searchChar, replacePos + 1);
        }
        return new String(convertedCharArr);
    }

    public static void main(String args[]) {
        APIHelper apiHelper = new APIHelper();
        System.out.println(apiHelper.base64Encoder("Audhi@1234"));
    }

}
