package com.oracle.babylon.Utils.helper;


/**
 * This class is for Linux Commands and methods
 */

public class LinuxOperations {

    public final static String createDirectory = "sudo mkdir";
    public final static String removeFile = "sudo rm -rf";
    public final static String copyFile = "sudo cp";
    public final static String unzipFile = "sudo unzip -o";
    public final static String setFilePermission = "sudo chmod -R 777";
    public final static String changeOwner = "sudo chown -R opc:opc";
    public final static String changeDirectory = "sudo cd";

    CommonMethods commonMethods = new CommonMethods();

    /**
     * Method to change file owner
     */
    public void changeFileOwner(String path, String folderName) {
        commonMethods.runCommands(changeOwner + " " + path + "/" + folderName);
    }

    /**
     * Method to create a new folder
     */
    public void createFolder(String path, String folderName) {
        commonMethods.runCommands(createDirectory + " " + path + "/" + folderName);
    }

    /**
     * Method to set file permissions
     */
    public void setFilePermissions(String path, String folderName) {
        commonMethods.runCommands(setFilePermission + " " + path + "/" + folderName);
    }

    /**
     * Method to remove files from folder
     */
    public void removeFile(String path, String folderName, String fileName) {
        commonMethods.runCommands(removeFile + " " + path + "/" + folderName + "/*" + fileName.split("\\.")[0] + "*");
    }

    /**
     * Method to extract zip files in a specific folder
     */
    public void extractZipFile(String path, String fileName, String folderName) {
        changeFileOwner(path, folderName);
        setFilePermissions(path, folderName);
        commonMethods.runCommands(unzipFile + " " + path + "/" + fileName + " -d " + path + "/" + folderName);
        changeFileOwner(path, folderName);
        setFilePermissions(path, folderName);
    }

    /**
     * Method to copy files
     */
    public void copyZipFile(String path, String folderName, String fileName) {
        System.out.println(fileName);
        commonMethods.runCommands(copyFile + " " + fileName + " " + path + "/" + folderName);
        changeFileOwner(path, folderName);
        setFilePermissions(path, folderName);
    }

    /**
     * Method to copy files
     */
    public void copyFiles(String path, String folderName, String source) {
        String[] cmd = new String[] {"bash", "-c", "cp -R \"" + source + "\" \"" + path + "/" + folderName + "/\""};
        commonMethods.runCommands(cmd);
        changeFileOwner(path, folderName);
        setFilePermissions(path, folderName);
    }

}
