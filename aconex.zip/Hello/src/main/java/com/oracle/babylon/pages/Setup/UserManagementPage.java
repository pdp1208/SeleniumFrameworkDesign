package com.oracle.babylon.pages.Setup;

import com.oracle.babylon.Utils.helper.Navigator;
import com.oracle.babylon.Utils.setup.utils.ConfigFileReader;
import io.restassured.internal.common.assertion.AssertionSupport;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import static com.codeborne.selenide.Selenide.$;


public class UserManagementPage extends Navigator {

    private By txtBoxSearch = By.xpath("//input[@id='textSearch'] | //div[@id='gm-list']//div[@class='oj-text-field-middle']/input");
    private By btnCreateGroup = By.xpath("//*[contains(text(),'Create Group')]");
    private String tblGroups = "//table[@class='auiTable' or @class='oj-table-element oj-component-initnode']//tr";
    private By btnGroups = By.xpath("//button[contains(text(),'Groups')]");
    private By descriptionTxt = By.xpath("//textarea[@name='description'] | //div[@class='oj-flex-item']//textarea");
    private By lnkFirstGroup = By.xpath("//table[@class='auiTable' or @class='oj-table-element oj-component-initnode']//tr[1]/td//a");
    private By btnFirstGroupDelete = By.xpath("//table[@class='auiTable' or @class='oj-table-element oj-component-initnode']//tr[1]/td[4]//*[@class='auiIcon close' or @class='gm-delete-icon']");
    private By btnDelete = By.xpath("//button[contains(text(),'Delete')]");
    private By txtBoxName = By.xpath("//div[@class='auiForm-field' or @class='oj-flex-item']//input[@name='name' or contains(@id,'input')]");
    private By btnSave = By.xpath("//button[contains(text(),'Save')] | //button//span[text()='Create']");
    private By addUserBtn = By.xpath("//button[contains(text(),'Add Users')]");
    private By btnAddUsers = By.xpath("//div[contains(text(),'Add Users')]");
    private By txtBoxUsers = By.xpath("//div[@class='auiModal-body' or @class='gm-form-container gm-user-form']//input[@type='search'or contains(@id,'input')]");
    private By btnAddUser = By.xpath("//button[contains(text(),'Add Users')] | //button//span[text()='Add']");
    private By btnBack = By.xpath("//button[@class='auiButton back'] | //button//span[@class='oj-ux-ico-close']");
    private By btnRemove = By.xpath("//button[contains(text(),'Remove')]");
    private By removeIcon = By.xpath("//*[@class='auiIcon close'] | //div[@id='gm-drawer_layer']//button//span[@class='gm-delete-icon']");
    private By noRolesAssigned = By.xpath("//div[@class='groupManagement-roleAssignment']//*[contains(text(),'No roles assigned')]");
    private By rolesAssigned = By.xpath("//div[@class='groupManagement-roleAssignment']//a[@class='auiIcon edit pull-right']");
    private By bidiSearch = By.id("bidiSearch");
    private By addItemToList = By.xpath("//button[@title='Add item to list']");
    private By removedItemFromList = By.xpath("//button[@title='Remove item from list']");
    private By backBtnOnUsers = By.xpath("//button[@class='auiButton back']");
    private By selectGrpId = By.xpath("//select[@ng-model='currentGroupId']");
    private By details = By.xpath("//h3[contains(text(),'Details')]");
    private By detailsEdit = By.xpath("//h3[contains(text(),'Details')]//a");
    private By assignedRolesTxt = By.xpath("//h3[text()='Assigned Roles']");
    private By assignedRolesEdit = By.xpath("//h3[text()='Assigned Roles']//a");
    private By editGrpTxt = By.xpath("//*[contains(text(),'Edit Group')]");
    private By assignRolesTxt = By.xpath("//h3[contains(text(),'Assign Roles')]");
    private By searchValues = By.xpath("//*[@class='ui-select-choices-row-inner' or @class='oj-listbox-drop-layer']//div");
    private By closeAddUsers = By.xpath("//div[@class='auiModal-close']");
    private By btnCreate = By.xpath("//button//span[text()='Create']");
    private By txtBoxAssignRole = By.xpath("//ul[@class='oj-combobox-choices oj-combobox-accessible-container']//input");
    private By btnUpdate = By.xpath("//button//span[text()='Update']");
    private By txtBoxSearchUser = By.xpath("//input[@id='textSearch'] | //div[@id='gm-drawer_layer']//div[@class='oj-text-field-middle']/input");
    private String groupPath = configFileReader.getGroupManagementDataPath();

    /**
     * Function to navigate to User Management tab
     */
    public void navigateAndVerifyPage() {
        commonMethods.waitForElementExplicitly(2000);
        getMenuSubmenu("Setup", "User Management");
        // if (ConfigFileReader.getApplicationUrl().toLowerCase().contains("hk1")) {
        By xpath = By.xpath("//div[@title= 'Application Name' and text()='Groups']");
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, xpath, 60);
        $(xpath).isDisplayed();
        //} else
        //  verifyPageTitle("User Management");
    }

    /**
     * Function to search for group by passing group name
     *
     * @param groupName
     */
    public void searchGroup(String groupName) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, txtBoxSearch, 30);
        $(txtBoxSearch).click();
        commonMethods.waitForElementExplicitly(1000);
        $(txtBoxSearch).clear();
        commonMethods.waitForElementExplicitly(1000);
        $(txtBoxSearch).sendKeys(groupName);
//        commonMethods.enterTextValue(txtBoxSearch, groupName);
    }

    /**
     * Function to click on Create group
     */
    public void clickCreateGroup() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, btnCreateGroup, 30);
        $(btnCreateGroup).click();
    }

    /**
     * Function to click on first group name
     */
    public void clickFirstGroup() {
        verifyAndSwitchFrame();
        $(lnkFirstGroup).click();
    }

    /**
     * Function to delete first group
     */
    public void deleteFirstGroup() {
        verifyAndSwitchFrame();
        $(btnFirstGroupDelete).click();
    }

    /**
     * Function to delete groups
     */
    public void deleteGroups(String groupName) {
        verifyAndSwitchFrame();
        String[] names = groupName.split(",");
        for (String group : names) {
            if (verifyGroup(groupName)) {
                commonMethods.waitForElementExplicitly(3000);
                    $(By.xpath(tblGroups + "//td//a[contains(text(),'" + group.trim() + "')]//..//..//td//*[@class='auiIcon close' or @class='gm-delete-icon']")).click();
                commonMethods.waitForElementExplicitly(2000);
                if ($(btnDelete).isDisplayed()) {
                    commonMethods.waitForElement(driver, btnDelete, 10);
                    Assert.assertTrue("Group is not deleted successfully", $(By.xpath("//div[contains(text(),'Delete the " + group.trim() + " group?')]")).isDisplayed());
                    $(btnDelete).click();
                }
            }
        }
    }

    /**
     * Function to create group with random name
     */
    public String createGroup() {
        clickCreateGroup();
        String name = faker.name().firstName().replaceAll("[^a-zA-Z0-9]+", "");
        commonMethods.waitForElement(driver, txtBoxName, 10);
        commonMethods.enterTextValue(txtBoxName, name);
        commonMethods.clickOnElement(btnSave);
        verifyGroup(name);
        return name;
    }

    /**
     * Function to create group with user specified name
     */
    public void createGroup(String groupName) {
        clickCreateGroup();
        commonMethods.waitForElement(driver, txtBoxName, 10);
        String grpName = faker.name().name().replaceAll("[^a-zA-Z0-9]+", "");
        commonMethods.enterTextValue(txtBoxName, grpName);
        commonMethods.clickOnElement(btnSave);
        commonMethods.waitForElementExplicitly(5000);
        verifyGroup(grpName);
        commonMethods.writeGroupToJson(groupName, grpName);
    }

    /**
     * Function to verify group present
     */
    public boolean verifyGroup(String groupName) {
        commonMethods.waitForElementExplicitly(1000);
        return $(By.xpath(tblGroups + "/td/a[contains(text(),'" + groupName + "')]")).isDisplayed();
    }

    /**
     * Function to verify group present
     */
    public boolean verifyDescription(String description) {
        return $(By.xpath(tblGroups + "td[contains(text(),'" + description + "')]")).isDisplayed();
    }

    /**
     * Function to open the group
     */
    public void clickOnGroup(String groupName) {
        searchGroup(groupName);
        commonMethods.waitForElementExplicitly(2000);
        clickFirstGroup();
    }

    /**
     * Function to click on Add Users
     */
    public void clickAddUsers() {
        verifyAndSwitchFrame();
        if ($(btnAddUsers).isDisplayed())
            $(btnAddUsers).click();
    }

    /**
     * Function to Add users
     */
    public void addUsers(String users) {
        clickAddUsers();
        commonMethods.waitForElement(driver, txtBoxUsers, 10);
        String[] names = users.split(",");
		for (String user : names) {
			String userName = commonMethods.getUserData(user, "name");
			for (int i = 0; i < 2; i++) {
				$(txtBoxUsers).click();
				$(txtBoxUsers).sendKeys(userName);
				commonMethods.waitForElementExplicitly(2000);
				By xpath = By.xpath("//div[@class='oj-listbox-drop oj-listbox-drop-multi']//li//*[contains(text(),'"
						+ userName + "')]");
				if ($(xpath).isDisplayed()) {
					$(xpath).click();
					break;
				} else {
					$(txtBoxUsers).sendKeys(Keys.ENTER);
				}
			}
		}
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.clickOnElement(btnAddUser);
    }

    /**
     * Function to go back to groups home screen
     */
    public void backToGroups() {
        if ($(btnBack).exists()) $(btnBack).click();
        commonMethods.waitForElement(driver, btnCreateGroup, 20);
    }

    /**
     * Function to delete users from group
     */
    public void deleteUser(String users, String groupName) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, btnAddUsers, 20);
        String[] names = users.split(",");
        for (String user : names) {
            if (verifyUser(commonMethods.getUserData(user, "name"))) {
                $(By.xpath(tblGroups + "/td[contains(text(),'" + user.trim() + "')]/../td[5]/div")).click();
                commonMethods.waitForElement(driver, btnDelete, 10);
                Assert.assertTrue($(By.xpath("//div[contains(text(),'Remove " + user.trim() + " from the " + groupName + " group?')]")).isDisplayed());
                $(btnRemove).click();
            }
        }
    }

    /**
     * Function to verify user present
     */
    public boolean verifyUser(String user) {
        commonMethods.waitForElementExplicitly(2000);
        return $(By.xpath(tblGroups + "/td[contains(text(),'" + user + "')]")).isDisplayed();
    }

    /**
     * Function to assert disabled users
     */
    public void verifyDisabledUser(String users) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, btnAddUsers, 20);
        String[] names = users.split(",");
        for (String user : names) {
            if (verifyUser(commonMethods.getUserData(user, "name"))) {
                Assert.assertEquals("Disabled", $(By.xpath(tblGroups + "/td[contains(text(),'" + user.trim() + "')]/../td[4]/div")).getText());
            }
        }
    }

    /**
     * Function to remove user
     */
    public void removeUser() {
        commonMethods.waitForElement(driver, removeIcon, 60);
        $(removeIcon).click();
        commonMethods.waitForElementExplicitly(2000);
        if ($(btnRemove).isDisplayed()) {
            commonMethods.waitForElement(driver, btnRemove, 10);
            $(btnRemove).click();
        }
    }

    /**
     * Method to verify removed user
     *
     * @param user
     * @return
     */
    public boolean verifyRemovedUser(String user) {
        By userDetails = By.xpath("//td[contains(text(),'" + user.trim() + "')]");
        return $(userDetails).isDisplayed();
    }

    /**
     * Method to verify no roles assigned
     */
    public boolean verifyNoRolesAssigned() {
//        commonMethods.waitForElement(driver, noRolesAssigned, 60);
        return $(noRolesAssigned).isDisplayed();
    }

    /**
     * Click on roles assigned
     */
    public void clickRolesAssigned() {
        commonMethods.waitForElement(driver, rolesAssigned);
        $(rolesAssigned).click();
    }

    /**
     * Assign Role
     *
     * @param roleName
     */
    public void assignRole(String roleName) {
        commonMethods.waitForElement(driver, bidiSearch, 60);
        $(bidiSearch).sendKeys(roleName);
        $(By.xpath("//*[@class='bidi-available']//option[text()='" + roleName + "']")).click();
        $(addItemToList).click();
        clickSaveBtn();
    }

    /**
     * verify role
     *
     * @param orgRole
     */
    public void verifyOrgRole(String orgRole) {
        By element = By.xpath("//div[@class='groupManagement-roleAssignment' or @class='oj-text-field-container']//li//*[text()='" + orgRole + "']");
        commonMethods.waitForElement(driver, element);
        $(element).exists();
    }

    /**
     * Removed assigned role
     *
     * @param roleName
     */
    public void removeAssignedRole(String roleName) {
        $(By.xpath("//*[@class='bidi-selected']//*[@class='sorted']//option[text()='" + roleName + "']")).click();
        $(removedItemFromList).click();
        clickSaveBtn();
    }

    /**
     * Function to verify UI screen
     */
    public void verifyUserManagementScreen() {
        commonMethods.waitForElement(driver, btnCreateGroup, 30);
        Assert.assertTrue($(btnCreateGroup).isDisplayed());
        Assert.assertTrue($(btnGroups).isDisplayed());
        Assert.assertTrue($(txtBoxSearch).isDisplayed());
    }

    /**
     * Function to verify GroupDetailsScreen
     */
    public void verifyGroupDetailsScreen() {
        Assert.assertTrue($(selectGrpId).isDisplayed());
        Assert.assertTrue($(details).isDisplayed());
        Assert.assertTrue($(assignedRolesTxt).isDisplayed());
    }

    /**
     * Function to verify Edit Details window
     */
    public void verifyEditDetailsWindow() {
        $(detailsEdit).click();
        Assert.assertTrue($(editGrpTxt).isDisplayed());
        $(btnCancel).click();
        $(assignedRolesEdit).click();
        commonMethods.waitForElement(driver, assignRolesTxt, 30);
        Assert.assertTrue($(assignRolesTxt).isDisplayed());
        $(btnCancel).click();
    }

    /**
     * Function to edit group name
     *
     * @param name
     */
    public void editGroupName(String name) {
        $(detailsEdit).click();
        commonMethods.waitForElement(driver, txtBoxName, 10);
        $(txtBoxName).clear();
        commonMethods.enterTextValue(txtBoxName, name);
        commonMethods.clickOnElement(btnSave);
        commonMethods.waitForElementExplicitly(5000);
    }

    /**
     * Function to search users with last name, org and first chars of first and last name
     *
     * @param user
     * @param value
     */
    public void searchUser(String user, String value) {
        clickAddUsers();
        commonMethods.waitForElement(driver, txtBoxUsers, 10);
        $(txtBoxUsers).click();
        String fullName = commonMethods.getUserData(user, "name");
        String[] names = fullName.split("\\s+");
        String str = new StringBuilder().append(names[0].charAt(0)).append(names[1].charAt(0)).toString();
        if (value.equalsIgnoreCase("lastName")) {
            $(txtBoxUsers).sendKeys(names[1].toString());
        } else if (value.equalsIgnoreCase("Organization")) {
            $(txtBoxUsers).sendKeys(commonMethods.getUserData(user, "organisation"));
            commonMethods.waitForElementExplicitly(2000);
            Assert.assertTrue($(searchValues).isDisplayed());
        } else {
            $(txtBoxUsers).sendKeys(str.replace("", " ").trim());
        }
        commonMethods.waitForElementExplicitly(2000);
        $(txtBoxUsers).sendKeys(Keys.ENTER);
        commonMethods.clickOnElement(addUserBtn);
    }

    /**
     * Function to search users
     *
     * @param user
     * @param value
     */
    public void searchDifferentUsers(String user, String value) {
        clickAddUsers();
        commonMethods.waitForElement(driver, txtBoxUsers, 10);
        $(txtBoxUsers).clear();
        $(txtBoxUsers).click();
        String fullName = commonMethods.getUserData(user, "name");
        $(txtBoxUsers).sendKeys(fullName);
        commonMethods.waitForElementExplicitly(2000);
        if (value.equalsIgnoreCase("Not Present")) {
            Assert.assertFalse($(searchValues).isDisplayed());
        } else {
            Assert.assertTrue($(searchValues).isDisplayed());
        }
        $(closeAddUsers).click();
    }

    /**
     * Function to verify access level
     *
     * @param user
     * @param access
     */
    public boolean verifyAccessLevel(String user, String access) {
        commonMethods.waitForElementExplicitly(2000);
        return $(By.xpath("//td[text()='" + access + "']//..//td[text()='" + user + "']")).isDisplayed();
    }

    /**
     * Assign Role for new screen
     *
     * @param roleName
     */
    public void assignRoleNewScreen(String roleName) {
        commonMethods.waitForElement(driver, txtBoxAssignRole, 60);
        $(txtBoxAssignRole).click();
        $(txtBoxAssignRole).sendKeys(roleName);
        commonMethods.waitForElementExplicitly(2000);
        $(By.xpath("//ul[@class='oj-listbox-results']//li//*[text()='" + roleName + "']")).click();
        commonMethods.waitForElementExplicitly(1000);
        clickOnUpdate();
    }

    /**
     * Function to click on Update group name
     */
    public void clickOnUpdateGroup(String group) {
        By btnUpdate = By.xpath("//a[text()='" + group + "']/ancestor::tbody//td[4]//span[@title='Edit']");
        commonMethods.waitForElement(driver, btnUpdate);
        $(btnUpdate).click();
    }

    /**
     * Function to click on Update button
     */
    public void clickOnUpdate() {
        commonMethods.waitForElement(driver, btnUpdate);
        $(btnUpdate).click();
    }

    /**
     * Function to remove assigned org role
     */
    public void removeAssignedRoleNewScreen(String orgRole) {
        $(By.xpath("//div[text()='" + orgRole + "']/..//span")).click();
    }

    /**
     * Function to search user in a group
     *
     * @param userName
     */
    public void searchUser(String userName) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, txtBoxSearchUser, 30);
        commonMethods.enterTextValue(txtBoxSearchUser, userName);
    }

}

