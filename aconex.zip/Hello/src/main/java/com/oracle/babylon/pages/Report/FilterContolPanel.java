package com.oracle.babylon.pages.Report;

import com.codeborne.selenide.SelenideElement;
import com.oracle.babylon.Utils.helper.Navigator;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;

import java.util.List;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Condition.appears;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

/**
 * Page object class for run time filter section.
 *
 */
public class FilterContolPanel extends Navigator {

    static String confirmationDialogSelector = "//*[contains(@id,'filter-panel')]//div[text()='ColumnName']/following::div";
    By applyButton = By.xpath("//*[contains(text(),'Apply')]");
    private By runTimeFilterColumns = By.xpath("//*[contains(@id,'filter-panel-container')]//div[contains(@class,'auiForm-label')]");
    public By cancelButton = By.xpath("//*[contains(@class,'cancelBtn')]");
    private By okbutton = By.xpath("//*[contains(@class,'applyBtn')]");
    private By filterValues = By.xpath("//*[@class='date-popover']//li");
    private By listFilterValues = By.xpath("//*[@class='sList']//li");
    private String inputElement = "//*[contains(@class,'input')]";
    private String listElement = "//*[@class='sSelect-list']";

    /**
     * Method to open list of filter values for run time filters.
     *
     * @param columnName - Name of the filter column.
     * @return filtervalues
     */
    public List<String> openListOfAvailaleFilterValues(String columnName){
        String confirmationDialogSelecorModified = replaceColumnNameInCommonLocator(columnName);
        List<String> availableFiterValues = null;
        if(!($(By.xpath(confirmationDialogSelecorModified)).getAttribute("class").contains("jstree"))){
            $(By.xpath(confirmationDialogSelecorModified + inputElement)).waitUntil(appears, 5000).click();
            try {
                commonMethods.waitForElement(driver, By.xpath(confirmationDialogSelecorModified + listElement), 5);
            } catch(TimeoutException e){
                //ignore
            }
            if($(By.xpath(confirmationDialogSelecorModified + inputElement)).getAttribute("class").contains("datepicker")){
                $(By.xpath(confirmationDialogSelecorModified + inputElement)).click();
                availableFiterValues = $$(filterValues).texts();
            } else if($(By.xpath(confirmationDialogSelecorModified + "/input")).getAttribute("class").contains("search-filter")){
                return $$(listFilterValues).texts();
            }
        }
        return availableFiterValues;
    }

    /**
     * Method to set filter value in text box.
     *
     * @param columnName - Name of the filter column.
     * @param value - Filter value to set.
     */
    public void setFilterValue(String columnName, String value){
        $(By.xpath(confirmationDialogSelector.replace("ColumnName",columnName) + "/input")).setValue(value);
    }

    /**
     * Method to clear all filter values at run time.
     *
     */
    public void clearAll(){
        for(SelenideElement clearAllBtn:$$(By.xpath("//button[@id='multiSelectDropdownClearAllBtn']"))) {
            if (clearAllBtn != null && clearAllBtn.isDisplayed()) {
                clearAllBtn.click();
            }
        }
    }

    /**
     * Method to select filter values at run time.
     *
     * @param values - List of filter values.
     */
    public void selectFilterValues(String columnName, List<String> values){
        String confirmationDialogSelecorModified = confirmationDialogSelector.replace("ColumnName", columnName);
        if($(By.xpath(confirmationDialogSelecorModified)).getAttribute("class").contains("jstree")){
            new TreeSelectionPanel($(By.xpath(confirmationDialogSelecorModified))).expand(values);
        } else if($(By.xpath(confirmationDialogSelecorModified)).getAttribute("id").contains("radio")){
            for(String value : values) {
                $(By.xpath(confirmationDialogSelecorModified + "//span[contains(text(),'" + value + "')]/preceding-sibling::input")).click();
            }
        }else if($(By.xpath(confirmationDialogSelecorModified)).getAttribute("id").contains("checkbox")){
            //uncheck all checkboxes
            for(String value : values) {
                $(By.xpath(confirmationDialogSelecorModified + "//input[@name='leftPanelRadioButtons']")).click();
            }
            //check specified checkboxes
            for(String value : values) {
                if($$(By.xpath(confirmationDialogSelecorModified + "//input[@id='" + value + "']")).size()<=0){
                    value = value.replaceAll(" ", "_");
                }
                $(By.xpath(confirmationDialogSelecorModified + "//input[@id='" + value + "']")).click();
            }
        } else if($(By.xpath(confirmationDialogSelecorModified + "/input")).getAttribute("class").contains("datepicker")){
            $(By.xpath(confirmationDialogSelecorModified + "/input")).click();
            $(By.xpath("//*[@class='date-popover']//li[text()='" + values.get(0) +"']")).waitUntil(appears, 5000).click();
            if($(okbutton).isDisplayed()){
                $(okbutton).click();
            }
        }
        else {
            for(String value : values){
                $(By.xpath("//*[@class='sSelect expanded']//input[@title-val='" + value + "']")).click();
            }
        }
    }

    /**
     * Method to set common base locator for confirmation dialog.
     *
     * @param columnName - Name of the column.
     */
    public String replaceColumnNameInCommonLocator(String columnName){
        return confirmationDialogSelector.replace("ColumnName",columnName);
    }

    /**
     * Method to apply filters at run time.
     *
     */
    public void apply(){
        $(applyButton).click();
    }

    /**
     * Method to get available filters at run time.
     *
     */
    public List<String> getAvailableFiltersAtRunTime(){
        return $$(runTimeFilterColumns).texts();
    }


}
