package com.oracle.babylon.pages.Document;

import com.codeborne.selenide.WebDriverRunner;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.oracle.babylon.Utils.helper.CommonMethods;
import com.oracle.babylon.Utils.setup.dataStore.DocumentTableConverter;
import com.oracle.babylon.Utils.setup.dataStore.pojo.Document;
import com.oracle.babylon.Utils.setup.utils.ConfigFileReader;
import com.oracle.babylon.pages.Mail.MailPage;
import io.cucumber.datatable.DataTable;
import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.util.*;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;
import static com.codeborne.selenide.Selenide.actions;

/**
 * Class that contains all the methods specific to the Document Register page
 */
public class DocumentRegisterPage extends DocumentPage {

    //Initialization of Web Elements
    private By transmitBtn = By.xpath("//button[contains(text(),'Transmit')]");
    private By createTransmittal = By.xpath("//div[@class='auiMenuButton-dropdownContents']//a[contains(text(),'Create a Transmittal')]");
    private By createTenderTransmittal = By.xpath("//div[@class='auiMenuButton-dropdownContents']//a[contains(text(),'Create a Tender Transmittal')]");
    private By createWorkFlow = By.xpath("//div[@class='auiMenuButton-dropdownContents']//a[contains(text(),'Start a Workflow')]");
    private By selectIdsCheckbox = By.name("selectedIdsInPage");
    private By firstDocumentChkBox = By.xpath("//div[@class='ag-pinned-left-cols-container']/div[1]/div[1]/div/span[1]");
    private By pageTitle = By.xpath("//div[@id='header']//h1");
    private By documentLink = By.xpath("//div[@col-id='title']//div//a");
    private By loadingIcon = By.cssSelector(".loading_progress");
    private By revision = By.xpath("//div[@col-id='revision']");
    private By startWorkFlow = By.xpath("//a[@class='ng-binding ng-scope'][contains(text(),'Start a Workflow')]");
    private By copyToProject = By.xpath("//div[@class='auiMenuButton-dropdownContents']//a[text()='Copy to Project']");
    private By updateProjectCopies = By.xpath("//div[@class='auiMenuButton-dropdownContents']//a[text()='Update Project Copies']");
    private By updateProjectCopiesBtn = By.xpath("//div[contains(text(),'Update Project Copies')]");
    private By documentsUpdated = By.xpath("//div[contains(text(),'Your documents have been updated')]");
    private By projectUpdatedTxt = By.xpath("//p[text()='All target projects have copies of the latest revision.']");
    private By supersedeCopiesTitle = By.xpath("//h1[text()='Project Copy Update - Superseded Copies Report']");
    private By UpdateProjectCopiesBtn = By.xpath("//div[contains(text(),'Update Project Copies')]");
    private By selectProject = By.xpath("//select[@name='PROJECT_ID']");
    private By selectDoc = By.xpath("//input[@name='DOCCONTROL_SEQUENCE']");
    private By copyBtn = By.xpath("//button[@id='btnCopy']");
    private By updatedEventTxt = By.xpath("//span[contains(text(),'Uploaded (From Project')]");
    private By deniedMessage = By.xpath("//h1[contains(text(),'Permission denied')]");
    private By linkSelectAll = By.xpath("//span[text()='Select All']");
    private By linkSelectAllPage = By.xpath("//span[@class='ag-icon ag-icon-checkbox-unchecked']");
    private By nextPageBtn = By.xpath("//div[@class='auiPagination-list ng-scope']//button[contains(text(),'Next')]");
    private By numberOfPages = By.xpath("// div[@class='auiPagination-manualPage']//span[2]");
    private By savedSearchesDropdownBtn = By.xpath("//div[@id='savedSearchButtonText']");
    private By documentOption = By.xpath("//div[@class='ag-pinned-left-cols-container']/div[1]/div[1]//div/span[2]/div");
    private By docPropertyOption = By.xpath("//a[contains(text(),'Properties')]");
    private By docEventLog = By.xpath("//a[contains(text(),'Event Log')]");
    //private By docSupersedeOption = By.xpath("//a[contains(text(),'Edit / Upload new version')]");
    private By docSupersedeOption = By.xpath("//a[text()='Update']");
    private By viewerOption = By.xpath("//a[@id='onlineViewer']");
    private By confidentialDocument = By.xpath("//div[@class='ag-pinned-left-cols-container']/div[1]/div[1]/div//span[@title='This document is confidential']");
    private By settionsIcon = By.xpath("//div[@class='filter-list ng-scope']//i[@class='auiText-right icon-settings']");
    private By unLockImage = By.xpath("//div[@col-id='lock']//img[@src='/html/Images/ic_unlock.gif']");
    private By lockImage = By.xpath("//div[@col-id='lock']//img[@src='/html/Images/ic_lock.gif']");
    private By shareBtn = By.xpath("//button[contains(text(),'Share')]");
    private By shareDocumentsLink = By.xpath("//div[@class='auiMenuButton-dropdownContents']//a[contains(text(),'Share Documents')]");
    private By shareToAllBtn = By.xpath("//button[@title='Share documents to all project members']");
    private By optionBtn = By.xpath("//div[contains(text(),'Options')]");
    private By exportToExcelBtn = By.xpath("//div[contains(text(),'Export to Excel')]");
    private By backBtn = By.xpath("//button[@id='btnBack']//div[@class='uiButton-content']");
    private By printBtn = By.xpath("//div[contains(text(),'Print')]");
    private By temporaryFilesBtn = By.xpath("//div[contains(text(),'Temporary Files')]");
    private By addUserBtn = By.xpath("//div[contains(text(),'Add')]");
    private By downloadFile = By.xpath("//div[@row-id='0']//span//div[@class='fileTypeTemplate']//img");
    private By reportsOptions = By.xpath("//div[@class='auiMenuButton-dropdownContents']//a");
    private By optionsBtn = By.xpath("//button[@id='btnOptions']");
    private By bulkSupersedeHeader = By.xpath("//h1[contains(text(),'Bulk Supersede')]");
    private final By selectEntirePage = By.xpath("//div[contains(text(),'Select entire page')]//img");
    private By drawingTxt = By.xpath("//div[@class='saved-search-list ng-isolate-scope']");
    private By markUpIcon = By.xpath("//span[contains(@title,'This file has')]");
    private By lnkWantToUploadNewDoc = By.xpath("//span[contains(text(),'Want to upload a new document?')]");
    private By btnAddDocument = By.xpath("//div[@id='documentResults']//a[contains(text(),'Add/Update Documents')]");
    private By btnAddDocumentsTransmitTool = By.xpath("//a[text()='Add/Update Documents']/../aui-menu-button/button");
    private By txtTotalPages = By.xpath("//div[@class='auiPagination-manualPage']//span[2]");
    private By btnNext = By.xpath("//div[@class='auiPagination-list ng-scope']/button[text()='Next']");
    private By txtBoxStartPage = By.xpath("//div[@class='auiPagination-manualPage']/input");
    private By lnkFirstPage = By.xpath("//a[text()='First page']");
    private By msgCheck = By.xpath("//div[@class='message check']");
    private By getConfidentialStatus = By.xpath("//div[@col-id='confidential' and @role='gridcell']");
    private By resultsColHeaders = By.xpath("//acx-search-ag-grid//div[@class='customHeader-label']");
    Actions actions = new Actions(driver);
    private By groupName = By.xpath("//input[@name='FIRST_NAME']");
    private By familyName = By.xpath("//input[@name='LAST_NAME']");
    private By selectRecipientSearch = By.xpath("//button[@id='btnSearch_page']");
    private By selectRecipientCheckbox = By.xpath("//input[@name='USERS_LIST']");
    private By selectRecipientOkBtn = By.xpath("//button[@id='btnOk']");
    private By selectRecipientToBtn = By.xpath("//div[@class='flow-right']/button[@id='btnAddTo_page']");
    private By exportMsg = By.xpath("//div[contains(text(),'Export to Excel')]");
    private By docSelectChkBox = By.xpath("(//div[@ref='headerRoot']//div[@class='ag-header-cell']//span)[1]");
    private By btnArrowCollpase = By.xpath("//div[@class='document-search full-mode expanded']//div[contains(@class,'oj-icon')]");
    private By btnArrowExpand = By.xpath("//div[@class='document-search full-mode']//div[contains(@class,'oj-icon')]");
    Actions action = new Actions(driver);
    DocumentPropertiesPage documentPropertiesPage = new DocumentPropertiesPage();
    private MailPage mailPage = new MailPage();

    //saved search;
    protected By searchBtn = By.xpath("//button[@class='auiButton primary ng-binding']");
    private By savedSearchBtn = By.xpath("//button[@id='savedSearchButton']");
    private By savedSearchOptions = By.xpath("//div[@class='filter-list ng-scope']//strong");
    private By saveSearchAsBtn = By.xpath("//button[@title='Save the current search configuration' and contains(text(),' Save Search As...')]");
    private By searchName = By.xpath("//div[@class='form-field']//input[@type='text']");
    private By saveOkBtn = By.xpath("//input[@title='Save']");
    private By deleteBtn = By.xpath("//button[@title='Delete this item']");
    private By confirmDeleteBtn = By.xpath("//button[contains(text(),'Yes, Delete')]");
    private By historyDocumentResultCount = By.xpath("//div[@id='searchResultsContainer']//div[@class='searchNav clearFloats']//div[@class='flow-left']/b[2]");
    private By historyOrganisationDocCount = By.xpath("//div[@id='searchResultsContainer']/div[@class='searchNav clearFloats'][1]/div/b[2]");
    //saved search
    private By saveSearchErrorMessage = By.xpath("//div[contains(text(),'A saved search already exists with that name. Please enter a different name')]");
    private By confidentialMark = By.xpath("//span[@title='This document is confidential']");
    protected By toolsBtn = By.xpath("//button[contains(.,'Tools')]");
    private By markNoLongerInUse = By.xpath("//a[contains(.,'Mark as No Longer in Use')]");
    private By noLongerInUseWarningMsg = By.xpath("//div[contains(text(),'This action will hide the selected documents in your register and also in the register of all organizations the documents have been transmitted to.')]");
    private By markNoLongerInUseBtn = By.xpath("//div[@class='uiButton-content']/div[contains(.,'Mark as No Longer in Use')]");
    private By candidateDocNo = By.xpath("//div[@col-id='candidateno']");
    private By dots = By.xpath("//span[@class='ag-icon ag-icon-checkbox-checked']//..//..//span//button");
    //private By docRevision = By.xpath("//div[@col-id='revision']");
    private By docRevision = By.xpath("//div[@col-id='revision']/span");
    private By status = By.xpath("//div[@col-id='docstatus']");
    private By discipline = By.xpath("//div[@col-id='discipline']");
    private By supersedeLink = By.xpath("//div[@class='auiMenuButton-dropdown ng-scope']//a[contains(text(),'Update')]");
    private By btnUpdate = By.xpath("//a[text()='Update']");
    private By previewLink = By.xpath("//div[@class='auiMenuButton-dropdownContents']//a[contains(text(),'Preview')]");
    private By openInModelsLink = By.xpath("//a[contains(text(),'Open in Models')]");
    private By previewDownloadBtn = By.xpath("//button[@title='Download']");
    private By previewCloseBtn = By.xpath("//button[@class='uiPanel-closeBox uiPanel-action-icon']");
    private By viewerLink = By.xpath("//a[contains(text(),'Viewer')]");
    private By previewDownload = By.xpath("//button[@title='Download']");
    private By gridPreview = By.xpath("//span[contains(text(),'Preview')]");
    private By restoreAsCurrent = By.xpath("//a[contains(.,'Restore As Current')]");
    private By propertiesLink = By.xpath("//a[contains(.,'Properties')]");
    private By restoreAsCurrentLink = By.xpath("//a[contains(.,'Restore As Current')]");
    private By restoreAsCurrentDisabled = By.xpath("//a[@class='ng-binding ng-scope disabled']");
    private By eventLogLink = By.xpath("//a[contains(.,'Event Log')]");
    private By transmittalHistoryLink = By.xpath("//div[@class='auiMenuButton-dropdownContents']//a[contains(text(),'Transmittal History')]");
    private By documentHistoryCheckBox = By.xpath("//input[@id='isShowDocumentHistory']");
    private By confidentialEventLog = By.xpath("//span[contains(text(),'Confidentiality Enabled')]");
    private By inputRevision = By.xpath("//div[@class='auiForm-field ng-scope']//input[contains(@class, 'auiField-input')]");
    private By searchInputBox = By.xpath("//input[@id='search-keywords-id']");
    private By reportBtn = By.xpath("//button[contains(text(),'Reports')]");
    private By historyDocNo = By.xpath("//div[@id='searchResultsContainer']//tr[contains(@class,'dataRow')]//td[1]");
    private By historyTransmittalNo = By.xpath("//div[@id='searchResultsContainer']//tr[contains(@class,'contentcell dataRow')]//td[4]");
    private By historyRecipientOrg = By.xpath("//div[@id='searchResultsContainer']//tr[contains(@class,'contentcell dataRow')]//td[1]");
    private By historyUploadedBy = By.xpath("//div[@id='searchResultsContainer']//tr[contains(@class,'dataRow')]//td[5]");
    private By historyRecipient = By.xpath("//div[@id='searchResultsContainer']//tr[contains(@class,'contentcell dataRow')]//td[2]");
    private By filterOptionAllDoc = By.xpath("//div[@id='btnOptions_panel']//input[@id='FilterMode_NONE']");
    private By filterOptionDocNeverTransmitted = By.xpath("//div[@id='btnOptions_panel']//input[@id='FilterMode_NEVERTRANSMITTED']");
    private By filterOptionDocByOrg = By.xpath("//div[@id='btnOptions_panel']//input[@id='FilterMode_BYORG']");
    private By filterOptionCancelBtn = By.xpath("//div[contains(text(),'Cancel')]");
    private By filterOptionOkBtn = By.xpath("//div[contains(text(),'OK')]");
    private By historyTransmitBtn = By.xpath("//div[contains(text(),'Transmit')]");
    private By historySearchBtn = By.xpath("//div[@class='uiButton-label'][contains(text(),'Search')]");
    private By historySelectOrg = By.xpath("//div[@id='searchConfig']//select[@id='TRANSMITTAL_HIST_CD_RECIPIENT_ORGID']");
    private By historySelectShow = By.xpath("//div[@id='searchConfig']//select[@id='_TRANSMITTAL_HIST_CD_SHOW_TYPE']");
    private By docReportOptions = By.xpath("//div[@class='auiMenuButton-dropdownContents']/a");
    private By mainPage = By.xpath("//div[@id='main']");
    private By addUser = By.xpath("//button[@id='btnAddUser']");
    private By linkingIcon = By.xpath("//span[@class='linking-icon link-exists']");
    private By saveDocShare = By.xpath("//button[@title='Save changes to share']");
    private By transmittalHistoryByDoc = By.xpath("//div[@class='auiMenuButton-dropdownContents']/a[contains(.,'Transmittal History By Document')]");
    private By transmittalHistoryByOrg = By.xpath("//div[@class='auiMenuButton-dropdownContents']/a[contains(.,'Transmittal History by Organization')]");
    private By transmittalHistoryByAsset = By.xpath("//div[@class='auiMenuButton-dropdownContents']/a[contains(.,'Transmittal History By Asset')]");
    private By exportToExcel = By.xpath("//div[@class='auiMenuButton-dropdownContents']/a[contains(.,'Export to Excel')]");
    private By exportToExcelMessage = By.xpath("//div[@id='messagePanel']//div[@class='auiMessage-content']");
    private By hideConfidential = By.xpath("//div[@class='customSortUpLabel customHeader-sorting active hideElement showElement']");
    private By forwardArrow = By.xpath("//div[@class='uiPanel-navigate uiPanel-navigate-right auiIcon']");
    private By backwardArrow = By.xpath("//div[@class='uiPanel-navigate uiPanel-navigate-left auiIcon']");
    private By lnkEditOrUpload = By.xpath("//div[@class='auiMenuButton-dropdown ng-scope']//a[contains(text(),'Upload')]");
    private By lnkDocOptions = By.xpath("//div[@class='auiMenuButton-dropdownContents']//a");
    private By docRegisterTab = By.xpath("//li[text()='Document Register']");
    private By drawingsTab = By.xpath("//li[text()='Drawings']");
    private By lblZipDwnldMarkup = By.xpath("//div[@class='uiPanel']//span[contains(text(),'Zip Download with Markups')]");
    private By btnZDWMClose = By.xpath("//span[text()='Zip Download with Markups']//following::button[@title='Close']");
    private By dateModifiedDropdown = By.xpath("//div[text()='Date Modified']");
    private By btnUpArrow = By.xpath("//div[@class='updown-container']/button[@title='Move selected items one position up the list']");
    private By btnDownArrow = By.xpath("//div[@class='updown-container']/button[@title='Move selected items one position down the list']");
    private By docNoList = By.xpath("//div[@role='gridcell' and@col-id='docno']//div");
    private By zdwmMessage = By.xpath("//div[contains(text(),'Your Zip Download with Markups job has commenced and will run in the background.')]");
    private By downloadLink = By.xpath("//div[@class='auiMenuButton-dropdownContents']/a[text()='Download']");
    private By savedSearchescription = By.xpath("//div[@class='form-field']//textarea");
    private By dateType = By.xpath("//div[@class='auiForm-field']//acx-date-type-picker");
    private By dateRange = By.xpath("//div[@class='auiForm-field ng-scope']//acx-date-range-picker");
    public static List<String> docList = new ArrayList<>();

    private By startDocumentProcessBtn = By.xpath("//button[text()='Start Document Process']");

    private By addingModelToStacks = By.xpath("//h3[text()='Adding model stacks to Models']");
    private By continueOnModelStacks = By.xpath("//button[contains(text(),'Continue')]");
    private By viewInModels = By.xpath("//*[@class='bim-next-steps']//*[contains(text(),'View in Models')]");

    /**
     * Function to click the transmit button to create a transmittal
     */
    public void clickTransmitBtn() {
        commonMethods.waitForElement(driver, transmitBtn, 40);
        getElementInView(transmitBtn);
        $(transmitBtn).click();
    }

    public DocumentRegisterPage() {
        this.driver = WebDriverRunner.getWebDriver();
    }

    /**
     * Method to navigate to Document and verify for the title of the page
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Documents", "Document Register");
        commonMethods.waitForElementExplicitly(3000);
        Assert.assertTrue("Document Register Page title is not displayed correctly", verifyPageTitle(pageTitle));
    }

    public void verifyPageTitle() {
        verifyPageTitle(pageTitle);
    }

    /**
     * Method to navigate to Document type and verify for the title of the page
     *
     * @param documentType
     */
    public void navigateAndVerifyPage(String documentType) {
        String menu = getDocumentMenuName();
        HashMap<String, String> docMap = CommonMethods.getDocumentTypeDetail(menu);
        try {
            getMenuSubmenu(docMap.get("registermenu"), docMap.get("registersubmenu"));
        } catch (NoSuchElementException e) {
            selectProject(globalProjectName);
            getMenuSubmenu(docMap.get("registermenu"), docMap.get("registersubmenu"));
        }
        verifyPage(docMap.get("registertitle"));
    }

    /**
     * Function to verify Page Title
     *
     * @param page
     */

    public void verifyPage(String page) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, searchInputBox, 60);
        Assert.assertTrue($(pageTitle).text().toLowerCase().contains(page.toLowerCase()));
    }

    /**
     * Function to click the create transmittal link
     */
    public void startWorkflow() {
        verifyAndSwitchFrame();
        clickTransmitBtn();
        $(startWorkFlow).click();
    }

    /**
     * Function to click the create transmittal link
     */
    public void clickCreateTransmittalLink() {
        $(createTransmittal).click();
    }

    /**
     * Function to click the create tender transmittal link
     */
    public void clickCreateTenderTransmittalLink() {
        $(createTenderTransmittal).click();
    }

    public void selectDocAndNavigateToTransmittal() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, firstDocumentChkBox, 30);
        $(firstDocumentChkBox).click();
        clickTransmitBtn();
        clickCreateTransmittalLink();
        driver.switchTo().defaultContent();
    }

    /**
     * Function to select first document and navigate to create tender transmittal
     */
    public void selectDocAndNavigateToTenderTransmittal() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, firstDocumentChkBox, 30);
        $(firstDocumentChkBox).click();
        clickTransmitBtn();
        clickCreateTenderTransmittalLink();
        driver.switchTo().defaultContent();
    }

    /**
     * Function to select first document and navigate to create a workflow
     */
    public void selectDocAndNavigateToWorkflow() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, firstDocumentChkBox, 30);
        $(firstDocumentChkBox).click();
        clickTransmitBtn();
        $(createWorkFlow).click();
        driver.switchTo().defaultContent();
    }

    /**
     * Function to create Transmittal for All documents
     */
    public void createTransmittalForAllDocuments(String value) {
        $(searchBtn).click();
        commonMethods.waitForElementExplicitly(2000);
        if (value.equalsIgnoreCase("All")) {
            commonMethods.waitForElement(driver, linkSelectAll, 25);
            $(linkSelectAll).click();

        } else if (value.equalsIgnoreCase("Multiple")) {
            selectMultipleDocs();
        } else {
            commonMethods.waitForElement(driver, linkSelectAllPage, 25);
            $(linkSelectAllPage).click();
        }
        commonMethods.waitForElementExplicitly(3000);
        clickTransmitBtn();
        clickCreateTransmittalLink();
        driver.switchTo().defaultContent();
    }

    /**
     * Function to create Transmittal for Multiple documents in different page
     */
    public void selectMultipleDocs() {
        commonMethods.waitForElement(driver, numberOfPages, 30);
        int value = Integer.parseInt($(numberOfPages).getText());
        for (int i = 0; i < value; i++) {
            if ($$(unSelectedCheckBox).size() >= i)
                selectDocumentCheckBox(i);
            else selectDocumentCheckBox(1);
            if ($(nextPageBtn).isDisplayed()) {
                commonMethods.waitForElement(driver, nextPageBtn, 30);
                $(nextPageBtn).click();
                commonMethods.waitForElementExplicitly(1000);
            }
        }
    }

    /**
     * Function to create Transmittal for Multiple documents in same page
     */
    public void selectMultipleDocs(int num) {
        commonMethods.waitForElement(driver, numberOfPages, 30);
        for (int i = 0; i <= num - 1; i++) {
            selectDocumentCheckBox(i);
        }
    }

    /**
     * Function to verify permission denied to start workflow
     */
    public void verifyWorkFlowDenied() {
        verifyAndSwitchFrame();
        Assert.assertTrue($(deniedMessage).exists());
    }

    public void openDocument() {
        commonMethods.waitForElement(driver, documentLink, 45);
        $(documentLink).click();
    }

    /**
     * Function to click on the saved search from dropdown
     *
     * @savedSearch is the search name which has to be clicked from the dropdown
     */
    public void selectSavedSearch(String savedSearch) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        By searchName = By.xpath("//span[text()='" + savedSearch + "']");
        actions.moveToElement($(searchName)).click($(searchName)).build().perform();
    }

    /**
     * Click on save search As Button
     */
    public void clickSaveSearchAs() {
        verifyAndSwitchFrame();
        $(saveSearchAsBtn).click();
    }

    /**
     * Function to verify saved search options
     *
     * @param savedSearchValue
     * @return
     */
    public Boolean verifySavedSearchOptions(String savedSearchValue) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        By element = By.xpath("//span[contains(text(),'" + savedSearchValue + "')]");
        getElementInView(element);
        return $(element).isDisplayed();
    }

    /**
     * Function to create saved search in documents
     *
     * @param name
     * @param sharingInfo
     */
    public void createDocumentSavedSearch(String name, String sharingInfo) {
        if (verifyDocumentSavedSearch(name)) {
            deleteDocumentSavedSearch(name);
        }
        verifyAndSwitchFrame();
        clickDocumentSearchInput();
        closeSmartFolders();
        commonMethods.waitForElement(driver, saveSearchAsBtn, 40);
        $(saveSearchAsBtn).click();
        commonMethods.waitForElement(driver, searchName);
        $(searchName).sendKeys(name);
        $(savedSearchescription).sendKeys("This is a " + name + " Saved search");
        commonMethods.waitForElementExplicitly(3000);
        $(By.xpath("//label[text()='" + sharingInfo + "']/..//input")).click();
        commonMethods.waitForElement(driver, saveOkBtn, 2);
        $(saveOkBtn).click();
        commonMethods.waitForElementExplicitly(3000);
    }

    /**
     * Function to verify saved search options
     * 1.Not shared (visible only to creator of this search)
     * 2.Shared with everyone in my organization
     * 3.Shared with everyone on this project
     *
     * @param sharingInfo
     * @return
     */
    public Boolean verifyOptions(String sharingInfo) {
        //commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, saveOkBtn, 30);
        return $(By.xpath("//label[text()='" + sharingInfo + "']/..//input[@disabled='disabled']")).isDisplayed();
    }

    /**
     * Function to verify document saved search
     *
     * @param savedSearch
     */
    public Boolean verifyDocumentSavedSearch(String savedSearch) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(3000);
        clickDocumentSearchInput();
        expandSmartFolders();
        By element = By.xpath("//span[text()='" + savedSearch + "']");
        actions.moveToElement($(drawingTxt)).build().perform();
        if ($(element).isDisplayed()) {
            return true;
        }
        return false;
    }

    /**
     * Function to Delete document saved search
     *
     * @param name
     */
    public void deleteDocumentSavedSearch(String name) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        By element = By.xpath("//span[text()='" + name + "']");
        actions.moveToElement($(element)).build().perform();
        WebElement searchName = $(By.xpath("//li[@title='" + name + "']"));
        WebElement editIcon = $(By.xpath("//span[text()='" + name + "']//..//i[2]"));
        actions.moveToElement(searchName).click(editIcon).build().perform();
        commonMethods.waitForElementExplicitly(1000);
        commonMethods.waitForElement(driver, deleteBtn, 40);
        $(deleteBtn).click();
        commonMethods.waitForElement(driver, confirmDeleteBtn, 40);
        $(confirmDeleteBtn).click();
    }

    /*
     * Function to Edit document saved search
     *
     * @param name is the name which has to be edited
     * @param newName is the new name which has to be given after editing
     * @param sharingInfo is the radio buttons which has to be selected before creating saved search
     */
    public void editDocumentSavedSearch(String name, String newName, String sharingInfo) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        By element = By.xpath("//span[text()='" + name + "']");
        actions.moveToElement($(element)).build().perform();
        WebElement savedSearchName = $(By.xpath("//li[@title='" + name + "']"));
        WebElement editIcon = $(By.xpath("//span[text()='" + name + "']//..//i[2]"));
        actions.moveToElement(savedSearchName).click(editIcon).build().perform();
        commonMethods.waitForElement(driver, searchName, 40);
        $(searchName).clear();
        $(searchName).sendKeys(newName);
        if (sharingInfo != null) {
            commonMethods.waitForElementExplicitly(2000);
            $(By.xpath("//label[text()='" + sharingInfo + "']/..//input")).click();
        }
        commonMethods.waitForElement(driver, saveOkBtn, 3);
        $(saveOkBtn).click();
    }

    /**
     * Function to validate error message if duplicate search name is entered
     *
     * @param name is the name of the search name which is duplicate
     * @return
     */

    public boolean validateDuplicateSavedSearch(String name) {
        $(saveSearchAsBtn).click();
        $(searchName).sendKeys(name);
        $(saveOkBtn).click();
        commonMethods.waitForElement(driver, saveSearchErrorMessage);
        return $(saveSearchErrorMessage).isDisplayed();
    }

    /**
     * Function to verify if confidential docs are present
     *
     * @return
     */
    public boolean verifyConfidentialDocs() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(4000);
        return $(confidentialMark).isDisplayed();
    }

    /**
     * Click on confidential arrow
     */
    public void clickConfidentialArrow() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, hideConfidential, 40);
        if ($(hideConfidential).isDisplayed()) {
            $(hideConfidential).click();
        }

    }

    /**
     * Function to verify if setting icon is present
     *
     * @return
     */

    public boolean verifySettingsIcon() {
        return $(settionsIcon).isDisplayed();
    }

    /**
     * Function to make document as No longer In Use
     */
    public void markDocumentNoLongerInUse() {
        commonMethods.waitForElement(driver, toolsBtn);
        $(toolsBtn).click();
        $(markNoLongerInUse).click();
        markAsNLIU();
    }


    /**
     * Function to click on No Longer In Use Button
     */
    public void verifyNoLongerInUserMsg() {
        commonMethods.waitForElement(driver, toolsBtn);
        $(toolsBtn).click();
        $(markNoLongerInUse).click();
        verifyAlert("You don't have permission to update some of the documents you've selected");
    }

    /**
     * Function to navigate and click on supersede link
     */

    public void clickOnSupersede() {
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.clickOnElement((dots));
        commonMethods.waitForElementExplicitly(500);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        commonMethods.clickOnElement((supersedeLink));
    }


    /**
     * Function to verify show document history checkbox is clicked
     *
     * @return
     */
    public boolean verifyShowDocumentHistory() {
        commonMethods.waitForElement(driver, documentHistoryCheckBox, 20);
        return $(documentHistoryCheckBox).isSelected();
    }


    /**
     * Function to verify if Document Register submenu is present
     *
     * @return
     */

    public boolean verifyDocumentRegister(String submenu, String menu) {
        return verifyMenuExists(menu, submenu);
    }

    /**
     * Function to select doc property after search
     */
    public void selectDocumentProperty() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, dots, 45);
        $(dots).click();
        getElementInView(docPropertyOption);
        $(docPropertyOption).click();
        documentPropertiesPage.verifyPage();
        verifyAndSwitchFrame();
    }

    /**
     * Function to select doc Event Log
     */
    public void selectDocumentEventLog() {
        verifyAndSwitchFrame();
        selectDocOption();
        getElementInView(docEventLog);
        $(docEventLog).click();
    }

    /**
     * Function to document option
     */
    public void selectDocOption() {
        verifyAndSwitchFrame();
        Actions actionProvider = new Actions(driver);
        commonMethods.waitForElement(driver, firstDocumentChkBox, 30);
        actionProvider.moveToElement($(firstDocumentChkBox)).click().click($(dots)).build().perform();
    }

    /**
     * Function to select document supersede option
     */
    public void selectSupersedeDocument() {
        verifyAndSwitchFrame();
        selectDocOption();
        getElementInView(docSupersedeOption);
        $(docSupersedeOption).click();
    }


    /**
     * Function to select viewer option
     */
    public void selectViewer() {
        verifyAndSwitchFrame();
        selectDocumentCheckBox(0);
        selectDocOption();
        getElementInView(viewerOption);
        $(viewerOption).click();
    }

    /**
     * Function to get confidentiality status
     */
    public String getConfidentialityStatus(String documentNumber) {
        verifyAndSwitchFrame();
        searchDocumentNo(documentNumber);
        //addColumnIfNotPresent("Confidential", "Documents");
        //scrollToEnd();
        addColumns("Confidential");
        return $(getConfidentialStatus).getText();
    }

    /**
     * Function to verify the message for update project copies
     *
     * @param message
     */

    public boolean verifyUpdatePrjCopy(String message) {
        verifyAlert(message);
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, documentsUpdated);
        return $(documentsUpdated).isDisplayed();

    }

    /**
     * Function to update project copies
     */
    public void clickUpdateProjectCopies() {
        verifyAndSwitchFrame();
        clickTransmitBtn();
        $(updateProjectCopies).click();
        $(selectEntirePage).click();
        commonMethods.waitForElement(driver, UpdateProjectCopiesBtn, 30);
        $(UpdateProjectCopiesBtn).click();
    }

    /**
     * Function To verify updated Event
     *
     * @return
     */
    public Boolean verifyUploadedEventLog() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, updatedEventTxt, 6);
        return $(updatedEventTxt).isDisplayed();

    }

    /**
     * Function to click on Event log Button
     */

    public void clickOnEventLog() {
        commonMethods.waitForElement(driver, dots);
        commonMethods.clickOnElement((dots));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        commonMethods.clickOnElement((eventLogLink));
    }


    /**
     * Function to click on Transmittal History
     */

    public void clickOnTransmittalHistory() {
        commonMethods.clickOnElement((dots));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        commonMethods.clickOnElement((transmittalHistoryLink));
    }

    /**
     * Function to verify confidential event log is present or not
     *
     * @return
     */

    public boolean verifyConfidentialEventLog() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(4000);
        return $(confidentialEventLog).isDisplayed();
    }

    /**
     * Function to enter revision value
     *
     * @param revision
     */

    public void sendRevisionValue(String revision) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, inputRevision, 6);
        $(inputRevision).clear();
        $(inputRevision).sendKeys(revision);
    }


    /**
     * Function to click on search input box of Document
     */

    public void clickDocumentSearchInput() {
        $(searchInputBox).click();
    }

    /**
     * Function to verify restore As current is present
     */

    public boolean verifyRestoreAsCurrent() {
        verifyAndSwitchFrame();
        commonMethods.clickOnElement((dots));
        return $(restoreAsCurrentLink).isDisplayed();
    }

    /**
     * Function to click on Document option Restore As Current
     */

    public void clickRestoreAsCurrent() {
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, dots, 10);
        commonMethods.clickOnElement((dots));
        getElementInView(restoreAsCurrent);
        commonMethods.clickOnElement((restoreAsCurrent));
    }

    /**
     * Function to click on lock to unlock it
     */
    public void lockDocument() {
        verifyAndSwitchFrame();
        commonMethods.waitForPageLoad(driver);
        addColumns("Lock");
        if (!$(lockImage).isDisplayed()) {
            commonMethods.waitForElement(driver, unLockImage);
            $(unLockImage).click();
        } else {
            Assert.assertTrue("Document already locked", true);
        }
    }

    /**
     * Method to unlock the document
     */

    public void unlockDocument() {
        verifyAndSwitchFrame();
        //locateScrollBar();
        //scrollToEnd();
        addColumns("Lock");
        if (!$(unLockImage).isDisplayed()) {
            addColumnIfNotPresent("Lock", "document");
            commonMethods.waitForElement(driver, lockImage);
            $(lockImage).click();
        } else {
            System.out.println("Document already unlocked");
        }

    }

    /**
     * Function to share Document
     */

    public void shareDocument() {
        verifyAndSwitchFrame();
        $(shareBtn).click();
        $(shareDocumentsLink).click();
        verifyAndSwitchFrame();
        $(shareToAllBtn).click();
        driver.switchTo().alert().accept();
    }

    /**
     * Function to share Document
     */

    public void specificUserShare() {
        verifyAndSwitchFrame();
        $(shareBtn).click();
        $(shareDocumentsLink).click();
        verifyAndSwitchFrame();
        $(addUser).click();
    }


    public void clickShareButton() {
        verifyAndSwitchFrame();
        $(shareBtn).click();
        $(shareDocumentsLink).click();
    }

    public void selectRecipient(String user) {
        $(addUserBtn).click();
        String full_name = commonMethods.getUserData(user, "name");
        String grpName = full_name.split(" ")[0];
        String famName = full_name.split(" ")[1];
        $(groupName).sendKeys(grpName);
        $(familyName).sendKeys(famName);
        $(selectRecipientSearch).click();
        commonMethods.waitForElement(driver, selectRecipientCheckbox, 15);
        $(selectRecipientCheckbox).click();
        commonMethods.waitForElement(driver, selectRecipientToBtn, 15);
        $(selectRecipientToBtn).click();
        commonMethods.waitForElementExplicitly(1000);
        $(selectRecipientOkBtn).click();
    }

    public int returnTemporaryFilesRows() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(3000);
        locateScrollBar();
        scrollToEnd();
        List<WebElement> cellElements = driver.findElements(candidateDocNo);
        int count = cellElements.size() - 1;
        return count;
    }

    /**
     * Function to verify Result values after Doc search
     *
     * @param columnName
     * @param columnValue
     */
    public void verifyResult(String columnName, String columnValue) {
        switch (columnName) {
            case "Type":
                String documentType = returnDocumentType();
                Assert.assertTrue((documentType.contains(columnValue)));
                break;
            case "Title":
                String documentTitle = returnDocumentTitle(driver);
                Assert.assertTrue((documentTitle.contains(columnValue)));
                break;
            case "Document No":
                String documentNumber = returnDocumentNumber(columnValue);
                driver = WebDriverRunner.getWebDriver();
                String docNo = returnDocumentNumber(2);
                Assert.assertTrue((docNo.contains(documentNumber)));
                break;
            case "Date Uploaded":
                String todayDate = commonMethods.getDate(configFileReader.getTimeZone(), columnValue);
                driver = WebDriverRunner.getWebDriver();
                addColumns(columnName);
                String dateUploaded = returnDateUploaded(driver);
                Assert.assertTrue((dateUploaded.contains(todayDate)));
                break;
            case "Status":
                String status = returnDocumentStatus(driver);
                Assert.assertTrue(status.contains(columnValue));
                break;
            case "Revision":
                String revision = returnRevision(2);
                Assert.assertTrue(revision.contains(columnValue));
                break;
        }
    }

    /**
     * Function to click report button on register page
     */
    public void clickReportButtonOption() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, reportBtn, 8);
        $(reportBtn).click();
    }


    /**
     * Function to select report option on register page
     */
    public void clickReportButtonOption(String option) {
        verifyAndSwitchFrame();
        $(reportBtn).click();
        option = option.toLowerCase();
        option = (option.contains("transmittal history by")) ? option.replace("transmittal history by ", "") : option;
        switch (option) {
            case "register":
                String value = getDocumentMenuName();
                verifyAndSwitchFrame();
                $(By.xpath("//div[@class='auiMenuButton-dropdownContents']/a[contains(.,'Transmittal History By " + value.substring(0, value.length() - 1) + "')]")).click();
                break;
            case "document":
                $(transmittalHistoryByDoc).click();
                break;
            case "asset":
                $(transmittalHistoryByAsset).click();
                break;
            case "organization":
                $(transmittalHistoryByOrg).click();
                break;
            case "export to excel":
                $(exportToExcel).click();
                commonMethods.waitForElementExplicitly(2000);
                break;
        }
    }

    /**
     * Function to get options available for the document report
     */
    public List<WebElement> getReportOptions() {
        verifyAndSwitchFrame();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
        clickReportButtonOption();
        List<WebElement> options = driver.findElements(docReportOptions);
        return options;

    }

    /**
     * Function to verify buttons available on the document history page
     *
     * @param button name
     */
    public void verifyDocHistoryBtn(String button) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, optionBtn, 7);
        switch (button.toLowerCase()) {
            case "options":
                Assert.assertTrue($(optionBtn).exists());
                break;
            case "back":
                Assert.assertTrue($(backBtn).exists());
                break;
            case "export to excel":
                Assert.assertTrue($(exportToExcelBtn).exists());
                break;
            case "print":
                Assert.assertTrue($(printBtn).exists());
                break;
        }

    }

    /**
     * Function to verify functions available on the document history by organisation page
     *
     * @param function name
     */
    public void verifyDocOrgHistoryBtn(String function) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, historyTransmitBtn, 7);
        switch (function.toLowerCase()) {
            case "transmit":
                Assert.assertTrue($(historyTransmitBtn).exists());
                break;
            case "back":
                Assert.assertTrue($(backBtn).exists());
                break;
            case "search":
                Assert.assertTrue($(historySearchBtn).exists());
                break;
            case "select org":
                Assert.assertTrue($(historySelectOrg).exists());
                break;
            case "select show":
                Assert.assertTrue($(historySelectShow).exists());

        }

    }


    /**
     * Function to verify transmitted document element on document history report
     *
     * @param table map data to verify
     */
    public void verifyElementHistory(Map<String, String> table) {
        commonMethods.waitForElementExplicitly(2000);
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        for (Map.Entry<String, String> row : table.entrySet()) {
            switch (row.getKey().toLowerCase()) {
                case "document no":
                    Assert.assertTrue($(historyDocNo).text().contains(commonMethods.returnDocNumberInJson(row.getValue())));
                    break;
                case "transmittal no":
                    System.out.println($(historyTransmittalNo).text());
                    System.out.println(commonMethods.getMailNumFromJson(row.getValue()));
                    Assert.assertTrue($(historyTransmittalNo).text().contains(commonMethods.getMailNumFromJson(row.getValue())));
                    break;
                case "recipient organization":
                    Assert.assertTrue($(historyRecipientOrg).text().contains(commonMethods.getUserData(row.getValue(), "organisation")));
                    break;
                case "uploaded by":
                    Assert.assertTrue($(historyUploadedBy).text().contains(getUserFullName(row.getValue())));
                    break;
                case "recipient":
                    Assert.assertTrue($(historyRecipient).text().contains(getUserFullName(row.getValue())));

            }
        }
    }

    public String getUserFullName(String key) {
        String fullName;
        String[] name;
        String expected;
        fullName = commonMethods.getUserData(key, "name");
        name = fullName.split(" ");
        return name[0].toCharArray()[0] + " " + name[name.length - 1];
    }

    /**
     * Function to click history button on register page
     */
    public void clickHistoryOption() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, optionBtn, 10);
        $(optionBtn).click();
    }

    /**
     * Function to verify filter option available on doc report page
     */
    public void verifyFilterOption() {
        verifyAndSwitchFrame();
        Assert.assertTrue($(filterOptionAllDoc).exists());
        Assert.assertTrue($(filterOptionDocByOrg).exists());
        Assert.assertTrue($(filterOptionDocNeverTransmitted).exists());
    }

    /**
     * Function to select filter from filter list
     *
     * @param option
     */
    public void selectFilterOption(String option) {
        verifyAndSwitchFrame();
        switch (option.toLowerCase()) {
            case "all doc":
            case "all asset":
                $(filterOptionAllDoc).click();
                $(filterOptionOkBtn).click();
                break;
            case "have been transmitted to the selected organizations":
                $(filterOptionDocByOrg).click();
                break;
            case "have never been transmitted":
                $(filterOptionDocNeverTransmitted).click();
                $(filterOptionOkBtn).click();
                break;
        }
    }

    /**
     * Function to click ok after selecting filter
     */
    public void clickFilterOk() {
        verifyAndSwitchFrame();
        getElementInView(filterOptionOkBtn);
        $(filterOptionOkBtn).click();
    }

    /**
     * Function to click cancel on filter panel
     */
    public void cancelFilterOption() {
        $(filterOptionCancelBtn).click();
    }

    /**
     * Function to select date range for document search form
     *
     * @param period
     */
    public void selectDateRange(String period) {
        verifyAndSwitchFrame();
        By xpath = By.xpath("//div[text()='" + period + "']");
        $(dateType).click();
        commonMethods.waitForElement(driver, dateModifiedDropdown, 30);
        $(dateModifiedDropdown).click();
        commonMethods.waitForElementExplicitly(1000);
        $(dateRange).click();
        commonMethods.waitForElement(driver, xpath, 30);
        $(xpath).click();
    }

    /**
     * Function to select document checkbox present on the search page
     *
     * @param doc
     */
    public void selectDocument(String doc) {
        By checkBox = By.xpath("//div[@role='row'][contains(.,'" + doc + "')]//parent::div[@role='row']");
        System.out.println($(checkBox).getAttribute("row-id"));
        int rowCount = Integer.parseInt($(checkBox).getAttribute("row-id"));
        List<WebElement> list = driver.findElements(By.xpath("//span[@class='ag-selection-checkbox']"));
        list.get(rowCount).click();
//        $(checkBox).setSelected(true);
    }


    /**
     * Function to verify document have transmitted or not
     *
     * @param doc  number
     * @param flag to verify
     */

    public void verifyDocumentTransmitted(String doc, String flag) {
        System.out.println("Search value--->" + doc);
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, optionBtn, 10);
        switch (flag) {
            case "false":
                Assert.assertTrue($(By.xpath("//td[contains(.,'" + doc + "')]/ancestor::tr/" +
                        "following-sibling::tr/td[contains(.,'has never been transmitted')]")).exists());
                break;
            case "true":
                Assert.assertTrue($(By.xpath("//td[contains(.,'" + doc + "')]/ancestor::tr/" +
                        "following-sibling::tr/th[contains(.,'Transmittal Number')]")).exists());
                break;
        }


    }

    /**
     * Function to click on export to excel button on doc report page
     */
    public void clickExportToExcel() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, exportToExcelBtn);
        $(exportToExcelBtn).click();
    }

    /**
     * Function to verify export to excel is successfull on doc report page
     */
    public void verifyExportToExcel() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, temporaryFilesBtn, 10);
        Assert.assertTrue($(mainPage).text().contains("Export to Excel has successfully commenced. It will run in the background as a low-priority process"));
        Assert.assertTrue($(mainPage).text().contains("When the export completes an email notification will be sent to"));
    }

    /**
     * Function to get document report count
     *
     * @return count of report
     */
    public String getDocReportCount() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, historyDocumentResultCount, 5);
        return $(historyDocumentResultCount).text();
    }

    /**
     * Function to select organisation from document history by organisation
     *
     * @param organisation name
     */
    public void selectHistoryOrganisation(String organisation) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, historySelectOrg, 5);
        $(historySelectOrg).selectOptionContainingText(organisation);
    }


    /**
     * Function to click organisation history search button
     */
    public void clickOrgHistorySearch() {
        verifyAndSwitchFrame();
        $(historySearchBtn).click();
    }


    /**
     * Function to get document report count from organisation
     *
     * @return count of report
     */
    public String getOrgDocReportCount() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, historyOrganisationDocCount, 35);
        return $(historyOrganisationDocCount).text();
    }

    /**
     * Function to select Show type report from organisation
     */
    public void selectShowOption(String option) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, historySelectShow, 5);
        $(historySelectShow).selectOptionContainingText(option);
    }

    /**
     * Function to select document and view report
     *
     * @param index of document
     */
    public void selectDocReport(String index) {
        verifyAndSwitchFrame();
        int i = Integer.parseInt(index);
        $(By.xpath("//div[@id='searchResultsContainer']//tbody//tr[" + i + "]//td[1]//input")).setSelected(true);
    }

    /**
     * Function to verify the Document
     *
     * @param docNum
     * @return
     */

    public boolean verifyDocument(String docNum) {
        driver = WebDriverRunner.getWebDriver();
        String docNo = returnDocumentNumber(1);
        return docNo.contains(commonMethods.returnDocNumberInJson(docNum));
    }

    /**
     * Function to click on the File to Download
     */

    public void clickFileToDownload() {
        commonMethods.waitForElement(driver, downloadFile, 45);
//        action.moveToElement($(downloadFile)).click().build().perform();
        $(downloadFile).click();

    }

    /**
     * Method to return if the related items icon is present
     *
     * @return
     */
    public Boolean returnLinkIcon() {
        commonMethods.waitForElement(driver, linkingIcon);
        return $(linkingIcon).isDisplayed();
    }

    /**
     * Method to click on the related items link
     */
    public void clickLinkIcon() {
        commonMethods.waitForElement(driver, linkingIcon);
        $(linkingIcon).click();
    }

    /**
     * Function to verify ail details in inbox mail
     *
     * @param data as attribute
     */
    public void verifyDocAttributes(String data) {
        Map<String, String> table = dataStore.getTable(data);
        //According to the keys passed in the table, we select the fields
        verifyAndSwitchFrame();
        for (String tableData : table.keySet()) {
            switch (tableData) {
                case "Type":
                    addColumns("Type");
                    Assert.assertEquals(table.get(tableData), returnDocumentType());
                    break;
                case "Revision":
                    addColumns("Revision");
                    Assert.assertEquals(table.get(tableData), returnRevision(2));
                    break;
                case "Status":
                    addColumns("Status");
                    Assert.assertEquals(table.get(tableData), returnDocumentStatus(driver));
                    break;
                case "Revision Date":
                    addColumns("Revision Date");
                    Assert.assertEquals(commonMethods.getTodayDate(configFileReader.getTimeZone()), returnRevisionDate());
                    break;
            }
        }
    }

    /**
     * Function to verify Reports options
     *
     * @param reportValues
     */
    public void verifyReportsOptions(List<String> reportValues) {
        verifyAndSwitchFrame();
        clickDocumentSearch();
        $(reportBtn).click();
        List<WebElement> options = driver.findElements(reportsOptions);
        for (int i = 0; i <= options.size() - 1; i++) {
            String optionsText = options.get(i).getText();
            Assert.assertTrue(optionsText.contains(reportValues.get(i)));
        }
    }

    /**
     * Function to verify Export Excel is present
     *
     * @return
     */
    public boolean verifyExportExcel() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, exportMsg, 20);
        return $(exportMsg).isDisplayed();
    }

    /**
     * Method to validate if supersede can be done
     *
     * @param text
     */
    public void validateSupersede(String uiText, String text) {

        Assert.assertTrue(uiText.contains(text));
    }


    /**
     * Method to validate if the supersede button is enabled
     *
     * @param rowNo
     * @return
     */
    public String validateSupersedeBtn(int rowNo) {
        List<WebElement> elements = driver.findElements(selectFile);
        elements.get(rowNo).click();
        $(dots).click();
        return $(supersedeLink).getAttribute("ng-class");
    }

    /**
     * Method to validate if the supersede button is enabled
     *
     * @param rowNo
     * @return
     */
    public void updateDocuments(int rowNo) {
        List<WebElement> elements = driver.findElements(selectFile);
        elements.get(rowNo).click();
        updateDocuments();
    }

    /**
     * Method to return the historical revision of the document
     *
     * @return
     */
    public String returnHistoricalRevision(int rowIndex) {
        return returnCellValues(revision, rowIndex);
    }

    /**
     * Method to return the historical revision of the document
     *
     * @return
     */
    public String returnLatestRevision() {
        moveColToFourthPlace("Revision");
        commonMethods.waitForElement(driver, docRevision, 60);
        return returnCellValues(docRevision, 1);
    }

    /**
     * Method to return the historical revision of the document
     *
     * @return
     */
    public String returnLatestStatus() {
        moveColToFourthPlace("Status");
        return returnCellValues(status, 2);
    }

    /**
     * Method to return the historical revision of the document
     *
     * @return
     */
    public String returnLatestDiscipline() {
        return returnCellValues(discipline, 2);
    }

    public void clickShareSearchBtn() {
        commonMethods.waitForElement(driver, saveDocShare, 40);
        $(saveDocShare).click();
    }

    /**
     * Function to verify Tools Option
     *
     * @param option
     * @return
     */
    public boolean verifyToolsOptions(String option) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, toolsBtn, 60);
        $(toolsBtn).click();
        return $(By.xpath("//a[contains(.,'" + option + "')]")).isDisplayed();
    }


    /**
     * Function to select Tools option
     *
     * @param option
     */
    public void selectToolsOption(String option) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, toolsBtn, 30);
        $(toolsBtn).click();
        commonMethods.waitForElementExplicitly(1000);
        actions.moveToElement($(By.xpath("//a[text()='" + option + "']"))).click().build().perform();
        //$(By.xpath("//a[text()='" + option + "']")).click();
    }

    /**
     * Function to select Tools option
     */
    public void selectToolsAddBIMModelToStacks() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, toolsBtn, 30);
        $(toolsBtn).click();
        commonMethods.waitForElementExplicitly(3000);
        $(By.xpath("//div[@class='auiMenuButton-dropdownContents']//a[text()='Add model stacks in Models']")).click();
        commonMethods.waitForElement(driver, addingModelToStacks, 60);
        $(continueOnModelStacks).click();
        commonMethods.waitForElement(driver, viewInModels);
        $(viewInModels).click();
    }

    /**
     * function to verify Restore As Current Diabality
     *
     * @return
     */

    public boolean verifyDisabledRestoreAsCurrent() {
        verifyAndSwitchFrame();
        selectDocOption();
        commonMethods.waitForElement(driver, restoreAsCurrentDisabled, 30);
        return $(restoreAsCurrentDisabled).isDisplayed();
    }

    /**
     * function to verify Restore As Current exists
     *
     * @return
     */

    public boolean verifyRestoreAsCurrentAvailability() {
        verifyAndSwitchFrame();
        selectDocOption();
        return $(restoreAsCurrentDisabled).exists();
    }

    /**
     * Function to navigate and click on Viewer
     */

    public void clickOnViewer() {
        commonMethods.clickOnElement((dots));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        commonMethods.clickOnElement((viewerLink));
    }

    /**
     * Function to verify the document Number and document Title displayed along with Event Log title
     *
     * @return
     */

    public boolean verifyTitleDetails(String docNo, String docTitle) {
        return $(By.xpath("//h1[contains(text(),\"Event Log - " + docNo + " - " + docTitle + "\")]")).isDisplayed();
    }

    /**
     * Function to click on Bulk Supersede link
     */

    public void clickBulkSupersede() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, toolsBtn);
        $(toolsBtn).click();
        commonMethods.waitForElement(driver, supersedeLink);
        $(supersedeLink).click();
    }


    /**
     * Method to click on bulk supersede option in tools options
     */
    public void updateDocuments() {
        commonMethods.waitForElement(driver, toolsBtn);
        Actions actions = new Actions(driver);
        actions.moveToElement($(toolsBtn)).click().build().perform();
//        $(toolsBtn).click();
        $(btnUpdate).click();
    }

    /**
     * Function to verify Document lock
     *
     * @param flag
     * @return
     */
    public boolean verifyDocumentLock(String flag) {
        verifyAndSwitchFrame();
        /*addColumnIfNotPresent("Lock", "document");
        locateScrollBar();
        scrollToEnd();*/
        addColumns("Lock");
        if (flag.equalsIgnoreCase("locked")) {
            return $(lockImage).isDisplayed();
        } else {
            commonMethods.waitForElementExplicitly(1000);
            return $(unLockImage).isDisplayed();
        }
    }

    public void selectFirstDocCheckBox() {
        commonMethods.waitForElement(driver, firstDocumentChkBox);
        $(firstDocumentChkBox).click();
    }

    public String getExportToExcelMessage() {
        commonMethods.waitForElement(driver, exportToExcelMessage);
        return $(exportToExcelMessage).getText();
    }

    /**
     * Function to verify update copy supersede page
     */
    public boolean verifySupersedeProjectCopy() {
        verifyAndSwitchFrame();
        getElementInView(transmitBtn);
        commonMethods.waitForElementExplicitly(3000);
        $(transmitBtn).click();
        commonMethods.waitForElement(driver, updateProjectCopies, 40);
        $(updateProjectCopies).click();
        commonMethods.waitForElement(driver, updateProjectCopiesBtn, 30);
        return $(supersedeCopiesTitle).isDisplayed();
    }

    /**
     * Function to verify markup pencil symbol
     *
     * @return
     */
    public boolean verifyMarkUpIcon() {
        commonMethods.waitForElement(driver, markUpIcon, 40);
        return $(markUpIcon).isDisplayed();
    }

    /**
     * Function to click on Preview
     */

    public void clickOnPreview() {
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.clickOnElement((dots));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        commonMethods.clickOnElement((previewLink));
    }

    /**
     * Function to click on Preview
     */

    public void clickOnOpenInModels() {
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.clickOnElement((dots));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        commonMethods.clickOnElement((openInModelsLink));
    }

    /**
     * Function to verify Document Fields
     *
     * @param data
     */

    public void verifyDocFields(List<String> data) {
        for (String field : data) {
            Assert.assertTrue("Doc field " + field + " is not displayed correctly", $(By.xpath("//div[@class='uiPanel-titleBar']//div[contains(text(),'" + field + "')]")).isDisplayed());
        }
    }

    /**
     * Function to verify the button on Preview screen
     */

    public void verifyButtons() {
        Assert.assertTrue($(previewDownloadBtn).isDisplayed());
        Assert.assertTrue($(previewCloseBtn).isDisplayed());
    }

    /**
     * Function to click Preview Close Button
     */

    public void clickPreviewClose() {
        $(previewCloseBtn).click();
    }

    /**
     * Function to verify No Preview Message
     *
     * @param message
     * @return
     */

    public boolean verifyNoPreview(String message) {
        return $(By.xpath("//h1[contains(text(),'" + message + "')]")).isDisplayed();
    }

    /**
     * Function to click Preview Download Icon
     */

    public void clickPreviewDownload() {
        commonMethods.waitForElement(driver, previewDownload, 45);
        $(previewDownload).click();
    }

    /**
     * Function to click Escape button
     */

    public void clickEscape() {
        action.sendKeys(Keys.ESCAPE).build().perform();
    }

    /**
     * Function to click Grid Preview
     */

    public void clickGridPreview() {
        action.moveToElement($(gridPreview)).build().perform();
        $(gridPreview).click();
    }

    /**
     * Function to verify Preview Version
     *
     * @param version
     * @return
     */

    public boolean verifyPreviewVersion(String version) {
        return $(By.xpath("//div[@class='uiPanel-title-block-column uiPanel-title-block-column-docVersion']//div[contains(text(),'" + version + "')]")).isDisplayed();
    }

    /**
     * Function to verify Preview Revision
     *
     * @param revision
     * @return
     */

    public boolean verifyPreviewRevision(String revision) {
        return $(By.xpath("//div[@class='uiPanel-title-block-column uiPanel-title-block-column-docRevision']//div[contains(text(),'" + revision + "')]")).isDisplayed();
    }

    /**
     * Function to verify Forward Arrow on Preview screen
     *
     * @return
     */

    public boolean verifyForwardArrow() {
        return $(forwardArrow).isDisplayed();
    }

    /**
     * Function to verify backward Arrow on Preview screen
     *
     * @return
     */

    public boolean verifyBackwardArrow() {
        return $(backwardArrow).isDisplayed();
    }

    /**
     * Function to click Forward Arrow
     */

    public void clickForward() {
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", $(forwardArrow));
    }

    public boolean verifyDotsClickable() {
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.elementToBeClickable(searchInputBox));
        return $(searchInputBox).isDisplayed();
    }

    public void clickStartDocumentProcess() {
        commonMethods.waitForElement(driver, startDocumentProcessBtn);
        $(startDocumentProcessBtn).click();
    }

    /**
     * Function to navigate and click on Edit or Upload new version link
     */
    public void clickEditOrUploadLink() {
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.clickOnElement((dots));
        //commonMethods.scrollToTop(driver);
        commonMethods.clickOnElement((lnkEditOrUpload));
    }

    /**
     * Function to click on want to upload a new document link
     */
    public boolean verifyWantToUploadNewDocLink() {
        commonMethods.waitForElement(driver, searchBtn, 30);
        return ($(lnkWantToUploadNewDoc).isDisplayed());
    }

    /**
     * Function to click on want to upload a new document link
     */
    public void clickWantToUploadNewDocLink() {
        commonMethods.waitForElement(driver, searchBtn, 30);
        $(lnkWantToUploadNewDoc).click();
    }

    /**
     * Function to click on Add Documents button
     */
    public void clickAddDocuments() {
        commonMethods.waitForElement(driver, btnAddDocument, 60);
        $(btnAddDocument).click();
    }

    /**
     * Function to click on Add Documents dropdown options
     */
    public void clickAddDocumentOptions(String option) {
        commonMethods.waitForElement(driver, btnAddDocumentsTransmitTool, 30);
        $(btnAddDocumentsTransmitTool).click();
        $(By.xpath("//div[@class='auiMenuButton-dropdownContents']//a[contains(text(),'" + option + "')]")).click();
    }

    /**
     * Function to get Doc Locked Msg
     */
    public String getDocLockedMsg() {
        commonMethods.waitForElement(driver, msgCheck);
        return $(msgCheck).getText();
    }

    public void clickToolBtn() {
        $(toolsBtn).click();
    }

    /**
     * Function to make document as No longer In Use
     */
    public void markAsNLIU() {
        commonMethods.waitForElement(driver, noLongerInUseWarningMsg, 60);
        $(noLongerInUseWarningMsg).isDisplayed();
        commonMethods.waitForElementExplicitly(1000);
        $(markNoLongerInUseBtn).click();
        commonMethods.acceptAlert(driver);
    }

    /**
     * Function to verify saved search options
     */
    public boolean verifySavedSearchInfo(String sharingInfo) {
        commonMethods.waitForElement(driver, saveSearchAsBtn, 40);
        $(saveSearchAsBtn).click();
        commonMethods.waitForElement(driver, searchName);
        return $(By.xpath("//label[text()='" + sharingInfo + "']/..//input")).isDisplayed();
    }

    /**
     * Function to get the specific col name
     */
    public String getColHdrName(int i) {
        verifyAndSwitchFrame();
        resultTable();
        return commonMethods.getValues(resultsColHeaders).get(i);
    }

    /**
     * Function to verify saved search button
     */
    public boolean verifySavedSearchButton() {
        return $(saveSearchAsBtn).isDisplayed();
    }

    /**
     * Method to click on three dots for selected document
     */
    public void clickDots() {
        commonMethods.waitForElement(driver, dots);
        $(dots).click();
    }

    /**
     * Method to return document options
     */
    public List<String> getDocOptions() {
        return commonMethods.getValues(lnkDocOptions);
    }

    /**
     * Method to click on Drawings tab
     */
    public void clickDrawingsTab() {
        $(drawingsTab).click();
    }

    /**
     * Method to click on Document Register tab
     */
    public void clickDocRegisterTab() {
        $(docRegisterTab).click();
    }

    /**
     * Method to close zip downloads with markups popup window
     */
    public void closeZDWMPopup() {
        commonMethods.waitForElement(driver, btnZDWMClose, 30);
        $(btnZDWMClose).click();
    }

    /**
     * Method to get the document number
     */
    public List<String> getAllDocNo() {
        docList.clear();
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, docSelectChkBox, 30);
        for (WebElement element : $$(docNoList)) {
            docList.add(element.getText());
        }
        return docList;
    }

    /**
     * Method to verify Zip download with markups message displayed
     */
    public boolean verifyPopUpWindow() {
        return $(zdwmMessage).isDisplayed();
    }

    /**
     * Function to click on Download button
     */
    public void clickOnDownload() {
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.clickOnElement((dots));
        commonMethods.waitForElementExplicitly(1000);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        commonMethods.clickOnElement((downloadLink));
    }

    /**
     * Function to get all column ids in document results table
     */
    public Map<String, String> getAllColumnIds(List<String> colNames) {
        Map<String, String> docColNames = new LinkedHashMap<>();
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        for (String colName : colNames) {
            moveColToFourthPlace(colName);
            resultTable();
            verifyAndSwitchFrame();
            docColNames.put(colName, $(By.xpath("//div[@class='customHeader-label' and text()='" + colName + "']/../..")).getText());
        }
        return docColNames;
    }

    /**
     * Function to click on saved search
     *
     * @param savedSearch
     */
    public void clickOnDocumentSavedSearch(String savedSearch) {
        clickDocumentSearchInput();
        By element = By.xpath("//*[@title='" + savedSearch + "']");
        actions.moveToElement($(element)).click().build().perform();
        $(element).click();
    }

    /**
     * Function to verify Preview Version
     *
     * @param docNo
     * @return
     */
    public boolean verifyPreviewDocNo(String docNo) {
        return $(By.xpath("//div[@class='uiPanel-title-block-column uiPanel-title-block-column-docNumber']//div[contains(text(),'" + docNo + "')]")).isDisplayed();
    }

    /**
     * Function to verify Preview Version
     *
     * @param title
     * @return
     */
    public boolean verifyPreviewTitle(String title) {
        return $(By.xpath("//div[@class='uiPanel-title-block-column uiPanel-title-block-column-docTitle']//div[contains(text(),'" + title + "')]")).isDisplayed();
    }

    /**
     * Function to click on Preview
     */
    public void clickPreview() {
        commonMethods.waitForElementExplicitly(2000);
        $(previewLink).click();
    }

    /**
     * Function to Expand the smart folders
     */
    public void expandSmartFolders() {
        if ($(btnArrowExpand).isDisplayed()) {
            $(btnArrowExpand).click();
        }
    }

    /**
     * Function to close the smart folders
     */
    public void closeSmartFolders() {
        if ($(btnArrowCollpase).isDisplayed()) {
            $(btnArrowCollpase).click();
        }
    }
}

