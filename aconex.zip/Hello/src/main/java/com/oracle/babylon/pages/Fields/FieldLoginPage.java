package com.oracle.babylon.pages.Fields;

import com.oracle.babylon.Utils.helper.Navigator;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Condition.appears;
import static com.codeborne.selenide.Selenide.*;

public class FieldLoginPage extends Navigator {

    private By usernameTxtBox = By.xpath("//*[contains(@id,'name')]");
    private By passwordTxtBox = By.xpath("//*[@type='password']");
    private By loginBtn = By.xpath("//*[@type='submit']");
    private By sslCertPage = By.cssSelector("body.ssl");
    private By advancedButton = By.cssSelector("button#details-button");
    private By proceedLink = By.cssSelector("a#proceed-link");

    public void adminLoginToFieldsTool(){
        open(configFileReader.getApplicationUrl() + "field/app/admin/#/settings/project-settings");
        if ($(sslCertPage).isDisplayed()) {
            $(advancedButton).click();
            $(proceedLink).click();
        }
        $(loginBtn).waitUntil(appears, 5000);
        $(usernameTxtBox).clear();
        $(usernameTxtBox).setValue(configFileReader.getAdminUsername());
        $(passwordTxtBox).clear();
        $(passwordTxtBox).setValue(configFileReader.getPassword());
        sleep(1000);
        $(loginBtn).click();
    }
}
