package com.oracle.babylon.pages.Document;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

import static com.codeborne.selenide.Selenide.$;

public class CopyToProjectPage extends DocumentPage {
    //Initialization of Web Elements
    private By copyToProject = By.xpath("//div[@class='auiMenuButton-dropdownContents']//a[text()='Copy to Project']");
    private By selectProject = By.xpath("//select[@name='PROJECT_ID']");
    private By copyBtn = By.xpath("//button[@id='btnCopy']");
    private By backBtn = By.xpath("//button[@id='btnBack']//div[@class='uiButton-content']");
    private By latestVersionTxt = By.xpath("//td[contains(text(),'Last Version Copied')]");
    private By copyStatusTxt = By.xpath("//td[contains(text(),'Copy Status')]");
    private By resultCopyTxt = By.xpath("//td[contains(text(),'Result of Copy')]");
    private By targetTxt = By.xpath("//span[contains(text(),'Target Edited')]");
    private By selectAllRecords = By.xpath("//form[@id='command']//table[@class='formTable']//a/img[@name='TOGGLE_SELECT']");

    Actions action = new Actions(driver);

    /**
     * Function to click on copy button
     */
    public void clickCopyButton(){
        commonMethods.waitForElement(driver,copyBtn,30);
        $(copyBtn).click();
    }

    /**
     * Method to navigate doc Copy project
     */
    public void navigate(){
        clickTransmitBtn();
        $(copyToProject).click();
    }

    /**
     * Function to copy Multiple document to project
     * @param userId
     * @param projectNumber
     */
    public void copyMultipleDocuments(String userId, String projectNumber,List<String> documents) {
        selectCopyProject(userId,projectNumber);
        verifyAndSwitchFrame();
        selectMultipleDocs(documents);
        $(copyBtn).click();
        acceptAlert();
    }

    /**
     * Function to copy document to project
     * @param userId
     * @param projectNumber
     */
    public void createCopyDocument(String userId, String projectNumber) {
        selectCopyProject(userId,projectNumber);
        selectAllRecords();
        $(copyBtn).click();
        acceptAlert();
    }

    /**
     * Function to verify UI fields in Page
     *
     * @param userId
     * @param docs
     */
    public void verifyFields(String userId, List<String> docs) {
        commonMethods.waitForElement(driver, selectProject, 30);
        Assert.assertTrue($(selectProject).isDisplayed());
        Assert.assertTrue($(copyBtn).isDisplayed());
        Assert.assertTrue($(backBtn).isDisplayed());
        Assert.assertTrue($(latestVersionTxt).isDisplayed());
        Assert.assertTrue($(copyStatusTxt).isDisplayed());
        Assert.assertTrue($(resultCopyTxt).isDisplayed());
        Assert.assertTrue($(targetTxt).isDisplayed());
        for (String doc : docs) {
            Assert.assertTrue(verifyDocMsg(commonMethods.returnDocNumberInJson(doc)));
        }
    }

    /**
     * Function to accept alert if displayed
     */
    public void acceptNewValueCopyAlert() {
        WebDriverWait wait = new WebDriverWait(driver, 10);
        try {
            if (wait.until(ExpectedConditions.alertIsPresent()) != null) ;
                acceptAlert();
        } catch (Exception e) {
            System.out.println("No Alert");
        }
    }

    /**
     * Function to select first record
     */
    public void selectAllRecords() {
        commonMethods.waitForElement(driver, copyBtn, 60);
        $(selectAllRecords).click();
    }

}
