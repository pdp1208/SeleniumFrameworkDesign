package com.oracle.babylon.pages.Document;

import com.oracle.babylon.pages.Mail.MailPage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Selenide.*;

public class AutoUpdateTenderTransmittedPage extends DocumentPage {

    //Initialization of web elements

    private By backButton = By.xpath("//div[@class='uiButton-content']");
    private By excludeButton = By.xpath("//div[contains(text(),'Exclude')]");
    private By showExclusion = By.xpath("//div[contains(text(),'Show Exclusions')]");


    private By ccRecipient = By.xpath("//a[contains(text(),'Cc')]");
    private By bccRecipient = By.xpath("//a[contains(text(),'Bcc')]");
    private By attachments = By.xpath("//div[@id='fldAttachments']");
    private By selectEntirePage = By.xpath("//img[@name='TOGGLE_SELECT_ALL']");
    private By selectDocumentChkBox = By.xpath("//tr//input");
    private By message = By.xpath("//p[contains(text(),'All document recipients have been issued with the latest revision')]");
    private By sendBtn = By.xpath("//div[contains(text(),'Send')]");
    private By reasonForIssueLabel = By.xpath("//label[contains(text(),'Reason for Issue')]");
    private By subjectLabel = By.xpath("//td[contains(text(),'Subject')]//span[@class='required']");
    private By mailSubject = By.xpath("//input[@name='Correspondence_subject']");
    private By reasonForIssue = By.xpath("//select[@id='Correspondence_correspondenceReasonID']");
    private By mailNumberField = By.xpath("//td//a");
    private By firstDocumentCheckBox = By.xpath("//input[@name='DOCCONTROL_SEQUENCE'][1]");
    private By formId = By.xpath("//form[@id='form1']");
    protected By transmitButton = By.xpath("//button[@id='btnTransmit']");
    private By popUpMsgs = By.xpath("//div[contains(text(),'These documents')]//strong");

    MailPage mailPage = new MailPage();


    /**
     * Function to verify buttons present
     */

    public void verifyButtonPresent() {
        $(backButton).exists();
        $(excludeButton).exists();
        $(showExclusion).exists();
        $(transmitButton).exists();
    }

    /**
     * Function to verify document attached in Tender Transmittal Page
     *
     * @return
     */

    public boolean verifyDocumentAttached(String docNo) {
        getElementInView(attachments);
        return $(By.xpath("//table[@class='dataTable']//td//div[contains(text(),'" + docNo + "')]")).isDisplayed();
    }

    /**
     * Function to verify Mail Options Cc and Bcc exists on page
     */

    public void verifyMailOptions() {
        $(ccRecipient).exists();
        $(bccRecipient).exists();
    }

    /**
     * Function to verify Auto update message is present
     *
     * @return
     */

    public boolean verifyAutoUpdateMessage(String message) {
        commonMethods.waitForElementExplicitly(2000);
        return $(By.xpath("//p[contains(text(),'" + message + "')]")).isDisplayed();
    }

    /**
     * Function to verify the elements present in Tender Transmittal Report page
     */

    public void verifyTTReportPage(String docNo, String mailNo) {

        commonMethods.waitForElementExplicitly(3000);
        $(By.xpath("//td[contains(text(),'" + docNo + "')]")).exists();
        $(By.xpath("//td//a[contains(text(),'" + mailNo + "')]")).exists();
        $(selectEntirePage).exists();
        $(selectDocumentChkBox).exists();
    }

    /**
     * Function to click on back button and verify
     */

    public void clickBackBtnAndVerify() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        if ($(backButton).isDisplayed()) {
            $(backButton).click();
            Assert.assertTrue(verifyPageTitle("Document Register"));
        }
    }

    /**
     * Function to click on exclude button and verify
     *
     * @return
     */

    public boolean clickExcludeBtnAndVerify() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, selectEntirePage);
        $(selectEntirePage).click();
        $(excludeButton).click();
        return $(message).isDisplayed();
    }

    /**
     * Function to click on show exclusion button and verify
     *
     * @return
     */

    public boolean clickShowExclusionAndVerify(String docNo) {
        $(showExclusion).click();
        return $(By.xpath("//td[contains(text(),'" + docNo + "')]")).isDisplayed();
    }

    /**
     * Function to click on title link and verify
     *
     * @return
     */

    public boolean clickTitleLinkAndVerify(String docNo) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        $(By.xpath("//td[contains(text(),'" + docNo + "')]//..//td//following-sibling::td//a")).click();
        commonMethods.waitForElementExplicitly(2000);
        return verifyPageTitle("Document Properties");
    }

    /**
     * Function to click on transmittal link and verify
     *
     * @return
     */

    public void clickTranmittalLink(String mailNum) {
        $(By.xpath("//td//a[contains(text(),'" + mailNum + "')]")).click();
    }

    /**
     * Function to select entire page
     */

    public void clickDocumentCheckBox() {
        commonMethods.waitForElementExplicitly(2500);
        commonMethods.waitForElement(driver, selectEntirePage);
        $(selectEntirePage).click();
    }

    /**
     * Function to select first Document
     */

    public void selectFirstDocument() {
        verifyAndSwitchFrame();
        $(firstDocumentCheckBox).click();
    }

    /**
     * Function to click on Transmit button
     */

    public void clickTransmitButton() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, transmitButton);
        $(transmitButton).click();
    }


    /**
     * Function to click on Exclude button
     */

    public void clickExcludeButton() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, excludeButton, 30);
        $(excludeButton).click();
    }

    /**
     * Function to click on show Exclusion Button
     */

    public void clickShowExclusionBtn() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(500);
        commonMethods.waitForElement(driver, showExclusion, 30);
        $(showExclusion).click();
    }

    /**
     * Function to verify Document is present
     *
     * @return
     */

    public boolean verifyDocumentPresent(String documentNo) {
        verifyAndSwitchFrame();
        return $(By.xpath("//tr//td[contains(text(),'" + documentNo + "')]")).isDisplayed();
    }

    /**
     * Function to verify elements in Auto update Transmittal Page
     */

    public void verifyAutoUpdateTransmittals(String documentNo) {
        verifyAndSwitchFrame();
        Assert.assertTrue(verifyBackButton());
        Assert.assertTrue(verifySendButton());
        Assert.assertTrue(verifyReasonForIssue());
        Assert.assertTrue(verifySubjectLabel());
        Assert.assertTrue(verifyAutoUpdateDocument(documentNo));
    }

    /**
     * Function to verify Back button present in Auto update Tender Transmittal Page
     *
     * @return
     */

    public boolean verifyBackButton() {
        return $(backButton).isDisplayed();
    }

    /**
     * Function to verify Send button present in Auto update Tender Transmittal Page
     *
     * @return
     */

    public boolean verifySendButton() {
        return $(sendBtn).isDisplayed();
    }

    /**
     * Function to verify Reason for Issue is present in Auto update Tender Transmittal Page
     *
     * @return
     */

    public boolean verifyReasonForIssue() {
        return $(reasonForIssueLabel).exists();
    }

    /**
     * Function to verify Subject Label is present in Auto update Tender Transmittal Page
     *
     * @return
     */

    public boolean verifySubjectLabel() {
        return $(subjectLabel).isDisplayed();
    }

    /**
     * Function used to compose auto update tender transmittal mail
     *
     * @param data
     */
    public void autoUpdateTransmittalMail(String data) {
        //Fetch the table from the data store
        switchTo().defaultContent();
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, formId, 10);
        Map<String, String> table = dataStore.getTable(data);
        //According to the keys passed in the table, we select the fields
        for (String tableData : table.keySet()) {
            switch (tableData) {
                case "Subject":
                    String subject = table.get(tableData);
                    driver.switchTo().defaultContent();
                    verifyAndSwitchFrame();
                    commonMethods.waitForElement(driver, mailSubject);
                    $(mailSubject).setValue(subject);
                    break;
            }
        }
        commonMethods.waitForElementExplicitly(2000);
        if ($(reasonForIssueLabel).isDisplayed()) {
            mailPage.selectReasonForIssue();
        }
        driver.switchTo().defaultContent();
    }

    /**
     * Function to click on mail Send button
     *
     * @return
     */
    public String getTransmittalNumber() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, mailNumberField, 10);
        return $(mailNumberField).getText();
    }

    /**
     * Function to click on transmittal mail link and verify
     *
     * @return
     */

    public boolean clickMailAndVerify(String mailNum) {
        verifyAndSwitchFrame();
        $(By.xpath("//td//a[contains(text(),'" + mailNum + "')]")).click();
        return verifyPageTitle("View Mail");
    }

    /**
     * Function to verify document attached in Auto Update Transmittal Page
     *
     * @return
     */

    public boolean verifyAutoUpdateDocument(String docNo) {
        verifyAndSwitchFrame();
        By element = By.xpath("//table[@class='blank']//tbody//tr[3]//td[1]");
        return $(element).getText().contains(docNo);
    }

    /**
     * Function to verify pop msg text
     *
     * @param msgs
     */
    public void verifyPopUpMessages(List<String> msgs) {
        verifyAndSwitchFrame();
        List<WebElement> msgsList = driver.findElements(popUpMsgs);
        for (int i = 0; i <= msgsList.size() - 1; i++) {
            Assert.assertTrue(msgsList.get(i).getText().equalsIgnoreCase(msgs.get(i)));
        }
    }

    /**
     * Function to select entire page displayed
     */

    public boolean verifySelectChkBox() {
        return $(selectEntirePage).isDisplayed();
    }

}
