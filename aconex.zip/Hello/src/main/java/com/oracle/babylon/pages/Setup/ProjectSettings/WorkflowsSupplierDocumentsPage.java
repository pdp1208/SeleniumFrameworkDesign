package com.oracle.babylon.pages.Setup.ProjectSettings;

import com.oracle.babylon.pages.Setup.ProjectSettingsPage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Selenide.$;

public class WorkflowsSupplierDocumentsPage extends ProjectSettingsPage {

    private By reviewsMenu = By.xpath("//span[contains(text(),'Reviews')]");
    private By workflowSupplierDocs = By.xpath("//div[contains(text(),'Workflows and Supplier Documents')]");
    private By responseRequiredChkBox = By.xpath("//tr[@class='top-align ng-scope']//td//input");
    private By saveBtn = By.xpath("//button[contains(text(),'Save')]");
    private By replacementFile = By.xpath("//input[@value='MARKUP_BY_REPLACEMENT_FILE']");
    private By onlineMarkUp = By.xpath("//input[@value='MARKUP_BY_ONLINE_VIEWER']");
    private By addStatusSet = By.xpath("//button[contains(text(),'New Status Set')]");
    private By statusSetName = By.xpath("//input[@name='name']");
    private By autoUpdateChkBox = By.xpath("//input[@name='updateDocumentStatus']");
    private By documentStatusEntry = By.xpath("//select[@name='docStatusOnEntry']");
    private By documentStatus = By.xpath("//select[contains(@name,'documentStatusTo')]");
    private By reviewStatusField = By.xpath("//div[text()='Review Status Label']//..//div[2]//div[2]//input");
    private By documentStatusField = By.xpath("//div[text()='Document Status']//..//span//select");
    private By reviewStatusSelect = By.xpath("//select[@name='selectedReviewStatusSet']");
    private By inProgressLabel = By.xpath("//input[@name='inProgressLabel']");
    private By yesBtn = By.xpath("//button[@name='actionButton']");
    private By replacementFileElement = By.xpath("//input[@type='checkbox' and @value='MARKUP_BY_REPLACEMENT_FILE']");
    private By onlineMarkupElement = By.xpath("//input[@type='checkbox' and @value='MARKUP_BY_ONLINE_VIEWER']");


    /**
     * Method to navigate and verify page
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Setup", "Project Settings");
        navigateWorkflowSDPage();
    }

    /**
     * method to navigate to Mail Types page
     */
    public void navigateWorkflowSDPage() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, reviewsMenu, 8);
        $(reviewsMenu).click();
        commonMethods.waitForElement(driver, workflowSupplierDocs, 8);
        $(workflowSupplierDocs).click();
        verifyPageTitle("Project Settings");
    }

    /**
     * Function to verify default mark up options
     */
    public void verifyMarkupOptions() {
        switchProjectSettingsFrame();
        commonMethods.waitForElement(driver, saveBtn, 40);
        getElementInView(replacementFile);
        Assert.assertTrue($(replacementFile).isSelected());
        Assert.assertTrue($(onlineMarkUp).isSelected());
    }

    /**
     * Function to Uncheck default mark up options
     */
    public void uncheckMarkupOptions(boolean value) {
        switchProjectSettingsFrame();
        commonMethods.waitForElement(driver, saveBtn, 40);
        getElementInView(replacementFile);
        $(replacementFile).setSelected(value);
        $(onlineMarkUp).setSelected(value);
        getElementInView(saveBtn);
        $(saveBtn).click();
    }

    /**
     * Method to add the status set required for supplier documents
     * @param map
     */
    public void addWFNewStatusSet(Map<String, String> map) {
        $(addStatusSet).click();
        $(statusSetName).sendKeys(map.get("name"));
        Boolean autoUpdate = Boolean.getBoolean(map.get("auto_update"));
        $(autoUpdateChkBox).setSelected(autoUpdate);
        if(autoUpdate==true){
            $(documentStatusEntry).click();
            Select selectElement = new Select($(documentStatusEntry));
            selectElement.selectByVisibleText(map.get("Document Status on Entry"));
        }
        String[] reviewStatusLbls = map.get("Review Status").split(",");
        List<WebElement> reviewStatusList = driver.findElements(reviewStatusField);
        int index=0;
        for(String reviewStatus:reviewStatusLbls){
            reviewStatusList.get(index).sendKeys(reviewStatus + Keys.ENTER);
            index++;
        }
        if(autoUpdate==true){
            index=0;
            List<WebElement> documentStatusList = driver.findElements(documentStatusField);
            String[] documentStatuses = map.get("Document Status").split(",");
            for(String status:documentStatuses){
                documentStatusList.get(index).sendKeys(status + Keys.ENTER);
                index++;
            }
        }
        clickSaveBtn();
    }

    /**
     * Method to return the created review status sets
     * @return
     */
    public List<String> returnReviewSets() {
        Select select = new Select($(reviewStatusSelect));
        List<WebElement> reviewSetFields = select.getOptions();
        List<String> reviewSetText  = new ArrayList<>();
        for(WebElement element: reviewSetFields){
            reviewSetText.add(element.getText());
        }
        return reviewSetText;
    }

    /**
     * Method to enter the values to the field
     * @param value
     */
    public void enterInProgressField(String value) {
        $(inProgressLabel).clear();
        $(inProgressLabel).sendKeys(value);
        $(saveBtn).click();
        $(yesBtn).click();
    }

    /**
     * Method to return the value
     * @return
     */
    public Boolean returnInProgressDisplayed() {
        commonMethods.waitForElement(driver, inProgressLabel);
        return $(inProgressLabel).isDisplayed();
    }

    /**
     * Method to set the values for enabling markup options
     * @param replacementFileValue
     * @param onlineMarkupValue
     */
    public void enableMarkup(Boolean replacementFileValue, Boolean onlineMarkupValue){
        $(replacementFileElement).setSelected(replacementFileValue);
        $(onlineMarkupElement).setSelected(onlineMarkupValue);
        clickSaveBtn();
    }

    /**
     * Method to add the SD Status set to a project
     * @param data
     */
    public void addSDStatusSet(Map<String, String> data) {
        for(String key:data.keySet()){
            By by = By.xpath("//div[text()='"+key+"']//following::label//input");
            commonMethods.waitForElementExplicitly(300);
            $(by).setSelected(Boolean.valueOf(data.get(key)));
        }
    }
}
