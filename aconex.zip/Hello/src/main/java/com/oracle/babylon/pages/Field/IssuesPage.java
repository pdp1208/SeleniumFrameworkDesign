package com.oracle.babylon.pages.Field;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.WebDriverRunner;
import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import java.awt.*;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.datatransfer.StringSelection;
import java.io.File;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Selenide.*;

public class IssuesPage extends Navigator {

    private By addBtn = By.xpath("//button[text()='Add']");
    private By closeBtnOnNotification = By.xpath("//div[@class='cross']");
    protected By issueType = By.xpath("//div[@class='field issue-type']//div[@class='issuetype-field-search ui-select-match ng-scope']");
    protected By issueSearchInput = By.xpath("(//input[@type='search' and contains(@class,'form-control ui-select-search')])[3]");
    protected By textArea = By.xpath("//div[@class='field']//textarea");
    private By textAreaDescription = By.xpath("//textarea[@class='form-control auiField-input ng-pristine ng-valid ng-empty ng-valid-maxlength ng-touched']");
    //protected By photoAttachment=By.xpath("//input[@id='add-checklist-add-photo-attachment']");
    protected By photoAttach = By.xpath("//input[@id='add-checklist-edit-photo-attachment']");
    protected By photoAttachment = By.xpath("//label[@for='add-photo-attachment']");
    private By auiAddBtn = By.xpath("//*[@class='auiModal-footer']//button[contains(text(),'Add')]");
    private By fieldIssueAssignedTo = By.xpath("//div[@class='field issue-assigned-to']");
    private By fieldIssueAssignedToInput = By.xpath("(//input[@type='search' and contains(@class,'')])[2]");
    String filePath = System.getProperty("user.dir") + "//src//main//resources//data//files//";
    private String fieldIssueDataPath = configFileReader.getFieldIssueDataPath();
    private By searchIssueText = By.xpath("//div[@class='search-input-wrapper']//input");
    private By searchBtn = By.xpath("//div[@class='search-container']//button[contains(text(),'Search')]");
    private By saveBtn = By.xpath("//button[@class='auiButton primary']//span[text()='Save']");
    private By allAreas = By.xpath("//div[@class='fm-areas-panel ng-scope']//a[contains(text(),'Root Area')]");
    //private By allAreas=By.xpath("//div[@class='fm-areas-panel ng-scope']//a[text()='All Areas']");
    private By clearAll = By.xpath("//div[@class='clear-all-filter ng-binding']");
    private By issuesDisplayed = By.xpath("//div[@class='issue-status-group']//span");
    private By stackedBarChartOpen = By.xpath("//span[@class='stackedBarChart-barItem open ng-scope']");
    private By commentsSection = By.xpath("//textarea[@id='content']");
    private By postBtn = By.xpath("//button[text()='Post']");
    private By commentsAdded = By.xpath("//p[@class='comment-text auiText-normal ng-binding']");
    private By inputCheckBoxOnIssue = By.xpath("//span[@class='issue-number ng-binding' and text()='76031']//..//..//..//..//input[@type='checkbox']");
    private By exportBtn = By.xpath("//button//span[contains(text(),'Export')]");
    private By pdfExport = By.xpath("//a[@class='pdf-export-with-modal']");
    private By fileNamePDF = By.xpath("//div[@class='filNameInput']//input[@type='text']");
    private By photosSelected = By.xpath("//input[@id='with-photos']");
    private By exportBtnOnWindow = By.xpath("//button[contains(text(),'Export')]");
    private By toolsBtn = By.xpath("//button//span[contains(text(),'Tools')]");
    private By sendMail = By.xpath("//li[@class='send-option']//div[contains(text(),'Send')]");
    private By sendWithAconexMail = By.xpath("//span[contains(text(),'Send with Aconex Mail')]");
    private By mailTypeSelect = By.xpath("//span[@class='select2-selection select2-selection--single']");
    private By sendMailBtn = By.xpath("//button[@class='auiButton primary ng-binding' and text()='Send']");

    public void navigateAndVerifyPage() {
    	getMenuSubmenu("Tasks", "My Tasks");
        getMenuSubmenu("Field", "Issues");
//        String menu="Field";
//        String submenu="Issues";
//        driver = WebDriverRunner.getWebDriver();
//        driver.switchTo().defaultContent();
//        WebDriverWait wait = new WebDriverWait(driver, 65);
//        wait.until(ExpectedConditions.or(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='nav-barRow']"))));
//        By Menu = By.xpath("//button[contains(@class,'uiButton navBarButton')]//div[text()='" + menu + "']");
//        commonMethods.waitForElement(driver, firstMenu, 30);
//        if ($(menuChanger).exists() && !$(Menu).isDisplayed()) {
//            $(menuChanger).click();
//        }
//        try {
//            sleep(1000);
//            $(Menu).click();
//        } catch (NoSuchElementException e) {
//            throw new NoSuchElementException("Project not as per doc type");
//        }
//        wait.until(ExpectedConditions.or(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class,'navBarPanel-menuItem') and text()='" + submenu + "' ]"))));
//        $(By.xpath("//div[contains(@class,'navBarPanel-menuItem') and text()='" + submenu + "' ]")).click();
        $(loadingProgressIcon).should(disappear);
        commonMethods.waitForElementExplicitly(5000);
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, toolBarSection, 90);
        Assert.assertTrue("Issues Page title is not displayed", $(toolBarSection).getText().contains("Issues"));
    }

    public void closeNotification() {
        if ($(closeBtnOnNotification).exists())
            $(closeBtnOnNotification).click();
    }

    public void clickAddButton() {
        commonMethods.waitForElement(driver, addBtn);
        $(addBtn).click();
    }

    public String fillIssue(String issueTypeText, String assignedTo) {

        commonMethods.waitForElement(driver, issueType);
        $(issueType).click();
        try {
            commonMethods.waitForElement(driver, issueSearchInput, 60);
            $(issueSearchInput).sendKeys(issueTypeText);
        } catch (Exception e) {
            $(By.xpath("(//input[@type='search' and contains(@class,'form-control ui-select-search')])[2]")).sendKeys(issueTypeText);
        }
        commonMethods.waitForElementExplicitly(2000);
        By selectType = By.xpath("//span[@class='ui-select-choices-row-inner']//span[text()='" + issueTypeText + "']");
        commonMethods.waitForElement(driver, selectType);
        $(selectType).click();
        String descriptionValue = "This is for Testing Issue " + faker.number().digits(5);
        $(textArea).click();
        commonMethods.waitForElementExplicitly(3000);
        $(textArea).sendKeys(descriptionValue);
        commonMethods.waitForElementExplicitly(5000);
        //$(photoAttachment).click();
        //fileAttach(photoAttachment);
        //$(photoAttach).sendKeys(filePath + "photoMB.jpg");
        //commonMethods.waitForElementExplicitly(14000);
        //$(auiAddBtn).click();
        //commonMethods.waitForElementExplicitly(6000);
        // $(photoAttachment).sendKeys(filePath+"sample.png");
        //commonMethods.waitForElementExplicitly(3000);
        $(fieldIssueAssignedTo).click();
        $(fieldIssueAssignedToInput).sendKeys(assignedTo);
        $(By.xpath("//span[@class='ui-select-choices-row-inner']//*[contains(text(),'" + assignedTo + "')]")).click();
        commonMethods.waitForElementExplicitly(3000);
        $(saveBtn).click();
        $(By.cssSelector(".auiLoaderOverlay-loader")).waitUntil(disappear, 60000, 3000);
        return descriptionValue;
    }

    public void clickAllAreas() {
        commonMethods.waitForElement(driver, allAreas);
        $(allAreas).click();
        $(loadingIcon).should(Condition.disappear);
    }

    public void searchIssue(String issueValue) {
        commonMethods.waitForElement(driver, searchIssueText, 60);
        $(searchIssueText).clear();
        $(searchIssueText).sendKeys(issueValue);
        $(searchBtn).click();
    }

    public void verifySearchIssue(String description) {
        $(loadingIcon).should(Condition.disappear);
        By currentStatus = By.xpath("(//div[@class='description line']//span[contains(text(),'" + description + "')]//..//..//div[@class='issue-status ng-scope open'])[1]");
        commonMethods.waitForElement(driver, currentStatus, 60);
        Assert.assertTrue("Issue Current status is not displayed", $(currentStatus).isDisplayed());
    }

    public String getIssueNo(String Description) {
        By issueNo = By.xpath("(//div[@class='description line']//span[text()='" + Description + "']//..//..//span[@class='issue-number ng-binding'])[1]");
        commonMethods.waitForElement(driver, issueNo, 60);
        commonMethods.waitForElementExplicitly(2000);
        return $(issueNo).getText();
    }

    public boolean verifyIssueNo(String issueNo) {
        By issue = By.xpath("//span[@class='issue-number ng-binding' and text()='" + issueNo + "']");
        commonMethods.waitForElement(driver, issue, 60);
        commonMethods.waitForElementExplicitly(3000);
        return $(issue).isDisplayed();
    }

    public void writeIssueNumToJson(String issueId, String issueNo) {
        //Write the data to the json file
        Map<String, Object> map = new Hashtable<>();
        Map<String, Map<String, Object>> mapOfMap = new HashMap<>();
        map.put("issue_number", issueNo);
        mapOfMap.put(issueId, map);
        dataSetup.fileWrite(issueId, mapOfMap, fieldIssueDataPath);
    }

    public String getIssueNoFromJSON(String issueId) {
        Map<String, Map<String, Object>> jsonData = new HashMap<>();
        Map<String, Object> map = new HashMap<>();
        jsonData = dataSetup.loadJsonDataToMap(fieldIssueDataPath);
        map = jsonData.get(issueId);
        return map.get("issue_number").toString();
    }

    public void filterStatus(String status) {
        By filterValue = By.xpath("//input[@value='" + status + "']");
        commonMethods.waitForElement(driver, filterValue);
        $(filterValue).click();
        $(loadingIcon).should(Condition.disappear);
    }

    public void clearAllFilters() {
        commonMethods.waitForElement(driver, clearAll);
        $(clearAll).click();
    }

    public boolean verifyFilterStatus(String status) {
        boolean flag = false;
        commonMethods.waitForElementExplicitly(3000);
        for (int iterator = 1; iterator <= $$(issuesDisplayed).size(); iterator++) {
            Assert.assertTrue("Filtered Status " + status + " is not  displayed", $(By.xpath("(//div[@class='issue-status-group']//span)[" + iterator + "]")).getText().equalsIgnoreCase(status));
            flag = true;
        }
        return flag;
    }

    public String addComments() {
        String commentValue = "This is for Adding comments on Issue " + faker.number().digits(5);
        commonMethods.waitForElement(driver, commentsSection);
        $(commentsSection).click();
        $(commentsSection).sendKeys(commentValue);
        clickPostBtn();
        return commentValue;
    }

    public void clickPostBtn() {
        commonMethods.waitForElement(driver, postBtn);
        $(postBtn).click();
    }

    public String getAddedComments() {
        commonMethods.waitForElement(driver, commentsAdded);
        return $(commentsAdded).getText();
    }

    public void exportToPDF() {
        commonMethods.waitForElement(driver, exportBtn);
        $(exportBtn).click();
        commonMethods.waitForElement(driver, pdfExport);
        $(pdfExport).click();
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, fileNamePDF);
        $(fileNamePDF).sendKeys("as");
        $(photosSelected).isSelected();
        $(exportBtnOnWindow).click();
        commonMethods.waitForElementExplicitly(15000);
    }

    public void mailReport(String mailType) {
        commonMethods.waitForElement(driver, sendMail);
        $(sendMail).click();
        commonMethods.waitForElement(driver, sendWithAconexMail);
        commonMethods.waitForElementExplicitly(3000);
        $(mailTypeSelect).click();
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, By.xpath("//option[@label='" + mailType + "']"));
        $(By.xpath("//option[@label='" + mailType + "']")).click();
        //commonMethods.waitForElement(driver,By.xpath("select2-search__field"));
        //$(By.xpath("select2-search__field")).sendKeys(mailType + Keys.ENTER);
        $(sendWithAconexMail).click();
        commonMethods.waitForElementExplicitly(3000);
        $(sendMailBtn).click();
        commonMethods.waitForElementExplicitly(6000);
    }

    public void clickTools() {
        commonMethods.waitForElement(driver, toolsBtn);
        $(toolsBtn).click();
    }

    public void fileAttach(By by, String path) {
        driver.findElement(by).click();

        //put path to your image in a clipboard
        //String path=filePath+"photoMB.jpg";
        File file = new File(path);
        filePath = file.getAbsolutePath();
        StringSelection ss = new StringSelection(filePath);
        commonMethods.waitForElementExplicitly(3000);
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
        commonMethods.waitForElementExplicitly(4000);
        //imitate mouse events like ENTER, CTRL+C, CTRL+V
        try {
            Robot robot = new Robot();
            robot.delay(250);
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);
            robot.keyPress(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_V);
            robot.keyRelease(KeyEvent.VK_V);
            robot.keyRelease(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.delay(90);
            robot.keyRelease(KeyEvent.VK_ENTER);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }


}
