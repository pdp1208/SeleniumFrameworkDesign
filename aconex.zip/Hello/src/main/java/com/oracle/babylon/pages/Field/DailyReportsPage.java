package com.oracle.babylon.pages.Field;

import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class DailyReportsPage extends Navigator {

    private By dayWithNotStarted = By.xpath("(//span[text()='Not Started']//..//..//..//*[@class='icon-holder-div'])[1]");
    private By editButton = By.xpath("//*[@id='view-daily-reports-edit']");
    private By copyFromBtn = By.xpath("//div[@class='oj-button-label']//*[text()='Copy From']");
    private By saveBtn = By.xpath("//div[@class='report-container']//button[@class='oj-button-button']//*[text()='Save']");
    private By submitBtnOnContainer = By.xpath("//div[@class='report-container']//button[@class='oj-button-button']//*[text()='Submit']");
    private By submitBtnOnHeader = By.xpath("//div[@class='report-header']//button[@class='oj-button-button']//*[text()='Submit']");
    private By statusBadge = By.xpath("(//*[@class='oj-badge oj-badge-info oj-badge-subtle status-badge oj-badge-end'])[1]");
    private By backBtnOnReportHeader = By.xpath("//div[@class='report-header']//button[@class='oj-button-button']//*[text()='Back']");
    private By copyToBtn = By.xpath("//div[@class='report-header']//button[@class='oj-button-button']//*[text()='Copy To']");
    private By generalComments = By.xpath("//h6[@class='section-title' and contains(text(),'General Comments')]//..//..//*[contains(@class,'field-panel__input oj-textarea oj-form-control oj-component')]//textarea[@class='oj-textarea-input oj-text-field-input oj-component-initnode']");
    private By uploadPhotos = By.xpath("//input[@type='file']");
    private By uploadDialogBox = By.xpath("//button//*[@class='oj-button-text' and text()='Upload']");
    private By trashIcon = By.xpath("//div[@class='trash-icon oj-ux-ico-close-circle oj-typography-body-lg']");
    private By submitBtnEnabled = By.xpath("//*[@id='view-daily-reports-submit' and contains(@class,'oj-enabled')]");
    private By submitBtnDisabled = By.xpath("//*[@id='view-daily-reports-submit' and contains(@class,'oj-disabled')]");
    private By actionBtn = By.id("actionMenuButton");
    private By eventLog = By.id("daily-reports-event-log");
    private By eventLogHeader = By.xpath("//*[@class='event-log-page-title']");
    private By eventLogStatusChange = By.xpath("//td[text()='Status change']");
    private By eventLogStatusText = By.xpath("(//td[text()='Status change']//..//td[@class='oj-table-data-cell oj-form-control-inherit lg wrap-word'])[1]");
    private By startThisReport = By.xpath("//span[text()='Start this report']");
    private By dailyReportDate = By.xpath("//div[@class='daily-report-date']");
    private By filteringOn = By.xpath("//input[@placeholder='Search in Daily Reports']");
    private By successBadge = By.xpath("//span[@class='oj-badge oj-badge-success oj-badge-subtle status-badge']");
    private By copyBtnOnDialog = By.xpath("//div[@class='oj-button-label']//*[text()='Copy']");
    private By dateCopyFrom = By.xpath("//*[@class='oj-dialog-body']//input[@type='text' and @class='oj-inputdatetime-input oj-text-field-input oj-component-initnode']");
    private By filterOpenBtn = By.id("filter-open-btn");
    private By applyBtn = By.xpath("//div[@id='filter-button-container']//span[text()='Apply']");
    private By reOpenReport = By.id("daily-reports-reopen");
    private By reOpenBtn = By.xpath("//span[text()='Reopen']");
    private By dailyReportsDownload = By.id("daily-reports-download");
    private By copyToTodayHeader = By.xpath("//h1[text()='Copy to today']");
    private By copyBtn = By.xpath("//div//span[text()='Copy']");
    private By generalCommentsOnScreen = By.xpath("//h6[text()='General Comments']//..//a");
    private By generalCommentsText = By.xpath("//h6[text()='General Comments']//..//..//div[@class='oj-text-field-readonly']");
    private By copyFromDatePickerBox = By.xpath("//span[@class='oj-inputdatetime-input-trigger']");
    private By datePickerCurrentDay = By.xpath("//td[contains(@class,' oj-enabled   oj-datepicker-today')]//a");
    private By datePickerStartCurrentDay = By.xpath("//td[contains(@class,' oj-datepicker-days-cell-over oj-enabled   oj-datepicker-current-day')]//a");
    private By copyFromPreviousDailyReport = By.xpath("//h1[text()='Copy from previous daily report']");
    private By previousMonth = By.xpath("//*[@class='oj-datepicker-prev-icon oj-enabled oj-default oj-component-icon oj-clickable-icon-nocontext']");
    private By nextMonth = By.xpath("//*[@class='oj-datepicker-next-icon oj-enabled oj-default oj-component-icon oj-clickable-icon-nocontext']");
    //private By previousMonth=By.xpath("//*[@class='oj-datepicker-prev-icon oj-enabled oj-default oj-component-icon oj-clickable-icon-nocontext']");
    private By monthFirstDate = By.xpath("//td//a[text()='1']");
    private By inputTo = By.id("filter-end-date|input");
    private By inputFrom = By.id("filter-start-date|input");
    private By firstDay = By.xpath("(//div[@id='date-container']//div[contains(@class,'dr-day-card')])[1]//div[@class='info-holder']");
    private By getStatusBadge = By.xpath("//div[contains(@class,'status-badge')]//span[@class='status-container']");
    private By dateContainer = By.xpath("//div[@class='dr-day-card']//div[@class='date-container']");
    private By clearAllBtn = By.xpath("//span[contains(@id,'filter-clear-button')]");

    public void navigateAndVerifyPage() {
        getMenuSubmenu("Field", "Daily Reports");
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, header5Section, 120);
        Assert.assertTrue("Daily Reports page title is not displayed", $(header5Section).getText().contains("Daily Reports"));
    }

    public void selectDay(String instance) {
        //int size=driver.findElements(By.xpath("//span[text()='" + instance + "']//..//..//..//*[@class='icon-holder-div']")).size();
        commonMethods.waitForElementExplicitly(4000);
        try {
            By daySelect = By.xpath("(//span[text()='" + instance + "']//..//..//..//*[@class='icon-holder-div'])[1]");
            commonMethods.waitForElementExplicitly(4000);
            WebDriverWait wait = new WebDriverWait(driver, 20);
            wait.until(ExpectedConditions.or(ExpectedConditions.visibilityOfElementLocated(daySelect)));
            $(daySelect).click();
        } catch (Exception e) {
            if (instance.equalsIgnoreCase("In Progress")) {
                selectSubmittedDay();
                navigateToreOpenDailyReport();
                clickBackOnDailyReports();
            }
            selectInProgressDay();
        }
    }

    public String selectNotStartedInstance() {
        String choosenDate = "";
        commonMethods.waitForElementExplicitly(4000);
        By daySelect = By.xpath("(//span[text()='Not Started']//..//..//..//*[@class='icon-holder-div'])[1]");
        try {
            WebDriverWait wait = new WebDriverWait(driver, 20);
            wait.until(ExpectedConditions.or(ExpectedConditions.visibilityOfElementLocated(daySelect)));
            commonMethods.waitForElementExplicitly(2000);
            $(daySelect).click();
            commonMethods.waitForElementExplicitly(4000);
            choosenDate = getChosenDate();
            startReport();
        } catch (Exception e) {
            commonMethods.waitForElementExplicitly(4000);
            selectInProgressDay();
            choosenDate = getChosenDate();
            clickEdit();
        }
        return choosenDate;
    }

    public void selectFirstDay() {
        commonMethods.waitForElementExplicitly(4000);
        commonMethods.waitForElement(driver, firstDay);
        $(firstDay).click();
    }

    public void selectDateRange() {
        filterOpenBtn();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, inputFrom);
        $(inputFrom).click();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, datePickerStartCurrentDay);
        //String currentDay=$(datePickerCurrentDay).getText();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, previousMonth);
        $(previousMonth).click();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, monthFirstDate);
        $(monthFirstDate).click();
        commonMethods.waitForElementExplicitly(4000);
        clickApplyBtn();
    }

    public void selectNextDay(String instance) {
        By daySelect = By.xpath("(//span[text()='" + instance + "']//..//..//..//*[@class='icon-holder-div'])[2]");
        commonMethods.waitForElementExplicitly(8000);
        if (!($(daySelect).isDisplayed()))
            selectDay("In Progress");
        try {
            WebDriverWait wait = new WebDriverWait(driver, 40);
            wait.until(ExpectedConditions.visibilityOfElementLocated(daySelect));
        } catch (Exception e) {
            daySelect = By.xpath("(//*[@class='icon-holder-div'])[2]");
            $(daySelect).click();
            commonMethods.waitForElementExplicitly(3000);
            if (getStatus().equalsIgnoreCase("Not Started")) {
                startReport();
                updateComments("Case Start");
                saveBtnOnDailyReports();
                commonMethods.waitForElementExplicitly(3000);
                clickBackOnDailyReports();
            }
            commonMethods.waitForElementExplicitly(3000);
            navigateToreOpenDailyReport();
            commonMethods.waitForElementExplicitly(3000);
            clickBackOnDailyReports();
            commonMethods.waitForElementExplicitly(4000);
        }
        $(daySelect).click();
    }

    public void clickEdit() {
        commonMethods.waitForElement(driver, editButton);
        $(editButton).click();
    }

    public void startReport() {
        commonMethods.waitForElementExplicitly(3000);
        JavascriptExecutor js = ((JavascriptExecutor) driver);
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        commonMethods.waitForElement(driver, startThisReport);
        $(startThisReport).click();
    }

    /**
     * Method to get the upload Org Logo
     */
    public void uploadPhoto(String fileName) {
        String filePath = configFileReader.getTestDataPath() + fileName;
        File file = new File(filePath);
        filePath = file.getAbsolutePath();
        commonMethods.waitForElement(driver, By.xpath("//*[@id='attachments-file-picker']"));
//        $(By.xpath("//*[@id='attachments-file-picker']//input")).sendKeys(filePath);
        IssuesPage issuesPage = new IssuesPage();
        issuesPage.fileAttach(By.xpath("//*[@id='attachments-file-picker']"), filePath);
        commonMethods.waitForElement(driver, uploadDialogBox);
        commonMethods.waitForElement(driver, trashIcon);
        getElementInView(trashIcon);
        $(uploadDialogBox).click();

    }

    public void updateComments(String textComments) {
        commonMethods.waitForElement(driver, generalComments);
        $(generalComments).clear();
        $(generalComments).sendKeys(textComments);
    }

    public boolean verifySubmitButton(String instance) {
        commonMethods.waitForElementExplicitly(3000);
        if (instance.equalsIgnoreCase("Enable"))
            return $(submitBtnEnabled).isDisplayed();
        else
            return $(submitBtnDisabled).isDisplayed();
    }

    public void clickSubmitButtonOnHomePage() {
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, submitBtnEnabled);
        $(submitBtnEnabled).click();
    }

    public void navigateToEventLog() {
        commonMethods.waitForElement(driver, actionBtn);
        $(actionBtn).click();
        commonMethods.waitForElement(driver, eventLog);
        $(eventLog).click();
    }

    public String verifyEventLog() {
        commonMethods.waitForElement(driver, eventLogStatusChange, 60);
        return $(eventLogStatusText).getAttribute("innerText");
    }

    public void saveBtnOnDailyReports() {
        getElementInView(saveBtn);
        commonMethods.waitForElement(driver, saveBtn);
        $(saveBtn).click();
    }

    public void clickBackOnDailyReports() {
        commonMethods.waitForElement(driver, backBtnOnReportHeader);
        $(backBtnOnReportHeader).click();
    }

    public boolean verifySubmitButtonOnContainer(String instance) {
        commonMethods.waitForElementExplicitly(3000);
        if (instance.equalsIgnoreCase("Enable"))
            return $(submitBtnOnContainer).isDisplayed();
        else
            return $(submitBtnOnContainer).isDisplayed();
    }

    public void clickSubmitButton() {
        commonMethods.waitForElement(driver, submitBtnOnContainer);
        commonMethods.waitForElementClickable(driver, submitBtnOnContainer, 10);
        $(submitBtnOnContainer).click();
        commonMethods.waitForElementExplicitly(5000);
    }

    public String getChosenDate() {
        commonMethods.waitForElementExplicitly(4000);
        commonMethods.waitForElement(driver, dailyReportDate);
        return $(dailyReportDate).getText();
    }

    public void filterSearch(String dateSearch) {
        commonMethods.waitForElement(driver, filteringOn);
        $(filteringOn).clear();
        $(filteringOn).sendKeys(dateSearch);
        commonMethods.waitForElementExplicitly(4000);
    }

    public void verifySuccessBadge() {
        commonMethods.waitForElement(driver, successBadge);
        Assert.assertEquals("Submitted badge is not displayed", "Submitted", $(successBadge).getText());
    }

    public void filterOpenBtn() {
        commonMethods.waitForElement(driver, filterOpenBtn);
        $(filterOpenBtn).click();
    }

    public void setSelect(String value) {
        commonMethods.waitForElementExplicitly(5000);
        getElementInView(By.id("status-label"));
        commonMethods.waitForElement(driver, clearAllBtn);
        $(clearAllBtn).click();
        $(By.xpath("//*[@id='filter-status-checkbox']//*[text()='Not Started']")).click();
        $(By.xpath("//*[@id='filter-status-checkbox']//*[text()='In Progress']")).click();
        $(By.xpath("//*[@id='filter-status-checkbox']//*[text()='Submitted']")).click();
        commonMethods.waitForElementExplicitly(3000);
        $(By.xpath("//*[@id='filter-status-checkbox']//*[text()='" + value + "']")).click();
        //$(By.xpath("//input[@value='"+value+"']")).setSelected(true);
    }

    public void clickApplyBtn() {
        commonMethods.waitForElement(driver, applyBtn);
        $(applyBtn).click();
    }

    public boolean verifyStatusOnFilter(String filterValue) {
        commonMethods.waitForElementExplicitly(5000);
        boolean flag = false;
        int statusSize = $$(By.xpath("//div[@class='status-container']")).size();
        for (int iterator = 1; iterator <= statusSize; iterator++) {
            Assert.assertEquals(filterValue, $(By.xpath("(//div[@class='status-container'])[" + iterator + "]")).getText());
            flag = true;
        }
        return flag;
    }

    public void navigateToreOpenDailyReport() {
        if (getStatus().equalsIgnoreCase("In Progress")) {
            clickSubmitButtonOnHomePage();
            commonMethods.waitForElementExplicitly(4000);
        }
        commonMethods.waitForElement(driver, actionBtn);
        commonMethods.waitForElementExplicitly(3000);
        $(actionBtn).click();
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, reOpenReport);
        $(reOpenReport).click();
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, reOpenBtn, 60);
        $(reOpenBtn).click();
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, submitBtnOnContainer, 120);
    }

    public void downloadPDFReport() {
        commonMethods.waitForElement(driver, actionBtn);
        $(actionBtn).click();
        commonMethods.waitForElement(driver, dailyReportsDownload);
        $(dailyReportsDownload).click();
        commonMethods.waitForElementExplicitly(5000);
    }

    public void clickOnCopyTo() {
        commonMethods.waitForElement(driver, copyToBtn);
        $(copyToBtn).click();
        commonMethods.waitForElement(driver, copyToTodayHeader);
        clickCopyBtn();
    }

    public void clickCopyBtn() {
        commonMethods.waitForElement(driver, copyBtn);
        getElementInView(copyBtn);
        $(copyBtn).click();
    }

    public void verifyGeneralComments(String comments) {
        commonMethods.waitForElement(driver, generalCommentsOnScreen);
        Assert.assertEquals(comments, getGeneralComments());

    }

    public String getGeneralComments() {
        getElementInView(generalCommentsOnScreen);
        $(generalCommentsOnScreen).click();
        commonMethods.waitForElement(driver, generalCommentsText);
        return $(generalCommentsText).getText();
    }

    public void clickCopyFrom() {
        commonMethods.waitForElement(driver, copyFromBtn);
        $(copyFromBtn).click();
        commonMethods.waitForElement(driver, copyFromPreviousDailyReport);
        getElementInView(copyBtn);
        commonMethods.waitForElementExplicitly(4000);
        $(copyFromDatePickerBox).click();
        commonMethods.waitForElementExplicitly(4000);
        try {
            //$(datePickerCurrentDay).waitUntil(Condition.visible, 10000);
            WebDriverWait wait = new WebDriverWait(driver, 40);
            wait.until(ExpectedConditions.visibilityOfElementLocated(datePickerCurrentDay));
            $(datePickerCurrentDay).click();
        } catch (Exception e) {
            commonMethods.waitForElement(driver, nextMonth);
            $(nextMonth).click();
            commonMethods.waitForElementExplicitly(4000);
            commonMethods.waitForElement(driver, datePickerCurrentDay);
            $(datePickerCurrentDay).click();
        }
       /* $(By.xpath("//span[@class='oj-inputdatetime-input-trigger']//..//input[@class='oj-inputdatetime-input oj-text-field-input oj-component-initnode']")).clear();
        commonMethods.waitForElementExplicitly(4000);
        $(By.xpath("//span[@class='oj-inputdatetime-input-trigger']//..//input[@class='oj-inputdatetime-input oj-text-field-input oj-component-initnode']")).sendKeys(commonMethods.getTodayDate("Australia/Sydney"));
        commonMethods.waitForElementExplicitly(4000);*/
        commonMethods.waitForElementExplicitly(4000);
        clickCopyBtn();
    }

    public void verifyStatusBadge(String status) {
        commonMethods.waitForElementExplicitly(4000);
        commonMethods.waitForElement(driver, statusBadge, 40);
        Assert.assertEquals("Status " + status + " is not displayed", status, $(statusBadge).getText());
    }

    public String getStatus() {
        commonMethods.waitForElement(driver, getStatusBadge);
        return $(getStatusBadge).getText();
    }

    public void selectDate(String date) {
        int size = driver.findElements(dateContainer).size();
        for (int iterator = 1; iterator <= size; iterator++) {
            By loc = By.xpath("(//div[@class='dr-day-card']//div[@class='date-container'])[" + iterator + "]");
            commonMethods.waitForElement(driver, loc);
            String dateValue = driver.findElement(loc).getText();
            if (dateValue.contains(date)) {
                $(loc).click();
            }
        }
    }

    public void selectInProgressDay() {
        try {
            commonMethods.waitForElementExplicitly(4000);
            By daySelect = By.xpath("(//span[text()='In Progress']//..//..//..//*[@class='icon-holder-div'])[1]");
            commonMethods.waitForElementExplicitly(4000);
            WebDriverWait wait = new WebDriverWait(driver, 20);
            wait.until(ExpectedConditions.or(ExpectedConditions.visibilityOfElementLocated(daySelect)));
            $(daySelect).click();
        } catch (Exception ex) {
            selectSubmittedDay();
            navigateToreOpenDailyReport();
            clickBackOnDailyReports();
            selectInProgressDay();
        }
    }

    public void selectSubmittedDay() {
        commonMethods.waitForElementExplicitly(4000);
        By daySelect = By.xpath("(//span[text()='Submitted']//..//..//..//*[@class='icon-holder-div'])[1]");
        commonMethods.waitForElementExplicitly(4000);
        $(daySelect).click();
    }
}


