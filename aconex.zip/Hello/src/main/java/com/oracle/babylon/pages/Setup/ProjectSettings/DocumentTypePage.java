package com.oracle.babylon.pages.Setup.ProjectSettings;

import com.oracle.babylon.Utils.helper.Navigator;
import com.oracle.babylon.pages.Setup.ProjectSettingsPage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.util.*;

import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Selenide.*;

public class DocumentTypePage extends ProjectSettingsPage {

    private By typeLabel = By.xpath("//b[contains(text(),'Type')]");
    private By codeLabel = By.xpath("//b[contains(text(),'Code')]");
    private By autoNumLabel = By.xpath("//b[contains(text(),'Auto Numbering')]");
    private By settingsLabel = By.xpath("//span[contains(text(),'Settings')]");
    private By projectFieldsLabel = By.xpath("//div[contains(text(),'Project Fields')]");
    private By appliedFields = By.xpath("//div[text()='Applied Fields']");
    private By sequenceLength =By.xpath("//select[@ng-model='settings.sequenceNumberLength']");
    private By documentFieldsLabel = By.xpath("//div[@class='customFieldsListPage-applied']//div[contains(text(),'Applied Fields')]");
    private By docTypeBackBtn = By.xpath("//button[@title='Back']");
    private By docTypeSaveBtn = By.xpath("//button[contains(text(),'Save')]");
    private By docTypeHeading = By.xpath("//span[contains(text(),'Document Type')]");
    private By name = By.xpath("//input[@name='schemeName']");
    private By seqNumUpArrow = By.xpath("//input[@value='Sequence Number']//..//div//button[@title='Move one position up']");
    private By addField = By.xpath("//button[contains(text(),'Add Field')]");
    private By notEnabledText= By.xpath("//*[contains(text(),'Not Enabled')]");
    private By autoNumberingText= By.xpath("//span[contains(text(),'Auto Numbering')]");
    private By editAutoNumIcon = By.xpath("//edit-icon[@title='Auto Numbering']");
    private By enableAutoNumChkBx = By.xpath("//label[@class='auiField-checkbox ng-binding']//input");
    private By schemeName = By.xpath("//div[contains(text(),'Scheme Name')]");
    private By schemeDetails = By.xpath("//div[contains(text(),'Scheme Details')]");
    private By preview = By.xpath("//span[contains(text(),'Preview:')]");
    private By seqNumInput = By.xpath("//input[@class='auiField-input large ng-scope']");
    private By seqNum = By.xpath("//div[contains(text(),'Sequence Number')]");
    private By autoNumSettingSaveBtn = By.xpath("//div[@class='auiModal-footer']//button[contains(text(),'Save')]");
    private By notEnabledLabel = By.xpath("//p[contains(text(),'Not Enabled')]");
    private By previewText = By.xpath("//div[@ng-if='autoNumberingEnabled']//p[2]");
    String docNumberingPath = configFileReader.getDocNumberingDataPath();
    final private By type = By.xpath("//select[@id='doctype']");
    final private By typeColumn = By.xpath("//div[@class='documentTypesList']//th[1]/b");
    final private By codeColumn = By.xpath("//div[@class='documentTypesList']//th[2]/b");
    final private By autoNumberingColumn = By.xpath("//div[@class='documentTypesList']//th[3]/b");
    final private By documentTypeList = By.xpath("//div[@class='documentTypesList']//tr//a//following::td[@class='ng-binding']");
    final private By autoNumberingTickMarkCount = By.xpath("//table[@class='auiTable']//td//div[@class='tick']");
    final private By documentTypeCount = By.xpath("//table[@class='auiTable']//td//a");
    static List<String> projectSetDocTypeValues = new ArrayList<>();
    final private By documentTypes = By.xpath("//select[@id='doctype']//option");
    final private By autoNumberEnabled = By.xpath("//div[@class='customFieldsListPage-settings']//settings-body//span[text()='Auto Numbering']//following::div[@ng-if='autoNumberingEnabled']/p[text()='Enabled']");
    final private By headerProjectFields = By.xpath("//div[@class='customFieldsListPage-main']//div[@class='section-heading']//div[text()='Project Fields']");
    final private By newFieldBtn = By.xpath("//div[@class='customFieldsListPage-main']//button[text()='+ New Field']");
    final private By searchProjectFieldTxt = By.xpath("//div[@class='customFieldsListPage-main']//input[@placeholder='Search Project Fields']");
    final private By projectFieldsList = By.xpath("//div[@class='list-group-item ng-scope']");
    final private By documentFieldHeader = By.xpath("//div[@class='customFieldsListPage-applied']//div[@class='section-heading']//div[text()='Applied Fields']");
    final private By documentFieldCol = By.xpath("//div[@class='tableContent']//label[text()='Field']");
    final private By mandatoryDocumentFieldCol = By.xpath("//div[@class='tableContent']//div[text()='Mandatory']");
    final private By pencilIcon = By.xpath("//div[@class='customFieldsListPage-settings']//settings-body//span[text()='Auto Numbering']//following::edit-icon");
    final private By closeBtn = By.xpath("//div[@class='auiModal-close']");
    final private By saveBtn = By.xpath("//div[@class='auiModal-footer']//button[@class='auiButton primary ng-binding' and contains(text(),'Save')]");
    final private By cancelBtn = By.xpath("//div[@class='auiModal-footer']//button[@class='auiButton ng-binding' and contains(text(),'Cancel')]");
    final private By autoNumberScheme = By.xpath("//div[@class='numberPreview']//span");
    final private By autoSettingAlertMessage = By.xpath("//div[@class='auiMessage info']//div[contains(text(),'In order to add a project field of this document type to the scheme, it must be mandatory and codes must be enabled')]");
    final private By autoNumberingChkBox = By.xpath("//div[@class='dialog-message']//label//input");
    final private By autoSettingHeaderTxt = By.xpath("//div[@class='doc-auto-num-dialog']//div[@class='auiModal-header']//h3");
    final private By newFieldType = By.xpath("//div[@class='form-section']//div[@class='form-field']//select/../preceding-sibling::div//label[text()='Type']");
    final private By newFieldLabel = By.xpath("//div[@class='form-section']//div[@class='form-field']//input/../preceding-sibling::div//label[text()='Label']");
    final private By newFieldToolTipTxtArea = By.xpath("//div[@class='form-section']//div[@class='form-field']//textarea/../preceding-sibling::div//label[text()='Tool Tip']");
    final private By newFieldName = By.xpath("//div[@class='form-section']//div//label[text()='Field Name']");
    final private By newFieldSaveBtn = By.xpath("//button[@name='saveButton']");
    final private By newFieldCancelBtn = By.xpath("//button[text()='Cancel']");
    final private By projectFieldPencilIcon = By.xpath("(//div[@class='list-group scroll']//div[@class='ng-scope']//descendant::div)[1]");
    final private By disableBtn = By.xpath("//button[text()='Disable']");
    final private By projectFieldTypeTxt = By.xpath("//form[@name='form.createCustomFieldForm']//div/label[text()='Type']/../following-sibling::div");
    final private By plusIcon = By.xpath("(//div[@class='list-group scroll']//div[@class='ng-scope']//descendant::div)[2]");
    final private By projectFieldNameTxt = By.xpath("(//div[@class='list-group scroll']//div[@class='ng-scope']//descendant::div[1]//following-sibling::h4)[1]");
    final private By projectFieldNameInDoc = By.xpath("//table[@class='auiTable']/tbody/tr/td[3]/div");
    final private By removeBtn = By.xpath("//button[contains(text(),'Remove')]");
    final private By fieldsList = By.xpath("//table[@class='auiTable']//input[@type='checkbox' and @class='auiField-input']//following::th[text()='Field']//following::th[text()='Mandatory']");
    private By docFieldsList = By.xpath("//div[@class='tableContent']/table[@class='auiTable']//tbody//div[text()='Type']//following::input[@checked='checked']");
    static String projectFieldText;
    final private By docSectionProjectFieldTxt = By.xpath("//div[@class='auiForm-section auiDetails-row project-fields ng-scope']//label[@class='ng-binding']");
    final private By docSecMandatoryProjectFieldTxt = By.xpath("//div[@class='auiForm-section auiDetails-row project-fields ng-scope']//div[@required='required']//label[@class='ng-binding']");
    final private By removeChk = By.xpath("(//div[@class='associatedCustomFields-tableContent']//input)[1]");
    final private By docNumberSelectBox = By.xpath("//input[@id='docno' and @required='required']");
    final private By mandatoryFieldChk = By.xpath("(//div[@class='associatedCustomFields-tableContent']//input)[3]");
    final private By schemeNameTxtBox = By.xpath("//input[@name='schemeName']");
    final private By autoNumberingNotEnabledTxt = By.xpath("//p[text()='Not Enabled']");
    final private By backBtn = By.xpath("//button[@class='auiButton back']");
    final private By documentFieldsLink = By.xpath("//div[@id='DocFields']");
    final private By documentFieldsList = By.xpath("//table[@class='dataTable']//tbody//tr//td[1]");
    final private By docFieldListProjectSettings = By.xpath("//div[@data-automation-id='document_fields_section']//table[@class='auiTable']//tbody//tr//td[1]");
    private By documentTypeSelectBox = By.id("doctype");
    private By lblAppliedDocFields = By.xpath("//div[@class='customFieldsListPage-applied']//ul/li//div[@class='fieldName']");
    String docTypeTxt = "//span[contains(text(),'@')]";
    private By btnUpArrow = By.xpath("//button[@class='auiButton auiIcon chevronButtons chevronUp']");
    private By btnDownArrow = By.xpath("//button[@class='auiButton auiIcon chevronButtons chevronDown']");
    private By appliedFieldNames = By.xpath("//li[contains(@id, 'draggable_')]//div[@class='fieldName']/label[1]");
    private String mandatoryFields = "//li[contains(@id, 'draggable_')]//div[@class='mandatoryCheckbox']";
    private String documentFields = "//li[contains(@id, 'draggable_')]//div[@class='fieldType']";
    private By btnPreview = By.xpath("//button[contains(text(),'Preview')]");
    private By lblPreviewFields = By.xpath("//upload-form-preview//div[contains(@class,'auiForm-label')]/label[1]");
    private By tabPreview = By.xpath("//*[contains(text(),'Preview for')]");
    private By btnDismiss = By.xpath("//button[contains(text(),'Dismiss')]");
    private By lblAppliedFields = By.xpath("//div[contains(text(),'Applied Fields')]");
    private By errorRemoveMsg = By.xpath("//div[contains(text(),'Document fields cannot be removed.')]");
    private String projectLabels = "//div[@class='fieldType']//label[text()='Project']";
    private By delimeterDropDown = By.xpath("(//div[@class='scheme-element-container']/select)[2]");
    private By documentTypeCodeDropdown = By.xpath("(//div[@class='scheme-element-container']/select)[1]");
    private By schemeDetailElement1 = By.xpath("(//div[@class='scheme-element-container']/select)[1]");
    private By documentTypeCodeDropdownValues = By.xpath("(//div[@class='scheme-element-container']/select)[1]/option");
    private By projectCodeDropdownValues = By.xpath("(//div[@class='scheme-element-container']/select)[4]/option");
    private By discipleDropdownValues = By.xpath("(//div[@class='scheme-element-container']/select)[8]/option");
    private By organizationCodeDropdownValues = By.xpath("(//div[@class='scheme-element-container']/select)[6]/option");
    private By startsAt = By.xpath("//input[@name='sequenceNumberStartsAt']");
    private By autoNumberingValues = By.xpath("//table[@class='auiTable']//td[3]");
    private By autoNumberinglabel = By.xpath("(//div[@class='auiText-small']/p)[2]");
    private By searchProjectFields = By.xpath("//input[@placeholder='Search Project Fields']");
    private By editIcon = By.xpath("//div[@class='auiIcon edit list-group-item-icon pull-left']");
    private By message1 = By.xpath("//div[contains(text(),'Changes you make to this Project Field will')]");
    private By message3 = By.xpath("//li[contains(text(),'affect the following Document Types')]");
    private By message4 = By.xpath("//li[contains(text(),'affect the following Document Types')]");
    private By message5 = By.xpath("//li[contains(text(),'affect the following Package Types')]");
    private By message6 = By.xpath("//li[contains(text(),'affect the following Field Issue Types')]");
    String projectFieldName;
    List<String> mandatoryFieldList;
    static List<String> documentFieldsNames;
    DocumentDrawingSetting documentDrawingSettings = new DocumentDrawingSetting();
    DocumentFieldsPage documentFieldsPage = new DocumentFieldsPage();
    public static List<String> appliedFieldsList = new LinkedList<>();
    public static List<String> mandatoryFieldsList = new LinkedList<>();
    Map<String, Map<String, Object>> mapOfMap = new Hashtable<>();
    String projectFieldsPath = configFileReader.getProjectFieldsDataPath();
    Navigator navigator = new Navigator();
    Actions act = new Actions(driver);

    /**
     * Method to verify Document Type tab
     */

    public void verifyDocTypeTab() {
        commonMethods.waitForElement(driver, typeLabel, 60);
        Assert.assertTrue($(typeLabel).isDisplayed());
        Assert.assertTrue($(codeLabel).isDisplayed());
        Assert.assertTrue($(autoNumLabel).isDisplayed());
    }
    /**
     * Method to verify AutoNumbering label
     */
    public void verifyAutoNumLabel(String docName) {
        commonMethods.waitForElement(driver, autoNumberinglabel, 60);
        Assert.assertTrue($(autoNumberinglabel).getText().contains(commonMethods.getAutoNumbering(docName).split(":")[1]));
    }
    /**
     * Method to verify Doc type AutoNumbering column is null
     */
    public Boolean verifyAutoNumColIsNull() {
        commonMethods.waitForElement(driver, autoNumberingValues, 20);
        List<WebElement> values = driver.findElements((autoNumberingValues));
        for (int i = 0; i < values.size(); i++) {
            if (!values.get(i).getText().equalsIgnoreCase("")) {
                return false;
            }
        }
        return true;
    }
    /**
     * Method to verify fields status in applied field
     */
    public void verifyFieldStatusInDocType(String value, List<String> data) {
        switch (value) {
            case "Checked":
                for (String field : data) {
                    By fields = By.xpath("//label[contains(text(),'" + field + "')]/../following-sibling::div/input[@type='checkbox']");
                    Assert.assertTrue($(fields).isSelected());
                    Assert.assertFalse($(fields).isEnabled());
                }
                break;
            case "Not Checked":
                for (String field : data) {
                    By fields = By.xpath("//label[contains(text(),'" + field + "')]/../following-sibling::div/input[@type='checkbox']");
                    Assert.assertFalse($(fields).isSelected());
                    Assert.assertFalse($(fields).isEnabled());
                }
                break;
        }
    }
    /**
     * Method to verify  project fields status in applied field
     */
    public void verifyProjFieldStatusInDocType(String value, List<String> data) {
        switch (value) {
            case "applied Field-Not mandatory":
                for (String field : data) {
                    String fieldValue=commonMethods.getLabelName(field);
                    commonMethods.waitForElementExplicitly(2000);
                    By fields = By.xpath("//label[contains(text(),'" + fieldValue + "')]/../following-sibling::div/input[@type='checkbox']");
                    Assert.assertFalse($(fields).isSelected());
                    Assert.assertTrue($(fields).isEnabled());
                }
                break;
            case "applied Field-mandatory":
                for (String field : data) {
                    String fieldValue=commonMethods.getLabelName(field);
                    commonMethods.waitForElementExplicitly(2000);
                    By fields = By.xpath("//label[contains(text(),'" + fieldValue + "')]/../following-sibling::div/input[@type='checkbox']");
                    if($(fields).isEnabled())
                    {
                        switchProjectSettingsFrame();
                        $(fields).setSelected(true);
                        Assert.assertTrue($(fields).isSelected());
                        clickAppliedFieldSave();
                    }
                }
                break;
        }
    }

    /**
     * Method to click Doc Type
     */
    public void clickDocType(String docType) {
        By xpath = By.xpath("//a[contains(text(),'" + docType + "')]");
        commonMethods.waitForElement(driver, xpath, 60);
        $(xpath).click();
    }

    /**
     * Method to verify details od Document Type
     */
    public void verifyDocType(String docType) {
        commonMethods.waitForElement(driver, docTypeHeading, 45);
        Assert.assertTrue($(docTypeHeading).isDisplayed());
        Assert.assertTrue($(settingsLabel).isDisplayed());
        Assert.assertTrue($(projectFieldsLabel).isDisplayed());
        Assert.assertTrue($(appliedFields).isDisplayed());
        Assert.assertTrue($(docTypeBackBtn).isDisplayed());
        Assert.assertTrue($(docTypeSaveBtn).isDisplayed());
        Assert.assertTrue($(btnPreview).isDisplayed());
        Assert.assertTrue($(editAutoNumIcon).isDisplayed());
        Assert.assertTrue($(autoNumberingText).isDisplayed());
        verifyElementPresent(docTypeTxt, docType, "Doc Type is displayed");
    }
    /**
     * Method to verify fields in Doc Type Auto number
     */
    public void verifyFieldDocTypeAutoNum() {
        commonMethods.waitForElement(driver, documentTypeCodeDropdown, 45);
        Assert.assertTrue($(documentTypeCodeDropdown).isDisplayed());
        Assert.assertTrue($(delimeterDropDown).isDisplayed());
        Assert.assertTrue($(seqNum).isDisplayed());
        Assert.assertTrue($(seqNumInput).isDisplayed());
    }

    /**
     * Method to verify  project fields status in applied field
     */
    public void verifyProjectFieldStatus(Boolean projectFieldStatus,List<String> fildvalues ){
        for (String field : fildvalues) {
            String fieldValue = commonMethods.getLabelName(field);
            commonMethods.waitForElementExplicitly(2000);
            verifyFieldValues(fieldValue, projectFieldStatus);
        }
    }
    /**
     * Method to verify document fields status in applied field
     */
    public void verifyDocFieldStatus(Boolean DocFieldStatus,List<String> fildvalues )
    {
        for (String field : fildvalues) {
            clickAddField();
            verifyFieldValues(field, DocFieldStatus);
        }

    }
    /**
     * Method to verify fields status in applied field
     */
    public void verifyFieldValues(String fieldvalue,boolean DocFieldStatus) {
        if(DocFieldStatus) {

            Assert.assertTrue(getDropdownValues(driver, documentTypeCodeDropdownValues).contains(fieldvalue));
            Assert.assertTrue(getDropdownValues(driver, projectCodeDropdownValues).contains(fieldvalue));
            Assert.assertTrue(getDropdownValues(driver, organizationCodeDropdownValues).contains(fieldvalue));
            Assert.assertTrue(getDropdownValues(driver, discipleDropdownValues).contains(fieldvalue));

        }else {

            Assert.assertFalse(getDropdownValues(driver, documentTypeCodeDropdownValues).contains(fieldvalue));
            Assert.assertFalse(getDropdownValues(driver, projectCodeDropdownValues).contains(fieldvalue));
            Assert.assertFalse(getDropdownValues(driver, organizationCodeDropdownValues).contains(fieldvalue));
            Assert.assertFalse(getDropdownValues(driver, discipleDropdownValues).contains(fieldvalue));

        }
    }
    /**
     * Method to get drodown values
     */
    public List<String> getDropdownValues(WebDriver driver,By by) {
        commonMethods.waitForElementClickable(driver, by, 30);
        navigator.getElementInView(by);
        return commonMethods.getValues(by);
    }
    /**
     * Method to set mandatory to applied fields
     */
    public void setMandatory(String label, String flag) {
        By element = By.xpath("//label[contains(text(),'" + label + "')]/../following-sibling::div/input[@type='checkbox']");
        if (flag.equals("true")) {
            $(element).setSelected(true);
        } else {
            $(element).setSelected(false);
        }
        $(docTypeSaveBtn).click();
        verifyAlert("Field labels have been saved successfully");
    }
    /**
     * Method to enter Scheme Name and write to Json file
     */

    public void enterSchemeName(String docNumName) {
        String docNumSchemeName = "DocNum" + faker.name().firstName();
        $(name).sendKeys(docNumSchemeName);
        commonMethods.writeToJson("doc_name",docNumName,docNumSchemeName,docNumberingPath);
    }
    /**
     * Method to create Auto number and write to Json file
     */
    public void createDocNumScheme(String docNumName,String projectfield, List<Map<String, String>> docData) {
        for (Map<String, String> data : docData) {
            String label="";
            String docNumSchemeName = faker.book().genre() + faker.number().digits(4);
            if(projectfield.equals("Project field"))
            {
                label = commonMethods.getLabelName(data.get("Element0"));
            }else {
                label=data.get("Element0");
            }
            switchProjectSettingsFrame();
            clickEditIcon();
            clickAutoNumChkBox(true);
            $(name).clear();
            $(name).sendKeys(docNumSchemeName);
            $(schemeDetailElement1).selectOptionContainingText(label);
            $(delimeterDropDown).selectOptionContainingText(data.get("Separator"));
            $(sequenceLength).selectOptionContainingText(data.get("SequenceNum"));
            $(startsAt).clear();
            $(startsAt).sendKeys(data.get("Start At"));
            String autoNumbering=$(autoNumberScheme).getText();
            $(saveBtn).click();
            commonMethods.writeToJson("doc_num_preview",docNumName, autoNumbering, docNumberingPath);
        }
    }
    /**
     * Method to verify default start value in doc type auto number
     */
    public void verifyDefaultStartsAt() {
        Assert.assertTrue(commonMethods.getTextFromInputField(driver,startsAt).equals("1"));
    }

    /**
     * Method to enter default start value in doc type auto number
     */
    public void enterStartsAt(String value) {
        $(startsAt).clear();
        $(startsAt).sendKeys(value);
    }
    /**
     * Method to verify the message
     */
    public boolean verifyMessage(String Message) {
        return $(By.xpath("//div[contains(text(),'" + Message + "')]")).isDisplayed();
    }
    /**
     * Method to enter AutoNmber details
     */
    public void enterAutoNumberDetails(Map<String, String> docData) {
        $(schemeDetailElement1).selectOptionContainingText(docData.get("Element0"));
        $(delimeterDropDown).selectOptionContainingText(docData.get("Separator"));
        $(sequenceLength).selectOptionContainingText(docData.get("SequenceNum"));
    }
    /**
     * Method verify Auto number preview
     */

    public void verifyAutoNumPreview(String expectedPreview) {
        Assert.assertTrue($(autoNumberScheme).getText().contains(expectedPreview));
    }

    /**
     * Method to move sequence number by one position up
     */

    public void clickSeqNumUp() {
//        action.moveToElement($(seqNumUpArrow)).click().build().perform();
    }

    /**
     * Method to click on Add Field Button
     */

    public void clickAddField(){
        $(addField).click();
    }

    /**
     * Method to click on Auto Num edit Icon
     */

    public void clickEditIcon(){
        commonMethods.waitForElement(driver, editAutoNumIcon);
        $(editAutoNumIcon).click();
    }

    /**
     * Method to verify autoNum popup
     */

    public void verifyAutoNumPopup() {
        List<WebElement> elements = Arrays.asList($(schemeName), $(schemeDetails), $(seqNum), $(preview));
        commonMethods.verifyElementsPresent(elements);
    }

    /**
     * Method to click on checkbox for enabling Auto Number
     */

    public void clickAutoNumChkBox(boolean value) {
        commonMethods.waitForElement(driver, enableAutoNumChkBx, 30);
        $(enableAutoNumChkBx).setSelected(value);
    }

    /**
     * Method to click on Auto Number Save Button
     */

    public void clickAutoNumSave(){
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, autoNumSettingSaveBtn);
        $(autoNumSettingSaveBtn).click();
    }

    public void clickAppliedFieldSave(){
        commonMethods.waitForElement(driver, docTypeSaveBtn);
        $(docTypeSaveBtn).click();
    }
    /**
     * Method to verify Auto Number is Enabled or not
     *
     * @return boolean
     */

    public boolean verifyEnabled(){
        commonMethods.waitForElementExplicitly(6000);
        commonMethods.waitForElement(driver, editAutoNumIcon);
        return $(notEnabledLabel).isDisplayed();
    }
    public boolean verifyAutoNumSaveButton(){
        commonMethods.waitForElement(driver, autoNumSettingSaveBtn);
        return $(autoNumSettingSaveBtn).isEnabled();
    }
    /**
     * Method to verify Preview text present
     */

    public void verifyPreview(String separator) {
        Assert.assertTrue($(previewText).getText().contains(separator));
    }

    /**
     * Method to set autonumbering
     */
    public void setAutoNumbering(boolean value) {
        commonMethods.waitForElementExplicitly(2000);
        $(loadingIcon).should(disappear);
        clickEditIcon();
        clickAutoNumChkBox(value);
        clickAutoNumSave();
    }

    /**
     * Method to upload a file in document register from local drive
     */
    public boolean verifyFieldPresent() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(3000);
        return verifyElementPresent(type);
    }

    /**
     * Function to verify the contents of the document type page
     */
    public void verifyDocTypePageCont(List<String> expectedData) {
        commonMethods.waitForElementExplicitly(5000);
        verifyAndSwitchFrame("project-settings-page");
        List<String> actualData = Arrays.asList($(typeColumn).getText(), $(codeColumn).getText(), $(autoNumberingColumn).getText());
        Assert.assertEquals(actualData, expectedData);
        Assert.assertTrue($$(documentTypeList).size() > 0);
        Assert.assertTrue($$(autoNumberingTickMarkCount).size() > 0 || $$(autoNumberingTickMarkCount).size() == 0);
        driver.switchTo().parentFrame();
    }

    /**
     * Function to store all the available document types
     */
    public List<String> storeDocTypeVal() {
        return commonMethods.getValues(documentTypeCount);
    }

    /**
     * Function to select the values from the dropdown document type
     */
    public void selectDocType(String documentTypeName) {
        $(loadingIcon).should(disappear);
        commonMethods.waitForElementExplicitly(5000);
        $(documentTypeSelectBox).selectOption(documentTypeName);
    }

    /**
     * Function to compare the document values with the one available in the project settings section
     */
    public List<String> compareDocVal() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, type, 15);
        return commonMethods.getValues(documentTypes);
    }

    /**
     * Function to verify the document type screen header text
     */
    public void verifyDocTypeHeader(String documentType) {
        commonMethods.waitForElementExplicitly(3000);
        WebElement element = $(By.xpath("//h1[@class='auiToolbar-header']//span[text()='Document Type']//following-sibling::span[text()='" + documentType + "']"));
        Assert.assertTrue("Header is displayed with the document type name", element.isDisplayed());
    }

    /**
     * Function to set the auto numbering enabled for the document type
     */
    public boolean verifyAutoNbrEnabled() {
        commonMethods.waitForElementExplicitly(3000);
        return $(autoNumberEnabled).isDisplayed();
    }

    /**
     * Function to verify the header text is present in the project fields section
     */
    public void verifyHeaderProFields(String documentType) {
        verifyElementPresent(headerProjectFields, "Header Project Fields is displayed for document type " + documentType + "");
    }

    /**
     * Function verify the New field button present in the document type page
     */
    public void verifyNewFieldBtn(String documentType) {
        verifyElementPresent(newFieldBtn, "+New Field button is displayed for document type " + documentType + "");
    }

    /**
     * Function verify search project field text box present
     */
    public void verifySearchProjFields(String documentType) {
        verifyElementPresent(searchProjectFieldTxt, "Search Project Fields text box is displayed for document type " + documentType + "");
    }

    /**
     * Function verify project field list is displayed in the page
     */
    public void verifyProjFieldsList(String documentType) {
        verifyElementPresent(searchProjectFieldTxt, "List of Project Fields available for is document type is displayed " + documentType + "");
    }

    /**
     * Function verify header text present under the document field section
     */
    public void verifyHeaderDocFields(String documentType) {
        verifyElementPresent(documentFieldHeader, "Header Document Fields is displayed for document type " + documentType + "");
    }

    /**
     * Function verify field column element present in the page
     */
    public void verifyFieldCol(String documentType) {
        verifyElementPresent(documentFieldCol, "Field column is displayed for document type " + documentType + "");
    }

    /**
     * Function verify Mandatory column header present in the page
     */
    public void verifyHeaderMandatoryCol(String documentType) {
        Assert.assertTrue("Mandatory column is displayed for document type " + documentType + "", $(mandatoryDocumentFieldCol).isDisplayed());
    }

    /**
     * Function click the pencil icon present in page
     */
    public void clickOnPencilBtn() {
        commonMethods.waitForElement(driver, pencilIcon);
        $(pencilIcon).click();
    }

    /**
     * Function verify close button present in the page
     */
    public void verifyCloseBtn(String documentTypeName) {
        Assert.assertTrue("Close button is displayed in the popup for document type " + documentTypeName + "", $(closeBtn).isDisplayed());
    }

    /**
     * Function verify save button present in the page
     */
    public void verifySaveBtn(String documentTypeName) {
        Assert.assertTrue("Save button is displayed in the auto numbering settings popup displayed for document type " + documentTypeName + "", $(saveBtn).isDisplayed());
    }


    /**
     * Function verify cancel button present in the page
     */
    public void verifyCancelBtn(String documentTypeName) {
        Assert.assertTrue("Cancel button is displayed in the auto numbering settings popup displayed for document type " + documentTypeName + "", $(cancelBtn).isDisplayed());
    }

    /**
     * Function verify auto number scheme text box present
     */
    public void verifyAutoNrbScheme(String documentTypeName) {
        Assert.assertTrue("Defined autonumber scheme with preview of the autonumber pattern is displayed for document type " + documentTypeName + "", $(autoNumberScheme).isDisplayed());
    }

    /**
     * Function verify alert message present in the popup box displayed for auto numbering settings
     */
    public void verifyAlertMessage(String documentTypeName) {
        Assert.assertTrue("Rhe alert message is displayed in auto numbering settings popup displayed for document type " + documentTypeName + "", $(autoSettingAlertMessage).isDisplayed());
    }

    /**
     * Function verify auto numbering checkbox checked
     */
    public void verifyAutoNbrChecked(String documentTypeName) {
        Assert.assertTrue("Enable auto number check box is ticked in the auto numbering settings popup displayed for document type " + documentTypeName + "", $(autoNumberingChkBox).isSelected());
    }

    /**
     * Function verify auto number settings header present
     */
    public void verifyAutoNbrSetHeader(String documentTypeName) {
        Assert.assertTrue("Heading Auto Numbering Settings is displayed for document type " + documentTypeName + "", $(autoSettingHeaderTxt).isDisplayed());
    }

    /**
     * Function verify enable auto numbering checkbox present in the page
     */
    public void verifyEnableAutoNbrChkBx(String documentTypeName) {
        Assert.assertTrue("Enable auto number check box displayed in the auto numbering settings popup for document type " + documentTypeName + "", $(autoNumberingChkBox).isDisplayed());
    }

    /**
     * Function to click on enable auto number check box
     */
    public void enableAutoNbrCheckBx(Boolean value) {
        commonMethods.waitForElement(driver, autoNumberingChkBox, 60);
        $(autoNumberingChkBox).setSelected(value);
    }

    /**
     * Function verify get the project field name displayed under document type page
     */
    public String getProjectFieldName() {
        projectFieldName = $(projectFieldNameTxt).getText();
        return projectFieldName;
    }

    /**
     * Function to click on new field button
     */
    public void clickNewFieldBtn() {
        $(newFieldBtn).click();
    }

    /**
     * Function to click on save button present in the document type page
     */
    public void clickSaveBtnDocType() {
        documentDrawingSettings.clickSave();
    }

    /**
     * Function verify type select box displayed in the popup for the project field
     */
    public void verifyTypeSelBox(String documentTypeName) {
        Assert.assertTrue("Type select box is displayed in project fields displayed for document type " + documentTypeName + "", $(newFieldType).isDisplayed());
    }

    /**
     * Function verify element is present
     */
    public void verifyElementPresent(By webElement, String message) {
        Assert.assertTrue(message, $(webElement).isDisplayed());
    }

    /**
     * Function verify element is present
     */
    public boolean verifyElementPresent(By webElement) {
        return $(webElement).isDisplayed();
    }

    /**
     * Function verify label text present in the popup
     */
    public void verifyLblTxtBx(String documentTypeName) {
        Assert.assertTrue("Label text box displayed in new project field popup for document type " + documentTypeName + "", $(newFieldLabel).isDisplayed());
    }

    /**
     * Function verify tool tip textarea present in the popup
     */
    public void verifyToolTipTxtArea(String documentTypeName) {
        Assert.assertTrue("Tool tip text area displayed in new project field popup for document type " + documentTypeName + "", $(newFieldToolTipTxtArea).isDisplayed());
    }

    /**
     * Function verify label field name present in the popup
     */
    public void verifyFieldNameTxt(String documentTypeName) {
        Assert.assertTrue("Field name text is displayed in new project field popup displayed for document type " + documentTypeName + "", $(newFieldName).isDisplayed());
    }

    /**
     * Function verify save button present in the popup displayed for the new field
     */
    public void verifyNewFieldSaveBtn(String documentTypeName) {
        Assert.assertTrue("Save button displayed in new project field popup for document type " + documentTypeName + "", $(newFieldSaveBtn).isDisplayed());
    }

    /**
     * Function verify cancel button present in the popup displayed for the new field
     */
    public void verifyNewFieldCancelBtn(String documentTypeName) {
        Assert.assertTrue("Cancel button is displayed in new project field popup for document type " + documentTypeName + "", $(newFieldCancelBtn).isDisplayed());
    }

    /**
     * Function verify field type text present
     */
    public void verifyProjFieldTypeTxt(String documentTypeName) {
        Assert.assertTrue("Message displayed in edit project field popup window for document type " + documentTypeName + "", $(projectFieldTypeTxt).isDisplayed());
    }

    /**
     * Function to click on the pencil button available under the project fields
     */
    public void clickPencilIcon() {
        $(projectFieldPencilIcon).click();

    }

    /**
     * Function to click on close button
     */
    public void clickCloseBtn() {
        $(closeBtn).click();
    }

    /**
     * Function to click on + button
     */
    public void clickPlusBtn() {
        $(plusIcon).click();
    }

    /**
     * Function to click on remove project field check box
     */
    public void clickRemoveCheck(boolean status) {
        $(removeChk).setSelected(status);
    }

    /**
     * Function vto click on remove button to remove the project field
     */
    public void clickRemoveBtn() {
        commonMethods.getElementInViewAndUp(removeBtn);
        $(removeBtn).click();
    }
    /**
     * Function vto click on remove button to remove the project field
     */
    public void verifyRemoveAppliedFieldsMsg( String msg,List<String> data) {
        for (String field : data) {
            String fieldValue = commonMethods.getLabelName(field);
            By fields = By.xpath("(//label[contains(text(),'" + fieldValue + "')]/../..//input[@type='checkbox'])[1]");
            switchProjectSettingsFrame();
            $(fields).setSelected(true);
           clickRemoveBtn();
            verifyMessage(msg);

        }
    }
    /**
     * Function verify remove button present
     */
    public void verifyRemoveButtonPresent(String documentTypeName) {
        Assert.assertTrue("Remove button is displayed successfully in the document field section for document type " + documentTypeName + "", $(removeBtn).isDisplayed());
    }

    /**
     * Function to extract the project field name from the project field section under document field section
     */
    public void getProjectFieldTxt() {
        commonMethods.waitForElementExplicitly(3000);
        projectFieldText = $(projectFieldNameInDoc).getText();
    }

    /**
     * Function verify new field popup contents
     */
    public void verifyNewFieldPopupPage() {
        commonMethods.waitForElementExplicitly(3000);
        List<WebElement> elements = Arrays.asList($(newFieldType), $(newFieldLabel), $(newFieldToolTipTxtArea), $(newFieldName), $(newFieldSaveBtn), $(newFieldCancelBtn), $(closeBtn));
        commonMethods.verifyElementsPresent(elements);
    }

    /**
     * Function verify Edit project fields popup contents
     */
    public void verifyEditProjFieldPopUp() {
        commonMethods.waitForElementExplicitly(3000);
        List<WebElement> elements = Arrays.asList($(projectFieldTypeTxt), $(newFieldLabel), $(newFieldToolTipTxtArea), $(newFieldName), $(newFieldSaveBtn), $(newFieldCancelBtn), $(closeBtn), $(disableBtn));
        commonMethods.verifyElementsPresent(elements);
    }

    /**
     * Function verify document type page contents
     */
    public void verifyDocTypeContents(String documentTypeName) {
        commonMethods.waitForElementExplicitly(3000);
        List<WebElement> elements = Arrays.asList($(headerProjectFields), $(newFieldBtn), $(searchProjectFieldTxt), $(projectFieldsList), $(documentFieldHeader), $(documentFieldCol), $(mandatoryDocumentFieldCol));
        commonMethods.verifyElementsPresent(elements);
        verifyDocTypeHeader(documentTypeName);
    }
    /**
     * Function verify auto number settings popup contents with auto numbering enabled
     */
    public void verifyAutoNbrConEnabled() {
        commonMethods.waitForElementExplicitly(3000);
        List<WebElement> elements = Arrays.asList($(closeBtn), $(saveBtn), $(cancelBtn), $(autoNumberScheme), $(autoSettingAlertMessage), $(autoSettingHeaderTxt));
        commonMethods.verifyElementsPresent(elements);
    }

    /**
     * Function verify auto number settings popup contents with auto numbering disabled
     */
    public void verifyAutoNbrConDisabled() {
        commonMethods.waitForElementExplicitly(3000);
        List<WebElement> elements = Arrays.asList($(closeBtn), $(saveBtn), $(cancelBtn), $(autoNumberingChkBox), $(autoSettingHeaderTxt));
        commonMethods.verifyElementsPresent(elements);
    }

    /**
     * Function verify project fields displayed under the doc upload section
     */
    public void verifyProjFieldsDisDoc(String documentTypeName) {
        commonMethods.waitForElementExplicitly(3000);
        By xpath = By.xpath("//div[@class='customFieldsListPage-applied']//ul/li//div/label[text()='" + getProjectFieldName() + "']/following::div/input");
        if (getAllAppliedFields().contains(getProjectFieldName())) {
            Assert.assertTrue("Applied project field in the document field section matches with the project filed section for document type  " + documentTypeName + "", true);
            Assert.assertTrue("Mandatory field with check box is displayed in document field section for document type  " + documentTypeName + "", $(xpath).isDisplayed());
        } else {
            Assert.assertTrue("Project Field Not present", getAllAppliedFields().contains(getProjectFieldName()));
        }
    }

    /**
     * Function add the mandatory fields values to the list
     */
    public void addMandatoryDocField() {
        commonMethods.waitForElementExplicitly(3000);
        for (WebElement mandatoryField : $$(docFieldsList)) {
            mandatoryFieldList.add(mandatoryField.getText());
        }
    }

    /**
     * Function verify the project fields displayed under the doc upload page
     */
    public void verifyProjFieldsDocUpload(String documentTypeName) {
        commonMethods.waitForElementExplicitly(3000);
        Assert.assertEquals("The project field displayed under doc upload page matched with the Project Fields available under project settings for document type " + documentTypeName + "", $(docSectionProjectFieldTxt).getText(),projectFieldText);

    }

    /**
     * Function to remove the project fields displayed under the doc section
     */
    public void removeProjFieldsDocSec() {
        clickRemoveCheck(true);
        commonMethods.waitForElementExplicitly(3000);
        clickRemoveBtn();
        clickSaveBtnDocType();

    }

    /**
     * Function verify the non mandatory project fields under doc upload section
     */
    public void verifyMandatoryProjFields(String documentTypeName) {
        commonMethods.waitForElement(driver, docSecMandatoryProjectFieldTxt, 60);
        Assert.assertEquals("The project field is marked as non mandatory under document upload section as expected for document type " + documentTypeName + "", $(docSecMandatoryProjectFieldTxt).getText(),projectFieldText);
    }

    /**
     * Function to click on the mandatory check box displayed in project field section under main doc section
     */
    public void clickMandatoryCheck(boolean status) {
        By xpath = By.xpath("//div[@class='customFieldsListPage-applied']//ul/li//div/label[text()='" + getProjectFieldName() + "']/following::div/input");
        $(xpath).setSelected(status);
    }

    /**
     * Function to verify the doc number fields is frozen in the doc upload page
     */
    public void verifyDocNbrFieldFrozen(String documentTypeName) {
        verifyElementPresent(docNumberSelectBox, "The document number field is frozen in the document upload page for document type " + documentTypeName + "");
    }

    /**
     * Function enter the scheme name in the text box
     */
    public void enterSchemeName(String schemeName, String documentTypeName) {
        enterText(schemeNameTxtBox, schemeName);
    }

    /**
     * Function verify auto numbering enables is displayed properly
     */
    public void verifyAutoNbrSetTxt(String documentTypeName) {
        commonMethods.waitForElement(driver, autoNumberingNotEnabledTxt, 20);
        Assert.assertTrue("Successfully save the auto numbering configuration for the document type " + documentTypeName + "", $(autoNumberingNotEnabledTxt).isDisplayed());
    }

    /**
     * Function to click on the back button present in the document type page
     */
    public void clickBackBtn() {
        $(backBtn).click();
    }

    /**
     * Function verify auto numbering tick mark not present in the document type page
     */
    public void verifyAutoNbrNotChecked(String documentTypeName) {
        boolean autoNumberTickMark = $(By.xpath("(//table[@class='auiTable']//td//a[text()='Calculations']//following::td)[2]//div[@class='tick']")).isDisplayed();
        if (!autoNumberTickMark)
            Assert.assertTrue("Auto number tick is not displayed" + documentTypeName + "", true);
        else
            Assert.assertFalse("Auto number tick is displayed" + documentTypeName + "", false);
    }

    /**
     * Function verify auto numbering tick mark not present in the document type page
     */
    public void verifyDocFieldNamesMatch(String documentTypeName) {
        int docFieldNameCounter = 0;
        List<String> expectedResult =new ArrayList<String>();
        commonMethods.waitForElementExplicitly(3000);
        for (WebElement documentFieldNames : $$(docFieldListProjectSettings))
            expectedResult.add(documentFieldNames.getText());
            /*if(ProjectSettingsPage.actualDocFieldList.contains())
             docFieldNameCounter++;
        }*/
        //if (docFieldNameCounter == $$(docFieldListProjectSettings).size())
        if(ProjectSettingsPage.actualDocFieldList.containsAll(expectedResult))
            Assert.assertTrue("Document fields listed under document types matches with listed documents fields  for the document type " + documentTypeName + "", true);
        else
            Assert.fail("Document fields listed under document types matches with listed documents fields  for the document type " + documentTypeName + "");
    }

    public void clickElement(By element) {
        commonMethods.clickOnElement(element);
    }

    public void enterText(By element, String text) {
        commonMethods.enterTextValue(element,text);
    }

    public void verifyElementPresent(String xpath, String appender, String message) {
        String finalXpath = xpath.replaceAll("@", appender);
        Assert.assertTrue(message, $(By.xpath(finalXpath)).isDisplayed());
    }

    public void clickSaveAutoNbr() {
        $(saveBtn).click();
    }

    public void getProjectFields() {
        documentFieldsNames = documentFieldsPage.getAllDocumentFields();
    }

    public List<String> getAllAppliedFields() {
        switchProjectSettingsFrame();
        List<String> appliedFields = new ArrayList<>();
        for (WebElement values : $$(lblAppliedDocFields))
            appliedFields.add($(values).getText().split("\n")[0]);
        return appliedFields;
    }

    public void storeProjectFieldName(String field) {
        commonMethods.waitForElementExplicitly(3000);
        mapOfMap = dataSetup.loadJsonDataToMap(projectFieldsPath);
        projectFieldText = mapOfMap.get(field).get("field_name").toString();
    }

    /**
     * Function to add project fields if it is not added already
     */
    public void addProjFields(String projectField) {
        $(By.xpath("//h4[text()='" + projectField + "']/../div[contains(@class,'pull-right')]")).click();
    }

    /**
     * Function to return status of project field whether it is already added or not
     */
    public String getProjFieldStatus(String projectField) {
        commonMethods.waitForElement(driver, lblAppliedFields, 60);
        return $(By.xpath("//h4[text()='" + projectField + "']/../div[contains(@class,'pull-right')]")).getAttribute("disabled");
    }

    /**
     * Function to select applied field
     */
    public void selectAppliedField(String fieldName, Boolean value) {
        $(By.xpath("//label[text()='" + fieldName + "']/../../..//input[contains(@class,'selectFieldCheckbox ')]")).setSelected(value);
    }
    public void dragDropAppliedField(String fieldName1, String fieldName2) {
        By drag=By.xpath("//label[text()='" + fieldName1 + "']/../../..//div[@class='auiIcon dragAffordance']");
        By drop=By.xpath("//label[text()='" + fieldName2 + "']/../../..//div[@class='auiIcon dragAffordance']");
        act.dragAndDrop($(drag), $(drop)).build().perform();
    }

    /**
     * Function to click up arrow
     */
    public void clickUpArrow() {
        $(btnUpArrow).click();
    }

    /**
     * Function to click down arrow
     */
    public void clickDownArrow() {
        $(btnDownArrow).click();
    }

    /**
     * Function to store applied fields
     */
    public void storeAppliedFields() {
        appliedFieldsList.clear();
        for(WebElement element : $$(appliedFieldNames))
            appliedFieldsList.add(element.getText());
    }

    /**
     * Function to set project fields mandatory or non mandatory
     */
    public void setMandatoryField(String fieldName, boolean value) {
        $(By.xpath("//label[text()='" + fieldName + "']/../../div[@class='mandatoryCheckbox']//input")).setSelected(value);
    }

    /**
     * Function to store mandatory fields
     */
    public void storeMandatoryFields() {
        mandatoryFieldsList.clear();
        List<WebElement> elements = new LinkedList<>($$(By.xpath(mandatoryFields)));
        for (int i = 0; i < elements.size(); i++)
            if ($(By.xpath("(" + mandatoryFields + "/input)[" + (i + 1) + "]")).isSelected())
                mandatoryFieldsList.add($(By.xpath("(" + mandatoryFields + ")[" + (i + 1) + "]/../div[@class='fieldName']/label[1]")).getText());
    }

    /**
     * Function to verify document fields mandatory field disabled
     */
    public void verifyDocFieldMandatory() {
        List<WebElement> elements = new ArrayList<>($$(By.xpath(documentFields)));
        for (int i = 0; i < elements.size(); i++)
            if ($(By.xpath("(" + documentFields + ")[" + (i + 1) + "]")).getText().equals("Document"))
                Assert.assertEquals("true", $(By.xpath("(" + documentFields + ")[" + (i + 1) + "]/../div[@class='mandatoryCheckbox']/input")).getAttribute("disabled"));
    }

    /**
     * Function to click on preview button
     */
    public void clickPreview() {
        commonMethods.waitForElement(driver, btnPreview);
        $(btnPreview).click();
    }

    /**
     * Function to get preview document fields
     */
    public List<String> getPreviewFields() {
        commonMethods.waitForElement(driver, tabPreview);
        return commonMethods.getValues(lblPreviewFields);
    }

    /**
     * Function to store document fields from preview window
     */
    public void storePreviewDocFields() {
        appliedFieldsList.clear();
        commonMethods.waitForElement(driver, tabPreview);
        for(WebElement element : $$(lblPreviewFields))
            appliedFieldsList.add(element.getText());
    }

    /**
     * Function to verify remove button
     */
    public boolean verifyRemoveBtn() {
        commonMethods.scrollPageUp(driver);
        return $(removeBtn).isEnabled();
    }

    /**
     * Function to verify document error message for document fields remove
     */
    public boolean verifyDocFieldsRemoveError() {
        commonMethods.scrollPageUp(driver);
        $(removeBtn).click();
        commonMethods.waitForElement(driver, errorRemoveMsg,10);
        return $(errorRemoveMsg).isDisplayed();
    }

    /**
     * Function to close preview button
     */
    public void closePreview() {
        $(btnDismiss).click();
    }

    /**
     * Function to select project field if present
     */
    public void selectProjectField(String fieldName, Boolean value) {
        By xpath = By.xpath("//label[text()='" + fieldName + "']/../../..//input[contains(@class,'selectFieldCheckbox')]");
        commonMethods.waitForElement(driver, xpath, 30);
        if ($(xpath).exists())
            $(xpath).setSelected(value);
    }

    /**
     * Function to remove all project fields
     */
    public void removeAllProjectFields() {
        commonMethods.waitForElement(driver, removeBtn, 60);
        List<WebElement> elements = new ArrayList<>($$(By.xpath(projectLabels)));
        for (int i = 0; i < elements.size(); i++)
            $(By.xpath("(" + projectLabels + "/../../..//input[contains(@class,'selectFieldCheckbox ')])[" + (i + 1) + "]")).setSelected(true);
        $(removeBtn).click();
    }


    /**
     * Function to verify project fields is displayed in document type page
     */
    public boolean verifyProjectField(String fieldName) {
        commonMethods.waitForElement(driver, lblAppliedFields, 60);
        return $(By.xpath("//h4[text()='" + fieldName + "']")).isDisplayed();
    }

    /**
     * Function to return project hierarchy field names
     */
    public List<String> getProjectHierarchyNames(String fieldName) {
        commonMethods.waitForElement(driver, lblAppliedFields);
        return Arrays.asList($(By.xpath("//h4[text()='" + fieldName + "']/../p")).getText().split(", "));
    }

    /**
     * Function to search the project fields present on the left side of the Document Type page
     *
     * @param label
     */
    public void searchProjectFields(String label) {
        $(searchProjectFields).clear();
        $(searchProjectFields).sendKeys(label);
    }

    /**
     * Function to verify the info message display on Edit project field pop-up dialog in Document Types page
     */
    public void verifyInfoMsg() {
        commonMethods.waitForElement(driver, message1, 45);
        Assert.assertTrue($(message1).isDisplayed());
        Assert.assertTrue($(message3).isDisplayed());
    }

    /**
     * Function to verify the messages on Edit Field Pop-up dialog when mapped to Document Type, Mail Type, Package Type and Field
     */
    public void verifyInfoMessagesOnEditFieldDialog() {
        commonMethods.waitForElement(driver, message1, 45);
        Assert.assertTrue($(message1).isDisplayed());
        Assert.assertTrue($(message3).isDisplayed());
        Assert.assertTrue($(message4).isDisplayed());
        Assert.assertTrue($(message5).isDisplayed());
        Assert.assertTrue($(message6).isDisplayed());
    }
    /**
     * Method to select scheme Code in Auto Numbering
     */
    public void selectScheme(String scheme) {
        $(schemeDetailElement1).selectOptionContainingText(scheme);
    }

}