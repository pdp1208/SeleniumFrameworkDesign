package com.oracle.babylon.pages.SupplierDocs;

import com.codeborne.selenide.Condition;
import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class
SupplierDocPage extends Navigator {

    private By pageTitle = By.xpath("//h1[contains(text(),'Search - Supplier Documents')]");
    protected By searchQuery = By.xpath("//input[@id='rawQueryText']");
    protected By inputDocNo=By.xpath("//input[@id='docno']");
    protected By searchBtn = By.xpath("//button[@id='btnSearch_page']");
    private By tableHeaders = By.xpath("//table[@class='dataTable']//thead//tr[1]//th");
    private By firstPackageChkBox = By.xpath("//table[@class='dataTable']//tbody[2]//tr[1]//td[1]//input");
    private By initiatorToolsBtn = By.xpath("//button[@id='btnInitiatorTools_page']");
    private By initiateSubmission = By.xpath("//a[text()='Initiate Submission']");
    private By cancelSubmission = By.xpath("//a[text()='Cancel']");
    private By markAsSubmitted=By.xpath("//a[text()='Mark As Submitted']");
    private By commentsIn = By.xpath("//div[@id='divDisplay_comments_1']");
    protected By commentsOut = By.xpath("//div[@id='divDisplay_comments_0']");
    private By commentsTxtArea = By.xpath("//textarea[@class='commentsTextArea']");
    private By newPackageBtn=By.xpath("//button[@id='btnNewSupplierDocsPackage']//div[text()='New Package']");
    //private By commentsOutTxtArea = By.xpath("//textarea[@id='divCommentsTxt_comments_0']");
    private By date = By.xpath("//input[@id='plannedSubmissionDate_0_da']");
    private By createTransmittalBtn = By.xpath("//button[@id='btnCreateTransmittal']");
    private By viewDocForSubmission = By.xpath("//img[@title='View ALL documents assigned to you in package for submission']");
    private By viewDocForReview = By.xpath("//img[@title='View ALL documents assigned to you in package for review']");
    private By firstRowChkBox = By.xpath("//table[@class='dataTable']//tbody[1]//td//input");
    private By secondRowChkBox = By.xpath("//table[@class='dataTable']//tbody[2]//td//input");
    private By selectReviewStatus = By.xpath("//select[@id='changes[0].reviewStatus']");
    private By submitReviewBtn = By.xpath("//button[@id='btnSubmitReview']");
    private By firstSupplierDocument = By.xpath("//table[@class='dataTable']//tbody[2]//td[1]/input");
    private By initiatorToolBtn = By.xpath("//table[@class='dataTable']//tbody[1]//td[2]/button");
    private By initiateSubmissionLink = By.xpath("//ul[@id='menuInitiatorTools']//li//a[contains(.,'Initiate Submission')]");
    private By submissionDateTextBox = By.xpath("//input[@id='plannedSubmissionDate_0_da']");
    private By firstSupplierDocChkBox = By.xpath("//div[@id='initiateSubmissionSearchResultsWrapper']//table[@class='dataTable']//tbody//tr[1]//td[1]/input");
    private By createNewSubsection=By.xpath("(//div[@class='navBarPanel-menuSubSection']//*[contains(text(),'Create New')])[2]");
    private By createNewSubsection_AppHub= By.xpath("//*[@id='popup-SUPPLIERDOCS']//*[contains(text(),'Create New')]");
    private By packageSubMenu=By.id("nav-bar-SUPPLIERDOCS-SUPPLIERDOCS-NEWPKG");
    private By packageSubMenu_AppHub=By.id("SUPPLIERDOCS-NEWPKG");
    public By btnAddDocumentsMenu=By.id("btnAddDocumentsMenu");
    private By supplierTurnAroundTxtLabel=By.xpath("(//label[contains(text(),'Turnaround')])[1]");
    private By requiredTurnAroundtxtLabel=By.xpath("(//label[contains(text(),'Turnaround')])[2]");
    private By numberTxt=By.id("number");
    private By descriptionTxt=By.id("description");
    private By suppliedBy=By.id("supplierOrgId_query");
    private By suppliedTurnAroundTxtBox=By.id("supplierTurnaround");
    private By requestTurnAroundTxtBox=By.id("requestorTurnaround");
    private By saveToDraftBtn=By.xpath("//*[@id='btnSaveToDraft']//*[text()='Save To Draft']");
    private By activateBtn=By.xpath("//*[@id='btnActivate']//*[text()='Activate']");
    private By availableReviewStatus=By.xpath("//div[@id='supplierDocumentReviewStatusSetLabels']//span");
    private By viewEditSuppliedBy=By.xpath("(//a[@title='Configure transmittal Cc recipients, attributes, reason for issue and subject'])[1]");
    private By viewEditRequiredBy=By.xpath("(//a[@title='Configure transmittal Cc recipients, attributes, reason for issue and subject'])[2]");
    private By requestEditTransmittalDefaultsHeader=By.xpath("//*[@id='requestorTransmittalTemplate']//span[text()='Edit Transmittal Defaults']");
    private By requestorToolTipHeader=By.xpath("//*[@id='requestorTransmittalTemplate_body']//h2");
    private By requestorToList=By.id("requestorToList");
    private By supplierToListContent=By.xpath("//div[@class='compactForm']//*[contains(text(),'No recipient selected')]");
    private By btnRequestorTransmittalTemplate_ok=By.id("btnrequestorTransmittalTemplate_ok");
    private By btnRequestorTransmittalTemplate_cancel=By.id("btnrequestorTransmittalTemplate_cancel");
    private By suppliedEditTransmittalDefaultHeader=By.xpath("//*[@id='supplierTransmittalTemplate_body']//h2");
    private By supplierToList=By.id("supplierToList");
    private By supplierToListOnPopUp=By.xpath("//div[@id='supplierToList' and @class='contentcell']");
    private By supplierToolTipHeader=By.xpath("//*[@id='supplierTransmittalTemplate_body']//h2");
    private By supplierSubject=By.xpath("//input[@id='supplierSubject']");
    private By requestorSubject=By.xpath("//input[@id='requestorSubject']");
    private By supplierReasonForIssue=By.id("supplierSelectedReason");
    private By requiredReasonForIssue=By.id("requestorSelectedReason");
    private By btnSupplierTransmittalTemplate_ok=By.id("btnsupplierTransmittalTemplate_ok");
    private By btnSupplierTransmittalTemplate_cancel=By.id("btnsupplierTransmittalTemplate_cancel");
    private By statusValue=By.xpath("//td[text()='Status']//..//td[@class='contentcell']");
    private By warningMessage=By.xpath("//li[@class='message warning']");
    private By suppliedByOrg = By.xpath("//input[@id='supplierOrgId_query']");
    private By suppliedByUser = By.xpath("//input[@id='supplierUsers_query']");
    private By requiredByUser=By.xpath("//input[@id='requestorUsers_query']");
    private By lookUpMessage=By.xpath("//div[@id='supplierOrgId_list']//div[@class='lookup-error-message']");
    private By lookUpAssigneeOrg=By.xpath("//div[@class='lookup-assignee lookup-org']");
    private By lookUpAssigneeSendTo=By.xpath("//div[@class='lookup-assignee lookup-user truncated']");
    private By suppliedBySendToErrorMsg=By.xpath("//div[@id='supplierUsers_list']//div[@class='lookup-error-message']");
    private By requiredBySendToErrorMsg=By.xpath("//div[@id='requestorUsers_list']//div[@class='lookup-error-message']");
    private By supplierCcUsers=By.id("supplierCcUsers_query");
    private By requestorCcUsers=By.id("requestorCcUsers_query");
    private By messageSuccess=By.xpath("//li[@class='message success']");
    private By excludedDocMsgForTransmit=By.xpath("//div[text()='The following 1 document cannot be transmitted']");
    private By dateErrorMsg=By.xpath("//tr[@class='dataRow ']//td[5]");
    protected By tableResults=By.xpath("//tr[contains(@class,'dataRow')]");
    private By cancelButton=By.xpath("//button[@id='btnsummaryPanel_cancel']//div[text()='Cancel']");
    private By clickSelectedOptions=By.xpath("//a[@title='Click for Selection Options']");
    private By selectAllResultsOnPage=By.xpath("//a[text()='Select All On This Page']");
    private By selectAllSearchResults=By.xpath("//a[text()='Select All Results']");
    private By saveAndContinueBtn=By.xpath("//button[@id='btnSaveAndContinue']//div[text()='Save And Continue']");
    private By saveAndContinueMsg=By.xpath("//li[@class='message success']//div[contains(text(),'All documents have been saved.')]");
    private By clearButton=By.xpath("//button[@id='btnClear_page']//div[text()='Clear']");
    private By supplierAction=By.xpath("//a//img[@title='View ALL documents assigned to you in package for submission']");
    private By submissionRequiredHeader=By.xpath("//h1[contains(text(),'Submission Required')]");
    private By lockImg=By.xpath("//table[@class='dataTable']//tbody[2]//td[13]//img");
    private By reasonMsg=By.xpath("//table[@id='excludedDocList']//td[5]");
    private By errorMsgLink=By.xpath("//table[@id='excludedDocList']//td[5]//a");
    private By packageNumbersMultiSelect=By.xpath("//div[@id='packageNumbers_multiselectdiv']");
    private By packageNumbersInput=By.id("bidi_packageNumbers_regexp");
    private By packageNumbersOk=By.xpath("//button[@id='btnbidiPanel_packageNumbers_ok']//div[text()='OK']");
    protected By submissionStatusMultiSelect=By.xpath("//div[@id='submissionStatuses_multiselectdiv']");
    protected By submissionStatusInput=By.id("bidi_submissionStatuses_regexp");
    protected By submissionStatusOk=By.xpath("//button[@id='btnbidiPanel_submissionStatuses_ok']//div[text()='OK']");
    protected By reviewStatusMultiSelect=By.xpath("//div[@id='reviewstatus_multiselectdiv']");
    protected By reviewStatusInput=By.id("bidi_reviewstatus_regexp");
    protected By reviewStatusOk=By.xpath("//button[@id='btnbidiPanel_reviewstatus_ok']//div[text()='OK']");
    private By cancelCommentBox=By.id("cancelDialog_comments");
    private By cancelOkButton=By.xpath("//button[@id='cancelDialog-commit']//div[text()='OK']");
    private By docUnAvailableError=By.xpath("//div[text()='The following documents are not available']");
    private By excludeMsgTable=By.xpath("//table[@id='excludedDocList']//tbody//tr");
    private By closeOnExcludeBox=By.xpath("//button[@id='btnexcludedDocs_ok']//div[text()='Close']");
    private By closeOnDialogBox=By.xpath("//button[@id='excludedDocs-cancel']//div[text()='Close']");
    private By closeOnBtnSubmissionHistory=By.xpath("//button[@id='btnsubmissionHistory_ok']//div[text()='Close']");
    private By submittedResultsSize=By.xpath("//tbody[@id='submittedResults']//tr");
    protected By numberOfResults=By.id("numResults");
    private By paginationToNext=By.xpath("(//div[@class='paging flow-right']//a[contains(text(),'next')])[1]");
    private By initiateSubmissionHeader=By.xpath("//div[@id='header']//*[contains(text(),'Submission')]");
    private By excludeDocMsg=By.id("excludedDocMsg");
    private By nextPaginationBtnOnBottom=By.xpath("(//div[@class='paging flow-right']//a[contains(text(),'next')])[2]");
    public By packageNumberHeaderInRow=By.xpath("(//tr[@class='dataGroup'][1]//td//*[contains(text(),'Package Number:')])[1]");
    public By packageNumberInRow=By.xpath("(//tr[@class='dataGroup'][1]//td//a[@title='Click to view the supplier document package details'])[1]");
    public By packageNumberInColumnHeader=By.xpath("//th[@class='sortable' and contains(text(),'Package Number')]");
    public By packageNumberRowValues=By.xpath("(//tr[contains(@class,'dataRow')]//a[@title='Click to view the supplier document package details'])[1]");
    public By firstPageOnSearch=By.xpath("(//div[@class='paging flow-right']//a[text()='1'])[1]");
    private By summaryOfTransmittedDocs=By.xpath("//*[@id='summaryPanel_title' and text()='Summary of Transmitted Documents']");
    private By headerOnInitatePage=By.xpath("//div[@id='toolbar_left']//h1");
    private By notRegisterdYetMsg=By.xpath("//tr[@class='notregistered']//td[5]");
    private By mailNoOnNotRegisterMsg=By.xpath("//tr[@class='notregistered']//td[@class='contentcell']//a");
    public By viewOnlyEditSuppliedBy=By.xpath("(//a[@title='View transmittal Cc recipients, attributes, reason for issue and subject'])[1]");
    public By viewOnlyEditRequiredBy=By.xpath("(//a[@title='View transmittal Cc recipients, attributes, reason for issue and subject'])[2]");
    public By errorMsg=By.xpath("//tbody[@id='submissionRequiredResults']//td[@class='contentcell'][5]");
    private By btnStartWorkflow=By.id("btnStartWorkflow");
    private By accessDocumentsMenu=By.xpath("//td//img[@title='Access document options menu']");
    private By updateDocOption=By.xpath("//*[contains(text(),'Update')]");
    private By supersedeDocOption = By.xpath("//*[contains(text(),'Edit / Upload new version')]");
    private By lnkAddDocsFromDocReg = By.xpath("//a[text()='Add Documents from Document Register']");
    private By btnUpdate = By.xpath("//ul[@class='uiMenu rowActionMenu']//li/div[text()='Update']");
    private By btnEventLog = By.xpath("//ul[@class='uiMenu rowActionMenu']//li/div[text()='Event Log']");
    private By btnDocProperties = By.xpath("//ul[@class='uiMenu rowActionMenu']//li/div[text()='Document Properties']");
    private By btnDocPropertiesClose = By.xpath("//div[@id='docPropertiesPanel_buttons']//div[text()='Close']");
    private By lnkDocPropertiesOption = By.xpath("//ul[@id='MENU_SUBMISSION_REQUIRED']//li//a[text()='Document Properties']");
    private By btnDownload = By.xpath("//ul[@class='uiMenu rowActionMenu']//li/div[text()='Download']");
    private By navigateSubmissionRequiredLink=By.xpath("(//tbody[@id='grid-group-body-supplierdocssubmissionrequired']//tr//*[@class='textlink'])[1]");
    private By actionsNavOnSubmissionRequired=By.xpath("(//*[@id='submissionRequiredResults']//*[@title='View submission history of document'])[1]");
    private By inputCheckBoxOnSubmissionRequired=By.xpath("(//*[@id='submissionRequiredResults']//*[@type='checkbox'])[1]");
    private By fileIconOnSubmissionRequired=By.xpath("(//*[@id='submissionRequiredResults']//*[@title='Open File'])[1]");
    private By removeDocumentLink = By.xpath("//a[text()='Remove Documents from Package']");
    private By modifyDueDateLink = By.xpath("//a[text()='Modify Due Dates']");
    private By dateCalTxtField = By.xpath("//input[@id='modifyDueDates_dueDate_da']");
    private By modifyDueDatesSlt = By.xpath("//select[@id='modifyDueDates_option']");
    private By daysTxtField = By.xpath("//input[@id='modifyDueDates_days']");
    private By reason = By.xpath("//textarea[@id='modifyDueDates_reason']");
    private By clickModifyDateOkBtn = By.xpath("//button[@id='btnmodifyDueDates_ok']");

    PackagePage packagePage=new PackagePage();
    private By sortBy = By.xpath("//select[@id='sortField']");
    /**
     * Method to navigate to create package page
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Supplier Documents", "Supplier Documents");
        $(loadingIcon).should(disappear);
        Assert.assertTrue("Supplier Documents Page title is not displayed correctly", verifyPageTitle(pageTitle));
    }

    /**
     * Method to search for the document through supplier document page
     *
     * @param packageNumber
     */
    public void searchPackage(String packageNumber) {
        verifyAndSwitchFrame();
        $(searchQuery).clear();
        $(searchQuery).sendKeys(packageNumber);
        commonMethods.waitForElementExplicitly(2000);
        getElementInView(searchQuery);
        clickSearchBtn();
    }

    /**
     * Method to search with Logical Operator
     *
     * @param query
     */
    public void searchPackageQuery(String query) {
        verifyAndSwitchFrame();
        $(searchQuery).sendKeys(Keys.END+query);
        commonMethods.waitForElementExplicitly(2000);
        getElementInView(searchQuery);
        clickSearchBtn();
    }
    /**
     * Method to search for the document through supplier document page
     *
     */
    public void clickSearchBtn() {
        commonMethods.waitForElement(driver,searchBtn);
        $(searchBtn).click();

    }
    /**
     * Method to get the value of the cell according to some header
     * Seperate function written as the table identifiers are different
     *
     * @param header
     * @return
     */
    public String getCellValue(String header) {
        commonMethods.waitForElement(driver, tableHeaders);
        List<WebElement> list = driver.findElements(tableHeaders);
        int index = 0;
        for (WebElement element : list) {
            if (element.getText().contains(header)) {
                index++;
                return driver.findElement(By.xpath("//table[@class='dataTable']//tbody[2]//tr[1]//td[" + index + "]")).getText();
            }
            index++;
        }

        return "not_found";


    }

    /**
     * Method to initiate the submission
     *
     * @param packageNumber
     */
    public void setInitiateSubmission(String packageNumber) {
        enterComments(commentsIn, "Comments for " + packageNumber);
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        Date tomorrow = calendar.getTime();
        commonMethods.enterTextValue(date,dateFormat.format(tomorrow));
        $(createTransmittalBtn).click();
    }
    /**
     * Method to select first result and Initiate Submission
     */
    public void navigateToInitiateSubmission()
    {
        commonMethods.waitForElementExplicitly(3000);
        $(firstPackageChkBox).click();
        clickInitiateSubmission();
    }
    /**
     * Method to get the No doc selection error message
     */
    public String getNoDocSelectionErrorMsg()
    {
        commonMethods.waitForElement(driver,createTransmittalBtn);
        $(firstSupplierDocChkBox).setSelected(false);
        $(createTransmittalBtn).click();
        return getAlertText();
    }
    /**
     * Method to get the error when we provide the past date
     */
    public String getPastDateErrorMsg()
    {
        $(submissionDateTextBox).clear();
        Calendar cal = Calendar.getInstance();
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        cal.add(Calendar.DATE, -1);
        getErrorMsgOnDate(dateFormat.format(cal.getTime()));
        return getAlertText();
    }
    /**
     * Method to get the error message based on Input Date value
     */
    public String getErrorMsgOnDate(String dateValue)
    {
        $(submissionDateTextBox).sendKeys(dateValue);
        $(createTransmittalBtn).click();
        return getAlertText();
    }
    /**
     * Method to the error message if the Submission date is empty
     */
    public String getEmptyDateErrorMsg()
    {
        commonMethods.waitForElement(driver,firstSupplierDocChkBox);
        $(submissionDateTextBox).clear();
        $(createTransmittalBtn).click();
        commonMethods.waitForElement(driver,createTransmittalBtn);
        return $(dateErrorMsg).getText();
    }
    /**
     * Method to view the documents available in the package for submission
     */
    public void clickViewDocForSubmission() {
        commonMethods.waitForElement(driver, viewDocForSubmission, 60);
        $(viewDocForSubmission).click();
    }

    /**
     * Method to view the documents available in the package for submission
     */
    public void viewDocForSubmission() {
        commonMethods.waitForElement(driver, viewDocForSubmission, 60);
        $(viewDocForSubmission).click();
    }

    /**
     * Method to view the package for review
     */
    public void clickViewDocForReview() {
        commonMethods.waitForElement(driver,viewDocForReview);
        $(viewDocForReview).click();
    }

    /**
     * Method to submit the review status on document
     */
    public void submitReviewOnDoc(String docNum,String reviewOutcome) {
        selectDocOnSubmitScreen(docNum);
        By docReview=By.xpath("//div[@id='submittedSearchResultsWrapper']//td//*[contains(text(),'"+docNum+"')]//..//..//select");
        commonMethods.waitForElement(driver,docReview);
        $(docReview).selectOption(reviewOutcome);
        enterComments(commentsOut, "Submit review SD "+reviewOutcome);
    }

    /**
     * Method to select document on submission
     */
    public void selectDocOnSubmitScreen(String docNum)
    {
        By selectDoc=By.xpath("//div[@id='submittedSearchResultsWrapper']//td//*[contains(text(),'"+docNum+"')]//..//..//input[@type='checkbox']");
        commonMethods.waitForElement(driver,selectDoc);
        $(selectDoc).click();
    }
    /**
     * Method to click Submit Review Button
     */
    public void clickSubmitReviewBtn()
    {
        commonMethods.waitForElement(driver,submitReviewBtn);
        $(submitReviewBtn).click();
    }
    /**
     * Method to write the comments to the sd process
     *
     * @param by
     * @param comments
     */
    public void enterComments(By by, String comments) {
        commonMethods.waitForElementExplicitly(2000);
        $(by).click();
        commonMethods.waitForElementExplicitly(2000);
        if (!$(commentsTxtArea).getText().equals("")) {
            $(commentsTxtArea).clear();
            $(by).click();
        }
        $(commentsTxtArea).sendKeys(comments);
    }

    /**
     * Method to submit a package
     */
    public void submitPackage() {
        selectFirstDocument();
        enterComments(commentsOut, "Submit SD");
        $(createTransmittalBtn).click();
    }

    /**
     * Method to submit a review
     */
    public void submitReview(String status) {
        selectFirstDocument();
        enterComments(commentsOut, "Submit review SD");
        Select select = new Select($(selectReviewStatus));
        select.selectByValue(status);
        clickSubmitReviewBtn();
    }

    /**
     * Select the first document in the SD Submit flow
     */
    public void selectFirstDocument() {
        commonMethods.waitForElement(driver,firstRowChkBox);
        $(firstRowChkBox).click();
    }

    /**
     * function to start transmittal for supplier document
     */
    public void startTransmittal() {
        verifyAndSwitchFrame();
        $(firstSupplierDocument).setSelected(true);
        $(initiatorToolBtn).click();
        $(initiateSubmissionLink).click();
        commonMethods.waitForElement(driver,createTransmittalBtn,15);
        $(submissionDateTextBox).clear();
        $(submissionDateTextBox).sendKeys(commonMethods.getTodayDate(configFileReader.getTimeZone()));
        $(firstSupplierDocChkBox).setSelected(true);
        $(createTransmittalBtn).click();
    }
    /**
     * Method to verify Create New Package Exists
     */
    public boolean verifyCreateNewPackage()
    {
            $(createNewSubsection).shouldBe(Condition.hidden);
            return $(packageSubMenu).exists();
    }

    /**
     * Method to verify Default Add Document Option present
     */
    public String verifyDefaultAddDocument()
    {
        commonMethods.waitForElement(driver,btnAddDocumentsMenu);
        return  $(btnAddDocumentsMenu).getAttribute("title");
    }
    /**
     * Method to verify Labels on New Supplier
     */
    public void verifyLabelsOnNewSupplier()
    {
        commonMethods.waitForElement(driver,saveToDraftBtn);
        commonMethods.waitForElement(driver,activateBtn);

    }
    /**
     * Method to Click Save To Draft Btn
     */
    public void clickSaveToDraftBtn()
    {
        commonMethods.waitForElement(driver,saveToDraftBtn);
        $(saveToDraftBtn).click();

    }
    /**
     * Method to Click Activate Btn
     */
    public void clickActivateBtn()
    {
        commonMethods.waitForElement(driver,activateBtn);
        $(activateBtn).click();

    }

    /**
     * Method to get Turn Around Default value displayed
     */
    public String getTurnAroundDefaultValue(String index)
    {
        return (index.equalsIgnoreCase("supplied")?$(suppliedTurnAroundTxtBox).getValue():$(requestTurnAroundTxtBox).getValue());
    }
    /**
     * Method to enterTurn Around
     */
    public void enterTurnAround(String index,String value)
    {
        if (index.equalsIgnoreCase("supplied")) {
            $(suppliedTurnAroundTxtBox).sendKeys(value);
        } else {
            $(requestTurnAroundTxtBox).sendKeys(value);
        }
    }
    /**
     * Method to verify Mandatory Text Box with the field property
     */
    public String verifyMandatoryTextBox(String fieldProperty)
    {
        return commonMethods.returnAttributeValue(driver,(By.id(fieldProperty)),"class");
    }
    /**
     * Method to get max length attribute on the field property
     */
    public String maxLengthOnNewSupplier(String fieldProperty)
    {
        return $(By.id(fieldProperty)).getAttribute("maxlength");
    }
    /**
     * Method to Get all the Review Status displayed
     */
    public ArrayList<String> getReviewStatus()
    {
        ArrayList<String> reviewFlowStatus=new ArrayList<>();
        for(int iterator=1;iterator<=$$(availableReviewStatus).size();iterator++)
            reviewFlowStatus.add($(By.xpath("(//div[@id='supplierDocumentReviewStatusSetLabels']//span)["+iterator+"]")).getText());
        return reviewFlowStatus;
    }
    /**
     * Method to click on View/Edit Transmittal Template based on Instance
     */
    public void clickViewEditTransmittalTemplate(String instance)
    {
        commonMethods.waitForElement(driver,viewEditSuppliedBy);
        if ((instance.contains("Supplied By"))) {
            $(viewEditSuppliedBy).click();
        } else {
            $(viewEditRequiredBy).click();
        }
    }
    /**
     * Method to verify Subject Length based on instance
     */
    public String verifySubjectLength(String instance)
    {
       String maxLength= (instance.contains("Supplied By")) ?  maxLengthOnNewSupplier("supplierSubject"): maxLengthOnNewSupplier("requestorSubject");
       return maxLength;
    }
    /**
     * Method to verify RequestedBy Transmittal Defaults Pop Up
     */
    public void verifyRequestorTransmittalDefaultsPopUp()
    {
        $(requestEditTransmittalDefaultsHeader).shouldBe(Condition.appear);
        $(requestorToolTipHeader).shouldBe(Condition.appear);
        $(requestorToList).shouldBe(Condition.appear);
        $(btnRequestorTransmittalTemplate_cancel).shouldBe(Condition.appear);
        $(btnRequestorTransmittalTemplate_ok).shouldBe(Condition.appear);
    }
    /**
     * Method to get RequestedBy To List
     */
    public String getReqeustorToList()
    {
        commonMethods.waitForElement(driver,requestorToList);
        return $(requestorToList).getText();
    }
    /**
     * Method to verify suppliedBy Transmittal Defaults Pop Up
     */
    public void verifySupplierTransmittalDefaultsPopUp()
    {
        $(suppliedEditTransmittalDefaultHeader).shouldBe(Condition.appear);
        $(supplierToolTipHeader).shouldBe(Condition.appear);
        $(supplierToList).shouldBe(Condition.appear);
        $(btnSupplierTransmittalTemplate_cancel).shouldBe(Condition.appear);
        $(btnSupplierTransmittalTemplate_ok).shouldBe(Condition.appear);
        $(supplierToListContent).shouldBe(Condition.appear);
    }
    /**
     * Method to click on cancel button on the Transmittal Defaults based on instance
     */
    public void clickCancelOnTransmittalTemplate(String instance)
    {
        if(instance.equalsIgnoreCase("Supplied By")) {
            commonMethods.waitForElement(driver, btnSupplierTransmittalTemplate_cancel);
            $(btnSupplierTransmittalTemplate_cancel).click();
        }
        else {
            commonMethods.waitForElement(driver, btnRequestorTransmittalTemplate_cancel);
            $(btnRequestorTransmittalTemplate_cancel).click();
        }
    }
    /**
     * Method to click on ok button on the Transmittal Defaults based on instance
     */
    public void clickOkOnTransmittalTemplate(String instance)
    {
        if(instance.equalsIgnoreCase("Supplied By")) {
            commonMethods.waitForElement(driver, btnSupplierTransmittalTemplate_ok);
            $(btnSupplierTransmittalTemplate_ok).click();
        }
        else {
            commonMethods.waitForElement(driver, btnRequestorTransmittalTemplate_ok);
            $(btnRequestorTransmittalTemplate_ok).click();
        }
    }
    /**
     * Method to enter Supplier No and Description
     */
    public void enterSupplierNoDescription(String supplierNo)
    {
        commonMethods.waitForElement(driver,numberTxt);
        $(numberTxt).sendKeys(supplierNo);
        $(descriptionTxt).sendKeys("This is for testing");
    }
    /**
     * Method to get supplier status
     */
    public String getStatus()
    {
        commonMethods.waitForElement(driver,statusValue);
        return $(statusValue).getText();
    }
    /**
     * Method to get New Package Button is displayed
     */
    public boolean getNewPackageBtn()
    {
        return $(newPackageBtn).isDisplayed();
    }

    /**
     * Method to get SaveToDraft Button is displayed
     */
    public boolean getSaveToDraftBtn()
    {
        return $(saveToDraftBtn).isDisplayed();
    }

    /**
     * Method to get Activate Button is displayed
     */
    public boolean getActivateBtn()
    {
        return $(activateBtn).isDisplayed();
    }

    /**
     * Method to get all the options in the Reason For Issue Dropdown
     */
    public ArrayList<String> getReasonForIssueDropDown(String instance)
    {
        if(instance.equalsIgnoreCase("Supplied By"))
            return commonMethods.returnAllOptionsInDropDown(driver,supplierReasonForIssue);
        else
            return commonMethods.returnAllOptionsInDropDown(driver,requiredReasonForIssue);
    }
    /**
     * Method to select SuppliedBy Attribute values
     */
    public void selectSupplierAttributeValues(String attributeIndex,String attributeValue)
    {
        $(By.id("supplierAttributes"+attributeIndex+"_multiselectdiv")).click();
        $(By.xpath("//select[@id='bidi_supplierAttributes"+attributeIndex+"_AVAIL']//option[@value='"+attributeValue+"']")).should(Condition.appear);
        $(By.id("btnbidiPanel_supplierAttributes"+attributeIndex+"_cancel")).click();
    }
    /**
     * Method to select RequiredBy attribute values
     */
    public void selectRequiredAttributeValues(String attributeIndex,String attributeValue)
    {
        $(By.id("requestorAttributes"+attributeIndex+"_multiselectdiv")).click();
        $(By.xpath("//select[@id='bidi_requestorAttributes"+attributeIndex+"_AVAIL']//option[@value='"+attributeValue+"']")).should(Condition.appear);
        $(By.id("btnbidiPanel_requestorAttributes"+attributeIndex+"_cancel")).click();
    }
    /**
     * Method to click Search result for the package number
     */
    public void clickSearchResult(String packageNumber)
    {
        By packageLink=By.xpath("//tr[@class='dataRow']//td[1]//a[text()='"+packageNumber+"']");
        commonMethods.waitForElement(driver,packageLink,30);
        $(packageLink).click();
    }
    /**
     * Method to click Search result for the package number
     */
    public void clickPackageNo(String packageNumber)
    {
        By packageLink=By.xpath("//tr[@class='dataRow']//a[text()='"+packageNumber+"']");
        commonMethods.waitForElement(driver,packageLink,30);
        $(packageLink).click();
    }
    /**
     * Method to verify Search result for the package number
     */
    public boolean verifySearchPackageNumber(String packageNumber)
    {
        By packageNo=By.xpath("//a[text()='"+packageNumber+"']");
        commonMethods.waitForElement(driver,packageNo);
        return  $(packageNo).isDisplayed();
    }
    /**
     * Method to verify Search result for the package number
     */
    public boolean verifyPackageNoOnPagination(String packageNumber)
    {
        boolean flag=false;
        By packageNo=By.xpath("//a[text()='"+packageNumber+"']");
        try {
            WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.visibilityOf($(packageNo)));
            flag= $(packageNo).isDisplayed();
        }catch (Exception e)
        {
            clickOnPagination("next");
            commonMethods.waitForElement(driver,packageNo);
            flag= $(packageNo).isDisplayed();
        }
        return flag;
    }

    /**
     * Method to verify the Supplier Doc Number
     */
    public boolean verifySupplierDocNumber(String supplierDocNo)
    {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(3000);
        return $(By.xpath("//td[contains(text(),'"+supplierDocNo+"')]")).isDisplayed();
    }
    /**
     * Method to get all existing error message
     */
    public String getAlreadyExistingMessage()
    {
        return $(warningMessage).getText();
    }
    /**
     * Method to enter supplied by org name on Supplied By and Send To fields
     */
    public void enterSuppliedByOrgAndUser(String toOrgName,String toUserName)
    {
        commonMethods.waitForElementExplicitly(2000);
        $(suppliedByOrg).clear();
        $(suppliedByOrg).sendKeys(toOrgName+Keys.ENTER);
        //$(suppliedByOrg).sendKeys(Keys.ENTER);
        commonMethods.waitForElementExplicitly(2000);
        $(lookUpAssigneeOrg).shouldBe(Condition.appear);
        commonMethods.waitForElement(driver,suppliedByUser);
        $(suppliedByUser).sendKeys(toUserName+Keys.ENTER);
    }
    /**
     * Method to get error message message for invalid user
     */
    public String getSuppliedByErrorMsg(String toOrgName)
    {
        commonMethods.waitForElementExplicitly(2000);
        $(suppliedByOrg).clear();
        $(suppliedByOrg).sendKeys(toOrgName+Keys.ENTER);
        return $(lookUpMessage).getText();
    }
    /**
     * Method to get supplied by send to error message
     */
    public String getSuppliedBySendToErrorMsg(String toOrgName,String userName)
    {
        enterSuppliedBySentTo(toOrgName,userName);
        return  $(suppliedBySendToErrorMsg).getText();
    }
    /**
     * Method to get requiredBy Send To Error Message
     */
    public String getRequiredSendToByErrorMsg(String userName)
    {
        enterRequiredBySendTo(userName);
        return  $(requiredBySendToErrorMsg).getText();
    }
    /**
     * Method to enter supplied by Org Name
     */
    public void enterSuppliedByOrg(String toOrgName)
    {
        commonMethods.waitForElement(driver,suppliedByUser);
        $(suppliedByOrg).clear();
        $(suppliedByOrg).sendKeys(toOrgName+Keys.ENTER);
    }
    /**
     * Method to enter supplied by org name on Supplied By and Send To fields
     */
    public void enterSuppliedBySentTo(String toOrgName,String userName)
    {
        enterSuppliedByOrg(toOrgName);
        $(suppliedByUser).clear();
        commonMethods.waitForElementExplicitly(2000);
        $(suppliedByUser).sendKeys(userName+Keys.ENTER);
    }
    /**
     * Method to enter required by on Send To field
     */
    public void enterRequiredBySendTo(String searchUserName)
    {
        commonMethods.waitForElement(driver,requiredByUser);
        // $(By.xpath("//div[@class='lookup-assignee  lookup-user truncated' and contains(text(),'"+requiredUserName+"')]")).shouldBe(Condition.appear);
        $(requiredByUser).clear();
        commonMethods.waitForElementExplicitly(2000);
        $(requiredByUser).sendKeys(searchUserName+Keys.ENTER);
    }
    /**
     * Method to verify the suppliedBy SendTo Search Field
     */
    public void verifySuppliedSentToSearch(String toOrgName,String userName)
    {
        enterSuppliedBySentTo(toOrgName,userName);
        if(userName.contains("group"))
            $(By.xpath("//li[@class='lookup-assignee lookup-group']//a[text()='"+userName+"']")).click();
        $(lookUpAssigneeSendTo).shouldBe(Condition.appear);
    }
    /**
     * Method to verify supplied by CC field on the Transmittal defaults
     */
    public void verifySuppliedSentToCCSearch(String userName)
    {
        $(supplierCcUsers).clear();
        $(supplierCcUsers).sendKeys(userName+Keys.ENTER);
        if(userName.contains("group"))
            $(By.xpath("//li[@class='lookup-assignee lookup-group']//a[text()='"+userName+"']")).click();
        $(lookUpAssigneeSendTo).shouldBe(Condition.appear);
    }
    /**
     * Method to verify RequiredBy SendTo Search field
     */
    public void verifyRequiredSentToSearch(String requiredUserName,String searchUserName)
    {
        enterRequiredBySendTo(searchUserName);
        if(searchUserName.contains("group"))
            $(By.xpath("//li[@class='lookup-assignee lookup-group']//a[text()='"+searchUserName+"']")).click();
        $(lookUpAssigneeSendTo).shouldBe(Condition.appear);
    }
    /**
     * Method to verify RequiredBy SendTo Search CC field
     */
    public void verifyRequiredSentToCCSearch(String searchUserName)
    {
        commonMethods.waitForElement(driver,requestorCcUsers);
        $(requestorCcUsers).clear();
        $(requestorCcUsers).sendKeys(searchUserName+Keys.ENTER);
        if(searchUserName.contains("group"))
            $(By.xpath("//li[@class='lookup-assignee lookup-group']//a[text()='"+searchUserName+"']")).click();
        $(lookUpAssigneeSendTo).shouldBe(Condition.appear);
    }
    /**
     * Method to click on Trash Icon in SuppliedBy sendTo field
     */
    public void clickTrashIconOnSupplied(String userName)
    {
        $(By.xpath("//table[@id='supplierUsers_container']//div[contains(text(),'"+userName+"')]//..//..//div[@class='auiIcon trash']")).click();
    }
    /**
     * Method to click on Trash Icon in SuppliedBy CC field
     */
    public void clickTrashIconOnCCSupplied(String userName)
    {
        $(By.xpath("//table[@id='supplierCcUsers_container']//div[contains(text(),'"+userName+"')]//..//..//div[@class='auiIcon trash']")).click();
    }
    /**
     * Method to click on Trash Icon in RequiredBy field
     */
    public void clickTrashIconOnRequiredBy(String userName)
    {
        $(By.xpath("//table[@id='requestorUsers_container']//div[contains(text(),'"+userName+"')]//..//..//div[@class='auiIcon trash']")).click();
    }
    /**
     * Method to click on Trash Icon in RequiredBy CC field
     */
    public void clickTrashIconOnCCRequiredBy(String userName)
    {
        $(By.xpath("//table[@id='requestorCcUsers_container']//div[contains(text(),'"+userName+"')]//..//..//div[@class='auiIcon trash']")).click();
    }
    /**
     * Method to verify SendTo user on RequiredBy Instance
     */
    public void verifySentToUserOnRequiredBy(String toUserName)
    {
        $(By.xpath("//div[@id='requestorToList']//div[@class='member' and contains(text(),'"+toUserName+"')]")).shouldBe(Condition.appear);
    }
    /**
     * Method to verify SendTo user on SuppliedBy Instance
     */
    public void verifySuppliedByToUser(String toUserName)
    {
        $(By.xpath("//div[@id='supplierToList']//div[@class='member' and contains(text(),'"+toUserName+"')]")).shouldBe(Condition.appear);
    }
    /**
     * Method to get default message on SendTo Transmittals default
     */
    public String getDefaultMsgOnSendToTransmittals()
    {
        commonMethods.waitForElement(driver,supplierToListOnPopUp);
        return $(supplierToListOnPopUp).getText();
    }
    /**
     * Method to enter suppliedBy user search
     */
    public void enterSuppliedByUserSearch(String toUserName)
    {
        $(suppliedByUser).clear();
        commonMethods.waitForElementExplicitly(2000);
        $(suppliedByUser).sendKeys(toUserName+Keys.ENTER);
        $(lookUpAssigneeSendTo).shouldBe(Condition.appear);
    }
    /**
     * Method to get the Initiator Tools display
     */
    public boolean getInitiatorToolsBtn()
    {
        return $(initiatorToolsBtn).isDisplayed();
    }

    /**
     * Method to click on the Package Number on search result
     */
    public void clickPackageNumber(String packageNumber)
    {
        commonMethods.waitForElement(driver,By.xpath("//td[@class='contentcell']//a[text()='"+packageNumber+"']"));
        $(By.xpath("//td[@class='contentcell']//a[text()='"+packageNumber+"']")).click();
    }
    /**
     * Method to get success message
     */
    public String getSuccessMsg()
    {
        commonMethods.waitForElement(driver,messageSuccess);
        return  $(messageSuccess).getText();
    }
    /**
     * Method to click Cancel On Initiator Tool
     */
    public void clickCancelOnInitiateSub()
    {
        commonMethods.waitForElement(driver,cancelButton);
        $(cancelButton).click();
    }
    /**
     * Method to select All Docs on Results in the same page
     */
    public void selectAllDocsOnResultsOnPage()
    {
        commonMethods.waitForElement(driver,clickSelectedOptions);
        $(clickSelectedOptions).click();
        commonMethods.waitForElement(driver,selectAllResultsOnPage);
        $(selectAllResultsOnPage).click();
    }
    /**
     * Method to select All docs in results
     */
    public void selectAllDocsOnResults()
    {
        $(loadingIcon).should(disappear);
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver,clickSelectedOptions);
        $(clickSelectedOptions).click();
        commonMethods.waitForElement(driver,selectAllSearchResults);
        $(selectAllSearchResults).click();
    }
    /**
     * Method to click initiator Tools and select Initiate Submission
     */
    public void clickInitiateSubmission()
    {
        commonMethods.waitForElement(driver,initiatorToolsBtn);
        $(initiatorToolsBtn).click();
        $(initiateSubmission).click();
    }
    /**
     * Method to click Cancel on Initiator Tools
     */
    public void clickCancelOnInitiatorTools()
    {
        commonMethods.waitForElement(driver,initiatorToolsBtn);
        $(initiatorToolsBtn).click();
        $(cancelSubmission).click();
    }
    /**
     * Method to cancel submission
     */
    public void clickCancelSubmission()
    {
        clickCancelOnInitiatorTools();
        commonMethods.waitForElement(driver,cancelCommentBox);
        $(cancelCommentBox).sendKeys("cancel");
        $(cancelOkButton).click();
    }
    /**
     * Method to cancel submission
     */
    public void verifyCancelDocument(String comments)
    {
        clickCancelOnInitiatorTools();
        commonMethods.waitForElement(driver,cancelCommentBox);
        Assert.assertEquals("checkTextAreaSize(event, this, 3000); ",$(cancelCommentBox).getAttribute("onkeyup"));
        $(cancelOkButton).click();
        Assert.assertEquals("Please specify a comment before continuing", getAlertText());
        acceptAlert();
        $(cancelCommentBox).sendKeys(comments);
        $(cancelOkButton).click();
    }
    /**
     * Method to verify the initiate submission header
     */
    public void verifyInitiateSubmissionHeader()
    {
        commonMethods.waitForElement(driver,createTransmittalBtn);
        Assert.assertTrue($(initiateSubmissionHeader).isDisplayed());
    }
    /**
     * Method to click mark as submitted under initiator tools
     */
    public void clickMarkAsSubmitted()
    {
        commonMethods.waitForElement(driver,initiatorToolsBtn);
        $(initiatorToolsBtn).click();
        $(markAsSubmitted).click();
    }
    /**
     * Method to get the planned submission date based on index
     */
   public String getPlannedSubmissionDate(String index)
   {
       commonMethods.waitForElementExplicitly(2000);
      return  $(By.xpath("//*[@id='plannedSubmissionDate_"+index+"_da']")).getValue();
   }
    /**
     * Method to enter submission date with provided value
     */
    public void enterSubmissionDate(String dateValue)
    {
        commonMethods.waitForElement(driver,submissionDateTextBox);
        $(submissionDateTextBox).sendKeys(dateValue);
    }
    /**
     * Method to enter the comments section with provided comments
     */
    public void enterCommentsOnInit(String comments)
    {
        enterComments(commentsIn, comments);
    }
    /**
     * Method to get the comments text
     */
    public String getComments()
    {
        $(commentsIn).click();
        return $(commentsTxtArea).getValue();
    }
    /**
     * Method to get the comments text
     */
    public String getCommentsOut()
    {
        $(commentsOut).click();
        return $(commentsTxtArea).getValue();
    }
    /**
     * Method to click on Save and Continue Button
     */
    public void clickSaveAndContinueBtn()
    {
        commonMethods.waitForElement(driver,saveAndContinueBtn);
        $(saveAndContinueBtn).click();
        commonMethods.waitForElement(driver,saveAndContinueMsg);
    }
    /**
     * Method to Clear the Search
     */
    public void clickClearBtn()
    {
        commonMethods.waitForElement(driver,clearButton);
        $(clearButton).click();
    }
    /**
     * Method to get the Results based on the Table Index
     */
    public String getSDResultsTableValue(String index)
    {
        return $(By.xpath("//table[@class='dataTable']//tbody[2]//td["+index+"]")).getText();
    }
    /**
     * Method to Click on Supplier Action
     */
    public void clickActionBtn()
    {
        commonMethods.waitForElement(driver,supplierAction);
        $(supplierAction).click();
        commonMethods.waitForElement(driver,submissionRequiredHeader);
    }
    /**
     * Method to get the Lock Image Source
     */
    public String getLockImgSrc()
    {
        return $(lockImg).getAttribute("src");
    }
    /**
     * Method to select the first result and click Mark as Submitted
     */
    public void selectMarkAsSubmitted()
    {
        commonMethods.waitForElementExplicitly(3000);
        $(firstPackageChkBox).click();
        clickMarkAsSubmitted();
    }
    /**
     * Method to get the Error Message on Submission
     */
    public String returnReason()
    {
        commonMethods.waitForElement(driver,reasonMsg);
        return $(reasonMsg).getText();
    }
    /**
     * Method to select Multiple package using the Package Number
     */
    public void multiSelectPackages(List<String> packageList)
    {
        commonMethods.waitForElement(driver,packageNumbersMultiSelect);
        $(packageNumbersMultiSelect).click();
        commonMethods.waitForElement(driver,packageNumbersInput);
        for(String packageNo:packageList)
        {
            $(packageNumbersInput).sendKeys(packageNo);
            $(By.xpath("//option[text()='"+packageNo+"']")).doubleClick();
            $(packageNumbersInput).clear();
        }
        commonMethods.waitForElementExplicitly(3000);
        $(packageNumbersOk).click();
    }
    /**
     * Method to select Submission Status to filter the results
     *//*
    public void setSubmissionStatus(List<String> submissionStatusList)
    {
        commonMethods.waitForElement(driver,submissionStatusMultiSelect);
        $(submissionStatusMultiSelect).click();
        commonMethods.waitForElement(driver,submissionStatusInput);
        for(String submissionStatus:submissionStatusList)
        {
            $(submissionStatusInput).sendKeys(submissionStatus);
            $(By.xpath("//option[text()='"+submissionStatus+"']")).doubleClick();
            $(submissionStatusInput).clear();
        }
        $(submissionStatusOk).click();
    }*/
    /**
     * Method to select Initiator Tools based on the Package No
     */
    public void setInitiatorTool(String PackageNo)
    {
        $(By.xpath("//a[text()='"+PackageNo+"']//..//button[@id='btnInitiatorTools_page']")).click();
        $(initiateSubmission).click();
    }
    /**
     * Method to get Error Messgae for Document Unavailable for the Package
     */
    public boolean getErrorMsgForDocUnAvailable(String errorMsg)
    {
        commonMethods.waitForElement(driver,docUnAvailableError);
        boolean flag=false;
        for(int iterator=1;iterator<=$$(excludeMsgTable).size();iterator++)
        {
            if($(By.xpath("//table[@id='excludedDocList']//tbody//tr["+iterator+"]//td[contains(text(),'"+errorMsg+"')]")).isDisplayed())
                flag=true;
            else
                flag=false;
        }
        return flag;
    }
    /**
     * Method to click on close on Exclude Dialog box
     */
    public void clickCloseOnExcludeBox()
    {
        commonMethods.waitForElement(driver,closeOnExcludeBox);
        $(closeOnExcludeBox).click();
    }
    /**
     * Method to click on close Dialog box
     */
    public void clickCloseOnDialogBox()
    {
        commonMethods.waitForElement(driver,closeOnDialogBox);
        $(closeOnDialogBox).click();
    }
    /**
     * Method to click on close Dialog box
     */
    public void clickCloseOnBtnSubmissionHistory()
    {
        commonMethods.waitForElement(driver,closeOnBtnSubmissionHistory);
        $(closeOnBtnSubmissionHistory).click();
    }
    /**
     * Method to get the submitted results size
     */
    public int verifySubmittedResults()
    {
        commonMethods.waitForElement(driver,createTransmittalBtn);
        return $$(submittedResultsSize).size();
    }

    /**
     * Method to get the Search Results Count on Submitted Screen
     */
    public int getTotalSubmittedResults()
    {
        String noOfResults=$(numberOfResults).getText();
        int resultsCount=0;
        if(noOfResults.contains("1-25"))
            resultsCount=Integer.valueOf(noOfResults.substring(8,10));
        return resultsCount;
    }
    /**
     * Method to choose document based on the Document No with Pagination
     */
    public void chooseDocument(String documentNo)
    {
        commonMethods.waitForElement(driver,initiatorToolsBtn);
        if($(By.xpath("//div[text()='"+documentNo+"']")).isDisplayed())
            selectDoc(documentNo);
        else
        {
            $(searchBtn).scrollTo();
            $(paginationToNext).click();
            chooseDocument(documentNo);
        }
    }
    /**
     * Method to select doc based on the document no
     */
    public void selectDoc(String documentNo)
    {
        commonMethods.waitForElementExplicitly(2000);
        WebElement documentCheckBox = driver.findElement(By.xpath("//div[text()='"+documentNo+"']//..//..//td//input[@type='checkbox']"));
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOf(documentCheckBox));
        wait.until(ExpectedConditions.elementToBeClickable(documentCheckBox));
        $(By.xpath("//div[text()='"+documentNo+"']//..//..//td//input[@type='checkbox']")).click();
    }
    /**
     * Method to click on pagination based on the instance - Previous and Next
     */
    public void clickOnPagination(String instance)
    {
        By pagination=By.xpath("(//div[@class='paging flow-right']//a[contains(text(),'"+instance+"')])[1]");
        if($(pagination).isDisplayed())
            $(pagination).click();
    }
    /**
     * Method to select based on the Count - Index
     */
    public void selectDocuments(int count)
    {
        commonMethods.waitForElement(driver,searchBtn);
        for(int iterator=1;iterator<=count;iterator++)
            $(By.xpath("(//table[@class='dataTable']//td//input[@type='checkbox'])[" + iterator + "]")).click();
    }
    /**
     * Method to get the document names displayed on the Submitted Screen
     */
    public ArrayList<String> getDocumentsSubmitted(int count)
    {
        ArrayList<String> docsSubmitted=new ArrayList<>();
        boolean paginationFlag=true;
        int rowCount=1;
        for(int iterator=1;iterator <=count;iterator++) {
            if(paginationFlag) {
                docsSubmitted.add($(By.xpath("//tbody[@id='submittedResults']//tr[" + iterator + "]//td[3]")).getText());
            }
            else
            {
                docsSubmitted.add($(By.xpath("//tbody[@id='submittedResults']//tr[" + rowCount + "]//td[3]")).getText());
                rowCount++;
            }
            if(iterator==25) {
                clickOnPagination("next");
                paginationFlag=false;
            }
        }
        return docsSubmitted;
    }
    /**
     * Method to enter planned submission date for all the documents displayed in the Initiate Submission Screen
     */
    public void setPlannedSubmissionDate(String date,int count)
    {
        boolean paginationFlag=true;
        int rowCount=0;
        for(int iterator=0;iterator<count;iterator++){
            if(paginationFlag) {
                $(By.xpath("//input[@id='plannedSubmissionDate_"+iterator+"_da']")).sendKeys(date);
            }
            else
            {
                $(By.xpath("//input[@id='plannedSubmissionDate_"+rowCount+"_da']")).sendKeys(date);
                rowCount++;
            }
            if(iterator==24) {
                $(nextPaginationBtnOnBottom).click();
                paginationFlag=false;
            }
        }
    }
    /**
     * Method to click on create transmittal button
     */
    public void clickCreateTransmittalBtn()
    {
        commonMethods.waitForElement(driver,createTransmittalBtn,60);
        $(createTransmittalBtn).click();
    }
    /**
     * Method to get exclude document message
     */
    public String getExcludeDocMsg()
    {
        $(loadingIcon).should(disappear);
        commonMethods.waitForElement(driver,excludeDocMsg);
        return $(excludeDocMsg).getText();
    }
    /**
     * Method to Click on Supplier Action
     */
    public void clickActionBtn(String docNo)
    {
        By supplierActionOnDoc=By.xpath("//td//div[contains(text(),'"+docNo+"')]//..//..//a//img[@title='View ALL documents assigned to you in package for submission']");
        commonMethods.waitForElement(driver,supplierActionOnDoc);
        $(supplierActionOnDoc).click();
        commonMethods.waitForElement(driver,submissionRequiredHeader);
    }

    /**
     * Method to select package using the Package Number
     */
    public void selectPackageNo(String packageNo)
    {
        commonMethods.waitForElement(driver,packageNumbersMultiSelect);
        $(packageNumbersMultiSelect).click();
        commonMethods.waitForElement(driver,packageNumbersInput);
        $(packageNumbersInput).sendKeys(packageNo);
        $(By.xpath("//option[text()='"+packageNo+"']")).doubleClick();
        $(packageNumbersInput).clear();
        $(packageNumbersOk).click();
    }
    /**
     * Method to click on create transmittal button
     */
    public void verifyCreateTransmittalBtn()
    {
        commonMethods.waitForElement(driver,createTransmittalBtn);
        $(createTransmittalBtn).shouldBe(visible);
    }
    /**
     * Method to click on create transmittal button
     */
    public void verifySaveAndContinueBtn()
    {
        commonMethods.waitForElement(driver,saveAndContinueBtn);
        $(saveAndContinueBtn).shouldBe(visible);
    }
    /**
     * Method to select Submission Status to filter the results
     */
    public void setSubmissionStatus(List<String> submissionStatusList)
    {
        getElementInView(inputDocNo);
        commonMethods.waitForElement(driver,submissionStatusMultiSelect);
        $(submissionStatusMultiSelect).click();
        commonMethods.waitForElement(driver,submissionStatusInput);
        for(String submissionStatus:submissionStatusList)
        {
            $(submissionStatusInput).sendKeys(submissionStatus);
            $(By.xpath("//option[text()='"+submissionStatus+"']")).doubleClick();
            $(submissionStatusInput).clear();
        }
        $(submissionStatusOk).click();
    }
    /**
     * Method to get comments area length
     */
    public String getCommentsAreaLength()
    {
        return $(commentsTxtArea).getAttribute("onkeyup");
    }

    /**
     * Method to verify summary of transmitted documents
     */
    public void verifySummaryOfTransmittedDocs()
    {
        commonMethods.waitForElement(driver,summaryOfTransmittedDocs,60);
    }
    /**
     * Method to verify comments out
     */
    public String verifyCommentsOut()
    {
        String comments=faker.number().digits(3001);
        commonMethods.waitForElementExplicitly(3000);
        enterComments(commentsOut,comments);
        commonMethods.waitForElementExplicitly(3000);
        return getAlertText();
    }
    /**
     * Method to get header on the submission screen
     */
    public String getHeaderOnSubmissionScreen()
    {
        commonMethods.waitForElement(driver,headerOnInitatePage,60);
        return $(headerOnInitatePage).getText();
    }
    /**
     * Method to get not yet registered message
     */
    public String getNotYetRegisteredMsg()
    {
        commonMethods.waitForElement(driver,notRegisterdYetMsg);
        return $(notRegisterdYetMsg).getText();
    }
    /**
     * Method to click mail on on not yet registered message
     */
    public void clickMailNotRegisteredMsg()
    {
        commonMethods.waitForElement(driver,mailNoOnNotRegisterMsg);
        $(mailNoOnNotRegisterMsg).click();
    }
    /**
     * Method to verify tasks submitted package
     */
    public boolean verifyTasksSubmittedPackage(String sdNumber)
    {
        By sdPackageLink=By.xpath("//tbody[@id='grid-group-body-supplierdocssubmissionrequired']//*[contains(text(),'"+sdNumber+"')]");
        commonMethods.waitForElement(driver,sdPackageLink,30);
        return $(sdPackageLink).isDisplayed();
    }
    /**
     * Method to navigate to submitted screen
     */
    public void navigateToSubmittedScreen(String sdNumber)
    {
        By sdPackageLink=By.xpath("//tbody[@id='grid-group-body-supplierdocssubmissionrequired']//*[contains(text(),'"+sdNumber+"')]");
        commonMethods.waitForElement(driver,sdPackageLink,30);
        $(sdPackageLink).click();
    }
    /**
     * Method to navigate to submitted screen
     */
    public String navigateToSubmittedScreen()
    {
        commonMethods.waitForElement(driver,navigateSubmissionRequiredLink,30);
        String packageNo=$(navigateSubmissionRequiredLink).getText();
        $(navigateSubmissionRequiredLink).click();
        if(packageNo.contains("(")) {
            int length = packageNo.length();
            packageNo=packageNo.substring(0,length-3);
        }
        return packageNo.trim();
    }
    /**
     * Method to verify submitted document No
     */
    public boolean verifySubmittedDocNo(String docNo)
    {
        By docNoSubmittedResults=By.xpath("//tbody[@id='submissionRequiredResults']//tr//*[contains(text(),'"+docNo+"')]");
        commonMethods.waitForElement(driver,docNoSubmittedResults,30);
        return $(docNoSubmittedResults).isDisplayed();
    }
    /**
     * Method to verify Actions Icon and doc input CheckBox on Submission Required Screen
     */
    public void verifyDocumentDetailsOnReview()
    {
        commonMethods.waitForElement(driver,actionsNavOnSubmissionRequired,30);
        commonMethods.waitForElement(driver,inputCheckBoxOnSubmissionRequired,30);
        commonMethods.waitForElement(driver,fileIconOnSubmissionRequired,30);
    }
    /**
     * Method to verify submission not accepted
     */
    public String verifySubmissionNotAccepted()
    {
        return $(errorMsg).getText();
    }

    /**
     * Method to get search value based on the Documents or Supplier Document Number
     */
    public String getSearchValue(String instance,String searchNo)
    {
        String searchValue;
            if (instance.equalsIgnoreCase("sd")) {
                searchValue = packagePage.getPackageNumber(searchNo);
                selectPackageNo(searchValue);
            } else {
                 searchValue = commonMethods.returnDocNumberInJson(searchNo);
                 searchPackage(searchValue);
            }
        return searchValue;
    }
    /**
     * Method to get manually marked message
     */
    public String getManuallyMarkedMsg(String docNum)
    {
        By warningMsg=By.xpath("//td//div[contains(text(),'"+docNum+"')]//..//..//a[@class='warning-icon']");
        commonMethods.waitForElement(driver,warningMsg);
        return $(warningMsg).getAttribute("data-content");
    }
    /**
     * Method to get the Results based on the Table Index
     */
    public String getSDResultDocValue(String docNo,String index)
    {
        By tableVal=By.xpath("//table[@class='dataTable']//tbody[2]//td//div[contains(text(),'"+docNo+"')]//..//..//td["+index+"]");
        return $(tableVal).getText();
    }
    /**
     * Method to click Start Workflow Button
     */
    public void clickStartWorkFlowBtn()
    {
        commonMethods.waitForElement(driver,btnStartWorkflow);
        $(btnStartWorkflow).click();
    }

    /**
     * Method to verify the planned submission date based on index
     */
   public boolean verifyPlannedSubmissionDate(String plannedDate)
   {
       if(commonMethods.getDate(configFileReader.getTimeZone(),"yesterday").equalsIgnoreCase(plannedDate))
           return true;
       else if(commonMethods.getDate(configFileReader.getTimeZone(),"today").equalsIgnoreCase(plannedDate))
           return true;
       else if(commonMethods.getDate(configFileReader.getTimeZone(),"tomorrow").equalsIgnoreCase(plannedDate))
           return true;
       else
           return false;
   }
    /**
     * Method to click Error Message LInk
     */
   public void clickErrorMsgLink()
   {
       commonMethods.waitForElement(driver,errorMsgLink);
       $(errorMsgLink).click();
   }
    /**
     * Method to get click on Access document menu
     */
    public void clickAccessDocumentsMenu() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, accessDocumentsMenu);
        $(accessDocumentsMenu).click();
    }

    /**
     * Method to click on update document option
     */
    public void clickUpdateDoc() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, updateDocOption, 60);
        $(updateDocOption).click();

    }

    /**
     * Method to click on Edit / Upload new version option
     */
    public void clickSupersedeDoc() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, supersedeDocOption);
        $(supersedeDocOption).click();
    }

    /**
     * Method to click on Add Documents from Document Register link from Initiator tools
     */
    public void clickAddDocsBtn() {
        commonMethods.waitForElement(driver,initiatorToolsBtn);
        $(initiatorToolsBtn).click();
        commonMethods.waitForElement(driver,lnkAddDocsFromDocReg);
        $(lnkAddDocsFromDocReg).click();
    }

    /**
     * Method to click on document number in supplier document search page
     */
    public void clickOnDocumentNumber(String docNum) {
        By xpath = By.xpath("//div[@id='searchResultsContainer']//table//td/div[text()='" + docNum + "']");
        commonMethods.waitForElement(driver, xpath);
        $(xpath).click();
    }

    /**
     * Method to click on Update button in doc search page
     */
    public void clickUpdate() {
        commonMethods.waitForElement(driver, btnUpdate);
        $(btnUpdate).click();
    }

    /**
     * Method to click on Document Properties button
     */
    public void clickDocProperties() {
        commonMethods.waitForElement(driver, btnDocProperties);
        $(btnDocProperties).click();
    }

    /**
     * Method to click on Document Properties button
     */
    public void clickDocPropertiesLink() {
        commonMethods.waitForElement(driver, lnkDocPropertiesOption);
        $(lnkDocPropertiesOption).click();
    }

    /**
     * Method to click on Event log button
     */
    public void clickEventLog() {
        commonMethods.waitForElement(driver, btnEventLog);
        $(btnEventLog).click();
    }

    /**
     * Method to verify document properties window
     */
    public boolean verifyDocProperties(String docNo) {
        return $(By.xpath("//div[@id='docPropertiesPanel_body']//table//td/div[contains(text(),'" + docNo + "')]")).isDisplayed();
    }

    public void closeDocProperties() {
        commonMethods.waitForElement(driver, btnDocPropertiesClose);
        $(btnDocPropertiesClose).click();
    }

    /**
     * Method to click on download button
     */
    public void clickDownload() {
        commonMethods.waitForElement(driver, btnDownload);
        $(btnDownload).click();
    }

    /**
     * Method to verify on the active package with package No is displayed
     */
    public boolean verifyActivePackageNo(String packageNo)
    {
        return $(By.xpath("//a[@title='Click to view the supplier document package details' and contains(text(),'"+packageNo+"')]")).isDisplayed();
    }
    /**
     * Function to get default sort By values in SdPackage search page
     */
    public List<String> getAvailableSortTypes() {
        verifyAndSwitchFrame();
        return commonMethods.returnAllOptionsInDropDown(driver, sortBy);
    }
    /**
     * Method to return the value present by default in SD package sortBy
     *
     * @return
     */
    public String getDefaultSortTypeValue() {
        return $(sortBy).getSelectedOption().getText();
    }

    /**
     * Method to remove the document
     */
    public void removeDocument(){
        $(initiatorToolsBtn).click();
        $(removeDocumentLink).click();
        clickCloseOnDialogBox();

    }

    /**
     * Method to modify the due date for a document
     */
    public void modifyDueDate(String operation, String days) {
        $(initiatorToolsBtn).click();
       $(modifyDueDateLink).click();
       if(operation.equals("SET_DATE")){
           String dateValue = commonMethods.getDate(configFileReader.getTimeZone(), "tomorrow");
           $(dateCalTxtField).sendKeys(dateValue);
       } else {
           $(modifyDueDatesSlt).selectOptionByValue(operation);
           $(daysTxtField).sendKeys(days);
       }
       $(reason).sendKeys("Entering modified date");
       $(clickModifyDateOkBtn).click();
    }


}
