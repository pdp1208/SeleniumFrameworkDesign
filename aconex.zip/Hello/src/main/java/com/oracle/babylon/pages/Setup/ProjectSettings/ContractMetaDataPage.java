package com.oracle.babylon.pages.Setup.ProjectSettings;

import org.openqa.selenium.By;
import static com.codeborne.selenide.Selenide.$;

public class ContractMetaDataPage extends ListMyProjectsPage{

    private By spm = By.xpath("//input[@id='projectMetaData-spmPlan']");
    private By subscriptionId = By.xpath("//input[@id='projectMetaData-subscriptionId']");
    private By subscriptionEndDate = By.xpath("//input[@id='projectMetaData-subscriptionEndDate']");
    private By today = By.xpath("//button[text()='Today']");


    public void enterMandatoryData(String spmValue, String subscriptionIdValue) {
        $(spm).clear();
        $(spm).sendKeys(spmValue);
        $(subscriptionId).clear();
        $(subscriptionId).sendKeys(subscriptionIdValue);
        $(subscriptionEndDate).click();
        $(today).click();

    }
}
