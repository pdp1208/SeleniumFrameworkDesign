package com.oracle.babylon.pages.Mail;

import com.codeborne.selenide.WebDriverRunner;
import com.github.javafaker.Faker;
import com.oracle.babylon.Utils.helper.Navigator;
import com.oracle.babylon.pages.Document.DocumentPage;
import com.oracle.babylon.pages.Tasks.TaskPage;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import java.io.File;
import java.util.*;
import java.util.stream.Collectors;

import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Selenide.*;

/**
 * Class that contains common methods related to Mails
 * Author : susgopal
 */
public class MailPage extends Navigator {

    //Initializing the web elements

    protected By searchBtn = By.xpath("//button[@title='Search']");
    public By mailNoTextBox = By.id("rawQueryText");
    private By optionsBtn = By.id("btnMailOptions");
    private By loadingIcon = By.cssSelector(".loading_progress");
    private By tableHead = By.xpath("//table[@id='resultTable']//thead//th");
    private By sendBtn = By.xpath("//button[@id='btnSend']");
    private By viewMailSendBtn = By.xpath("//button[@ng-click = 'send()']");
    private By addRemovePanel = By.xpath("//div[@class='auiModal-content']");
    private By mailNumberField = By.xpath("//div[@class='mailHeader-numbers']//div[2]//div[2]");
    private By mailNoFromTable = By.xpath("//td[@class='column_documentNo']");
    private By unreadMail = By.xpath("//tr[@class='dataRow unread highlight-row ng-scope']");
    private By attributeAddButton = By.xpath("//button[@id='attributeBidi_PRIMARY_ATTRIBUTE_add']");
    private By correspondenceTypeId = By.xpath("//select[@id='Correspondence_correspondenceTypeID']");
    private By reasonForIssue = By.xpath("//select[@id='Correspondence_correspondenceReasonID']");
    private By reasonForIssueFirstOption = By.xpath("//select[@id='Correspondence_correspondenceReasonID']//option[2]");
    private By mailType = By.xpath("//div[@class='mailHeader-value']");
    private By subject = By.xpath("//div[@class='mailHeader-subject']//h2//span");
    private By attribute = By.xpath("//div[@class='auiDetails-value mailAttributes-value ng-binding']");
    private By document = By.xpath("//table[@class='auiTable']//div[contains(text(),'confidential')]");
    private By documentAttachment = By.xpath("//mail-attached-documents[@class='ng-isolate-scope']//div//div[@class='auiCollapsibleSection-bodyContainer ng-isolate-scope auiCollapsible']");
    private By documentNumber = By.xpath("//td[@class='mailAttachedFiles-filename']//a");
    private By mailSubject = By.xpath("//table[@id='resultTable']//tr[1]//td//a");
    private By subjectMail = By.xpath("//input[@id='Correspondence_subject']");
    private By mailSubjectTxt = By.xpath("//table[@id='resultTable']//tr[1]//td//a//span");
    protected By myMailOnlyChkBox = By.xpath("//span[contains(text(),'My mail only')]//././../input");
    private By markAsUnread = By.xpath("//a[@class='ng-binding ng-scope']");
    private By markedAsUnreadMsg = By.xpath("//div[contains(text(),'Marked as unread')]");
    private By firstMailPageLink = By.xpath("//div[@id='searchResultsWrapper']//div[@class='searchNav clearfix']//a[contains(text(),'1')]");
    private By projectMailAttachmentIcon = By.xpath("//div[@class='mailAttachedMails ng-scope']//td//a");
    private By mailAttachmentsText = By.xpath("//span[contains(text(),'Mail Attachments')]");
    private By fileAttachmentsText = By.xpath("//span[contains(text(),'File Attachments')]");
    private By fileNameOnAttachment = By.xpath("//td[@class='mailAttachedFiles-filename']//a");
    String userFilePath = configFileReader.getUserDataPath();
    public By actionMailBodyBtn = By.xpath("//descendant::button[contains(text(),'Actions')][2]");
    public By actionOnTopBtn = By.xpath("//div[@class='auiToolbar fixed noprint']//button[contains(text(),'Actions')]");
    private By resultTable = By.xpath("//table[@id='resultTable']");
    protected By resultTableRow = By.xpath("//table[@id='resultTable']//tbody[contains(@id,'rowPer')]//tr");
    private By resultTableRowInputs = By.xpath("//table[@id='resultTable']//tbody//tr//td//input");
    private By firstMailChkBox = By.xpath("//table[@id='resultTable']//tbody//tr[1]//td[1]//input");
    private By firstRecord = By.xpath("//table[@id='resultTable']//tbody[contains(@id,'TableBody')]//tr[1]//td[1]");
    private By addOrRemoveBtn = By.xpath("//button[@title='Choose the columns displayed in the search results']");
    private By addButton = By.xpath("//button[@title='Add item to list']");
    private By removeBtn = By.xpath("//button[@title='Remove item from list']");
    private By okBtn = By.xpath("//button[@id='ok']");
    private By checkBoxSaveAsDefault = By.xpath("//input[@ng-model='saveAsDefault.value']");
    protected static String mailNumber = null;
    protected static String draftMailNumber = null;
    protected By addRemoveColumnBtn = By.xpath("//button[@title='Choose the columns displayed in the search results']");
    private By selectedColumns = By.xpath("//div[@class='auiModal-content']//div[@class='manual-sort']");
    private By selectedColumnsSelect = By.xpath("//div[@class='auiModal-content']//div[@class='manual-sort']//select");
    private By resetBtn = By.xpath("//button[@class='auiButton pull-right reset ng-binding']");
    private String availableOptions = "//div[@class='bidi-available not-sorted']";
    private String selectedOption = "//div[@class='manual-sort']";
    private By addColumn = By.xpath("//button[contains(text(),'>>')]");
    private By tableHeader = By.xpath("//table[@id='resultTable']//thead//tr");
    public By toolsBtn = By.xpath("//span[contains(text(),'Tools')]");
    private By removeColumn = By.xpath("//button[contains(text(),'<<')]");
    private By cancelBtn = By.xpath("//button[text()='Cancel']");
    private By filterSearch = By.xpath("//input[@placeholder='- Filter -']");
    private By recipientSection = By.xpath("//div[@class='auiDetails']");
    private By noResult = By.xpath("//span[contains(text(),'No matching results found.')]");
    private By availableFilter = By.xpath("//div[@class='bidi']//div[1]/../select[1]");
    private By selectedFilter = By.xpath("//div[@class='bidi']//div[2]/select[1]");
    private By saveAsDefault = By.xpath("//*[contains(text(),'Save as my default')]");
    private By markAsCloseOutOption = By.xpath("//a[contains(text(),'Mark as Closed-Out')]");
    private By closeOutOption = By.xpath("//a[contains(text(),'Close Out')]");
    protected By firstMailNumber = By.xpath("//table[@id='resultTable']//tbody//tr[1]//td[@class='column_documentNo']//span");
    private By markAsCloseOutBtnPopUp = By.xpath("//button[contains(text(),'Mark mail as Closed-Out')]");
    private By closeOutSuccessMessage = By.xpath("//div[@class='auiMessage-content']");
    private By selectFirstMail = By.xpath("//table[@class='auiTable']//tbody//tr[1]//td[1]//input");
    private By selectSecondMail = By.xpath("//table[@class='auiTable']//tbody//tr[2]//td[1]//input");
    private By draftSendBtn = By.xpath("//button[text()='Send']");
    private By tableElement = By.xpath("//tbody[@id='rowPerMailTableBody']");
    private By rowElements = By.xpath("//tbody[@id='rowPerMailTableBody']//tr");
    private By scrollBarInAttributeDropdown = By.xpath("//div[@class='selectize-dropdown-content ng-scope']");
    public static List<String> mailNumbers = new LinkedList<>();
    public By printRequestBtn = By.xpath("//a[contains(text(),'Submit a Print Request')]");
    public By dateColumn = By.xpath("//div[contains(text(),'Date')]//..//div[2]");
    public By dateColumnFilter = By.xpath("//div[@class='dropdown-menu']");
    private By highlightedRow = By.xpath("//table//tbody//tr[@class='dataRow highlight-row ng-scope']");
    protected By myUnreadChkbox = By.xpath("//span[contains(text(),'My Unread')]//..//input");
    private By unreadMails = By.xpath("//table//tbody//tr[@class='dataRow unread ng-scope']");
    protected By showOneRowPerDropdown = By.xpath("//div[@class='mail-view-config pull-left']//select[1]");
    private By rowPerMailAlertMsg = By.xpath("//div[@modal-instance='alertDialog.modalInstance']/div/h3");
    protected By newMailBtn = By.xpath("//a[contains(text(),'New Mail')]");
    private By responseRequiredDropdown = By.xpath("//select[@id='Correspondence_responseDate-responseTypes']");
    private By calenderIcon = By.xpath("//div[@class='bicon ic-calendar']");
    private By responseRequiredDate = By.xpath("//input[@name='Correspondence_responseDate-responseDate_da']");
    private By markAsClosedOutBtn = By.xpath("//button[contains(text(),'Mark as Closed-Out')]");
    private By orgDetails = By.xpath("//span[@class='nav-orgDetails']");
    private By clearAllFilter = By.xpath("//a[@title='Clear all filters']");
    JavascriptExecutor js = (JavascriptExecutor) driver;
    protected By clearAllLink = By.xpath("//div[@class='clear-all-container']//a[contains(.,'Clear All')]");
    protected By viewSendBtn = By.xpath("//button[contains(text(),'Send')]");
    private By mailNo = By.xpath("//div[@class='mailHeader-numbers']//div[2]//div[2]");
    private By errorMsg = By.xpath("//div[@id='messagePanel']");
    private By noMatchingResults = By.xpath("//span[contains(text(),'No matching results found.')]");
    private By pageTitle = By.xpath("//h1//span[text()='Search Mail']");
    private By myUnreadChkBox = By.xpath("//span[contains(text(),'My Unread')]//././../input");
    private By startWorkFlowBtn = By.xpath("//button[contains(text(),'Start a Workflow')]");
    private By loggedInUserName = By.xpath("//span[@class='nav-userDetails']");
    private By recipientName = By.xpath("//table[@id='resultTable']//tbody//tr[1]//td[8]//span");
    private By markAsRead = By.xpath("//a[contains(text(),'Mark as Read')]");
    private By mailBodyRow = By.xpath("//tbody[@id='rowPerMailTableBody']");
    private By registerIncomingReply = By.xpath("//a[contains(text(),'Register an incoming reply')]");
    private By referenceNumber = By.xpath("//div[@class='mailHeader-numbers']//div[3]//div[2]");
    private By viewUnreadMail = By.xpath("//label[@id='show-unread-only']//input");
    private By selectRowDisplayOption = By.xpath("//label[contains(.,'Show one row per')]//select");
    private By rowPerPopUp = By.xpath("//div[@class='ng-scope ng-isolate-scope']");
    protected By anyMail = By.xpath("//div[@class='ng-isolate-scope']//label[1]//input[1]");
    private By sendPublicBtn = By.xpath("//button[contains(.,'Send As Public')]");
    protected Map<String, Object> docMap = null;
    private By mailNumberHeader = By.xpath("//div[contains(text(),'Mail Number')]");
    private By printRequestPageTitle = By.xpath("//h1[contains(.,'Print Request')]");
    private By toField = By.xpath("//input[@id='SPEED_ADDRESS_TO']");
    private By addColumnError = By.xpath("//div[@class='auiModal-content']");
    private By errorOkBtn = By.xpath("//button[text()='OK']");
    private By addColumnErrorMsg = By.xpath("//div[@class='auiModal-content']//p");
    private By closeOutLink = By.xpath("//ul[@class = 'dropdown-menu']//li//a[contains(.,'Close-out')]");
    public By mailCount = By.xpath("//div[@class='searchNav clearfix']//div[@id='numResults']//span[1]");
    private By onPanelAttachBtn = By.xpath("//div[@id='attachOnNewPanel_buttons']//div[@class='uiButton-label'][contains(text(),'Attach')]");
    private By toRecipient = By.xpath("//div[@class='ng-isolate-scope']//label[contains(.,'To')]//input");
    private By fileAttachments = By.xpath("//span[contains(.,' Attachments')]");

    private By replyBtn = By.xpath("//button[text()='Reply']");
    private By replyAllBtn = By.xpath("//button[text()='Reply to All']");
    private By forwardBtn = By.xpath("//button[text()='Forward']");
    private By ownMailNumber = By.xpath("//input[@id='radSpecifyMailNoManually']");
    private By mailNumberTxtBox = By.xpath("//input[@id='Correspondence_documentNo']");
    private By optionsOkBtn = By.xpath("//div[@class='uiButton-label' and text()='OK']");
    private By docRegister = By.xpath("//button[contains(@title,'Register selected Controlled')]");
    private By createForward = By.xpath("//button[contains(@title,'Create a Forwarding')]");
    private By printBtn = By.xpath("//button[contains(text(),'Print')]");
    private By getAddRemovePanelClose = By.xpath("//div[@class='auiModal-close']");
    private By messageBody = By.xpath("//acx-mail-body[@class='ng-isolate-scope']");
    private By mailFooter = By.xpath("//textarea[@id='Correspondence_footer']");
    private By reasonForIssueViewMail = By.xpath("//div[@class='mailHeader']//div[@class='auiDetails']//div[contains(text(),'Reason')]/following-sibling::div");
    private By mailStatus = By.xpath("//div[@class='mailHeader']/div[@class='auiDetails']/div[contains(.,'Status')]");
    private By localFileUploadBtn = By.xpath("//input[@title='file input']");
    private By localFileAttachBtn = By.xpath("//button[@id='btnAttachLocalFile']//div[contains(text(),'Attach')]");
    private By localFileCloseBtn = By.xpath("//button[@id='btnCloseAttachments']//div[contains(text(),'Close')]");
    private By inboxAttachCount = By.xpath("//span[@ng-bind-html='getResultSummary()']");
    private String lnkMore = "//a[contains(text(),'more...')]";
    private String multiSelectLocator = "//div[contains(@id,'_bidi')]//div[@class='uiBidi-left']//select";
    private String multiSelectSelector = "//div[contains(@id,'_bidi')]//div[@class='uiBidi-right']//select/option";
    private By lblNoRecipient = By.xpath("//div[contains(text(),'No Recipients Currently Selected')]");
    private By btnReload = By.xpath("//button[contains(text(),'Reload')]");
    private By btnCancel = By.xpath("//button[contains(text(),'Cancel')]");
    private By btnOK = By.xpath("//button[@type='button' and @title='OK']");
    private By hdrReloadError = By.xpath("//h3[text()=\"Sorry, we can't save your changes\"]");
    private By lnkPagePrevious = By.xpath("//div[@class='top-paging ng-scope']//a[@ng-click='selectPage(page - 1)']");
    private By lnkPageNext = By.xpath("//div[@class='top-paging ng-scope']//a[@ng-click='selectPage(page + 1)']");
    private By btnApprove = By.xpath("//button[contains(text(),'Approve')]");
    private By btnReject = By.xpath("//button[contains(text(),'Reject')]");
    private By btnPopUpWindowApprove = By.xpath("//div[@class='auiModal-footer ng-scope']//button[contains(text(),'Approve')]");
    private By hdrMailApproval = By.xpath("//h3[contains(text(),'Mail Approval')]");
    private By lblConfirmation = By.xpath("//div[contains(text(),'Are you sure you want to approve this mail?')]");
    private By imgProfileIcon = By.xpath("//img[@title='Sent - Pending Approval']");
    private String wfTableRows = "//table[@class='formTable']//tr";
    private String wfTableCols = "//table[@class='formTable']//tr[2]/td";
    private By firstMailInputCheckBox = By.xpath("(//table[@id='resultTable']//tbody//tr//td[1]//input)[1]");

    //Reports
    protected By reportsBtn = By.xpath("//button[@title='Reports']");
    private By successMsg = By.xpath("//div[@class='auiMessage success']");
    private By closeBtn = By.xpath("//button[text()='Close']");
    private By reportsOptions = By.xpath("//div[@class='open']//ul[@class='dropdown-menu']//a");

    //Save search
    private By saveBtn = By.xpath("//button[@title='Save the current search configuration']");
    private By nameOfSearch = By.xpath("//div[@class='form-field']//input[@type='text']");
    private By saveOkBtn = By.xpath("//input[@id='ok']");
    private By savedSearchErrorMsg = By.xpath("//div[contains(text(),'A saved search already exists with that name. Please enter a different name')]");
    private By cancelActionBtn = By.xpath("//button[@title='Cancel this action']");
    private By description = By.xpath("//div[@class='form-field']//textarea");

    //Edit Saved Search
    private By savedSearchBtn = By.xpath("//div[@class='filter-container pull-left']//button[@class='auiButton']");
    private By deleteSavedSearchBtn = By.xpath("//button[@title='Delete this item']");
    private By confirmDeleteBtn = By.xpath("//button[@name='actionButton']");
    private By useAutoNumbering = By.xpath("//input[@id='radAutoMailNo']");
    private By useAutoNumbermailNow= By.xpath("//input[@id='radAllocateRealMailNoNow']");
    Faker faker = new Faker();
    //Remove type
    protected By advancedSearchBtn = By.xpath("//button[text()='Advanced Search']");
    private By selectFilter = By.xpath("//div[@class='auiModal-dialog large']//select[contains(@class,'auiField-input')]");
    private By typeTrans = By.xpath("//div[text()='Type']//../../../../..//span[text()='Transmittal'][1]");
    private By addedFilters = By.xpath("//div[@class='filters-container ng-scope']//div[@class='title ng-binding']");
    private By zeroResultMessage = By.xpath("//div[@class='well no-results-container']");
    private By clearAllMsg = By.xpath("//div[@class='auiMessage info']");

    //Table elements and package identifiers
    private By tableRows = By.xpath("//table[@class='auiTable']//tbody//tr");
    private By linkToPackages = By.xpath("//a[@title='Link to packages']");
    public By submitDocumentBtn = By.xpath("//a[contains(text(),'Submit Documents')]");
    private By clickSelectedOptions=By.xpath("//div[@title='Click for Selection Options']");
    private By selectAllResultsOnPage=By.xpath("//a[text()='Select All On This Page']");
    private By selectAllSearchResults=By.xpath("//a[text()='Select All Results']");

    private By sendMailAsConf = By.xpath("//button[@id='hasConfiDocsPanel_btnSendAsConfidential']");
    private By attachIcon = By.xpath("//table[@class='auiTable']//tr[1]//i[@class='attachment']");
    private By searchFilter = By.xpath("//html");
    private By mailNumPreview = By.xpath("//span[@id='mailNumber']");


    String mailFilePath = configFileReader.getMailDataPath();
    String docFilePath = configFileReader.getDocumentDataPath();
    String filePath = configFileReader.getTestDataPath();
    private DocumentPage documentPage = new DocumentPage();
    private MailApprovalsPage mailApprovalsPage = new MailApprovalsPage();
   // private ComposeMailPage composeMailPage=new ComposeMailPage();


    public MailPage() {
        this.driver = WebDriverRunner.getWebDriver();
    }


    /**
     * Function to navigate to mail pages
     *
     * @param page it takes page name
     */

    public void navigateAndVerifyPage(String page) {
        switch (page.toLowerCase()) {
            case "inbox":
            case "in box":
            case "inbox page":
                new InboxPage().navigateAndVerifyPage();
                break;
            case "sent":
            case "sentbox":
            case "sent box":
            case "sent page":
                new MailSentPage().navigateAndVerifyPage();
                break;
            case "draft":
            case "draft page":
            case "draft mail":
                new DraftMailPage().navigateAndVerifyPage();
                break;
            case "all":
            case "all mails":
            case "all page":
                new AllMailsPage().navigateAndVerifyPage();
                break;
        }
    }

    /**
     * Function to search mails by the mail number search key
     *
     * @param mail_number
     */
    public void searchMailNumber(String mail_number) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, mailNoTextBox, 35);
        commonMethods.waitForElementExplicitly(1000);
        $(mailNoTextBox).clear();
        commonMethods.waitForElementExplicitly(1000);
        $(mailNoTextBox).sendKeys(mail_number + Keys.ENTER);
        commonMethods.waitForElementExplicitly(1000);
        $(mailNoTextBox).sendKeys(Keys.ENTER);
        $(searchBtn).doubleClick();
        commonMethods.waitForPageLoad(driver);
        verifyAndSwitchFrame();
        addColumnIfNotPresent("Mail No", "mail");
        try {
            commonMethods.waitForElement(driver, firstMailNumber, 60);
        } catch (TimeoutException e) {
            clickSearch();
        }
        try {
            commonMethods.waitForElement(driver, firstMailNumber, 60);
        } catch (TimeoutException e) {
            clickSearch();
        }
        $(loadingIcon).should(disappear);
    }

    public void refresh() {
        driver.navigate().refresh();
        commonMethods.waitForPageLoad(driver);
    }

    /**
     * Return the number of rows when we search for the mail
     *
     * @return
     */
    public int searchResultCount() {
        verifyAndSwitchFrame();
        try {
            commonMethods.waitForElement(driver, By.cssSelector(".dataRow"), 30);
            return driver.findElements(By.cssSelector(".dataRow")).stream().filter(e -> e.isDisplayed()).collect(Collectors.toList()).size();
        } catch (TimeoutException e) {
            return 0;
        }
    }

    /**
     * Function to select the mail type while composing the mail
     *
     * @param mailType input for correspondence type id
     */
    public void selectMailType(String mailType) {
        $(loadingIcon).should(disappear);
        commonMethods.waitForElement(driver, correspondenceTypeId, 40);
        if (!mailType.equals("default")) {
            $(correspondenceTypeId).selectOption(mailType);
        } else {
            Select select = new Select(driver.findElement(correspondenceTypeId));
            select.selectByIndex(1);
        }
    }

    /**
     * Retrieve the mail using the mail number as the key
     *
     * @return the mail number of the
     */
    public String getMailNumber() {
        commonMethods.waitForElement(driver, mailNoFromTable, 30);
        return driver.findElement(mailNoFromTable).getText();
    }

    /**
     * Function to select the field attribute*
     *
     * @param attributeIdentifier key to be searched
     * @param value               the value that needs to be selected
     */
    public void selectMailAttribute(String attributeIdentifier, String value) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        verifyAndSwitchFrame();
        //Selecting attribute from the left panel to the right panel.Click on OK after it is done.
        String attributeLocator = "//tr//td//label[contains(text(),'" + attributeIdentifier + "')]//..//..//td[2]//div";
        commonMethods.waitForElement(driver, (By.xpath(attributeLocator)));
        js.executeScript("window.scrollBy(0,-1000)", "");
        $(By.xpath(attributeLocator)).click();
        switch (attributeIdentifier) {
            case "Attribute 1":
                selectAttribute(value, "attributeBidi_PRIMARY_ATTRIBUTE");
                break;
            case "Attribute 2":
                selectAttribute(value, "attributeBidi_SECONDARY_ATTRIBUTE");
                break;
            case "Attribute 3":
                selectAttribute(value, "attributeBidi_THIRD_ATTRIBUTE");
                break;
            case "Attribute 4":
                selectAttribute(value, "attributeBidi_FOURTH_ATTRIBUTE");
                break;
        }
        driver = commonMethods.waitForElement(driver, attributeAddButton);
        $(attributeAddButton).click();
        driver = commonMethods.waitForElement(driver, By.xpath("//button[@id='attributePanel-commit' and @title='OK']"));
        selectAttributeClickOK();
    }

    /**
     * Function to select Attributes
     *
     * @param value
     * @param attributeNumber
     */
    public void selectAttribute(String value, String attributeNumber) {
        String[] attributeKey = value.split(",");
        String attributeLocator1 = "//div[@id='";
        String attributeLocator2 = "']//div[@class='uiBidi-left']//select";
        String attLocator = attributeLocator1 + attributeNumber + attributeLocator2;
        Map<String, Map<String, Object>> mapOfMap = dataSetup.loadJsonDataToMap(mailDataPath);
        Map<String, Object> mailAttributeMap = mapOfMap.get(value);
        if (value.equals("default")) {
            driver = commonMethods.waitForElement(driver, (By.xpath(attLocator)));
            $(By.xpath(attLocator + "//option")).doubleClick();
        } else {
            List<String> listOfAttributes = new ArrayList<String>();
            JSONObject jsonObject = new JSONObject(mapOfMap.get(attributeKey[0]));
            JSONArray jsonArray = jsonObject.getJSONArray(attributeKey[1]);
            for (int i = 0; i < jsonArray.length(); i++) {
                listOfAttributes.add(jsonArray.getString(i));
            }
            for (int i = 0; i < listOfAttributes.size(); i++) {
                commonMethods.waitForElementExplicitly(2000);
                $(By.xpath(attLocator + "//option[contains(text(),'" + listOfAttributes.get(i) + "')]")).doubleClick();
            }

        }

    }

    /**
     * Function to select Reason for Issue
     */
    public void selectReasonForIssue() {
        commonMethods.waitForElement(driver, reasonForIssue);
        if ($(reasonForIssueFirstOption).isDisplayed())
            $(reasonForIssue).selectOption(2);
    }


    /**
     * Function to select Reason for Issue
     */
    public void selectReasonForIssue(String option) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, reasonForIssue, 10);
        $(reasonForIssue).selectOptionContainingText(option);
    }

    /**
     * CLick on First Mail
     */
    public void clickOnFirstMail() {
        verifyAndSwitchFrame();
        addColumnIfNotPresent("Subject", "mail");
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, mailSubject, 80);
        commonMethods.waitForElementClickable(driver, mailSubject, 15);
        $(mailSubject).click();
        driver.switchTo().defaultContent();
    }

    /**
     * Function to click on mail Send button
     *
     * @return
     */
    public String sendMail() {
        clickSendBtn();
        $(loadingIcon).should(disappear);
        if ($(sendMailAsConf).isDisplayed()) {
            $(sendMailAsConf).click();
        }
        commonMethods.waitForElementExplicitly(4000);
        commonMethods.waitForElement(driver, mailNumberField, 90);
//        try {
//
//        } catch (TimeoutException e) {
//            try {
//                for (int i = 0; i < 2; i++) {
//                    if ($(mailNumberField).isDisplayed()) {
//                        break;
//                    } else {
//                        commonMethods.waitForElement(driver, mailNumberField, 30);
//                    }
//                }
//            } catch (TimeoutException e1) {
//                throw new TimeoutException(e1);
//            }
//        }
        mailNumber = $(mailNumberField).getText();
        driver.switchTo().defaultContent();
        return mailNumber;

    }

    /**
     * Function  to send mail with options for
     * 1.
     * 2.
     *
     * @param option
     */
    public String sendMail(String option) {
        clickSendBtn();
        commonMethods.waitForElementExplicitly(4000);
        By optionElement = By.xpath("//div[text()='" + option + "']");
        if ($(optionElement).isDisplayed()) {
            commonMethods.waitForElement(driver, optionElement);
            $(optionElement).click();
        }
        $(loadingIcon).should(disappear);
        commonMethods.waitForElement(driver, mailNumberField, 60);
        mailNumber = $(mailNumberField).getText();
        driver.switchTo().defaultContent();
        return mailNumber;
    }

    /**
     * Function  to click Send button from view mail
     */
    public void clickSendViewMail() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, viewMailSendBtn, 45);
        $(viewMailSendBtn).click();
        commonMethods.waitForElementExplicitly(1000);
    }

    /**
     * Function  to send mail from View Mail
     */
    public String sendFromViewMail() {
        clickSendViewMail();
        $(loadingIcon).should(disappear);
        commonMethods.waitForElement(driver, mailNumberField, 60);
        return $(mailNumberField).getText();
    }

    /**
     * Function to Validate select group
     *
     * @param option
     * @return
     */
    public boolean validateSelectedGroup(String option, boolean unreadOption) {
        verifyAndSwitchFrame();
        sleep(2000);
        By groupOptionChkBox = By.xpath("//span[text()='" + option + "']//././..//input");
        if (unreadOption == false) {
            if ((!$(myMailOnlyChkBox).isSelected()) && (!$(groupOptionChkBox).isSelected())) {
                return false;
            }
        } else {
            if ((!$(myMailOnlyChkBox).isSelected()) && (!$(groupOptionChkBox).isSelected()) && (!$(myUnreadChkbox).isSelected())) {
                return false;
            }
        }
        return true;
    }

    /**
     * Function to click on Mail Group
     *
     * @param option
     */
    public void clickMailGroup(String option) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(4000);
        By groupOptionChkBox = By.xpath("//span[text()='" + option + "']//././..//input");
        if (!$(myMailOnlyChkBox).isSelected()) {
            $(myMailOnlyChkBox).click();
        }
        $(groupOptionChkBox).click();
        driver.switchTo().defaultContent();
    }

    /**
     * Function to uncheck my mail only checkbox
     */
    public void unCheckMyMailOnly() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(4000);
        if ($(myMailOnlyChkBox).isSelected()) {
            $(myMailOnlyChkBox).click();
        }
        driver.switchTo().defaultContent();
    }

    /**
     * Function to validate Search results by selecting Recipient Type
     *
     * @group1 refers to Recipient Type
     * @mailNumber is the mailNum for which results should be verified
     */
    public void searchValidateWithGroupOption(String userId, String group1, int rowNumber, String mailNumber) {
        clickMailGroup(group1);
        searchMailNumber(mailNumber);
        driver = WebDriverRunner.getWebDriver();
        commonMethods.waitForElement(driver, resultTable);
        Map<Integer, Map<String, String>> tableData = returnMailTableData(driver);
        verifyUserPresent(commonMethods.getColumnValue(driver, tableData, rowNumber, "Recipients"));
        clickOnFirstMail();
    }

    /**
     * Function to Export Reports
     *
     * @param reportType
     * @param typeOfExport Example reportType=Export to Excel - Extended Report,Export to Excel - Standard Report,Export to Excel
     *                     typeOfExport=Row per recipient,Row per mail
     */
    public void exportReports(String reportType, String typeOfExport) {
        commonMethods.waitForElement(driver, reportsBtn);
        $(reportsBtn).click();
        if (typeOfExport != null) {
            $(By.xpath("//*[text()='" + reportType + "']")).click();
        }
        selectReportType(typeOfExport);
    }

    /**
     * Function to Select Report Type
     *
     * @param reportType
     */
    public void selectReportType(String reportType) {
        By by = By.xpath("//*[text()='" + reportType + "']");
        commonMethods.waitForElement(driver, by, 40);
        $(by).click();
    }

    /**
     * Function to save created search
     *
     * @param sharingInfo with whom we can share created search
     *                    Sharinginfo is radio button to whom we need to share the created saved search
     */
    public void createSavedSearch(String name, String sharingInfo) {
        if (verifySavedSearchSameUser(name)) {
            deleteSavedSearch(name);
        }
        commonMethods.waitForElementExplicitly(2000);
        verifyAndSwitchFrame();
        $(saveBtn).click();
        $(nameOfSearch).sendKeys(name);
        $(description).sendKeys("This is a " + name + " Saved search");
        $(By.xpath("//span[text()='" + sharingInfo + "']/..//input")).click();
        $(saveOkBtn).click();
    }

    /**
     * Function to save created search with same name
     *
     * @param sharingInfo with whom we can share created search
     *                    Sharinginfo is radio button to whom we need to share the created saved search
     */
    public void createSavedSearchWithSameName(String name, String sharingInfo) {
        verifyAndSwitchFrame();
        $(saveBtn).click();
        $(nameOfSearch).sendKeys(name);
        $(By.xpath("//span[text()='" + sharingInfo + "']/..//input")).click();
        $(saveOkBtn).click();
    }

    /**
     * Function to cancel action
     */
    public void cancelAction() {
        verifyAndSwitchFrame();
        $(cancelActionBtn).click();
    }

    /**
     * function to chnage sharing info
     */
    public void selectSharingInfo(String sharingInfo) {
        verifyAndSwitchFrame();
        $(By.xpath("//span[text()='" + sharingInfo + "']/..//input")).click();
        $(saveOkBtn).click();
    }

    /**
     * Function to verify Error Msg A saved search already exists
     */
    public Boolean verifySavedSearchError() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        return $(savedSearchErrorMsg).isDisplayed();
    }

    /**
     * function to select created saved search
     */
    public void selectSavedSearch(String mySavedSearch) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, savedSearchBtn);
        $(savedSearchBtn).click();
        $(By.xpath("//div[@class='filter-list ng-scope']//div[text()='" + mySavedSearch + "']")).click();
    }

    /**
     * Function to verify created saved search
     */
    public Boolean verifySavedSearchSameUser(String mySavedSearch) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, savedSearchBtn, 30);
        $(savedSearchBtn).click();
        By savedSearch = By.xpath("//div[@class='filter-list ng-scope']//div[text()='" + mySavedSearch + "']");
        try {
            commonMethods.waitForElement(driver, savedSearch, 20);
        } catch (TimeoutException e) {
            System.out.println("Element not found Proceeding");
        }
        return $(savedSearch).isDisplayed();
    }

    /**
     * function to verify Created saved from different user
     */
    public Boolean verifySavedSearchDifferentUser(String mySavedSearch) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, savedSearchBtn, 20);
        $(savedSearchBtn).click();
        return $(By.xpath("//div[@class='filter-list ng-scope']//ul//li//*[text()='" + mySavedSearch + "']")).isDisplayed();
    }

    /**
     * Function to verify created search not prsent
     */
    public Boolean verifySavedSearchNotVisibleForSameUser(String mySavedSearch) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, savedSearchBtn, 20);
        $(savedSearchBtn).click();
        if (!$(By.xpath("//div[@class='filter-list ng-scope']//div[text()='" + mySavedSearch + "']")).isDisplayed()) {
            return true;
        }
        return false;
    }

    /**
     * Function to verify created saved search from different user for not present
     */
    public Boolean verifySavedSearchNotVisibleForDiffUser(String mySavedSearch) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, savedSearchBtn, 20);
        $(savedSearchBtn).click();
        if (!$(By.xpath("//div[@class='filter-list ng-scope']//ul//li//span[text()='" + mySavedSearch + "']")).isDisplayed()) {
            return true;
        }
        return false;
    }

    /**
     * Function to Edit saved My searches
     *
     * @param mySavedSearch
     * @param sharingInfo
     */
    public void editSavedSearch(String mySavedSearch, String newSearchName, String sharingInfo) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, savedSearchBtn, 20);
        $(savedSearchBtn).click();
        By savedSearch = By.xpath("//div[text()='" + mySavedSearch + "']/..//i[@title='Manage Saved Searches']");
        commonMethods.waitForElement(driver, savedSearch, 20);
        $(savedSearch).click();
        if (newSearchName != null) {
            commonMethods.waitForElement(driver, nameOfSearch);
            $(nameOfSearch).clear();
            $(nameOfSearch).sendKeys(newSearchName);
        }
        if (sharingInfo != null) {
            By sharingInfoLocator = By.xpath("//span[text()='" + sharingInfo + "']/..//input");
            commonMethods.waitForElement(driver, sharingInfoLocator, 20);
            $(sharingInfoLocator).click();
        }
        commonMethods.waitForElement(driver, saveOkBtn);
        $(saveOkBtn).click();
    }

    /**
     * Function to Delete saved My searches
     *
     * @param savedSearchName
     */
    public void deleteSavedSearch(String savedSearchName) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, savedSearchBtn, 30);
        $(savedSearchBtn).click();
        if ($(By.xpath("//div[text()='" + savedSearchName + "']/..//i[@title='Manage Saved Searches']")).isDisplayed()) {
            $(By.xpath("//div[text()='" + savedSearchName + "']/..//i[@title='Manage Saved Searches']")).click();
            commonMethods.waitForElement(driver, deleteSavedSearchBtn);
            $(deleteSavedSearchBtn).click();
            commonMethods.waitForElement(driver, confirmDeleteBtn, 20);
            $(confirmDeleteBtn).click();
        }
    }

    /**
     * Function to Add Filter in Advanced search
     *
     * @param filterName Name of the filter
     */
    public void addFilterAdvancedSearch(String filterName) {
        verifyAndSwitchFrame();
        $(advancedSearchBtn).click();
        Boolean exist = verifyAddedFilter(filterName);
        if (!exist) {
            $(selectFilter).selectOption(filterName);
        }
    }

    /**
     * Function to Remove added filter in Advanced search
     */
    public void removeFilterAdvancedSearch(String filterName) {
        verifyAndSwitchFrame();
        $(advancedSearchBtn).click();
    }


    /**
     * Function to verify Added Filter for Advanced search
     *
     * @param filterName
     * @return
     */
    public Boolean verifyAddedFilter(String filterName) {
        commonMethods.waitForElement(driver, addedFilters, 20);
        List<WebElement> filters = driver.findElements(addedFilters);
        for (int i = 0; i <= filters.size() - 1; i++) {
            if (filters.get(i).getText().equalsIgnoreCase(filterName)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Function to Remove Filter from Advanced search
     *
     * @param filterName
     * @return
     */
    public Boolean verifyRemovedFilter(String filterName) {
        commonMethods.waitForElement(driver, addedFilters, 20);
        List<WebElement> filters = driver.findElements((addedFilters));
        for (int i = 0; i <= filters.size() - 1; i++) {
            if (!filters.get(i).getText().equalsIgnoreCase(filterName)) {
                return true;
            }

        }
        return false;
    }


    /**
     * Function To Remove Added Filter in Advanced search
     *
     * @param filterName
     */
    public void removeFilter(String filterName) {
        By filterNameLocator = By.xpath("//div[text()='" + filterName + "']//../..//span[@class='auiIcon trash']");
        commonMethods.waitForElement(driver, filterNameLocator, 20);
        $(filterNameLocator).click();
    }

    /**
     * @param type
     * @return
     */
    public Boolean verifyMailType(String type) {
        Boolean textPresent = false;
        commonMethods.waitForElementExplicitly(2000);
        List<WebElement> types = driver.findElements(By.xpath("//div[text()='Type']//..//../../../..//span[text()='" + type + "']"));
        for (int i = 0; i <= types.size() - 1; i++) {
            String transType = types.get(i).getText();
            if (transType.equalsIgnoreCase(type)) {
                textPresent = true;
            }

        }
        return textPresent;
    }

    /**
     * Function to verify Recipient in mail search page
     *
     * @param Recipient
     * @return
     */
    public Boolean verifyMailRecipients(String Recipient) {
        By recipientLocator = By.xpath("//div[text()='Recipients']//..//../../../..//tr[1]//td//span[text()='" + Recipient + "']");
        commonMethods.waitForElement(driver, recipientLocator, 20);
        String recipientsText = $(recipientLocator).getText();
        if (recipientsText.equalsIgnoreCase(Recipient)) {
            return true;
        }
        return false;
    }

    /**
     * Function to verify filter Mail types after Advanced search
     *
     * @param data
     * @return
     */
    public Boolean verifyFilteredMailTypes(String data) {
        Boolean present = false;
        Map<String, String> table = dataStore.getTable(data);
        for (String key : table.keySet()) {
            String[] namesList = table.get(key).split(",");
            for (String name : namesList) {
                present = verifyMailType(name);
                if (!present) {
                    return false;
                }

            }
        }
        return present;
    }

    /**
     * Function to return the table contents
     *
     * @param driver
     * @return
     */
    public Map<Integer, Map<String, String>> returnMailTableData(WebDriver driver) {
        try {
            commonMethods.waitForElement(driver, resultTable, 20);
        } catch (TimeoutException e) {
            clickSearch();
        }
        try {
            commonMethods.waitForElement(driver, resultTableRow, 20);
        } catch (TimeoutException e) {
            clickSearch();
        }
        return commonMethods.convertUITableToHashMap(driver, resultTable, resultTableRow);
    }

    /**
     * verify Unread Mail
     *
     * @return
     */
    public boolean unreadMailPresent() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, unreadMail, 18);
        return $(unreadMail).isDisplayed();
    }

    /**
     * Function to return unread Message
     *
     * @return
     */
    public String returnUnreadMsg() {
        String successMsg = $(markedAsUnreadMsg).getText();
        driver.switchTo().defaultContent();
        return successMsg;
    }

    public void markAsUnread() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, actionOnTopBtn, 15);
        $(actionOnTopBtn).click();
        commonMethods.waitForElementExplicitly(2000);
        $(markAsUnread).click();
    }

    /**
     * Function to click on send button
     */
    public void clickSendBtn() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, sendBtn, 30);
        $(sendBtn).click();
    }


    /**
     * Function to click on Advanced search
     */
    public void clickAdvanceSearch() {
        verifyAndSwitchFrame();
        $(advancedSearchBtn).click();
    }

    /**
     * Method to return the mail number from the UI
     *
     * @return
     */
    public String returnMailNumber() {
        verifyAndSwitchFrame();
        Map<Integer, Map<String, String>> tableData = returnMailTableData(driver);
        return commonMethods.getColumnValue(driver, tableData, 0, "Mail No");
    }

    public String returnColumnValue(int rownumber, String columnName) {
        verifyAndSwitchFrame();
        Map<Integer, Map<String, String>> tableData = returnMailTableData(driver);
        return commonMethods.getColumnValue(driver, tableData, rownumber, columnName);
    }

    /**
     * Function to select first mail
     */
    public void clickOnFirstMailChkbox() {
        try {
            commonMethods.waitForElement(driver, firstMailChkBox, 30);
        } catch (TimeoutException e) {
            clickSearch();
        }
        try {
            commonMethods.waitForElement(driver, firstMailChkBox, 30);
        } catch (TimeoutException e) {
            clickSearch();
        }
        $(firstMailChkBox).setSelected(true);
    }


    /**
     * Function to navigate page on search result table
     */
    public void navigateToPage(int pageNumber) {
        verifyAndSwitchFrame();
        By pageLink = By.xpath("//div[@id='searchResultsWrapper']//a[contains(text(),'" + pageNumber + "')]");
        try {
            commonMethods.waitForElement(driver, firstMailPageLink, 20);
        } catch (TimeoutException e) {
            clickSearch();
            navigateToPage(pageNumber);
        }
        try {
            $(pageLink).click();
        } catch (NoSuchElementException e) {
            System.out.println("Page Not Available to Navigate");
        }
    }


    public void searchColumn(String searchText) {
        driver.switchTo().defaultContent();
        verifyAndSwitchFrame();
        $(filterSearch).clear();
        $(filterSearch).sendKeys(searchText);
    }

    /**
     * Function to get selected columns on mail search page
     *
     * @return list of selected columns
     */
    public List<String> returnSelectedColumns() {
        driver.switchTo().defaultContent();
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, selectedColumnsSelect, 60);
        List<String> selectColumnsText = new LinkedList<>();
        Select select = new Select($(selectedColumnsSelect));
        for (WebElement element : select.getOptions()) {
            selectColumnsText.add(element.getText());
        }
        return selectColumnsText;
    }

    /**
     * Function to reset columns selected
     */

    public void resetColumns(String page) {
        verifyAndSwitchFrame();
        $(addRemoveColumnBtn).click();
        $(resetBtn).click();
        $(okBtn).click();
    }

    /**
     * Function to add columns on mail search page
     *
     * @param columns as list of columns to be added
     */
    public void addColumns(List<String> columns) {
        driver.switchTo().defaultContent();
        verifyAndSwitchFrame();
        for (String column : columns) {
            By xpath = By.xpath(availableOptions + "//option[@title='" + column + "']");
            commonMethods.waitForElement(driver, filterSearch, 60);
            if (!$(By.xpath(selectedOption + "//option[@title='" + column + "']")).exists()) {
                $(filterSearch).clear();
                $(filterSearch).sendKeys(column);
                commonMethods.waitForElement(driver, xpath, 30);
                commonMethods.waitForElementExplicitly(500);
                $(xpath).click();
                $(xpath).doubleClick();
                commonMethods.waitForElementExplicitly(1000);
            }
        }
    }

    /**
     * Function to remove columns on mail search page
     *
     * @param columns as list of columns to be removed
     */
    public void removeColumns(List<String> columns) {
        driver.switchTo().defaultContent();
        verifyAndSwitchFrame();
        for (String column : columns) {
            if ($(By.xpath(selectedOption + "//option[@title='" + column + "']")).exists()) {
                $(By.xpath(selectedOption + "//option[@title='" + column + "']")).click();
            }
        }
        $(removeColumn).click();
    }

    public String[] getOrderOfSelectedColumns() {
        driver.switchTo().defaultContent();
        verifyAndSwitchFrame();
        String[] order = $(selectedColumns).text().split("\\r?\\n");
        $(okBtn).click();
        return order;
    }

    public String[] getOrderOfColumnsOnPage() {
        driver.switchTo().defaultContent();
        verifyAndSwitchFrame();
        return $(tableHeader).text().split("\\r?\\n");
    }

    public String getValueAttributeColumn(String column) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(1000);
        $(By.xpath("//div[contains(text(),'" + column + "')]//..//div[2]")).click();
        return $(By.xpath("//div[@class='selectize-dropdown multi ng-scope']")).text();
    }

    /**
     * verifying the Values present in dropdown
     *
     * @columnName is the column from where values has to be selected
     * @listOfAttributes is the list which has to be verified
     */
    public boolean verifyAttributeValuesInDropdown(String columnName, List<String> listOfAttributes) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        addColumnIfNotPresent(columnName, "mail");
        List<String> attributesInDropdown = commonMethods.getDropdownValues(driver, columnName);
        if (attributesInDropdown.containsAll(listOfAttributes)) {
            return true;
        }
        return false;
    }

    /**
     * Selecting the values from dropdown
     *
     * @numOfValues is number of values to select in dropdown
     * @column is the column from where values to be selected
     * @listOfAttributes is the values which has to be selected from dropdown
     */

    public List<String> selectDropdownValues(String numOfValues, String column, List<String> listOfAttributes) {
        int number = Integer.parseInt(numOfValues);
        List<String> list = new LinkedList<String>();
        for (int i = 0; i < number; i++) {
            list.add(listOfAttributes.get(i));
        }
        searchDropDownFilter(column, list);
        for (int i = 0; i < number; i++) {
            Assert.assertTrue(checkAttributePresent(listOfAttributes.get(i)));
        }
        return list;
    }

    public void selectDropdownValues(String column, List<String> value) {
        verifyAndSwitchFrame();
        searchDropDownFilter(column, value);
    }

    /**
     * Verify scrollbar in dropdown
     *
     * @column is the column which has dropdown
     */

    public boolean verifyScrollbarInDropdownValues(String columnName) {
        $(By.xpath("//div[contains(text(),'" + columnName + "')]//..//div[2]")).click();
        return commonMethods.verifyScrollbar(driver, $(scrollBarInAttributeDropdown));
    }

    /**
     * Clicking on Search and verifying the search results after selecting the values from dropdown
     *
     * @numOfValues is number of values to select in dropdown
     * @column is the column from where values to be selected
     * @listOfAttributes is the values which has to be verified in search results
     */

    public void verifySearchResults(String column, List<String> listOfAttributes) {
        verifyAndSwitchFrame();
        $(searchBtn).click();
        commonMethods.waitForElementExplicitly(2000);
        List<WebElement> columnValue = getColumnSearchResult(column);
        for (String attribute : listOfAttributes) {
            for (WebElement result : columnValue) {
                Assert.assertTrue((result.getText().contains(attribute)));
            }
        }
    }

    /**
     * Function to get all the available options/columns present to select on mail search page
     *
     * @return available option present
     */

    public String getAvailableOptions() {
        driver.switchTo().defaultContent();
        verifyAndSwitchFrame();
        return $(By.xpath(availableOptions)).text();
    }

    /**
     * Function verify all the elements present on add/remove column popup on mail search page
     */
    public void verifyElementOnAddRemoveColumnPopUp() {
        driver.switchTo().defaultContent();
        verifyAndSwitchFrame();
        $(availableFilter).exists();
        $(selectedFilter).exists();
        $(saveAsDefault).exists();
        $(okBtn).exists();
        $(cancelBtn).exists();
        $(resetBtn).exists();
        $(filterSearch).exists();
        $(addColumn).exists();
        $(removeColumn).exists();
    }

    public void clickCancelBtn() {
        commonMethods.waitForElement(driver, cancelBtn, 30);
        $(cancelBtn).click();
    }

    public void setSaveAsDefault() {
        commonMethods.waitForElement(driver, saveAsDefault, 15);
        $(saveAsDefault).click();
    }

    public void clickOk() {
        commonMethods.waitForElement(driver, okBtn, 35);
        $(okBtn).click();
    }


    /**
     * Function to restore columns on mail search page
     *
     * @param columns list of column to be restored
     */
    public void restoreColumns(List<String> columns) {
        driver.switchTo().defaultContent();
        verifyAndSwitchFrame();
        String[] columnLength = $(selectedColumns).text().split("\\r?\\n");
        for (String i : columnLength) {
            $(By.xpath("//div[@class='manual-sort']//option[1]")).click();
            $(removeColumn).click();
        }
        addColumns(columns);
    }


    /**
     * Function to select recipient group while composing or editing mail
     *
     * @param group to be selected
     */
    public void selectRecipientGroup(String group) {
        verifyAndSwitchFrame();
        $(By.xpath("//label[@class='auiField-radio ng-scope']//span[@class='ng-binding'][contains(text(),'" + group + "')]")).click();
    }

    /**
     * Function to verify recipient group is available in the edit form
     */
    public void verifyRecipientGroup(String group) {
        verifyAndSwitchFrame();
        Assert.assertTrue($(recipientSection).text().contains(group));
    }

    /**
     * Function to get table header values
     *
     * @return table head values as string array
     */
    public List<String> getTableHeadValues() {
        List<String> headers = new ArrayList<>();
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, tableHead, 20);
        List<WebElement> webElements = new ArrayList<>($$(tableHead));
        for (WebElement tblHeader : webElements) {
            headers.add(tblHeader.getAttribute("innerText").split("\n")[0]);
        }
        return headers;
    }


    /**
     * checking whether the value selected from dropdown is present in pill area
     *
     * @attributeList is the value selected from dropdown
     */

    public boolean checkAttributePresent(String attributeList) {
        commonMethods.waitForElementExplicitly(3000);
        List<WebElement> attrName = driver.findElements(By.xpath("//div[@class='pills ng-scope']//span[contains(text(),'" + attributeList + "')]"));
        if (!attrName.isEmpty()) {
            return true;
        } else {
            return false;
        }

    }

    /**
     * Function to verify no mails present
     *
     * @return boolean
     */

    public boolean searchResult() {
        return $(noResult).exists();
    }


    /**
     * Function to click tools button
     */
    public void clickTools() {
        $(toolsBtn).click();
    }


    /**
     * Function to close out mails
     *
     * @param numberOfMail number of mails to be close out on page
     * @return mailNumbers which are closed out as list
     */
    public List<String> closeOutMail(int numberOfMail) {
        mailNumbers.clear();
        verifyAndSwitchFrame();
        if (numberOfMail > 0) {
            for (int i = 1; i <= numberOfMail; i++) {
                WebElement page = $(By.xpath("//div[@id='searchResultsWrapper']//a[contains(text(),'" + i + "')]"));
                if (page.isDisplayed()) {
                    page.click();
                    commonMethods.waitForElementExplicitly(1000);
                    $(By.xpath("//table[@id='resultTable']//tbody//tr[" + i + "]//td[1]//input")).click();
                    mailNumbers.add($(By.xpath("//table[@id='resultTable']//tbody//tr[" + i + "]//td[@class='column_documentNo']//span")).text());
                }
            }
            clickTools();
            $(markAsCloseOutOption).click();
            commonMethods.waitForElement(driver, markAsCloseOutBtnPopUp, 15);
            $(markAsCloseOutBtnPopUp).click();
        } else {
            clickTools();
            $(markAsCloseOutOption).click();
        }
        return mailNumbers;
    }


    /**
     * Function to close out mail
     *
     * @param mailNumber to be closed out
     */
    public void closeOutMail(String mailNumber) {
        verifyAndSwitchFrame();
        searchMailNumber(mailNumber);
        $(selectFirstMail).click();
        clickTools();
        $(markAsCloseOutOption).click();
        $(markAsCloseOutBtnPopUp).click();
    }

    /**
     * Method to close out multiple mails
     *
     * @param mailNumbers
     */
    public void closeOutMail(List<String> mailNumbers) {
        Map<String, Map<String, Object>> mapOfMap = dataSetup.loadJsonDataToMap(mailFilePath);
        for (int i = 0; i <= mailNumbers.size() - 1; i++) {
            Map<String, Object> map1 = mapOfMap.get(mailNumbers.get(i));
            String mailNum1 = map1.get("mail_num").toString();
            closeOutMail(mailNum1);
        }
    }

    /**
     * Function to get closed out success message
     */
    public String returnClosedOutSuccessMsg() {
        verifyAndSwitchFrame();
        return $(closeOutSuccessMessage).text();
    }

    /**
     * Function to get the text from alter window
     */
    public String alertWindowMessage() {
        return switchTo().alert().getText();
    }


    /**
     * Function to click search button on mail search page
     */
    public void clickSearch() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, searchBtn, 30);
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", $(searchBtn));
        hitEnter();
        commonMethods.waitForElement(driver, searchBtn);
        $(searchBtn).click();
        $(mailNoTextBox).sendKeys(Keys.ENTER);
        Actions actionProvider = new Actions(driver);
        actionProvider.clickAndHold($(searchBtn)).build().perform();
        sleep(1500);
        actionProvider.release($(searchBtn)).build().perform();
        actionProvider.click($(searchBtn)).build().perform();
    }


    public void clickSearchButton() {
        verifyAndSwitchFrame();
        $(searchBtn).click();
    }


    /**
     * Function to verify selected rows from search result table
     *
     * @param rows as list of rows to be verified
     */
    public void verifySelectedRow(List<String> rows) {
        verifyAndSwitchFrame();
        for (String row : rows) {
            By mailSelect = By.xpath("//table[@id='resultTable']//tr[td[@class= 'column_documentNo'] and contains(.,'" + row + "')]//td[1]//input");
            commonMethods.waitForElement(driver, mailSelect, 10);
            Assert.assertTrue($(mailSelect).isSelected());
        }
    }


    /**
     * Function to select mail
     *
     * @param mailNumber
     */
    public void clickOnFirstMail(String mailNumber) {
        $(loadingIcon).should(disappear);
        searchMailNumber(mailNumber);
        addColumnIfNotPresent("Subject", "mail");
        try {
            commonMethods.waitForElement(driver, mailSubject, 10);
        } catch (TimeoutException e) {
            clickSearch();
        }
        searchMailNumber(mailNumber);
        addColumnIfNotPresent("Subject", "mail");
        try {
            commonMethods.waitForElement(driver, mailSubject, 10);
        } catch (TimeoutException e) {
            clickSearch();
        }
        $(mailSubject).click();
    }

    public void clickOnMailFromTable(String mailNumber) {
        $(loadingIcon).should(disappear);
        clickSearch();
        By subject = By.xpath("//table[@id='resultTable']//tbody//tr//td[@class='column_documentNo' and contains(.,'" + mailNumber + "')]//following-sibling::td//a");
        addColumnIfNotPresent("Subject", "mail");
        try {
            commonMethods.waitForElement(driver, subject, 10);
        } catch (TimeoutException e) {
            clickSearch();
        }
        addColumnIfNotPresent("Subject", "mail");
        try {
            commonMethods.waitForElement(driver, subject, 10);
        } catch (TimeoutException e) {
            clickSearch();
        }
        $(subject).click();
    }


    /**
     * Function to get search result of column searched
     *
     * @param columnName
     * @return list of search result
     */
    public List<WebElement> getColumnSearchResult(String columnName) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, firstRecord, 60);
        addColumnIfNotPresent(columnName, "mail");
        List<String> a = getTableHeadValues();
        int columnIndex = a.indexOf(columnName) + 1;
        clickSearch();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, firstRecord, 60);
        int tableSize = driver.findElements(resultTableRow).size();
        List<WebElement> listOfColumns = new ArrayList<>();
        for (int i = 1; i <= tableSize; i++) {
            commonMethods.waitForElementExplicitly(500);
            WebElement element = driver.findElement(By.xpath("//table[@id='resultTable']//tbody[contains(@id,'rowPer')]//tr[" + i + "]//td[" + columnIndex + "]"));
            listOfColumns.add(element);
        }
        return listOfColumns;
    }

    public void getRowPerColumn(String option) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, showOneRowPerDropdown, 30);
        $(showOneRowPerDropdown).selectOptionContainingText(option);
    }


    /**
     * Function to select text based search filter on mail search page
     *
     * @param value      as text to be searched
     * @param columnName
     */
    public void searchTextBasedFilter(String value, String columnName) {
        verifyAndSwitchFrame();
        addColumnIfNotPresent(columnName, "mail");
        $(By.xpath("//div[contains(text(),'" + columnName + "')]//..//input")).clear();
        $(By.xpath("//div[contains(text(),'" + columnName + "')]//..//input")).sendKeys(value);
        $(searchFilter).sendKeys(Keys.ENTER);
    }


    /**
     * Function to select dropdown filter on mail search page
     *
     * @param columnName
     * @param options    as list of values to be selected
     */
    public void searchDropDownFilter(String columnName, List<String> options) {
        verifyAndSwitchFrame();
        addColumnIfNotPresent(columnName, "mail");
        if (columnName.equals("Confidential")) {
            for (String option : options) {
                $(By.xpath("//div[contains(text(),'" + columnName + "')]//..//select")).selectOptionContainingText(option);
            }
        } else {
            $(By.xpath("//div[contains(text(),'" + columnName + "')]//..//div[2]")).click();
            for (String option : options) {
                commonMethods.enterTextValue(By.xpath("//div[contains(text(),'" + columnName + "')]//..//div[2]//input"), option);
                $(By.xpath("//div[@class='selectize-dropdown-content ng-scope']//div[contains(text(),'" + option + "')]")).click();
            }

        }
        commonMethods.waitForElementExplicitly(1000);
        $(searchFilter).sendKeys(Keys.ENTER);
    }

    /**
     * Function to select dropdown filter on mail search page
     *
     * @param columnName
     * @param option     as list of values to be selected
     */
    public void searchDropDownFilter(String columnName, String option) {
        verifyAndSwitchFrame();
        addColumnIfNotPresent(columnName, "mail");
        $(By.xpath("//div[contains(text(),'" + columnName + "')]//..//select")).selectOptionContainingText(option);
        commonMethods.waitForElementExplicitly(1000);
        $(searchFilter).sendKeys(Keys.ENTER);
    }

    /**
     * Function to select date filter without date values (Ex: tomorrow, today, last 7 days etc)
     *
     * @param filter date option
     */
    public void selectDateFilter(String filter) {
        verifyAndSwitchFrame();
        $(By.xpath("//div[contains(text(),'Date')]//..//div[2]")).click();
        $(By.xpath("//div[@class='dropdown-menu']//li[contains(text(),'" + filter + "')]")).click();
        commonMethods.waitForElementExplicitly(1000);
        $(mailNoTextBox).click();
        commonMethods.waitForElementExplicitly(2000);
        $(searchBtn).click();
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Function to select date filter without date values (Ex: tomorrow, today, last 7 days etc)
     */
    public void selectDateFilter(String colName, String filter) {
        verifyAndSwitchFrame();
        $(By.xpath("//div[contains(text(),'" + colName + "')]//..//div[2]//input")).click();
        $(By.xpath("//div[text()='" + colName + "']/..//div[@class='dropdown-menu']//li[contains(text(),'" + filter + "')]")).click();
        commonMethods.waitForElementExplicitly(1000);
        $(mailNoTextBox).click();
        commonMethods.waitForElementExplicitly(2000);
        $(searchBtn).click();
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Function to select date filter for between, on, before, after date ranges
     *
     * @param filter date option
     * @param value1 from date
     * @param value2 to date
     */
    public void selectDateFilter(String filter, String value1, String value2) {
        verifyAndSwitchFrame();
        $(By.xpath("//div[contains(text(),'Date')]//..//div[2]//input")).click();
        $(By.xpath("//div[@class='dropdown-menu']//li[contains(text(),'" + filter + "')]")).click();
        selectFromDate(value1);
        if (filter.equalsIgnoreCase("between"))
            selectToDate(value2);
        $(mailNoTextBox).click();
        commonMethods.waitForElementExplicitly(2000);
        $(searchBtn).click();
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Function to get option on date column
     *
     * @return options present in the date filter column
     */
    public String getDateFilterOptions() {
        verifyAndSwitchFrame();
        $(dateColumn).click();
        return $(dateColumnFilter).text();
    }


    /**
     * Function to verify title of the date column when filter is selected
     *
     * @param from as string from date
     * @param to   as string to date
     */
    public void verifyBetweenDateTitle(String from, String to) {
        verifyAndSwitchFrame();
        String locator = "//div[contains(text(),'Date')]//..//div[2]//input[@title='Between ";
        $(By.xpath(locator + from + " and " + to + "']")).exists();
        Assert.assertTrue($(By.xpath(locator + from + " and " + to + "']")).exists());
    }

    /**
     * Function to search attached mail in mail
     *
     * @param mail_number mail number to be searched
     */
    public void searchAttachedMail(String mail_number) {
        switchToMailAttachPanel();
        commonMethods.waitForElement(driver, mailNoTextBox, 40);
        $(mailNoTextBox).clear();
        $(mailNoTextBox).sendKeys(mail_number);
        commonMethods.waitForElement(driver, searchBtn, 20);
        commonMethods.waitForElementExplicitly(3000);
        $(searchBtn).click();
        $(loadingIcon).should(disappear);
        commonMethods.waitForElement(driver, selectFirstMail, 40);
        $(selectFirstMail).click();
    }

    /**
     * Function verify column header present
     */
    public Boolean verifyColumnHeader(String columnName) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(3000);
        List<String> columnHeader = getTableHeadValues();
        if (columnHeader.contains(columnName)) {
            return true;
        }

        return false;
    }

    /**
     * Function to verify report options
     *
     * @param reportValues
     * @return
     */
    public Boolean verifyReportOptions(List<String> reportValues) {
        ArrayList reportOptionsText = new ArrayList();
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, reportsBtn, 20);
        $(reportsBtn).click();
        sleep(1000);
        List<WebElement> options = driver.findElements(reportsOptions);
        for (WebElement e : options) {
            String optionsText = e.getText();
            reportOptionsText.add(optionsText);
        }
        return reportValues.equals(reportOptionsText);
    }

    /**
     * Function to verify  Advanced serach column fields
     *
     * @param data
     * @return
     */

    public Boolean verifyAdvancedSearchColumnFields(List<String> data) {
        ArrayList filtersText = new ArrayList();
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        List<WebElement> filters = driver.findElements(addedFilters);
        for (int i = 0; i < filters.size(); i++) {
            String filterText = filters.get(i).getText();
            filtersText.add(filterText);
        }
        return data.equals(filtersText);
    }

    /**
     * Function to verify Add Filter is Displayed
     *
     * @return
     */
    public Boolean verifyAddFilterIsDisplayed() {
        clickAdvanceSearch();
        commonMethods.waitForElement(driver, selectFilter, 20);
        return $(selectFilter).isDisplayed();
    }

    /**
     * Function to verify nature of column in Advanced search
     * Need to be look and re work
     *
     * @param header
     * @return
     */
    public Boolean verifyNatureOfColumn(List<String> header, Boolean draft) {
        WebElement element;
        int count = 0;
        for (int i = 0; i <= header.size() - 1; i++) {
            if (header.get(i).equals("Type") || header.get(i).equals("Status") || header.get(i).equals("Attribute 1") || header.get(i).equals("Attribute 2") || header.get(i).equals("Attribute 3") || header.get(i).equals("Attribute 4")) {
                commonMethods.waitForElementExplicitly(2000);
                driver.findElement(By.xpath("//div[text()='" + header.get(i) + "']//..//..//div[contains(@class,'selectize-input items')]")).isDisplayed();
                count++;
            } else if (header.get(i).equals("Recipients")) {
                driver.findElement(By.xpath("//div[text()='" + header.get(i) + "']//..//..//input")).isDisplayed();
                count++;
            } else if (header.get(i).equalsIgnoreCase("Date")) {
                driver.findElement(By.xpath("//div[text()='" + header.get(i) + "']//..//..//div[@class='input-group-addon icon icon-calendar']")).isDisplayed();
                count++;
            }
        }
        if (draft) {
            return count == 7;
        } else {
            return count == 8;
        }
    }

    public void clickOnVeiwSend() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, viewSendBtn, 13);
        $(viewSendBtn).click();
    }

    /**
     * checking whether the mail is Highlighted after viewing
     */
    public boolean verifyHighlightedMail() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, highlightedRow, 30);
        return $(highlightedRow).isDisplayed();
    }

    /**
     * checking whether blank mail open after clicking New mail
     */
    public boolean openNewBlankMail() {
        verifyAndSwitchFrame();
        $(newMailBtn).click();
        return verifyPageTitle("New Mail");
    }

    /**
     * checking whether unread mails are displayed after clicking radio button My Unread
     */

    public boolean verifyUnreadMails() {
        verifyAndSwitchFrame();
        if ($(myMailOnlyChkBox).isSelected()) {
            $(myMailOnlyChkBox).click();
        }
        $(myUnreadChkbox).click();
        $(searchBtn).click();
        List<WebElement> noOfRows = getColumnSearchResult("Mail No");
        for (int i = 1; i < noOfRows.size(); i++) {
            if (!($(unreadMails).isDisplayed())) {
                return false;
            }

        }
        return true;
    }

    /**
     * function to check vie my mails check box
     */

    public void selectMyMails() {
        commonMethods.waitForElement(driver, myMailOnlyChkBox, 80);
        $(myMailOnlyChkBox).setSelected(true);
    }


    /**
     * this method will return the table result size based on option selected
     *
     * @option is the Row option selected
     */
    public Integer returnTableSizeOnOptionSelected(String option) {
        verifyAndSwitchFrame();
        if ($(myMailOnlyChkBox).isSelected()) {
            $(myMailOnlyChkBox).click();
        }
        commonMethods.waitForElement(driver, showOneRowPerDropdown, 10);
        $(showOneRowPerDropdown).selectOptionContainingText(option);
        clickSearch();
        try {
            commonMethods.waitForElement(driver, showOneRowPerDropdown, 10);
            Assert.assertTrue($(showOneRowPerDropdown).getSelectedText().equalsIgnoreCase(option));
        } catch (AssertionError e) {
            $(showOneRowPerDropdown).selectOptionContainingText(option);
            clickSearch();
        }
        commonMethods.waitForElementExplicitly(2000);
        Map<Integer, Map<String, String>> tableData = returnMailTableData(driver);
        int size = tableData.size();
        return size;

    }

    /**
     * Verify whether selecting of an Row option in Mails is available
     *
     * @columnName is the column name which has to be selected
     * @option is the row option that is selected
     */

    public boolean verifyRowOptionUnavailable(String option, String columnName) {
        By columnNameInsideAlert = By.xpath("//div[@class='auiModal-body']//ul/li[contains(text(),'" + columnName + "')]");
        verifyAndSwitchFrame();
        if ($(myMailOnlyChkBox).isSelected()) {
            $(myMailOnlyChkBox).click();
        }
        commonMethods.waitForElement(driver, showOneRowPerDropdown, 20);
        $(showOneRowPerDropdown).selectOptionContainingText(option);
        String expected = "Row per Mail is unavailable in this column configuration";
        if (($(rowPerMailAlertMsg).getText().equalsIgnoreCase(expected)) &&
                ($(columnNameInsideAlert).getText().equalsIgnoreCase(columnName))) {
            return true;
        }
        return false;
    }


    public boolean verifyDeletedMail(String mailNumber) {
        verifyAndSwitchFrame();
        searchMailNumber(mailNumber);
        clickSearch();
        commonMethods.waitForElement(driver, noMatchingResults, 20);
        if ($(noMatchingResults).getText().equalsIgnoreCase("No matching results found.")) {
            return true;
        }
        return false;

    }

    /**
     * Verify whether column results are in ascending order or descending order
     *
     * @columnName is the column name for which results has to be verified
     */
    public boolean verifyMailSorting(String columnName) {
        verifyAndSwitchFrame();
        if (columnName.equalsIgnoreCase("status"))
            $(By.xpath("//div[text() = '" + columnName + "']")).click();
        else $(By.xpath("//div[contains(text(),'" + columnName + "')]")).click();
        List<WebElement> ascValue = getColumnSearchResult(columnName);
        List<String> allAscValues = new ArrayList<>();
        for (WebElement webElement : ascValue) allAscValues.add(webElement.getText());
        if (columnName.equalsIgnoreCase("status"))
            $(By.xpath("//div[text() = '" + columnName + "']")).click();
        else $(By.xpath("//div[contains(text(),'" + columnName + "')]")).click();
        List<WebElement> descValue = getColumnSearchResult(columnName);
        List<String> allDescValues = new ArrayList<>();
        for (WebElement webElement : descValue) allDescValues.add(webElement.getText());
        return !allAscValues.equals(allDescValues);
    }

    /**
     * Function to submit print request
     *
     * @param document document number for which print request is to be submitted
     */
    public void submitPrintRequest(String document) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, By.xpath("//table[@class='auiTable']//tbody//tr[td//text()[contains(., '" + document + "')]]/td[1]/input"), 10);
        $(By.xpath("//table[@class='auiTable']//tbody//tr[td//text()[contains(., '" + document + "')]]/td[1]/input")).click();
        $(actionMailBodyBtn).click();
        commonMethods.waitForElementExplicitly(1000);
        $(printRequestBtn).click();
    }

    public void verifyPrintRequestPage() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, printRequestPageTitle, 30);
        Assert.assertTrue($(printRequestPageTitle).text().contains("Print Request"));
    }


    public void clickOnClearAllFilter() {
        verifyAndSwitchFrame();
        $(clearAllFilter).click();
        driver.switchTo().defaultContent();
    }


    /**
     * Function to mark mail as read
     */
    public void markAsRead() {
        $(toolsBtn).click();
        $(markAsRead).click();
    }

    /**
     * Function to verify ail details in inbox mail
     *
     * @param data as attribute
     */
    public void verifyMailDetails(String data) {
        Map<String, String> table = dataStore.getTable(data);
        //According to the keys passed in the table, we select the fields
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, mailNumberHeader, 60);
        for (String tableData : table.keySet()) {
            switch (tableData) {
                case "Mail Type":
                    if (!table.get((tableData)).equals("default")) {
                        Assert.assertTrue("Mail type is not matched", $(mailType).text().contains(table.get(tableData)));
                    }
                    break;
                case "Subject":
                    if (table.get(tableData).contains("unique".toLowerCase())) {
                        String[] subjectarray = table.get(tableData).split(",");
                        String subjectLine = commonMethods.getMailNumFromJson(subjectarray[1]);
                        if ($(subject).isDisplayed())
                            Assert.assertTrue("Mail Subject is not matched", $(subject).getText().toLowerCase().contains(subjectLine.toLowerCase()));
                    } else {
                        Assert.assertTrue("Mail Subject is not matched", $(subject).getText().contains(table.get(tableData)));
                    }
                    break;
                case "Attachment":
                    getElementInView(documentNumber);
                    Assert.assertTrue("Mail Attached Document Number is not matched", $(documentNumber).getText().contains(table.get(tableData)));
                    break;
                case "No Attachment":
                    Assert.assertFalse("Attachments are present in mail", $(documentNumber).getText().contains(table.get(tableData)));
                    break;
                case "Message":
                    Assert.assertTrue("Message is not matched", getMailMessage().contains(table.get(tableData)));
                    break;
                case "Status":
                    Assert.assertTrue("Mail Status is not matched", $(mailStatus).text().contains(table.get(tableData)));
                    break;
                case "File Name":
                    getElementInView(documentAttachment);
                    Assert.assertTrue("File Name is not matched", $(documentAttachment).getText().contains(commonMethods.returnDocNumberInJson(table.get(tableData))));
                    break;
                case "Attribute":
                    getElementInView(attribute);
                    Assert.assertTrue("Attribute name is not matched", $(attribute).getText().contains(table.get(tableData)));
                    break;
                case "Reason For Issue":
                    getElementInView(reasonForIssueViewMail);
                    Assert.assertTrue("Reason for issue is not matched", $(reasonForIssueViewMail).text().contains(table.get(tableData)));
                    break;
                case "From":
                case "To":
                case "Cc":
                case "Bcc":
                    Assert.assertTrue("Recipient names is not matched", verifyRecipientGroup(tableData, table.get(tableData)));
                    break;
                case "Workflow Initiated":
                    Assert.assertTrue("Workflow Initiated is not matched", verifyWFInitiated(table.get(tableData)));
                    break;
                case "Workflow Note":
                    Assert.assertTrue("Workflow Note is not matched", verifyWFNote(table.get(tableData)));
                    break;
                default:
                    if(tableData.startsWith("label_"))
                        Assert.assertTrue("Project fields are not matched", verifyProjectFields(tableData, table.get(tableData)));
            }
        }
    }

    /**
     * Function to return mail body text from preview
     */
    public void verifyAttachment(String type, String mailAttachment) {
        switch (type) {

            case "Project Mail": {
                mailAttachment = returnMailNumber(mailAttachment);
                commonMethods.waitForElement(driver, mailAttachmentsText, 20);
                Assert.assertTrue($(By.xpath("//div[@class='mailAttachedMails ng-scope']//td[contains(text(),'" + mailAttachment + "')]")).isDisplayed());
                $(projectMailAttachmentIcon).click();
                commonMethods.waitForElementExplicitly(3000);
                Set<String> winHan = driver.getWindowHandles();
                for (String window : winHan) {
                    driver.switchTo().window(window);
                    if (driver.getCurrentUrl().contains("attachedMailParentId")) {
                        commonMethods.waitForElement(driver, By.xpath("(//div[contains(text(),'" + mailAttachment + "')])[1]"));
                    }
                }
                break;
            }
            case "Local File": {
                commonMethods.waitForElement(driver, fileAttachmentsText);
                Assert.assertEquals($(fileNameOnAttachment).getText(), mailAttachment);
                break;
            }
        }
    }

    /**
     * Function to return mail body text from preview
     */
    public String getMailMessage() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, messageBody, 60);
        return $(messageBody).text();
    }

    /**
     * Function to navigate to different mail pages
     *
     * @param pageName it takes page name
     */

    public void clickPage(String pageName) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        $(By.xpath("//a[text()='" + pageName + "']")).click();
    }

    /**
     * Function to select row display on mail search page
     *
     * @param page it takes page name
     * @return boolean whether page is selected or not
     */
    public Boolean verifyPageIsSelected(String page) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(3000);
        return $(By.xpath("//ul[@id='pageTabs']//li[@class='active']//a")).getText().equals(page);
    }

    /**
     * Function to clear search on mail page
     */
    public void clearAll() {
        verifyAndSwitchFrame();
        commonMethods.scrollToTop(driver);
        commonMethods.waitForElement(driver, clearAllLink, 15);
        $(clearAllLink).click();
        Actions actions = new Actions(driver);
        actions.click($(clearAllLink)).build().perform();
    }

    /**
     * Function to get text message after clearing search result
     *
     * @return message for cleared result
     */
    public String getResultClearText() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, clearAllMsg, 30);
        return $(clearAllMsg).text();
    }

    /**
     * Function to search mail with random text to get zero result
     *
     * @return message for zero result
     */
    public String emptySearch() {
        verifyAndSwitchFrame();
        Faker faker = new Faker();
        String searchQuery = faker.book().title() + faker.address().cityPrefix();
        searchMailNumber(searchQuery);
        return $(zeroResultMessage).text();
    }

    /**
     * Function to search mail with multiple columns
     *
     * @param searchAttribute as searchAttribute from data table
     */
    public void multipleColumnSearch(String searchAttribute) {
        verifyAndSwitchFrame();
        Map<String, String> table = dataStore.getTable(searchAttribute);
        for (String tableData : table.keySet()) {
            switch (tableData) {
                case "From":
                case "Mail No":
                case "Recipients":
                case "Subject":
                    searchTextBasedFilter(table.get(tableData), tableData);
                    break;
                case "Date":
                    selectDateFilter(table.get(tableData));
                    break;
                case "Status":
                case "Type":
                    String[] attributes = table.get(tableData).split(",");
                    List<String> attList = Arrays.asList(attributes);
                    searchDropDownFilter(tableData, attList);
                    break;
            }
        }
        clickSearch();
    }


    /**
     * Function to select rows from search result table
     *
     * @param rows as list of rows
     * @return
     */
    public List<String> selectMailRow(List<Integer> rows) {
        List<String> selectedMailNumber = new ArrayList<String>();
        for (int row : rows) {
            sleep(1000);
            By mailSelect = By.xpath("//table[@id='resultTable']//tr[" + row + "]//td[1]//input");
            if ($(mailSelect).exists()) {
                $(mailSelect).setSelected(true);
                selectedMailNumber.add($(By.xpath("//table[@id='resultTable']//tr[" + row + "]//td[@class= 'column_documentNo']//span")).text());
            }
        }
        return selectedMailNumber;
    }


    /**
     * Function to verify mail row is present
     *
     * @param mailNumber mail Number to be verified
     */
    public void verifyMail(String mailNumber) {
        searchMailNumber(mailNumber);
        addColumnIfNotPresent("Mail No", "mail");
        try {
            commonMethods.waitForElement(driver, firstMailNumber, 10);
        } catch (TimeoutException e) {
            clickSearch();
        }
        searchMailNumber(mailNumber);
        addColumnIfNotPresent("Mail No", "mail");
        try {
            commonMethods.waitForElement(driver, firstMailNumber, 10);
        } catch (TimeoutException e) {
            clickSearch();
        }
        try {
            Assert.assertTrue($(firstMailNumber).text().contains(mailNumber));
        } catch (AssertionError e) {
            clickSearch();
            commonMethods.waitForElement(driver, firstMailNumber, 10);
            Assert.assertTrue($(firstMailNumber).text().contains(mailNumber));
        }
    }

    /**
     * Function to verify error Message panel
     */

    public Boolean verifyErrorMsg() {
        commonMethods.waitForElement(driver, errorMsg, 40);
        return $(errorMsg).isDisplayed();
    }

    /**
     * Function to click register incoming mail from action dropdown
     */

    public void registerIncomingReply() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, actionOnTopBtn);
        $(actionOnTopBtn).click();
        $(registerIncomingReply).click();
    }


    /**
     * Function to mark mail as read
     */

    public void markMailAsRead(String mailNumber) {
        verifyAndSwitchFrame();
        searchMailNumber(mailNumber);
        $(firstMailChkBox).click();
        markAsRead();
    }


    /**
     * Function to get mail reference number
     *
     * @return reference number
     */

    public String getReferenceNumber() {
        verifyAndSwitchFrame();
        return $(referenceNumber).text();
    }

    /**
     * Function to select unread mail checkbox
     */

    public void viewUnreadMail() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, viewUnreadMail, 15);
        if (!$(viewUnreadMail).isSelected()) {
            $(viewUnreadMail).click();
        }
    }

    /**
     * Function to select a value for response required field
     *
     * @value is the value from the dropdown to be selected
     */

    public void selectResponseRequired(String value) {
        String values[] = value.split(",");
        commonMethods.waitForElement(driver, responseRequiredDropdown, 13);
        $(responseRequiredDropdown).selectOptionContainingText(values[0]);
        String futureDate = commonMethods.getDate(configFileReader.getTimeZone(), values[1]);
        commonMethods.waitForElementExplicitly(1000);
        $(responseRequiredDate).sendKeys(futureDate);
    }

    /**
     * Function to uncheck My Mail Only Checkbox
     */

    public void deselectMyMailOnly() {
        verifyAndSwitchFrame();
        $(myMailOnlyChkBox).setSelected(false);
    }


    public void resetSearchForm() {
        verifyAndSwitchFrame();
        if ($(myMailOnlyChkBox).isSelected()) {
            $(myMailOnlyChkBox).click();
        }
        if ($(myUnreadChkBox).isSelected()) {
            $(myUnreadChkBox).click();
        }
        $(anyMail).click();
    }


    /**
     * Function to verify there are zero result for mail search
     */

    public void verifyEmptyResult() {
        $(loadingIcon).should(disappear);
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, noMatchingResults, 20);
        String text = $(noMatchingResults).getText();
        Assert.assertTrue(text.equalsIgnoreCase("No matching results found."));
    }


    /**
     * Function to select row display on mail search page
     *
     * @param option to select mails or recipients
     */

    public void selectMailRowDisplayOption(String option) {
        verifyAndSwitchFrame();
        $(selectRowDisplayOption).selectOptionContainingText(option);
    }


    /**
     * Function to get text for pop up when column in not supported for the selected option
     *
     * @return error message
     */

    public String getColumnNotSupportedError() {
        verifyAndSwitchFrame();
        return $(rowPerPopUp).text();
    }

    /*
     * Function to select saved search form Standard searches
     */
    public void selectStandardSearch(String searchName) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, savedSearchBtn);
        $(savedSearchBtn).click();
        $(By.xpath("//div[@class='filter-list ng-scope']//ul//li//span[text()='" + searchName + "']")).doubleClick();
    }

    /**
     * Function to click on view send Button
     */
    public void clickViewSend() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, draftSendBtn, 30);
        $(draftSendBtn).click();
    }

    /**
     * Function to press enter on page
     */
    public void hitEnter() {
        $(searchFilter).sendKeys(Keys.ENTER);
    }


    /**
     * Function to add from compose mail page when user is in same project
     */
    public void sendTo(String user) {
        verifyAndSwitchFrame();
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userFilePath);
        userMap = jsonMapOfMap.get(user);
        $(toField).sendKeys(userMap.get("full_name").toString());
        $(toField).sendKeys(Keys.ENTER);
    }


    /**
     * Function to add column if not present
     *
     * @param columnName is the column name which has to be added
     */

    public List<String> addColumnIfNotPresent(String columnName, String error) {
        MailPage mailPage = new MailPage();
        List<String> columnHeader = returnColumnHeaders(driver);
        if (!columnHeader.contains(columnName)) {
            clickAddRemoveColumns();
            mailPage.addColumns(Collections.singletonList(columnName));
            mailPage.clickOk();
        }
        commonMethods.waitForElementExplicitly(2000);
        if (error.equalsIgnoreCase("unavailable")) {
            if ($(addColumnError).exists()) {
                Assert.assertTrue($(addColumnErrorMsg).text().toLowerCase().
                        contains("Remove these columns if you wish to view this result in Row per Mail mode".toLowerCase()));
                return null;
            }
        }
        commonMethods.waitForElementExplicitly(2000);
        columnHeader = returnColumnHeaders(driver);
        if (!columnHeader.contains(columnName)) {
            addColumnIfNotPresent(columnName, "page");
        }
        return columnHeader;
    }

    public List<String> addColumnIfNotPresent(String columnName) {
        MailPage mailPage = new MailPage();
        List<String> columnHeader = returnColumnHeaders(driver);
        if (!columnHeader.contains(columnName)) {
            clickAddRemoveColumns();
            mailPage.addColumns(Collections.singletonList(columnName));
            mailPage.clickOk();
        }
        commonMethods.waitForElementExplicitly(2000);
        columnHeader = returnColumnHeaders(driver);
        if (!columnHeader.contains(columnName)) {
            addColumnIfNotPresent(columnName, "page");
        }
        return columnHeader;
    }

    /**
     * Function to remove column present
     *
     * @param columnName is the column name which has to be added
     */
    public void removeColumn(String columnName, String page) {
        MailPage mailPage = new MailPage();
        commonMethods.waitForElementExplicitly(5000);
        mailPage.resetColumns(page);
        List<String> columnHeader = returnColumnHeaders(driver);
        if (columnHeader.contains(columnName)) {
            verifyAndSwitchFrame();
            clickAddRemoveColumns();
            mailPage.removeColumns(Collections.singletonList(columnName));
            mailPage.clickOk();
        }
    }


    /**
     * Method to return all the headers values of the column in the table
     *
     * @param driver
     * @return
     */
    public List<String> returnColumnHeaders(WebDriver driver) {

        //We click on the add/remove columns button. Fetch all the selected columns
        clickAddRemoveColumns();
        List<String> list = returnSelectedColumns();
        list.add(0, "");
        //Load it into a list and click on cancel button.
        // A empty value is added in the start because an empty value is present in the start of the results
        clickCancelBtn();
        return list;
    }

    /**
     * Method to click on Add Remove columns button
     */

    public void clickAddRemoveColumns() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, addOrRemoveBtn, 40);
        if ($(addRemovePanel).isDisplayed()) {
            $(getAddRemovePanelClose).click();
        }
        verifyAndSwitchFrame();
        commonMethods.waitForPageLoad(driver);
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, addOrRemoveBtn, 40);
        $(addOrRemoveBtn).click();
    }

    /**
     * Method to return the Mail number from the json file
     *
     * @param mailNo
     * @return
     */
    public String returnMailNumber(String mailNo) {
        String mailDataPath = configFileReader.getMailDataPath();
        Map<String, Map<String, Object>> mapOfMap = dataSetup.loadJsonDataToMap(mailDataPath);
        Map<String, Object> map = mapOfMap.get(mailNo);
        return map.get("mail_num").toString();
    }


    /**
     * Method to verify close out option is present under tools
     *
     * @return boolean flag
     */
    public Boolean verifyCloseoutOption() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, toolsBtn, 5);
        $(toolsBtn).click();
        return $(closeOutLink).exists();

    }

    /**
     * Method to select mail recipient type in mail search filter
     *
     * @param type recipient type
     */
    public void selectRecipientTypeMailSearch(String type) {
        verifyAndSwitchFrame();
        String typeLocator = "//div[@class='ng-isolate-scope']//label[1]//input[1]";
        switch (type.toLowerCase()) {
            case "to":
                $(By.xpath(typeLocator + "2]//input[1]")).setSelected(true);
                break;
            case "cc":
                $(By.xpath(typeLocator + "3]//input[1]")).setSelected(true);
                break;
            case "any":
                $(By.xpath(typeLocator + "1]//input[1]")).setSelected(true);
                break;
        }

    }

    /**
     * Function to return total mails present
     *
     * @return count of mail
     */
    public int getTotalCountMailPage() {
        verifyAndSwitchFrame();
        String count = $(mailCount).text();
        return Integer.parseInt(count.substring(count.lastIndexOf(" ") + 1));
    }

    /**
     * Function to click on panel Attach button
     */
    public void clickPanelAttachBtn() {
        switchTo().defaultContent();
        verifyAndSwitchFrame();
        $(onPanelAttachBtn).click();
    }

    /**
     * Method to select Response required
     *
     * @param value
     * @param day
     */
    public void selectResponseRequired(String value, int day) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, responseRequiredDropdown, 60);
        $(responseRequiredDropdown).selectOptionContainingText(value);
        String date = commonMethods.getDate(configFileReader.getTimeZone(), day);
        $(responseRequiredDate).sendKeys(date);
    }


    /**
     * Method to verify document attached in mail
     *
     * @param docNo
     * @return
     */

    public boolean verifyDocumentAttached(String docNo) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(5000);
        getElementInView(fileAttachments);
        return $(By.xpath("//td[@class='mailAttachedFiles-filename']//a[contains(.,'" + docNo + "')]")).isDisplayed();
    }

    /**
     * Method to check select my unread checkbox
     */
    public void selectMyUnread() {
        verifyAndSwitchFrame();
        $(myUnreadChkbox).setSelected(true);
    }

    /**
     * Method to check select to as mail recipient
     */
    public void searchRecipientGroupTo() {
        verifyAndSwitchFrame();
        $(toRecipient).click();
    }

    /**
     * Function to verify sent and To Users
     *
     * @param userName
     * @return
     */
    public boolean verifyUsers(String userName) {
        verifyAndSwitchFrame();
        sleep(2000);
        return $(By.xpath("//label[contains(text(),'" + userName + "')]")).isDisplayed();
    }

    /**
     * Function to verify Mail subject
     *
     * @param subject
     * @return
     */
    public boolean verifySubject(String subject) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, subjectMail, 20);
        return $(subjectMail).getValue().contains(subject);
    }

    /**
     * Method to verify Mail Attachment
     *
     * @param name
     * @param mailType
     * @return
     */
    public void verifyMailAttachment(String name, String mailType, String mailNum) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        if (name != null) {
            if (mailType.equalsIgnoreCase("Transmittal")) {
                String fileName = documentPage.returnDocumentNumber(name);
                Assert.assertTrue($(By.xpath("//table[@class='dataTable']//td//div[contains(text(),'" + fileName + "')]")).isDisplayed());
            } else {
                Assert.assertTrue($(By.xpath("//table[@class='dataTable']//td[text()='" + name + "']")).isDisplayed());
            }
        }
        if (mailNum != null) {
            Assert.assertTrue($(By.xpath("//table[@class='dataTable']//td[contains(text(),'" + mailNum + "')]")).isDisplayed());
        }
    }

    /**
     * method to verify reply Button
     *
     * @return
     */
    public boolean verifyReplyBtn() {
        verifyAndSwitchFrame();
        return $(replyBtn).isDisplayed();
    }

    /**
     * verify forward Button
     *
     * @return
     */
    public boolean verifyForwardBtn() {
        verifyAndSwitchFrame();
        return $(forwardBtn).isDisplayed();
    }

    /**
     * CLick on options Button
     */
    public void clickOptions() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, optionsBtn, 5);
        $(optionsBtn).click();
    }

    /**
     * Method to enter manual mail number
     *
     * @param newMailNum
     */
    public void selectManualMailNumber(String newMailNum) {
        verifyAndSwitchFrame();
        clickOptions();
        $(ownMailNumber).click();
        $(mailNumberTxtBox).sendKeys(newMailNum);
        $(optionsOkBtn).click();
    }

    /**
     * click on Register Doc
     */
    public void clickRegisterDoc() {
        verifyAndSwitchFrame();
        $(docRegister).click();
    }

    /**
     * Function to click on Mail module
     */
    public void clickMailModule(String module) {
        $(By.xpath("//button[@class='uiButton navBarButton']//div[text()='" + module + "']")).click();
    }


    /**
     * checking whether blank mail is present
     */
    public boolean verifyBlankMail(String option) {
        verifyAndSwitchFrame();
        return $(By.xpath("//div[@class='navBarPanel-menuItem' and text()='" + option + "' ]")).isDisplayed();
    }

    /**
     * Function to Attach a Project Mail
     */
    public void attachProjectMail() {
        verifyAndSwitchFrame();
        verifyAndSwitchFrame("attachOnNewPanel_iframe");
        commonMethods.waitForElement(driver, selectFirstMail, 60);
        $(selectFirstMail).click();
        switchToOriginal();
        verifyAndSwitchFrame();
        clickPanelAttachBtn();
    }

    /**
     * Function to Attach a Project Mail
     *
     * @param mailNum
     */
    public void attachProjectMail(String mailNum) {
        verifyAndSwitchFrame();
        verifyAndSwitchFrame("attachOnNewPanel_iframe");
        commonMethods.waitForElement(driver, selectFirstMail, 45);
        $(selectFirstMail).click();
        commonMethods.setMailNumInJson(mailNum, getMailNumber());
        driver.switchTo().defaultContent();
        verifyAndSwitchFrame();
        clickPanelAttachBtn();
    }

    /**
     * Function to Attach a Local File
     *
     * @param fileName
     */
    public void attachLocalFile(String fileName) {
        File file = new File(filePath + fileName);
        verifyAndSwitchFrame("attachFiles-frame");
        $(localFileUploadBtn).sendKeys(file.getAbsolutePath());
        switchToOriginal();
        verifyAndSwitchFrame();
        $(localFileAttachBtn).click();
        commonMethods.waitForElementExplicitly(3000);
        $(localFileCloseBtn).click();
    }

    /**
     * Function to Attach multiple Mails
     *
     * @param type
     * @param noOfMails
     */
    public void attachMultipleMails(String type, int noOfMails) {
        $(mailNoTextBox).clear();
        $(mailNoTextBox).sendKeys(type);
        $(searchBtn).click();
        commonMethods.waitForElementExplicitly(5000);
        commonMethods.waitForElement(driver, tableRows);

        int count = 1;
        while (count <= noOfMails) {
            By element = By.xpath("//table[@class='auiTable']//tbody//tr[" + count + "]//td[1]//input");
            $(element).click();
            count++;
        }
        $(toolsBtn).click();
        $(linkToPackages).click();
    }


    /**
     * click on Create Forward
     */
    public void clickCreateForward() {
        verifyAndSwitchFrame();
        $(createForward).click();

    }

    /**
     * Function to verify mail footer txt
     *
     * @param footer
     * @return
     */
    public boolean verifyMailFooter(String footer) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, mailFooter, 25);
        getElementInView(mailFooter);
        return commonMethods.getTextFromInputField(driver,mailFooter).contains(footer);
    }

    /**
     * function to verify all mails listed are confidential
     */
    public void verifyMailAsConfidential() {
        verifyAndSwitchFrame();
        int n = searchResultCount();
        for (int i = 1; i <= n; i++) {
            Assert.assertTrue($(By.xpath("//table[@id='resultTable']//tbody//tr[" + i + "]//td[1]//span[@class='confidentialIcon']")).isDisplayed());
            Assert.assertTrue($(By.xpath("//table[@id='resultTable']//tbody//tr[" + i + "]")).getAttribute("class").contains("confidential ng-scope"));
        }
    }

    /**
     * function to verify recipient
     *
     * @param user
     */
    public boolean verifyRecipient(String user) {
        commonMethods.waitForElementExplicitly(3000);
        verifyAndSwitchFrame();
        int n = searchResultCount();
        boolean flag = false;
        for (int i = 1; i <= n; i++) {
            if ($(By.xpath("//table[@id='resultTable']//tbody//tr[" + i + "]")).text().contains(user)) {
                flag = true;
            } else {
                flag = false;
                break;
            }
        }
        return flag;
    }

    /**
     * Method to get The Mail Count
     *
     * @return
     */

    public String getMailCount() {
        commonMethods.waitForElement(driver, inboxAttachCount, 45);
        return $(inboxAttachCount).getText();

    }

    /**
     * Function to verify mailsubject txt
     *
     * @param txt
     */
    public void verifyMailSubjectTxt(String txt) {
        commonMethods.waitForElement(driver, mailSubjectTxt, 40);
        $(mailSubjectTxt).getText().contains(txt);
    }

    /*
     * Method to verify the project label
     * @param label
     * @return
     */
    public boolean verifyProjectLabel(String label) {
        By element = By.xpath("//div[@id='detailsSection']//label[contains(text(),'" + label + "')]");
        getElementInView(element);
        return $(element).isDisplayed();
    }

    public void setElement(String name, boolean value) {
        switchToMailAttachPanel();
        By by = By.xpath("//span[text()='" + name + "']//..//input");
        commonMethods.waitForElement(driver, by);
        $(by).setSelected(value);
    }

    /**
     * Function to select multiple values from multi select field
     *
     * @param value
     */
    public void selectMultiSelectValues(By element, String value) {
        commonMethods.waitForElementClickable(driver, element, 60);
        $(element).click();
        String[] attributeKey = value.split(",");
        By btnOk = By.xpath("//span[contains(text(),'" + commonMethods.getLabelName(attributeKey[0]) + "')]/../following-sibling::div//button[@title='OK']");
        commonMethods.waitForElement(driver, btnOk, 10);
        for (int i = 1; i < attributeKey.length; i++) {
            if (attributeKey[i].contains("user")) attributeKey[i] = commonMethods.getUserData(attributeKey[i], "name");
            commonMethods.waitForElementExplicitly(3000);
            $(By.xpath(multiSelectLocator + "//option[contains(text(),'" + attributeKey[i] + "')]")).doubleClick();
        }
        $(btnOk).click();
        commonMethods.waitForElementExplicitly(3000);
    }

    /**
     * Function to verify To, CC, BCC user names
     *
     * @param data
     */
    public boolean verifyRecipientGroup(String key, String data) {
        String xpath;
        verifyAndSwitchFrame();
        if (key.equalsIgnoreCase("from"))
            xpath = "//div[contains(text(),'" + key + "')]/parent::div//../div[@class='auiDetails-value']";
        else
            xpath = "//div[@class='auiDetails-label']//span[text()='" + key + "']/parent::div//../div[@class='auiDetails-value']";
        $(loadingIcon).should(disappear);
        commonMethods.waitForElement(driver, mailNumberHeader, 60);
        expandMoreLinks();
        String[] values = data.split(",");
        for (String value : values) {
            if (value.contains("user"))
                return ($(By.xpath(xpath + "//span[contains(text(),'" + commonMethods.getUserData(value, "name") + "')]")).isDisplayed());
            else
                return ($(By.xpath(xpath + "//span[contains(text(),'" + value + "')]")).isDisplayed());
        }
        return false;
    }

    /**
     * Function to verify Send Mail error
     */
    public void assertSendMailError() {
        $(loadingIcon).should(disappear);
        commonMethods.waitForElementExplicitly(5000);
        Assert.assertTrue($(lblNoRecipient).isDisplayed());
        Assert.assertTrue($(btnReload).isDisplayed());
        $(btnReload).click();
        commonMethods.waitForElementExplicitly(2000);
        $(loadingIcon).should(disappear);
    }

    /**
     * Function to remove multi select field and user field values
     *
     * @param element
     */
    public void removeMultiSltValues(By element) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, element, 20);
        $(element).click();
        commonMethods.waitForElement(driver, By.xpath(multiSelectLocator), 10);
        List<WebElement> elements = new ArrayList<>($$(By.xpath(multiSelectSelector)));
        for (int i = 0; i < elements.size(); i++) {
            $(By.xpath(multiSelectSelector + "[" + 1 + "]")).doubleClick();
            commonMethods.waitForElementExplicitly(1000);
        }
        $(btnOK).click();
        commonMethods.waitForElementExplicitly(3000);
    }

    public void setSelectFirstMail() {
        commonMethods.waitForElement(driver, firstMailInputCheckBox, 30);
        $(firstMailInputCheckBox).setSelected(true);
    }

    /**
     * Function to verify mail modified error
     */
    public boolean verifyMailModified() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        return $(hdrReloadError).isDisplayed();
    }

    /**
     * Function to click on reload
     */
    public void clickReload() {
        $(btnReload).click();
    }

    /**
     * Function to click on More link in preview screen for To, Cc and Bcc
     */
    public void expandMoreLinks() {
        List<WebElement> moreLinks = new ArrayList<>($$(By.xpath(lnkMore)));
        for (int i = 1; i <= moreLinks.size(); i++)
            $(By.xpath("(" + lnkMore + ")[1]")).click();
    }

    /**
     * Function to click Back and Next pagination arrows
     */
    public void clickOnPagination(String option) {
        verifyAndSwitchFrame();
        if (option.equalsIgnoreCase("next")) $(lnkPageNext).click();
        else if (option.equalsIgnoreCase("previous")) $(lnkPagePrevious).click();
    }

    /**
     * Function to verify default sort column in mails tab
     */
    public boolean verifyDefaultSort(String column) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, firstMailNumber, 60);
        return $(By.xpath("//div[text()='" + column + "']/../../div")).getAttribute("class").contains("sortDESC");
    }

    /**
     * Function to click on enabled from date value
     */
    public void selectFromDate(String value) {
        if (value.substring(0, 1).contains("0")) value = value.substring(1);
        List<WebElement> elements = new ArrayList<>($$(By.xpath("//ul[@selected-option='displayedOption.date1']//span[contains(@class,'ng-binding')][./text()='" + value + "']")));
        for (WebElement element : elements) {
            if (!element.getAttribute("class").contains("auiText-muted")) {
                element.click();
                break;
            }
        }
    }

    /**
     * Function to click on enabled to date value
     */
    public void selectToDate(String value) {
        if (value.substring(0, 1).contains("0")) value = value.substring(1);
        List<WebElement> elements = new ArrayList<>($$(By.xpath("//ul[@selected-option='displayedOption.date2']//span[contains(@class,'ng-binding')][./text()='" + value + "']")));
        for (WebElement element : elements) {
            if (!element.getAttribute("class").contains("auiText-muted")) {
                element.click();
                break;
            }
        }
    }

    /**
     * Function to close Advance search tab
     */
    public void closeAdvanceSearch() {
        verifyAndSwitchFrame();
        $(closeBtn).click();
    }

    /**
     * Function to Add Filters in Advanced search
     */
    public void addFilterAdvancedSearch(List<String> filterName) {
        verifyAndSwitchFrame();
        $(advancedSearchBtn).click();
        for (String filter : filterName) {
            Boolean exist = verifyAddedFilter(filter);
            if (!exist) {
                $(selectFilter).selectOption(filter);
            }
        }
    }

    /**
     * Function to select date filter for between, on, before, after date ranges
     *
     * @param filter date option
     * @param value1 from date
     * @param value2 to date
     */
    public void selectDateFilter(String dateField, String filter, String value1, String value2) {
        verifyAndSwitchFrame();
        $(By.xpath("//div[contains(text(),'" + dateField + "')]//..//div[2]//input")).click();
        $(By.xpath("//div[text()='" + dateField + "']/..//div[@class='dropdown-menu']//li[contains(text(),'" + filter + "')]")).click();
        commonMethods.waitForElementExplicitly(500);
        selectFromDate(value1);
        if (filter.equalsIgnoreCase("between"))
            selectToDate(value2);
        $(mailNoTextBox).click();
        commonMethods.waitForElementExplicitly(2000);
        $(searchBtn).click();
        commonMethods.waitForElementExplicitly(2000);
    }


    public void submitDocumentsRequest(String document) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, By.xpath("//table[@class='auiTable']//tbody//tr[td//text()[contains(., '" + document + "')]]/td[1]/input"), 10);
        $(By.xpath("//table[@class='auiTable']//tbody//tr[td//text()[contains(., '" + document + "')]]/td[1]/input")).click();
        $(actionMailBodyBtn).click();
        commonMethods.waitForElementExplicitly(1000);
        $(submitDocumentBtn).click();
    }

    /**
     * Method to verify approve and reject buttons in view mail page
     */
    public boolean verifyApproveRejectButtons() {
        return $(btnApprove).isDisplayed() && $(btnReject).isDisplayed();
    }

    /**
     * Method to approve mail approval request
     */
    public void approveRequest() {
        clickApprove();
        commonMethods.waitForElement(driver, btnPopUpWindowApprove, 10);
        verifyMailApprove();
        $(btnPopUpWindowApprove).click();
        commonMethods.waitForElementExplicitly(5000);
    }

    /**
     * Method to verify mail approve pop up window
     */
    public void verifyMailApprove() {
        Assert.assertTrue($(hdrMailApproval).isDisplayed());
        Assert.assertTrue($(lblConfirmation).isDisplayed());
        Assert.assertTrue($(btnPopUpWindowApprove).isDisplayed());
    }

    /**
     * Method to verify user profilee icon present in search results
     */
    public boolean verifyUserIcon() {
        verifyAndSwitchFrame();
        return $(imgProfileIcon).isDisplayed();
    }

    /**
     * Method to reject mail approval request
     */
    public void rejectRequest(String requestId, String type, String sender) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, btnReject, 10);
        $(btnReject).click();
        mailApprovalsPage.verifyRejectTab(commonMethods.returnFromJson(requestId, "request_num", configFileReader.getMailDataPath()), type, commonMethods.getUserData(sender, "name"));
        $(mailApprovalsPage.txtBoxComments).sendKeys("Mail Rejected");
        $(btnReject).click();
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Function to Attach a Local File
     *
     * @param fileName
     */
    public void attachRestrictLocalFile(String fileName) {
        commonMethods.waitForElement(driver, localFileAttachBtn, 30);
        verifyAndSwitchFrame("attachFiles-frame");
        $(localFileUploadBtn).sendKeys(new File(filePath + "/" + fileName).getAbsolutePath());
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Function to verify workflow initiated message in message section
     */
    public boolean verifyWFInitiated(String value) {
        return $(By.xpath("//div[contains(text(),'The attached documents are part of the \"" + commonMethods.getWFTemplateDetails(value, "template_name") + "\" workflow.')]")).isDisplayed();
    }

    /**
     * Function to verify workflow note in message section
     */
    public boolean verifyWFNote(String value) {
        return $(By.xpath("//div[contains(text(),'" + value + "')]")).isDisplayed();
    }

    /**
     * Function to get workflow table row value in mails message section
     */
    public int getRowNumber(String docName) {
        List<WebElement> elements = new ArrayList<>($$(By.xpath(wfTableRows)));
        for (int i = 3; i <= elements.size(); i++) {
            if ($(By.xpath(wfTableRows + "[" + i + "]/td[1]")).getText().equals(docName))
                return i;
        }
        return 1;
    }

    /**
     * Function to verify workflow details in mails message section
     */
    public String verifyWFOutCome(int rowId, int colId) {
        return $(By.xpath("//table[@class='formTable']//tr[" + rowId + "]/td[" + colId + "]")).getAttribute("innerText");
    }

    /**
     * Function to get the column number
     */
    public int getColNumber(String colName) {
        List<String> headers = commonMethods.getValues(By.xpath(wfTableCols));
        return headers.indexOf(colName) + 1;
    }

    /**
     * Function To Remove Added Filter in Advanced search
     *
     * @param filterName
     */
    public void removeAdditionalFilter(String filterName) {
        By filterNameLocator = By.xpath("//div[text()='" + filterName + "']//../..//span[@class='auiIcon trash']");
        if ($(filterNameLocator).isDisplayed())
            $(filterNameLocator).click();
    }

    /**
     * Function To click on approve button in view mail page
     */
    public void clickApprove() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, btnApprove, 60);
        $(btnApprove).click();
    }

    /**
     * Function To click on reject button in reject popup window
     */
    public void clickReject() {
        commonMethods.waitForElement(driver, mailApprovalsPage.hdrCannotApprove, 60);
        $(btnReject).click();
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Function To click on attach icon
     */
    public boolean attachIcon() {
        return $(attachIcon).isDisplayed();
    }

    /**
     * Method to return the number of rows present
     * when we search for a mail
     *
     * @return
     */
    public int returnRows() {
        commonMethods.waitForElement(driver, rowElements);
        List<WebElement> rows = driver.findElements(rowElements);
        return rows.size();
    }

    /**
     * Method to verify the project label
     */
    public boolean verifyProjectFields(String key, String data) {
        if (key.startsWith("label_")) key = commonMethods.getLabelName(key);
        if (data.equalsIgnoreCase("yesterday") || data.equals("today") || data.equals("tomorrow"))
            data = commonMethods.getDate(configFileReader.getTimeZone(), data);
        else if (data.startsWith("user")) data = commonMethods.getUserName(data);
        return $(By.xpath("//div[text()='" + key + "']/..//div/span[contains(text(),'" + data + "')]")).isDisplayed();
    }

    /**
     * Method to get all available list of column headers from add or remove columns
     */
    public List<String> getAvailableColHeaders() {
        clickAddRemoveColumns();
        return commonMethods.getValues(By.xpath(availableOptions + "//option"));
    }

    /**
     * Function to verify fields in Inbox/Sent/Draft tab
     */
    public void verifyFields(String tab) {
        commonMethods.waitForElement(driver, addRemoveColumnBtn, 60);
        Assert.assertTrue($(addRemoveColumnBtn).isDisplayed());
        if (!tab.equalsIgnoreCase("draft"))
            Assert.assertTrue($(toolsBtn).isDisplayed());
        Assert.assertTrue($(mailCount).isDisplayed());
        Assert.assertTrue($(reportsBtn).isDisplayed());
        Assert.assertTrue($(advancedSearchBtn).isDisplayed());
        Assert.assertTrue($(newMailBtn).isDisplayed());
        if (tab.equalsIgnoreCase("inbox"))
            Assert.assertTrue($(myUnreadChkbox).isDisplayed());
        Assert.assertTrue($(myMailOnlyChkBox).isDisplayed());
        Assert.assertTrue($(anyMail).isDisplayed());
        Assert.assertTrue($(clearAllLink).isDisplayed());
        Assert.assertTrue($(searchBtn).isDisplayed());
    }

    /**
     * Method to select All mails on Results in the same page
     */
    public void selectAllMailsResults() {
        commonMethods.waitForElement(driver, clickSelectedOptions);
        $(clickSelectedOptions).click();
        commonMethods.waitForElement(driver, selectAllSearchResults);
        $(selectAllSearchResults).click();
    }
    /**
     * Function to select mail no as auto-numbering in mail option
     */
    public void clickOnUseAutoNum() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, useAutoNumbering, 5);
        $(useAutoNumbering).click();
        $(optionsOkBtn).click();

    }

    /**
     * checking whether the mail is Highlighted after viewing
     */
    public boolean verifyMailFooter() {
        verifyAndSwitchFrame();
        return $(mailFooter).isDisplayed();
    }

    /**
     * Function to select mail no as auto-numbering in mail option
     */
    public void clickOnAutoNumMailNow() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, useAutoNumbermailNow, 5);
        $(useAutoNumbermailNow).click();
        $(optionsOkBtn).click();

    }
    /**
     * Method to get mail number previw
     *
     * @return mail number
     */
    public String retrieveMailNumberPreview() {
        verifyAndSwitchFrame();
        return  $(mailNumPreview).getText();
    }

    /**
     * Method to unread all mails
     */
    public void unreadAllMails() {
        TaskPage taskPage = new TaskPage();
        int mailLinks = taskPage.getMailsLink();
        while (mailLinks != 0) {
            verifyAndSwitchFrame();
            taskPage.clickOnMailsLinks(1);
            verifyAndSwitchFrame();
            commonMethods.waitForElementExplicitly(3000);
            taskPage.navigateAndVerifyPage();
            mailLinks = taskPage.getMailsLink();
        }
    }
}
