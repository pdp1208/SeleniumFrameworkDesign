package com.oracle.babylon.pages.Admin;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.WebDriverRunner;
import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Selenide.*;

/**
 * Class file to contain all the method related to the Admin Xoogle Search Page
 * Author : susgopal
 */
public class AdminOrg extends Navigator {

    //Initialization the web elements
    private By orgNameField = By.xpath("//input[@name='SRCH_ORG_NAME']");
    private By searchBtn = By.xpath("//div[contains(text(),'Search')]");
    private By configureRoleBtn = By.xpath("//div[contains(text(),'User Role Configuration')]");
    private By orgRadioBtn = By.xpath("//input[@id='Org']");
    private By orgLink = By.xpath("//a[@title='Edit organisation information']");
    private By orgStatus = By.xpath("//select[@name='ORG_STATUS']");
    private By newOrgBtn = By.xpath("//button//div[contains(text(),'New Org')]");
    private By orgName = By.id("ORGANIZATION_NAME");
    private By tradingName = By.id("TRADING_NAME");
    private By divisionInput = By.name("NEW_DIVISION");
    private By addDivisionBtn = By.xpath("//*[@title='Add a new division']");
    private By formInputFields = By.xpath("//form[@name='OrgView']");
    private By addGuestBtn = By.xpath("//div[@class='uiButton-content']//*[contains(text(),'Add Guest')]");
    private By newUserBtn = By.xpath("//div[@class='uiButton-content']//*[contains(text(),'New User')]");
    private By addUserBtn = By.xpath("//div[@class='uiButton-content']//*[contains(text(),'Add User')]");
    private By editOrgLogo = By.xpath("//span[@class='auiIcon edit upload_edit_icon']");
    private By modalLogoHeader = By.xpath("//div[@class='auiModal-header']//h3");
    private By dropZone = By.xpath("//div[@class='dropzone']");
    private By browseComputerBtn = By.xpath("//span[@class='show-text-as-link select-image-btn']");
    private By uploadLogo = By.xpath("//*[@id='cropit-file-input']");
    private By updateLogo = By.xpath("//input[@value='Update']");
    private By cancelLogo = By.xpath("//input[@value='Cancel']");
    private By logoImgUploaded = By.id("orgLogoImg");
    private By deleteLogo = By.xpath("//*[@class='auiModal-footer']//*[@id='btn_deleteOrgLogo']");
    private By defaultZeroLogo = By.id("orgLogoZeroStateContainer");
    private By editOrgDetails = By.xpath("//table[@class='formTable']//input[@type='text']");
    private By txtOrgId = By.xpath("//td/input[@id='ORGANIZATION_NAME']/following::td[@class='contentcell']/label");
    private By imgProjectLogo = By.xpath("//div[@id='projLogoContainer']//img[@src='null']");
    private By orgAbbreviation = By.xpath("//input[@id='ORGANIZATION_CODE']");

    public AdminOrg() {
        this.driver = WebDriverRunner.getWebDriver();
    }

    /**
     * Method to navigate and verify for the title of the page
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Setup", "Organization Details");
        commonMethods.waitForElementExplicitly(3000);
        Assert.assertTrue(verifyPageTitle("Organizations"));
    }


    public void searchOrganisation(String org) {
        verifyAndSwitchFrame();
        $(orgNameField).sendKeys(org);
        $(searchBtn).click();
    }

    public void editOrgSecurity(String org) {
        searchOrganisation(org);
        $(By.xpath("//tr[td//text()[contains(., '" + org + "')]][1]//div[contains(text(),'Security')]")).click();
        $(configureRoleBtn).click();
    }

    /**
     * Method to click on the organization listed
     */
    public void clickOrganization() {
        commonMethods.waitForElementExplicitly(500);
        $(orgLink).click();
    }

    /**
     * Change Org status
     *
     * @param value
     */
    public void changeStatus(String value) {
        commonMethods.waitForElement(driver, orgStatus, 40);
        String capitalizeStr=value.substring(0,1).toUpperCase()+value.substring(1).toLowerCase();
        System.out.println(capitalizeStr);
        commonMethods.enterDropdownValue(orgStatus, capitalizeStr);
        $(pageSaveBtn).click();
        commonMethods.waitForElementExplicitly(5000);
        driver.navigate().refresh();
    }

    /**
     * Method to divisions to the organization.
     *
     * @param divisions array of division names.
     */
    public void addDivisions(String[] divisions) {
        for (String division : divisions) {
            $(divisionInput).waitUntil(Condition.appears, 30000).setValue(division);
            $(addDivisionBtn).click();
        }
    }


    /**
     * Method to click on the new organization link
     */
    public void clickNewOrganization() {
        commonMethods.waitForElement(driver, newOrgBtn);
        $(newOrgBtn).click();
    }

    /**
     * Method to verify whether the field is read-only
     */
    public String verifyOrgNameEditable(String fieldProperty) {
        return $(By.xpath("//input[@name='" + fieldProperty + "']")).getAttribute("readonly");
    }

    /**
     * Method to change the Organization Name
     */
    public void changeOrgName(String newOrgName) {
        commonMethods.waitForElement(driver, orgName);
        $(orgName).clear();
        $(orgName).sendKeys(newOrgName);
        $(tradingName).clear();
        $(tradingName).sendKeys(newOrgName);
        $(pageSaveBtn).click();
    }

    /**
     * Method to verify the read only - Hidden Input Fields
     */
    public void verifyReadOnlyDetails() {
        commonMethods.waitForElement(driver, formInputFields);
        commonMethods.waitForElement(driver, addGuestBtn);
        commonMethods.waitForElement(driver, newUserBtn);
        boolean checkFlag = false;
        for (int iterator = 1; iterator <= $$(By.xpath("//form[@name='OrgView']//input")).size(); iterator++) {
            Assert.assertEquals("hidden", $(By.xpath("(//form[@name='OrgView']//input)[" + iterator + "]")).getAttribute("type"));
            checkFlag = true;
        }
        Assert.assertEquals(true, checkFlag);
    }

    /**
     * Method to verify the edit org details parameters - Size should be of input Text
     */
    public int verifyEditOrgDetails() {
        return  $$(editOrgDetails).size();
    }

    /**
     * Method to click Add User Button
     */
    public void clickAddUser() {
        commonMethods.waitForElement(driver, addUserBtn);
        $(addUserBtn).click();
    }

    /**
     * Method to get the mandatory error message
     */
    public String getMandatoryErrorAlert(String fieldProperty) {
        $(By.xpath("//input[@name='" + fieldProperty + "']")).clear();
        clickSaveButton();
        commonMethods.waitForElementExplicitly(2000);
        return getAlertText();
    }

    /**
     * Method to reset the mandatory field
     */
    public void enterRandomValue(String fieldProperty) {
        $(By.xpath("//input[@name='" + fieldProperty + "']")).sendKeys(faker.file().fileName().substring(0, 6));
    }

    /**
     * Method to edit the org attributes
     */
    public void editOrgAttributes(String data) {
        Map<String, String> table = dataStore.getTable(data);
        for (String tableData : table.keySet()) {
            $(By.xpath("//input[@name='" + tableData + "']")).clear();
            $(By.xpath("//input[@name='" + tableData + "']")).sendKeys(table.get(tableData) + " add");
        }
    }

    /**
     * Method to verify the updated org details
     */
    public void verifyOrgDetails(String data) {
        Map<String, String> table = dataStore.getTable(data);
        for (String tableData : table.keySet())
            Assert.assertEquals(table.get(tableData) + " add", $(By.xpath("//input[@name='" + tableData + "']")).getValue());
    }

    /**
     * Method to Click on ORG Logo
     */
    public void clickEditOrgLogo() {
        commonMethods.waitForElement(driver, editOrgLogo);
        $(editOrgLogo).click();
    }

    /**
     * Method to get the logo Headers
     */
    public String getModalLogoHeader() {
        commonMethods.waitForElement(driver, modalLogoHeader);
        return $(modalLogoHeader).getText();
    }

    /**
     * Method to get the Dropzone text on Upload Modal
     */
    public String getModalDropZone() {
        return $(dropZone).getText();
    }

    /**
     * Method to click on Browse Computer
     */
    public void clickBrowseComputerBtn() {
        commonMethods.waitForElement(driver, browseComputerBtn);
        $(browseComputerBtn).click();

    }

    /**
     * Method to verify the Buttons present on the Logo Upload
     */
    public void verifyLogoButton() {
        commonMethods.waitForElement(driver, updateLogo);
        Assert.assertTrue($(updateLogo).isDisplayed());
        commonMethods.waitForElement(driver, cancelLogo);
        Assert.assertTrue($(cancelLogo).isDisplayed());
    }

    /**
     * Method to get the upload Org Logo
     */
    public void uploadOrgLogo(String fileName) {
        String filePath = configFileReader.getTestDataPath() + fileName;
        File file = new File(filePath);
        filePath = file.getAbsolutePath();
        $(uploadLogo).sendKeys(filePath);
        $(updateLogo).click();
        commonMethods.waitForElement(driver, logoImgUploaded);
    }

    /**
     * Method to get the delete Org Logo
     */
    public void deleteOrgLogo() {
        commonMethods.waitForElementExplicitly(3000);
        WebElement deleteIcon = driver.findElement(deleteLogo);
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOf(deleteIcon));
        wait.until(ExpectedConditions.elementToBeClickable(deleteIcon));
        $(deleteLogo).click();
        $(defaultZeroLogo).shouldBe(Condition.appear);
    }

    /**
     * Method to edit the Org Name
     */
    public void editOrgName(String newOrgName) {
        $(orgName).clear();
        $(orgName).sendKeys(newOrgName);
        $(tradingName).clear();
        $(tradingName).sendKeys(newOrgName);
    }

    /**
     * Method to get the Labels text on the UI
     */
    public List<String> getUIInputFields() {
        List<WebElement> list = driver.findElements(By.xpath("//table[@class='formTable']//input//..//..//td[@class='messagecell']//label"));
        List<String> values = new LinkedList<>();
        for (WebElement element : list) {
            values.add(element.getText());
        }
        return values;
    }

    /**
     * Method to get organization id
     */
    public String getOrganizationId(String organisation) {
        navigateAndVerifyPage();
        searchOrganisation(organisation);
        clickOrganization();
        commonMethods.waitForElement(driver, orgName, 60);
        return $(txtOrgId).getText();
    }

    /**
     * Method to validate the project logo
     */
    public boolean verifyProjectLogo() {
        return $(imgProjectLogo).isDisplayed();
    }

    /**
     * Method to change organization abbrivation code
     */
    public void fillOrgCode(String code) {
        commonMethods.enterTextValue(orgAbbreviation, code);
    }
}
