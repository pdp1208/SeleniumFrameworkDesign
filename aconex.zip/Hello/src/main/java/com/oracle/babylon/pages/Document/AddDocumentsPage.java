package com.oracle.babylon.pages.Document;

import com.codeborne.selenide.WebDriverRunner;
import com.github.javafaker.Faker;
import com.oracle.babylon.Utils.helper.CommonMethods;
import com.oracle.babylon.Utils.helper.Navigator;
import com.oracle.babylon.Utils.setup.FakeData;
import com.oracle.babylon.Utils.setup.utils.ConfigFileReader;
import com.oracle.babylon.pages.Setup.ProjectSettings.DocumentTypePage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class AddDocumentsPage extends DocumentPage {

    private By uploadDocument=By.xpath("//h1[text()='Upload Document']");
    private By input_associatedfile=By.id("associatedfile_0");
    protected By type = By.xpath("//select[@id='doctype']");
    private By docNumber = By.xpath("//input[@id='docno']");
    private By revision = By.xpath("//input[@name='revision']");
    private By attribute1 = By.xpath("//aui-select[@title='Attribute 1 List']//input");
    private By attribute2 = By.xpath("//aui-select[@title='Attribute 2 List']//input");
    private By docTitle = By.xpath("//input[@name='title']");
    protected By status = By.xpath("//select[@id='docstatus']");
    private By discipline = By.xpath("//select[@id = 'discipline']");
    private By vdrCode = By.xpath("//select[@id='vdrcode']");
    private By revisionDate = By.xpath("//input[@title='Revision Date']");
    private By dateCreated = By.xpath("//input[@title='Date Created']");
    private By dateForReview = By.xpath("//input[contains(@id,'forreview')]");
    private By plannedSubmissionDate = By.xpath("//input[contains(@id, 'plannedsubmissiondate')]");
    protected By scaleFrom = By.xpath("//input[contains(@name,'scale') and contains(@name, 'from')]");
    protected By scaleTo = By.xpath("//input[contains(@name,'scale') and contains(@name, 'to')]");
    private By percentComplete = By.xpath("//input[@name='percentcomplete']");
    private By uploadBtn = By.xpath("//button[contains(text(),'Register')]");
    private By confidentialChkBox = By.xpath("//span[contains(text(),'Limit access to selected individuals')]//..//input[@type='checkbox']");
    private final By accessListInput = By.xpath("//label[contains(text(),'Confidential')]//..//..//input[@type='search']");
    private final By importMetaDataPopUp = By.xpath("//div[@class='auiModal-content']//h3[text()='Import metadata']");
    private final By importMetaDataFile = By.xpath("(//input[@name='qqfile'])[2]");
    private final By metaDatafileSelected = By.xpath("//div/span/aui-file-icon");
    private By userField = By.xpath("//span[@placeholder='Enter names to add users']//..//input");
    private By okBtn = By.xpath("//div[contains(text(),'OK')]");
    private By pageTitle = By.xpath("//div[@id='unifiedUpload']//h2");
    private By autoNumber = By.xpath("//input[@id='autonumber']");
    private By fieldsMissingError = By.xpath("//div[text()='Several mandatory fields are empty. Please complete all highlighted fields before submitting.']");
    private By mandatoryFieldError = By.xpath("//div[text()='A mandatory field is empty. Please complete all highlighted fields before submitting.']");
    private By missingInfoError = By.xpath("//span[@title='Not ready to be registered. Please check the highlighted fields.']");
    private By closeBtn = By.xpath("//*[text()='Close']");
    private By files = By.xpath("//div[@class='files']//li//div[@class='fileInfo ng-scope' or @class='placeholder ng-binding ng-scope']");
    private By addMoreBtn = By.xpath("//button[@title='Add more']");
    private By importMetaData = By.xpath("//button[contains(text(),'Import metadata')]");
    protected By documentAttachPanel = By.xpath("(//input[@name='qqfile'])[1]");
    private By autoNumDocField = By.xpath("//label[text()='Document No']//..//..//input");
    private By lblSelectUploadProfile = By.xpath("//span[contains(text(),'Select Upload Profile')]");
    private By btnSelectProfile = By.xpath("//div[@class='upload-profiles-list']/button");
    private By btnEditProfile = By.xpath("//div[@class='upload-profiles-list']//span[@title='Edit Profile']");
    private By btnPlusIcon = By.xpath("//div[@class='dropzoneAdd' and text()='+']");
    private By btnCancel = By.xpath("//button[text()='Cancel']");
    private By lnkTellUsWhatYouThink = By.xpath("//button//span[contains(text(),'Tell us what you think')]");
    private By btnRemove = By.xpath("//div[@class='left-buttons']//button[contains(text(),'Remove')]");
    private By lblFilesCount = By.xpath("//span[@class='all-files ng-binding']");
    private By btnTableView = By.xpath("//button[@id='viewTable']");
    private By btnListView = By.xpath("//button[@id='viewList']");
    private By cancelBtn = By.xpath("//div[@class='auiToolbar-right']//button[text()='Cancel']");
    private By chkBoxSelectAll = By.xpath("//section[@class='file-list']/div/input");
    private By lblStandardProfile = By.xpath("//strong[contains(text(),'Standard Profiles')]");
    private By lblMyOrgProfiles = By.xpath("//strong[contains(text(),\"My Organization's Profiles\")]");
    private By lblMyProjectProfiles = By.xpath("//strong[contains(text(),\"My Project's Profiles\")]");
    private By btnCreateProfile = By.xpath("//button[contains(text(),'Create Upload Profile')]");
    private By selectUploadProfileDropDown = By.xpath("//button[@class='dropdown-trigger auiIcon expanded']");
    private By newFile = By.xpath("//span[@title='Creates New Document']");
    private By uploadProfile = By.xpath("//div[@id='uploadProfiles']//ul//li/label");
    private By chkBoxSelectAllInTableView = By.xpath("//section[@class='main tableView']//div[@class='ag-header-cell']//span[contains(@class,'ag-icon-checkbox')]");
    private By txtBoxSearch = By.xpath("//div[@class='field-search']//input");
    private By txtLabel = By.xpath("//div[text()='Label']");
    private By txtBoxAddLabel = By.xpath("//input[@name='newLabel']");
    private By btnPlus = By.xpath("//div[@class='field-action']/div[contains(@class,'icon icon-add')]");
    private By btnApply = By.xpath("//button[contains(text(),'Apply')]");
    private By txtDocUniqueError = By.xpath("//span[text()='This document number is already taken. Enter a unique document number.']");
    private By tblViewHeaders = By.xpath("//div[@class='bulk-registration-form']//div[@class='ag-header-viewport']");
    private By tblViewDocNo = By.xpath("//span[contains(text(),'Document No')]//ancestor::div[@ag-grid='gridOptions']//div[@class='ag-center-cols-container']//div[contains(@col-id,'docno')]");
    private By docNoAutoAssigned = By.xpath("//acx-unified-upload-document-number-field//input");
    private By lblDocUniqueError = By.xpath("//div[@ref='eBodyViewport']//div[@col-id='badges']//span");
    private By mandatoryFields = By.xpath("//form[@name='uploadForm']//div[contains(@class,'auiForm-label') and @required='required']/label");
    private By docFieldMandatoryError = By.xpath("//div[contains(text(),'This field is required.')]");
    private By associatedFile = By.xpath("//div[contains(@class,'ag-body-viewport')]//div[@col-id='associatedfile']");
    private By lblUUUploadPopup = By.xpath("//div[@id='uploadFilesModal']//div[@class='auiModal-header']//h3");
    private By newLabel = By.xpath("//input[@name='newLabel']");
    private By newCode = By.xpath("//input[@name='newCode']");
    private By plusIcon = By.xpath("//div[@class='icon icon-add']");
    private By docFieldLabels = By.xpath("//form[@name='uploadForm']//div[contains(@class,'auiForm-label')]//label");
    private By bulkEditFields = By.xpath("//form[@name='form.bulkEditForm']//div[contains(@class,'auiForm-label')]//label");
    private By bulkEditMandatoryFields = By.xpath("//form[@name='form.bulkEditForm']//div[contains(@class,'auiForm-label') and @required='required']/label");
    private By lblDocumentNo = By.xpath("//span[contains(text(),'Document No')]");
    private By txtBoxDocNo = By.xpath("(//div[@class='ag-center-cols-container']/div/div[contains(@col-id,'docno')]//input)[1]");
    private By docPencilIcon = By.xpath("//label[text()='Document No']/../following-sibling::div//span");
    private By txtBoxDocNum = By.xpath("//form[@name='uploadForm']//div//*[contains(@title,'Document Number')]");
    private By projFieldDropDown = By.xpath("//select//option");
    protected By documentReplacePanel = By.xpath("(//input[@name='qqfile'])[3]");
    private By removeBtn = By.xpath("//button[@title='Remove']");
    private By hdrUpload = By.xpath("//div[text()='Select an Option Below to Proceed'] | //label[text()='Select how to create the placeholders']");
    private By docFieldLabelsFromProp = By.xpath("//ul[@class='propertiesPanel-list']/li/div[@class='propertiesPanel-list-item-label ng-binding']");
    Navigator navigator = new Navigator();
    BulkSupersedePage bulkSupersedePage = new BulkSupersedePage();
    private ConfigFileReader configFileReader = new ConfigFileReader();
    String filePath = configFileReader.getTestDataPath();
    private Faker faker = new Faker();
    SimpleDateFormat formatter = new SimpleDateFormat("dd-HH-mm-ss");
    public static String documentNumber;
    public static List<String> docFieldValues = new ArrayList<>();
    private By projectFields = By.xpath("//acx-multi-select-field[@project-field='true']//input[@type='search']");
    FakeData fakeData = new FakeData();
    private By missingInformationText=By.xpath("//span[contains(text(),'Missing information')]");
    private By input_docNo=By.id("docno_0");
    private By input_revision=By.xpath("//input[@name='revision_0']");
    private By input_title=By.xpath("//input[@name='title_0']");
    private By input_doctype=By.id("doctype_0");
    private By input_status=By.id("docstatus_0");
    private By input_discipline=By.id("discipline_0");
    private By input_revisionDate=By.xpath("//input[@name='revisiondate_0_da']");
    private By documentUploadSuccessMsg=By.xpath("//*[text()='Document Uploaded Successfully']");


    /**
     * Method to navigate to upload Document and verify or the title of the page
     */
    public void navigateAndVerifyPage(String documentType) {
        HashMap<String, String> docMap = CommonMethods.getDocumentTypeDetail(getDocumentMenuName());
        getMenuSubmenu(docMap.get("uploadmenu"), docMap.get("uploadsubmenu"));
        verifyPage(docMap.get("uploadtitle"));
    }

    public void verifyPage(String title) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, pageTitle, 60);
        List<WebElement> list = driver.findElements(pageTitle);
        Assert.assertTrue("Page Title is not displayed correctly", list.get(0).getText().toLowerCase().contains(title.toLowerCase()));
    }

    public String returnPageTitle() {
        commonMethods.waitForElement(driver, pageTitle, 60);
        return $(pageTitle).getText();
    }

    /**
     * Method to upload a document in document register from local file upload
     *
     * @param attribute attributes of upload document
     */
    public String uploadDocument(String attribute) {
        upload(attribute);
        commonMethods.waitForElement(driver, docUploadSuccess, 60);
        clickViewInRegisterLink();
        return returnDocNumber();
    }

    /**
     * Method only uploads the document.
     * Does not navigate to the document register page to return the document number
     *
     * @param attribute
     */
    public void upload(String attribute) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(5000);
        chooseFile(attribute);
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, type, 60);
        fillFields(attribute);
        commonMethods.waitForElementExplicitly(6000);
        clickRegisterBtn();
    }
    /**
     * Method only uploads the document without angular
     * Does not navigate to the document register page to return the document number
     *
     * @param attribute
     */
    public String uploadWithoutAngular(String attribute) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(5000);
        //chooseFile(attribute);
        //$(input_associatedfile).sendKeys(filePath + "sample.png");
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, uploadDocument, 15);
        //fillFields(attribute);
        Map<String, String> table = dataStore.getTable(attribute);
        Date dt = new Date();
        String documentNumber = "";
        //Required for initial document number creation
        if (table.get("Title") == null) {
           // documentNumber = faker.file().fileName().substring(0, 6) + "_" + formatter.format(dt);
            documentNumber = faker.file().fileName().substring(0, 6) + faker.number().digits(5);
            documentNumber=documentNumber.replaceAll("[^a-zA-Z0-9]", " ");
        } else {
            documentNumber = table.get("Title");
        }

        documentNumber = documentNumber.replace(" ", "");
        if ($(input_title).getAttribute("value").equalsIgnoreCase("")) {
            $(input_title).clear();
            $(input_title).sendKeys(documentNumber);
        }
        if (table.get("Auto Numbering") != null && table.get("Auto Numbering").equalsIgnoreCase("true")) {
            $(autoNumber).setSelected(true);
        }
        $(input_docNo).clear();
        $(input_docNo).sendKeys(documentNumber);
        for (String tableData : table.keySet()) {
            String date = commonMethods.getTodayDate("Australia/Sydney");
            switch (tableData) {
                case "Type":
                    commonMethods.enterDropdownValue(input_doctype, table.get(tableData));
                    break;
                case "Attribute1":
                    commonMethods.enterTextValue(attribute1, table.get(tableData));
                    break;
                case "Revision":
                    commonMethods.enterTextValue(input_revision, table.get(tableData));
                    break;
                case "Status":
                    commonMethods.enterDropdownValue(input_status, table.get(tableData));
                    break;
                case "Discipline":
                    commonMethods.enterDropdownValue(input_discipline, table.get(tableData));
                    break;
                case "Revision Date":
                    String revisionDateValue = commonMethods.getDate("Australia/Sydney", table.get(tableData));
                    commonMethods.enterTextValue(input_revisionDate, revisionDateValue);
                    break;
                case "Date Created":
                    commonMethods.enterTextValue(dateCreated, date);
                    break;
                case "Scale":
                    String[] strList = table.get(tableData).split(":");
                    commonMethods.enterTextValue(scaleFrom, strList[0]);
                    commonMethods.enterTextValue(scaleTo, strList[1]);
                    break;
                case "Percent Complete":
                    commonMethods.enterTextValue(percentComplete, table.get(tableData));
                    break;
                case "Date For Review":
                    String dateForReviewValue = commonMethods.getDate("Australia/Sydney", table.get(tableData));
                    getElementInView(dateForReview);
                    commonMethods.enterTextValue(dateForReview, dateForReviewValue);
                    break;
                case "Planned Submission Date": {
                    String plannedDate = commonMethods.getDate("Australia/Sydney", table.get(tableData));
                    getElementInView(plannedSubmissionDate);
                    commonMethods.enterTextValue(plannedSubmissionDate, plannedDate);
                    break;
                }
                case "HasFile":
                {
                    String[] docAttribute = table.get(tableData).split(",");
                    if (Boolean.parseBoolean(docAttribute[0])) {
                        if ((docAttribute.length) < 2) {
                            $(input_associatedfile).sendKeys(filePath + "sample.png");
                            break;
                        } else {
                            $(input_associatedfile).sendKeys(filePath + docAttribute[1]);
                            break;
                        }
                    }
                }
                case "Confidential":
                    getElementInView(attribute2);
                    String[] confidential = table.get(tableData).split(",");
                    if (!confidential[0].equalsIgnoreCase("false")) {
                        if (!$(confidentialChkBox).isSelected()) {
                            $(confidentialChkBox).setSelected(true);
                            verifyAlert("This action will make this document confidential");
                            verifyAndSwitchFrame();
                        }
                        if (confidential.length > 1) {
                            verifyAndSwitchFrame();
                            //commonMethods.waitForElement(driver, accessListBtn, 45);
                            //$(accessListBtn).click();
                            for (int i = 1; i < confidential.length; i++) {
                                jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
                                userMap = jsonMapOfMap.get(confidential[i]);
                                $(userField).clear();
                                $(userField).sendKeys(userMap.get("full_name").toString());
                                commonMethods.waitForElementExplicitly(1000);
                                $(userField).sendKeys(Keys.ENTER);
                                commonMethods.waitForElementExplicitly(1000);
                            }
                            break;
                        }
                    } else {
                        $(confidentialChkBox).setSelected(Boolean.parseBoolean(confidential[0]));
                        //acceptAlert();
                        verifyAndSwitchFrame();
                    }
                    break;
            }
        }
        verifyAndSwitchFrame();
        clickUploadBtn();
        commonMethods.waitForElement(driver, documentUploadSuccessMsg, 30);
        return documentNumber;
    }
    /**
     * Method to fill up the upload document fields
     *
     * @param attribute
     */
    public void fillFields(String attribute) {
        commonMethods.waitForElement(driver, type, 60);
        Map<String, String> table = dataStore.getTable(attribute);
        Date dt = new Date();
        String documentNumber = "";
        //Required for initial document number creation
        if (table.get("Title") == null) {
            fakeData.setDocumentNumber();
            documentNumber = fakeData.getDocumentNumber();
        } else {
            documentNumber = table.get("Title");
        }
        documentNumber = documentNumber.replace(" ", "");
        commonMethods.waitForElement(driver, titleName, 30);
        if ($(titleName).getAttribute("value").equalsIgnoreCase("")) {
            $(titleName).clear();
            $(titleName).sendKeys(documentNumber);
        }
        if (table.get("Auto Numbering") != null && table.get("Auto Numbering").equalsIgnoreCase("true")) {
            $(autoNumber).setSelected(true);
        }
        if ($(autoNumber).isDisplayed()) {
            if (!$(autoNumber).isSelected() && $(docNumber).getAttribute("disabled") == null) {
                commonMethods.waitForElementExplicitly(400);
                $(docNumber).clear();
                $(docNumber).sendKeys(documentNumber);
            }
        }
        if ($(docNumber).isDisplayed()) {
            if (($(docNumber).getAttribute("disabled") == null)) {
                commonMethods.waitForElementExplicitly(2000);
                $(docNumber).clear();
                commonMethods.waitForElementExplicitly(1000);
                $(docNumber).sendKeys(documentNumber);
            }
        }
        String date = commonMethods.getTodayDate(configFileReader.getTimeZone());
        for (String tableData : table.keySet()) {
            commonMethods.waitForElementExplicitly(1000);
            switch (tableData) {
                case "Type":
                    commonMethods.enterDropdownValue(type, table.get(tableData));
                    break;
                case "Attribute1":
                    commonMethods.getElementInViewAndUp(attribute1);
                    commonMethods.enterTextValue(attribute1, table.get(tableData));
                    commonMethods.waitForElementExplicitly(500);
                    $(attribute1).sendKeys(Keys.ENTER);
                    break;
                case "Attribute2":
                    commonMethods.getElementInViewAndUp(attribute1);
                    commonMethods.enterTextValue(attribute2, table.get(tableData));
                    $(attribute2).sendKeys(Keys.ENTER);
                    break;
                case "ProjectFields":
                    getElementInView(projectFields);
                    commonMethods.enterTextValue(projectFields, table.get(tableData));
                    $(projectFields).sendKeys(Keys.ENTER);
                    break;

                case "Revision":
                    commonMethods.enterTextValue(revision, table.get(tableData));
                    break;
                case "Status":
                    commonMethods.waitForElement(driver, status);
                    commonMethods.enterDropdownValue(status, table.get(tableData));
                    break;
                case "Discipline":
                    commonMethods.enterDropdownValue(discipline, table.get(tableData));
                    break;
                case "Revision Date":
                    if ($(revisionDate).isDisplayed()) {
                        String revisionDateValue = commonMethods.getDate(configFileReader.getTimeZone(), table.get(tableData));
                        commonMethods.enterTextValue(revisionDate, revisionDateValue);
                        $(revisionDate).sendKeys(Keys.ENTER);
                        break;
                    }
                case "Date Created":
                    commonMethods.enterTextValue(dateCreated, date);
                    break;
                case "Scale":
                    String[] strList = table.get(tableData).split(":");
                    commonMethods.enterTextValue(scaleFrom, strList[0]);
                    commonMethods.enterTextValue(scaleTo, strList[1]);
                    break;
                case "Percent Complete":
                    commonMethods.enterTextValue(percentComplete, table.get(tableData));
                    break;
                case "Date For Review":
                    String dateForReviewValue = commonMethods.getDate(configFileReader.getTimeZone(), table.get(tableData));
                    getElementInView(dateForReview);
                    commonMethods.enterTextValue(dateForReview, dateForReviewValue);
                    break;
                case "Planned Submission Date": {
//                    $(missingInformationText).click();
                    String plannedDate = commonMethods.getDate(configFileReader.getTimeZone(), table.get(tableData));
                    getElementInView(plannedSubmissionDate);
                    commonMethods.enterTextValue(plannedSubmissionDate, plannedDate);
                    break;
                }
                case "Confidential":
                    getElementInView(confidentialChkBox);
                    String[] confidential = table.get(tableData).split(",");
                    if (!confidential[0].equalsIgnoreCase("false")) {
                        if (!$(confidentialChkBox).isSelected()) {
                            $(confidentialChkBox).setSelected(true);
                            verifyAlert("This action will make this document confidential");
                            verifyAndSwitchFrame();
                        }
                        if (confidential.length > 1) {
                            verifyAndSwitchFrame();
                            //commonMethods.waitForElement(driver, accessListBtn, 45);
                            //$(accessListBtn).click();
                            for (int i = 1; i < confidential.length; i++) {
                                By userRemoveBtn = By.xpath("//span[contains(text(),'" + commonMethods.getUserName(confidential[i]) + "')]/../../span[@class='close ui-select-match-close']");
                                if ($(userRemoveBtn).isDisplayed()) $(userRemoveBtn).click();
                                $(userField).clear();
                                $(userField).sendKeys(commonMethods.getUserName(confidential[i]));
                                commonMethods.waitForElement(driver, By.xpath("//div/strong[contains(text(),'" + commonMethods.getUserName(confidential[i]).split(" ")[0] + "')]"), 10);
                                $(userField).sendKeys(Keys.ENTER);
                                commonMethods.waitForElementExplicitly(1000);
                            }
                            break;
                        }
                    } else {
                        $(confidentialChkBox).setSelected(Boolean.parseBoolean(confidential[0]));
                        //acceptAlert();
                        verifyAndSwitchFrame();
                    }
                    break;
            }

        }
    }

    /**
     * Method to add document fields based on field names, values and type passed in parameter
     *
     * @param fieldName
     * @param fieldValue
     * @param fieldTypes
     */
    public void fillFields(String fieldName, String fieldValue, String fieldTypes) {
        commonMethods.waitForElement(driver, type, 30);
        switch (fieldTypes.toLowerCase()) {
            case "dropdown":
                commonMethods.enterDropdownValue(By.xpath("//form[@name='uploadForm']//div/acx-single-select-field/select[contains(@title,'" + fieldName + "')]"), fieldValue);
                commonMethods.waitForElementExplicitly(1000);
                break;
            case "text":
                commonMethods.enterTextValue(By.xpath("//form[@name='uploadForm']//div/acx-unified-upload-text-field//input[contains(@title,'" + fieldName + "')]"), fieldValue);
                break;
            case "date":
                updateDateField(fieldValue, By.xpath("//form[@name='uploadForm']//div/acx-unified-upload-date-field/input[@title='" + fieldName + "']"));
                break;
            case "select list":
                updateSelectListField("//form[@name='uploadForm']//div/acx-multi-select-field/aui-select[contains(@title,'" + fieldName + "')]", fieldValue);
                break;
            case "checkbox":
                updateCheckboxField(fieldName, fieldValue);
                break;
            case "file":
                replaceDocument(fieldValue);
                break;
            case "pf-selectlist":
                updateSelectListField("//label[text()='" + fieldName + "']/../following-sibling::div//acx-multi-select-field/aui-select", fieldValue);
                break;
            case "pf-button":
                $(By.xpath("//label[text()='" + fieldName + "']/../following-sibling::div//acx-boolean-radio-field//span[text()='" + fieldValue + "']")).click();
                break;
            case "pf-dropdown":
                commonMethods.enterDropdownValue(By.xpath("//label[text()='" + fieldName + "']/../following-sibling::div//acx-single-select-field//select"), fieldValue);
                break;
            case "pf-text":
                commonMethods.enterTextValue(By.xpath("//label[text()='" + fieldName + "']/../following-sibling::div//div[@class='auiForm-field']/input"), fieldValue);
                break;
            case "pf-textarea":
                commonMethods.enterTextValue(By.xpath("//label[text()='" + fieldName + "']/../following-sibling::div//div[@class='auiForm-field']/textarea"), fieldValue);
                break;
            case "pf-date":
                updateDateField(fieldValue, By.xpath("//label[text()='" + fieldName + "']/../following-sibling::div//acx-date-field/input"));
                break;
            case "pf-number":
                commonMethods.enterTextValue(By.xpath("//label[text()='" + fieldName + "']/../following-sibling::div//acx-number-field/input"), fieldValue);
                break;
        }
    }

    /**
     * Method to get doc confidentiality flag
     *
     * @return flag
     */
    public Boolean getDocConfidentiality() {
        verifyAndSwitchFrame();
        Boolean flag = $(confidentialChkBox).isSelected();
        return flag;
    }

    /**
     * Method to verify confidential functionality is disabled
     */
    public Boolean confidentialCheckBoxPresence() {
        verifyAndSwitchFrame();
        getElementInView(confidentialChkBox);
        commonMethods.waitForElement(driver, confidentialChkBox, 45);
        return $(confidentialChkBox).isEnabled();
    }


    /**
     * Method to validate if the success message is displayed
     *
     * @return
     */
    public boolean validateSuccessMessage() {
        commonMethods.waitForElementExplicitly(4000);
        commonMethods.waitForElement(driver, docUploadSuccess, 120);
        return $(docUploadSuccess).getText().contains("moved to Document Register of your organization");

    }

    /**
     * Method to validate when one or two mandatory fields are missing
     *
     * @return
     */
    public boolean validateMandatoryMessages() {
        return $(mandatoryFieldError).isDisplayed();
    }

    public boolean validateMissingFields() {
        return $(fieldsMissingError).isDisplayed();
    }

    public boolean validateMissingInfo() {
        return $(missingInfoError).isDisplayed();
    }

    /**
     * Method to validate if the message document number must be unique is displayed
     *
     * @return
     */
    public boolean validateUniqueMessage() {
        return $(uniqueDocumentMessage).isDisplayed();
    }

    /**
     * Method to validate if the message document number must be unique is displayed
     *
     * @return
     */
    public boolean validateDocumentSupersede() {
        commonMethods.waitForElement(driver, documentSupersedeCheck, 60);
        return $(documentSupersedeCheck).isDisplayed();
    }

    /**
     * Method to validate if the message document number must be unique is displayed
     *
     * @return
     */
    public String validateDocFieldDisabled() {
        commonMethods.waitForElement(driver, documentNumberField, 60);
        return $(documentNumberField).getAttribute("disabled");

    }


    /**
     * Method to set the auto number checkbox as true
     */
    public void setAutoNumber() {
        commonMethods.waitForElement(driver, autoNumber);
        Actions actions = new Actions(driver);
        actions.moveToElement($(autoNumber)).click().perform();
        //$(autoNumber).setSelected(true);
    }


    /**
     * Method to drop files when registering a document
     *
     * @param attribute
     */
    public void chooseFile(String attribute) {
        Map<String, String> table = dataStore.getTable(attribute);
        String checkValue = table.get("HasFile");
        String[] docAttribute = new String[2];
        if (checkValue == null) {
            docAttribute[0] = "";
        } else {
            docAttribute = table.get("HasFile").split(",");
        }

        verifyAndSwitchFrame();
        // driver.switchTo().frame("dropZone");
        if (Boolean.parseBoolean(docAttribute[0])) {
            if ((docAttribute.length) < 2) {
                $(documentAttachPanel).sendKeys(new File(filePath + "/" + "street_plan.pdf").getAbsolutePath());

            } else {
                $(documentAttachPanel).sendKeys(new File(filePath + "/" + docAttribute[1]).getAbsolutePath());
            }
        } else {
            $(documentAttachPanel).sendKeys(new File(filePath + "/" + "street_plan.pdf").getAbsolutePath());
        }
        driver.switchTo().defaultContent();
    }

    /**
     * Method to upload all the files from test data path
     *
     * @param directoryPath
     */
    public void uploadMultipleFiles(String directoryPath) {
        List<String> filesToUpload = commonMethods.returnFileNames(directoryPath);
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, hdrUpload, 60);
        for (String file : filesToUpload) {
            $(documentAttachPanel).sendKeys(file);
        }
        commonMethods.waitForElementExplicitly(5000);
        switchToOriginal();
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        removeConfidentiality();
        clickSaveTempFiles();
        commonMethods.waitForElement(driver, closeBtn, 120);
        $(closeBtn).click();

    }

    /**
     * Method to upload a single file from test data path
     *
     * @param fileName
     */
    public void uploadFile(String fileName) {
        verifyAndSwitchFrame();
        attachDocument(fileName);
        commonMethods.waitForElementExplicitly(5000);
        removeConfidentiality();
        clickSaveTempFiles();
    }

    /**
     * Method to validate Add More is displayed
     *
     * @return
     */
    public boolean isAddMoreBtnDisplayed() {
        return $(addMoreBtn).isDisplayed();
    }

    /**
     * Method to validate import meta data is displayed
     *
     * @return
     */
    public boolean isImportMetadataDisplayed() {
        return $(importMetaData).isDisplayed();
    }

    /**
     * Method to validate if temp files is displayed
     *
     * @return
     */
    public boolean isTempFilesBtnDisplayed() {
        return $(saveTempFiles).isDisplayed();
    }


    /**
     * Method to validate if register button is displayed
     *
     * @return
     */
    public boolean isRegisterBtnDisplayed() {
        return $(uploadBtn).isDisplayed();
    }

    /**
     * Method to validate if register button is enabled
     *
     * @return
     */
    public boolean isRegisterBtnEnabled() {
        return $(uploadBtn).isEnabled();
    }

    /**
     * Fills the document with document number of the second document on the left panel
     */
    public void fillNonUniqueValue() {
        commonMethods.waitForElementExplicitly(5000);
        List<WebElement> list = driver.findElements(files);
        list.get(0).click();
        commonMethods.waitForElementExplicitly(5000);
        commonMethods.waitForElement(driver, docNumber);
        String value = $(docNumber).getValue();
        list.get(1).click();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, docNumber);
        $(docNumber).clear();
        commonMethods.waitForElementExplicitly(4000);
        $(docNumber).sendKeys(value);
    }

    /**
     * Returns the document number present in the page
     *
     * @return
     */
    public String returnDocNo() {
        List<WebElement> list = driver.findElements(autoNumDocField);
        return list.get(0).getAttribute("value");
    }

    /**
     * Method to select file
     */
    public void selectFile(int index) {
        List<WebElement> list = driver.findElements(files);
        list.get(index - 1).click();
    }

    /**
     * Method to clear status field
     */
    public void clearStatusField() {
        commonMethods.enterDropdownValue(status, "-- Select --");
    }

    /**
     * Method to attach a document
     */
    public void attachDocument(String fileName) {
        String filePath = configFileReader.getTestDataPath() + fileName;
        File file = new File(filePath);
        filePath = file.getAbsolutePath();
        commonMethods.waitForElementExplicitly(5000);
        $(documentAttachPanel).sendKeys(filePath);
    }
    /**
     * Method to to verify doc auto number
     */
    public void verifyDocumentNumber(String docName) {
        Assert.assertTrue(commonMethods.returnDocNumberInJson(docName).trim().equals(commonMethods.getAutoNumbering(docName).split(":")[1].trim()));
    }

    /**
     * Method to update checkbox field in add/update document screen
     */
    public void updateCheckboxField(String fieldName, String fieldValue) {
        String[] values = fieldValue.split(",");
        By checkboxField = By.xpath("//form[@name='uploadForm']//div//input[contains(@name,'" + fieldName.toLowerCase() + "')]");
        commonMethods.waitForElement(WebDriverRunner.getWebDriver(), checkboxField, 10);
        if (!Boolean.parseBoolean(values[0].toLowerCase()) == $(checkboxField).isSelected())
            $(checkboxField).click();
        for (int i = 1; i < values.length; i++) {
            commonMethods.enterTextValue(accessListInput, commonMethods.getUserName(values[i]));
            commonMethods.waitForElementExplicitly(2000);
            $(accessListInput).sendKeys(Keys.ENTER);
        }
    }

    /**
     * Function to verify Document Auto Number
     *
     * @param attribute
     * @return
     */
    public boolean verifyAutoNumber(String attribute) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(5000);
        chooseFile(attribute);
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, type, 15);
        return $(autoNumber).isDisplayed();
    }

    /**
     * Method to verify disabled dropdown fields
     */
    public String verifyDisabledFields(String name) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, type, 60);
        if (name.startsWith("label_")) name = commonMethods.getLabelName(name);
        return $(By.xpath("//form[@name='uploadForm']//label[text()='" + name + "']/../following-sibling::div//select")).getAttribute("disabled");
    }

    /**
     * Function to get all dropdown field values present
     *
     * @return
     */
    public List<String> getFieldValues(String fieldName) {
        verifyAndSwitchFrame();
        if (fieldName.startsWith("label_"))
            return getDropdownValues("//form[@name='uploadForm']//label[text()='" + commonMethods.getLabelName(fieldName) + "']/../following-sibling::div//select");
        else
            return getDropdownValues("//form[@name='uploadForm']//div/acx-single-select-field/select[@title='" + fieldName + "']");
    }

    /**
     * Method to File restriction alert window
     */
    public void verifyFileRestrictionAlert(String message) {
        commonMethods.waitForElementExplicitly(5000);
        Assert.assertEquals(message, getAlertText());
        acceptAlert();
    }

    /**
     * Method to File restriction page
     */
    public boolean verifyFileRestriction(String message) {
        commonMethods.waitForElement(driver, By.xpath("//*[text()='" + message + "']"), 30);
        return $(By.xpath("//*[text()='" + message + "']")).isDisplayed();
    }

    /**
     * Method to verify upload Documents popup window options
     */
    public void verifyUploadDocumentsPopup() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, lblSelectUploadProfile, 60);
        Assert.assertTrue($(lblSelectUploadProfile).isDisplayed());
        Assert.assertTrue($(btnSelectProfile).isDisplayed());
        Assert.assertTrue($(btnEditProfile).isDisplayed());
        Assert.assertTrue($(btnPlusIcon).isDisplayed());
    }

    /**
     * Method to verify upload Documents page options
     */
    public void verifyUploadDocumentOptions(String docType) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, type, 60);
        Assert.assertTrue($(uploadBtn).isDisplayed());
        Assert.assertTrue($(cancelBtn).isDisplayed());
        Assert.assertTrue($(removeBtn).isDisplayed());
        Assert.assertTrue($(lnkTellUsWhatYouThink).isDisplayed());
        Assert.assertTrue($(addMoreBtn).isDisplayed());
        Assert.assertTrue($(bulkSupersedePage.bulkEditBtn).isDisplayed());
        Assert.assertTrue($(btnTableView).isDisplayed());
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, btnTableView, 30);
        Assert.assertTrue($(btnTableView).isEnabled());
        Assert.assertTrue($(btnListView).isDisplayed());
        commonMethods.waitForElementExplicitly(1000);
        Assert.assertFalse($(btnListView).isEnabled());
        if (!docType.equalsIgnoreCase("placeholder")) {
            Assert.assertTrue($(saveTempFiles).isDisplayed());
            Assert.assertTrue($(importMetaData).isDisplayed());
        }
    }

    /**
     * Method to verify ready for register message
     */
    public boolean verifyReadyForRegister() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, spanReadyToRegister, 30);
        commonMethods.waitForElementClickable(driver, uploadBtn, 10);
        return $(spanReadyToRegister).isDisplayed() && $(uploadBtn).isEnabled();
    }

    /**
     * Method to get the files count
     */
    public int getFilesCount() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(5000);
        return Integer.parseInt($(lblFilesCount).getText().split(" ")[1].trim());
    }

    /**
     * Method to select all files
     */
    public void selectAllFiles(boolean flag) {
        commonMethods.waitForElement(driver, chkBoxSelectAll, 60);
        $(chkBoxSelectAll).setSelected(flag);
    }

    public void selectAllFiles() {
        commonMethods.waitForElement(driver, chkBoxSelectAll, 30);
        $(chkBoxSelectAll).setSelected(true);
    }

    /**
     * Method to get doc count from success popup window
     */
    public int returnRegDocCount() {
        commonMethods.waitForElement(driver, docUploadSuccess, 60);
        return Integer.parseInt($(docUploadSuccess).getText().split("\\s+")[0].trim());
    }

    /**
     * Method to verify entered field value
     */
    public String verifyFieldData(String fieldName) {
        String value = "";
        commonMethods.waitForElement(driver, type, 60);
        switch (fieldName) {
            case "Comments":
                value = $(By.xpath("//form[@name='uploadForm']//div/acx-unified-upload-text-area-field//*[contains(@name,'" + fieldName.toLowerCase() + "')]")).getValue();
                break;
            case "Document No":
            case "Title":
            case "Revision":
            case "Date Created":
            case "Revision Date":
                if (fieldName.equalsIgnoreCase("document no")) fieldName = "Document Number";
                value = $(By.xpath("//form[@name='uploadForm']//div//*[contains(@title,'" + fieldName + "')]")).getValue();
                break;
            case "Type":
            case "Status":
            case "Discipline":
                if (fieldName.equalsIgnoreCase("status")) fieldName = "status";
                value = $(By.xpath("//form[@name='uploadForm']//div//*[contains(@title,'" + fieldName + "')]")).getText();
                break;
            default:
                if (fieldName.startsWith("label_")) {
                    value = $(By.xpath("//form[@name='uploadForm']//label[text()='" + commonMethods.getLabelName(fieldName) + "']/../following-sibling::div//select")).getText();
                }
        }
        return value;
    }

    /**
     * Method to verify upload profile options
     */
    public void verifyProfileOptions() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, btnSelectProfile, 30);
        $(btnSelectProfile).click();
        Assert.assertTrue($(lblStandardProfile).isDisplayed());
        Assert.assertTrue($(lblMyOrgProfiles).isDisplayed());
        Assert.assertTrue($(lblMyProjectProfiles).isDisplayed());
        Assert.assertTrue($(btnCreateProfile).isDisplayed());
    }

    /**
     * Method to click on edit profile button
     */
    public void editProfile(String profileName) {
        if (!$(btnCreateProfile).isDisplayed()) {
            commonMethods.waitForElement(driver, btnSelectProfile);
            $(btnSelectProfile).click();
        }
        $(By.xpath("//label[contains(text(),'" + profileName + "')]/../span[@title='Edit Profile']")).click();
    }

    /**
     * Method to get the entered document number
     */
    public String getEnteredDocNumber() {
        return $(docNumber).getValue();
    }

    /**
     * Method to click on create upload profile button
     */
    public void clickCreateUploadProfile() {
        if (!$(btnCreateProfile).isDisplayed())
            $(btnSelectProfile).click();
        $(btnCreateProfile).click();
    }

    /**
     * Method to verify upload profile name
     */
    public boolean verifyUploadProfile(String profileName, String section) {
        if (!$(btnCreateProfile).isDisplayed())
            $(btnSelectProfile).click();
        if (section.equalsIgnoreCase("organization"))
            return $(By.xpath("//label/strong[contains(text(),\"My Organization's Profiles\")]/../..//label[text()='" + profileName + "']")).isDisplayed();
        else
            return $(By.xpath("//label/strong[contains(text(),\"My Project's Profiles\")]/../..//label[text()='" + profileName + "']")).isDisplayed();

    }

    /**
     * Method to select a profile
     */
    public void selectProfile(String profileName) {
        if (!$(btnCreateProfile).isDisplayed())
            $(btnSelectProfile).click();
        $(By.xpath("//label[text()='" + profileName + "']")).click();
    }

    /**
     * Method to get all profile names
     */
    public List<String> getProfileNames() {
        List<String> names = new ArrayList<>();
        List<WebElement> elements = new ArrayList<>($$(By.xpath("//div[@id='uploadProfiles']//ul//li/label")));
        for (WebElement element : elements)
            names.add(element.getText());
        return names;
    }

    public void removeConfidentiality() {
        List<WebElement> list = driver.findElements(files);
        for (WebElement element : list) {
            commonMethods.waitForElementExplicitly(3000);
            $(element).click();
            commonMethods.waitForElementExplicitly(3000);
            $(confidentialChkBox).setSelected(false);
        }
    }


    public boolean newFileCheck() {
        return $(newFile).isDisplayed();
    }

    public void setDefaultProfile() {
        $(btnSelectProfile).click();
        List<WebElement> elements = new ArrayList<>($$(uploadProfile));
        if (elements.size() > 0) {
            elements.get(0).click();
        }

    }

    public void clickTableView() {
        $(btnTableView).click();
    }

    public String addLabel() {
        Faker faker = new Faker();
        String buzzWord = faker.company().buzzword();
        $(newLabel).sendKeys(buzzWord);
        $(newCode).sendKeys(buzzWord.substring(0, 2));
        $(plusIcon).click();
        clickSaveBtn();
        return buzzWord;
    }

    public void deleteLabel(String label) {
        WebElement element = $(By.xpath("//div[contains(text(),'" + label + "')]//..//div[@class='auiIcon trash']"));
        element.click();
        clickSaveBtn();
    }

    /**
     * Method to select view in upload documents page
     */
    public void selectView(String view) {
        if (view.equalsIgnoreCase("list")) $(btnListView).click();
        else if (view.equalsIgnoreCase("table")) $(btnTableView).click();
    }

    /**
     * Method to select all files in table view mode
     */
    public void selectAllFilesInTableView(boolean flag) {
        commonMethods.waitForElementExplicitly(2000);
        $(associatedFile).click();
        commonMethods.waitForElement(driver, chkBoxSelectAllInTableView, 30);
        if (($(chkBoxSelectAllInTableView).getAttribute("class").contains("unchecked") && flag) || ($(chkBoxSelectAllInTableView).getAttribute("class").contains("checked") && !flag))
            $(chkBoxSelectAllInTableView).click();
        else {
            if ($(chkBoxSelectAllInTableView).getAttribute("class").contains("indeterminate") && flag)
                $(chkBoxSelectAllInTableView).click();
            else
                $(chkBoxSelectAllInTableView).doubleClick();
        }
    }

    /**
     * Method to choose upload profile
     */
    public void chooseUploadProfile() {
        commonMethods.waitForElement(driver, selectUploadProfileDropDown, 60);
        $(selectUploadProfileDropDown).click();
    }

    /**
     * Method to get field values from table view
     */
    public String verifyTableViewFieldData(String fieldName) {
        return $(By.xpath("//section[@class='main tableView']//div[@ref='eCenterViewport']//div[contains(@col-id,'" + fieldName.toLowerCase() + "')]")).getText();
    }

    /**
     * Method to verify pencil icon displayed for document fields
     */
    public boolean verifyEditableInlineIcon(String field) {
        return $(By.xpath("//label[text()='" + field + "']/../following-sibling::div//span[@title='Edit " + field + " values']")).isDisplayed();

    }

    /**
     * Method to click on pencil icon displayed for document fields
     */
    public void clickPencilIcon(String field) {
        $(By.xpath("//label[text()='" + field + "']/../following-sibling::div//span[@title='Edit " + field + " values']")).click();
    }

    /**
     * Method to verify edit inline field window
     */
    public void verifyEditInlineWindow(String field, String type) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, txtBoxSearch, 30);
        Assert.assertTrue($(txtBoxSearch).isDisplayed());
        Assert.assertTrue($(By.xpath("//h3[contains(text(),'Edit " + type + " field values - " + field + "')]")).isDisplayed());
        if (type.equalsIgnoreCase("document"))
            Assert.assertTrue($(txtLabel).isDisplayed());
        Assert.assertTrue($(txtBoxAddLabel).isDisplayed());
        Assert.assertTrue($(btnPlus).isDisplayed());
        Assert.assertTrue($(saveButton).isDisplayed());
        Assert.assertTrue($(btnCancel).isDisplayed());
    }

    /**
     * Method to close edit inline field window
     */
    public void closeEditInlineWindow() {
        commonMethods.waitForElement(driver, btnCancel);
        $(btnCancel).click();
    }

    /**
     * Method to add field values
     */
    public void addFieldValue(String value) {
        commonMethods.enterTextValue(txtBoxAddLabel, value);
        commonMethods.waitForElementExplicitly(1000);
        $(btnPlus).click();
        docFieldValues.add(value);
    }


    /**
     * Method to verify doc field attribute value and trash icon are displayed in edit inline window
     */
    public boolean verifyFieldValue(String value) {
        String xpath = "//div[text()='" + value + "']";
        commonMethods.getElementInViewAndUp(txtBoxSearch);
        return $(By.xpath(xpath)).isDisplayed() && $(By.xpath(xpath + "/following-sibling::div/div[@class='auiIcon trash']")).isDisplayed();
    }

    /**
     * Method to verify field value is displayed in edit inline window
     */
    public void deleteFieldValue(String value) {
        commonMethods.getElementInViewAndUp(txtBoxSearch);
        String xpath = "//div[text()='" + value + "']";
        By element = By.xpath(xpath + "/following-sibling::div/div[@class='auiIcon trash']");
        commonMethods.waitForElement(driver, element);
        $(element).click();
        commonMethods.waitForElementExplicitly(1000);
    }

    /**
     * Method to verify selected dropdown value
     */
    public String verifyDropdownFields(String fieldName) {
        By dropdownElement;
        if (fieldName.startsWith("label_"))
            dropdownElement = By.xpath("//form[@name='uploadForm']//label[text()='" + commonMethods.getLabelName(fieldName) + "']/../following-sibling::div//select");
        else
            dropdownElement = By.xpath("//form[@name='uploadForm']//div/acx-single-select-field/select[contains(@title,'" + fieldName + "')]");
        commonMethods.waitForElement(driver, dropdownElement, 10);
        return $(dropdownElement).getSelectedText();
    }

    /**
     * Method to verify pencil icon displayed for document fields in bulk edit tab
     */
    public boolean verifyPencilIcon(String field) {
        return $(By.xpath("//form[@name='form.bulkEditForm']//label[text()='" + field + "']/../following-sibling::div//span[@title='Edit " + field + " values']")).isDisplayed();
    }

    /**
     * Method to click on pencil icon displayed for document fields in bulk edit tab
     */
    public void clickOnPencilIcon(String field) {
        $(By.xpath("//form[@name='form.bulkEditForm']//label[text()='" + field + "']/../following-sibling::div//span[@title='Edit " + field + " values']")).click();
    }

    /**
     * Method to fill fields in table view
     */
    public void fillTableViewFields(String fieldName, String fieldValue, String fieldTypes, int row) {
        commonMethods.waitForElement(driver, tblViewHeaders, 30);
        String name = "";
        switch (fieldTypes.toLowerCase()) {
            case "dropdown":
                String path = "//div[@class='ag-center-cols-container']/div[" + row + "]/div[contains(@col-id,'" + fieldName + "')]";
                $(By.xpath(path)).click();
                commonMethods.enterDropdownValue(By.xpath(path + "//select"), fieldValue);
                commonMethods.waitForElementExplicitly(2000);
                break;
            case "text":
                String xpath = "//div[@class='ag-center-cols-container']/div[" + row + "]/div[contains(@col-id,'" + fieldName + "')]";
                commonMethods.waitForElementClickable(driver, By.xpath(xpath), 60);
                $(By.xpath(xpath)).doubleClick();
                commonMethods.waitForElementExplicitly(2000);
                commonMethods.enterTextValue(By.xpath(xpath + "//input"), fieldValue);
                break;
            case "select list":
                fillSelectList(fieldName, fieldValue, row);
                break;
        }
        $(associatedFile).click();
    }

    /**
     * Method to fill select list fields in table view
     */
    public void fillSelectList(String name, String value, int row) {
        By xpath = By.xpath("//div[@class='ag-center-cols-container']/div[" + row + "]/div[contains(@col-id,'" + name.replace(" ", "").toLowerCase().trim() + "')]");
        commonMethods.waitForElementExplicitly(5000);
        $(xpath).click();
        By xpath1 = By.xpath("//acx-multi-select-field/aui-select[contains(@title,'" + name + "')]//input");
        commonMethods.waitForElement(driver, xpath1, 30);
        $(xpath1).click();
        commonMethods.enterTextValue(xpath1, value);
        commonMethods.waitForElementExplicitly(1000);
        $(xpath1).sendKeys(Keys.ENTER);
        $(btnApply).click();
    }

    /**
     * Method to verify document no uniqueness error message
     */
    public void verifyUniqueDocError() {
        commonMethods.waitForElement(driver, txtDocUniqueError, 10);
        Assert.assertTrue($(txtDocUniqueError).isDisplayed());
    }

    /**
     * Method to return table view document count
     */
    public int getTableViewFilesCount() {
        $(loadingIcon).should(disappear);
        commonMethods.waitForElement(driver, tblViewHeaders, 60);
        return $$(files).size();
    }

    /**
     * Method to get All document numbers from table view
     */
    public List<String> getDocumentNo() {
        commonMethods.waitForElement(driver, tblViewDocNo, 60);
        return commonMethods.getValues(tblViewDocNo);
    }

    /**
     * Method to fill random document no in table view for all rows
     */
    public void fillDocumentNo() {
        commonMethods.waitForElement(driver, tblViewDocNo, 60);
        List<WebElement> elements = new ArrayList<>($$(tblViewDocNo));
        fillDocumentNo(elements.get(0), commonMethods.getRandomString(10));
        CommonMethods.randomString = "";
        sortDocumentNo();
        commonMethods.waitForElementExplicitly(2000);
        for (int i = elements.size() - 1; i >= 0; i--) {
            commonMethods.waitForElementExplicitly(1000);
            fillDocumentNo(elements.get(i), commonMethods.getRandomString(10));
            CommonMethods.randomString = "";
        }
        fillDocumentNo(elements.get(0), commonMethods.getRandomString(10));
    }

    /**
     * Method to sort the document field in table view
     */
    private void sortDocumentNo() {
        verifyAndSwitchFrame();
        $(lblDocumentNo).click();
    }

    /**
     * Method to fill random document no in table view for all rows
     */
    public void fillDocumentNo(WebElement element, String docNum) {
        if (!$(element).getText().contains("Auto assigned")) {
            $(element).doubleClick();
            commonMethods.waitForElementExplicitly(1000);
            commonMethods.waitForElement(driver, txtBoxDocNo);
            commonMethods.enterTextValue(txtBoxDocNo, docNum);
            commonMethods.waitForElementExplicitly(1000);
            $(associatedFile).click();
            commonMethods.waitForElementExplicitly(3000);
        }
    }

    /**
     * Method to get auto assigned from document field
     */
    public String getAutoAssigned() {
        return $(docNoAutoAssigned).getValue();
    }

    /**
     * Method to get document no unique error message from table view
     */
    public String verifyDocError() {
        commonMethods.waitForElement(driver, tblViewHeaders);
        return $(lblDocUniqueError).getAttribute("title");
    }

    /**
     * Method to get mandatory fields error count
     */
    public int getErrorFieldCount() {
        return $$(docFieldMandatoryError).size();
    }

    /**
     * Method to get mandatory fields list in table view in unified upload screen
     */
    public int getMandatoryFields(int row) {
        return $$(By.xpath("//div[@class='ag-center-cols-container']/div[" + row + "]/div[contains(@class,'required-cell')]")).size();
    }

    /**
     * Method to get Document field order
     */
    public List<String> getDocFieldsOrder() {
        return commonMethods.getValues(docFieldLabels);
    }
    /**
     * Method to get Document field order from Document properties
     */
    public List<String> getDocFieldsOrderFromDocProp() {
        return commonMethods.getValues(docFieldLabelsFromProp);
    }

    /**
     * Function to store applied fields as per document properties field
     */
    public void appliedFieldsAsperInDocProp(List<String> data) {
        data.remove(1);
        data.remove(2);
        String fields[]={"Review Status","Version","Review Source"};
        for(String field:fields)
            DocumentTypePage.appliedFieldsList.add(field);
    }
    /**
     * Method to get bulk edit field order
     */
    public List<String> getBulkEditFieldsOrder() {
        return commonMethods.getValues(bulkEditFields);
    }

    /**
     * Method to get mandatory fields list in unified upload screen
     */
    public List<String> getMandatoryFields() {
        List<String> values = new LinkedList<>();
        List<WebElement> elements = new LinkedList<>($$(mandatoryFields));
        for(WebElement element : elements) {
            values.add(element.getText());
        }
        return values;
    }

    /**
     * Method to get mandatory fields list in bulk edit tab
     */
    public List<String> getBulkEditMandatoryFields() {
        return commonMethods.getValues(bulkEditMandatoryFields);
    }

    /**
     * Method to attach import meta document
     */
    public void attachImportMetaDoc(String fileName) {
        String filePath = configFileReader.getTestDataPath() + fileName;
        File file = new File(filePath);
        filePath = file.getAbsolutePath();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, importMetaDataPopUp, 60);
        $(importMetaDataFile).sendKeys(filePath);
        commonMethods.waitForElement(driver,metaDatafileSelected,60);
    }

    /**
     * Method to verify upload Documents page options
     */
    public void verifyUploadDocTableView(String docType) {
        verifyAndSwitchFrame();
        Assert.assertTrue($(uploadBtn).isDisplayed());
        Assert.assertTrue($(cancelBtn).isDisplayed());
        Assert.assertTrue($$(btnRemove).get(1).isDisplayed());
        Assert.assertTrue($(lnkTellUsWhatYouThink).isDisplayed());
        Assert.assertTrue($$(addMoreBtn).get(1).isDisplayed());
        Assert.assertTrue($$(bulkSupersedePage.bulkEditBtn).get(1).isDisplayed());
        Assert.assertTrue($(btnTableView).isDisplayed());
        commonMethods.waitForElementExplicitly(3000);
        Assert.assertTrue($(btnListView).isDisplayed());
        commonMethods.waitForElementExplicitly(1000);
        if (!docType.equalsIgnoreCase("placeholder")) {
            Assert.assertTrue($(saveTempFiles).isDisplayed());
            Assert.assertTrue($$(importMetaData).get(1).isDisplayed());
        }
    }

    /**
     * Method to click on add more files button
     */
    public void clickAddMoreTableView() {
        commonMethods.waitForElementExplicitly(3000);
        $$(addMoreBtn).get(1).click();
    }

    /**
     * Method to verify import metadata enabled in table view
     */
    public boolean importMetaDataTableView() {
        commonMethods.waitForElementExplicitly(4000);
        return $$(importMetaData).get(1).isEnabled();
    }

    /**
     * Method to click on import metadata table view
     */
    public void clickImpMetDatTableView() {
        commonMethods.waitForElementExplicitly(3000);
        $$(importMetaData).get(1).click();
    }

    /**
     * Method to get the attribute value
     */
    public boolean getAttributeValue(String attributeValue) {
        return $(attribute1).getText().equals(attributeValue);
    }

    /**
     * Method to click on pencil icon displayed next to document number field
     */
    public void clickDocPencilIcon() {
        $(docPencilIcon).click();
    }

    /**
     * Method to update document number
     */
    public void updateDocumentNo(String docNum) {
        commonMethods.enterTextValue(txtBoxDocNum, docNum);
    }

    /**
     * Method to update uploaded file in unified upload screen
     */
    public void replaceDocument(String fileName) {
        $(documentReplacePanel).sendKeys(new File(configFileReader.getTestDataPath() + fileName).getAbsolutePath());
    }

    /**
     * Method to attach a document from a given folder and filename
     */
    public void attachDocument(String path, String fileName) {
        commonMethods.waitForElementExplicitly(3000);
        $(documentAttachPanel).sendKeys(new File(path + fileName).getAbsolutePath());
    }

    /**
     * Method to verify the table view displayed
     */
    public boolean verifyUUTableView() {
        return $(btnTableView).isDisplayed();
    }

    /**
     * Method to verify disabled dropdown fields in bulk edit window
     */
    public String verifyDisableFieldsInBulkEdit(String name) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, type, 60);
        if (name.startsWith("label_"))
            return $(By.xpath("//form[@name='form.bulkEditForm']//label[text()='" + commonMethods.getLabelName(name) + "']/../following-sibling::div//acx-single-select-field//select")).getAttribute("disabled");
        else
            return $(By.xpath("//form[@name='form.bulkEditForm']//div/acx-single-select-field/select[@title='" + name + "']")).getAttribute("disabled");
    }

    /**
     * Function to get all dropdown field values present in bulk edit window
     *
     * @return
     */
    public List<String> getValuesInBulkEdit(String fieldName) {
        verifyAndSwitchFrame();
        if (fieldName.startsWith("label_"))
            return getDropdownValues("//form[@name='form.bulkEditForm']//label[text()='" + commonMethods.getLabelName(fieldName) + "']/../following-sibling::div//select");
        else
            return getDropdownValues("//form[@name='form.bulkEditForm']//div/acx-single-select-field/select[@title='" + fieldName + "']");
    }

    /**
     * Function to get all dropdown field values present in bulk edit window and upload screen
     *
     * @return
     */
    public List<String> getDropdownValues(String xpath) {
        commonMethods.waitForElementClickable(driver, By.xpath(xpath), 30);
        navigator.getElementInView(By.xpath(xpath));
        return commonMethods.getValues(By.xpath(xpath + "/option"));
    }

    /**
     * Method to verify selected dropdown value in bulk edit window
     */
    public String verifyDropdownValue(String fieldName) {
        By dropdownElement;
        if (fieldName.startsWith("label_"))
            dropdownElement = By.xpath("//form[@name='form.bulkEditForm']//label[text()='" + commonMethods.getLabelName(fieldName) + "']/../following-sibling::div//select");
        else
            dropdownElement = By.xpath("//form[@name='form.bulkEditForm']//div/acx-single-select-field/select[contains(@title,'" + fieldName + "')]");
        commonMethods.waitForElement(driver, dropdownElement, 10);
        return $(dropdownElement).getSelectedText();
    }

    /**
     * Method to click on the file names
     */
    public void clickFileNames(int fileNo) {
        $(By.xpath("//div[@class='files']//li[" + fileNo + "]")).click();
    }

    /**
     * Method to upload a document in document register and save in temporary file
     *
     * @param attribute attributes of upload document
     */
    public void uploadAndSaveInTempFile(String attribute) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(5000);
        chooseFile(attribute);
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, type, 60);
        fillFields(attribute);
        clickSaveTempFiles();
    }

    /**
     * Method to select the discipline
     *
     * @param disciplineStr
     */
    public void selectDiscipline(String disciplineStr) {
        commonMethods.enterDropdownValue(discipline, disciplineStr);
    }

    /**
     * Method to return the vdr code
     *
     * @return
     */
    public List<String> returnVdrCode() {
        return commonMethods.returnAllOptionsInDropDown(driver, vdrCode);
    }
}