package com.oracle.babylon.pages.Setup.ProjectSettings;

import com.oracle.babylon.Utils.helper.Navigator;
import com.oracle.babylon.pages.Setup.ProjectSettingsPage;
import com.oracle.babylon.pages.Setup.UserManagementPage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import java.util.*;

import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class MailTypes extends ProjectSettingsPage {

    private By mailMenu = By.xpath("//span[contains(text(),'Mail')]");
    private By mailTypes = By.xpath("//div[contains(text(),'Mail Types')]");
    private By responseRequiredChkBox = By.xpath("//tr[@class='top-align ng-scope']//td//input");
    private By saveBtn = By.xpath("//button[contains(text(),'Save')]");
    private By mailTypeHeader = By.xpath("//h1[contains(text(),'Welcome to Mail Types.')]");
    private By searchProjectFields = By.xpath("//input[@placeholder='Search Project Fields']");
    //private By editIcon = By.xpath("//div[@class='icon icon-edit list-group-item-icon pull-left']");
    private By editIcon = By.xpath("//div[@class='auiIcon edit list-group-item-icon pull-left']");
    private By noResults = By.xpath("//div[contains(text(),'0 results found')]");
    private By newFieldBtn = By.xpath("//button[contains(text(),'+ New Field')]");
    private By plusIcon = By.xpath("//div[@class='auiIcon add list-group-item-icon pull-right']");
    private By newFieldMsg = By.xpath("//div[contains(text(),'Create a new project field by completing the fields below')]");
    private By typeField = By.xpath("//label[contains(text(),'Type')]");
    private By labelField = By.xpath("//label[contains(text(),'Label')]");
    private By tooltipField = By.xpath("//label[contains(text(),'Tool Tip')]");
    private By fieldName = By.xpath("//label[contains(text(),'Field Name')]");
    private By cancelBtn = By.xpath("//button[contains(text(),'Cancel')]");
    private By newFieldSaveBtn = By.xpath("//div[@class='modal-footer ng-scope']//button[contains(text(),'Save')]");
    private By selectType = By.xpath("//select[@name='type']");
    private By inputLabel = By.xpath("//input[@type='text'][@name='label'][@maxlength='40']");
    private By expandArrow = By.xpath("//span[@class='icon icon-expando collapsibleSection-headerArrow ng-scope']");
    private By collapseArrow = By.xpath("//span[@class='icon icon-expando collapsibleSection-headerArrow ng-scope expanded-downwards']");
    private By fieldNameTag = By.xpath("//div[contains(text(),'Field Name')]");
    private By mandatoryCheckbox = By.xpath("//tr[@class='top-align ng-scope']//td//input[@ng-disabled='field.inUse']");
    private By projectFieldCheckbox = By.xpath("//input[@ng-click='select(field)']");
    private By removeBtn = By.xpath("//button[contains(text(),'Remove')]");
    private By noProjectFieldMsg = By.xpath("//p[contains(text(),'No Project Fields assigned')]");
    private By backBtn = By.xpath("//button[@title='Back']");
    private By leavePage = By.xpath("//button[contains(text(),'Leave Page')]");
    private By continueEditing = By.xpath("//button[contains(text(),'Continue Editing')]");
    private By mailFormsPage = By.xpath("//span[contains(text(),'Mail Forms')]");
    private By message1 = By.xpath("//div[contains(text(),'Changes you make to this Project Field will')]");
    private By message2 = By.xpath("//li[contains(text(),'apply to any Field Issues that use')]");
    private By message3 = By.xpath("//li[contains(text(),'affect the following Mail Types')]");
    private By message4 = By.xpath("//li[contains(text(),'affect the following Document Types')]");
    private By firstCheckBox = By.xpath("//table[@class='auiTable']//tr[1]//input[@ng-checked='isSelected(field)']");
    private By secondCheckBox = By.xpath("//table[@class='auiTable']//tr[2]//input[@ng-checked='isSelected(field)']");
    private By firstLabel = By.xpath("//table[@class='auiTable']//tr[1]//a");
    private By secondLabel = By.xpath("//table[@class='auiTable']//tr[2]//a");
    private By downArrow = By.xpath("//button[@ng-click='moveDown()']");
    private String lnkeditRule = "//a[text()='Edit Rules']";
    private By sltMailType = By.xpath("//select[@name='mailTypes']");
    private By btnBackArrow = By.xpath("//button[@title='Back']");
    private By tabGeneralRules = By.xpath("//div[@class='auiTabs']//a/span[text()='General Rules']");
    private By tabActiveTab = By.xpath("//div[@class='auiTabs']//a[contains(@class,'active')]");
    private By tabDistributionRules = By.xpath("//div[@class='auiTabs']//a/span[text()='Distribution Rules']");
    private By frameProjectSettings = By.xpath("//iframe[@id='project-settings-page']");
    private By tblMailTypes = By.xpath("//table[@class='auiTable']//tr");
    private By lblPreventMail = By.xpath("//label[contains(text(),'Prevent an emailed')]");
    private By lblAllowMail = By.xpath("//label[contains(text(),'Allow user')]");
    private By chkboxPreventMail = By.xpath("//label[contains(text(),'Prevent an emailed')]/input");
    private By chkboxAllowMail = By.xpath("//label[contains(text(),'Allow user')]/input");
    private By lblForwardAs = By.xpath("//b[text()='Forward']/parent::div[contains(text(),'as:')]");
    private By lblReplyWith = By.xpath("//b[text()='Reply']/parent::div[contains(text(),'with:')]");
    private String lblanyMailType = "/parent::div/following-sibling::div//label[contains(text(),'Any mail type')]";
    private By btnReplyInfo = By.xpath("//b[text()='Reply']/parent::div/following-sibling::div//div[@id='Reply']");
    private By btnForwardInfo = By.xpath("//b[text()='Forward']/parent::div/following-sibling::div//div[@id='Forward']");
    private By btnReplyStatusInfo = By.xpath("//b[text()='Reply']/parent::div/parent::form/div//div[@class='icon icon-info statusPopup']");
    private By btnForwardStatusInfo = By.xpath("//b[text()='Forward']/parent::div/parent::form/div//div[@class='icon icon-info statusPopup']");
    private By txtForwardInfo = By.xpath("//*[contains(text(),'Forwarded mail will update the status of mail requiring a response')]");
    private By txtRepliesInfo = By.xpath("//*[contains(text(),'Replies will update the status of mail requiring a response')]");
    private By txtStatusInfo = By.xpath("//*[contains(text(),'When set to \"Yes\" the mail type will update the status to  Responded')]");
    private String lblCustom = "/parent::div/following-sibling::div//label[contains(text(),'Custom')]";
    private By btnSave = By.xpath("//button[contains(text(),'Save')]");
    private By frameMailRules = By.xpath("//iframe[@class='mailRulesFrame']");
    private By popupMailTypes = By.xpath("//div[@class='modal-content']");
    private By txtMailTypes = By.xpath("//h3[text()='Mail Types']");
    private By btnOk = By.xpath("//button[@title='OK and close window']");
    private By btnCancel = By.xpath("//button[contains(text(),'Cancel')]");
    private String sltAvailableTypes = "//div[@class='bidi-available']//select";
    private String sltSelectedTypes = "//div[@class='bidi-selected']//select";
    private By btnCreateNewRule = By.xpath("//button[contains(text(),'Create New Rule')]");
    private By lblNoDistributionRules = By.xpath("//div[contains(text(),'No distribution rules have been configured')]");
    private By hdrCreateNewRule = By.xpath("//h3[contains(text(),'Create New Rule')]");
    private By lblWhen = By.xpath("//span[contains(text(),'When')]");
    private By lblIf = By.xpath("//span[contains(text(),'IF')]");
    private By lblThen = By.xpath("//span[contains(text(),'Then')]");
    private By lblConditionDef = By.xpath("//span[contains(text(),'Initiating, replying with or forwarding as')]");
    private String sltIfCategory = "//acx-rule-creation-condition//select[@ng-model='field']";
    private String sltIfCondition = "//acx-rule-creation-condition//select[@ng-model='operator']";
    private String sltThenCategory = "//div[@class='condition-definition ng-scope']//span/select[@ng-model='distribution.channel']";
    private String sltThenCondition = "//div[@class='condition-definition ng-scope']//span/select[@ng-model='recipient']";
    private String txtUsers = "//acx-rule-creation-condition//input";
    private String txtGroups = "//acx-rule-creation-add-groups//input";
    private String txtThenUser = "//div[@place-holder='addUserPlaceHolderForThen']//input";
    private String txtThenGroup = "//acx-rule-creation-add-groups[@place-holder='addGroupPlaceHolderForThen']//input";
    private By btnNewFieldSave = By.xpath("//button[@name='saveButton']");
    private String lstUsers = "//div[contains(@class,'ui-select-choices-row ng-scope')]";
    private String btnRemove = "//div[@class='distribution-action icon icon-remove ng-scope']";
    private By lnkIfAnd = By.xpath("//div[@class='andCondition ng-scope']//parent::div//a[contains(text(),'+ And')]");
    private By lnkIfOr = By.xpath("//div[@class='andCondition ng-scope']//parent::div//a[contains(text(),'+ Or')]");
    private By lnkThenAnd = By.xpath("//div[@class='condition-definition ng-scope']//parent::div//a[contains(text(),'+ And')]");
    private By lblIfAnd = By.xpath("//div[@class='andCondition ng-scope']//parent::div//span[contains(text(),'And')]");
    private By lblIfOr = By.xpath("//div[@class='andCondition ng-scope']//parent::div//span[contains(text(),'Or')]");
    private By lblThenAnd = By.xpath("//div[@class='condition-definition ng-scope']//parent::div//span[contains(text(),'And')]");
    private By btnEditRule = By.xpath("//div[@class='card rules draggable ng-scope']//span[@class='icon icon-edit editButton']");
    private String btnDeleteRule = "//div[@class='card rules draggable ng-scope']//span[@class='icon icon-remove']";
    private By lblDeleteRule = By.xpath("//h3[contains(text(),'Delete Rule')]");
    private By btnDelete = By.xpath("//button[contains(text(),'Delete')]");
    private By tblCustomFields = By.xpath("//div[@fields='mailTypeCustomFields']//table[@class='auiTable']//tr");
    private String lblErrorMessage = "//span[@title='Field removed from mail type']";
    private By lblMailType = By.xpath("//th[contains(text(),'Mail Type')]");
    private By btnPreventEmailInfo = By.xpath("//div[@id='preventEmailPopover']");
    private By txtPreventEmailInfo = By.xpath("//*[contains(text(),'This setting excludes email replies sent using the Outlook Plugin')]");
    private By selectFirstField = By.xpath("//div[@fields='mailTypeCustomFields']//table[@class='auiTable']//tr[1]//td[1]/input");
    private By chkBoxSelectAll = By.xpath("//div[@fields='mailTypeCustomFields']//table[@class='auiTable']//th[1]");
    private By hdrRestrictedFields = By.xpath("//h1[@class='auiToolbar-header']");
    private By hdrAssociatedFields = By.xpath("//div[@class='associatedFilteredCustomFields']//div[@class='text ng-binding']");
    private By messageToolTip = By.xpath("//span[contains(text(),'You can include a tooltip with this field to give users more information about how it should be used.')]");
    private By btnToolTip = By.xpath("//button[@title='More information']");
    private By txtBoxToolTip = By.xpath("//div[@class='form-field']/textarea");
    private By hdrEditFieldPermission = By.xpath("//h3[contains(text(),'Edit Field Value Permission')]");
    private By btnSelectedRole = By.xpath("//table//div/label[contains(text(),'Selected roles')]/../input");
    private By btnAllUsers = By.xpath("//table//div/label[contains(text(),'All Users')]/../input");
    private By firstCell = By.xpath("//table//tbody//td[1]");
    private By editResponseRequired = By.xpath("//div[@id='defaultDurationDetails']/a");
    private By btnSetResponseTime = By.xpath("//span[contains(text(),'Set response time frame for')]/../input");
    private By txtBoxTimeFrame = By.xpath("//div[@class='form-field-value']//input");
    private By timeFrameToolTip = By.xpath("//div[@class='form-field-value']//textarea");
    private By message5 = By.xpath("//li[contains(text(),'affect the following Package Types')]");
    private By message6 = By.xpath("//li[contains(text(),'affect the following Field Issue Types')]");
    private By restrictions = By.xpath("//div[@class='restriction']");
    private By editRestriction = By.xpath("//div[@class='card distribution-restriction-container']//span[@class='icon icon-edit editRestrictions']");
    private By hdrDistributionRestrictions = By.xpath("//h3/*[text()='Distribution Restrictions']");
    private By btnAllowRecipients = By.xpath("//label[contains(text(),'Sender can add to list of recipients')]/input");
    private By btnNotAllowRecipients = By.xpath("//label[contains(text(),'Sender cannot add or remove recipients')]/input");
    private By lblAllowRecipients = By.xpath("//label[contains(text(),'Sender can add to list of recipients')]");
    private By lblNotAllowRecipients = By.xpath("//label[contains(text(),'Sender cannot add or remove recipients')]");
    private By txtNotAllowRestrcition = By.xpath("//span[text()='Sender cannot add or remove recipients']");
    private By txtAllowRestrcition = By.xpath("//span[text()='Sender can add to list of recipients']");

    Map<String, Map<String, Object>> mapOfMap = new Hashtable<>();
    String projectFieldsPath = configFileReader.getProjectFieldsDataPath();
    Actions action = new Actions(driver);
    Navigator navigator = new Navigator();
    UserManagementPage userManagementPage = new UserManagementPage();

    /**
     * method to navigate to Mail Types page
     */

    public void navigateToMailTypes() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, mailMenu, 8);
        $(mailMenu).click();
        commonMethods.waitForElement(driver, mailTypes, 8);
        $(mailTypes).click();
        verifyPageTitle("Project Settings");
    }

    /**
     * method to Edit Mail Types
     *
     * @param mailTypeName
     */

    public void editMailTypes(String mailTypeName) {
        switchProjectSettingsFrame();
        By mailType = By.xpath("//tr[@id='" + mailTypeName + "']//td//a[contains(text(),'Edit Mail Forms')]");
        commonMethods.waitForElement(driver, mailType, 25);
        $(mailType).click();
        commonMethods.waitForElement(driver, searchProjectFields, 20);
    }

    /**
     * method to set response required field based on the condition
     *
     * @param condition
     */

    public void setResponseRequired(boolean condition) {
        commonMethods.waitForElementExplicitly(2000);
        $(responseRequiredChkBox).setSelected(condition);
        $(saveBtn).click();
    }

    /**
     * Function to search the project fields present on the left side of the mail page
     *
     * @param label
     */

    public void searchProjectFields(String label) {
        $(searchProjectFields).clear();
        $(searchProjectFields).sendKeys(label);
    }

    /**
     * Function to verify the fields present on the search project fields of particular Mail Type
     */

    public void verifyFields() {
        Assert.assertTrue($(searchProjectFields).isDisplayed());
        Assert.assertTrue($(plusIcon).isDisplayed());
        Assert.assertTrue($(editIcon).isDisplayed());
        Assert.assertTrue($(newFieldBtn).isDisplayed());
    }

    /**
     * Function to click on the New Field button present on the left side of project fields section
     */

    public void clickNewField() {
        $(newFieldBtn).click();
    }

    /**
     * Function to verify the New Field created Mail Forms page
     */

    public void verifyNewField() {
        Assert.assertTrue($(newFieldMsg).isDisplayed());
        Assert.assertTrue($(typeField).isDisplayed());
        Assert.assertTrue($(labelField).isDisplayed());
        Assert.assertTrue($(tooltipField).isDisplayed());
        Assert.assertTrue($(fieldName).isDisplayed());
        Assert.assertTrue($(cancelBtn).isDisplayed());
        Assert.assertTrue($(newFieldSaveBtn).isDisplayed());
    }

    /**
     * Function to select Type Field after clicking on New Field button
     *
     * @param value
     */

    public void selectDataType(String value) {
        $(selectType).selectOptionContainingText(value);
    }

    /**
     * Function to verify the project Field on the right side of the page after clicking on plus icon
     *
     * @param fieldName
     * @return
     */

    public boolean verifyFieldPresent(String fieldName) {
        commonMethods.waitForElementExplicitly(3000);
        String labelName = commonMethods.returnFromJson(fieldName, "field_name", projectFieldsPath);
        return $(By.xpath("//h4[contains(text(),'" + labelName + "')]")).isDisplayed();
    }

    /**
     * Function to verify the messages for new label given after editing the present label
     */

    public void verifyLabel() {
        commonMethods.waitForElement(driver, message1, 45);
        Assert.assertTrue($(message1).isDisplayed());
        commonMethods.waitForElement(driver, message3, 45);
        Assert.assertTrue($(message3).isDisplayed());
    }

    /**
     * Function to edit the project field and provide a new name
     *
     * @param labelName
     */

    public void editLabel(String labelName) {
        $(editIcon).click();
        $(inputLabel).clear();
        String newLabel = faker.name().firstName() + faker.number().digits(2);
        $(inputLabel).sendKeys(newLabel);
        commonMethods.writeToJson("field_name", labelName, newLabel, projectFieldsPath);
    }

    /**
     * Function to click on the save Button after editing the field name in create New Field pop up
     */

    public void clickSaveBtn() {
        navigator.getElementInView(saveBtn);
        $(saveBtn).click();
    }

    /**
     * Function to verify the no results message when user searches for the project field which does not exists
     *
     * @return
     */

    public boolean verifyNoResults() {
        return $(noResults).isDisplayed();
    }

    /**
     * Function to click plus icon present under the project fields section in Mail Forms page
     *
     * @return
     */

    public void clickPlusIcon() {
        commonMethods.waitForElement(driver, plusIcon, 45);
        $(plusIcon).click();
    }

    /**
     * Method to add the project field to the mail type based on the label name
     *
     * @param label
     */
    public void clickPlusIcon(String label) {
        By by = By.xpath("//h4[text()='" + label + "']//..//div[2]");
        commonMethods.waitForElement(driver, by, 45);
        $(by).click();
    }

    /**
     * Function to verify plus icon is present under the project fields section in Mail Forms page
     *
     * @return
     */
    public boolean verifyPlusIcon() {
        return $(plusIcon).isDisplayed();
    }

    /**
     * Function to verify the project Fields are displayed correctly on the right side os Mail Form page
     * after clicking on plus icon
     *
     * @param label
     */

    public void checkProjectField(String label) {
        Assert.assertTrue($(By.xpath("//a[contains(text(),'" + label + "')]")).isDisplayed());
        $(expandArrow).click();
        Assert.assertTrue($(fieldNameTag).isDisplayed());
        Assert.assertTrue($(By.xpath("//table//tbody//tr/td//div//a[contains(text(),'" + label + "')]")).isDisplayed());
    }

    /**
     * Function to verify the details of project Fields are collapsed on clicking on collapsable icon
     *
     * @param label
     */

    public void verifyCollapsableField(String label) {
        commonMethods.waitForElementExplicitly(3000);
        $(collapseArrow).click();
        Assert.assertFalse($(fieldNameTag).isDisplayed());
        Assert.assertFalse($(By.xpath("//div[contains(text(),'" + label + "')]")).isDisplayed());
    }

    /**
     * Function to click on the mandatory checkbox present on the mail forms page
     */

    public void clickMandatoryCheckbox() {
        $(mandatoryCheckbox).setSelected(true);
    }

    /**
     * Function to click on the mandatory checkbox present on the mail forms page
     */
    public void clickMandatoryCheckbox(String fieldName, String option) {
        List<WebElement> elements = new ArrayList<>($$(tblCustomFields));
        for (int i = 1; i < elements.size(); i++) {
            if ($(By.xpath("//div[@fields='mailTypeCustomFields']//table[@class='auiTable']//tr[" + i + "]//a")).getText().equalsIgnoreCase(fieldName)) {
                $(By.xpath("//div[@fields='mailTypeCustomFields']//table[@class='auiTable']//tr[" + i + "]//td[4]/input")).setSelected(Boolean.parseBoolean(option));
                break;
            }
        }
    }

    /**
     * Function to remove the project field added to the mail type
     */

    public void removeProjectField() {
        $(projectFieldCheckbox).setSelected(true);
        $(removeBtn).click();
    }

    /**
     * Function to remove the project field associated with field name
     */

    public void removeProjectField(String fieldName) {
        List<WebElement> elements = new ArrayList<>($$(tblCustomFields));
        for (int i = 1; i < elements.size(); i++) {
            if ($(By.xpath("//div[@fields='mailTypeCustomFields']//table[@class='auiTable']//tr[" + i + "]//a")).getText().equalsIgnoreCase(fieldName)) {
                $(By.xpath("//div[@fields='mailTypeCustomFields']//table[@class='auiTable']//tr[" + i + "]//td[1]/input")).setSelected(true);
                $(removeBtn).click();
                break;
            }
        }
    }

    /**
     * Function to remove all project fields associated to mail type
     */
    public void removeAllProjectFields() {
        commonMethods.waitForElementExplicitly(2000);
        $(chkBoxSelectAll).click();
        commonMethods.waitForElementExplicitly(1000);
        $(removeBtn).click();
    }

    /**
     * Function to verify the the message after removing the project fields in mail form page
     *
     * @return
     */

    public boolean verifyNoProjectField() {
        return $(noProjectFieldMsg).isDisplayed();
    }

    /**
     * Function to click on the project fields back button present on the right side of mail forms page
     */

    public void clickProjFieldsBckBtn() {
        $(backBtn).click();
    }

    /**
     * Function to click on continue editing button on clicking back button pop up
     */

    public void clickContinueEditing() {
        $(continueEditing).click();
    }

    /**
     * Function to verify mail forms page is displayed
     *
     * @return
     */

    public boolean verifyMailFormsPage() {
        return $(mailFormsPage).isDisplayed();
    }

    /**
     * Function to click on leave page button on the pop of back button in mail forms page
     */

    public void clickLeavePage() {
        $(leavePage).click();
    }

    /**
     * Function to verify mail Types page is displayed
     *
     * @return
     */

    public boolean verifyMailTypesPage() {
        commonMethods.waitForElement(driver, mailTypeHeader, 45);
        return $(mailTypeHeader).isDisplayed();
    }

    /**
     * Function to move fields present on the right side of mail forms page
     */

    public void moveFields() {
        $(firstCheckBox).setSelected(true);
        $(downArrow).click();
    }

    /**
     * Function to verify the sorting of project fields after clicking on the upward arrow
     *
     * @param actfields
     * @param count
     * @return
     */

    public boolean verifyProjectFields(String[] actfields, int count) {
        List<String> fields = new ArrayList<>();
        commonMethods.waitForElementExplicitly(1500);
        for (int i = 1; i <= count; i++) {
            By by = By.xpath("//table[@class='auiTable']//tr[" + i + "]//a");
            commonMethods.waitForElement(driver, by);
            fields.add($(by).getText());
        }
        String[] allFields = Arrays.copyOf(fields.toArray(), fields.size(), String[].class);
        if (Arrays.equals(actfields, allFields)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Method to navigate to Edit Rules
     */
    public void navigateToEditRules(String type) {
        commonMethods.waitForElement(driver, lblMailType, 30);
        $(By.xpath("//table//td[text()='" + type + "']//parent::tr//a[text()='Edit Rules']")).click();
        $(loadingIcon).should(disappear);
        commonMethods.waitForElement(driver, sltMailType, 10);
    }

    /**
     * Method to verify general rules tab fields
     */
    public void verifyGROptions(String type) {
        verifyGeneralOptions(type);
        commonMethods.switchToFrame(driver, frameMailRules);
        switch (type.toLowerCase()) {
            case "internal memorandum":
            case "addendum":
            case "variant":
                Assert.assertTrue($(chkboxAllowMail).isDisplayed());
                Assert.assertTrue($(lblAllowMail).isDisplayed());
            default:
                Assert.assertTrue($(btnSave).isDisplayed());
                Assert.assertTrue($(chkboxPreventMail).isDisplayed());
                Assert.assertTrue($(lblPreventMail).isDisplayed());
                verifyForwardAsFields();
                verifyReplyWithFields();
                break;
        }
    }

    /**
     * Method to verify distribution rules tab fields
     */
    public boolean verifyDROptions(String type) {
        verifyGeneralOptions(type);
        switchToMailRulesFrame();
        return $(btnCreateNewRule).isDisplayed();
    }

    /**
     * Method to verify options in edit rules
     */
    public void verifyGeneralOptions(String type) {
        switchProjectSettingsFrame();
        Assert.assertTrue($(sltMailType).isDisplayed());
        Assert.assertEquals($(sltMailType).getSelectedOption().getText(), type);
        Assert.assertTrue($(btnBackArrow).isDisplayed());
        Assert.assertTrue($(tabGeneralRules).isDisplayed());
        Assert.assertTrue($(tabActiveTab).isDisplayed());
    }

    /**
     * Method to verify Forward as options in edit rules
     */
    public void verifyForwardAsFields() {
        Assert.assertTrue($(lblForwardAs).isDisplayed());
        Assert.assertTrue($(By.xpath("//b[text()='Forward']" + lblanyMailType)).isDisplayed());
        Assert.assertTrue($(By.xpath("//b[text()='Forward']" + lblCustom)).isDisplayed());
        Assert.assertTrue($(By.xpath("//b[text()='Forward']" + lblanyMailType + "/input")).isDisplayed());
        Assert.assertTrue($(By.xpath("//b[text()='Forward']" + lblCustom + "/input")).isDisplayed());
        Assert.assertTrue($(btnForwardInfo).isDisplayed());
        action.moveToElement($(btnForwardInfo)).perform();
        commonMethods.waitForElementExplicitly(1000);
        Assert.assertTrue($(txtForwardInfo).isDisplayed());
        verifyCustomFields("Forward");
    }

    /**
     * Method to verify Reply with options in edit rules
     */
    public void verifyReplyWithFields() {
        Assert.assertTrue($(lblReplyWith).isDisplayed());
        Assert.assertTrue($(By.xpath("//b[text()='Reply']" + lblanyMailType)).isDisplayed());
        Assert.assertTrue($(By.xpath("//b[text()='Reply']" + lblCustom)).isDisplayed());
        Assert.assertTrue($(By.xpath("//b[text()='Reply']" + lblanyMailType + "/input")).isDisplayed());
        Assert.assertTrue($(By.xpath("//b[text()='Reply']" + lblCustom + "/input")).isDisplayed());
        Assert.assertTrue($(btnReplyInfo).isDisplayed());
        action.moveToElement($(btnReplyInfo)).perform();
        commonMethods.waitForElementExplicitly(1000);
        Assert.assertTrue($(txtRepliesInfo).isDisplayed());
        verifyCustomFields("Reply");
    }

    /**
     * Method to verify custom field options in edit rules
     */
    public void verifyCustomFields(String option) {
        $(By.xpath("//b[text()='" + option + "']" + lblCustom + "/input")).click();
        Assert.assertTrue($(popupMailTypes).isDisplayed());
        Assert.assertTrue($(txtMailTypes).isDisplayed());
        Assert.assertTrue($(btnOk).isDisplayed());
        Assert.assertTrue($(btnCancel).isDisplayed());
        $(btnCancel).click();
        commonMethods.waitForElementExplicitly(1000);
        $(loadingIcon).should(disappear);
    }

    /**
     * Method to save rules
     */
    public void saveRules() {
        if ($(btnSave).isEnabled())
            $(btnSave).click();
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Method to change tabs
     */
    public void changeRulesTab(String tab) {
        if (tab.equalsIgnoreCase("general rules")) {
            commonMethods.waitForElement(driver, tabGeneralRules, 10);
            $(tabGeneralRules).click();
            switchToMailRulesFrame();
            commonMethods.waitForElement(driver, btnSave, 20);
        } else if (tab.equalsIgnoreCase("distribution rules")) {
            commonMethods.waitForElement(driver, tabDistributionRules, 60);
            $(tabDistributionRules).click();
            $(loadingIcon).should(disappear);
            switchToMailRulesFrame();
            commonMethods.waitForElement(driver, btnCreateNewRule, 30);
        }
    }

    /**
     * Method to verify rules tab is present or not
     */
    public void verifyNoRulesTab(String tab) {
        if (tab.equalsIgnoreCase("distribution rules")) {
            Assert.assertFalse($(tabDistributionRules).isDisplayed());
        } else if (tab.equalsIgnoreCase("general rules")) {
            Assert.assertFalse($(tabGeneralRules).isDisplayed());
        }
    }

    /**
     * Method to select mail type from dropdown
     */
    public void selectMailType(String type) {
        verifyAndSwitchFrame();
        $(loadingIcon).should(disappear);
        commonMethods.switchToFrame(driver, frameProjectSettings);
        if (!$(sltMailType).getSelectedOption().getText().equals(type)) {
            $(sltMailType).selectOption(type);
        }
    }

    /**
     * Method to select/unselect checkbox "Allow user to start mail thread"
     */
    public void selectAllowUsersCheckbox(String option) {
        switchToMailRulesFrame();
        commonMethods.waitForElement(driver, chkboxAllowMail, 5);
        if (option.equalsIgnoreCase("checked")) {
            if (!$(chkboxAllowMail).isSelected()) {
                $(chkboxAllowMail).setSelected(true);
                saveRules();
            }
        } else {
            if ($(chkboxAllowMail).isSelected()) {
                $(chkboxAllowMail).setSelected(false);
                saveRules();
            }
        }
    }

    /**
     * Method to select/unselect checkbox "Prevent an emailed reply"
     */
    public void selectPreventEmailCheckbox(String option) {
        switchToMailRulesFrame();
        commonMethods.waitForElement(driver, chkboxPreventMail, 5);
        if (option.equalsIgnoreCase("checked")) {
            if (!$(chkboxPreventMail).isSelected())
                $(chkboxPreventMail).setSelected(true);
        } else {
            if ($(chkboxPreventMail).isSelected())
                $(chkboxPreventMail).setSelected(false);
        }
    }

    /**
     * Method to select radio button either for Any Mail Type option or Custom option
     */
    public void selectRadioButton(String tab, String choice) {
        switchToMailRulesFrame();
        String option = tab.equalsIgnoreCase("reply with") ? "Reply" : "Forward";
        if (choice.equalsIgnoreCase("custom"))
            $(By.xpath("//b[text()='" + option + "']" + lblCustom + "/input")).click();
        else $(By.xpath("//b[text()='" + option + "']" + lblanyMailType + "/input")).click();
    }

    /**
     * Method to add mail types for custom option
     */
    public void addAvailableTypes(List<String> types) {
        if ($(popupMailTypes).isDisplayed()) {
            List<String> availableTypes = getAvailableTypes();
            for (String mailType : types) {
                commonMethods.waitForElementExplicitly(1000);
                if (availableTypes.contains(mailType))
                    $(By.xpath(sltAvailableTypes + "/option[text()='" + mailType + "']")).doubleClick();
            }
            $(btnOk).click();
        }
    }

    /**
     * Method to get available types from bidirectional mailtypes popup window
     */
    public List<String> getAvailableTypes() {
        List<String> availableTypes = new LinkedList<>();
        Select select = new Select($(By.xpath(sltAvailableTypes)));
        for (WebElement element : select.getOptions()) {
            availableTypes.add(element.getText());
        }
        return availableTypes;
    }

    /**
     * Method to get selected types from bidirectional mailtypes popup window
     */
    public List<String> getSelectedTypes() {
        List<String> selectedTypes = new LinkedList<>();
        Select select = new Select($(By.xpath(sltSelectedTypes)));
        for (WebElement element : select.getOptions()) {
            selectedTypes.add(element.getText());
        }
        return selectedTypes;
    }

    /**
     * Method to verify custom table in general rules tab
     */
    public void verifyCustomTable(String tab, Map<String, String> types) {
        switchToMailRulesFrame();
        String option = tab.equalsIgnoreCase("reply with") ? "Reply" : "Forward";
        String element = "//b[contains(text(),'" + option + "')]/parent::div/parent::form//table";
        List<String> addedTypes = new ArrayList<>();
        ArrayList<String> expTypes = new ArrayList<>(types.keySet());
        commonMethods.waitForElement(driver, By.xpath(element), 5);
        Assert.assertEquals("Mail Types", $(By.xpath(element + "//tr[1]/th[1]/b")).getText().trim());
        Assert.assertTrue($(By.xpath(element + "//tr[1]/th[1]/span")).isDisplayed());
        Assert.assertEquals("Updates Status", $(By.xpath(element + "//tr[1]/th[2]/b")).getText().trim());
        Assert.assertTrue($(By.xpath(element + "//tr[1]/th[2]/span")).isDisplayed());
        List<WebElement> tableRows = new ArrayList<>($$(By.xpath(element + "//tr")));
        for (int i = 1; i < tableRows.size(); i++) {
            String type = $(By.xpath(element + "//tr[" + i + "]/td[1]")).getText();
            addedTypes.add(type);
            Assert.assertTrue($(By.xpath(element + "//tr[" + i + "]/td[2]")).getText().equalsIgnoreCase(types.get(type)));
        }
        Assert.assertTrue(addedTypes.containsAll(expTypes));
        if (option.equalsIgnoreCase("reply"))
            action.moveToElement($(btnReplyStatusInfo)).perform();
        else action.moveToElement($(btnForwardStatusInfo)).perform();
        commonMethods.waitForElementExplicitly(1000);
        Assert.assertTrue($(txtStatusInfo).isDisplayed());
    }

    /**
     * Method to edit mail types from custom table
     */
    public void editAvailableTypes(String tab, List<String> types) {
        switchToMailRulesFrame();
        clickEditIcon(tab, 1);
        commonMethods.waitForElement(driver, popupMailTypes, 5);
        addAvailableTypes(types);
    }

    /**
     * Method to update mail type status from popup window
     */
    public void updatesMailTypeStatus(String tab, Map<String, String> types) {
        switchToMailRulesFrame();
        clickEditIcon(tab, 2);
        List<String> values = new ArrayList<>();
        commonMethods.waitForElement(driver, popupMailTypes, 5);
        types.forEach(this::updateStatus);
        $(btnOk).click();
    }

    /**
     * Method to update mail type status either to yes or no
     */
    public void updateStatus(String type, String status) {
        if (status.equalsIgnoreCase("no")) {
            List<String> yesTypes = getAvailableTypes();
            if (yesTypes.contains(type))
                $(By.xpath(sltAvailableTypes + "/option[text()='" + type + "']")).doubleClick();
        } else if (status.equalsIgnoreCase("yes")) {
            List<String> noTypes = getSelectedTypes();
            if (noTypes.contains(type))
                $(By.xpath(sltSelectedTypes + "/option[text()='" + type + "']")).doubleClick();
        }
    }

    /**
     * Method to click on pencil icon in custom table mail types
     */
    public void clickEditIcon(String tab, int column) {
        String option = tab.equalsIgnoreCase("reply with") ? "Reply" : "Forward";
        By element = By.xpath("//b[contains(text(),'" + option + "')]/parent::div/parent::form//table//tr[1]/th[" + column + "]/span");
        commonMethods.waitForElement(driver, element, 5);
        $(element).click();
    }

    /**
     * Method to switch to Mail rules frame
     */
    public void switchToMailRulesFrame() {
        verifyAndSwitchFrame();
        $(loadingIcon).should(disappear);
        commonMethods.switchToFrame(driver, frameProjectSettings);
        verifyAndSwitchFrame(frameMailRules);
    }

    /**
     * Method to verify create new rule window options
     */
    public void verifyNewRuleTab(String type) {
        Assert.assertTrue($(lblWhen).isDisplayed());
        Assert.assertTrue($(lblConditionDef).isDisplayed());
        Assert.assertTrue($(By.xpath("//strong[contains(text(),'" + type + "')]")).isDisplayed());
        Assert.assertTrue($(lblIf).isDisplayed());
        Assert.assertTrue($(lblThen).isDisplayed());
        verifyAndORLinks();
    }

    /**
     * Method to verify condition fields
     */
    public void assertConditionFields(String clause, String values) {
        List<String> expValues = Arrays.asList(values.split(","));
        switch (clause.toLowerCase()) {
            case "if-category":
                assertRulesField(By.xpath(sltIfCategory), expValues);
                addConditions(sltIfCategory, expValues.get(0));
                break;
            case "if-condition":
                assertRulesField(By.xpath(sltIfCondition), expValues);
                $(By.xpath(sltIfCondition)).selectOption(expValues.get(0));
                break;
            case "if-users":
                verifyUsersField(By.xpath(txtUsers), values);
                $(By.xpath(btnRemove)).click();
                break;
            case "then-category":
                assertRulesField(By.xpath(sltThenCategory), expValues);
                break;
            case "then-condition":
                assertRulesField(By.xpath(sltThenCondition), expValues);
                addConditions(sltThenCondition, expValues.get(0));
                break;
            case "then-users":
                verifyUsersField(By.xpath(txtThenUser), values);
                break;
            case "then-group":
                verifyUsersField(By.xpath(txtThenGroup), values);
                break;
            case "guest-users":
                verifyGuestUser(By.xpath(txtThenUser), values);
                break;
        }
    }

    /**
     * Method to assert dropdown field and values
     */
    public void assertRulesField(By element, List<String> expValues) {
        List<String> values = replaceFieldNames(expValues);
        Assert.assertTrue($(element).isDisplayed());
        commonMethods.waitForElementExplicitly(2000);
        List<String> ifCategory = commonMethods.returnAllOptionsInDropDown(driver, element);
        Assert.assertTrue(ifCategory.containsAll(values));
    }

    /**
     * Method to assert user or group fields
     */
    public void verifyUsersField(By element, String values) {
        List<String> value = new ArrayList<>();
        if (!values.equals("")) {
            value = Arrays.asList(values.split(","));
        } else {
            $(element).click();
            commonMethods.waitForElement(driver, By.xpath(lstUsers), 5);
            List<WebElement> elements = new ArrayList<>($$(By.xpath(lstUsers)));
            for (int i = 1; i <= elements.size(); i++) {
                value.add($(By.xpath("(" + lstUsers + ")[" + i + "]")).getAttribute("innerText"));
            }
        }
        String user;
        for (String name : value) {
            if (name.contains("user")) user = commonMethods.getUserData(name, "name");
            else user = name;
            $(element).sendKeys(user);
            commonMethods.waitForElement(driver, By.xpath(lstUsers), 10);
            $(element).sendKeys(Keys.ENTER);
            Assert.assertTrue($(By.xpath("//span[contains(text(),'" + user + "')]")).isDisplayed());
            Assert.assertTrue($(By.xpath("//span[contains(text(),'" + user + "')]/parent::span//span[@class='close ui-select-match-close']")).isDisplayed());
            $(element).sendKeys(user);
            Assert.assertFalse($(By.xpath(lstUsers)).isDisplayed());
            $(By.xpath("//span[contains(text(),'" + user + "')]/parent::span//span[@class='close ui-select-match-close']")).click();
            Assert.assertFalse($(By.xpath("//span[contains(text(),'" + user + "')]")).isDisplayed());
            $(element).sendKeys(user);
            commonMethods.waitForElement(driver, By.xpath(lstUsers), 5);
            $(element).sendKeys(Keys.ENTER);
            Assert.assertTrue($(By.xpath("//span[contains(text(),'" + user + "')]")).isDisplayed());
        }
    }

    /**
     * Method to assert guest user
     */
    public void verifyGuestUser(By element, String value) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
        userMap = jsonMapOfMap.get(value);
        $(element).sendKeys(userMap.get("full_name").toString());
        commonMethods.waitForElementExplicitly(2000);
        Assert.assertFalse($(By.xpath(lstUsers)).isDisplayed());
    }

    /**
     * Method to assert AND and OR condition links in create new rule window
     */
    public void verifyAndORLinks() {
        $(lnkIfAnd).click();
        Assert.assertTrue($(lblIfAnd).isDisplayed());
        $(lnkIfOr).click();
        Assert.assertTrue($(lblIfOr).isDisplayed());
        $(lnkThenAnd).click();
        Assert.assertTrue($(lblThenAnd).isDisplayed());
        List<WebElement> elements = new ArrayList<>($$(By.xpath(sltIfCategory)));
        Assert.assertEquals(3, elements.size());
        List<WebElement> element = new ArrayList<>($$(By.xpath(sltThenCategory)));
        Assert.assertEquals(2, element.size());
    }

    /**
     * Method to click on New rules button
     */
    public void clickNewRule() {
        switchToMailRulesFrame();
        $(btnCreateNewRule).click();
        commonMethods.waitForElement(driver, hdrCreateNewRule, 10);
        Assert.assertTrue($(hdrCreateNewRule).isDisplayed());
    }

    /**
     * Method to Add Distribution rule with If clause
     */
    public void addIfRule(String fieldName, String value) {
        commonMethods.waitForElement(driver, saveBtn, 20);
        switch (fieldName.toLowerCase()) {
            case "if-category":
                if (!value.equals("")) addConditions(sltIfCategory, value);
                break;
            case "if-condition":
                if (!value.equals("")) addConditions(sltIfCondition, value);
                break;
            case "if-users":
            case "if-field":
                if (!value.equalsIgnoreCase("")) addUsersGroup(txtUsers, value);
                break;
            case "if-group":
                if (!value.equalsIgnoreCase("")) addUsersGroup(txtGroups, value);
                break;
            case "if-and-option":
                if (value.equalsIgnoreCase("and")) addIfAndOption();
                break;
            case "if-or-option":
                if (value.equalsIgnoreCase("or")) addIfOrOption();
                break;
        }
    }

    /**
     * Method to Add Distribution rule with Then Clause
     */
    public void addThenRule(String fieldName, String value) {
        commonMethods.waitForElement(driver, saveBtn, 20);
        switch (fieldName.toLowerCase()) {
            case "then-category":
                if (!value.equals("")) addConditions(sltThenCategory, value);
                break;
            case "then-condition":
                if (!value.equals("")) addConditions(sltThenCondition, value);
                break;
            case "then-users":
                if (!value.equalsIgnoreCase("")) addUsersGroup(txtThenUser, value);
                break;
            case "then-group":
                if (!value.equalsIgnoreCase("")) addUsersGroup(txtThenGroup, value);
                break;
            case "then-and-option":
                if (value.equalsIgnoreCase("and")) addThenAndOption();
                break;
        }
    }

    /**
     * Method to Add users or group to users or group fields
     */
    public void addUsersGroup(String element, String values) {
        String[] value = values.split(",");
        for (String name : value) {
            if (name.contains("user")) {
                name = commonMethods.getUserData(name, "name");
            } else if (name.contains("GRP")) {
                name = commonMethods.getGroupFromJSON(name);
            }
            List<WebElement> textField = new ArrayList<>($$(By.xpath(element)));
            commonMethods.waitForElement(driver, By.xpath("(" + element + ")[" + textField.size() + "]"), 10);
            $(By.xpath("(" + element + ")[" + textField.size() + "]")).sendKeys(name);
            commonMethods.waitForElement(driver, By.xpath(lstUsers), 20);
            commonMethods.waitForElementExplicitly(200);
            $(By.xpath("(" + element + ")[" + textField.size() + "]")).sendKeys(Keys.ENTER);

        }
    }

    /**
     * Method to click on AND button in THEN Clause distribution rules tab
     */
    public void addThenAndOption() {
        $(lnkThenAnd).click();
    }

    /**
     * Method to click on AND button in IF Clause distribution rules tab
     */
    public void addIfAndOption() {
        $(lnkIfAnd).click();
    }

    /**
     * Method to click on OR button in distribution rules tab
     */
    public void addIfOrOption() {
        $(lnkIfOr).click();
    }

    /**
     * Method to add conditions for distribution rules
     */
    public void addConditions(String element, String value) {
        if (value.contains("label")) value = commonMethods.getLabelName(value);
        List<WebElement> elements = new ArrayList<>($$(By.xpath(element)));
        $(By.xpath("(" + element + ")[" + elements.size() + "]")).selectOption(value);
    }

    /**
     * Method to verify new rule
     */
    public void verifyNewRule(String type, String text1, String text2) {
        switchToMailRulesFrame();
        commonMethods.waitForElement(driver, btnEditRule, 30);
        Assert.assertTrue($(lblWhen).isDisplayed());
        Assert.assertTrue($(lblConditionDef).isDisplayed());
        Assert.assertTrue($(By.xpath("//strong[contains(text(),'" + type + "')]")).isDisplayed());
        Assert.assertTrue($(lblIf).isDisplayed());
        Assert.assertTrue($(lblThen).isDisplayed());
        Assert.assertTrue($(btnEditRule).isDisplayed());
        Assert.assertTrue($(By.xpath(btnDeleteRule)).isDisplayed());
        assertConditions(text1);
        assertConditions(text2);
    }

    /**
     * Method to assert new rule conditions
     */
    public void assertConditions(String condition) {
        String[] conditions = condition.split("\\|");
        for (String string : conditions) {
            if (string.contains("label")) string = commonMethods.getLabelName(string);
            else if (string.startsWith("GRP")) string = commonMethods.getGroupFromJSON(string);
            if (string.length() > 3 && string.substring(0, 4).contains("user"))
                Assert.assertTrue($(By.xpath("//span[contains(text(),'" + commonMethods.getUserData(string, "name") + "')]")).isDisplayed());
            else Assert.assertTrue($(By.xpath("//span[contains(text(),'" + string + "')]")).isDisplayed());
        }
    }

    /**
     * Method to delete rule
     */
    public void deleteRule() {
        commonMethods.waitForElement(driver, btnCreateNewRule, 60);
        $(loadingIcon).should(disappear);
        commonMethods.waitForElementExplicitly(2000);
        List<WebElement> elements = new ArrayList<>($$(By.xpath(btnDeleteRule)));
        for (int i = 1; i <= elements.size(); i++) {
            $(By.xpath("(" + btnDeleteRule + ")[" + i + "]")).click();
            commonMethods.waitForElement(driver, lblDeleteRule, 5);
            $(btnDelete).click();
        }
    }

    /**
     * Method to return whether mailtype is present or not
     */
    public boolean verifyMailType(String mailType) {
        switchProjectSettingsFrame();
        return $(By.xpath("//table[@class='auiTable']//tr/td[contains(text(),'" + mailType + "')]")).isDisplayed();
    }

    /**
     * Method to click on edit button for existing distribution rule
     */
    public void editDistributionRule() {
        commonMethods.waitForElement(driver, btnEditRule, 60);
        $(btnEditRule).click();
    }

    /**
     * Method to verify error messages
     */
    public void verifyErrorMessage(List<String> value) {
        switchToMailRulesFrame();
        List<WebElement> element = new ArrayList<>($$(By.xpath(lblErrorMessage)));
        for (WebElement ele : element) {
            List<String> values = replaceFieldNames(value);
            Assert.assertTrue(values.contains($(ele).getText()));
        }
    }

    /**
     * Method to remove existing users in Distribution rule
     */
    public void removeUsersInRule(List<String> values) {
        for (String s : values) {
            if (s.contains("user")) s = commonMethods.getUserData(s, "name");
            $(By.xpath("//span[contains(text(),'" + s + "')]/parent::span//span[@class='close ui-select-match-close']")).click();
        }
    }

    /**
     * Method to remove last if Clause from distribution rule
     */
    public void removeLastIf() {
        commonMethods.waitForElement(driver, saveBtn, 10);
        List<WebElement> removeList = new ArrayList<>($$(By.xpath(btnRemove)));
        $(By.xpath("(" + btnRemove + ")[" + removeList.size() + "]")).click();
    }

    /**
     * Method to verify Prevent Email options
     */
    public void verifyPreventEmailFields() {
        Assert.assertTrue($(lblPreventMail).isDisplayed());
        Assert.assertTrue($(chkboxPreventMail).isDisplayed());
        Assert.assertTrue($(btnPreventEmailInfo).isDisplayed());
        action.moveToElement($(btnPreventEmailInfo)).perform();
        commonMethods.waitForElementExplicitly(1000);
        Assert.assertTrue($(txtPreventEmailInfo).isDisplayed());
    }

    /**
     * Method to replace Project Label Ids to project field Label Names
     */
    public List<String> replaceFieldNames(List<String> values) {
        List<String> replacedValues = new ArrayList<>();
        for (String s : values) {
            if (s.contains("label")) {
                s = commonMethods.getLabelName(s);
            }
            replacedValues.add(s);
        }
        return replacedValues;
    }

    /**
     * Function to verify deleted rule
     *
     * @param rule
     */
    public boolean verifyDeletedRule(String rule) {
        return $(By.xpath("//span[@title='Group has been deleted' and text()='" + commonMethods.getGroupFromJSON(rule) + "']")).isDisplayed();
    }

    /**
     * @param user
     * @return
     */
    public boolean verifyDeletedUser(String user) {
        commonMethods.waitForElementExplicitly(2000);
        return $(By.xpath("//span[text()='" + user + "']")).isDisplayed();
    }

    /**
     * method to Edit Restricted Items
     */
    public void editRestrictedItems(String mailTypeName) {
        switchProjectSettingsFrame();
        By mailType = By.xpath("//tr[@id='" + mailTypeName + "']//td//a[contains(text(),'Edit Restricted Fields')]");
        commonMethods.waitForElement(driver, mailType, 60);
        $(mailType).click();
        commonMethods.waitForElement(driver, searchProjectFields, 60);
    }

    /**
     * method to Edit Restricted Items
     */
    public void verifyEditRestrictedRules(String mailType) {
        Assert.assertEquals("Restricted Fields - " + mailType, $(hdrRestrictedFields).getText());
        Assert.assertEquals("Project Fields applied to '" + mailType + "'", $(hdrAssociatedFields).getText());
        commonMethods.verifyElementsPresent(Arrays.asList($(searchProjectFields), $(newFieldBtn), $(saveBtn)));
    }

    /**
     * method to get all dropdown values of a type field
     */
    public List<String> getAllTypes() {
        return commonMethods.returnAllOptionsInDropDown(driver, selectType);
    }

    /**
     * method to verify mandatory fields
     */
    public void verifyMandatoryField() {
        $(selectType).click();
        $(labelField).click();
        commonMethods.waitForElementExplicitly(1000);
        Assert.assertEquals(configFileReader.getMandatoryFieldColorCode(), commonMethods.getBorderColor(selectType));
        $(inputLabel).click();
        $(typeField).click();
        commonMethods.waitForElementExplicitly(1000);
        Assert.assertEquals(configFileReader.getMandatoryFieldColorCode(), commonMethods.getBorderColor(inputLabel));
    }

    /**
     * method to verify tooltip
     */
    public void verifyToolTip() {
        $(btnToolTip).click();
        commonMethods.waitForElement(driver, messageToolTip);
        Assert.assertTrue($(messageToolTip).isDisplayed());
    }

    /**
     * method to close the new field window
     */
    public void closeNewField() {
        $(cancelBtn).click();
    }

    /**
     * method to click on pencil icon for provided restricted field
     */
    public void editRestrictedField(String restrictedField) {
        By xpath = By.xpath("//h4[text()='" + restrictedField + "']/../div[@class='auiIcon edit list-group-item-icon pull-left']");
        commonMethods.waitForElement(driver, xpath);
        $(xpath).click();
    }

    /**
     * Function to edit the restricted field and provide a new name
     */
    public void editProjectField(String labelName, String tooltip) {
        $(inputLabel).clear();
        String newLabel = faker.name().firstName() + faker.number().digits(4);
        $(inputLabel).sendKeys(newLabel);
        $(txtBoxToolTip).clear();
        $(txtBoxToolTip).sendKeys(tooltip);
        clickSaveBtn();
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.writeToJson("field_name", labelName, newLabel, projectFieldsPath);
    }

    /**
     * Function to verify select all checkbox for project fields
     */
    public String verifyAllPFChkBox() {
        commonMethods.waitForElement(driver, chkBoxSelectAll);
        return $(chkBoxSelectAll).getAttribute("disabled");
    }

    /**
     * Method to add restricted fields for mail types in project settings
     */
    public void addRestrictedFields(String mailTypeName) {
        By mailType = By.xpath("//tr[@id='" + mailTypeName + "']//td//a[contains(text(),'Edit Restricted Fields')]");
        commonMethods.waitForElement(driver, mailType, 25);
        $(mailType).click();
        commonMethods.waitForElement(driver, searchProjectFields, 20);
    }

    /**
     * Method to expand project field present in available to panel
     */
    public void expandProjectField(String name) {
        By xpath = By.xpath("//a[text()='" + name + "']");
        commonMethods.waitForElement(driver, chkBoxSelectAll);
        commonMethods.getElementInViewAndUp(xpath);
        $(xpath).click();
    }

    /**
     * Method to update available to for a project field
     */
    public void updateAllAvailableTo(String fieldName, String option) {
        List<WebElement> elements;
        By iconAvailableTo = By.xpath("//a[text()='" + fieldName + "']/../following-sibling::div//span[@title='Edit Field Value Permission']");
        commonMethods.waitForElement(driver, iconAvailableTo);
        $(iconAvailableTo).click();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, hdrEditFieldPermission);
        if (option.equalsIgnoreCase("selected roles"))
            elements = new ArrayList<>($$(btnSelectedRole));
        else elements = new ArrayList<>($$(btnAllUsers));
        for (WebElement element : elements) {
            $(element).click();
            commonMethods.waitForElementExplicitly(1000);
        }
    }

    /**
     * Return the mail types available in the table
     *
     * @return
     */
    public List<String> returnMailTypesRow() {
        List<WebElement> elements = driver.findElements(firstCell);
        List<String> mailTypes = new ArrayList<>();
        for (WebElement element : elements) {
            mailTypes.add(element.getText());
        }
        return mailTypes;
    }

    /**
     * Method to verify the given project field removed from the project fields applied
     *
     * @return
     */
    public boolean verifyProjectFieldRemoved(String label) {
        By projectFieldCheckbox = By.xpath("//td/div/a[text()='" + label + "']");
        return !$(projectFieldCheckbox).isDisplayed();
    }

    /**
     * Method to set response required for mail types
     */
    public void editResponseTime(String timeFrame, String toolTip) {
        commonMethods.waitForElement(driver, editResponseRequired);
        $(editResponseRequired).click();
        commonMethods.waitForElement(driver, btnSetResponseTime);
        $(btnSetResponseTime).click();
        commonMethods.waitForElementExplicitly(1000);
        $(txtBoxTimeFrame).clear();
        $(timeFrameToolTip).clear();
        commonMethods.waitForElementExplicitly(1000);
        $(txtBoxTimeFrame).sendKeys(timeFrame);
        $(timeFrameToolTip).sendKeys(toolTip);
        $(saveBtn).click();
    }

    /**
     * Function to verify the messages on Edit Field Pop-up dialog when mapped to Document Type, Mail Type, Package Type and Field
     */
    public void verifyInfoMessagesOnEditFieldDialog() {
        commonMethods.waitForElement(driver, message1, 45);
        Assert.assertTrue($(message1).isDisplayed());
        Assert.assertTrue($(message3).isDisplayed());
        Assert.assertTrue($(message4).isDisplayed());
        Assert.assertTrue($(message5).isDisplayed());
        Assert.assertTrue($(message6).isDisplayed());
    }

    /**
     * Method to remove restriction
     */
    public void removeRestriction() {
        commonMethods.waitForElement(driver, restrictions);
        $(editRestriction).click();
        commonMethods.waitForElement(driver, hdrDistributionRestrictions);
        $(btnAllowRecipients).click();
        $(btnSave).click();

    }

    /**
     * Method to add restriction
     */
    public void addRestriction() {
        commonMethods.waitForElement(driver, restrictions);
        $(editRestriction).click();
        commonMethods.waitForElement(driver, hdrDistributionRestrictions);
        $(btnNotAllowRecipients).click();
        $(btnSave).click();
    }

    /**
     * Method to click on back arrow button
     */
    public void clickBack() {
        commonMethods.waitForElement(driver, btnBackArrow);
        $(btnBackArrow).click();
    }

    /**
     * Method to verify restriction
     */
    public boolean verifyRestriction(String option) {
        commonMethods.waitForElement(driver, restrictions);
        if(option.equalsIgnoreCase("allow"))
        return $(txtAllowRestrcition).isDisplayed();
        else return $(txtNotAllowRestrcition).isDisplayed();
    }
}
