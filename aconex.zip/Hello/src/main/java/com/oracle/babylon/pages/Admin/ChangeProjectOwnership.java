package com.oracle.babylon.pages.Admin;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import static com.codeborne.selenide.Selenide.$;

public class ChangeProjectOwnership extends AdminTools{

    private By projectOwnership = By.xpath("//a[text()='Change Project Owner Organization']");
    private By selectProject = By.xpath("//label[text()='Select a Project']//..//..//div[2]//input");
    private By selectProjectLbl = By.xpath("//label[text()='Select a Project']");
    private By currentOwnerLbl = By.xpath("//label[text()='Select a Project']");
    private By newOwnerlbl = By.xpath("//label[text()='Select a Project']");
    private By currentOwner = By.xpath("//label[text()='Current Owner']//..//..//div[2]//span");
    private By newOwner = By.xpath("//label[text()='New Owner']//..//..//div[2]//select");
    private By savedSearchOwnershiplbl = By.xpath("//label[text()='Saved Search Ownership']");
    private By savedSearchOwnership = By.xpath("//label[text()='Saved Search Ownership']//..//..//div[2]//select");
    private By changeOwnerSuccessMessage = By.xpath("//div[contains(text(),'The project owner organization has been successfully changed')]");


    /**
     * Methd to navigate to the Change project ownership page in Admin Tools page
     * @param projectId
     */
    public void navigateChangeOwnership(String projectId){
        selectOptionToConfigure(projectOwnership);
        commonMethods.waitForElementExplicitly(1000);
        commonMethods.waitForElement(driver, selectProject);
        $(selectProject).sendKeys(projectId + Keys.ENTER);
        commonMethods.waitForElementExplicitly(2500);
        $(selectProject).sendKeys(Keys.ENTER);
    }

    public void verifyUI() {
        Assert.assertTrue($(selectProject).isDisplayed());
        Assert.assertTrue($(selectProjectLbl).isDisplayed());
        Assert.assertTrue($(currentOwnerLbl).isDisplayed());
        Assert.assertTrue($(newOwnerlbl).isDisplayed());
        Assert.assertTrue($(currentOwner).isDisplayed());
        Assert.assertTrue($(newOwner).isDisplayed());
        Assert.assertTrue($(savedSearchOwnershiplbl).isDisplayed());
        Assert.assertTrue($(savedSearchOwnership).isDisplayed());
    }

    /**
     * Method to verify the current owner of the project
     * @param orgName
     */
    public void verifyCurrentOwnership(String orgName){
        String currentOwnerStr = $(currentOwner).getText();
        Assert.assertTrue(currentOwnerStr.contains(orgName));
    }


    /**
     * Method to select a new owner
     * @param orgName
     */
    public void selectNewOwner(String orgName) {
        $(newOwner).click();
        $(newOwner).selectOptionContainingText(orgName);
        clickSaveBtn();
    }

    /**
     * Draft method. Will add the actual code for it
     * @return
     */
    public String returnSuccessMessage() {
        return $(changeOwnerSuccessMessage).getText();
    }
}
