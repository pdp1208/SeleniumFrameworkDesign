package com.oracle.babylon.Utils.helper;

import com.codeborne.selenide.WebDriverRunner;
import com.github.javafaker.Faker;
import com.oracle.babylon.Utils.setup.dataStore.DataSetup;
import com.oracle.babylon.Utils.setup.dataStore.DataStore;
import com.oracle.babylon.Utils.setup.dataStore.pojo.User;
import com.oracle.babylon.Utils.setup.utils.ConfigFileReader;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;

/**
 * Base class for all page files
 * Author: vsingsi
 * Edited by : susgopal
 * Edited by : Kukumavi
 */
public class AppHubNavigator {
    protected User user = new User();
    protected DataStore dataStore = new DataStore();
    protected ConfigFileReader configFileReader = new ConfigFileReader();
    protected WebDriver driver = null;
    protected CommonMethods commonMethods = new CommonMethods();
    protected DataSetup dataSetup = new DataSetup();
    protected Faker faker = new Faker();
    protected Map<String, String> projectMap = null;
    protected Map<String, Object> userMap = null;
    protected Map<String, Object> mailMap = null;
    protected Map<String, Object> sdMap = null;
    protected Map<String, Map<String, Object>> jsonMapOfMap = null;
    protected String userDataPath = null;
    protected String mailDataPath = null;
    protected String docDataPath = null;
    static public String globalProjectType;
    static public String globalProjectName;

    protected By avatar = By.xpath("//div[@id='userMenu']/oj-avatar");
    public By titleName = By.xpath("//input[@name='title']");
    private By usernameTxtBox = By.id("userName");
    private By passwordTxtBox = By.id("password");
    private By loginBtn = By.id("login");
    private By appLoadingIcon = By.id("acx-before-load");
    private By innerLoadingIcon = By.xpath("//oj-progress-circle[@role='progressbar']//div[@class='oj-progress-circle-indeterminate-inner']");
    protected By projectChangerSelect = By.id("current-project-holder_selected");
    private By projectChangerContainer = By.xpath("//ul[@id='oj-listbox-results-current-project-holder']");
    private By projectTxtBox = By.xpath("//div[@id='oj-listbox-drop']//input[@title='Search field']");
    private By userDetails = By.xpath("//span[@id='loggedin-user-name']");
    private By orgDetails = By.xpath("//span[@id='org-name']");
    private By loadingProgressIcon = By.cssSelector(".loading_progress");
    private By loginFailureMessage = By.xpath("//li[@class='message warning']//div[text()='Your login name or password is incorrect. Check that caps lock is not on.']");
    private By logOffBtn = By.xpath("//button[@class='oj-button-button']//span[text()='Logout']");
    private By registerLink = By.xpath("//a[text()='Register']");
    private By attributeClickOk = By.xpath("//button[@id='attributePanel-commit' and @title='OK']");
    protected By header = By.xpath("//h1");
    protected By loadingIcon = By.cssSelector(".loading_progress");
    private By okBtn = By.xpath("//button[@id='btnattachDocs_panel_ok']");
    private By newDocSearchOption = By.xpath("//li[@class='nav-banner-item']//a[text()='Try out the new Document Search']");
    private By switchToClassicView = By.xpath("//li[@class='nav-banner-item']//a[text()='Switch back to the classic Document Search']");
    protected By webViewerFrame = By.xpath("//iframe[@title='webviewer']");
    private By sslCertPage = By.cssSelector("body.ssl");
    private By advancedButton = By.cssSelector("button#details-button");
    protected By agreeTermsAndConditions = By.xpath("//input[contains(@id,'highComplianceTermsAgreed')]/following-sibling::button");
    private By collapsableArrow = By.xpath("//div[@class='collapse-container ng-scope']");
    private By proceedLink = By.cssSelector("a#proceed-link");
    protected By backBtn = By.xpath("//button[@id='btnBack']//div[@class='uiButton-content']");
    protected By menuNext = By.xpath("//div[@class='oj-conveyorbelt-overflow-button' and @title='Next']");
    protected By menuPrevious = By.xpath("//div[@class='oj-conveyorbelt-overflow-button' and @title='Previous']");
    private By menuRow = By.xpath("//div[@class='oj-tabbar-listview oj-component']");
    private By firstMenu = By.xpath("(//div[@class='oj-tabbar-listview oj-component']//li)[1]/a");
    protected By document = By.xpath("//li[@id='nav-bar-DOC']//span[@class='nav-item']");
    public By saveButton = By.xpath("//button[text()='Save']");
    public By saveBtn = By.xpath("//button[@id='btnSave']");
    public By saveToDraft = By.xpath("//button[@id='btnSaveDraftAddendum']");
    public By pageSaveBtn = By.xpath("//button[@id='btnSave']");
    protected By dataHeaders = By.xpath("//tr[@class='dataHeaders']//th");
    protected By dataRows = By.xpath("//div[@id='searchResultsContainer']//tr[@class='dataRow']");
    protected By menuBar = By.xpath("//div[@class='oj-tabbar-listview oj-component']//ul[@id='ui-id-2']//li//span[@class='nav-item']");
    protected By errorMessages = By.xpath("//*[contains(@id,'failure-message')]");
    protected By setUpLink = By.xpath("//a[@role='tab']//span[text()='Setup']");
    protected By searchButton = By.xpath("//button[@id='btnSearch_page']");
    protected By searchBtn = By.xpath("//button[contains(@id,'btnSearch')]//div[text()='Search']");
    private By nextLink = By.xpath("//a[text()='next>>']");
    public By selectGroupBy = By.xpath("//select[@id='groupBy']");
    public By showPerPageDropDown = By.xpath("//select[@id='pageSize']");
    private By tryNowLink = By.xpath("//button[@class='oj-button-button']//span[text()='Try Now']");
    private By btnAdd = By.xpath("//button[contains(text(),'Add')]");
    private By btnDocumentsMenu = By.xpath("//li[@id='nav-bar-DOC']/a//span[@class='nav-item']");
    private By loaderOverlay = By.cssSelector(".uiLoadingBlocker");
    protected By btnCancel = By.xpath("//button[text()='Cancel']");
    private By dropdownLogOff = By.xpath("//oj-popup[@id='logout-menu']//span[text()='Logout']");
    private By btnAccessCmpnyAct = By.xpath("//div[text()=\"Access Aconex via your company's network\"]");
    private By txtBoxWorkEmail = By.xpath("//input[@id='userEmail']");
    private By btnContinue = By.xpath("//button[@id='btnLogin']");
    private By ssoUserName = By.xpath("//input[@id='username']");
    private By ssoPassword = By.xpath("//input[@id='password']");
    private By btnSignOn = By.xpath("//a[contains(text(),'Sign On')]");
    private By oldDocLink = By.xpath("//button[@class='oj-button-button']//span[text()='Switch To Old']");
    protected By frame = By.xpath("//iframe[@id='frameMain']");
    private By btnBIMMenu = By.xpath("//li[@id='nav-bar-BIM']/a//span[@class='nav-item']");
    public By headerToolBarSection = By.xpath("//*[@id='toolbar_left']");
    public By headerSpanSection = By.xpath("//h1//span");
    public By headerSection = By.xpath("//h1");
    public By header5Section = By.xpath("//h5");
    public By toolBarSection = By.xpath("//div[contains(@class,'auiToolbar-header') or contains(@class, 'pageHeader-title')]");

    //AAS Identifiers
    private By aasUsernameTxtBox = By.xpath("//div/oj-label[@id='userName-labelled-by']");
    private By aasBtnNext = By.xpath("//div/oj-button[@id='nextButton']");
    private By aasPasswordTxtBox = By.xpath("//div/oj-input-password[@id='password']");
    private By aasLoginBtn = By.xpath("//div/oj-button[@id='nextButton']");

    private By aasUsernameTxtBoxNew = By.xpath("//div//oj-input-text[@id='userName']");
    private By aasBtnNextNew = By.xpath("//div//oj-button[@id='nextButton']");
    private By aasPasswordTxtBoxNew = By.xpath("//div//oj-input-password[@id='password']");
    private By aasLoginBtnNew = By.xpath("//div//oj-button[@id='nextButton']");

    public AppHubNavigator() {
        if (!(configFileReader.onlyAPIFlag)) {
            driver = WebDriverRunner.getWebDriver();
        }
        userDataPath = configFileReader.getUserDataPath();
        mailDataPath = configFileReader.getMailDataPath();
        docDataPath = configFileReader.getDocumentDataPath();
    }

    /**
     * Method to login using the user id from the feature file. One of the overloaded methods
     *
     * @param page
     * @param username user id from the feature file
     * @param block
     * @param <P>
     */
    public <P> void loginAsUser(P page, String username, Consumer<P> block) {
        user = dataStore.getUser(username);
        loginAsUser(user);
        block.accept(page);
    }

    /**
     * Method to login using the details from userData.json. We convert json data to user object and use it.
     *
     * @param page
     * @param userId
     * @param block
     * @param <P>
     */
    public <P> void loginAsUser(P page, String userId, String projectNumber, Consumer<P> block) {
        //Parse the json to retrieve the essential information and store it in user object
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
        commonMethods.waitForElementExplicitly(1000);
        userMap = jsonMapOfMap.get(userId);
        if (projectNumber != null) {
            String projectIndex = projectNumber.substring(projectNumber.length() - 1);
            globalProjectType = projectNumber;
            HashMap<String, String> map = CommonMethods.getDocumentTypeDetail(globalProjectType);
            String projectName = userMap.get(map.get("projectname") + projectIndex).toString();
            globalProjectName = projectName;
            if (projectName != null) {
                user.setProjectName(projectName);
            }
        }
        user.setUsername(userMap.get("username").toString());
        user.setPassword(userMap.get("password").toString());
        user.setFullName(userMap.get("full_name").toString());

        loginAsUser(user);
        block.accept(page);
    }

    /**
     * Method to login to aconex as a admin user
     *
     * @param page
     * @param block
     * @param <P>
     */
    public <P> void loginAsUser(P page, Consumer<P> block) {
        user.setUsername(configFileReader.getAdminUsername());
        user.setPassword(configFileReader.getPassword());
        user.setProjectName(null);
        loginAsUser(user);
        block.accept(page);
    }

    /**
     * Method to login to aconex as a user
     *
     * @param user
     */
    public <P> void loginAsUser(User user) {
        launchApplication();
        enterCreds(user.getUsername(), user.getPassword());
        if (user.getProjectName() != null) {
            selectProject(user.getProjectName());
        }
    }

    /**
     * Method to store the page in block
     *
     * @param page
     * @param block
     * @param <P>
     */
    public <P> void on(P page, Consumer<P> block) {
        block.accept(page);
    }

    /**
     * Method to enter credentials into application
     *
     * @param username
     * @param password
     */
    public void enterCreds(String username, String password) {
        try {
            commonMethods.waitForPageLoad(WebDriverRunner.getWebDriver());
            commonMethods.waitForElement(driver, usernameTxtBox, 60);
        } catch (NoSuchElementException | TimeoutException e) {
            logout();
            openAconexUrl();
        }
        if(configFileReader.getAASEnable()) {
            commonMethods.waitForElement(driver, aasUsernameTxtBox, 120);
            $(aasUsernameTxtBox).sendKeys(username);
            commonMethods.waitForElementClickable(driver, aasBtnNext, 15);
            $(aasBtnNext).click();
            commonMethods.waitForElement(driver, aasPasswordTxtBox);
            $(aasPasswordTxtBox).sendKeys(password);
            $(aasLoginBtn).click();
        } else {
            commonMethods.waitForElement(driver, usernameTxtBox, 60);
            $(usernameTxtBox).clear();
            $(usernameTxtBox).setValue(username);
            $(passwordTxtBox).clear();
            $(passwordTxtBox).setValue(password);
            $(loginBtn).click();
        }
        $(".loading_progress").should(disappear);
        //Accept terms and condition
        try {
            commonMethods.waitForElementExplicitly(5000);
            commonMethods.waitForElement(driver, agreeTermsAndConditions, 6);
            $(agreeTermsAndConditions).click();
        } catch (TimeoutException e) {
            //ignore
        }
    }
    
    public void enterCreds(User user) {
        try {
            commonMethods.waitForPageLoad(WebDriverRunner.getWebDriver());
            commonMethods.waitForElement(driver, usernameTxtBox, 60);
        } catch (NoSuchElementException | TimeoutException e) {
            logout();
            openAconexUrl();
        }
        if(configFileReader.getAASEnable()) {
            commonMethods.waitForElement(driver, aasUsernameTxtBoxNew, 120);
            $(aasUsernameTxtBoxNew).sendKeys(user.getUsername());
            commonMethods.waitForElementClickable(driver, aasBtnNextNew, 15);
            $(aasBtnNextNew).click();
            commonMethods.waitForElement(driver, aasPasswordTxtBoxNew);
            $(aasPasswordTxtBoxNew).sendKeys(user.getPassword());
            $(aasLoginBtnNew).click();
        } else {
            commonMethods.waitForElement(driver, usernameTxtBox, 60);
            $(usernameTxtBox).clear();
            $(usernameTxtBox).setValue(user.getUsername());
            $(passwordTxtBox).clear();
            $(passwordTxtBox).setValue(user.getPassword());
            $(loginBtn).click();
        }
        $(".loading_progress").should(disappear);
        //Accept terms and condition
        try {
            commonMethods.waitForElementExplicitly(5000);
            commonMethods.waitForElement(driver, agreeTermsAndConditions, 6);
            $(agreeTermsAndConditions).click();
        } catch (TimeoutException e) {
            //ignore
        }
    }
    
    
    /**
     * Method to select a project
     *
     * @param projectName
     */
    public void selectProject(String projectName) {
        commonMethods.waitForPageLoad(driver);
        commonMethods.waitForElementExplicitly(2000);
        try {
            commonMethods.waitForElement(driver, userDetails, 45);
        } catch (Exception e) {
            refresh();
            commonMethods.waitForPageLoad(driver);
            commonMethods.waitForElement(driver, userDetails, 45);
            commonMethods.waitForElementExplicitly(5000);
        }
        if (projectName != null) {
            commonMethods.waitForElement(driver, projectChangerSelect, 60);
            if ($(projectChangerSelect).isDisplayed()) {
                if (!$(projectChangerSelect).text().equals(projectName)) {
                    //project select dropdown shows 20characters only. So need to crop the project name if length is more than 20.
                    if (projectName.length() > 20) {
                        projectName = projectName.substring(0, 20);
                    }
                    $(projectChangerSelect).click();
                    $(projectTxtBox).sendKeys(projectName);
//                    By projectXpath = By.xpath("//ul[@class='oj-listbox-results']//span[text()='" + projectName + "']");
                    By projectXpath = By.xpath("//oj-highlight-text[@text='" + projectName + "']");
                    commonMethods.waitForElement(driver, projectXpath, 20);
                    if ($(projectXpath).isDisplayed()) {
                        $(projectXpath).click();
                    } else {
                        System.out.println("User not part of the project");
                    }
                }
                if (configFileReader.getEnableNewDocSearchFlag()) enableNewDocSearch();
            } else {
                System.out.println("No projects available to select");
            }
        } else {
            System.out.println("No Projects Exist in the Organization / Creating new Project /Admin Login");
        }
    }

    /**
     * Method to enable new document search page
     */
    public void enableNewDocSearch() {
        commonMethods.waitForElement(driver, document, 60);
        $(document).click();
        commonMethods.waitForElementExplicitly(1000);
        if ($(newDocSearchOption).exists()) {
            $(newDocSearchOption).click();
        }
        refresh();
    }

    /**
     * Method to switch to old document search page
     */
    public void switchClassicDocSearch() {
        commonMethods.waitForElement(driver, document, 25);
        $(document).click();
        commonMethods.waitForElementExplicitly(1000);
        if ($(switchToClassicView).exists()) {
            $(switchToClassicView).click();
        }
        refresh();
    }

    /**
     * Method to select a submenu item
     *
     * @param menu
     * @param submenu
     */
	public WebDriver getMenuSubmenu(String menu, String submenu) {
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		driver = WebDriverRunner.getWebDriver();
		driver.switchTo().defaultContent();
		waitForLoaderToDisappear();
		commonMethods.waitForPageLoad(driver);
		commonMethods.waitForElementHidden(driver, innerLoadingIcon);
		commonMethods.waitForPageLoad(driver);
		waitInnerLoaderDisappear();
		commonMethods.waitForElement(driver, menuRow, 65);
		commonMethods.sleep(2000);
		By Menu = By.xpath("//a[@role='tab']//span[text()='" + menu + "']");
		if (!$(Menu).isDisplayed() && $(menuNext).isDisplayed()) {
			waitForLoaderToDisappear();
			waitInnerLoaderDisappear();
			commonMethods.waitForPageLoad(driver);
			commonMethods.waitForElementClickable(driver, menuNext, 30);
			commonMethods.waitForElementExplicitly(2000);
			if ($(menuNext).isDisplayed()) {
				System.out.println("Coming inside menu click condition");
				commonMethods.waitForElementClickable(driver, menuNext, 30);
				commonMethods.waitForElementExplicitly(2000);
				try {
					$(menuNext).click();
				} catch (ElementClickInterceptedException e) {
					executor.executeScript("arguments[0].click();", $(menuNext));
				} catch (Exception e) {
					actions().moveToElement($(menuNext)).click().build().perform();
				}
//            	actions().moveToElement($(menuNext)).click().build().perform();
//              executor.executeScript("arguments[0].click();", $(menuNext));
			}
			commonMethods.waitForElementExplicitly(3000);
		}
		commonMethods.waitForElementExplicitly(2000);
		try {
			$(Menu).click();
		} catch (Exception e) {
			executor.executeScript("arguments[0].click();", $(Menu));
		}
		commonMethods.waitForElementExplicitly(1000);
		By subMenu = By.xpath("//ul[@class='nav-item-group-list']/li/a[text()='" + submenu + "']");
		commonMethods.waitForElement(driver, subMenu, 30);
		$(subMenu).click();
		$(appLoadingIcon).should(disappear);
		commonMethods.waitForPageLoad(driver);
		return driver;
	}

    /**
     * Method to select a submenu item
     *
     * @param menu
     * @param submenu
     * @param section
     */
    public WebDriver getMenuSubmenu(String menu, String section, String submenu) {
        driver = WebDriverRunner.getWebDriver();
        driver.switchTo().defaultContent();
        waitForLoaderToDisappear();
        waitInnerLoaderDisappear();
        commonMethods.waitForElement(driver, menuRow, 20);
        By navigationMenu = By.xpath("//a[@role='tab']//span[text()='" + menu + "']");
        commonMethods.waitForElement(driver, firstMenu, 25);
        if ($(menuNext).isDisplayed() && !$(navigationMenu).isDisplayed()) {
            $(menuNext).click();
        }
        commonMethods.waitForElement(driver, navigationMenu, 10);
        $(navigationMenu).click();
        By subMenu = By.xpath("//ul[@class='nav-item-group-list']/li/a[text()='" + submenu + "']");
        commonMethods.waitForElement(driver, subMenu, 20);
        $(By.xpath("//div[@class='nav-item-group-header' and contains(.,'" + section + "')]//..//a[text()='" + submenu + "']")).click();
        $(appLoadingIcon).should(disappear);
        return driver;
    }

    /**
     * Method to find the menu
     *
     * @param css
     * @param text
     */
    public WebElement menuFinder(String css, String text) {
        return driver.findElements(By.cssSelector(css)).stream()
                .filter(e -> e.getText().equalsIgnoreCase(text) && e.isDisplayed() && e.isEnabled())
                .findFirst()
                .get();
    }

    /**
     * Method to verify user details
     *
     * @param fullName
     */
    public boolean verifyUserPresent(String fullName) {
        commonMethods.waitForElement(driver, userDetails);
        return $(userDetails).getText().contains(fullName);
    }

    /**
     * Method to verify organization details
     *
     * @param orgName
     */
    public boolean verifyOrganisationPresent(String orgName) {
        commonMethods.waitForElement(driver, orgDetails);
        return $(orgDetails).getText().contains(orgName);
    }

    /**
     * Method to verify username not present
     */
    public void verifyUserNotPresent() {
        $(userDetails).shouldNot(text(user.getFullName()));
    }

    /**
     * Method to verify login failed message
     */
    public void verifyLoginFailed() {
        $(loginFailureMessage).shouldHave(text("Your login name or password is incorrect. Check that caps lock is not on."));
    }


    /**
     * Function to logout from the server.
     */
    public void logout() {
        if (driver.getCurrentUrl().contains(ConfigFileReader.getApplicationUrl())) {
            if (commonMethods.isAlertPresent(WebDriverRunner.getWebDriver())) acceptAlert();
            switchToOriginal();
            commonMethods.waitForPageLoad(WebDriverRunner.getWebDriver());
            if (!$(userDetails).isDisplayed()) refresh();
            commonMethods.waitForElementExplicitly(2000);
            Actions actions = new Actions(WebDriverRunner.getWebDriver());
            WebDriverRunner.getWebDriver().switchTo().defaultContent();
            commonMethods.waitForElementClickable(WebDriverRunner.getWebDriver(), userDetails, 60);
            actions.moveToElement($(userDetails)).click().build().perform();
            commonMethods.waitForElementExplicitly(500);
            try {
                commonMethods.waitForElement(driver, dropdownLogOff, 5);
            } catch (Exception e) {
                switchToOriginal();
                actions.moveToElement($(userDetails)).doubleClick().build().perform();
                commonMethods.waitForElementExplicitly(500);
                commonMethods.waitForElementClickable(WebDriverRunner.getWebDriver(), logOffBtn, 10);
            }
            switchToOriginal();
            commonMethods.waitForElementClickable(WebDriverRunner.getWebDriver(), logOffBtn, 10);
            actions.moveToElement($(logOffBtn)).click().build().perform();
        }
    }


    /**
     * Function to click on Register link to create a organization
     */
    public void clickRegisterLink() {
        commonMethods.waitForElement(driver, registerLink, 60);
        $(registerLink).click();
    }

    /**
     * Function to launch Aconex application url in a browser
     */
    public void openAconexUrl() {
        try {
            open(ConfigFileReader.getApplicationUrl());
        } catch (TimeoutException e) {
            if (e.toString().contains("Timed out receiving message from renderer:")) {
                open(ConfigFileReader.getApplicationUrl());
            }
        }
        if ($(sslCertPage).isDisplayed()) {
            $(advancedButton).click();
            $(proceedLink).click();
        }
        //Accept terms and condition
        try {
            commonMethods.waitForElement(driver, agreeTermsAndConditions, 6);
            $(agreeTermsAndConditions).click();
        } catch (TimeoutException e) {
            //ignore
        }
        new ConfigSingleton(driver);
    }

    /**
     * Method to select the ok button when selecting the attribute value
     */
    public void selectAttributeClickOK() {
        $(attributeClickOk).click();
    }

    /**
     * Method to return project details
     */
    public Map<String, String> returnProjectMap() {
        return projectMap;
    }

    /**
     * Method to verify the element is displayed
     *
     * @param by
     * @return
     */
    public boolean verifyPageTitle(By by) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, by, 60);
        Boolean isDisplayed = $(by).isDisplayed();
        return isDisplayed;
    }

    /**
     * Method to verify the text of the element
     *
     * @param pageTitle
     * @return
     */
    public boolean verifyPageTitle(String pageTitle) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        new WebDriverWait(driver, 40).until(ExpectedConditions.textToBePresentInElementLocated(header, pageTitle));
        boolean flag = ($(header).text()).contains(pageTitle);
        driver.switchTo().defaultContent();
        return flag;
    }

    /**
     * Method to verify and switch to mail frame
     */
    public void verifyAndSwitchFrame() {
        waitForLoaderToDisappear();
        waitInnerLoaderDisappear();
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        String currentFrame = null;
        $(".loading_progress").should(disappear);
        try {
            currentFrame = (String) jsExecutor.executeScript("return self.name");
        } catch (UnhandledAlertException e) {
            $(".loading_progress").should(disappear);
            currentFrame = (String) jsExecutor.executeScript("return self.name");
        }
        try {
            if (!currentFrame.equalsIgnoreCase("main")) {
                switchTo().defaultContent();
                commonMethods.switchToFrame(driver, "frameMain");
            }
        } catch (NoSuchElementException e) {
            switchTo().defaultContent();
            commonMethods.waitForElement(driver, frame, 10);
            commonMethods.switchToFrame(driver, "frameMain");
        }
    }

    /**
     * Method to switch the the default frame
     */
    public void switchToOriginal() {
        driver.switchTo().defaultContent();
    }

    /**
     * Method to switch to a specific frame if it exists
     *
     * @param frameName
     */
    public void verifyAndSwitchFrame(String frameName) {
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        String currentFrame = (String) jsExecutor.executeScript("return self.name");
        if (!currentFrame.equalsIgnoreCase(frameName)) {
            commonMethods.switchToFrame(driver, frameName);
        }
    }

    /**
     * Method to switch to a specific frame by its locator
     *
     * @param frameLocator
     */
    public void verifyAndSwitchFrame(By frameLocator) {
        commonMethods.waitForElement(driver, frameLocator, 10);
        switchTo().frame($(frameLocator));
    }

    /**
     * Method to refresh page
     */
    public void refresh() {
        waitForLoaderToDisappear();
        waitInnerLoaderDisappear();
        driver.navigate().refresh();
        commonMethods.waitForElementExplicitly(8000);
        commonMethods.acceptAlert(driver);
        commonMethods.waitForPageLoad(driver);
        waitForLoaderToDisappear();
        waitInnerLoaderDisappear();
        try {
            commonMethods.waitForElement(driver, firstMenu, 60);
        } catch (TimeoutException e) {
            driver.navigate().refresh();
            commonMethods.waitForElement(driver, firstMenu, 60);
        }
    }

    /**
     * function to get logged in username with salutation
     *
     * @return
     */
    public String getLoggedInUser() {
        driver.switchTo().defaultContent();
        String userName = $(userDetails).text();
        String[] user = userName.split(" ");
        userName = user[1] + " " + user[2];
        return userName;

    }

    /**
     * function to get element in the view
     *
     * @param element to make visible
     */
    public void getElementInView(By element) {
        WebElement e = $(element);
        commonMethods.waitForElement(driver, element, 60);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", e);
    }

    /**
     * Function to press enter on page
     */
    public void hitEnter() {
        verifyAndSwitchFrame();
        $(By.xpath("//html")).sendKeys(Keys.ENTER);
    }

    /**
     * Function to click on Ok button
     */
    public void clickOkBtn() {
        commonMethods.waitForElementExplicitly(2000);
        if ($(okBtn).exists()) {
            $(okBtn).click();
        }
    }

    /**
     * Function to navigate to menu and submenu
     */
    public void navigateAndVerifyPage(String menu, String submenu) {

        getMenuSubmenu(menu, submenu);
    }

    /**
     * Function to navigate to menu and submenu under section
     */
    public void navigateAndVerifyPage(String menu, String section, String submenu) {
        commonMethods.waitForElementExplicitly(3000);
        getMenuSubmenu(menu, section, submenu);
    }

    /**
     * Method to switch to the Web Viewer frame needed for workflows and document viewer test cases
     */
    public void webViewerFrame() {
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        String currentFrame = jsExecutor.executeScript("return self.name").toString();
        if (currentFrame.equals("main")) {
            commonMethods.waitForElement(driver, webViewerFrame, 40);
            driver.switchTo().frame($(webViewerFrame));
        }
    }

    /**
     * Function to accept alert
     */
    public void acceptAlert() {
        commonMethods.waitForElementExplicitly(2000);
        driver.switchTo().alert().accept();
    }

    /**
     * Function to dismiss alert
     */
    public void dismissAlert() {
        commonMethods.waitForElementExplicitly(1000);
        driver.switchTo().alert().dismiss();
    }


    /**
     * Function to click on back button
     */
    public void clickBackButton() {
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, backBtn, 40);
        $(backBtn).click();
    }

    /**
     * Function to switch to mail attach panel
     */
    public void switchToMailAttachPanel() {
        switchTo().defaultContent();
        verifyAndSwitchFrame();
        if (!driver.findElements(By.xpath("//iframe[@id='attachOnNewPanel_iframe']")).isEmpty()) {
            switchTo().frame("attachOnNewPanel_iframe");
        }

    }

    /**
     * Function to switch tab for document and mail pages
     *
     * @param page name
     * @param tab  name
     */
    public boolean switchTab(String page, String tab) {
        switch (page.toLowerCase()) {
            case "document":
                verifyAndSwitchFrame();
                commonMethods.waitForElementExplicitly(10000);
                By element = By.xpath("//li[@title='" + tab + "']");
                if (!$(element).isDisplayed()) {
                    $(collapsableArrow).click();
                }
                $(element).click();
                return $(By.xpath("//h1[contains(text(),'Search -')]//span[text()='" + tab + "']")).isDisplayed();
            case "mail":
                $(By.xpath("//div[@class='center-content']//a[contains(text(),'" + tab + "')]")).click();
                break;
            case "mail panel":
                switchToMailAttachPanel();
                commonMethods.waitForElementExplicitly(2000);
                $(By.xpath("//div[@class='center-content']//a[contains(text(),'" + tab + "')]")).click();
                break;
        }
        return true;
    }

    /**
     * Function to check if message is displayed on the page.
     *
     * @param message expected message.
     * @return
     */
    public boolean isMessageDispalyedOnPage(String message) {
        try {
            commonMethods.waitForElement(driver, By.xpath("//*[contains(text(),'" + message + "')]"), 8);
            $(By.xpath("//*[contains(text(),'" + message + "')]")).waitUntil(disappears, 10000);
            return true;
        } catch (TimeoutException e) {
            return false;
        }
    }

    /**
     * Function to wait until loader disappers.
     */
    public void waitForLoaderToDisappear() {
        commonMethods.waitForElementHidden(driver, loaderOverlay);
    }

    /**
     * Function to verify alert message
     *
     * @actual is the message to verify in alert text box
     */

    public boolean verifyAlert(String actual) {
        try {
            String windowHandle = driver.getWindowHandle();
            commonMethods.waitForElementExplicitly(4000);
            String text = driver.switchTo().alert().getText();
            driver.switchTo().alert().accept();
            driver.switchTo().window(windowHandle);
            Assert.assertTrue((text).contains(actual));
            return true;
        } catch (UnhandledAlertException | NoAlertPresentException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Function to click save button
     */
    public void clickSaveBtn() {
        $(saveButton).click();
    }

    /**
     * Function to click save button
     */
    public void clickSaveButton() {
        $(pageSaveBtn).click();
    }

    /**
     * Function to get alter window message
     */
    public String getAlertText() {
        commonMethods.waitForElementExplicitly(1000);
        return driver.switchTo().alert().getText();
    }

    /**
     * Function to Get the column number on the result table
     *
     * @param columnName
     * @return
     */
    public int getColumnIndex(String rowClassName, String columnName) {
        int columnIndex = 0;
        commonMethods.waitForElement(driver, dataRows);
        for (int iterator = 1; iterator <= $$(dataHeaders).size(); iterator++) {
            if ($(By.xpath("(//tr[@class='" + rowClassName + "']//th)[" + iterator + "]")).getText().contains(columnName)) {
                columnIndex = iterator;
                break;
            }
        }
        return columnIndex;
    }

    /**
     * Method to return the selected dropdown
     *
     * @return
     */
    public String returnSelectedDropDown(By element) {
        commonMethods.waitForElement(driver, element);
        return $(element).getSelectedText();
    }

    /**
     * Method to verify menu is exist
     *
     * @return
     */
    public boolean verifyMenuExists(String menuHeader, String menuName) {
        driver = WebDriverRunner.getWebDriver();
        driver.switchTo().defaultContent();
        commonMethods.waitForElement(driver, menuRow, 45);
        By Menu = By.xpath("//a[@role='tab']//span[text()='" + menuHeader + "']");
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, Menu);
        $(Menu).click();
        return $(By.xpath("//ul[@class='nav-item-group-list']/li/a[text()='" + menuName + "']")).isDisplayed();
    }

    /**
     * Method to click on search button
     */
    public void searchButton() {
        $(searchButton).shouldBe(appear);
        $(searchButton).click();
    }

    /**
     * Method to click on menu changer icon
     *
     * @return
     */
    public boolean clickMenuChangerIcon() {
        if ($(menuNext).isDisplayed()) {
            $(menuNext).click();
            commonMethods.waitForElementExplicitly(2000);
            return true;
        } else
            return false;
    }

    /**
     * Method to return the text present in the alert box
     *
     * @return
     */
    public String returnAlertText() {
        return commonMethods.returnAlertText(driver);
    }

    /**
     * Function to click on next
     */
    public void clickNext() {
        commonMethods.waitForElement(driver, nextLink, 40);
        $(nextLink).click();
    }

    /**
     * Function to check if error displayed on the page.
     *
     * @return
     */
    public boolean isErrorDisplayedOnPage() {
        try {
            commonMethods.waitForElement(driver, errorMessages, 10);
        } catch (TimeoutException e) {
            return false;
        }
        return true;
    }

    /**
     * Function to check if error displayed on the page.
     *
     * @return
     */
    public boolean isErrorDispalyedOnPage() {
        commonMethods.waitForElementExplicitly(5000);
        return $(errorMessages).isDisplayed();
    }

    /**
     * Function to select the Group By with the passed param
     *
     * @param option
     */
    public void selectGroupByFilter(String option) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, selectGroupBy);
        $(selectGroupBy).selectOptionContainingText(option);
        commonMethods.waitForElementExplicitly(6000);
    }

    /**
     * Function to select page Size
     *
     * @param size
     */
    public void selectPageSize(String size) {
        verifyAndSwitchFrame();
        $(showPerPageDropDown).selectOption(size);
        commonMethods.waitForElement(driver, searchButton);
        $(searchButton).click();
    }

    public void enableUnifiedUpload(String projectId) {
        HashMap<String, String> map = CommonMethods.getDocumentTypeDetail(projectId);
        String key = map.get("registermenu");
        By by = By.xpath("//a[@role='tab']//span[text()='" + key + "']");
        commonMethods.waitForElement(driver, by);
        $(by).click();
        if ($(tryNowLink).isDisplayed()) {
            $(tryNowLink).click();
        }
        refresh();
    }

    /**
     * Method to click menu previous arrow
     */
    public void clickMenuPreviousArrow() {
        driver.switchTo().defaultContent();
        if ($(menuPrevious).isDisplayed()) {
            $(menuPrevious).click();
            commonMethods.waitForElementExplicitly(1000);
        }
    }

    /**
     * Method to double click on menu name
     */
    public WebDriver doubleClickMenu(String menu) {
        switchToOriginal();
        commonMethods.waitForElement(driver, menuRow, 65);
        By Menu = By.xpath("//a[@role='tab']//span[text()='" + menu + "']");
        commonMethods.waitForElement(driver, firstMenu, 30);
        if ($(menuPrevious).exists() && !$(Menu).isDisplayed()) $(menuPrevious).click();
        $(loadingProgressIcon).should(disappear);
        commonMethods.waitForElementExplicitly(1000);
        $(Menu).doubleClick();
        commonMethods.waitForElementExplicitly(5000);
        return driver;
    }

    /**
     * Method to click on menu name
     */
    public WebDriver clickMenu(String menu) {
        switchToOriginal();
        commonMethods.waitForElement(driver, menuRow, 65);
        By Menu = By.xpath("//a[@role='tab']//span[text()='" + menu + "']");
        commonMethods.waitForElement(driver, firstMenu, 30);
        if ($(menuPrevious).exists() && !$(Menu).isDisplayed()) $(menuPrevious).click();
        $(loadingProgressIcon).should(disappear);
        commonMethods.waitForElementExplicitly(1000);
        $(Menu).click();
        commonMethods.waitForElementExplicitly(5000);
        return driver;
    }

    /**
     * Method to reset credentials
     */
    public void resetCredentials(String userName, String password) {
        commonMethods.waitForElementExplicitly(6000);
        driver.get(configFileReader.getApplicationUrl());
        commonMethods.waitForElementExplicitly(4000);
        commonMethods.waitForElement(driver, usernameTxtBox);
        $(usernameTxtBox).clear();
        $(usernameTxtBox).setValue(userName);
        $(passwordTxtBox).clear();
        $(passwordTxtBox).setValue(password);
        sleep(1000);
        $(loginBtn).click();
    }


    /**
     * Method to verify project name is present in the project list of logged in user
     */
    public boolean verifyProjectList(String userId, String projectId) {
        driver.switchTo().defaultContent();
        commonMethods.waitForElement(driver, projectChangerSelect, 30);
        $(projectChangerSelect).click();
        return $(By.xpath("//ul[@class='oj-listbox-results']/li/div[text()='" + commonMethods.getProjectName(userId, projectId) + "']")).isDisplayed();
    }

    /**
     * Method to click on Add button
     */
    public void clickAdd() {
        $(btnAdd).click();
    }

    /**
     * Method to verify tool tip messages
     */
    public String verifyToolTips(By element) {
        Actions actions = new Actions(driver);
        actions.moveToElement($(element)).perform();
        return $(element).getAttribute("title");
    }

    /**
     * Method to return documents' menu name
     */
    protected String getDocumentMenuName() {
        switchToOriginal();
        commonMethods.waitForElement(driver, btnDocumentsMenu, 60);
        return $(btnDocumentsMenu).getText();
    }

    /**
     * Method to wait until loading icon disappear
     */
    public void loadingIconDone() {
        $(loadingProgressIcon).should(disappear);
    }

    /**
     * Method to click Setup link on the menu bar
     */
    public void clickSetupLink() {
        if ($(menuNext).exists() && !$(setUpLink).isDisplayed()) {
            $(menuNext).click();
        }
        commonMethods.waitForElement(driver, setUpLink);
        $(setUpLink).click();
    }

    public boolean verifyMenu(String menuName) {
        By menu = By.xpath("//a[@role='tab']//span[text()='" + menuName + "']");
        return $(menu).isDisplayed();
    }

    /**
     * Method to wait till link select all displayed
     */
    public void waitForResultsDisplay(By element) {
        $(loadingIcon).should(disappear);
        commonMethods.waitForElement(driver, element, 60);
    }

    /**
     * Method to login into Application using Single Sign On
     *
     * @param page
     * @param userId user id from the feature file
     * @param block
     * @param <P>
     */
    public <P> void loginAsSSO(P page, String userId, Consumer<P> block) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
        commonMethods.waitForElementExplicitly(1000);
        userMap = jsonMapOfMap.get(userId);
        launchApplication();
        enterUserAccount(userMap.get("username").toString());
        enterSSODetails(userMap.get("idp_username").toString(), userMap.get("idp_password").toString());
        block.accept(page);
    }

    /**
     * Method to open the Aconex application in a browser
     */
    public void launchApplication() {
        switchTo().defaultContent();
        if ($(userDetails).isDisplayed()) {
            refresh();
            logout();
            commonMethods.waitForElementExplicitly(4000);
        }
        openAconexUrl();
    }

    /**
     * Method to open the Aconex application in a browser
     */
	public void launchApplication(User user) {
		switchTo().defaultContent();
		if ($(userDetails).isDisplayed() && !$(userDetails).getText().contains(user.getFullName())) {
			refresh();
			logout();
			commonMethods.waitForElementExplicitly(4000);
			openAconexUrl();
			enterCreds(user);
		} else if ($(userDetails).isDisplayed() && $(userDetails).getText().contains(user.getFullName())) {
			refresh();
		} else {
			openAconexUrl();
			enterCreds(user);
		}
	}
    
    /**
     * Method to enter Company Account details
     */
    public void enterUserAccount(String userName) {
        commonMethods.waitForElement(driver, btnAccessCmpnyAct);
        $(btnAccessCmpnyAct).click();
        commonMethods.waitForElement(driver, txtBoxWorkEmail, 60);
        commonMethods.enterTextValue(txtBoxWorkEmail, userName);
        $(btnContinue).click();
    }

    /**
     * Method to enter Single Sign On details
     */
    public void enterSSODetails(String userName, String password) {
        commonMethods.waitForElement(driver, ssoUserName, 60);
        commonMethods.enterTextValue(ssoUserName, userName);
        commonMethods.enterTextValue(ssoPassword, password);
        $(btnSignOn).click();
    }

    /**
     * Method to Register user to IDP User
     */
    public void registerIdpUser(String userId) {
        commonMethods.waitForElement(driver, usernameTxtBox);
        commonMethods.enterTextValue(usernameTxtBox, commonMethods.getUserData(userId, "username"));
        commonMethods.enterTextValue(passwordTxtBox, commonMethods.getUserData(userId, "password"));
        $(btnContinue).click();
    }

    /**
     * Function to switch to the old document page
     */
    public void enableOldDoc() {
        commonMethods.waitForElementExplicitly(3000);
        driver = WebDriverRunner.getWebDriver();
        driver.switchTo().defaultContent();
        commonMethods.waitForElement(driver, document);
        $(document).click();
        commonMethods.waitForElementExplicitly(3000);
        if ($(oldDocLink).isDisplayed()) {
            $(oldDocLink).click();
        }
        refresh();
    }

    public void switchToUnifiedUpload() {
        commonMethods.waitForElementExplicitly(3000);
        driver = WebDriverRunner.getWebDriver();
        driver.switchTo().defaultContent();
        commonMethods.waitForElement(driver, document);
        $(document).click();
        commonMethods.waitForElementExplicitly(3000);
        if ($(tryNowLink).isDisplayed()) {
            $(tryNowLink).click();
        }
        refresh();
    }

    /**
     * Method to launch application
     */
    public <P> void loginAsUser(String url, String userId) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
        commonMethods.waitForElementExplicitly(1000);
        userMap = jsonMapOfMap.get(userId);
        launchApplication(url);
        enterCreds(userMap.get("username").toString(), userMap.get("password").toString());
    }

    /**
     * Method to launch application
     */
    public void launchApplication(String url) {
        switchTo().defaultContent();
        if ($(userDetails).isDisplayed()) {
            refresh();
            logout();
            commonMethods.waitForElementExplicitly(4000);
        }
        openAconexUrl(url);
    }

    /**
     * Method to open the Aconex application in a browser by providing url
     */
    public void openAconexUrl(String url) {
        try {
            open(url);
        } catch (TimeoutException e) {
            if (e.toString().contains("Timed out receiving message from renderer:")) {
                open(url);
            }
        }
        if ($(sslCertPage).isDisplayed()) {
            $(advancedButton).click();
            $(proceedLink).click();
        }

        //Accept terms and condition
        try {
            commonMethods.waitForElement(driver, agreeTermsAndConditions, 6);
            $(agreeTermsAndConditions).click();
        } catch (TimeoutException e) {
            //ignore
        }
    }

    /**
     * Method to click on menu item
     *
     * @return
     */
    public void clickOnMenu(String menuHeader) {
        driver = WebDriverRunner.getWebDriver();
        driver.switchTo().defaultContent();
        commonMethods.waitForElement(driver, menuRow, 45);
        By Menu = By.xpath("//a[@role='tab']//span[text()='" + menuHeader + "']");
        if (!$(Menu).isDisplayed() && $(menuNext).isDisplayed()) {
            $(menuNext).click();
        }
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, Menu);
        $(Menu).click();
    }

    /**
     * Method to verify sub menu items
     *
     * @return
     */
    public boolean verifySubMenuExist(String subMenu) {
        driver = WebDriverRunner.getWebDriver();
        driver.switchTo().defaultContent();
        By xpath = By.xpath("//ul[@class='nav-item-group-list']/li/a[text()='" + subMenu + "']");
        commonMethods.waitForElementExplicitly(2000);
        return $(xpath).isDisplayed();
    }

    /**
     * Method to return the Menu Size
     */
    public int returnMenuSize() {
        commonMethods.waitForElement(driver, userDetails);
        commonMethods.waitForElement(driver, menuBar);
        return $$(menuBar).size();

    }

    /**
     * Function to wait until inner loader disappears.
     */
    public void waitInnerLoaderDisappear() {
        commonMethods.waitForElementHidden(driver, innerLoadingIcon);
    }

    /**
     * Return the project selected
     *
     * @return
     */
    public String returnProject() {
        return $(projectChangerSelect).getText();
    }

    /**
     * Method to return documents' menu name
     */
    protected String getBIMMenu() {
        switchToOriginal();
        commonMethods.waitForElement(driver, btnBIMMenu, 60);
        return $(btnBIMMenu).getText();
    }

    public String verifyHeader(String instance) {
        String headerText = "";
        switch (instance) {
            case "toolbar": {
                commonMethods.waitForElement(driver, headerToolBarSection);
                headerText = $(headerToolBarSection).getText();
                break;
            }
            case "span": {
                commonMethods.waitForElement(driver, headerSpanSection);
                headerText = $(headerSpanSection).getText();
                break;
            }
            case "h1": {
                commonMethods.waitForElement(driver, headerSection);
                headerText = $(headerSection).getText();
                break;
            }
            case "h5": {
                commonMethods.waitForElement(driver, header5Section);
                headerText = $(header5Section).getText();
                break;
            }
            case "ngHeader": {
                commonMethods.waitForElement(driver, toolBarSection);
                headerText = $(toolBarSection).getText();
                break;
            }
        }
        return headerText;
    }
}