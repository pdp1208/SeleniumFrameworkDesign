package com.oracle.babylon.pages.Package;

import com.github.javafaker.Faker;
import com.oracle.babylon.Utils.helper.Navigator;
import com.oracle.babylon.pages.Document.DocumentPage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import java.util.Map;

import static com.codeborne.selenide.Selenide.$;

public class NewPackage extends Navigator {

    private By title = By.xpath("//div[text()='New Package']");
    By packageTypeElement = By.xpath("//select[@id='packageType']");
    By packageTitle = By.xpath("//input[@id='packageTitle']");
    By packageNumber = By.xpath("//input[@id='packageNumber']");
    By revision = By.xpath("//input[@id='revision']");
    By addDocumentsBtn = By.xpath("//button[text()='Add/Update Documents']");
    By saveBtn = By.xpath("//button[text()='Save']");
    By createdPackageNumber = By.xpath("//div[text()='Your package has been created']//b");
    By closeBtn = By.xpath("//button[@id='close']");
    PackagePage packagePage = new PackagePage();
    DocumentPage documentPage = new DocumentPage();


    public void navigateAndVerifyPage() {
        getMenuSubmenu("Packages", "New Package");
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, title);
        Assert.assertTrue("New package page title is not displayed", $(title).isDisplayed());
    }

    public void clickAddDocBtn() {
        $(addDocumentsBtn).click();
    }

    public void clickSaveBtn() {
        $(saveBtn).click();
    }

    /**
     * Method to create the package.
     * If project fields are available, then appropriate option is provided to it
     *
     * @param jsonData
     * @param featureFileData
     * @return
     */
    public void createPackage(Map<String, Object> jsonData, Map<String, String> featureFileData) {
        Faker faker = new Faker();
        String title = faker.book().title();
        String number = faker.company().buzzword() + "-" + faker.color().name() + "-" + faker.number().digit();
        $(packageTypeElement).click();
        Select select = new Select($(packageTypeElement));
        if (jsonData.get("package_type").toString() == null) {
            select.selectByIndex(0);
        } else {
            select.selectByVisibleText(jsonData.get("package_type").toString());
        }
        commonMethods.waitForElement(driver, packageNumber);
        commonMethods.sleep(3000);
        if ($(packageNumber).getAttribute("disabled") == null || !$(packageNumber).getAttribute("disabled").equals("true")) {
            $(packageNumber).sendKeys(number);
        } else {
            System.out.println("Package Number field is auto numbered");
        }
        $(packageTitle).sendKeys(title);
        $(revision).sendKeys(featureFileData.get("Revision"));
        commonMethods.waitForElementExplicitly(2000);
        if (jsonData.containsKey("project_field")) {
            By element = By.xpath("//label[text()='" + jsonData.get("project_field") + "']//..//..//select");
            if ($(element).isDisplayed()) {
                $(element).click();
                select = new Select($(element));
                select.selectByVisibleText(featureFileData.get("Project Field"));
            }
        }
    }

    /**
     * Method to save package and return created package number
     */
    public String savePackage() {
        commonMethods.waitForElement(driver, saveBtn);
        $(saveBtn).click();
        commonMethods.waitForElement(driver, createdPackageNumber, 60);
        String pkNumber = $(createdPackageNumber).getText().split(" ")[0];
        $(closeBtn).click();
        return pkNumber;
    }

    /**
     * Method to verify the document in package
     */
    public void verifyDocInPkg(String docNo) {
        packagePage.verifyDocInPackage(docNo);
    }

}
