package com.oracle.babylon.pages.Setup.ProjectSettings;

import com.codeborne.selenide.ex.ElementNotFound;
import com.oracle.babylon.pages.Setup.ProjectSettingsPage;
import io.cucumber.datatable.DataTable;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;

import java.util.*;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;
import static com.codeborne.selenide.Condition.*;

public class ProjectParticipantsPage extends ProjectSettingsPage {

    private By projectLink = By.xpath("//a[@class='auiCollapsibleSection-header']//span[contains(.,'Project')]");
    private By projectParticipants = By.xpath("//div[@class='auiCollapsibleSection']//div[@class='auiCollapsibleSection-body']//div[contains(.,'Project Participants')]");
    private By workingWeek = By.xpath("//div[@class='auiCollapsibleSection']//div[@class='auiCollapsibleSection-body']//div[contains(.,'Working Week')]");
    private By searchTextBox = By.xpath("//input[@type='text']");
    private By eyeIcon = By.xpath("//a[@title='Visible in the Project Directory']");
    private By threeDots = By.xpath("//button[@class='auiMenuButton auiButton ng-binding']");
    private By changePrjVisbilityLink = By.xpath("//a[contains(text(),'Change Project Visibility')]");
    private By removeUserLink = By.xpath("//a[contains(text(),'Remove User')]");
    private By hiddenUser = By.xpath("//a[@title='Hidden in the Project Directory (Shadow user)']");
    //private By choiceUserId = By.xpath("//div[@id='ui-select-choices-row-0-0']");
    private By choiceUserId = By.xpath("//span[contains(@class,'ui-select-choices-row-inner')]//div");
    private By inviteUser = By.xpath("//button[text()='Invite user']");
    private By searchUser = By.xpath("//input[starts-with(@class,'ui-select-search input-xs')]");
    private By firstUser = By.xpath("//div[@row-index='0']//div[@col-id='userFullName']//span");
    private By userDetailsClose = By.xpath("//button[contains(text(),'Close')]");
    private By projectParticipantsTitle = By.xpath("//p[contains(text(),'Project Participants')]");
    private By organizationTab = By.xpath("//span[contains(text(),'Organization')]");
    private By userTab = By.xpath("//span[contains(text(),'User')]");
    private By addGuestBtn = By.xpath("//div[contains(text(),'Add Guest')]");
    private By newUserBtn = By.xpath("//div[contains(text(),'New User')]");
    private By givenName = By.xpath("//input[@name='USER_FIRST_NAME']");
    private By familyName = By.xpath("//input[@name='USER_LAST_NAME']");
    private By guestSaveBtn = By.xpath("//div[contains(text(),'Save')]");
    private By newUserGivenName = By.xpath("//input[@id='givenName-input']");
    private By newUserMiddleName = By.xpath("//input[@id='middleName-input']");
    private By newUserFamilyName = By.xpath("//input[@id='familyName-input']");
    private By newUserEmail = By.xpath("//div[@id='email']//input[@class='uiTextField-input']");
    private By newUserLoginName = By.xpath("//div[@id='loginName']//input[@class='uiTextField-input']");
    private By newUserPassword = By.xpath("//div[@id='password']//input[@type='password']");
    private By newUserConfirmPassword = By.xpath("//div[@id='passwordConfirm']//input[@type='password']");
    private By newUserInvite = By.xpath("//button[@title='Invite']");
    private By newUserCreatedMsg = By.xpath("//span[contains(text(),'New User Created Successfully')]");
    private By createAnotherUser = By.xpath("//h4[contains(text(),'Create another user')]");
    private By editUserDetails = By.xpath("//h4[contains(text(),'full details')]");
    private By newUserCloseBtn = By.xpath("//button[@title='Close']");
    private By inviteUserHeader = By.xpath("//h1[contains(text(),'Invite a new user')]");
    private By newUserProject = By.xpath("//div[@id='selProjects']");
    private By availablePrjInput = By.xpath("//div[@id='selProjects_bidi']//input");
    private By addPrjBtn = By.xpath("//button[@title='Add item to list']");
    private By okBtn = By.xpath("//button[@title='OK']");
    private By advancedSearch = By.xpath("//button[contains(text(),'Advanced Search')]");
    private By sendEmail = By.xpath("//label[contains(text(),'Send email notification')]");
    private By inviteBtn = By.xpath("//span[contains(text(),'Invite')]");
    private By cancelBtn = By.xpath("//button[contains(text(),'Cancel')]");
    private By removeUser = By.xpath("//button[contains(text(),'Remove')]");
    private By mailCheckbox = By.xpath("//div[@class='ag-header-select-all ag-labeled ag-label-align-right ag-checkbox'][@role='presentation']");
    private By removeBtn = By.xpath("//button[contains(text(),'Remove')]");
    private By firstCheckbox = By.xpath("//div[@row-index=0]//span[@class='ag-selection-checkbox']//span[@class='ag-icon ag-icon-checkbox-unchecked']");
    private By getUserFullName = By.xpath("//span[@class='user-name-cell ng-scope']");
    private By changeProjectVisibilityBtn = By.xpath("//button[contains(text(),'Change Project Visibility')]");
    private By projectVisibilityCheckbox = By.xpath("//input[@id='visibility']");
    private By prjVisibilitySaveBtn = By.xpath("//button[contains(text(),'Save')]");
    private By nameField = By.xpath("//span[contains(text(),'Name')]");
    private By typeField = By.xpath("//span[contains(text(),'Type')]");
    private By organizationField = By.xpath("//span[@class='ag-header-cell-text'][contains(text(),'Organization')]");
    private By prjDirectoryVisibilityField = By.xpath("//span[contains(text(),'Project Directory Visibility')]");
    private By orgAddressField = By.xpath("//span[contains(text(),'Address')]");
    private By orgCityField = By.xpath("//span[contains(text(),'City')]");
    private By orgStateField = By.xpath("//span[contains(text(),'County/State')]");
    private By orgCountryField = By.xpath("//span[contains(text(),'Country')]");
    private By createMailGrpBtn = By.xpath("//div[contains(text(),'Create Mailing Group')]");
    private By createGuestBtn = By.xpath("//div[contains(text(),'Create Guest')]");
    private By directoryOkBtn = By.xpath("//div[contains(text(),'OK')]");
    private By projectTab = By.xpath("//li[contains(text(),'Project')]");
    private By globalTab = By.xpath("//li[contains(text(),'Global')]");
    private By directorySearchBtn = By.xpath("//button[@id='btnSearch_page']");
    private By noRecipients = By.xpath("//div[contains(text(),'No recipients currently selected')]");
    private By firstNameInput = By.xpath("//input[@id='FIRST_NAME']");
    private By userCheckBox = By.xpath("//input[@name='USERS_LIST']");
    private By addFullUser = By.xpath("//div[contains(text(),'Add as Full User')]");
    private By addShadowUser = By.xpath("//div[contains(text(),'Add as Shadow User')]");
    private By directoryUserDelete = By.xpath("//tr[@class='dataRow']//a//img");
    private By namesList = By.xpath("//div[@col-id='userFullName']");
    private By orgList = By.xpath("//div[@col-id='organizationName']");
    private By orgNameList = By.xpath("//div[@col-id='tradingName']");
    private By orgTypeList = By.xpath("//div[@col-id='orgType']");
    private By orgAddressList = By.xpath("//div[@col-id='fullAddress']");
    private By orgCityList = By.xpath("//div[@col-id='city']");
    private By orgStateList = By.xpath("//div[@col-id='state']");
    private By orgCountryList =By.xpath("//div[@col-id='country']");
    private String listedUser = "//span[contains(@class,'select-choice')]//div[contains(.,'ORG_NAME')]";
    private By lastNameInput =By.xpath("//input[@id='LAST_NAME']");
    private By firstUnChkBx = By.xpath("//div[@row-index=0]//span[@class='ag-selection-checkbox']//span[@class='ag-icon ag-icon-checkbox-checked']");
    String path = configFileReader.getProjParticipantsDataPath();
    private By workingDays = By.xpath("//div[@class='weekday-container']//span[@class='weekday workday-true']");
    private By nonWorkingDays = By.xpath("//div[@class='weekday-container']//span[@class='weekday workday-false']");
    /**
     * Method to navigate to Project Settings page and then navigating to Project Participants page
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Setup", "Project Settings");
        navigateToProjectParticipants();
    }

    /**
     * Method to navigate to Project Participants page
     */

    public void navigateToProjectParticipants() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, projectLink, 30);
        $(projectLink).click();
        $(projectParticipants).click();
    }

    /**
     * Method to search user
     *
     * @param username
     */

    public void searchUser(String username) {
        commonMethods.waitForElement(driver, searchTextBox, 40);
        $(searchTextBox).clear();
        $(searchTextBox).sendKeys(username);
        $(searchTextBox).pressEnter();
    }

    /**
     * Method to disable user Visibility
     *
     * @param userName
     */

    public void toggleUserVisibility(String userName, boolean instance) {
        By toogle = (instance) ? By.xpath("//div[@class='ag-center-cols-viewport']/div/div[contains(.,'" + userName + "')]//a[@title='Hidden in the Project Directory (Shadow user)']") : By.xpath("//div[@class='ag-center-cols-viewport']/div/div[contains(.,'" + userName + "')]//a[@title='Visible in the Project Directory']");
        commonMethods.waitForElement(driver, toogle, 60);
        commonMethods.waitForElementExplicitly(3000);
        $(toogle).click();
        commonMethods.waitForElementExplicitly(2000);
    }

    public void toggleUser(String userName, boolean instance) {
       commonMethods.waitForElementExplicitly(3000);
        String currentState = $(By.xpath("//div[@class='ag-center-cols-viewport']//div[@col-id='userFullName']//span[text()='" + userName + "']//following::div[@col-id='shadowUser']//a")).getAttribute("title");
        if(currentState.equals("Hidden in the Project Directory (Shadow user)")) {
            if (instance)
                $(By.xpath("//div[@class='ag-center-cols-viewport']//div[@col-id='userFullName']//span[text()='" + userName + "']//following::div[@col-id='shadowUser']//a")).click();
        } else {
            if(instance==false)
                $(By.xpath("//div[@class='ag-center-cols-viewport']//div[@col-id='userFullName']//span[text()='" + userName + "']//following::div[@col-id='shadowUser']//a")).click();
        }
        commonMethods.waitForElementExplicitly(5000);
    }

    /**
     * Method to check whether the user is Hidden
     *
     * @return
     */

    public boolean checkHiddenUser() {
        commonMethods.waitForElementExplicitly(2000);
        return $(hiddenUser).isDisplayed();
    }

    /**
     * Method to get the Org Name on the Suggestion list
     */
    public String getOrgName() {
        commonMethods.waitForElement(driver, choiceUserId);
        return $(choiceUserId).getText();
    }
    public void searchUserOnInvite(String fullName)
    {
        commonMethods.waitForElement(driver, inviteUser, 60);
        $(inviteUser).click();
        commonMethods.waitForElement(driver, searchUser, 45);
        $(searchUser).sendKeys(fullName);
        commonMethods.waitForElementExplicitly(2000);
    }

    public void enterInviteBtn()
    {
        $(searchUser).sendKeys(Keys.ENTER);
        commonMethods.waitForElement(driver, inviteBtn, 40);
        $(inviteBtn).click();
    }
    /**
     * Method to click on the Invite User
     */
    public void inviteUser(String fullName) {
        commonMethods.waitForElement(driver, inviteUser, 60);
        $(inviteUser).click();
        commonMethods.waitForElement(driver, searchUser, 45);
        $(searchUser).sendKeys(fullName);
        commonMethods.waitForElement(driver, By.xpath("//div[@class='ng-binding ng-scope']"), 45);
        commonMethods.waitForElementExplicitly(2000);
        $(searchUser).sendKeys(Keys.ENTER);
        commonMethods.waitForElement(driver, inviteBtn, 40);
        $(inviteBtn).click();
    }

    /**
     * Method to click on the Invite User
     *
     * @param fullName Full name of user.
     * @param orgName Org name of the user.
     */
    public void inviteUser(String fullName, String orgName) {
        commonMethods.waitForElement(driver, inviteUser, 60);
        $(inviteUser).click();
        commonMethods.waitForElement(driver, searchUser, 45);
        $(searchUser).sendKeys(fullName);
        commonMethods.waitForElementExplicitly(2000);
        $(By.xpath(listedUser.replace("ORG_NAME", orgName))).waitUntil(appears,4000).click();
        commonMethods.waitForElement(driver, inviteBtn, 40);
        $(inviteBtn).click();
    }

    /**
     * Method to verify the participant added
     */
    public boolean verifyParticipantAdded(String fullName) {
        return $(By.xpath("//div[@col-id='userFullName']//span[text()='" + fullName + "']")).isDisplayed();
    }

    /**
     * Method to enable visibility
     */
    public void showUser(String userName) {
        By enable = By.xpath("//div[@class='ag-center-cols-viewport']/div/div[contains(.,'" + userName + "')]//a[@title='Hidden in the Project Directory (Shadow user)']");
        commonMethods.waitForElement(driver, enable);
        $(enable).click();
    }

    /**
     * Function to verify tabs present on the page
     */

    public void verifyTab(List<String> data) {
        for (String element : data) {
            By tab = By.xpath("//span[contains(text(),'" + element + "')]");
            commonMethods.waitForElement(driver, tab, 45);
            Assert.assertTrue($(tab).isDisplayed());
        }
    }

    /**
     * Method to verify the user searched is correctly displayed
     *
     * @param data
     */

    public void verifyUserDetails(List<String> data) {
        for (String field : data) {
            By element = By.xpath("//td[contains(text(),'" + field + "')]");
            commonMethods.waitForElement(driver, element, 45);
            Assert.assertTrue($(element).isDisplayed());
        }
    }

    /**
     * Method to click project participants button
     */

    public void clickProjectParticipants() {
        commonMethods.waitForElementExplicitly(4000);
        $(projectParticipants).click();
    }

    /**
     * Method to click working week
     */

    public void clickWorkingWeek() {
        $(workingWeek).click();
    }

    /**
     * Method to click on first user
     */

    public void clickFirstUser() {
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, firstUser, 60);
        $(firstUser).click();
    }

    /**
     * Method to verify the user name
     */

    public void verifyUserName(String userName) {
        $(By.xpath("//h2[contains(text(),'" + userName + "')]")).isDisplayed();
    }

    /**
     * Method to click on user details close button
     */

    public void clickDetailsCloseBtn() {
        $(userDetailsClose).click();
    }

    /**
     * Method to verify project participants page
     *
     * @return
     */

    public boolean verifyProjectParticipantsPage() {
        return $(projectParticipantsTitle).isDisplayed();
    }

    /**
     * Method to click Organization tab
     */

    public void clickOrganizationTab() {
        $(organizationTab).click();
    }

    /**
     * Method to click Users tab
     */

    public void clickUserTab() {
        $(userTab).click();
    }

    /**
     * Method to search organization
     *
     * @param orgName
     */

    public void searchOrganization(String orgName) {
        commonMethods.waitForElement(driver, searchTextBox, 20);
        $(searchTextBox).sendKeys(orgName);
        $(searchTextBox).pressEnter();
    }

    /**
     * Method to click Organization
     * @return
     * @param orgName
     */
    public boolean verifyOrganization(String user,String orgName) {
        commonMethods.waitForElement(driver,  By.xpath("//div[@class='ag-center-cols-clipper']//a[contains(text(),'" + orgName + "')]"), 65);
        return tableProjectFieldNameIsDisplayed(driver,commonMethods.getUserData(user, "organisation"));
    }

    public boolean verifyOrganizationInOrgInfoPage(String orgName) {
        return tableProjectFieldNameIsDisplayed(driver, orgName);
    }

    /**
     * Method to verify Organization fields
     *
     * @param data
     */

    public void verifyOrgFields(List<String> data) {
        for (String field : data) {
            By element = By.xpath("//td[contains(text(),'" + field + "')]");
            commonMethods.waitForElement(driver, element, 40);
            Assert.assertTrue($(element).isDisplayed());
        }
    }

    /**
     * Method to verify Admin fields
     *
     * @param data
     */

    public void verifyAdminFields(List<String> data) {
        for (String field : data) {
            By element = By.xpath("//th[contains(text(),'" + field + "')]");
            Assert.assertTrue($(element).isDisplayed());
        }
    }

    /**
     * Method to verify User buttons on the project participants page
     */

    public void verifyUserButtons() {
        commonMethods.waitForElement(driver, addGuestBtn, 45);
        Assert.assertTrue($(addGuestBtn).isDisplayed());
        commonMethods.waitForElement(driver, newUserBtn, 45);
        Assert.assertTrue($(newUserBtn).isDisplayed());
    }

    /**
     * Method to add Guest from project participants page
     */

    public void addGuest() {
        $(addGuestBtn).click();
        $(givenName).sendKeys(faker.name().firstName());
        $(familyName).sendKeys(faker.name().lastName());
    }

    /**
     * Method to click save button for Guest
     */

    public void clickGuestSave() {
        $(guestSaveBtn).click();
    }

    /**
     * Method to click New User button
     */

    public void clickNewUser() {
        commonMethods.waitForElement(driver, newUserBtn, 45);
        $(newUserBtn).click();
    }

    /**
     * Method to create New User
     */

    public void createNewUser(String user, String project) {
        String firstName = faker.name().firstName();
        String password = faker.internet().password() + "81";
        $(newUserGivenName).sendKeys(firstName);
        $(newUserMiddleName).sendKeys(faker.name().nameWithMiddle());
        $(newUserFamilyName).sendKeys(faker.name().lastName());
        $(newUserLoginName).sendKeys(faker.number().digit() + faker.name().firstName() + "12");
        $(newUserEmail).sendKeys(faker.internet().emailAddress());
        $(newUserPassword).sendKeys(password);
        $(newUserConfirmPassword).sendKeys(password);
        if (project != null) {
            selectProject(project);
        }
        commonMethods.writeToJson("name",user,firstName,path);
        $(newUserInvite).click();

    }

    /**
     * Method to verify the messages displayed after creating New User
     */

    public void verifyNewUserMsg() {
        commonMethods.waitForElement(driver, newUserCreatedMsg, 45);
        Assert.assertTrue($(newUserCreatedMsg).isDisplayed());
        commonMethods.waitForElement(driver, createAnotherUser, 45);
        Assert.assertTrue($(createAnotherUser).isDisplayed());
        commonMethods.waitForElement(driver, editUserDetails, 45);
        Assert.assertTrue($(editUserDetails).isDisplayed());
    }

    /**
     * Method to verify New User Close Button
     */

    public void verifyNewUserClose() {
        $(newUserCloseBtn).click();
        Assert.assertTrue($(inviteUserHeader).isDisplayed());
    }

    /**
     * Method to verify User is present
     *
     * @param user
     * @return
     */

    public boolean verifyNoUser(String user) {
        commonMethods.waitForElementExplicitly(3000);
        By element = By.xpath("//span[contains(text(),\"" + user + "\")]");
        return $(element).isDisplayed();
    }

    /**
     * Method to select project for the New User created
     *
     * @param projName
     */

    public void selectProject(String projName) {
        $(newUserProject).click();
        $(availablePrjInput).sendKeys(projName);
        $(By.xpath("//option[contains(text(),'" + projName + "')]")).click();
        $(addPrjBtn).click();
        $(okBtn).click();
    }

    /**
     * Method to verify the elements in Invite User pop up method
     */

    public void verifyInviteUser() {
        Assert.assertTrue($(searchUser).isDisplayed());
        Assert.assertTrue($(advancedSearch).isDisplayed());
        Assert.assertTrue($(sendEmail).isDisplayed());
        Assert.assertTrue($(inviteBtn).isDisplayed());
        Assert.assertTrue($(cancelBtn).isDisplayed());
        commonMethods.waitForElement(driver, cancelBtn, 35);
        $(cancelBtn).click();
    }

    /**
     * Method to click Invite User
     */

    public void clickInviteUser() {
        $(inviteUser).click();
    }

    /**
     * Method to remove user from the project and verify
     *
     * @param user
     * @param project
     */

    public void removeAndVerify(String user, String project) {
        commonMethods.waitForElement(driver, removeBtn, 45);
        $(removeUser).click();
        commonMethods.waitForElement(driver, removeBtn, 40);
        Assert.assertTrue($(By.xpath("//div[contains(text(),'Remove " + user + " from the " + project + " project?')]")).isDisplayed());
        $(removeBtn).click();
    }

    /**
     * Method to select the first checkbox
     */

    public void selectFirstCheckBox() {
        commonMethods.waitForElementExplicitly(4000);
        try {
            $(firstCheckbox).click();
        }catch(ElementNotFound e){
            $(firstUnChkBx).click();
        }
    }

    /**
     * Method to get User name after searching the user
     */

    public String getUserName() {
        commonMethods.waitForElement(driver, getUserFullName, 45);
        return $(getUserFullName).getText();
    }

    /**
     * Method to change project visibility through change project visibility button
     */

    public void changeVisibility() {
        commonMethods.waitForElement(driver, changeProjectVisibilityBtn, 35);
        $(changeProjectVisibilityBtn).click();
        commonMethods.waitForElement(driver, projectVisibilityCheckbox, 15);
        $(projectVisibilityCheckbox).click();
        commonMethods.waitForElement(driver, prjVisibilitySaveBtn, 45);
        $(prjVisibilitySaveBtn).click();
    }

    /**
     * Method to verify project visibility
     * @return
     */

    public boolean verifyVisibility() {
        try {
            commonMethods.waitForElementExplicitly(4000);
            return $(eyeIcon).isDisplayed();
        } catch (TimeoutException e) {
            e.printStackTrace();
            return false;
        }

    }

    /**
     * Method to click on three dots present
     *
     */

    public void clickDots() {
        $(threeDots).click();
    }

    /**
     * Method to click on the visibility button
     *
     */

    public void clickVisibility() {
        $(changePrjVisbilityLink).click();
        $(projectVisibilityCheckbox).click();
        $(prjVisibilitySaveBtn).click();
    }

    /**
     * Method to remove USer
     *
     */

    public void removeUser() {
        $(removeUserLink).click();
        $(removeBtn).click();
    }

    /**
     * Method to verify the buttons present on the page
     */

    public void verifyButtons() {
        commonMethods.waitForElement(driver, inviteUser, 45);
        Assert.assertTrue($(inviteUser).isDisplayed());
        Assert.assertTrue($(changeProjectVisibilityBtn).isDisplayed());
        Assert.assertTrue($(removeUser).isDisplayed());
        Assert.assertTrue($(mailCheckbox).isDisplayed());
    }

    /**
     * Method to verify the different columns present on the page
     *
     * @param data
     */

    public void verifyColumns(List<String> data) {
        for (String name : data) {
            Assert.assertTrue($(By.xpath("//div[@ref='eLabel']//span[contains(text(),'" + name + "')]")).isDisplayed());
        }
    }

    /**
     * Method to verify the Invite User button is present
     *
     * @return
     */

    public boolean verifyInviteUserBtn() {
        return $(inviteUser).isDisplayed();
    }

    /**
     * Method to verify Remove User button is present
     *
     * @return
     */

    public boolean verifyRemoveUserBtn() {
        return $(removeUser).isDisplayed();
    }

    /**
     * Method to verify Change Project Visibility button is present
     *
     * @return
     */

    public boolean verifyChangeProjectVisibilityBtn() {
        return $(changeProjectVisibilityBtn).isDisplayed();
    }

    /**
     * Method to verify Project Participants button is present
     *
     * @return
     */

    public boolean verifyProjectParticipants() {
        return $(projectParticipants).isDisplayed();
    }

    /**
     * Method to verify Add Guest button is present
     *
     * @return
     */

    public boolean verifyAddGuestBtn() {
        return $(addGuestBtn).isDisplayed();
    }

    /**
     * Method to verify New User button is present
     *
     * @return
     */

    public boolean verifyNewUserBtn() {
        return $(newUserBtn).isDisplayed();
    }

    /**
     * Method to search User by entering each letter in search text box
     *
     * @param name
     */

    public void searchByLetter(String name, String tab) {
        $(searchTextBox).clear();
        for (int i = 0; i < name.length(); i++) {
            char c = name.charAt(i);
            String s = Character.toString(c);
            $(searchTextBox).sendKeys(s);
            $(searchTextBox).pressEnter();
            Assert.assertTrue(verifyResultsPresent(s, tab));
            if (name.charAt(i) == '\0') {
                break;
            }
        }
    }

    /**
     * Method to verify search results are present
     *
     * @param name
     * @return
     */

    public boolean verifyResultsPresent(String name, String tab) {
        By element;
        if(tab.equalsIgnoreCase("user"))
            element = By.xpath("//div[@col-id='userFullName']/span[contains(text(),'" + name + "')]");
        else element = By.xpath("//div[@col-id='tradingName']//a[contains(text(),'" + name + "')]");
        commonMethods.waitForElement(driver,element,30);
        commonMethods.waitForElementExplicitly(2000);
        return $(element).isDisplayed();
    }

    /**
     * Method to click Name field
     */

    public void clickNameField() {
        $(nameField).click();
    }

    /**
     * Method to click Organisation field
     */

    public void clickOrganizationField() {
        $(organizationField).click();
    }

    /**
     * Method to click Type field
     */

    public void clickTypeField() {
        $(typeField).click();
    }

    /**
     * Method to click Project Directory field
     */

    public void clickDirectoryField() {
        $(prjDirectoryVisibilityField).click();
    }

    /**
     * Method to click Organisation Address field
     */

    public void clickOrgAddressField() {
        $(orgAddressField).click();
    }

    /**
     * Method to click Organisation City field
     */

    public void clickOrgCityField() {
        $(orgCityField).click();
    }

    /**
     * Method to click Organisation State field
     */

    public void clickOrgStateField() {
        $(orgStateField).click();
    }

    /**
     * Method to click Organisation Country field
     */

    public void clickOrgCountryField() {
        $(orgCountryField).click();
    }

    /**
     * Method to click get All Names present in User tab
     *
     * @return
     */

    public List<String> returnValues(By elements, String path) {
        commonMethods.waitForElementExplicitly(1000);
        List<String> allValues = new ArrayList<>();
        List<WebElement> allElements = driver.findElements(elements);
        for (int i = 0; i < allElements.size()-1; i++) {
            String value = driver.findElement(By.xpath("//div[@row-index='" + i + "']" + path + "")).getText();
            allValues.add(value);

        }
        return allValues;

    }

    public List<String> getAllNames() {
        return returnValues(namesList, "//div[@col-id='userFullName']");
    }

    /**
     * Method to verify the sorting of data
     *
     * @param actual
     * @param expected
     * @param instance
     * @return
     */

    public boolean verifySort(List<String> actual, List<String> expected, String instance) {
        if (instance.equalsIgnoreCase("Ascending"))
            Collections.sort(actual);
        else
            actual.sort(Collections.reverseOrder());
        return actual.equals(expected);
    }

    /**
     * Method to click get All Organisation present in User tab
     *
     * @return
     */

    public List<String> getAllOrganization() {
        return  returnValues(orgList,"//div[@col-id='organizationName']");
    }

    /**
     * Method to click get All Types present in User tab
     *
     * @return
     */

    public List<String> getAllTypes() {
        List<String> allTypes = new ArrayList<>();
        List<WebElement> types = driver.findElements(By.xpath("//div[@col-id='userType']"));
        for (int i = 1; i < types.size(); i++) {
            allTypes.add(types.get(i).getText());
        }
        return allTypes;
    }

    /**
     * Method to click get All Names present in Org tab
     *
     * @return
     */

    public List<String> getAllOrgNames() {
        return returnValues(orgNameList,"//div[@col-id='tradingName']//a");
    }


    /**
     * Method to click get All Types present in Org tab
     *
     * @return
     */

    public List<String> getAllOrgTypes() {
        return returnValues(orgTypeList,"//div[@col-id='orgType']");
    }


    /**
     * Method to click get All Address present in Org tab
     *
     * @return
     */

    public List<String> getAllOrgAddress() {
        return returnValues(orgAddressList,"//div[@col-id='fullAddress']");
    }


    /**
     * Method to click get All City present in Org tab
     *
     * @return
     */

    public List<String> getAllOrgCity() {
        return returnValues(orgCityList,"//div[@col-id='city']");
    }

    /**
     * Method to click get All State present in Org tab
     *
     * @return
     */

    public List<String> getAllOrgState() {
        return returnValues(orgStateList,"//div[@col-id='state']");
    }

    /**
     * Method to click get All Country present in Org tab
     * @return
     */

    public List<String> getAllOrgCountry() {
        return returnValues(orgCountryList,"//div[@col-id='country']");
    }

    /**
     * Method to get the total count of Names present
     *
     * @return
     */

    public int getAllNamesCount() {
        List<String> allNames = getAllNames();
        return allNames.size();
    }

    /**
     * Method to verify the count of users present
     *
     * @param actual
     * @return
     */

    public boolean verifyUserCount(int actual) {
        return $(By.xpath("//div[contains(text(),'" + actual + " User(s)')]")).isDisplayed();
    }

    /**
     * Method to click on the Advanced search
     */

    public void clickAdvancedSearch() {
        $(advancedSearch).click();
    }

    /**
     * Method to verify the elements in Directory Search page
     */

    public void verifyDirectoryElements() {
        Assert.assertTrue($(createMailGrpBtn).isDisplayed());
        Assert.assertTrue($(createGuestBtn).isDisplayed());
        Assert.assertTrue($(directoryOkBtn).isDisplayed());
        Assert.assertTrue($(noRecipients).isDisplayed());
        Assert.assertTrue($(projectTab).isDisplayed());
        Assert.assertTrue($(globalTab).isDisplayed());
        Assert.assertTrue($(directorySearchBtn).isDisplayed());
    }

    /**
     * Method to add As a Full User
     *
     * @param userName
     */

    public void addFullUser(String userName) {
        String[] userNameSplit= userName.split(" ");
        $(firstNameInput).clear();
        $(firstNameInput).sendKeys(userNameSplit[0]);
        $(lastNameInput).clear();
        $(lastNameInput).sendKeys(userNameSplit[1]);
        $(directorySearchBtn).click();
        $(userCheckBox).setSelected(true);
        $(addFullUser).click();
    }

    /**
     * Method to verify the user in Target list
     *
     * @param user
     * @return
     */

    public boolean verifyTargetList(String user) {
        return $(By.xpath("//td[contains(text(),'" + user + "')]")).isDisplayed();
    }

    /**
     * Method to click on Directory OK button
     */

    public void clickDirectoryOkBtn() {
        $(directoryOkBtn).click();
    }

    /**
     * Method to click on the remove icon present in Directory search
     */

    public void removeTargetUser() {
        $(directoryUserDelete).click();
    }

    /**
     * Method to add As a Shadow User
     *
     * @param userName
     */

    public void addShadowUser(String userName) {
        String[] userNameSplit= userName.split(" ");
        $(firstNameInput).clear();
        $(firstNameInput).sendKeys(userNameSplit[0]);
        $(lastNameInput).clear();
        $(lastNameInput).sendKeys(userNameSplit[1]);
        $(directorySearchBtn).click();
        $(userCheckBox).setSelected(true);
        $(addShadowUser).click();
    }

    /**
     * Method to check if the table field Project name is displayed in the UI page
     *
     * @param text
     * @return
     */
    public boolean tableProjectFieldNameIsDisplayed(WebDriver driver, String text) {
        By by = By.xpath("//td[contains(text(),'Trading Name')]//following-sibling::td[text()='" + text + "']");
        commonMethods.waitForElement(driver, by, 60);
        return driver.findElement(by).isDisplayed();
    }

    /**
     * Method to verify working week details
     */
    public List<String> verifyWorkingDays() {
        commonMethods.waitForElementExplicitly(4000);
        return commonMethods.getValues(workingDays);
    }

    /**
     * Method to verify nonworking days details
     */
    public List<String> verifyNonWorkingDays() {
        commonMethods.waitForElementExplicitly(4000);
        return commonMethods.getValues(nonWorkingDays);
    }

    /**
     * Method to click on the organization
     * @param orgName
     */
    public void clickOrganization(String orgName){
        By element = By.xpath("//div[@class='ag-center-cols-clipper']//a[contains(text(),'" + orgName + "')]");
        commonMethods.waitForElement(driver,  element, 65);
        $(element).click();
    }
}
