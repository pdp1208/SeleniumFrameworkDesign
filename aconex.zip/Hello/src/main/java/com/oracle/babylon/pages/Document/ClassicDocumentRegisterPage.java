package com.oracle.babylon.pages.Document;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

/**
 * Class that contains all the methods specific to the Classic Document Register page
 */
public class ClassicDocumentRegisterPage extends DocumentRegisterPage {

    //old search identifiers
    private By tblHeaders = By.xpath("//table[@id='resultTable']//th");
    private String tblRows = "//table[@id='resultTable']//tbody/tr";
    private By btnTransmit = By.xpath("//button[@id='btnTransmitMenu']");
    private By lnkCreateTransmittal = By.xpath("//a[contains(text(),'Create a Transmittal')]");
    private By lnkSelectAllRecords = By.xpath("//a[contains(text(),'Select All Results')]");
    private By imgSelectAllMenu = By.xpath("//table[@id='resultTable']//th[1]//img");
    private String sltTFSelectedList = "//select[@id='selectedUnregColumns']";
    private String sltTFAvailableList = "//select[@id='selectedUnregColumns_AVAIL']";
    private By showDocHistory = By.xpath("//input[@id='showDocHistory']");
    private By btnMarkNLIU = By.xpath("//div[contains(text(),'Mark as No Longer in Use')]");
    private By editUploadNewVersion = By.xpath("//div[text()='Edit / Upload new version']");
    private By documentRegisterTab = By.xpath("//ul[@class='uiTabs-list']//li[contains(text(),'Document register')]");
    //old saved search
    private String drpdwnSavedSearches = "//select[@id='savedsearches']";
    private By lblManagerSavedSearches = By.xpath("//span[text()='Manage Saved Searches']");
    private String sltManageLabels = "//select[@id='ssEditId']";
    private By txtBoxEditSSName = By.xpath("//input[@id='ssEditName']");
    private By lnkDelete = By.xpath("//a[text()='delete']");
    private By btnSaveSearchAs = By.xpath("//button[@id='btnSaveSearchAs']");
    private By txtBoxSearchName = By.xpath("//input[@id='savedSearchName']");
    private By btnOK = By.xpath("//button[@id='btnsaveSearchPanel_ok']");
    private By btnManageSSOk = By.xpath("//button[@id='btnmanageSavedSearchesPanel_ok']");
    private By btnManageSSCancel = By.xpath("//button[@id='btnmanageSavedSearchesPanel_cancel']");
    //old search add/remove columns
    private By btnAddRemoveCol = By.xpath("//div[contains(text(),'Add/Remove Columns')]");
    private String sltSelectedList = "//select[@id='selectedRegColumns']";
    private String sltAvailableList = "//select[@id='selectedRegColumns_AVAIL']";
    private By btnAddRemoveColOK = By.xpath("//button[@id='btnconfigureColumnsPanel_ok']");
    private By resultSummary = By.xpath("//div[@id='numResults']");

    /**
     * Function to create old saved search in documents
     *
     * @param name
     * @param sharingInfo
     */
    public void createDocSavedSearch(String name, String sharingInfo) {
        if (verifyDocSavedSearch(name)) deleteDocSavedSearch(name);
        else $(btnManageSSCancel).click();
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        $(btnSaveSearchAs).click();
        commonMethods.waitForElement(driver, txtBoxSearchName);
        $(txtBoxSearchName).sendKeys(name);
        $(By.xpath("//label[contains(text(),'" + sharingInfo + "')]/../input")).click();
        $(btnOK).click();
    }

    /**
     * Function to verify doc saved search
     *
     * @param savedSearch
     */
    public Boolean verifyDocSavedSearch(String savedSearch) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(1000);
        commonMethods.waitForElement(driver, By.xpath(drpdwnSavedSearches), 60);
        commonMethods.enterDropdownValue(By.xpath(drpdwnSavedSearches), "Manage Saved Searches");
        commonMethods.waitForElement(driver, lblManagerSavedSearches, 60);
        return $(By.xpath(sltManageLabels + "//option[text()='" + savedSearch + "']")).isDisplayed();
    }

    /**
     * Function to delete doc saved search
     *
     * @param name
     */
    public void deleteDocSavedSearch(String name) {
        verifyAndSwitchFrame();
        commonMethods.enterDropdownValue(By.xpath(sltManageLabels), name);
        commonMethods.waitForElement(driver, lnkDelete);
        actions.moveToElement($(lnkDelete)).click().build().perform();
//        $(lnkDelete).click();
        commonMethods.waitForElementExplicitly(2000);
        Assert.assertTrue(verifyAlert("Delete saved search."));
        commonMethods.waitForElementExplicitly(1000);
        verifyAndSwitchFrame();
        $(btnManageSSOk).click();
    }

    /**
     * Function to verify saved search options for old saved search
     *
     * @param savedSearchValues
     * @return
     */
    public Boolean verifySavedSearchOptions(List<String> savedSearchValues) {
        List<String> savedOptionsText = new ArrayList<>();
        verifyAndSwitchFrame();
        for (WebElement element : $$(By.xpath(drpdwnSavedSearches + "//optgroup")))
            savedOptionsText.add($(element).getAttribute("label"));
        return savedOptionsText.containsAll(savedSearchValues);
    }

    /**
     * Function to verify doc saved search from old saved search dropdown
     *
     * @param savedSearch
     */
    public Boolean verifyCreatedSavedSearch(String savedSearch) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(1000);
        commonMethods.waitForElement(driver, By.xpath(drpdwnSavedSearches), 60);
        return $(By.xpath(drpdwnSavedSearches + "//option[text()='" + savedSearch + "']")).isDisplayed();
    }

    /**
     * Click on save search As Button in ol saved search
     */
    public void clickSaveSearchAs() {
        verifyAndSwitchFrame();
        $(btnSaveSearchAs).click();
    }

    /**
     * Function to verify saved search options
     * 1.Not shared (visible only to creator of this search)
     * 2.Shared with everyone in my organization
     * 3.Shared with everyone on this project
     *
     * @param sharingInfo
     * @return
     */
    public Boolean verifyVisibilityOptions(String sharingInfo) {
        commonMethods.waitForElement(driver, btnOK, 30);
        return $(By.xpath("//label[contains(text(),'" + sharingInfo + "')]/..//input")).isEnabled();
    }

    /**
     * Function to click on the saved search from dropdown
     *
     * @savedSearch is the search name which has to be clicked from the dropdown
     */
    public void selectSavedSearch(String savedSearch) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.enterDropdownValue(By.xpath(drpdwnSavedSearches), savedSearch);
    }

    /**
     * Function to add columns if not present from add/remove columns
     */
    public void addColumns(String columnName, String instance) {
        commonMethods.waitForElement(driver, btnAddRemoveCol, 60);
        commonMethods.getElementInViewAndUp(btnAddRemoveCol);
        commonMethods.waitForElementExplicitly(1000);
        $(btnAddRemoveCol).doubleClick();
        verifyAndSwitchFrame();
        if (instance.equalsIgnoreCase("temporary files")) {
            commonMethods.waitForElement(driver, By.xpath(sltTFSelectedList));
            if (!$(By.xpath(sltTFSelectedList + "//option[text()='" + columnName + "']")).isDisplayed())
                commonMethods.enterDropdownValue(By.xpath(sltTFAvailableList), columnName);
        } else {
            commonMethods.waitForElement(driver, By.xpath(sltSelectedList));
            if (!$(By.xpath(sltSelectedList + "//option[text()='" + columnName + "']")).isDisplayed())
                commonMethods.enterDropdownValue(By.xpath(sltAvailableList), columnName);
        }
        commonMethods.waitForElementExplicitly(1000);
        $(btnAddRemoveColOK).click();
    }

    /**
     * Function to get search results of a particular row and column of old document search results
     */
    public String getDocumentResults(String colName, int row) {
        commonMethods.waitForElement(driver, tblHeaders, 60);
        int col = commonMethods.getValues(tblHeaders).indexOf(colName) + 1;
        return $(By.xpath(tblRows + "[" + row + "]/td[" + col + "]")).getText();
    }

    /**
     * Function to create Transmittal for All documents in old search
     */
    public void createTransmittals() {
        searchButton();
        verifyAndSwitchFrame();
        selectAllResults();
        commonMethods.waitForElementExplicitly(3000);
        clickTransmit();
        clickCreateTransmittal();
        driver.switchTo().defaultContent();
    }

    /**
     * Function to select all records in old document search
     */
    public void selectAllResults() {
        commonMethods.waitForElement(driver, tblHeaders, 60);
        commonMethods.getElementInViewAndUp(imgSelectAllMenu);
        $(imgSelectAllMenu).click();
        commonMethods.waitForElement(driver, lnkSelectAllRecords);
        $(lnkSelectAllRecords).click();
        commonMethods.waitForElementExplicitly(1000);
    }

    /**
     * Function to click on transmit button in old doc search
     */
    public void clickTransmit() {
        commonMethods.waitForElement(driver, btnTransmit);
        $(btnTransmit).click();
    }

    /**
     * Function to click create transmittal link under transmit in old doc search
     */
    public void clickCreateTransmittal() {
        commonMethods.waitForElement(driver, lnkCreateTransmittal);
        $(lnkCreateTransmittal).click();
    }

    /**
     * Function to validate error message if duplicate search name is entered in old saved search
     *
     * @param name is the name of the search name which is duplicate
     * @return
     */
    public boolean validateDuplicateSSError(String name) {
        $(btnSaveSearchAs).click();
        commonMethods.waitForElement(driver, txtBoxSearchName);
        $(txtBoxSearchName).sendKeys(name);
        $(btnOK).click();
        return verifyAlert("You've already saved a search and called it '" + name);
    }

    /**
     * Function to edit saved search
     */
    public void editSavedSearch(String columnValue, String newValue, String sharingInfo) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, By.xpath(sltManageLabels));
        $(By.xpath(sltManageLabels)).click();
        commonMethods.enterDropdownValue(By.xpath(sltManageLabels), columnValue);
        commonMethods.waitForElement(driver, txtBoxEditSSName);
        commonMethods.enterTextValue(txtBoxEditSSName, newValue);
        $(By.xpath("//label[@for='ssEditShared' and contains(text(),'" + sharingInfo + "')]/../input")).click();
        $(btnManageSSOk).click();
    }

    /**
     * Function to click on checkbox show document history in old doc search
     */
    public void clickShowDocHistory(boolean value) {
        verifyAndSwitchFrame();
        $(showDocHistory).setSelected(value);
    }

    /**
     * Function to verify show document history checkbox in old doc search
     *
     * @return
     */
    public boolean verifyShowDocHistory() {
        commonMethods.waitForElement(driver, showDocHistory, 20);
        return $(showDocHistory).isSelected();
    }

    /**
     * Function to make document as No longer In Use for old doc search
     */
    public void markDocumentNLIU() {
        commonMethods.waitForElement(driver, toolsBtn, 60);
        $(toolsBtn).click();
        $(btnMarkNLIU).click();
        markAsNLIU();
    }

    /**
     * Function to return total rows from results table for old document search results
     */
    public int getResultRows() {
        commonMethods.waitForElement(driver, tblHeaders, 60);
        return $$(By.xpath(tblRows)).size();
    }

    /**
     * Select the document checkbox for the row number specified in old document search
     *
     * @param row
     */
    public void selectDocCheckBox(int row) {
        verifyAndSwitchFrame();
        By checkBox = By.xpath(tblRows + "[" + row + "]/td[1]/input[@name='selectedIdsInPage']");
        commonMethods.waitForElement(driver, checkBox, 30);
        $(checkBox).click();
    }

    /**
     * Function to click on Edit / Upload new version link in old doc search
     */
    public void clickEditUpload(int row) {
        commonMethods.waitForElementExplicitly(2000);
        $(By.xpath(tblRows + "[" + row + "]")).click();
        commonMethods.waitForElementExplicitly(500);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        commonMethods.waitForElement(driver, editUploadNewVersion);
        commonMethods.clickOnElement((editUploadNewVersion));
    }

    /**
     * Function to verify edit options
     */
    public void verifyEditSavedSearch(String savedSearch) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, By.xpath(sltManageLabels));
        $(By.xpath(sltManageLabels)).click();
        commonMethods.enterDropdownValue(By.xpath(sltManageLabels), savedSearch);
        commonMethods.waitForElement(driver, txtBoxEditSSName);
        Assert.assertFalse($(txtBoxEditSSName).isEnabled());
        $(lnkDelete).click();
        verifyAlert("");
    }

    /**
     * Function to select record in old doc search
     */
    public void selectRecord(int row) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, tblHeaders, 60);
        By xpath = By.xpath(tblRows + "[" + row + "]/td[1]/input");
        commonMethods.waitForElement(driver, xpath, 60);
        commonMethods.getElementInViewAndUp(xpath);
        commonMethods.waitForElementExplicitly(1000);
        $(xpath).click();
        commonMethods.waitForElementExplicitly(500);
        $(By.xpath(tblRows + "[" + row + "]")).doubleClick();
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Function to return the total documents
     *
     * @return
     */
    public int getTotalRecords() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, resultSummary, 60);
        String sizeStr = $(resultSummary).getText();
        return (Integer.parseInt((sizeStr.split(" of ")[1]).split(" ")[0]));
    }
}
