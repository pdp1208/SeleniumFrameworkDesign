package com.oracle.babylon.pages.Setup.ProjectSettings;

import com.github.javafaker.Faker;
import com.oracle.babylon.Utils.helper.Navigator;
import com.oracle.babylon.pages.Setup.ProjectSettingsPage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Selenide.$;

public class DocumentNumberingPage extends ProjectSettingsPage {

    private By documentNumbering = By.xpath("//div[contains(text(),'Document Numbering')]");
    private By createNumSchemeBtn = By.xpath("//button[@id='btnCreateNewDocumentNumberScheme']");
    private By name = By.name("name");
    private By formatElement0 = By.xpath("//select[@id='formatElement0']");
    private By formatElementDrpdwn0 = By.xpath("//select[@id='formatElement0']/option");
    private By formatElementDrpdwn1 = By.xpath("//select[@id='formatElement1']/option");
    private By formatSeparator1 = By.xpath("//select[@id='formatSeparator1']");
    private By formatSeparator2 = By.xpath("//select[@id='formatSeparator2']");
    private By formatElement1 = By.id("formatElement1");
    private By documentType = By.xpath("//span[text()='Available document types']//..//..//select");
    private By addBtn = By.id("documentType-bidi_add");
    private By removeBtn = By.id("documentType-bidi_remove");
    private By filter = By.xpath("//input[@class='uiTextField-input hint']");
    private By successMsg = By.xpath("//div[text()='Scheme saved successfully']");
    private By createNumbering = By.xpath("//div[contains(text(),'Create Numbering Scheme')]");
    private By nameLabel = By.xpath("//td[contains(text(),'Name')]//span[@class='required']");
    private By formatLabel = By.xpath("//td[contains(text(),'Format')]//span[@class='required']");
    private By sequenceNumLabel = By.xpath("//td[contains(text(),'Sequence Number')]//span[@class='required']");
    private By applyThisSchemeLabel = By.xpath("//td[contains(text(),'Apply this scheme to')]");
    private By availableDocTypes = By.xpath("//div[@class='uiBidi-left']//span[contains(text(),'Available document types')]");
    private By selectedDocTypes = By.xpath("//div[@class='uiBidi-right']//div[contains(text(),'Selected document types')]");
    private By sequenceNumber = By.xpath("//select[@name='sequenceNumberLength']");
    private By startAt = By.xpath("//input[@id='sequenceNumberStartAt']");
    private By searchDocTypeInput = By.xpath("//div[@class='uiBidi-left']//input");
    private By addItem = By.xpath("//button[@title='Add item to list']");
    private String nameValue = null;
    private By documentTypesHeader = By.xpath("//th[contains(text(),'Document Types')]");
    private By nameheader = By.xpath("//th[contains(text(),'Name')]");
    private By docNumDataTable = By.xpath("//table[@id='tblSavedSchemes']//td");
    String docNumberingPath = configFileReader.getDocNumberingDataPath();
    Navigator navigator = new Navigator();

    /**
     * Method to navigate to Project Settings and then navigating to Document Numbering
     */

    public void navigateAndVerifyPage() {
        getMenuSubmenu("Setup", "Project Settings");
        navigateToDocNumbering();
    }


    /**
     * Function to navigate to Doc Numbering
     */
    public void navigateToDocNumbering() {
        verifyAndSwitchFrame();
        commonMethods.clickLinkToChange(driver, projectSettingsLabel, documentSettings);
        commonMethods.clickLinkToChange(driver, projectSettingsLabel, documentNumbering);
    }

    /**
     * Method to click Document Numbering Scheme Button
     */

    public void clickDocNumSchemeBtn() {
        $(createNumSchemeBtn).click();
    }

    public void addSampleDocNumScheme(Map<String, String> map) {
        Faker faker = new Faker();
        nameValue = faker.app().name();
        $(name).sendKeys(nameValue);

        //Selecting format1, data passed from feature file

        Select element1Select = new Select($(formatElement0));
        $(formatElement0).click();
        element1Select.selectByVisibleText(map.get("element1"));

        //Selecting the first separator
        Select separator1Select = new Select($(formatSeparator1));
        $(formatSeparator1).click();
        separator1Select.selectByVisibleText(map.get("separator1"));

        //Selecting format 2
        Select format2Select = new Select($(formatElement1));
        $(formatElement1).click();
        format2Select.selectByVisibleText(map.get("element2"));

        $(filter).clear();
        $(filter).sendKeys(map.get("document_type"));
        Select addDocumentType = new Select($(documentType));
        addDocumentType.selectByVisibleText(map.get("document_type"));
        $(addBtn).click();
        $(pageSaveBtn).click();
    }

    /**
     * Method to verify Document Numbering Scheme is displayed or not
     * @return
     */

    public Boolean verifyDocNumScheme() {
        By element = By.xpath("//a[contains(text(),'" + nameValue + "')]");
        return $(element).isDisplayed();
    }

    /**
     * Method to validate the header
     * @return
     */

    public Boolean validateHeader() {
        commonMethods.waitForElement(driver, successMsg);
        return $(successMsg).isDisplayed();
    }

    /**
     * Function to click on Document Numbering and verify the page
     *
     * @return
     */

    public boolean verifyDocumentNumbering() {
        switchProjectSettingsFrame();
        commonMethods.waitForElement(driver, createNumbering, 45);
        return $(createNumbering).isDisplayed();
    }

    /**
     * Function to verify Document Numbering is enabled or disabled
     * @return
     */
    public boolean docNumberingEnabled() {
        switchProjectSettingsFrame();
        return $(createNumbering).isSelected();
    }

    /**
     * Function to verify Document Number Message
     * @return
     */
    public boolean verifyDocNumMessage(String msg) {
        return $(By.xpath("//div[contains(text(),'" + msg + "')]")).isDisplayed();
    }

    /**
     * Function to verify Document Number Scheme Fields
     */

    public void verifyDocNumSchemeFields() {
        Assert.assertTrue($(nameLabel).isDisplayed());
        Assert.assertTrue($(formatLabel).isDisplayed());
        Assert.assertTrue($(sequenceNumLabel).isDisplayed());
        Assert.assertTrue($(applyThisSchemeLabel).isDisplayed());
        Assert.assertTrue($(availableDocTypes).isDisplayed());
        Assert.assertTrue($(selectedDocTypes).isDisplayed());
    }
    /**
     * Function to verify Default Document Number Scheme Fields
     */
    public void verifyDefaultDocNumSchemeFields() {
        Assert.assertFalse($(docNumDataTable).isDisplayed());
        Assert.assertTrue($(nameheader).isDisplayed());
        Assert.assertTrue($(documentTypesHeader).isDisplayed());
    }
    /**
     * Function to create Document Numbering Scheme
     * @param docNumName
     * @param docData
     */
    public void createDocNumScheme(String docNumName, List<Map<String, String>> docData) {
        for (Map<String, String> data : docData) {
            String docNumSchemeName = "DocNum" + commonMethods.getRandomString(12) + faker.number().digits(3);
            $(name).sendKeys(docNumSchemeName);
            $(formatElement0).selectOptionContainingText(data.get("Element0"));
            $(formatSeparator1).selectOptionContainingText(data.get("Separator"));
            $(formatElement1).selectOptionContainingText(data.get("Element1"));
            $(sequenceNumber).selectOptionContainingText(data.get("SequenceNum"));
            $(startAt).clear();
            $(startAt).sendKeys(data.get("Start At"));
            addDocTypes(data.get("DocType"));
            commonMethods.writeToJson("doc_name", docNumName, docNumSchemeName, docNumberingPath);
        }
    }
    /**
     * Function to verify Document Numbering Scheme
     * @param fieldValue
     * @param value-boolean
     */
    public void verifyFieldValue(String fieldValue,boolean value) {
        if(value) {

            Assert.assertTrue(getDropdownValues(driver, formatElementDrpdwn0).contains(fieldValue));
            Assert.assertTrue(getDropdownValues(driver, formatElementDrpdwn1).contains(fieldValue));
        }else {
            Assert.assertFalse(getDropdownValues(driver, formatElementDrpdwn0).contains(fieldValue));
            Assert.assertFalse(getDropdownValues(driver, formatElementDrpdwn1).contains(fieldValue));
        }
    }
    public List<String> getDropdownValues(WebDriver driver, By by) {
        commonMethods.waitForElementClickable(driver, by, 30);
        navigator.getElementInView(by);
        return commonMethods.getValues(by);
    }
    /**
     * Function to edit Document Numbering Scheme
     * @param docData
     */
    public void editDocNumScheme(List<Map<String, String>> docData) {
        for (Map<String, String> data : docData) {
            commonMethods.waitForElement(driver, formatSeparator1);
            $(formatSeparator1).selectOptionContainingText(data.get("Separator"));
            $(formatSeparator2).selectOptionContainingText(data.get("Separator2"));
        }
    }
    /**
     * Function to create Empty Document Numbering Scheme
     */
    public void createEmptyDocNumScheme() {
        $(name).sendKeys("");
    }

    /**
     * Function to add Document Types
     * @param docType
     */

    public void addDocTypes(String docType) {
        for(String type : docType.split(",")) {
            commonMethods.enterTextValue(searchDocTypeInput, type);
            $(By.xpath("//option[contains(text(),'" + type.trim() + "')]")).click();
            $(addItem).click();
        }
    }

    /**
     * Function to click on Document Number Save Button
     */

    public void clickDocNumSaveBtn() {
        $(saveBtn).click();
    }

    /**
     * Function to click on Document Numbering Scheme
     * @param docNumName
     */

    public void clickDocNumScheme(String docNumName) {
        $(By.xpath("//a[contains(text(),'" + commonMethods.returnFromJson(docNumName, "doc_name", docNumberingPath) + "')]")).click();
    }

    /**
     * Function to verify Document Numbering Scheme
     * @param docNumName
     * @return
     */

    public boolean verifyDocNumScheme(String docNumName) {
        By by = By.xpath("//a[contains(text(),'" + commonMethods.returnFromJson(docNumName, "doc_name", docNumberingPath) + "')]");
        commonMethods.waitForElement(driver, by);
        return $(by).isDisplayed();
    }

    /**
     * Function to verify Document Type
     * @param docNumName
     * @param docType
     */

    public boolean verifyDocType(String docNumName, String docType) {
        By by = By.xpath("//a[contains(text(),'" + commonMethods.returnFromJson(docNumName, "doc_name", docNumberingPath) + "')]//..//following-sibling::td");
        commonMethods.waitForElement(driver, by);
        return $(by).getText().equals(docType);
    }

    /**
     * Function to verify Message
     * @param Message
     * @return
     */

    public boolean verifyMessage(String Message) {
        return $(By.xpath("//div[contains(text(),'" + Message + "')]")).isDisplayed();
    }

    /**
     * Function to verify Document Number
     * @param docNo
     * @param scheme
     * @return
     */

    public boolean verifyDocNumber(String docNo, String scheme) {
        return docNo.contains(scheme);
    }

    /**
     * Function to verify Document Number Sequence
     * @param docNum
     */

    public void verifyDocSequence(List<String> docNum) {
        List<String> actDocNo = new ArrayList<>();
        String num[] = docNum.get(0).split("(?<=-)");
        String num2[] = num[1].split("[1-9]");
        int num1 = Integer.parseInt(num[1]);
        for (int i = 1; i <= docNum.size(); i++) {
            String expectedSeq = num[0] + num2[0] + num1;
            commonMethods.waitForElementExplicitly(1000);
            num1 = num1 + 1;
            actDocNo.add(expectedSeq);
        }
        commonMethods.waitForElementExplicitly(2000);
        Assert.assertTrue(docNum.equals(actDocNo));

    }

    /**
     * Function to verify Document Numbering Scheme details
     * @param docNumName
     * @return
     */
    public boolean verifyDocNumSchemeDetails(String docNumName,String docTypeName) {
        return $(By.xpath("//table[@id='tblSavedSchemes']//tbody//tr//td/a[text()='"+docNumName+"']")).isDisplayed() && $(By.xpath("//table[@id='tblSavedSchemes']//tbody//tr//td[text()='"+docTypeName+"']")).isDisplayed();
    }
}



