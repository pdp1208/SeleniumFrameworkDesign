package com.oracle.babylon.pages.Setup.MyOrganization;

import com.codeborne.selenide.Condition;
import com.github.javafaker.Faker;
import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;

import static com.codeborne.selenide.Selenide.*;

//Why check in a file that is not part of your requirement
public class UserAccountListPage extends Navigator {

    private By txtboxGivenName = By.xpath("//input[@name='SRCH_FIRST_NAME']");
    private By txtboxFamilyName = By.xpath("//input[@name='SRCH_LAST_NAME']");
    private By txtboxLoginName = By.xpath("//input[@name='SRCH_USER_NAME']");
    private By chkBoxShowDisable = By.xpath("//input[@id='SRCH_SHOW_DISABLED']");
    private By btnSearch = By.xpath("//div[contains(text(),'Search')]");
    private By btnShowInGlobal = By.xpath("//div[contains(text(),'Show in Global')]");
    private By btnHideInGlobal = By.xpath("//div[contains(text(),'Hide in Global')]");
    private By btnCreateNewUser = By.xpath("//div[contains(text(),'Create a New User')]");
    private String tblResults = "//table[@id='resultTable']/tbody/tr";
    private By chkBoxFirstResult = By.xpath("//table[@id='resultTable']/tbody/tr[1]/td[1]/input[@name='selectedIdsInPage']");

    private By pageTitle = By.xpath("//h1[contains(text(),'User Accounts List')]");
    private By givenName = By.xpath("//label[contains(text(),'Given Name')]");
    private By givenNameTxtbox = By.xpath("//input[@name='SRCH_FIRST_NAME']");
    private By loginName = By.xpath("//label[contains(text(),'Login Name')]");
    private By loginNameTxtbox = By.xpath("//input[@name='SRCH_USER_NAME']");
    private By familyName = By.xpath("//label[contains(text(),'Family Name')]");
    private By familyNameTxtbox = By.xpath("//input[@name='SRCH_LAST_NAME']");
    private By disabledAccChkbox = By.xpath("//input[@id='SRCH_SHOW_DISABLED']");
    private By searchBtn = By.xpath("//div[contains(text(),'Search')]");
    private By usernameLink = By.xpath("//a[@title='Edit user information']");
    private By fullUserIcon = By.xpath("//img[@title='User']");
    private By guestUserIcon = By.xpath("//img[@title='Guest']");
    private By disableAccount = By.xpath("//input[@name='USER_DISABLED']");
    private By saveBtn = By.xpath("//div[contains(text(),'Save')]");
    private By noResults = By.xpath("//td[contains(text(),'No Search Results!')]");
    private By passwordBtn = By.xpath("//div[contains(text(),'Password')]");
    private By currentPwd = By.xpath("//input[@id='PASSWORD']");
    private By newPwd = By.xpath("//input[@id='NEW_PASSWORD']");
    private By confirmPwd = By.xpath("//input[@id='CONFIRM_PASSWORD']");

    String userDataPath = configFileReader.getUserDataPath();

    /**
     * Method to navigate to User Account List
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Setup", "User Accounts List");
        commonMethods.waitForElementExplicitly(5000);
        switchTo().frame("frameMain");
        verifyPageTitle("User Accounts List");
    }

    /**
     * Method to search for a user with Given and Family Name
     */
    public void searchUserName(String user) {
        verifyAndSwitchFrame();
        $(txtboxGivenName).clear();
        $(txtboxGivenName).sendKeys(user.split(" ")[0]);
        $(txtboxFamilyName).clear();
        $(txtboxFamilyName).sendKeys(user.split(" ")[1]);
        clickSearchUser();
    }

    /**
     * Method to click on search button
     */
    public void clickSearchUser() {
        $(btnSearch).click();
    }

    /**
     * Method to select first result
     */
    public void selectFirstResult() {
//        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(1000);
        commonMethods.waitForElement(driver, chkBoxFirstResult, 10);
        $(chkBoxFirstResult).click();
    }

    /**
     * Method to verify results table is displayed or not
     */
    public boolean verifyResults(String user) {
        verifyAndSwitchFrame();
        return $(By.xpath("//a[text()='" + commonMethods.getUserData(user, "name").replace(" ", "\\u00a0") + "']")).isDisplayed();
    }

    /**
     * Method to click on username
     */
    public void clickOnUserName(String user) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, By.xpath(tblResults), 30);
        List<WebElement> results = new ArrayList<>($$(By.xpath(tblResults)));
        for (int i = 1; i <= results.size(); i++)
            if ($(By.xpath(tblResults + "[" + i + "]/td[3]/a")).getText().contains(commonMethods.getUserData(user, "name"))) {
                $(By.xpath(tblResults + "[" + i + "]/td[3]/a")).click();
                break;
            }
    }

    /**
     * Method to select show disabled button
     */
    public void selectShowDisabled(boolean option) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, chkBoxShowDisable, 10);
        $(chkBoxShowDisable).setSelected(option);
    }

    /**
     * Method to click the show in global directory button
     */
    public void showInGlobalDirectory(){
        $(btnShowInGlobal).click();
    }

    /**
     * Method to click on hide in global directory button
     */
    public void hideInGlobalDirectory(){
        $(btnHideInGlobal).click();
    }

    /**
     * Function to verify the elements present in User Accounts List page
     */

    public void verifyElements() {
        Assert.assertTrue($(givenName).isDisplayed());
        Assert.assertTrue($(givenNameTxtbox).isDisplayed());
        Assert.assertTrue($(loginName).isDisplayed());
        Assert.assertTrue($(loginNameTxtbox).isDisplayed());
        Assert.assertTrue($(familyName).isDisplayed());
        Assert.assertTrue($(familyNameTxtbox).isDisplayed());
        Assert.assertTrue($(disabledAccChkbox).isDisplayed());
    }

    /**
     * Function to verify the buttons present in User Accounts List page
     *
     * @param names
     */
    public void verifyButtons(List<String> names) {
        for (String name : names) {
            Assert.assertTrue($(By.xpath("//div[contains(text(),'" + name + "')]")).isDisplayed());
        }
    }

    /**
     * Function to verify the data headers present in User Accounts List page
     *
     * @param names
     */

    public void verifyHeaders(List<String> names) {
        for (String name : names) {
            Assert.assertTrue($(By.xpath("//th[contains(text(),'" + name + "')]")).isDisplayed());
        }
    }

    /**
     * Function to search the guest user present in User Accounts List page
     *
     * @param user
     */

    public void searchGuestUser(String user) {
        $(givenNameTxtbox).clear();
        $(loginNameTxtbox).clear();
        String guestName = commonMethods.returnFromJson(user, "full_name", userDataPath);
        String[] name = guestName.split(" ");
        $(givenNameTxtbox).sendKeys(name[0]);
        $(searchBtn).click();
    }

    /**
     * Function to verify the full user Icon present in User Accounts List page
     * @return
     */

    public boolean verifyFullUserIcon() {
        return $(fullUserIcon).isDisplayed();
    }

    /**
     * Function to verify the guest user Icon present in User Accounts List page
     * @return
     */

    public boolean verifyGuestUserIcon() {
        return $(guestUserIcon).isDisplayed();
    }

    /**
     * Function to click on the user after search
     */

    public void clickUser() {
        $(usernameLink).click();
    }

    /**
     * Function to click on Disable Account checkbox
     */

    public void disableAccount() {
        $(disableAccount).setSelected(true);
        $(saveBtn).click();
    }

    /**
     * Function to verify the message
     * @return
     */

    public boolean verifyMsg(String msg) {
        return $(By.xpath("//div[@id='main']//h1[contains(text(),'" + msg + "')]")).isDisplayed();
    }

    /**
     * Function to click on search button
     */

    public void clickSearchBtn() {
        $(searchBtn).click();
    }

    /**
     * Function to verify the user present in User Accounts List page
     * @param user
     * @return
     */

    public boolean verifyUser(String user) {
        return (commonMethods.returnFromJson(user, "full_name", userDataPath)).contains($(usernameLink).getText());

    }

    /**
     * Function to verify that No results displayed
     * @return
     */

    public boolean verifyNoResults() {
        return $(noResults).isDisplayed();
    }


    /**
     * Function to search user present in User Accounts List page
     * @param user
     */

    public void searchUser(String user) {
        $(loginNameTxtbox).clear();
        $(givenNameTxtbox).clear();
        $(loginNameTxtbox).sendKeys(commonMethods.getUserData(user, "username"));
        $(searchBtn).click();
    }

    /**
     * Function to click on password button
     */

    public void clickPassword() {
        $(passwordBtn).click();
    }

    /**
     * Function to change the password for the user
     * @param user1
     * @param user2
     */

    public void changePassword(String user1, String user2) {
        $(currentPwd).sendKeys(commonMethods.returnFromJson(user1, "password", userDataPath));
        Faker faker = new Faker();
        String password = faker.internet().password(9, 12, true);
        String newPassword = password + "@08";
        $(newPwd).sendKeys(newPassword);
        $(confirmPwd).sendKeys(newPassword);
        commonMethods.writeToJson("password", user2, newPassword, userDataPath);
    }

}