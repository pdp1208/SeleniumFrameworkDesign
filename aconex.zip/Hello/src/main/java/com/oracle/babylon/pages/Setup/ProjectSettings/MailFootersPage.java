package com.oracle.babylon.pages.Setup.ProjectSettings;

import com.google.common.collect.Ordering;
import com.oracle.babylon.pages.Setup.ProjectSettingsPage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.util.LinkedList;
import java.util.List;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class MailFootersPage extends ProjectSettingsPage {

    private By mailMenu = By.xpath("//span[contains(text(),'Mail')]");
    private By mailFooters = By.xpath("//div[contains(text(),'Mail Footers')]");
    private By mailFooter = By.xpath("//div[contains(text(),'Mail Footers')]");
    private By mailFooterHeader = By.xpath("//table[@class='formTable']//td[contains(text(),'Mail Footers')]");
    private By mailFooterProjectName = By.xpath("//table[@class='formTable']//tr[2]//td[2]");
    private By mailFooterProjectAddress = By.xpath("//table[@class='formTable']//tr[3]//td[2]");
    private By saveBtn = By.xpath("//button[@id='btnSave']");
    private By transmittalAttachmentViews = By.xpath("//td[contains(text(),'Transmittal Attachment Views')]");
    private By customViewEditButton = By.xpath("//button[@id='btnEdit']");
    private By createCustomViewBtn = By.xpath("//button[@id='btnCreateCustomView']");
    private By nameTableColumn = By.xpath("//table[@class='grid-header-table dataTable']//div[contains(text(),'Name')]");
    private By removeTableColumn = By.xpath("//table[@class='grid-header-table dataTable']//div[contains(text(),'Remove')]");
    private By customViewSaveBtn = By.xpath("//button[@title='Save']");
    private By customViewCancelBtn = By.xpath("//button[@title='Cancel']");
    private By customViewErrorMessage = By.xpath("//ul[@class='messagePanel']//div[contains(text(),'A mandatory field is empty. Please complete the highlighted field before submitting.')]");
    private By revisionSelectBoxOptionRight = By.xpath("//div[@class='uiBidi-right']//select//option[@value='revision']");
    private By revisionSelectBoxOptionLeft = By.xpath("//div[@class='uiBidi-left']//select//option[@value='revision']");
    private By removeItemsFromListBtn = By.xpath("//button[@title='Remove item from list']");
    private By addItemToListBtn = By.xpath("//button[@title='Add item to list']");
    private By name = By.xpath("//input[@name='name']");
    private By createCustomViewMessage = By.xpath("//li[@class='message success']//div[contains(text(),'Your changes have been saved')]");
    private By customView = By.xpath("//div[@id='transmittalAttachmentViews-main']//table[@class='grid-body-table dataTable']//td//a");
    private By customViewDelete = By.xpath("//div[@id='transmittalAttachmentViews-main']//table[@class='grid-body-table dataTable']//div[@class='auiIcon trash']");
    private By documentAutoNumber = By.xpath("//input[@name='DOC_AUTO_NUMBER_ORG_CODE']");
    private By documentAutoNumberErrorMsg = By.xpath("//div[@id='messagePanel']//ul//li[@class='message warning']/div//div");
    private By mailTypeOrgPrefix = By.id("corrPrefix");
    private String selectedFields = "//div[@id='createTransmittalAttachmentViewPanel-bidi']//div[@class='uiBidi-right']//option";
    private String availableFields = "//div[@id='createTransmittalAttachmentViewPanel-bidi']//div[@class='uiBidi-left']//option";
    private By countErrorMessage = By.xpath("//li[@class='message check']//div[text()='You can only select up to 10 fields']");
    private By customViewNames = By.xpath("//div[@id='transmittalAttachmentViewsGrid']//table//tr/td//a");
    private String btnTrash = "//div[@id='transmittalAttachmentViewsGrid']//table//tr/td//div[@class='auiIcon trash']";
    private By txtBoxAutoNumberBy = By.xpath("//input[@id='corrPrefix']");
    private By documentNoField = By.xpath("//div[@class='uiBidi-right']//select//option[@value='docno']");
    private By txtBoxFooterMessages = By.xpath("//form[@name='CORRESPONDENCE_SETTINGS']//table//tr/td/textarea");
    private By lblUnSavedChanges = By.xpath("//div/span[text()='Unsaved changes']");
    private By txtUnSavedMessage = By.xpath("//div[@class = 'message info']//div[text()='You have unsaved changes on this screen']");
    private By btnSaveMyChanges = By.xpath("//button[@id='unsavedChangesPanel-save']");
    private By btnIgnoreMyChanges = By.xpath("//button[@id='unsavedChangesPanel-ignore']");
    private By firstMailFooter = By.xpath("(//form[@name='CORRESPONDENCE_SETTINGS']//table//tr/td/textarea)[1]");
    protected By autoNumScheme = By.xpath("//select[@name='PROJ_ORG_AUTONUMBER_FIELD']");
    private By autoNumSchemeSection = By.xpath("//td[contains(text(),'Auto-number scheme')]");
    private By mailFootersSection = By.xpath("//td[contains(text(),'Mail Footers')]");
    private By customViewSelectedField = By.xpath("//div[@class='uiBidi-right']//select/option");

    public static String orgPrefix=null;
    public static String mailFootersText=null;
    public static String mailFootersText2=null;
    public static List<String> customViewSelectedFieldList = new LinkedList<>();
    Actions actions = new Actions(driver);

    /**
     * method to navigate to Mail Footers page
     */
    public void navigateToMailFooters() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, mailMenu, 8);
        $(mailMenu).click();
        commonMethods.waitForElement(driver, mailFooters, 8);
        $(mailFooters).click();
        verifyPageTitle("Project Settings");
    }

    /**
     * Function to add Mail Footer
     *
     * @param mailType
     * @param footer
     */
    public void addMailFooter(String mailType, String footer) {
        switchProjectSettingsFrame();
        By mailTypeFooter = By.xpath("//td[text()='" + mailType + "']//..//td//textarea");
        commonMethods.waitForElement(driver, mailTypeFooter, 25);
        getElementInView(mailTypeFooter);
        $(mailTypeFooter).setValue(footer);
        $(pageSaveBtn).click();
    }

    /**
     * Function to click on Mail Footer tab and verify
     *
     * @return
     */

    public boolean verifyMailFooters() {
        switchToOriginal();
        verifyAndSwitchFrame();
        $(mailFooter).click();
        switchProjectSettingsFrame();
        commonMethods.waitForElement(driver, mailFooterHeader, 45);
        return $(mailFooterHeader).isDisplayed();
    }

    /**
     * Function to click on Mail Footer tab and verify
     **/
    public void verifyLinkPresent() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, mailMenu, 8);
        $(mailMenu).click();
        commonMethods.waitForElement(driver, mailFooters, 4);
        Assert.assertTrue($(mailFooters).isDisplayed());
    }

    /**
     * method to get the Project Name and Address
     **/
    public String[] getProjectDetails() {
        String[] projectDetails = new String[2];
        projectDetails[0] = $(mailFooterProjectName).getText();
        projectDetails[1] = $(mailFooterProjectAddress).getText();
        return projectDetails;
    }

    /**
     * Function to click on Mail Footer tab and verify
     */
    public void clickLink() {
        switchToOriginal();
        verifyAndSwitchFrame();
        $(mailMenu).click();
        commonMethods.waitForElement(driver, mailFooters);
        $(mailFooter).click();
        switchProjectSettingsFrame();
        commonMethods.waitForElement(driver, mailFooterHeader);
    }

    /**
     * Function to click on Mail Footer tab and verify
     */
    public void verifySaveButton() {
        Assert.assertTrue($(saveBtn).isDisplayed());
    }

    /**
     * Function to verify the Transmittal Attachment View text is displayed
     */
    public void verifyTransmittalAttachmentView() {
        Assert.assertTrue($(transmittalAttachmentViews).isDisplayed());
    }

    /**
     * Function to verify the Custom view Edit button present
     */
    public void verifyCustomViewEditButton() {
        Assert.assertTrue($(customViewEditButton).isDisplayed());
    }

    /**
     * Function to verify the Custom View Edit button present
     */
    public void clickCustomViewEditButton() {
        verifyCustomViewEditButton();
        $(customViewEditButton).click();
    }

    /**
     * Function to verify the Custom View page elements loaded
     */
    public void verifyCustomViewPage() {
        Assert.assertTrue($(createCustomViewBtn).isDisplayed());
        Assert.assertTrue($(backBtn).isDisplayed());
        Assert.assertEquals($(nameTableColumn).getText(), "Name");
        Assert.assertEquals($(removeTableColumn).getText(), "Remove");
    }

    /**
     * Function to click on Create Custom View button
     */
    public void clickCreateCustomerView() {
        commonMethods.waitForElement(driver, createCustomViewBtn, 60);
        $(createCustomViewBtn).click();
    }

    /**
     * Function to click on Save Custom View button
     */
    public void clickSaveButton() {
        $(customViewSaveBtn).click();
    }

    /**
     * Function to verify Custom View Error message displayed
     */
    public void verifyCustomViewErrorMessage() {
        Assert.assertTrue($(customViewErrorMessage).isDisplayed());
    }

    /**
     * Function to verify toggle feature in the  Custom View Select box
     */
    public void verifyToggleCustomViewSelectBox() {
        commonMethods.waitForElement(driver, removeItemsFromListBtn);
        if ($(revisionSelectBoxOptionRight).isDisplayed()) {
            $(revisionSelectBoxOptionRight).click();
            $(removeItemsFromListBtn).click();
            Assert.assertTrue($(revisionSelectBoxOptionLeft).isDisplayed());
            $(revisionSelectBoxOptionLeft).click();
            $(addItemToListBtn).click();
            Assert.assertTrue($(revisionSelectBoxOptionRight).isDisplayed());
        } else {
            $(revisionSelectBoxOptionLeft).click();
            $(addItemToListBtn).click();
            Assert.assertTrue($(revisionSelectBoxOptionRight).isDisplayed());
            $(revisionSelectBoxOptionRight).click();
            $(removeItemsFromListBtn).click();
            Assert.assertTrue($(revisionSelectBoxOptionLeft).isDisplayed());
        }
    }

    /**
     * Function to verify the page is navigated back successfully
     */
    public void verifyPageNavigatedBack() {
        commonMethods.waitForElement(driver, transmittalAttachmentViews, 30);
        if ($(transmittalAttachmentViews).isDisplayed())
            Assert.assertTrue("The user navigated back to the previous page", true);
        else
            Assert.fail("Error in navigating back to the previous page");
    }

    /**
     * Function to create Custom View
     *
     * @param customViewName is the name of the Custom View to be created
     */
    public void createCustomView(String customViewName) {
        $(name).sendKeys(customViewName);
        clickSaveButton();
    }

    /**
     * Function to enter Custom View name
     *
     * @param customViewName is the name of the Custom View to be entered
     */
    public void enterCustomView(String customViewName) {
        $(name).sendKeys(customViewName);
    }

    /**
     * Function to cancel Custom View creation
     */
    public void clickCancelCustomView() {
        $(customViewCancelBtn).click();
    }

    /**
     * Function to validate Custom View created
     *
     * @param customViewName is the name of the Custom View to be validated
     */
    public boolean verifyCustomViewCreation(String customViewName) {
        return $(By.xpath("//div[@id='transmittalAttachmentViewsGrid']//table//tr/td//a[text()='" + customViewName + "']")).isDisplayed();
    }

    /**
     * Function to delete the existing Custom View
     */
    public void deleteCustomViews() {
        if (!$(customView).getText().isEmpty()) {
            int count = $$(customViewDelete).size();
            for (int i = 1; i <= count; i++) {
                $(By.xpath("(" + btnTrash + ")[1]")).click();
            }
        } else {
            Assert.fail("No Custom View are available");
        }
    }

    /**
     * Function to verify Custom view deleted successfully
     */
    public void verifyCustomViewDeleted() {
        if (!$(customView).isDisplayed())
            Assert.assertTrue("Successfully deleted the Custom Views", true);
        else
            Assert.fail("Error in deleting the Custom View");
    }

    /**
     * Function to validate Custom Views are not exist
     */
    public void verifyCustomViewNotPresent() {
        if (!$(customView).exists())
            Assert.assertTrue("Cancel Custom View button is working as expected", true);
        else {
            Assert.fail("Cancel Custom View button is not working as expected");
        }
    }

    /**
     * Function to click on Save button in Mail Footer
     */
    public void clickSaveButtonMailFooter() {
        $(saveBtn).click();
    }

    /**
     * Function to clear Document Auto Organization code
     */
    public void clearAutoOrganizationCode() {
        $(documentAutoNumber).clear();
    }

    /**
     * Function to verify Document Auto Organization code error message
     */
    public void verifyAutoOrganizationCodeErrorMsg(String errorMessage) {
        if ($(documentAutoNumberErrorMsg).getText().equals(errorMessage))
            Assert.assertTrue("Error message is displayed", true);
        else
            Assert.fail("Error message is not displayed");
    }

    /**
     * Function to get the mail type with organization prefix value from source project
     */
    public String getMailTypeOrgPrefix() {
        return $(mailTypeOrgPrefix).getAttribute("value");
    }

    /**
     * Function to compare the mail type with organization prefix value from source project to the destination project
     */
    public String compareMailTypeOrgPrefix() {
        return $(mailTypeOrgPrefix).getAttribute("value");
    }

    /**
     * Function to check the mail footer present or not
     */
    public boolean compareMailFooter(String mailType) {
        switchProjectSettingsFrame();
        By mailTypeFooter = By.xpath("//td[text()='" + mailType + "']//..//td//textarea");
        commonMethods.waitForElement(driver, mailTypeFooter, 25);
        getElementInView(mailTypeFooter);
        return $(mailTypeFooter).getText().isEmpty();
    }

    /**
     * Function to set the Document Auto Organization code
     */
    public void setDocAutoOrgCode(String docAutoCode) {
        commonMethods.waitForElementExplicitly(2000);
        $(documentAutoNumber).sendKeys(docAutoCode);
    }

    /**
     * Function to get the Document Auto Organization code
     */
    public String verifyDocAutoNbrOrgCode() {
        commonMethods.waitForElementExplicitly(2000);
        return $(documentAutoNumber).getAttribute("value");
    }

    /**
     * Function to remove all selected fields
     */
    public void removeAllSelectedFields() {
        int count = $$(By.xpath(selectedFields)).size();
        for (int i = 2; i <= count; i++) {
            $(By.xpath("(" + selectedFields + ")[2]")).click();
            $(removeItemsFromListBtn).click();
        }
    }

    /**
     * Function to add available fields based on count
     */
    public void selectAvailableFields(int count) {
        for (int i = 1; i <= count; i++) {
            actions.moveToElement($(By.xpath("(" + availableFields + ")[" + i + "]"))).keyDown(Keys.SHIFT).click().build().perform();
        }
        $(addItemToListBtn).click();
    }

    /**
     * Function to add available fields based on count
     */
    public void addAvailableFields(int count) {
        for (int i = 1; i <= count; i++) {
            $(By.xpath("(" + availableFields + ")[" + i + "]")).click();
            $(addItemToListBtn).click();
            commonMethods.waitForElementExplicitly(1000);
        }
    }

    /**
     * Function to verify exceeded count error
     */
    public boolean verifyCountError() {
        return $(countErrorMessage).isDisplayed();
    }

    /**
     * Function to return selected fields count
     */
    public int verifySelectedFields() {
        return $$(By.xpath(selectedFields)).size();
    }

    /**
     * Function to verify custom views arranged order
     *
     * @return
     */
    public boolean verifyCustomViewOrder() {
        List<String> customViews = $$(customViewNames).texts();
        return Ordering.natural().isOrdered(customViews);
    }

    /**
     * Function to clear Autonumber by field
     */
    public void clearAutonumberCode() {
        $(txtBoxAutoNumberBy).clear();
    }

    /**
     * Function to select and remove document no from selected fields
     */
    public void selectAndRemoveDocNo() {
        $(documentNoField).click();
        $(removeItemsFromListBtn).click();
    }

    /**
     * Function to get all selected field values
     */
    public List<String> getSelectedFields() {
        return commonMethods.getValues(By.xpath(selectedFields));
    }

    /**
     * Function to enter mail footer text and verify alert message
     */
    public void enterMailFooterAndVerify(String message) {
        commonMethods.waitForElement(driver, customViewEditButton, 60);
        int count = $$(txtBoxFooterMessages).size();
        for (int i = 1; i <= count; i++) {
            verifyAndSwitchFrame();
            switchProjectSettingsFrame();
            commonMethods.enterTextValue(By.xpath("(//form[@name='CORRESPONDENCE_SETTINGS']//table//tr/td/textarea)[" + i + "]"), commonMethods.getRandomString(701));
            Assert.assertTrue(verifyAlert(message));
            commonMethods.waitForElementExplicitly(1000);
        }
    }

    /**
     * Function to verify unsaved changes popup window
     */
    public void verifyUnsavedChanges() {
        Assert.assertTrue($(lblUnSavedChanges).isDisplayed());
        Assert.assertTrue($(txtUnSavedMessage).isDisplayed());
        Assert.assertTrue($(btnSaveMyChanges).isDisplayed());
        Assert.assertTrue($(btnIgnoreMyChanges).isDisplayed());
    }

    /**
     * Function to click on Ignore changes button in unsaved changes popup window
     */
    public void clickIgnoreChanges() {
        commonMethods.waitForElement(driver, btnIgnoreMyChanges);
        $(btnIgnoreMyChanges).click();
    }

    /**
     * Function to click on Save changes button in unsaved changes popup window
     */
    public void clickSaveChanges() {
        commonMethods.waitForElement(driver, btnSaveMyChanges);
        $(btnSaveMyChanges).click();
    }

    /**
     * Function to verify first mailtype footer message value
     */
    public boolean verifyFirstFooterMessage() {
        return $(firstMailFooter).getText().isEmpty();
    }

    /**
     * Function to verify mailtype footer message value is blank or not
     */
    public boolean verifyFooterMessage(String mailType) {
        return $(By.xpath("//form[@name='CORRESPONDENCE_SETTINGS']//table//tr//td[text()='" + mailType + "']/../td/textarea")).getText().isEmpty();
    }

    /**
     * Function to enter mail footer random message
     */
    public void enterMailFooter(String mailType) {
        mailFootersText=commonMethods.getRandomString(30);
        commonMethods.enterTextValue(By.xpath("//form[@name='CORRESPONDENCE_SETTINGS']//table//tr//td[text()='" + mailType + "']/../td/textarea"),mailFootersText );
    }

    /**
     * Function to get AutonumberBy org code
     */
    public String getAutoNumberCode() {
        return $(txtBoxAutoNumberBy).getAttribute("value");
    }

    /**
     * Function to get Document auto number org code
     */
    public String getDocAutoNumberOrgCode() {
        return $(documentAutoNumber).getAttribute("value");
    }

    /**
     * Function to fill Document auto number org code
     */
    public void enterDocAutNumOrgCode(String code) {
        commonMethods.enterTextValue(documentAutoNumber, code);
    }

    /**
     * Function to fill auto number by code
     */
    public void enterAutoNumberCode(String code) {
        commonMethods.enterTextValue(txtBoxAutoNumberBy, code);
    }

    /**
     * method to click on Mail Footers option
     */
    public void clickOnMailFooters() {
        commonMethods.waitForElement(driver, mailFooters);
        $(mailFooters).click();
        verifyPageTitle("Project Settings");
    }
    /**
     * Function to validate Custom View created
     *
     * @param customViewName is the name of the Custom View to be validated
     */
    public void clickCreatedCustomView(String customViewName) {
        $(By.xpath("//div[@id='transmittalAttachmentViewsGrid']//table//tr/td//a[text()='" + customViewName + "']")).click();
    }
    /**
     * Function to get available Auto Num Schemes
     */
    public List<String> getAvailableAutoNumSchemes() {
        return commonMethods.returnAllOptionsInDropDown(driver, autoNumScheme);
    }
    /**
     * Method to select auto number scheme Value
     *
     */
    public void selectAutoNumSchemeValue(String scheme) {
        commonMethods.waitForElement(driver, autoNumScheme, 60);
        $(autoNumScheme).selectOption(scheme);
        $(saveBtn).click();
        commonMethods.waitForElementExplicitly(2000);
    }
    /**
     * Method to get organization prefix
     *
     */
    public void getOrgPrefix() {
        commonMethods.waitForElement(driver, autoNumScheme, 60);
        if ($(txtBoxAutoNumberBy).isDisplayed())
        {
            orgPrefix= getAutoNumberCode();
        }
    }
    /**
     * Function to verify Transmittal attachment views visibility
     *
     */
    public boolean verifyTransmittal() {
        switchToOriginal();
        switchProjectSettingsFrame();
        commonMethods.waitForElement(driver, mailFooterHeader, 45);
        return $(transmittalAttachmentViews).isDisplayed();
    }
    /**
     * Function to verify mail Footers Sections
     *
     */
    public void verifyMailFooterSection() {
        switchToOriginal();
        switchProjectSettingsFrame();
        commonMethods.waitForElement(driver, mailFooterHeader, 45);
        Assert.assertTrue($(transmittalAttachmentViews).isDisplayed());
        Assert.assertTrue($(autoNumSchemeSection).isDisplayed());
        Assert.assertTrue($(mailFootersSection).isDisplayed());
    }

    /**
     * Function to store custom view selected fields
     */
    public void storeCustomViewFields() {
        customViewSelectedFieldList.clear();
        for(WebElement element : $$(customViewSelectedField))
            customViewSelectedFieldList.add(element.getText().toUpperCase());
    }
    /**
     * Function to create Custom View And Store selected fields
     *
     * @param customViewName is the name of the Custom View to be created
     */
    public void createAndStoreCustomViewFields(String customViewName) {
        $(name).sendKeys(customViewName);
        storeCustomViewFields();
        clickSaveButton();
    }
    /**
     * Function to clear mail footer
     */
    public void clearFooterMessage(String mailType) {
         $(By.xpath("//form[@name='CORRESPONDENCE_SETTINGS']//table//tr//td[text()='" + mailType + "']/../td/textarea")).clear();
    }

    /**
     * Function - visibility of mail type in mail footer
     */
    public boolean verifyMaiType(String mailType) {
      return  $(By.xpath("//form[@name='CORRESPONDENCE_SETTINGS']//table//tr//td[text()='" + mailType + "']/../td/textarea")).isDisplayed();
    }

    /**
     * Function to enter mail footer random message
     */
    public void enterMailFooters(String mailType) {
        mailFootersText2=commonMethods.getRandomString(30);
        commonMethods.enterTextValue(By.xpath("//form[@name='CORRESPONDENCE_SETTINGS']//table//tr//td[text()='" + mailType + "']/../td/textarea"),mailFootersText2 );
    }
}
