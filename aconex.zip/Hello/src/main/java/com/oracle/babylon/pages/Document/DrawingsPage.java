package com.oracle.babylon.pages.Document;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.WebDriverRunner;
import io.cucumber.datatable.DataTable;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.util.List;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.page;
import static com.codeborne.selenide.Condition.disappear;

public class DrawingsPage extends DocumentPage {

    private By pageTitle = By.xpath("//h1[contains(text(),'Search -')]//span[text()='Drawings']");
    private By docHyperLink = By.xpath("//div[@col-id='dochyperlink']/div/a");
    private By drawingsTab = By.xpath("//ul[@class='uiTabs-list']//li[contains(text(),'Drawings')]");
    private By DocRegisterPageTitle = By.xpath("//h1[contains(text(),'Search -')]//span[contains(text(),'Document Register')]");
    private By DocTemporaryPageTitle = By.xpath("//h1[contains(text(),'Search -')]//span[text()='Temporary Files']");
    private By docRegisterLink = By.xpath("//li[contains(text(),'Document Register')]");
    private By docDrawingsLink = By.xpath("//li[contains(text(),'Drawings')]");
    private By docTemporaryFilesLink = By.xpath("//li[contains(text(),'Temporary Files')]");
    private By drawingInfoIcon = By.xpath("//div[@id='infoIcon']//div[contains(text(),'Drawings Definition')]");
    private By listView = By.xpath("//span[@class='auiIcon viewList']");
    private By showFilters = By.xpath("//span[text()='Show filters']");
    private By searchDocKeywords = By.xpath("//input[@id='search-keywords-id']");
    private By previewOption = By.xpath("//div[@class='searchNav clearfix']//span[contains(text(),'Preview')]");
    private By downloadIcon = By.xpath("//button[@class='tile-icon-download tile-icon-action']");
    private By gridDots = By.xpath("//aui-menu-button[@class='tile-icon-overflow ng-isolate-scope']");
    private By gridDocOption = By.xpath("//div[@class='auiMenuButton-dropdownContents']//a");
    private By gridDocDetails = By.xpath("//div[@class='drawing-details']//h3");
    private By previewCloseBtn = By.xpath("//button[@class='uiPanel-closeBox uiPanel-action-icon']");
    private By showDefWindow = By.xpath("//div[@id='defiClose']");
    private By closeDefWindow = By.xpath("//div[@class='auiIcon close currentSetCloseIcon']");
    protected By loadingIcon = By.xpath("//div[@class='auiLoaderOverlay-loader']");
    private By selectAllLink = By.xpath("//span[contains(text(),'Select All')]");
    private By gridResults = By.xpath("//li[@class='drawing-tile-list ng-scope'][1]");
    private By drawingGrid = By.xpath("//div[@class='tile-img']//following-sibling::div[@class='drawing-details']");
    Actions actions = new Actions(driver);
    private By docRegisterDrawing = By.xpath("//li[text()='Drawings']");
    private By searchFilter = By.xpath("//html");

    public DrawingsPage() {
        this.driver = WebDriverRunner.getWebDriver();
    }

    /**
     * Method to navigate to Document and verify for the title of the page
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Documents", "Drawings");
        commonMethods.loadPage(driver);
        Assert.assertTrue(verifyPageTitle(pageTitle));
    }

    /**
     * Method to click on  Drawings tab
     */

    public void clickOnDrawings() {
        commonMethods.waitForElement(driver,drawingsTab,35);
        commonMethods.clickOnElement(drawingsTab);
        commonMethods.waitForElementExplicitly(2000);
        if(!$(listView).isDisplayed()) $(drawingsTab).click();
    }

    /**
     * Method to refresh page and navigate to respective tab
     *
     * @param documentNumber
     */

    public void switchTabAndSearch(String documentNumber, String instance) {
        refresh();
        navigateAndVerifyPage(instance);
        verifyAndSwitchFrame();
        String documentNo = returnDocumentNumber(documentNumber);
        searchDocumentNo(documentNo);
    }

    /**
     * Function to verify drawing info message
     *
     * @return
     */
    public Boolean verifyInfoMessage() {
        verifyAndSwitchFrame();
        return $(drawingInfoIcon).isDisplayed();
    }

    /**
     * Function to open drawings definition window
     */
    public void openInfoMessageBox() {
        verifyAndSwitchFrame();
        $(drawingInfoIcon).click();
        Assert.assertTrue($(showDefWindow).isDisplayed());
    }

    /**
     * Function to close drawings definition window
     */
    public void closeInfoMessageBox() {
        $(closeDefWindow).click();
        commonMethods.waitForElementExplicitly(500);
    }

    /**
     * Function to verify drawing Accessibility from different tabs
     */
    public void verifyDrawingAccessibility() {
        verifyAndSwitchFrame();
        Assert.assertTrue(switchTab("document", "Document Register"));
        commonMethods.waitForElementExplicitly(60000);
        Assert.assertTrue(switchTab("document", "Drawings"));
        Assert.assertTrue(switchTab("document", "Temporary Files"));
    }

    /**
     * Function to verify filter value
     *
     * @param filter
     * @return
     */
    public Boolean verifyFilterValue(String filter, String filterValue, String flag) {
        verifyAndSwitchFrame();
        $(By.xpath("//div[text()='" + filter + "']//..//input")).click();
        if (flag.equalsIgnoreCase("Removed") && (!$(By.xpath("//li[@class='ui-select-choices-group']//div[text()='" + filterValue + "']")).isDisplayed())) {
            return true;
        } else if ($(By.xpath("//div[text()='" + filterValue + "']")).isDisplayed()) {
            $(searchFilter).click();
            return true;
        }
        return false;
    }

    /**
     * Function to click on List view
     */

    public void clickOnListView() {
        commonMethods.waitForElement(driver, listView, 60);
        $(listView).click();
    }

    /**
     * Function to check Preview option
     */

    public void verifyPreview(String documentNo) {
        verifyAndSwitchFrame();
        actions.moveToElement($(previewOption)).click().perform();
        Assert.assertTrue($(By.xpath("//div[@class='uiPanel-title-block-column uiPanel-title-block-column-docTitle' and @title='"+documentNo+"']")).isDisplayed());
        actions.moveToElement($(previewCloseBtn)).click().perform();
    }

    /**
     * Function to verify Download Icon
     */

    public boolean verifyDownloadIcon() {
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, gridResults, 60);
        actions.moveToElement($(downloadIcon)).build().perform();
        return $(downloadIcon).isDisplayed();
    }

    /**
     * Function to verify Doc Options in Grid Mode
     */

    public void verifyGridDocOption(List<String> data) {
        actions.moveToElement($(gridDots)).click().perform();
        List<WebElement> docOption = driver.findElements(gridDocOption);
        for(int i=1;i<docOption.size();i++){
            commonMethods.waitForElementExplicitly(1000);
            Assert.assertTrue(data.contains(docOption.get(i).getAttribute("innerText")));
        }
    }

    /**
     * Function to verify Doc Details in Grid Mode
     */

    public void verifyDocDetails(List<String> data) {
        verifyAndSwitchFrame();
        actions.moveToElement($(gridDocDetails)).build().perform();
        for (int i = 0; i < data.size(); i++) {
            Assert.assertTrue($(By.xpath("//div[@class='drawing-details']//h3[contains(.," + data.get(i) + ")]")).isDisplayed());
        }
    }

    /**
     * Function to click on the Document Number Link in grid mode and verify
     */

    public void verifyGridDocument(String docNum, String pageTitle){
        verifyAndSwitchFrame();
        By documentNumber = By.xpath("//span[contains(text(),'"+docNum+"')]");
        getElementInView(documentNumber);
        $(documentNumber).click();
        Assert.assertTrue(verifyPageTitle(pageTitle));
    }


    /**
     * Method to verify document displayed in drawings page
     */
    public boolean verifyDocInDrawingTab(String docNo) {
        $(docRegisterDrawing).click();
        commonMethods.waitForElementExplicitly(3000);
        searchDocumentNo(docNo);
        return verifyDocumentGrid();
    }

    /**
     * Method to return drawing definition attributes for a given doc type
     */
    public String verifyDrawingDefinition(String type) {
        By xpath = By.xpath("//div/strong[text()='" + type + "']/../following-sibling::div");
        commonMethods.waitForElement(driver, xpath);
        return $(xpath).getText();
    }

    /**
     * Method to verify drawing grid displayed
     */
    public boolean verifyDrawingGrid() {
       commonMethods.waitForElementExplicitly(3000);
        return $(drawingGrid).isDisplayed();
    }
}

