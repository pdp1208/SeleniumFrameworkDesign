package com.oracle.babylon.Utils.helper;

import com.oracle.pgbu.selenium.common.reportms.utils.HttpClientHelper;
import io.restassured.http.Cookie;
import io.restassured.http.Header;
import io.restassured.http.Method;
import io.restassured.response.Response;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SessionHolder extends Navigator{

    String baseURL;
    HttpClientHelper httpClientHelper = new HttpClientHelper();
    private static final Map<String,String> headerNames;
    private static final Map<String,String> cookieNames;
    private static final Map<String,String> contentTypes;

    static {
        headerNames = new HashMap<String, String>(){
            {
                put("contenttype", "Content-Type");
            }
        };
        cookieNames = new HashMap<String, String>(){
            {
                put("jsessionid", "JSESSIONID");
                put("xsrftoken", "XSRF-TOKEN");
            }
        };
        contentTypes = new HashMap<String, String>(){
            {
                put("form-urlencoded","application/x-www-form-urlencoded");
            }
        };
    }
    public SessionHolder(){
        baseURL = configFileReader.getApplicationUrl();
    }

    /**
     * Method to get initial csrf token required for starting communication with application server.
     * @return response
     */
    public Response getXSRFToken() {
        return httpClientHelper.execRequest(Method.GET, baseURL + "Logon", new ArrayList<Header>(), "", null, null, null, "");
    }

    /**
     * Method to get user session along with csrf token, jsessionid, sessionid, cookies,headers,etc.
     *
     * @param username username
     * @param password password
     * @return response
     */
    public Response login(String username, String password) {
        Response response = getXSRFToken();
        List<Cookie> cookies = new ArrayList<>();
        cookies.add(response.getDetailedCookie(cookieNames.get("jsessionid")));
        cookies.add(response.getDetailedCookie(cookieNames.get("xsrftoken")));
        List<Header> headersList = new ArrayList<>();
        Header xsrfToken = new Header(cookieNames.get("xsrftoken"), response.getCookie(cookieNames.get("xsrftoken")));
        headersList.add(xsrfToken);
        Header header = new Header(headerNames.get("contenttype"), contentTypes.get("form-urlencoded"));
        headersList.add(header);
        String url = baseURL + "Logon?csrfToken=" + response.getCookie(cookieNames.get("xsrftoken")) + "&Action=Logon&cred=true&userName=" + username + "&password=" + password + "&sso=false";
        return httpClientHelper.execRequest(Method.POST, url, headersList, null, cookies, null, null, "");
    }
}
