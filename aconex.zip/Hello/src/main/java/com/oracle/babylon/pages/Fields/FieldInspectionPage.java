package com.oracle.babylon.pages.Fields;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;

import java.util.Map;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Condition.disappears;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.actions;

public class FieldInspectionPage extends FieldIssuePage {

    private By loaderOverlay = By.cssSelector(".uiLoadingBlocker");
    private By newInspectionButton = By.xpath("//button[contains(@class,'new-inspection')]");
    private By templateSelctionDialog = By.cssSelector(".modal-dialog .auiModal-content");
    private String startInspection = "//span[contains(text(),'TEMPLATE_NAME')]/parent::td//following-sibling::td[contains(@class,'template-button')]//button[contains(@class,'primary')]";
    private By textInput = By.xpath("//*[contains(@class,'textResponseInput')]");
    private By textAreaInput = By.xpath("//*[contains(@class,'textareaResponseInput')]");
    private By save = By.xpath("//div[contains(@class,'page-top-bar')]//button[contains(@class,'primary')]");
    private By yes = By.xpath("//*[contains(@class,'eachresponse')][1]");
    private By no = By.xpath("//*[contains(@class,'eachresponse')][2]");
    private By listDropDown = By.xpath("//*[contains(@class,'aui-custom-dropdown')]");
    private By search = By.xpath("//input[contains(@class,'search-filter')]");
    private By inspectionCreationSuccessMessage = By.xpath("//*[text()='Changes to the inspection have been saved']");
    private By loader = By.xpath("//*[contains(@class,'uiLoadingBlocker')]");
    private By addIssueLink = By.xpath("//*[contains(@class,'add-issue-link')]");
    private String successMessagelocator = "//div[contains(@class,'success')]/descendant::div[(text()='MESSAGE')]";
    private By issueId = By.xpath("//*[contains(@class,'issue-metadata')]//span[contains(@class,'issue-number')]");
    private By done = By.xpath("//*[contains(@class,'primary')][contains(@ng-click,'NewIssue')]");
    private By inspectionNo = By.xpath("//label[contains(@class,'number-value')]");
    private By photoAttachment = By.xpath("//input[@id='add-photo-attachment'][@type='file']");
    private By upload = By.xpath("//button[contains(text(),'Upload')]");
    private By searchInput = By.xpath("//input[contains(@class,'search-input')]");
    private By searchButton = By.xpath("//div[contains(@class,'list-action-header')]/button");
    private By edit = By.xpath("//*[contains(@class,'checklist-controls')]/button");
    private By issueAttachment = By.xpath("//div[contains(@class,'issue-attachment')]");
    private By attachmentSection = By.xpath("//div[contains(@class,'attachment-div')]");
    private String filePath = System.getProperty("user.dir") + "/src/main/resources/data/files/";

    /**
     * Method to navigate to field Inspections page.
     *.
     */
    public void navigateAndVerifyPage(){
        getMenuSubmenu("Field", "Inspections");
        commonMethods.switchToFrame(driver, "frameMain");
        try {
            commonMethods.waitForElement(driver, loaderOverlay, 8);
            $(loaderOverlay).waitUntil(hidden, 30000);
        } catch(TimeoutException e){
            //ignore
        }
    }

    /**
     * Method to create inspection.
     *
     * @param template name of the template.
     * @param area name of the area.
     * @param type type of inspection template.
     * @param value value for the inspection item.
     */
    public String createInspection(String template, String area, String type, String value){
        selectRootArea();
        selectSubArea();
        navigateToAreaByPath(area);
        closeDropDown();
        $(newInspectionButton).waitUntil(appears, 5000).click();
        $(templateSelctionDialog).waitUntil(appears, 7000);
        $(search).setValue(template);
        actions().moveToElement($(By.xpath(startInspection.replaceAll("TEMPLATE_NAME",template)))).click().build().perform();
        waitForLoaderToDisappear();
        switch(type.toLowerCase()){
            case "text":
                $(textInput).setValue(value);
                break;
            case "yes # no":
                if(value.equalsIgnoreCase("yes")){
                    $(yes).click();
                } else {
                    $(no).click();
                }
                break;
            case "text area":
                $(textAreaInput).waitUntil(appears,5000).setValue(value);
                break;
            case "select list":
                $(listDropDown).click();
                $(By.xpath("//li[contains(@class,'select-option ng-scope')]/span[text()='" + value + " ']")).click();
                break;
        }
        $(save).click();
        $(inspectionCreationSuccessMessage).waitUntil(appears,5000);
        $(inspectionCreationSuccessMessage).waitUntil(disappears,10000);
        return $(inspectionNo).getText();
    }

    /**
     * Method to add new field issue.
     *
     * @param issueDetails Details of the issue to be added.
     */
    public void addIssue(Map<String, String> issueDetails){
        $(addIssueLink).waitUntil(appears, 6000).click();
        if($(loader).isDisplayed()) {
            $(loader).waitUntil(disappears, 10000);
        }
        selectIssueType(issueDetails.get("Issue type"));
        setIssueDescription(issueDetails.get("Description"));
        setAssignee(issueDetails.get("Assign to"));
        selectDueDate(issueDetails.get("Due date"));
        $(photoAttachment).sendKeys(filePath + issueDetails.get("Photo"));
        $(upload).click();
        $(done).click();
        $(save).waitUntil(appear, 5000).click();
    }

    /**
     * Method to edit inspection item.
     *
     * @param inspectionId inspection id.
     */
    public void editInspectionItem(String inspectionId){
        $(searchInput).setValue(inspectionId);
        $(searchButton).click();
        $(By.xpath("//div[contains(@class,'checklist-details-number')][text()='" + inspectionId + "']")).waitUntil(appears, 50000);
        $(edit).click();
        $(issueAttachment).click();
        $(attachmentSection).waitUntil(appear, 6000);
    }

    /**
     * Method to verify success message.
     *
     * @param message expected message.
     */
    public void verifySuccessMessage(String message){
        String locator = successMessagelocator.replaceAll("MESSAGE",message);
        $(By.xpath(locator)).waitUntil(appears, 10000);
        $(By.xpath(locator)).waitUntil(disappears, 10000);
    }

    /**
     * Method to fetch issue numbre from webpage.
     *
     */
    public String getIssueNo(){
        return $(issueId).waitUntil(appears,5000).getText();
    }
}
