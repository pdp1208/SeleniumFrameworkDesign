package com.oracle.babylon.pages.Document;

import com.oracle.babylon.Utils.helper.CommonMethods;
import com.oracle.babylon.Utils.setup.dataStore.DataStore;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class ImportMetaDataPage extends AddDocumentsPage {
    private By docName = By.xpath("//div[@class='filename ng-binding']");
    private By uploadDocHeader = By.xpath("//h2[text()='Upload Documents']");
    private By mandatoryType = By.xpath("//label[text()='Type']//parent::div[@ng-required='field.mandatory'and @required='required']");
    private By mandatoryDocNo = By.xpath("//label[text()='Document No']//parent::div[@ng-required='field.mandatory'and @required='required']");
    private By mandatoryRevision = By.xpath("//label[text()='Revision']//parent::div[@ng-required='field.mandatory'and @required='required']");
    private By mandatoryTitle = By.xpath("//label[text()='Title']//parent::div[@ng-required='field.mandatory'and @required='required']");
    private By mandatoryStatus = By.xpath("//label[text()='Status']//parent::div[@ng-required='field.mandatory'and @required='required']");
    private By mandatoryDiscipline = By.xpath("//label[text()='Discipline']//parent::div[@ng-required='field.mandatory'and @required='required']");
    private By mandatoryRevDate = By.xpath("//label[text()='Revision Date']//parent::div[@ng-required='field.mandatory'and @required='required']");
    private By attribute1 = By.xpath("//label[text()='Attribute 1']//parent::div[@ng-required='field.mandatory']");
    private By attribute2 = By.xpath("//label[text()='Attribute 2']//parent::div[@ng-required='field.mandatory']");
    private By confidential = By.xpath("//label[text()='Confidential']//parent::div[@ng-required='field.mandatory']");
    private By scale = By.xpath("//label[text()='Scale']//parent::div[@ng-required='field.mandatory']");
    private By dateCreated = By.xpath("//label[text()='Date Created']//parent::div[@ng-required='field.mandatory']");
    private By mileStoneDate = By.xpath("//label[text()='Milestone Date']//parent::div[@ng-required='field.mandatory']");
    private By plannedSubDate = By.xpath("//label[text()='Planned Submission Date']//parent::div[@ng-required='field.mandatory']");
    private By authorizedBy = By.xpath("//label[text()='Authorized by']//parent::div[@ng-required='field.mandatory']");
    private By comments = By.xpath("//label[text()='Comments']//parent::div[@ng-required='field.mandatory']");
    private By contractNo = By.xpath("//label[text()='Contract No']//parent::div[@ng-required='field.mandatory']");
    private By packageNo = By.xpath("//label[text()='Package No']//parent::div[@ng-required='field.mandatory']");
    private By importMetaDataBtn = By.xpath("//button[contains(text(),'Import metadata')]");
    private By importMetaDatPopUpHeader = By.xpath("//div[@class='auiModal-content']//h3[text()='Import metadata']");
    private By sampleTemplateHeader = By.xpath("//h2[contains(text(),'1. Populate the sample template')]");
    private By downloadHeaderMessage = By.xpath("//p[contains(text(),'Download the template below and then populate the metadata')]");
    private By templateMetaDataLink = By.xpath("//a[text()='TemplateMetadata.xls']");
    private By uploadMetaDataFileHeader = By.xpath("//h2[contains(text(),'2. Upload the populated metadata file')]");
    private By filesTypesHeader = By.xpath("//span[text()='File types accepted: CSV, XLS']");
    private By importMetaDataCancelBtn = By.xpath("//div[@class='auiModal-footer']//button[@ng-click='closeImportMetadataModal()']");
    private By importMetaDataCloseBtn = By.xpath("//div[@class='auiModal-close' and @ng-click='closeImportMetadataModal()']");
    private By importBtnEnabled = By.xpath("//div[@class='auiModal-footer']//button[@ng-click='importMetadata()' and not(@disabled='disabled')]");
    private By docSelectChkBox = By.xpath("(//div[@ref='headerRoot']//div[@class='ag-header-cell']//span)[1]");
    private By updateDocSelectOpt = By.xpath("//a[text()='Update']");
    private By importMetaDataErrorMsg = By.xpath("//label[text()='The file is either empty or invalid. Download the template and fill in the required information.']");
    private By fileUploadSuccessMsg = By.xpath("//div[contains(text(),'files have been updated')]");
    private By revisionList = By.xpath("//input[@id='revision']");
    private By title = By.xpath("//input[@id='title']");
    private By status = By.xpath("//select[@id='docstatus']//option[text()='-- Select --' and @selected='selected']");
    private By listView = By.xpath("//button[@title='List View' and @disabled='disabled']//span");
    private By tableView = By.xpath("//button[@title='Table View' and @disabled='disabled']//span");
    private By readyToRegister = By.xpath("//span[contains(text(),'Ready to register')]");
    private By tblViewreadyToRegister = By.xpath("//div[@ref='eBodyViewport']//div[@col-id='badges']//span[contains(text(),'Ready to register')]");
    private By registerBtn = By.xpath("//button[contains(text(),'Register') and  not (@disabled='disabled')]");
    private By updateDocHeader = By.xpath("//h2[text()='Update Documents']");
    private By filesList = By.xpath("//div[@class='filename ng-binding']");
    private By docNumber = By.xpath("//acx-unified-upload-text-field[@class='ng-pristine ng-untouched ng-valid ng-scope ng-isolate-scope ng-not-empty']//input[@id='docno']");
    private By revisionFilled = By.xpath("//acx-unified-upload-text-field[@class='ng-pristine ng-untouched ng-valid ng-scope ng-isolate-scope ng-not-empty']//input[@name='revision']");
    private By titleFilled = By.xpath("//acx-unified-upload-text-field[@class='ng-pristine ng-untouched ng-valid ng-scope ng-isolate-scope ng-not-empty']//input[@id='title']");
    private By fileSelectTableView = By.xpath("//div[@class='ag-header-cell' and @role='presentation']//input[@type='checkbox']//following-sibling::div//span");
    private By fileSelectListView = By.xpath("//div[@class='files']//input[@type='checkbox']");
    private By docTypeOption = By.id("doctype");
    private By docStatusOption = By.id("docstatus");
    private By disciplineOption = By.id("discipline");
    private By docTypeTableView = By.xpath("//div[@col-id='doctype']");
    private By docNoTableView = By.xpath("//div[@col-id='docno']");
    private By revisionTableView = By.xpath("//div[@col-id='revision']");
    private By titleTableView = By.xpath("//div[@col-id='title']");
    private By statusTableView = By.xpath("//div[@col-id='docstatus']");
    private By disciplineTableView = By.xpath("//div[@col-id='discipline']");
    private By revisionDateTableView = By.xpath("//div[@col-id='revisiondate']");
    private By confirmBtn = By.xpath("//div[@class='uiPanel confirmPanel'][2]//button[@title='Continue']");
    private By tempFileUploadToday = By.xpath("//li[@title='Temporary files uploaded by me today']");
    private By confidentialChk = By.xpath("//label[@class='auiField-checkbox']//input[@type='checkbox']");
    private By docUploadCloseBtn = By.xpath("//button[text()='Close']");
    CommonMethods commonMethods = new CommonMethods();
    protected DataStore dataStore = new DataStore();
    BulkSupersedePage bulkSupersedePage = new BulkSupersedePage();
    private By docTypeEmptyCheck =  By.xpath("//div[@class='auiForm-field']//select[@id='doctype']//following::acx-validation-hint[1]/div[contains(text(),'This field is required.')]");
    private By revDateEmptyCheck =  By.xpath("//div[@class='auiForm-field']//input[contains(@id,'revisiondate')]//following::acx-validation-hint[1]/div[contains(text(),'This field is required.')]");
    private By docNumberEmptyCheck = By.xpath("//div[@class='auiForm-field']//input[contains(@id,'docno')]//following::acx-validation-hint[1]/div[contains(text(),'This field is required.')]");
    private By revisionEmptyCheck =  By.xpath("//div[@class='auiForm-field']//input[@name='revision']//following::acx-validation-hint[1]/div[contains(text(),'This field is required.')]");
    private By titleEmptyCheck =  By.xpath("//div[@class='auiForm-field']//input[@name='title']//following::acx-validation-hint[1]//div[contains(text(),'This field is required.')]");
    private By docStatusEmptyCheck =  By.xpath("//div[@class='auiForm-field']//select[@id='docstatus']//following::acx-validation-hint[1]//div[contains(text(),'This field is required.')]");
    private By disciplineEmptyCheck =  By.xpath("//div[@class='auiForm-field']//select[@id='discipline']//following::acx-validation-hint[1]//div[contains(text(),'This field is required.')]");
    private By templateUploadErrorMsg = By.xpath("//div[contains(text(),'Some imported values are invalid and have been removed.')]");
    /**
     * Method to verify the document left panel contents
     */
    public void verifyUploadDocLeftPanel(String fileName) {
        Assert.assertTrue("Document name matches", $(docName).getText().equals(fileName));
        List<WebElement> elements = Arrays.asList($(uploadDocHeader), $(mandatoryType), $(mandatoryDocNo), $(mandatoryRevision), $(mandatoryTitle), $(mandatoryStatus), $(mandatoryDiscipline), $(mandatoryRevDate), $(attribute1), $(attribute2), $(confidential), $(scale), $(dateCreated), $(authorizedBy), $(comments), $(contractNo), $(packageNo));
        commonMethods.verifyElementsPresent(elements);
    }

    /**
     * Method to verify the import meta data button enabled
     */
    public void verifyImportMetadata() {
        Assert.assertTrue("The import meta data button is enabled", $(importMetaDataBtn).isEnabled());
    }

    /**
     * Method to click the import meta data button
     */
    public void clickImportMetaData() {
        commonMethods.waitForElement(driver, importMetaDataBtn, 60);
        $(importMetaDataBtn).click();
    }

    /**
     * Method to verify the import meta data popup contents
     */
    public void verifyImportMetDataPopUp() {
        Assert.assertTrue("Import metadata popup is displayed", $(importMetaDatPopUpHeader).isDisplayed());
    }

    /**
     * Method to verify import button is enabled
     */
    public boolean verifyImportBtnEnabled() {
        commonMethods.waitForElementExplicitly(4000);
        return $(importBtnEnabled).isEnabled();
    }

    /**
     * Method to click the import button
     */
    public void clickImportBtn() {
        $(importBtnEnabled).click();
    }

    /**
     * Method to close the import meta data popup
     */
    public void clickImportMetaDataClose() {
        commonMethods.waitForElement(driver,importMetaDataCloseBtn,30);
        $(importMetaDataCloseBtn).click();
        commonMethods.waitForElementExplicitly(3000);
    }

    /**
     * Method to click document selection check box
     */
    public void clickDocSelectChkBx() {
        commonMethods.waitForElement(driver,docSelectChkBox,30);
        $(docSelectChkBox).click();
    }

    /**
     * Method to verify import meta data button not present
     */
    public boolean importMetaDataBtnNotPresent() {
        return $(importMetaDataBtn).isDisplayed();
    }

    /**
     * Method to verify the error message in import meta data popup
     */
    public void verifyErrorMsg() {
        commonMethods.waitForElementExplicitly(2000);
        Assert.assertTrue("Error message displayed", $(importMetaDataErrorMsg).isDisplayed());
    }

    /**
     * Method to verify the success message after the file upload
     */
    public void fileUploadSuccessMsg() {
        commonMethods.waitForElement(driver, fileUploadSuccessMsg, 15);
        Assert.assertTrue("File is not uploaded successfully", $(fileUploadSuccessMsg).isDisplayed());
    }

    /**
     * Method to verify mandatory field is empty
     */
    public void verifyMandFieldEmpty() {
        Assert.assertTrue("Doc Type select box option selected",$(docTypeEmptyCheck).isDisplayed());
        Assert.assertTrue("Revision is not empty",$(revisionEmptyCheck).isDisplayed());
        Assert.assertTrue("Rev date is not empty",$(revDateEmptyCheck).isDisplayed());
        Assert.assertTrue("Title is not empty",$(titleEmptyCheck).isDisplayed());
        Assert.assertTrue("Doc status is not empty",$(docStatusEmptyCheck).isDisplayed());
        Assert.assertTrue("Discipline is not empty",$(disciplineEmptyCheck).isDisplayed());
    }

    /**
     * Method to verify the list view is displayed
     */
    public void verifyListView() {
        Assert.assertTrue("List view is displayed", $(listView).isDisplayed());
    }

    /**
     * Method to verify the badge and register buttons displayed
     */
    public void verifyBadgeRegisterBtn(String badgeCount, String viewName) {
        commonMethods.waitForElementExplicitly(3000);
        if (viewName.equals("table view")) {
            commonMethods.waitForElement(driver, tblViewreadyToRegister, 30);
            Assert.assertTrue("Badge button is enabled  in table view", $$(tblViewreadyToRegister).size() == Integer.parseInt(badgeCount));

        }
        else {
            commonMethods.waitForElement(driver, readyToRegister, 30);
            Assert.assertTrue("Badge button is enabled in list view", $$(readyToRegister).size() == Integer.parseInt(badgeCount));
        }
        Assert.assertTrue("Register button is enabled", $(registerBtn).isDisplayed());
    }

    /**
     * Method to verify the import meta data popup contents
     */
    public void verifyMetaDataPopUp() {
        Assert.assertTrue("Import metaData header displayed", $(importMetaDatPopUpHeader).isDisplayed());
        Assert.assertTrue("Import Meta data button is displayed", $(importMetaDataBtn).isDisplayed());
        Assert.assertTrue("Populate the sample template text is displayed", $(sampleTemplateHeader).isDisplayed());
        Assert.assertTrue("Download the template below and then populate the metadata test is displayed", $(downloadHeaderMessage).isDisplayed());
        Assert.assertTrue("Template Metadata file download link is displayed", $(templateMetaDataLink).isDisplayed());
        Assert.assertTrue("Upload the populated metadata file text is displayed", $(uploadMetaDataFileHeader).isDisplayed());
        Assert.assertTrue("File types accepted: CSV, XLS text is displayed", $(filesTypesHeader).isDisplayed());
        Assert.assertTrue("import metadata close button is displayed", $(importMetaDataCloseBtn).isDisplayed());
        Assert.assertTrue("Cancel button is displayed", $(importMetaDataCancelBtn).isDisplayed());
    }

    /**
     * Method to verify the multiple files displayed
     */
    public void verifyMultiFilesDocUpdate() {
        commonMethods.waitForElementExplicitly(6000);
        Assert.assertTrue("Navigated to update documents page ", $(updateDocHeader).isDisplayed());
        commonMethods.waitForElement(driver, filesList, 30);
        Assert.assertTrue("Multiple files displayed", $$(filesList).size() > 1);
    }

    /**
     * Method to verify the import meta data contents in list view
     */
    public void verifyImpMetListView(String details) {
        Map<String, String> table = dataStore.getTable(details);
        commonMethods.waitForElementExplicitly(3000);
        for (WebElement element : $$(fileSelectListView)) {
            element.click();
            commonMethods.waitForElementExplicitly(2000);
            Assert.assertTrue("Document number is not empty", !$(docNumber).getValue().isEmpty());
            Assert.assertTrue("Revision field is not empty", table.containsValue($(revisionFilled).getValue()));
            Assert.assertTrue("Title field is not empty", !$(titleFilled).getValue().isEmpty());
            Assert.assertTrue("Doc Type value matches", table.containsValue($(docTypeOption).getText()));
            Assert.assertTrue("Status select box value matches", table.containsValue($(docStatusOption).getText()));
            Assert.assertTrue("Discipline value matches", table.containsValue($(disciplineOption).getText()));
        }
    }

    /**
     * Method to verify the import meta data contents in table view
     */
    public void verifyImpMetTableView(String details) {
        Map<String, String> table = dataStore.getTable(details);
        List<String> expectedlist = new ArrayList<String>(table.values());
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver,fileSelectTableView,30);
        $(fileSelectTableView).click();
        commonMethods.waitForElementExplicitly(1000);
        commonMethods.waitForElement(driver,docNoTableView,30);
        Assert.assertTrue("Revision in table view matches",listCompare(expectedlist, revisionTableView));
        Assert.assertTrue("Status in table view matches",listCompare(expectedlist, statusTableView));
        Assert.assertTrue("Discipline in table view matches",listCompare(expectedlist, disciplineTableView));
    }

    /**
     * Method to verify the import meta data contents on right side
     */
    public void verifyImportMetDatRight() {
        Assert.assertTrue("Document number is not empty", $(docNumber).isDisplayed());
        Assert.assertTrue("Revision field is not empty", $(revisionFilled).isDisplayed());
        Assert.assertTrue("Title field is not empty", $(titleFilled).isDisplayed());
        Assert.assertTrue("Doc Type select box as a value " + $(docTypeOption).getSelectedOption().exists(), true);
        Assert.assertTrue("Status select box as a value " + $(docStatusOption).getSelectedOption().exists(), true);
        Assert.assertTrue("Discipline select box as a value " + $(disciplineOption).getSelectedOption().exists(), true);
    }

    /**
     * Method to click the confirm button
     */
    public void clickConfirmBtn() {
        if ($(confirmBtn).isDisplayed())
            $(confirmBtn).click();
    }

    /**
     * Method to click the temp files uploaded by today
     */
    public void clickTempFileUpload() {
        $(tempFileUploadToday).click();
    }

    /**
     * Method to click document confidential check box
     */
    public void clickConfidentialChk() {
        $(confidentialChk).click();
    }

    /**
     * Method to click the document upload close button
     */
    public void clickDocUploadClose() {
        $(docUploadCloseBtn).click();
    }

    /**
     * Method to compare the WebElement list
     */
    public boolean listCompare(List<String> table, By elementList) {
        List<WebElement> elements = new ArrayList<>($$(elementList));
        boolean flag= false;
        for (int i =1; i<elements.size(); i++) {
            if(table.contains(elements.get(i).getText()))
                flag=true;
            else{
                flag=false;
                break;
            }
        }
        return flag;
    }

    /**
     * Method to download the template file
     */
    public void clickTemplateLink(){
        commonMethods.waitForElementExplicitly(4000);
        commonMethods.waitForElement(driver,templateMetaDataLink,30);
        $(templateMetaDataLink).click();
    }

    /**
     * Method to verify mandatory single select fields are empty
     */
    public void verifyMandSelectFields() {
        Assert.assertTrue("Doc Type select box option selected",$(docTypeEmptyCheck).isDisplayed());
        Assert.assertTrue("Rev date is not empty",$(revDateEmptyCheck).isDisplayed());
        Assert.assertTrue("Doc status is not empty",$(docStatusEmptyCheck).isDisplayed());
        Assert.assertTrue("Discipline is not empty",$(disciplineEmptyCheck).isDisplayed());
    }

    /**
     * Method to verify mandatory text fields are not empty
     */
    public void verifyMandTextFields() {
        Assert.assertFalse("Revision is empty",$(revisionEmptyCheck).isDisplayed());
        Assert.assertFalse("Doc no is empty",$(docNumberEmptyCheck).isDisplayed());
        Assert.assertFalse("Title is empty",$(titleEmptyCheck).isDisplayed());
    }

    /**
     * Method to verify invalid value(s) template upload error message
     */
    public void verifyTemplateUploadMsg() {
       Assert.assertTrue("Invalid Values Template Upload Error Msg is not displayed" , $(templateUploadErrorMsg).isDisplayed());
    }

}