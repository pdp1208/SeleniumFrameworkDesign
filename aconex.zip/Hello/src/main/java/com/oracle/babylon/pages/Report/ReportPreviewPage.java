package com.oracle.babylon.pages.Report;

import com.oracle.babylon.Utils.helper.Navigator;
import com.oracle.babylon.Utils.helper.SessionHolder;
import com.oracle.pgbu.selenium.common.reportms.utils.CommonUtilities;
import com.oracle.pgbu.selenium.common.reportms.utils.ReportDownloadHelper;
import io.restassured.http.Cookie;
import io.restassured.http.Header;
import io.restassured.response.Response;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.tika.exception.TikaException;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.xml.sax.SAXException;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import java.util.Map;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;

/**
 * Page object class for Report preview page.
 *
 */
public class ReportPreviewPage extends Navigator {

    private By saveSuccessMessage = By.cssSelector("#save-success");
    private FilterContolPanel filterControlPanel = new FilterContolPanel();
    private Toolbar toolbar = new Toolbar();
    public CommonUtilities commonUtilities = new CommonUtilities();
    private By loader = By.xpath("//div[@id='loading']//div[@class='auiLoaderOverlay-loader']");
    private By addLayoutButton = By.cssSelector("#add-layout-button");
    private By configureLayoutButton = By.cssSelector("#configureLayout");
    private By recordsTable = By.xpath("(//table)[last()]");
    private static final String BIP_WINDOW_TITAL = "BI Publisher";
    private SessionHolder session = new SessionHolder();
    private static final String experimentation_subject_id = "Ijc1ZDlmMWFhLWVhYjItNDdkNC04NzU1LWM1ZjQ0ZGFjMDA3MSI%3D--4493c4c935ea7db935f660d7d209d4b075076555;";
    public ReportDownloadHelper reportDownloadHelper = new ReportDownloadHelper();
    private By customRangeMessage = By.xpath("//*[contains(@class,'growler')]/*[contains(@class,'auiMessage-content')]");
    private By filterPanel = By.xpath("//*[contains(@id,'filter-panel')]//*[contains(@class,'filter-label')]");
    private By exportAs = By.xpath("//*[contains(text(),'Export As')]");
    public By loaderOverlay = By.cssSelector(".auiLoaderOverlay");
    private WaitOptionDialog waitOptionDialog = new WaitOptionDialog();

    /**
     * Method to verify success message.
     *
     */
    public void verifySaveSuccessMessage(){
        $(saveSuccessMessage).waitUntil(appear, 10000);
        $(saveSuccessMessage).waitUntil(disappear, 10000);
    }

    /**
     * Method to select filter values on preview page.
     *
     * @param columnName column name.
     * @param values filter values to be selected for specified columns.
     */
    public void selectFilterValuesOnPreviePage(String columnName, List<String> values){
        verifyAndSwitchFrame();
        filterControlPanel.openListOfAvailaleFilterValues(columnName);
        filterControlPanel.clearAll();
        if(!values.contains("NULL")) {
            filterControlPanel.selectFilterValues(columnName, values);
        }
    }

    /**
     * Method to close list of filter values.
     *
     * @param columnName - Name of the filter column.
     */
    public void closeListOfFilterValues(String columnName) {
        String confirmationDialogSelecorModified = filterControlPanel.replaceColumnNameInCommonLocator(columnName);
        if (!columnName.contains("Date")){
            if ($(By.xpath(confirmationDialogSelecorModified + "//*[@class='sSelect-input']")).isDisplayed()) {
                $(By.xpath(confirmationDialogSelecorModified + "//*[@class='sSelect-input']")).click();
            }
        }
    }

    /**
     * Method to set filter values on preview page.
     *
     * @param columnName column name.
     * @param value filter value to be set.
     */
    public void setFilterValues(String columnName, String value){
        verifyAndSwitchFrame();
        if(value.equalsIgnoreCase("NULL")){
            filterControlPanel.setFilterValue(columnName, "");
        } else{
            filterControlPanel.setFilterValue(columnName, value);
        }
    }

    /**
     * Method to fetch available filter values for specified column on preview page.
     *
     * @param columnName column name.
     */
    public List<String> getFilterValuesOnPreviePage(String columnName){
        List<String> availableFilterValues = null;
        verifyAndSwitchFrame();
        availableFilterValues = filterControlPanel.openListOfAvailaleFilterValues(columnName);
        if($(filterControlPanel.cancelButton).isDisplayed()) {
            $(filterControlPanel.cancelButton).click();
        }
        return availableFilterValues;
    }

    /**
     * Method to select bip layout on preview page.
     *
     * @param layoutName layout name.
     */
    public void selectLayout(String layoutName){
        toolbar.selectBIPLayout(layoutName);
    }

    /**
     * Method to get preview data.
     *
     */
    public String getPreviewData() throws IOException, SAXException, TikaException {
        switchTo().defaultContent();
        verifyAndSwitchFrame("frameMain");
        try {
            if($(waitOptionDialog.waitingOption).isDisplayed()){
                waitOptionDialog.keepWaiting();
                commonMethods.waitForElement(driver, loaderOverlay, 10);
                $(loaderOverlay).waitUntil(disappear, 90000, 3000);
            }
        }catch(Exception e){
            //No action needs to be taken.
        }
        $(exportAs).waitUntil(appears, 20000);
        driver.switchTo().frame("runnerIframe");
        String previewData = driver.getPageSource();
        previewData = StringUtils.replacePattern(previewData, "<colgroup>(.*?)</colgroup>", "");
        previewData = StringUtils.replacePattern(previewData, "<head>(.*?)</head>", "");
        previewData = previewData.replace("<br>", "<br/>");
        previewData = StringUtils.replacePattern(previewData, "<meta(.*?)>", "");
        previewData = StringUtils.replacePattern(previewData, "<style(.*?)</style>", "");
        previewData = StringEscapeUtils.unescapeHtml4(previewData);
        previewData = previewData.replace("svg+xml\">", "svg+xml\"/>");
        previewData = previewData.replaceAll("&","&amp;");
        InputStream stream1 = new ByteArrayInputStream(previewData.getBytes(Charset.forName("UTF-8")));
        previewData = commonUtilities.getExpectedDataFromFile(stream1);
        return previewData;
    }

    /**
     * Method to fetch data from file.
     *
     * @param filePath path of file.
     */
    public String extractDataFromFile(String filePath, String format) throws IOException, TikaException, SAXException {
        return commonUtilities.extractDataFromFile(filePath, format);
    }

    /**
     * Method to get available filters at run time.
     *
     */
    public List<String> getAvailableFiltersAtRunTime(){
        return filterControlPanel.getAvailableFiltersAtRunTime();
    }

    /**
     * Method to open bip layout editor page.
     *
     */
    public void openBIPLayoutEditorPage(){
        if($(addLayoutButton).isDisplayed()) {
            $(addLayoutButton).click();
        } else {
            $(configureLayoutButton).click();
        }
        commonMethods.waitForWindowToOpen(driver, BIP_WINDOW_TITAL);
    }

    /**
     * Method to download report using API call.
     * @param userId user id
     * @param projectId projectId
     * @param reportName Name of the report.
     * @param layoutName Name of the layout.
     * @param format Format of the report
     * @return parsed report data.
     */
    public InputStream downloadReportAPI(String userId, String projectId, String reportName,String layoutName, String format){
        Map<String, Map<String,Object>> mapOfMap =  dataSetup.loadJsonDataToMap(userDataPath);
        Map<String,Object> userMap = mapOfMap.get(userId);
        Response userSession = session.login(userMap.get("username").toString(),userMap.get("password").toString());
        List<Header> headersList = new ArrayList<Header>();
        List<Cookie> cookies = new ArrayList<Cookie>();
        List<Cookie> tempCookies = new ArrayList<>();
        cookies.add(userSession.getDetailedCookie("JSESSIONID"));
        cookies.add(userSession.getDetailedCookie("ASESSIONID"));
        cookies.add(userSession.getDetailedCookie("ASDSESSIONID"));
        cookies.add(userSession.getDetailedCookie("XSRF-TOKEN"));
        tempCookies.add(userSession.getDetailedCookie("JSESSIONID"));
        tempCookies.add(userSession.getDetailedCookie("XSRF-TOKEN"));
        Response settingsResponse = reportDownloadHelper.getSettings(cookies, headersList);
        Response prepareTokenResponse = reportDownloadHelper.getToken(settingsResponse, cookies, headersList);
        String csrfToken = reportDownloadHelper.getCSRFToken(prepareTokenResponse);
        cookies.clear();
        for(Cookie c : tempCookies){
            cookies.add(c);
        }
        cookies.add(prepareTokenResponse.getDetailedCookie("jasper_session_id"));
        cookies.add(settingsResponse.getDetailedCookie("ASESSIONID"));
        cookies.add(settingsResponse.getDetailedCookie("ASDSESSIONID"));
        cookies.add(settingsResponse.getDetailedCookie("com.aconex.locale"));
        headersList.clear();
        headersList.add(new Header("X-CSRF-Token", csrfToken));
        String reportId = reportDownloadHelper.getReportId(reportName, cookies, headersList);
        String filters = reportDownloadHelper.getRunTimeFilters(reportId, cookies, headersList);
        cookies.add(userSession.getDetailedCookie("XSRF-TOKEN"));
        return reportDownloadHelper.downlodReport(reportId, layoutName, format, filters, cookies, headersList);
    }

    /**
     * Method to export report to xml using web API call.
     * @param userId user id
     * @param reportName Name of the report.
     * @return parsed report data.
     */
    public InputStream exportToXml(String userId, String reportName){
        Map<String, Map<String,Object>> mapOfMap =  dataSetup.loadJsonDataToMap(userDataPath);
        Map<String,Object> userMap = mapOfMap.get(userId);
        Response userSession = session.login(userMap.get("username").toString(),userMap.get("password").toString());
        List<Header> headersList = new ArrayList<Header>();
        List<Cookie> cookies = new ArrayList<Cookie>();
        List<Cookie> tempCookies = new ArrayList<>();
        cookies.add(userSession.getDetailedCookie("JSESSIONID"));
        cookies.add(userSession.getDetailedCookie("ASESSIONID"));
        cookies.add(userSession.getDetailedCookie("ASDSESSIONID"));
        cookies.add(userSession.getDetailedCookie("XSRF-TOKEN"));
        tempCookies.add(userSession.getDetailedCookie("JSESSIONID"));
        tempCookies.add(userSession.getDetailedCookie("XSRF-TOKEN"));
        Response settingsResponse = reportDownloadHelper.getSettings(cookies, headersList);
        Response prepareTokenResponse = reportDownloadHelper.getToken(settingsResponse, cookies, headersList);
        String csrfToken = reportDownloadHelper.getCSRFToken(prepareTokenResponse);
        cookies.clear();
        for(Cookie c : tempCookies){
            cookies.add(c);
        }
        cookies.add(prepareTokenResponse.getDetailedCookie("jasper_session_id"));
        cookies.add(settingsResponse.getDetailedCookie("ASESSIONID"));
        cookies.add(settingsResponse.getDetailedCookie("ASDSESSIONID"));
        cookies.add(settingsResponse.getDetailedCookie("com.aconex.locale"));
        headersList.clear();
        headersList.add(new Header("X-CSRF-Token", csrfToken));
        String reportId = reportDownloadHelper.getReportId(reportName, cookies, headersList);
        cookies.add(userSession.getDetailedCookie("XSRF-TOKEN"));
        Map<String, String> queryParams = new HashMap<String, String>();
        queryParams.put("fileName", reportName);
        return reportDownloadHelper.exportToXmlReport(reportId, cookies, headersList, queryParams);
    }

    /**
     * Method to download report.
     *
     * @paarm layoutName Name of the layout.
     * @param outputFormat Output format.
     */
    public void exportReport(String layoutName, String outputFormat) {
        if(!layoutName.isEmpty()){
            toolbar.selectBIPLayout(layoutName);
        }
        toolbar.selectExportFormat(outputFormat);
    }

    /**
     * Method to get custom range specific message.
     *
     * @return message
     */
    public String getCustomRangeSpecificMessage(){
        String messageDisplayed = $(customRangeMessage).waitUntil(appear, 30000).getText();
        $(customRangeMessage).waitUntil(disappear, 15000);
        return messageDisplayed;
    }

    /**
     * Method to apply filters on preview page.
     *
     */
    public void applyFilters(){
        verifyAndSwitchFrame();
        try {
            commonMethods.waitForElement(driver, filterPanel,8 );
        } catch(TimeoutException e){
            //ignore
        }
        filterControlPanel.apply();
        try {
            commonMethods.waitForElement(driver, loader, 10);
            $(loader).waitUntil(disappear, 60000);
        } catch(TimeoutException ex){
            //ignore
        }
    }

    /**
     * Method to return record count from preview page.
     *
     */
    public int getRecordCount(){
        verifyAndSwitchFrame();
        verifyAndSwitchFrame("runnerIframe");
        return $(recordsTable).findElements(By.tagName("tr")).size();
    }

    /**
     * Method to untill loader disappers.
     *
     */
    public void waitForLoaderToDisapper(){
        try {
            commonMethods.waitForElement(driver, loader, 20);
            $(loader).waitUntil(hidden, 30000);
        } catch(TimeoutException | NoSuchElementException e){
            //ignore
        }
    }
}