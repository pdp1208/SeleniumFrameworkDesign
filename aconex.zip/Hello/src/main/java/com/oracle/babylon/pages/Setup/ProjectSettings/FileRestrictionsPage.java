package com.oracle.babylon.pages.Setup.ProjectSettings;

import com.oracle.babylon.pages.Setup.ProjectSettingsPage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class FileRestrictionsPage extends ProjectSettingsPage {

    private By hdrFileRestrictions = By.xpath("//h1/span[contains(text(),'File restrictions')]");
    private By lblRestrictFiles = By.xpath("//h3[contains(text(),'Restrict files with the following strings in the f')]");
    private By txtBoxRestrictedItem = By.xpath("(//form[@name='form.fileRestrictionsForm']//div//input)[1]");
    private By sltItemType = By.xpath("(//form[@name='form.fileRestrictionsForm']//div//select)[1]");
    private String txtBoxRestrictedItems = "//form[@name='form.fileRestrictionsForm']//div//input";
    private String sltItemTypes = "//form[@name='form.fileRestrictionsForm']//div//select";
    private By btnAdd = By.xpath("//button[contains(text(),'Add')]");
    private By btnSave = By.xpath("//button[contains(text(),'Save')]");
    private By lnkRemoveItem = By.xpath("(//form[@name='form.fileRestrictionsForm']//div//a)[1]");
    private String lnkRemoveItems = "//form[@name='form.fileRestrictionsForm']//div//a";
    private By lblNoRestrictions = By.xpath("//caption[contains(text(),'No file restrictions configured')]");

    /**
     * Function to verify File Restriction options
     */
    public void verifyFileRestrictionOptions() {
        commonMethods.waitForElement(driver, btnAdd, 60);
        Assert.assertTrue($(hdrFileRestrictions).isDisplayed());
        Assert.assertTrue($(lblRestrictFiles).isDisplayed());
        commonMethods.waitForElementExplicitly(2000);
        Assert.assertTrue($(txtBoxRestrictedItem).isDisplayed());
        Assert.assertTrue($(sltItemType).isDisplayed());
        Assert.assertTrue($(btnAdd).isDisplayed());
        Assert.assertTrue($(btnSave).isDisplayed());
        Assert.assertTrue($(lnkRemoveItem).isDisplayed());
    }

    /**
     * Function to verify default restriction items added in file restriction tab
     */
    public List<String> verifyRestrictionItems(String type) {
        List<String> defaultValues = new ArrayList<>();
        commonMethods.waitForElement(driver,txtBoxRestrictedItem,60);
        List<WebElement> elements = new ArrayList<>($$(By.xpath(sltItemTypes)));
        for (int i = 0; i < elements.size(); i++) {
            if ($(elements.get(i)).getSelectedText().equalsIgnoreCase(type))
                defaultValues.add($(By.xpath("(" + txtBoxRestrictedItems + ")[" + (i + 1) + "]")).getAttribute("value"));
        }
        return defaultValues;
    }

    /**
     * Function to create new restriction
     */
    public void addRestrictedItem(String items, String type) {
        String[] values = items.split(",");
        for(String itemName: values) {
            clickAddButton();
            enterItemName(itemName);
            selectItemType(type);
        }
        $(btnSave).click();
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Method to click on Add button
     */
    public void clickAddButton() {
        commonMethods.waitForElement(driver, btnAdd, 30);
        $(btnAdd).click();
    }

    /**
     * Function to enter item name in restriction item name field
     */
    public void enterItemName(String value) {
        List<WebElement> elements = new ArrayList<>($$(By.xpath(txtBoxRestrictedItems)));
        $(By.xpath("(" + txtBoxRestrictedItems + ")[" + elements.size() + "]")).sendKeys(value);
    }

    /**
     * Function to select item type for restricted item
     */
    public void selectItemType(String type) {
        List<WebElement> elements = new ArrayList<>($$(By.xpath(sltItemTypes)));
        $(By.xpath("(" + sltItemTypes + ")[" + elements.size() + "]")).selectOption(type);
    }

    /**
     * Function to remove specific item from file restriction items
     */
    public void removeRestrictedItem(String items) {
        String[] values = items.split(",");
        commonMethods.waitForElement(driver,btnAdd,60);
        for (String itemName : values) {
            List<WebElement> elements = new ArrayList<>($$(By.xpath(txtBoxRestrictedItems)));
            for (int i = 0; i < elements.size(); i++) {
                if ($(elements.get(i)).getAttribute("value").equalsIgnoreCase(itemName)) {
                    $(By.xpath("(" + lnkRemoveItems + ")[" + (i + 1) + "]")).click();
                    break;
                }
            }
        }
        $(btnSave).click();
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Function to remove all items from file restriction items
     */
    public void removeAllRestrictedItem() {
        commonMethods.waitForElement(driver,btnAdd);
        List<WebElement> elements = new ArrayList<>($$(By.xpath(lnkRemoveItems)));
        for (int i = 0; i < elements.size(); i++) $(lnkRemoveItem).click();
        $(btnSave).click();
        commonMethods.waitForElementExplicitly(2000);
    }

    public boolean noRestrictionsConfigured() {
        return $(lblNoRestrictions).isDisplayed();
    }

}