package com.oracle.babylon.pages.Mail;

import com.codeborne.selenide.WebDriverRunner;
import com.github.javafaker.Faker;
import com.oracle.babylon.Utils.helper.CommonMethods;
import com.oracle.babylon.Utils.helper.Navigator;
import com.oracle.babylon.pages.Directory.DirectoryPage;
import com.oracle.babylon.pages.Document.DocumentPage;
import com.oracle.babylon.pages.Document.DocumentRegisterPage;
import com.oracle.babylon.pages.Document.DrawingsPage;
import com.oracle.babylon.pages.Document.TemporaryFilesPage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Selenide.*;

/**
 * Function that contains the methods related to Compose Mail
 * Author : vsinghsi
 */
public class ComposeMailPage extends MailPage {

    //Initializing the objects and assigning references to it
    public ComposeMailPage() {
        this.driver = WebDriverRunner.getWebDriver();
    }

    private DocumentPage documentPage = new DocumentPage();
    private DrawingsPage drawingsPage = new DrawingsPage();
    private TemporaryFilesPage temporaryFilesPage = new TemporaryFilesPage();
    DocumentRegisterPage documentRegisterPage = new DocumentRegisterPage();
    //Initializing the Web Elements

    private By to_mailId = By.xpath("//input[@name='SPEED_ADDRESS_TO']");
    private By sendBtn = By.xpath("//button[@id='btnSend']");
    private By clearAllLink = By.xpath("//div[@class='clear-all-container']//a[contains(.,'Clear All')]");
    private By loadingIcon = By.cssSelector(".loading_progress");
    private By searchBtn = By.xpath("//button[@title='Search']");
    private By attachBtn = By.xpath("//button[@id='btnMailAttachments']//div[@class='uiButton-label'][contains(text(),'Attach')]");
    private By option = By.xpath("//div[contains(text(),'Options')]");
    private By manualMailNumber = By.xpath("//input[@id='radSpecifyMailNoManually']");
    private By autoNumbering = By.xpath("//input[@id='radAutoMailNo']");
    private By saveToDraftBtn = By.xpath("//div[contains(text(),'Save To Draft')]");
    private By attachmentContainer = By.xpath("//td[@id='corrAttachmentsContainer']");
    private By myMailOnlyChkBox = By.xpath("//span[contains(text(),'My mail only')]//././../input");
    private By mailSubject = By.xpath("//input[@id='Correspondence_subject']");
    private By selectUser = By.xpath("//table[@id='resultTable']//tbody//tr[1]//input[@name='USERS_LIST']");
    private By directory = By.xpath("//body/div[@id='page']/form[@id='form1']/div[@id='main']/div[@id='mockdoc']/div[@class='box']/table[@id='heroSection']/tbody//tr[1]//button[1]//div[1]//div[1]");
    private By docContainer = By.xpath("//td[@id='corrAttachmentsContainer']");
    String userFilePath = configFileReader.getUserDataPath();
    private By documentNumber = By.xpath("//input[@id='Correspondence_documentNo']");
    private By okBtn = By.xpath("//button[@id='btnOptionsOk']//div[@class='uiButton-label'][contains(text(),'OK')]");
    private By attachFile = By.xpath("//div[contains(text(),'Attach File')]");
    private By selectFirstFile = By.xpath("//div[@class='ag-pinned-left-cols-container']/div/div[1]/div/span");
    private By openFullSearch = By.xpath("//div[contains(text(),'Open Full Search Page')]");
    private By attachDocFromDropDown = By.xpath("//a[contains(text(),'Document')]");
    private By reasonForIssue = By.xpath("//label[text()='Reason for Issue']");
    private DirectoryPage directoryPage = new DirectoryPage();
    private By directoryPageTitle = By.xpath("//h1[text()='Search - Directory']");
    private By confidentialChkBox = By.xpath("//input[@id='Correspondence_confidentialFlag']");
    private By resetReference = By.xpath("//input[@id='Correspondence_resetInRefTo']");
    private By errorMessage = By.xpath("//li[@class='message warning']");
    private By mailBodyFrame = By.xpath("//iframe[@class='cke_wysiwyg_frame cke_reset']");
    private By attachBtnOnMailPanel = By.xpath("//div[@id='attachOnNewPanel_buttons']//button[@id='btnAttach_page' and contains(.,'Attach')]");
    private By cancelBtnOnMailPanel = By.xpath("//button[@id='btnattachOnNewPanel_cancel']");
    private By onPanelAttachBtn = By.xpath("//div[@id='attachOnNewPanel_buttons']//div[@class='uiButton-label'][contains(text(),'Attach')]");
    private By previewBtn = By.xpath("//div[contains(text(),'Preview')]");
    private By projectMail = By.xpath("//a[contains(text(),'Project Mail')]");
    private By localFile = By.xpath("//a[contains(text(),'Local File')]");
    private By viewUnreadMail = By.xpath("//label[@id='show-unread-only']//input");
    private By sentTo = By.xpath("//a[text()='Sent To']//..//..//..//div[text()='Directory']");
    private By cc = By.xpath("//a[text()='Cc']//..//..//..//div[text()='Directory']");
    private By Bcc = By.xpath("//table[@id='heroSection']//tr[1]//button[1]");
    private By to = By.xpath("//a[text()='To']//..//..//..//div[text()='Directory']");
    private By sentFrom = By.xpath("//a[text()='Sent From']//..//..//..//div[text()='Directory']");
    private By sendPublicBtn = By.xpath("//button[contains(.,'Send As Public')]");
    private By ccBinIcon = By.xpath("//table[@id='recipientList_CC']//td//div[@class='auiIcon trash remove']");
    private By bccBinIcon = By.xpath("//table[@id='recipientList_BCC']//td//div[@class='auiIcon trash remove']");
    private By missingFields = By.xpath("//div[contains(text(),'There was a problem with one or more of your entries. Please revise the highlighted fields and try again')]");
    private By resultTable = By.xpath("//table//tbody");
    private By sentTab = By.xpath("//div[@class='center-content']//a[contains(text(),'Sent')]");
    private By inboxTab = By.xpath("//div[@class='center-content']//a[contains(text(),'Inbox')]");
    private By formId = By.xpath("//form[@id='form1']");
    private By toRecipient = By.xpath("//a[contains(text(),'To')]");
    String docFilePath = configFileReader.getDocumentDataPath();
    protected Map<String, Object> docMap = null;
    private By mailAttachment = By.xpath("//div[@id='fldAttachments']");
    private By mailForm = By.xpath("//form[@id='form1']");
    private By autoText = By.xpath("//div[@class='editorExtraTools']//select[1]");
    private By signatureSelect = By.xpath("//div[@class='editorExtraTools']//select[@id='SignatureSelector']");
    private By reasonForIssueDropDown = By.xpath("//select[@id='Correspondence_correspondenceReasonID']//option");
    private By confidentialHeader = By.xpath("//span[contains(text(),'(Confidential)')]");
    private By responseRequired = By.xpath("//div[@class='responseRequired']//select");
    private By attributeList = By.xpath("//div[@class='uiBidi-left']//select//option");
    private By mailTypes = By.xpath("//select[@id='Correspondence_correspondenceTypeID']//option");
    private By recipientTo = By.xpath("//div[@id='recipientsTO']");
    private By recipientCc = By.xpath("//div[@id='recipientsCC']");
    private By recipientBcc = By.xpath("//div[@id='recipientsBCC']");
    private By ccLink = By.xpath("//a[contains(.,'Cc')]");
    private By attachmentRemovedMsg = By.xpath("//div[contains(text(),'The following attachments have been removed')]");
    private By attachmentRemovedOkBtn = By.xpath("//button[@id='btnconfirmPanel_ok']//div[contains(text(),'OK')]");
    private By attachmentRemovedSuccessMsg = By.xpath("//ul[@class='messagePanel']//div[contains(text(),'The following attachments have been removed from the transmittal as they are not in your document register:')]");
    private By noAttachment = By.xpath("//td[@id='corrAttachmentsContainer']//table[@class='dataTable']//td");
    private By errorMailType = By.xpath("//div[contains(text(),'Sorry, that mail type is no longer available. Please choose another one.')]");
    private By infoMailRule = By.xpath("//div[@id='mailRuleIndicator']");
    private By lblDistributionRule = By.xpath("//span[contains(text(),'Distribution rules apply to this mail type.')]");
    private By lnkPreview = By.xpath("//a[contains(text(),'Preview')]");
    private By lblRestricted = By.xpath("//div[@id='restrictedFieldsSection']/div[contains(text(),'Restricted')]");
    private By restrictedFieldNames = By.xpath("//div[@id='restrictedFieldsSection']//table//tr[@class='mailMetaRow']/td/label");
    private By tabRestrictedFields = By.xpath("//div[@id='restrictedFieldsSection']");
    private By mailBodyField = By.xpath("//textarea[@class='auiField-input']");
    private By mailBodyNewField = By.cssSelector(".ck-editor__editable.ck-editor__editable_inline");
    private By detailsTestField = By.xpath("//select[starts-with(@id,'_mailForm_')]");
    private By attchmentViewOrder = By.xpath("//tr[@class='dataHeaders']/th[@class='tight']/following::th");

    private By restrictionBanner = By.xpath("//span[contains(text(),'Recipients are determined by Distribution Rules and cannot be modified for this mail type.')]");
    protected By attachmentsView = By.xpath("//*[@id='corrAttachmentsContainer']//select");
    Navigator navigator = new Navigator();
    public static List<String> attachmentView = new LinkedList<>();

    /**
     * Function to navigate to a sub menu from the Aconex home page
     */
    public void navigateAndVerifyPage() {
        $(loadingIcon).should(disappear);
        getMenuSubmenu("Mail", "Blank Mail");
        $(loadingIcon).should(disappear);
        Assert.assertTrue("Blank Mail Page title is not displayed", verifyPageTitle("New Mail"));
    }

    /**
     * Function to navigate to a Your commonly used mail types sub menu under mails tab by passiing mailtype parameter
     *
     * @param mailType
     */
    public void navigateAndVerifyPage(String mailType) {
        $(loadingIcon).should(disappear);
        getMenuSubmenu("Mail", mailType);
        $(loadingIcon).should(disappear);
        Assert.assertTrue(verifyPageTitle("New Mail"));
    }

    /**
     * Function used to compose the mail.
     *
     * @param data
     */
    public void composeMail(String data) {
        //Fetch the table from the data store
        switchTo().defaultContent();
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(3000);
        composeAMail(data);
    }

    /**
     * Function used to compose the mail.
     *
     * @param
     * @param data
     */
    public void composeAMail(String data) {
        //Fetch the table from the data store
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, mailSubject, 60);
        Map<String, String> table = dataStore.getTable(data);
        //According to the keys passed in the table, we select the fields
        for (String tableData : table.keySet()) {
            switch (tableData) {
                case "To":
                case "Cc":
                case "Bcc":
                case "Sent From":
                case "Sent To":
                    String[] namesList = table.get(tableData).split(",");
                    for (String name : namesList) {
                        addRecipient(tableData, name);
                    }
                    break;
                case "Mail Type":
                    selectMailType(table.get(tableData));
                    $(loadingIcon).should(disappear);
                    if ($(reasonForIssue).isDisplayed()) selectReasonForIssue();
                    break;
                case "Subject":
                    if (table.get(tableData).contains("unique".toLowerCase())) {
                        commonMethods.waitForElementExplicitly(2500);
                        String[] subjectArray = table.get(tableData).split(",");
                        Date dt = new Date();
                        DateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
                        String subject = subjectArray[0] + " " + formatter.format(dt);
                        fillInSubject(subject);
                        commonMethods.setMailNumInJson(subjectArray[1], subject);
                    } else {
                        fillInSubject(table.get(tableData));
                    }
                    break;
                case "Attribute 1":
                    selectMailAttribute("Attribute 1", table.get(tableData));
                    break;
                case "Attribute 2":
                    selectMailAttribute("Attribute 2", table.get(tableData));
                    break;
                case "Attribute 3":
                    selectMailAttribute("Attribute 3", table.get(tableData));
                    break;
                case "Attribute 4":
                    selectMailAttribute("Attribute 4", table.get(tableData));
                    break;
                case "Response Required":
                    selectResponseRequired(table.get(tableData));
                    break;
                case "Mail Body":
                    setMailBody(table.get(tableData));
                    break;
                case "Attachment":
                    attachDocument(table.get(tableData));
                    break;
                case "Auto Text":
                    selectAutoText(commonMethods.getMailNumFromJson(table.get(tableData)));
                    break;
                case "Signature":
                    sleep(2000);
                    selectSignature(commonMethods.getMailNumFromJson(table.get(tableData)));
                    sleep(2000);
                    break;
                case "Attachment From JSON":
                case "Attachment From JSON1":
                case "Attachment From JSON2":
                    jsonMapOfMap = dataSetup.loadJsonDataToMap(docFilePath);
                    String[] doc = table.get(tableData).split(",");
                    docMap = jsonMapOfMap.get(doc[0]);
                    String docNum = docMap.get("doc_num").toString();
                    if (doc.length > 1) {
                        verifyAndSwitchFrame();
                        attachDocument(docNum, doc[1]);
                    } else {
                        attachDocument(docNum);
                    }
                    break;
                case "Confidential":
                    selectConfidential();
                    break;
                case "Reset Reference":
                    selectResetReference();
                    break;
                case "Attach Documents":
                    List<String> documents = Arrays.asList(table.get(tableData).split(","));
                    for(String document : documents)
                        attachDocument(commonMethods.returnDocNumberInJson(document));
                    break;
                default:
                    if (tableData.toLowerCase().contains("project fields"))
                        selectProjectFieldValues(table.get(tableData));
                    break;
            }
        }
        commonMethods.waitForElementExplicitly(2000);
       // if ($(reasonForIssue).isDisplayed()) selectReasonForIssue();
        if (table.containsKey("Reason for Issue")) selectReasonForIssue(table.get("Reason for Issue"));
        verifyAndSwitchFrame();
        if ($(detailsTestField).isDisplayed()) $(detailsTestField).selectOption(1);
        driver.switchTo().defaultContent();
    }


    /**
     * Function to select reset reference number in compose mail option
     */
    public void selectResetReference() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, option, 15);
        sleep(1000);
        $(option).click();
        $(resetReference).click();
        $(okBtn).click();
    }

    /**
     * Function to Select confidential
     */
    public void selectConfidential() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, option, 15);
        sleep(1000);
        $(option).click();
        $(confidentialChkBox).click();
        commonMethods.waitForElementExplicitly(2000);
        $(okBtn).click();

    }

    /**
     * Function to Add Recipient for Mail
     *
     * @param group
     * @param name
     */
    public void addRecipient(String group, String name) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userFilePath);
        userMap = jsonMapOfMap.get(name);
        //String user = userMap.get("full_name").toString();
        By directoryBtn;
        if (group.equals("Sent From")) {
            directoryBtn = sentFrom;
        } else if (group.equals("Sent To")) {
            directoryBtn = sentTo;
        } else if (group.equals("Cc")) {
            directoryBtn = cc;
        } else if (group.equals("Bcc")) {
            directoryBtn = Bcc;
        } else {
            directoryBtn = to;
        }
        commonMethods.waitForPageLoad(driver);
        commonMethods.waitForElementExplicitly(6000);
        verifyAndSwitchFrame();
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,-250)");
        try {
            commonMethods.waitForElement(driver, directoryBtn, 40);
            Actions actions = new Actions(driver);
            sleep(1000);
            actions.moveToElement($(directoryBtn)).click().perform();
        } catch (TimeoutException e) {
            commonMethods.waitForElement(driver, ccLink, 30);
            sleep(2000);
            $(ccLink).click();
        }
        $(loadingIcon).should(disappear);
        if (directoryBtn.equals(sentTo)) {
            directoryPage.addRecipientUnderProject(group, userMap);
        } else {
            commonMethods.waitForElementExplicitly(3000);
            if ($(directoryBtn).isDisplayed()) {
                jse = (JavascriptExecutor) driver;
                jse.executeScript("window.scrollBy(0,-250)");
                $(directoryBtn).click();
            }
            directoryPage.addRecipient(group, userMap);
        }
        commonMethods.waitForElement(driver, mailSubject, 15);
    }

    /**
     * Enter the subject required while composing the mail
     *
     * @param subject to be entered
     */
    public void fillInSubject(String subject) {
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, mailSubject, 30);
        commonMethods.enterTextValue(mailSubject, subject);
    }

    /**
     * Enter the mail body by switching the frame
     *
     * @param mailBody
     */
	public void setMailBody(String mailBody) {
		if ($(mailBodyFrame).exists()) {
			switchTo().frame($(mailBodyFrame));
			$(By.xpath("//body")).clear();
			$(By.xpath("//body")).sendKeys(mailBody);
		} else if ($(mailBodyNewField).exists()) {
			commonMethods.waitForElementExplicitly(2000);
			commonMethods.waitForElement(driver, mailBodyNewField, 20);
			$(mailBodyNewField).clear();
			$(mailBodyNewField).sendKeys(mailBody);
		} else {
			commonMethods.waitForElementExplicitly(2000);
			commonMethods.waitForElement(driver, mailBodyField, 20);
			$(mailBodyField).clear();
			$(mailBodyField).sendKeys(mailBody);
		}
	}

    /**
     * Switch the mail body frame
     */
    public void switchToMailBodyFrame() {
        switchTo().defaultContent();
        switchTo().frame("frameMain");
    }

    /**
     * Enter to user list to send the mail to
     *
     * @param userTo string of users that we want to send the mail to
     */
    public void fillTo(String userTo) {
        addRecipient("To", userTo);
    }

    public String userDefinedMailNumber() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, option, 15);
        sleep(1000);
        $(option).click();
        Faker faker = new Faker();
        Map<String, String> userDetail = new HashMap<>();
        String mail = "Draft-" + faker.number().digits(6) + "d" + faker.number().digits(2);
        ComposeMailPage.draftMailNumber = mail;
        ComposeMailPage.mailNumber = ComposeMailPage.draftMailNumber;
        WebElement checkBox = driver.findElement(manualMailNumber);
        if (checkBox.isSelected()) {
            $(documentNumber).sendKeys(mail);
        } else {
            checkBox.click();
            $(documentNumber).sendKeys(mail);
        }
        $(okBtn).click();
        return mail;
    }


    /**
     * Function to select auto mail numbering while mail composing
     */
    public void mailAutoNumbering() {
        verifyAndSwitchFrame();
        sleep(1000);
        $(option).click();
        WebElement checkBox = driver.findElement(autoNumbering);
        if (!checkBox.isSelected()) {
            checkBox.click();
        }
        $(okBtn).click();
    }

    /**
     * Function to use user defined mail number
     *
     * @param mailNumber to be used
     */

    public void userDefinedMailNumber(String mailNumber) {
        verifyAndSwitchFrame();
        sleep(1000);
        $(option).click();
        WebElement checkBox = driver.findElement(manualMailNumber);
        if (!checkBox.isSelected()) {
            checkBox.click();
        }
        $(documentNumber).sendKeys(mailNumber);
        $(okBtn).click();

    }

    /**
     * Function to Save Mail to Draft
     */
    public void saveToDraft() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, saveToDraftBtn, 40);
        $(saveToDraftBtn).click();
    }

    /**
     * Function to Attach a Document
     *
     * @param documentDetail
     */
    public void attachDocument(String documentDetail) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, attachBtn, 10);
        sleep(1000);
        $(attachBtn).click();
        String text = getDocumentMenuName();
        verifyAndSwitchFrame();
        By documentLink = By.xpath("//a[contains(text(),'" + text.substring(0, text.length() - 1) + "')]"); //docMap.get("attachbutton")
        commonMethods.waitForElement(driver, documentLink, 15);
        $(documentLink).click();
        commonMethods.waitForElementExplicitly(2000);
        documentPage.attachDocument(documentDetail);
        verifyAndSwitchFrame();
        getElementInView(attachmentContainer);
        commonMethods.waitForElement(driver, attachmentContainer, 40);
    }

    public void attachDocument(String documentDetail, String revision) {
        commonMethods.waitForElement(driver, attachBtn);
        $(attachBtn).click();
        $(attachDocFromDropDown).click();
        commonMethods.waitForElementExplicitly(2000);
        documentPage.attachDocument(documentDetail, revision);
        commonMethods.waitForElement(driver, attachmentContainer);
    }

    /**
     * Function to Remover User from Mailing List
     *
     * @param group
     * @param user
     */
    public void removeUserFromMailingList(String group, String user) {
        verifyAndSwitchFrame();
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userFilePath);
        userMap = jsonMapOfMap.get(user);
        String userToRemove = userMap.get("full_name").toString();
        verifyAndSwitchFrame();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,-document.body.scrollHeight)", "");
        commonMethods.waitForElementExplicitly(3000);
        switch (group.toLowerCase()) {
            case "to":
                commonMethods.waitForElementExplicitly(3000);
                $(By.xpath("//div[@id='recipientsTO']//tr[contains(., '" + userToRemove + "')]//td[3]/div")).click();
                break;
            case "cc":
                commonMethods.waitForElementExplicitly(3000);
                $(By.xpath("//div[@id='recipientsCC']//tr[contains(., '" + userToRemove + " ')]//td[3]/div")).click();
                break;
            case "bcc":
                commonMethods.waitForElementExplicitly(3000);
                $(By.xpath("//div[@id='recipientsBCC']//tr[contains(., '" + userToRemove + " ')]//td[3]/div")).click();
                break;
        }
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Function to click on preview Mail
     */
    public void previewMail() {
        commonMethods.waitForElementExplicitly(3000);
        verifyAndSwitchFrame();
        $(previewBtn).click();
    }

    /**
     * Function to verify validate  message for Associated files
     */
    public void verifyValidationMessage() {
        commonMethods.waitForElement(driver, docContainer);
        String message = $(docContainer).text();
        Assert.assertTrue(message.contains("This attachment has no associated file"));
    }

    /**
     * Function to change Mail type
     *
     * @param mailType
     */
    public void changeMailType(String mailType) {
        selectMailType(mailType);
    }

    /**
     * Function to remove document
     *
     * @param document
     */
    public void removeDocument(String document) {
        commonMethods.waitForElementExplicitly(3000);
        verifyAndSwitchFrame();
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(document.body.scrollHeight, 0)");
        commonMethods.waitForElementExplicitly(3000);
        List<WebElement> listOfColumns = driver.findElements(By.xpath("//td[@id='corrAttachmentsContainer']//tr[1]//td"));
        int bin = listOfColumns.size();
        By binIcon = By.xpath("//td[@id='corrAttachmentsContainer']//tr[contains(., '" + document + "')]//td[" + bin + "]//div");
        commonMethods.waitForElement(driver, binIcon, 10);
        $(binIcon).click();
        commonMethods.waitForElementExplicitly(3000);
    }

    /**
     * function for Mandatory Fields error message  for Mails
     *
     * @return
     */
    public String mandatoryFieldError() {
        return $(errorMessage).text();
    }

    /**
     * Function to click on Attach
     */
    public void clickAttach() {
        commonMethods.waitForElement(driver, attachBtn, 50);
        $(attachBtn).click();
    }

    /**
     * Function to  verify the error msg when No Document is attached
     */
    public void verifyNoDocAttachedError(String errMsg) {
        verifyAlert(errMsg);
    }

    /**
     * Function to click on projectMail
     */
    public void clickProjectMail() {
        verifyAndSwitchFrame();
        $(projectMail).click();
    }

    /**
     * Function to click on Local File link
     */
    public void clickLocalFile() {
        $(localFile).click();
    }

    /**
     * Function to click on panel Attach button
     */
    public void clickOnPanelAttachBtn() {
        switchTo().defaultContent();
        verifyAndSwitchFrame();
        $(onPanelAttachBtn).click();
    }

    /**
     * Function to Add Mail Attributes
     *
     * @param attributeId
     * @param listOfAttributes
     */

    public void addAttributes(String attributeId, String listOfAttributes) {
        selectMailAttribute(attributeId, listOfAttributes);
    }


    /**
     * Function to verify alert text while downloading document before saving it to draft
     *
     * @param document name
     */

    public void verifyDocumentDownloadPopUp(String document) {
        verifyAndSwitchFrame();
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(document.body.scrollHeight, 0)");
        commonMethods.waitForElementExplicitly(3000);
        $(By.xpath("//table//tbody//tr/td[@id='corrAttachmentsContainer']//td[contains(text(), '" + document + "')]//..//a")).click();
        commonMethods.waitForElementExplicitly(1000);
        Assert.assertTrue(driver.switchTo().alert().getText().contains("Please click Preview before attempting to download attachments."));
    }

    /**
     * Function to delete recipients cc and bcc
     */

    public void clickBinIcon() {
        verifyAndSwitchFrame();
        Actions actions = new Actions(driver);
        actions.moveToElement($(ccBinIcon)).build().perform();
        $(ccBinIcon).click();
        $(bccBinIcon).click();
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Function to verify the missing fields when sending mail
     */

    public boolean verifyMissingFieldsMessage() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, missingFields, 10);
        return $(missingFields).isDisplayed();
    }

    /**
     * Method to clear subject
     */
    public void clearSubject() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, mailSubject, 5);
        $(mailSubject).clear();
    }

    /**
     * Function to click Mail Options
     */

    public void clickMailOption(String option) {
        By by = By.xpath("//a[contains(text(),'" + option + "')]");
        commonMethods.waitForElement(driver, by, 30);
        $(by).click();
//        $(By.xpath("//a[contains(text(),'" + option + "')]")).click();
    }

    /**
     * Function to verify Mail Option
     *
     * @return
     */

    public boolean verifyOption(String option) {
        commonMethods.waitForElementExplicitly(2500);
        return $(By.xpath("//button//div[contains(text(),'" + option + "')]")).isDisplayed();
    }


    /**
     * Function to clear search on mail page
     */
    public void clearAll() {
        commonMethods.waitForElement(driver, clearAllLink, 5);
        $(clearAllLink).click();
    }

    public void selectRecipientTypeOnPanel(String type, int num) {
        switchToMailAttachPanel();
        switch (type.toLowerCase()) {
            case "to":
                $(By.xpath("//div[@class='ng-isolate-scope']//label[" + num + "]//input[1]")).setSelected(true);
                break;
            case "cc":
                $(By.xpath("//div[@class='ng-isolate-scope']//label[" + num + "]//input[1]")).setSelected(true);
                break;
            case "any":
                $(By.xpath("//div[@class='ng-isolate-scope']//label[" + num + "]//input[1]")).setSelected(true);
                break;
        }
    }

    /**
     * Function to select unread mail checkbox
     */

    public void viewUnreadMail() {
        switchToMailAttachPanel();
        commonMethods.waitForElement(driver, viewUnreadMail);
        $(viewUnreadMail).click();
    }


    /**
     * Function to click search button on mail search page
     */
    public void clickSearch() {
        switchToMailAttachPanel();
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", $(searchBtn));
        $(searchBtn).click();
    }

    /**
     * Function to search mails by the mail number search key
     *
     * @param mail_number
     */
    public void searchMailNumber(String mail_number) {
        switchToMailAttachPanel();
        commonMethods.waitForElement(driver, mailNoTextBox, 10);
        $(mailNoTextBox).clear();
        $(mailNoTextBox).sendKeys(mail_number);
        $(mailNoTextBox).pressTab();
        $(mailNoTextBox).pressEnter();
        commonMethods.waitForElementExplicitly(1000);
        $(searchBtn).doubleClick();
        $(loadingIcon).should(disappear);
    }

    public void verifyMailPresent(String mailNumber) {
        switchToMailAttachPanel();
        commonMethods.waitForElement(driver, resultTable, 20);
        Assert.assertTrue($(resultTable).text().contains(mailNumber));
    }

    /**
     * Function to select mail on mail attach panel
     *
     * @param mailNumber
     */
    public void selectMail(String mailNumber) {
        switchToMailAttachPanel();
        $(By.xpath("//table//tbody//tr[contains(.,'" + mailNumber + "')]//td[1]//input")).click();
    }

    /**
     * Function to click attach button on mail attach panel
     */
    public void clickAttachOnMail() {
        switchTo().defaultContent();
        verifyAndSwitchFrame();
        $(attachBtnOnMailPanel).click();
    }

    /**
     * Function to click cancel button on mail attach panel
     */
    public void clickCancelOnMail() {
        switchTo().defaultContent();
        verifyAndSwitchFrame();
        $(cancelBtnOnMailPanel).click();
    }


    /**
     * Function to get mail count on mail tab
     */
    public int getMailCountOnAttachPanel() {
        switchToMailAttachPanel();
        String count = $(mailCount).text();
        return Integer.parseInt(count.substring(count.lastIndexOf(" ") + 1));
    }


    /**
     * Function to select mails to attach
     *
     * @param numberOfMail
     */
    public ArrayList<String> selectMailToAttach(int numberOfMail) {
        switchToMailAttachPanel();
        ArrayList<String> selectedMailList = new ArrayList<>();
        for (int i = 1; i <= numberOfMail; i++) {
            $(By.xpath("//tbody//tr[" + i + "]//td[1]//input")).setSelected(true);
            selectedMailList.add($(By.xpath("//tbody//tr[" + i + "]//td[@class='column_documentNo']/span")).text());
        }
        return selectedMailList;
    }

    /**
     * Function to get text of attachment in parent mail
     */
    public String getAttachment() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, mailAttachment, 5);
        return $(mailAttachment).text();
    }

    /**
     * Function to select auto text option
     *
     * @param autoTextName
     */
    public void selectAutoText(String autoTextName) {
        verifyAndSwitchFrame();
        $(autoText).selectOptionContainingText(autoTextName);
    }

    /**
     * Function to get mail Body text
     */

    public String getMailBody() {
        verifyAndSwitchFrame();
        if (!configFileReader.getApplicationUrl().contains("qa123")) {
            switchTo().frame($(mailBodyFrame));
            commonMethods.waitForElement(driver, By.xpath("//body"), 10);
            sleep(2000);
            return $(By.xpath("//body")).text();
        }
        return null;
    }

    /**
     * Function to verify availability of auto text option
     *
     * @param name
     */
    public boolean verifyAutoTextOption(String name) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, autoText, 10);
        return $(By.xpath("//div[@class='editorExtraTools']//select[1]//option[contains(.,'" + name + "')]")).exists();
    }

    /**
     * Function to select auto signature text option
     *
     * @param signatureName
     */
    public void selectSignature(String signatureName) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, signatureSelect, 20);
        $(signatureSelect).selectOptionContainingText(signatureName);
    }

    /**
     * Function to verify availability of auto signature option
     *
     * @param name
     */
    public boolean verifySignatureOption(String name) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, signatureSelect, 10);
        return $(By.xpath("//div[@class='editorExtraTools']//select[@id='SignatureSelector']//option[contains(.,'" + name + "')]")).exists();

    }

    /**
     * Function to get List of reason for issue present in dropdown
     */
    public List<String> getReasonForIssueOption() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, reasonForIssueDropDown, 45);
        $(reasonForIssueDropDown).getText();
        List<WebElement> optionElement = driver.findElements(reasonForIssueDropDown);
        List<String> options = new ArrayList<>();
        for (WebElement e : optionElement) {
            if (!e.getText().contains("<Select>")) options.add(e.getText().trim());
        }
        return options;
    }

    /**
     * Method to check select to as mail recipient
     */
    public boolean verifyButtonPresent(String buttonName) {
        verifyAndSwitchFrame();
        return $(By.xpath("//div[@class='clearFloats noprint auiToolbar']//div[contains(text(),'" + buttonName + "')]")).isDisplayed();
    }


    /**
     * Method to verify Response Required field
     *
     * @return
     */

    public boolean verifyResponseRequired() {
        return $(responseRequired).isDisplayed();
    }


    /**
     * Method to verify subject field
     *
     * @return
     */

    public boolean verifySubjectPresent() {
        return $(mailSubject).isDisplayed();
    }


    /**
     * Function to verify confidential header
     *
     * @return
     */

    public boolean verifyConfidentialHeader() {
        verifyAndSwitchFrame();
        return $(confidentialHeader).isDisplayed();
    }

    /**
     * Method to get all attribute values from multi select field
     */
    public List<String> getAttributeList(String name) {
        commonMethods.waitForElementExplicitly(1000);
        //$(By.xpath("//label[contains(text(),'" + name + "')]//..//..//td//div[@title='Edit Attributes']")).click();
        return commonMethods.getValues(By.xpath("//span[contains(text(),'Available " + name + "')]//../following-sibling::select/option"));
    }

    /**
     * Method to click on attribute values from multi select field
     */
    public void clickAttributeList(String name) {
        By xpath = By.xpath("//label[contains(text(),'" + name + "')]//..//..//td//div[contains(@class,'uiMultiSelectField')]");
        commonMethods.waitForElement(driver, xpath);
        $(xpath).click();
    }

    /**
     * Function to verify Attribute List with the list present in preference page
     *
     * @param attributes
     * @param attributesList
     */

    public void verifyAttributeList(List<String> attributes, List<String> attributesList) {
        for (String text : attributes) {
            Assert.assertTrue(attributesList.contains(text));
        }
    }

    /**
     * Function to verify whether labels are marked as Mandatory
     *
     * @param labelName
     */

    public boolean checkMandatoryLabel(String labelName) {
        try {
            verifyAndSwitchFrame();
            By label = By.xpath("//label[contains(text(),'" + labelName + "')]//span[@class='required']");
            commonMethods.waitForElement(driver, label, 20);
            return $(label).isDisplayed();
        } catch (TimeoutException e) {
            System.out.println("element not present");
            return false;
        }
    }

    /**
     * Function to get all Mail Types present
     *
     * @return
     */

    public List<String> getMailTypes() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, mailTypes, 30);
        List<String> allMailTypes = new ArrayList<>();
        List<WebElement> types = driver.findElements(mailTypes);
        commonMethods.waitForElementExplicitly(2000);
        for (WebElement e : types) {
            allMailTypes.add(e.getText());
        }
        return allMailTypes;
    }

    /**
     * Function to verify mail Types present
     *
     * @param types
     */

    public void verifyMailTypes(List<String> types) {
        List<String> allMailTypes = getMailTypes();
        for (int i = 1; i < allMailTypes.size(); i++) {
            Assert.assertTrue(types.contains(allMailTypes.get(i)));
        }
    }

    /**
     * Function to verify Mail Options To, cc and bcc
     */

    public boolean verifyMailOptions(String option) {
        return $(By.xpath("//a[contains(text(),'" + option + "')]")).isDisplayed();
    }

    /**
     * Function to wait and check Mail Option (Ex:To) is Hidden
     */

    public void waitForMailOptionToHide(String option) {
        commonMethods.waitForElementHidden(driver, By.xpath("//a[contains(text(),'" + option + "')]"));
    }

    /**
     * Function to verify Recipients in Directory
     *
     * @param option
     * @param user
     * @return
     */

    public boolean verifyDirectoryResults(String option, String user) {
        $(By.xpath("//a[text()='" + option + "']//..//..//..//div[text()='Directory']")).click();
        directoryPage.globalDirectorySearch(user);
        return directoryPage.verifyEmptyRecords();
    }

    /**
     * Function to verify the Recipients added
     *
     * @param attributes
     */

    public void verifyUserAdded(String attributes) {
        verifyAndSwitchFrame();
        switchTo().defaultContent();
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, mailForm, 30);
        Map<String, String> table = dataStore.getTable(attributes);
        //According to the keys passed in the table, we select the fields
        for (String tableData : table.keySet()) {
            switch (tableData) {
                case "To":
                    String[] namesList = table.get(tableData).split(",");
                    for (String name : namesList) {
                        Assert.assertTrue($(recipientTo).text().contains(commonMethods.getUserData(name, "name")));
                    }
                    break;
                case "Cc":
                    String[] namesListcc = table.get(tableData).split(",");
                    for (String name : namesListcc) {
                        Assert.assertTrue($(recipientCc).text().contains(commonMethods.getUserData(name, "name")));
                    }
                    break;
                case "Bcc":
                    String[] namesListbcc = table.get(tableData).split(",");
                    for (String name : namesListbcc) {
                        Assert.assertTrue($(recipientBcc).text().contains(commonMethods.getUserData(name, "name")));
                    }
                    break;
            }
        }
    }

    /**
     * Function to click on the Directory button of Mail Recipient
     *
     * @param option
     */

    public void clickDirectory(String option) {
        verifyAndSwitchFrame();
        By mailOption = By.xpath("//a[text()='" + option + "']//..//..//..//div[text()='Directory']");
        try {
            commonMethods.waitForElement(driver, mailOption, 40);
            Actions actions = new Actions(driver);
            sleep(1000);
            actions.moveToElement($(mailOption)).click().perform();
        } catch (TimeoutException e) {
            commonMethods.waitForElement(driver, mailOption, 30);
            sleep(2000);
            $(mailOption).click();
        }
    }


    /**
     * Function to click Document Link of Attach Button
     */

    public void clickDocumentLink() {
        HashMap<String, String> docMap = CommonMethods.getDocumentTypeDetail(getDocumentMenuName());
        By documentLink = By.xpath("//a[contains(text(),'" + docMap.get("supersedebutton").substring(0, docMap.get("supersedebutton").length() - 1) + "')]");
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, documentLink, 30);
        $(documentLink).click();

    }


    /**
     * Function to get the Element In view for attaching Document
     */

    public void getAttachmentContainer() {
        getElementInView(attachmentContainer);
        commonMethods.waitForElement(driver, attachmentContainer, 40);
    }

    /**
     * Function to verify the error message when Mail Type is changed and has
     * attachment from temp and local files.
     */

    public void verifyAttachmentRemoved() {
        verifyAndSwitchFrame();
        Assert.assertTrue($(attachmentRemovedMsg).isDisplayed());
        $(attachmentRemovedOkBtn).click();
        commonMethods.waitForElement(driver, attachmentRemovedSuccessMsg, 35);
        Assert.assertTrue($(attachmentRemovedSuccessMsg).isDisplayed());
    }

    /**
     * Function to verify whether any attachment is present or not
     *
     * @return
     */

    public boolean verifyNoAttachment() {
        verifyAndSwitchFrame();
        return $(noAttachment).isDisplayed();
    }

    /**
     * Method to fill the field for the project field created
     *
     * @param label name of the project field
     */
    public void fillProjectField(String label) {
        Faker faker = new Faker();
        By by = By.xpath("//input[contains(@name,'" + label + "')]");
        if ($(by).getAttribute("type").equalsIgnoreCase("text")) {
            $(by).sendKeys(faker.color().name());
        }
    }

    /**
     * Method to verify error banner for mail type is displayed
     */
    public boolean assertMailTypeError() {
        verifyAndSwitchFrame();
        return $(errorMailType).isDisplayed();
    }

    /**
     * Method to assert info banner
     */
    public void assertInfoBanner(String mailType) {
        verifyAndSwitchFrame();
        Assert.assertTrue($(By.xpath("//div[contains(text(),\"" + mailType + " will update a mail\'s status to  Responded\")]")).isDisplayed());
    }

    /**
     * Method to verify mail rules Info
     */
    public boolean verifyMailRuleInfo() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        if ($(lblDistributionRule).isDisplayed() && $(lnkPreview).isDisplayed())
            return true;
        else return false;
    }

    /**
     * Method to click on Preview link in distribution rules banner
     */
    public void clickPreviewLink() {
        verifyAndSwitchFrame();
        navigator.getElementInView(lnkPreview);
        commonMethods.scrollPageUp(driver);
        $(lnkPreview).click();
        commonMethods.waitForElement(driver, viewSendBtn, 30);
    }

    /**
     * Method to remove selected values from multi selected fields
     */
    public void removeMultiSltAttributes(String fieldName) {
        String xpath = "//label[text()='" + commonMethods.getLabelName(fieldName) + "']//../..//td";
        By element = By.xpath(xpath + "/div[contains(@class,'uiMultiSelectField uiField uiIconField large')]");
        removeMultiSltValues(element);
    }

    /**
     * Method to select project field values
     */
    public void selectProjectFieldValues(String values) {
        String[] value = values.split(",");
        String xpath = "//label[text()='" + commonMethods.getLabelName(value[0]) + "']//../..//td";
        commonMethods.waitForElementExplicitly(2000);
        switch (commonMethods.getLabelType(value[0]).toLowerCase()) {
            case "yes/no":
            case "select list (single)":
                commonMethods.waitForElementClickable(driver, By.xpath(xpath + "/select"), 60);
                commonMethods.enterDropdownValue(By.xpath(xpath + "/select"), value[1]);
                break;
            case "select list (multiple)":
                By element = By.xpath(xpath + "/div[contains(@class,'uiMultiSelectField uiField uiIconField large')]");
                selectMultiSelectValues(element, values);
                break;
            case "date":
            case "text":
            case "number":
                if (value[1].equalsIgnoreCase("today") || value[1].equalsIgnoreCase("tomorrow") || value[1].equalsIgnoreCase("yesterday"))
                    value[1] = commonMethods.getDate(configFileReader.getTimeZone(), value[1].toLowerCase());
                commonMethods.waitForElementClickable(driver, By.xpath(xpath + "//input"), 60);
                commonMethods.enterTextValue(By.xpath(xpath + "//input"), value[1]);
                break;
            case "text area":
                commonMethods.waitForElementClickable(driver, By.xpath(xpath + "//textarea"), 60);
                commonMethods.enterTextValue(By.xpath(xpath + "//textarea"), value[1]);
                break;
        }
    }

    /**
     * Method to click on Attach and Click on Document
     */
    public void clickAttachDocument() {
        commonMethods.waitForElement(driver, attachBtn, 60);
        $(attachBtn).click();
        commonMethods.waitForElement(driver, attachDocFromDropDown);
        $(attachDocFromDropDown).click();
    }

    /**
     * Method to Click on full Document search from mail page
     */
    public void verifyDocSearch() {
        switchTo().defaultContent();
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, mailSubject, 60);
        sleep(1000);
        $(attachBtn).click();
        String text = getDocumentMenuName();
        verifyAndSwitchFrame();
        By documentLink = By.xpath("//a[contains(text(),'" + text.substring(0, text.length() - 1) + "')]"); //docMap.get("attachbutton")
        commonMethods.waitForElement(driver, documentLink, 15);
        $(documentLink).click();
        commonMethods.waitForElementExplicitly(2000);
        documentPage.clickFullSearch();
        commonMethods.waitForElementExplicitly(2000);
        //return documentPage.verifyDocPresent(fileName);
    }

    /**
     * Method to get all restricted fields from a selected mail type
     */
    public List<String> getRestrictedFields() {
        commonMethods.waitForElement(driver, lblRestricted);
        return commonMethods.getValues(restrictedFieldNames);
    }

    /**
     * Method to verify restricted field section displayed in blank mail
     */
    public boolean verifyRestrictedField() {
        commonMethods.waitForElement(driver, mailSubject, 60);
        return $(tabRestrictedFields).isDisplayed();
    }

    /**
     * Method to verify restricted fields and values displayed in compose mail screen
     */
    public boolean verifyRestrictedField(String name, String type) {
        switch (type.toLowerCase()) {
            case "text":
                 return $(By.xpath("//input[@name='_restrictedFields_" + name + "_singleLineText']")).isDisplayed();
            case "textarea":
                return $(By.xpath("//textarea[@name='_restrictedFields_" + name + "_multiLineText']")).isDisplayed();
            case "dropdown":
                return $(By.xpath("//select[contains(@name,'_restrictedFields_" + name + "')]")).isDisplayed();
            case "date":
                return $(By.xpath("//input[@id='_restrictedFields_" + name + "_date_da']")).isDisplayed();
            case "selectlist":
                return $(By.xpath("//div[contains(@id,'_restrictedFields_" + name + "_')]")).isDisplayed();
            case "number":
                return $(By.xpath("//input[contains(@name,'_restrictedFields_" + name + "_number')]")).isDisplayed();
        }
        return false;
    }

    /**
     * Method to click Info message displayed for restricted fields
     */
    public void clickRFIcon(String name) {
        By xpath = By.xpath("//td[@class='contentcell']//*[contains(@id,'" + name + "')]/../..//div[@class='info-icon']");
        commonMethods.getElementInViewAndUp(xpath);
        $(xpath).click();
    }

    /**
     * Method to verify mandatory is displayed for restricted fields
     */
    public boolean getRFMandatory(String fieldName) {
        return $(By.xpath("//div[@id='restrictedFieldsSection']//table//td/label[contains(text(),'" + fieldName + "')]/span[@class='required']")).isDisplayed();
    }

    /**
     * Method to get dropdown and select list values for restricted fields
     */
    public List<String> getRFValues(String name, String type) {
        By xpath;
        switch (type.toLowerCase()) {
            case "dropdown":
                xpath = By.xpath("//select[contains(@name,'_restrictedFields_" + name + "')]");
                return commonMethods.returnAllOptionsInDropDown(driver, xpath);
            case "selectlist":
                clickAttributeList(name);
                List<String> values = getAttributeList("");
                $(By.xpath("//button[contains(@id,'_restrictedFields_" + name + "_') and @title='Cancel']")).click();
                return values;
        }
        return null;
    }

    /**
     * Method to return info message
     */
    public boolean verifyInfoMessage(String name) {
        clickRFIcon(name);
        return $(By.xpath("//div[@class='calloutContent' and contains(text(),'" + name + "')]")).isDisplayed();
    }

    /**
     * Function to get Restricted fields color code for mandatory and non mandatory fields
     */
    public String getRFColorCode(String name, String type) {
        switch (type.toLowerCase()) {
            case "text":
                return commonMethods.getBGColor(By.xpath("//div[@id='_restrictedFields_" + name + "_singleLineText']"));
            case "textarea":
                return commonMethods.getBGColor(By.xpath("//textarea[@name='_restrictedFields_" + name + "_multiLineText']"));
            case "dropdown":
                return commonMethods.getBGColor(By.xpath("//select[contains(@name,'_restrictedFields_" + name + "')]"));
            case "date":
                return commonMethods.getBGColor(By.xpath("//div[@id='_restrictedFields_" + name + "_date-dateField']"));
            case "selectlist":
                return commonMethods.getBGColor(By.xpath("//div[contains(@id,'_restrictedFields_" + name + "_')]"));
            case "number":
                return commonMethods.getBGColor(By.xpath("//div[contains(@id,'_restrictedFields_" + name + "_number')]"));
        }
        return "";
    }

    /**
     * Method to verify restricted fields values
     */
    public String verifyRFValues(String name, String type) {
        switch (type.toLowerCase()) {
            case "text":
                return $(By.xpath("//div[@id='_restrictedFields_" + name + "_singleLineText']//input")).getValue();
            case "textarea":
                return $(By.xpath("//textarea[@name='_restrictedFields_" + name + "_multiLineText']")).getValue();
            case "dropdown":
                return $(By.xpath("//select[contains(@name,'_restrictedFields_" + name + "')]")).getSelectedText();
            case "date":
                return $(By.xpath("//div[@id='_restrictedFields_" + name + "_date-dateField']//input")).getValue();
            case "selectlist":
                return $(By.xpath("//div[contains(@id,'_restrictedFields_" + name + "_')]//span[@class='uiMultiSelectField-selectedText']")).getText();
            case "number":
                return $(By.xpath("//div[contains(@id,'_restrictedFields_" + name + "_number')]//input")).getValue();
        }
        return "";
    }

    /**
     * Method to verify To field displayed
     */
    public boolean verifyToField() {
        return $(toRecipient).isDisplayed() && $(to).isDisplayed();
    }

    /**
     * Method to verify To field displayed
     */
    public boolean verifyCcField() {
        return $(ccLink).isDisplayed() && $(cc).isDisplayed();
    }

    /**
     * Method to verify restriction banner
     */
    public boolean verifyRestrictionBanner() {
        return $(restrictionBanner).isDisplayed();
    }

    /**
     * Method to verify added recipients in compose mail screen
     */
    public boolean verifyRecipient(String group, String name) {
        return $(By.xpath("//table[@id='recipientList_" + group.toUpperCase() + "']//label[contains(text(),'" + name + "')]")).isDisplayed();
    }
    /**
     * Method to return the value present by default in Attachments
     *
     * @return
     */
    public String getDefaultAttachmentValue() {
        commonMethods.waitForElement(driver, attachmentsView, 60);
        return $(attachmentsView).getSelectedText();
    }
    /**
     * Method to select attachment Value
     *
     */
    public void selectAttachmentValue(String customView) {
        commonMethods.waitForElement(driver, attachmentsView, 60);
        $(attachmentsView).selectOption(customView);
    }
    /**
     * Method to Store Attachment view column order
     *
     * @return
     */
    public void storeAttachmentViewOrder() {
        attachmentView.clear();
        commonMethods.waitForElementExplicitly(5000);
        for(WebElement element : $$(attchmentViewOrder)) {
            attachmentView.add(element.getText());
        }
    }

}