package com.oracle.babylon.pages.Document;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Selenide.$;

public class TransmittalHistoryReportPage extends DocumentPage {

    private By optionsBtn = By.xpath("//button[@id='btnOptions']");
    private By exportToExcelBtn = By.xpath("//button[@id='btnExportToExcel']");
    private By printBtn = By.xpath("//button[@id='btnPrint']");
    private By backBtn = By.xpath("//button[@id='btnBack']");
    private By filterShowAll = By.xpath("//label[text()='Show me all documents']//input");
    private By okBtn = By.xpath("//button[@id='btnOrganizationsOk']");
    private By okOrgBtn = By.xpath("//button[@id='btnOrganizationsOk']");
    private By resultValue = By.xpath("//div[@class='searchNav clearFloats']//div//b[1]");
    private By exportMsg = By.xpath("//div[contains(text(),'Export to Excel has successfully')]");
    private By temporaryFilesBtn = By.xpath("//div[@class='uiButton-label' and contains(text(),'Temporary Files')]");

    //Transmittal History Org
    private By selectOrg = By.xpath("//select[@id='TRANSMITTAL_HIST_CD_RECIPIENT_ORGID']");
    private By showStatus = By.xpath("//select[@id='_TRANSMITTAL_HIST_CD_SHOW_TYPE']");
    private By showOptions = By.xpath("//select[@id='_TRANSMITTAL_HIST_CD_SHOW_TYPE']//option");
    private By searchBtn = By.xpath("//button[@id='btnSearch_page']");
    private By transmitBtn = By.xpath("//button[@id='btnTransmit']");
    private By selcetDocOption = By.xpath("//th[@id='selectMenuColumn']");

    /**
     * Function to verify doc transmittal history
     *
     * @param status
     * @return
     */
    public boolean verifyTransmittalHistory(String status) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, optionsBtn, 20);
        return $(By.xpath("//td[text()='" + status + "']")).isDisplayed();
    }

    /**
     * Function to verify transmitted document history
     *
     * @param data
     */
    public void verifyTransmittedDocumentHistory(String data) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, optionsBtn, 40);
        Map<String, String> table = dataStore.getTable(data);
        for (String tableData : table.keySet()) {
            switch (tableData) {
                case "Document":
                    String[] namesList = table.get(tableData).split(",");
                    for (String name : namesList) {
                        Assert.assertTrue(verifyDocumentData(returnDocumentNumber(name)));
                    }
                    break;
                case "Uploaded By":
                    jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
                    userMap = jsonMapOfMap.get(table.get(tableData));
                    String[] user = userMap.get("full_name").toString().split(" ");
                    Assert.assertTrue(verifyDocumentData(user[1]));
                    break;
                case "Received Transmittal link":
                    String[] transList = table.get(tableData).split(",");
                    for (String name : transList) {
                        verifyAndSwitchFrame();
                        Assert.assertTrue(verifyTransmittalLink(commonMethods.getMailNumFromJson(name)));
                    }
                    break;
                case "Not Transmitted":
                    Assert.assertTrue(verifyTransmittalHistory(table.get(tableData)));
                default:
                    Assert.assertTrue(verifyRevisionOrStatus(table.get(tableData)));
            }
        }
    }

    /**
     * Function to verify Doc Transmittal Data
     *
     * @param docName
     * @return
     */
    public boolean verifyDocumentData(String docName) {
        By doc = (By.xpath("//td[contains(text(),'" + docName + "')]"));
        commonMethods.waitForElement(driver, doc, 40);
        return $(doc).isDisplayed();
    }

    /**
     * Function to verify transmitted document status and revision
     *
     * @param value
     * @return
     */
    public boolean verifyRevisionOrStatus(String value) {
        By statusValue = (By.xpath("//td[text()='" + value + "']"));
        commonMethods.waitForElement(driver, statusValue, 40);
        return $(statusValue).isDisplayed();
    }

    /**
     * Function to verify document transmitted link
     *
     * @param link
     * @return
     */
    public boolean verifyTransmittalLink(String link) {
        By transLink = (By.xpath("//td//a[contains(text(),'" + link + "')]"));
        commonMethods.waitForElement(driver, transLink, 40);
        return $(transLink).isDisplayed();
    }

    /**
     * Function verify different page options
     */
    public void verifyPageOptions() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, printBtn, 20);
        Assert.assertTrue($(printBtn).isDisplayed());
        Assert.assertTrue($(backBtn).isDisplayed());
        Assert.assertTrue($(exportToExcelBtn).isDisplayed());
    }

    /**
     * Function to verify filter option is selected
     *
     * @param option
     * @return
     */
    public boolean verifyFilterIsSelected(String option) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, optionsBtn, 20);
        $(optionsBtn).click();
        commonMethods.waitForElement(driver, filterShowAll, 20);
        return $(By.xpath("//label[text()='" + option + "']//input")).isSelected();
    }

    /**
     * Function to select Filter option
     *
     * @param option
     * @return
     */
    public void selectFilterOption(String option) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, optionsBtn, 20);
        $(optionsBtn).click();
        commonMethods.waitForElement(driver, filterShowAll, 20);
        $(By.xpath("//label[text()='" + option + "']//input")).click();
    }

    /**
     * Click ok Button
     */
    public void clickOkButton() {
        verifyAndSwitchFrame();
        $(okBtn).click();
    }

    /**
     * Function to verify Organization filters
     *
     * @param org
     * @param result
     */
    public void verifyOrgFilter(String org, String result) {
        verifyAndSwitchFrame();
        if (org.equalsIgnoreCase("user55")) {
            jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
            userMap = jsonMapOfMap.get(org);
            if ($(By.xpath("//select[@id='ORGS_AVAIL']//option[text()='" + userMap.get("org_name").toString() + "']")).isDisplayed()) {
                $(By.xpath("//select[@id='ORGS_AVAIL']//option[text()='" + userMap.get("org_name").toString() + "']")).doubleClick();
                getElementInView(okOrgBtn);
                $(okOrgBtn).click();
            }
            Assert.assertTrue($(resultValue).getText().contains(result));
        } else {
            jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
            userMap = jsonMapOfMap.get(org);
            $(By.xpath("//select[@id='ORGS_AVAIL']//option[text()='" + userMap.get("org_name").toString() + "']")).doubleClick();
            getElementInView(okOrgBtn);
            $(okOrgBtn).click();
            Assert.assertTrue(verifyDocumentData(returnDocumentNumber(result)));

        }
    }

    /**
     * Function to verify Export to excel
     *
     * @return
     */
    public Boolean verifyExportToExcel() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, exportToExcelBtn, 20);
        $(exportToExcelBtn).click();
        commonMethods.waitForElement(driver, exportMsg);
        return $(exportMsg).isDisplayed();
    }

    /**
     * Click on Temporary files Button
     */
    public void clickTemporaryFiles() {
        verifyAndSwitchFrame();
        $(temporaryFilesBtn).click();
    }

    /**
     * Function to verify Print button
     *
     * @return
     */
    public boolean verifyPrintOption() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, printBtn, 20);
        return $(printBtn).isDisplayed();
    }

    /**
     * Function to select org
     *
     * @param user
     */
    public void selectOrg(String user) {
        verifyAndSwitchFrame();
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
        userMap = jsonMapOfMap.get(user);
        commonMethods.waitForElement(driver, selectOrg, 30);
        $(selectOrg).selectOption(userMap.get("org_name").toString());
    }

    /**
     * Function to select status
     *
     * @param status
     */
    public void selectShowStatus(String status) {
        verifyAndSwitchFrame();
        $(showStatus).selectOption(status);
    }

    /**
     * Function to Click search
     */
    public void clickSearch() {
        verifyAndSwitchFrame();
        $(searchBtn).click();
    }

    /**
     * Function to verify show status options
     *
     * @param data
     */
    public void verifyShowStatus(List<String> data) {
        verifyAndSwitchFrame();
        $(showStatus).click();
        List<WebElement> options = driver.findElements(showOptions);
        for (int i = 0; i <= options.size() - 1; i++) {
            String optionsText = options.get(i).getText();
            Assert.assertTrue(optionsText.contains(data.get(i)));
        }
    }

    /**
     * Function to verify page fields
     */
    public void verifyPageFields() {
        verifyAndSwitchFrame();
        Assert.assertTrue($(transmitBtn).isDisplayed());
        Assert.assertTrue($(selectOrg).isDisplayed());
        Assert.assertTrue($(backBtn).isDisplayed());
        Assert.assertTrue($(searchBtn).isDisplayed());
    }

    /**
     * Function to click on back button
     */
    public void clickBackBtn() {
        verifyAndSwitchFrame();
        $(backBtn).click();
    }

    /**
     * Function to verify reports based on Organization
     *
     * @param orgName
     * @param result
     */
    public void verifyOrgReports(String orgName, String result) {
        verifyAndSwitchFrame();
        selectOrg(orgName);
        commonMethods.waitForElementExplicitly(2000);
        clickSearch();
        commonMethods.waitForElement(driver, resultValue);
        Assert.assertTrue($(resultValue).getText().contains(result));
    }

    /**
     * Function to verify transmitted document history for org
     *
     * @param data
     */
    public void verifyOrgTransmittedDocumentHistory(String data) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(3000);
        Map<String, String> table = dataStore.getTable(data);
        for (String tableData : table.keySet()) {
            switch (tableData) {
                case "Document":
                    String[] namesList = table.get(tableData).split(",");
                    for (String name : namesList) {
                        Assert.assertTrue(verifyDocumentData(returnDocumentNumber(name)));
                    }
                    break;
                case "Transmittal Sent":
                    Assert.assertTrue(verifyDate(4, table.get(tableData)));
                    break;
                case "Date Sent":
                    Assert.assertTrue(verifySentDate(3, table.get(tableData)));
                    break;
                case "Sent Revision":
                case "Current Revision":
                case "Last Revision":
                    Assert.assertTrue(verifyRevisionOrStatus(table.get(tableData)));
                    break;
                case "Current Revision Date":
                    Assert.assertTrue(verifyDate(7, table.get(tableData)));
                    break;
                case "Transmittal link":
                case "Transmittal Number":
                    String[] transList = table.get(tableData).split(",");
                    for (String name : transList) {
                        verifyAndSwitchFrame();
                        Assert.assertTrue(verifyTransmittalLink(commonMethods.getMailNumFromJson(name)));
                    }
                    break;
                case "To":
                    jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
                    userMap = jsonMapOfMap.get(table.get(tableData));
                    String[] user = userMap.get("full_name").toString().split(" ");
                    Assert.assertTrue(verifyDocumentData(user[1]));
                    break;
            }
        }
    }

    /**
     * Function to verify date
     *
     * @param num
     * @param date
     * @return
     */
    public boolean verifyDate(int num, String date) {
        commonMethods.waitForElementExplicitly(2000);
        return $(By.xpath("//tbody//tr[1]//td[" + num + "]")).getText().contains(commonMethods.getDate(configFileReader.getTimeZone(), date));
    }

    /**
     * Function to verify sent date
     *
     * @param row
     * @param date
     * @return
     */
    public boolean verifySentDate(int row, String date) {
        commonMethods.waitForElementExplicitly(2000);
        return $(By.xpath("//tbody//tr[" + row + "]//td[6]")).getText().contains(commonMethods.getDate(configFileReader.getTimeZone(), date));
    }


    /**
     * Function to select document options
     *
     * @param option
     */
    public void selectDocumentOptions(String option) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, selcetDocOption, 20);
        $(selcetDocOption).click();
        $(By.xpath("//a[text()='" + option + "']")).click();
    }
}
