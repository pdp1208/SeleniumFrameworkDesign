package com.oracle.babylon.Utils.helper;

import com.oracle.babylon.Utils.setup.utils.ConfigFileReader;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Platform;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.FirefoxDriverLogLevel;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.logging.Level;

/**
 * Class to handle the operations related to the driver
 * Author : vsingsi, susgopal
 */
public class DriverFactory {
    //Initialization of objects and assigning references to the object.
    ConfigFileReader configFileReader = new ConfigFileReader();

    /**
     * Function to create a browser
     *
     * @return browser reference
     * @throws MalformedURLException
     */
    public WebDriver getDriver() {
        WebDriver driver = null;
        try {
            if (configFileReader.getMode().equalsIgnoreCase("grid")) {
                driver = remoteDriver();
            } else {
                driver = browser();
            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
            System.exit(1);
        }
        return driver;
    }

    /**
     * Function to create a remote driver
     *
     * @return browser reference
     * @throws MalformedURLException
     */
    public WebDriver remoteDriver() throws MalformedURLException {
        String url = configFileReader.getHubUrl() + "/wd/hub";
        switch (configFileReader.getBrowser().toLowerCase()) {

            case "chrome":
                LoggingPreferences logPrefs = new LoggingPreferences();
                logPrefs.enable(LogType.BROWSER, Level.ALL);
                DesiredCapabilities desiredCapabilities = new DesiredCapabilities().chrome();
                desiredCapabilities.setCapability(CapabilityType.PROXY, setUpProxy());
//                desiredCapabilities.setCapability("resolution", configFileReader.getBrowserDimensions());
                HashMap<String, Object> chromePrefs = new HashMap<>();
                chromePrefs.put("profile.default_content_settings.popups", 0);
                chromePrefs.put("download.prompt_for_download", "false");
                chromePrefs.put("safebrowsing.enabled", "false");
                ChromeOptions options = new ChromeOptions();
                options.setExperimentalOption("prefs", chromePrefs);
                options.setCapability("goog:loggingPrefs", logPrefs);
                //options.setHeadless(true);
                options.addArguments("--headless=new", "--no-sandbox", "--disable-dev-shm-usage",
						"--window-size=1920,1080", "--disable-gpu", "--force-device-scale-factor=.60");

                /// options.setCapability("se.recordVideo", true);
                desiredCapabilities.setCapability(ChromeOptions.CAPABILITY, options);
                desiredCapabilities.setCapability("goog:loggingPrefs", logPrefs);
                System.out.println("set capability done -----");
                RemoteWebDriver chromeDriver = new RemoteWebDriver(new URL(url), desiredCapabilities);
                System.out.println("Configuration done -----");
                configureDriver(chromeDriver);
                System.out.println("done -----");
                chromeDriver.setFileDetector(new LocalFileDetector());
                return chromeDriver;
            case "firefox":
                LoggingPreferences fireFoxLogPrefs = new LoggingPreferences();
                fireFoxLogPrefs.enable(LogType.BROWSER, Level.ALL);
                fireFoxLogPrefs.enable(LogType.PERFORMANCE, Level.ALL);
                FirefoxOptions ffoptions = new FirefoxOptions();
                ffoptions.setCapability("proxy", setUpProxy());
                ffoptions.setCapability("resolution", configFileReader.getBrowserDimensions());
                FirefoxProfile profile = new FirefoxProfile();
                profile.setPreference("browser.download.manager.showWhenStarting", false);
                profile.setPreference("browser.helperApps.neverAsk.saveToDisk", "application/octet-stream");
                profile.setPreference("browser.download.manager.showWhenStarting", false);
                profile.setPreference("browser.helperApps.neverAsk.saveToDisk", "application/octet-stream");
                profile.setPreference("browser.download.manager.alertOnEXEOpen", false);
                profile.setPreference("browser.download.manager.closeWhenDone", true);
                profile.setPreference("browser.download.manager.showAlertOnComplete", false);
                profile.setPreference("browser.download.manager.useWindow", false);
                profile.setPreference("browser.helperApps.alwaysAsk.force", false);
                profile.setPreference("pdfjs.disabled", true);
                ffoptions.setLogLevel(FirefoxDriverLogLevel.TRACE);
                ffoptions.setProfile(profile);
                RemoteWebDriver firefoxDriver = new RemoteWebDriver(new URL(url), ffoptions);
                configureDriver(firefoxDriver);
                firefoxDriver.setFileDetector(new LocalFileDetector());
                return firefoxDriver;

            case "ie":
                DesiredCapabilities IEcapability = new DesiredCapabilities().internetExplorer();
                IEcapability.setCapability(CapabilityType.PROXY, setUpProxy());
                RemoteWebDriver IEDriver = new RemoteWebDriver(new URL(url), IEcapability);
                configureDriver(IEDriver);
                IEDriver.setFileDetector(new LocalFileDetector());
                return IEDriver;

            case "edge":
                DesiredCapabilities edgeCapabilities = new DesiredCapabilities().edge();
                edgeCapabilities.setCapability(CapabilityType.PROXY, setUpProxy());
                edgeCapabilities.setCapability("resolution", configFileReader.getBrowserDimensions());
                edgeCapabilities.setCapability("platform", "linux");
                RemoteWebDriver edgeDriver = new RemoteWebDriver(new URL(url), edgeCapabilities);
                configureDriver(edgeDriver);
                edgeDriver.setFileDetector(new LocalFileDetector());
                return edgeDriver;
        }
        throw new RuntimeException(" Remote driver not found available, Please verify your driver !!!");
    }

    /**
     * Function to check for the os, browser and select the appropriate driver
     *
     * @return respective browser references according to the required properties
     */
    public WebDriver browser() {
        /**
         * Using the OS and the required browser by using the conditional statements, to return the browser reference
         */
        String os = System.getProperty("os.name");
        String driverPath = System.getProperty("user.dir") + configFileReader.getDriverPath();
        if (os.contains("Windows") && configFileReader.getBrowser().equalsIgnoreCase("chrome")) {
            driverPath = driverPath + "win64/chromedriver.exe";
            return setPropertyAndInitChromeDriver(driverPath);
        } else if (os.contains("Windows") && configFileReader.getBrowser().equalsIgnoreCase("edge")) {
            driverPath = driverPath + "win64/msedgedriver.exe";
            return setPropertyAndInitEdgeDriver(driverPath);
        } else if (os.contains("Windows") && configFileReader.getBrowser().equalsIgnoreCase("firefox")) {
            driverPath = driverPath + "win64/geckodriver.exe";
            return setPropertyAndInitFirefoxDriver(driverPath);
        } else if (os.contains("Windows") && configFileReader.getBrowser().equalsIgnoreCase("ie")) {
            driverPath = driverPath + "win32/IEDriverServer.exe";
            return setPropertyAndInitIEDriver(driverPath);
        } else if (os.contains("Mac") && configFileReader.getBrowser().equalsIgnoreCase("chrome")) {
            driverPath = driverPath + "mac64/chromedriver";
            return setPropertyAndInitChromeDriver(driverPath);
        } else if (os.contains("Mac") && configFileReader.getBrowser().equalsIgnoreCase("firefox")) {
            driverPath = driverPath + "mac64/geckodriver";
            return setPropertyAndInitFirefoxDriver(driverPath);
        } else if (os.contains("Linux") && configFileReader.getBrowser().equalsIgnoreCase("firefox")) {
            driverPath = driverPath + "linux/geckodriver";
            return setPropertyAndInitFirefoxDriver(driverPath);
        }
        throw new RuntimeException(" Not such driver available, Please verify your driver !!!");
    }

    /**
     * Function to configure the properties for Chrome browser
     *
     * @param path
     * @return browser reference
     */
    private WebDriver setPropertyAndInitChromeDriver(String path) {
        WebDriver chromeDriver = null;
        System.setProperty("webdriver.chrome.driver", path);
        String downloadFilepath = configFileReader.getDownloadedFilePath();
        LoggingPreferences logPrefs = new LoggingPreferences();
        logPrefs.enable(LogType.BROWSER, Level.ALL);
        logPrefs.enable(LogType.PERFORMANCE, Level.ALL);
        DesiredCapabilities desiredCapabilities = DesiredCapabilities.chrome();
        HashMap<String, Object> chromePrefs = new HashMap<>();
        chromePrefs.put("download.default_directory", downloadFilepath);
        //setting for disabling 'This type of file can harm your computer' pop up while downloading the report.
        chromePrefs.put("safebrowsing.enabled", "true");
        ChromeOptions options = new ChromeOptions();
        options.setExperimentalOption("prefs", chromePrefs);
        options.setHeadless(false);
        desiredCapabilities.setCapability(ChromeOptions.CAPABILITY, options);
        desiredCapabilities.setCapability("goog:loggingPrefs", logPrefs);
        //Setting the proxy for the driver by getting the configuration from configFile.properties
        if (configFileReader.getHttpProxyStatus()) {
            desiredCapabilities.setCapability(CapabilityType.PROXY, setUpProxy());
            chromeDriver = new ChromeDriver(desiredCapabilities);

        } else {
            chromeDriver = new ChromeDriver(desiredCapabilities);
        }
        configureDriver(chromeDriver);
        return chromeDriver;
    }

    /**
     * Function to configure the properties of Firefox browser
     *
     * @param path
     * @return browser reference
     */
    public WebDriver setPropertyAndInitFirefoxDriver(String path) {
        //For latest version of firefox we need to configure the gecko driver
        System.setProperty("webdriver.gecko.driver", path);
        WebDriver firefoxDriver = null;
        FirefoxOptions options = new FirefoxOptions();
        options.setLogLevel(FirefoxDriverLogLevel.TRACE);
        FirefoxProfile profile = new FirefoxProfile();
        profile.setPreference("browser.download.folderList", 2);
        profile.setPreference("browser.download.dir", configFileReader.getDownloadedFilePath());
        profile.setPreference("browser.download.manager.showWhenStarting", false);
        profile.setPreference("browser.helperApps.neverAsk.saveToDisk", "application/octet-stream");
        profile.setPreference("pdfjs.disabled", true);
        profile.setPreference("devtools.selfxss.count", 100);
        options.setProfile(profile);
        firefoxDriver = new FirefoxDriver(options);
        configureDriver(firefoxDriver);
        return firefoxDriver;
    }

    /**
     * Function to configure the properties of Internet Explorer browser
     *
     * @param path
     * @return reference to the ie driver
     */
    private WebDriver setPropertyAndInitIEDriver(String path) {
        System.setProperty("webdriver.ie.driver", path);
        WebDriver ieDriver = null;
        if (configFileReader.getHttpProxyStatus()) {
            DesiredCapabilities desiredCapabilities = DesiredCapabilities.internetExplorer();
            desiredCapabilities.setCapability(CapabilityType.PROXY, setUpProxy());
            ieDriver = new InternetExplorerDriver(desiredCapabilities);
        } else {
            ieDriver = new InternetExplorerDriver();
        }
        configureDriver(ieDriver);
        return ieDriver;
    }

    /**
     * Function to configure the properties of Edge browser
     *
     * @param path
     * @return reference to the edge driver
     */
    private WebDriver setPropertyAndInitEdgeDriver(String path) {
        System.setProperty("webdriver.edge.driver", path);
        WebDriver edgeDriver = null;
        if (configFileReader.getHttpProxyStatus()) {
            DesiredCapabilities desiredCapabilities = DesiredCapabilities.edge();
            desiredCapabilities.setCapability(CapabilityType.PROXY, setUpProxy());
            edgeDriver = new EdgeDriver(desiredCapabilities);
        } else {
            edgeDriver = new EdgeDriver();
        }
        configureDriver(edgeDriver);
        return edgeDriver;
    }


    /**
     * Function to Setup proxy for oracle
     *
     * @param
     * @return proxy
     */

    public Proxy setUpProxy() {
        String proxyURL = configFileReader.getProxyURL();
        Proxy proxy = new Proxy();
        return proxy.setHttpProxy(proxyURL).setSslProxy(proxyURL).setSslProxy(proxyURL).setNoProxy(configFileReader.getNoProxyURL()); //setFtpProxy(proxyURL)
    }

    /**
     * Function to Setup no proxy for oracle
     *
     * @param
     * @return proxy
     */

    public Proxy setNoProxy() {
        Proxy proxy = new Proxy();
        proxy.setProxyType(Proxy.ProxyType.MANUAL);
        proxy.setNoProxy("");
        return proxy;
    }

    /**
     * Function to make some changes to the object / reference
     *
     * @param driver
     */
    private void configureDriver(WebDriver driver) {
//        Dimension dimension = new Dimension(Integer.parseInt(configFileReader.getBrowserDimensions().split("x")[0]), Integer.parseInt(configFileReader.getBrowserDimensions().split("x")[1]));
//        driver.manage().window().setSize(dimension);
        driver.manage().deleteAllCookies();
        driver.manage().window().maximize();
    }

}

