package com.oracle.babylon.pages.Directory;

import com.codeborne.selenide.Condition;
import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Selenide.*;

/**
 * Contains the methods to perform operations on the Directory search page
 * Author : susgopal
 */
public class DirectoryPage extends Navigator {

    //Initialize all the identifier required in the page
    private By inviteUser= By.xpath("//button[text()='Invite user']");
    private By groupName = By.xpath("//input[@name='FIRST_NAME']");
    private By familyName = By.xpath("//input[@name='LAST_NAME']");
    private By searchBtn = By.xpath("//button[@id='btnSearch_page']//div//div");
    private By organizationName = By.xpath("//input[@id='ORG_NAME']");
    private By jobTitle = By.xpath("//input[@name='POSITION_NAME']");
    private By division = By.xpath("//input[@name='DIVISION_NAME']");
    private By userList = By.xpath("//input[@name='USERS_LIST']");
    private By addUserToBtn = By.xpath("//button[@id='btnAddTo_page']");
    private By okBtn = By.xpath("//button[@id='btnOk']");
    private By selectUser = By.xpath("//table[@id='resultTable']//tbody//tr[1]//input[@name='USERS_LIST']");
    private By loadingProgressIcon = By.cssSelector(".loading_progress");
    private By globalDirectoryLink = By.xpath("//li[text()='Global']");
    private By projectDirectoryLink = By.xpath("//li[text()='Project']");
    private By addBtn = By.xpath("//div[text()='Add']");
    private By fromBtn = By.xpath("//div[text()='From']");
    private By topUserTxt = By.xpath("//table[@id='resultTable']//tr[1]//a");
    private By userNames = By.xpath("//table[@id='resultTable']//tr//td[1]//a");
    private By noRecordsMessage = By.xpath("//td[contains(text(),'No search results')]");
    private By header = By.xpath("//h1[text()='Search - Directory']");
    private By createMailingGroupBtn = By.xpath("//button[@id='btnNewMailGroup']//div[@class='uiButton-content']//div[contains(text(),'Create Mailing Group')]");
    private By inputGroupName = By.xpath("//input[@name='GROUP_NAME']");
    private By editUsersBtn = By.xpath("//button[@id='btnEditUsers']//*[contains(text(),'Edit Users')]");
    private By selectRecipientsHeader = By.xpath("//h1[text()='Select Recipients']");
    private By dataResults = By.xpath("//tr[@class='dataRow']");
    private By firstResult = By.xpath("(//tr[@class='dataRow'])[1]//td//a");
    private By createGuestBtn = By.xpath("//button//div[text()='Create Guest']");
    private By searchDirectoryHeader = By.xpath("//h1[text()='Search - Directory']");
    SimpleDateFormat formatter = new SimpleDateFormat("dd-HH-mm-ss");
    private By directoryMenu = By.xpath("//button[contains(@class,'uiButton navBarButton')]//div[text()='Directory']");
    private By projectDirectoryText = By.xpath("//div[text()='Project Directory']");
    private By globalDirectoryText = By.xpath("//div[text()='Global Directory']");
    private By columnHeaders = By.xpath("//tr[@class='dataHeaders']//th");
    private By orgValues = By.xpath("//table[@id='resultTable']//tbody//tr//td[2]//a");
    private By divisionValues = By.xpath("//table[@id='resultTable']//tbody//tr//td[2]");
    private By full_name = By.xpath("//table[@id='resultTable']//tbody//tr//td[1]//a");
    private By job_title_col = By.xpath("//table[@id='resultTable']//tbody//tr//td[1]//div");
    private By pageTitle = By.xpath("//h1[text()='Search - Directory']");
    private By noResultsText = By.xpath("//div[@class='dataNoResults']//span");
    private By noSearchResult = By.xpath("//td[text()=' No search results']");
    private By nextPage = By.xpath("//a[text()='next>>']");
    private By previousPage = By.xpath("//a[contains(text(),'<<previous')]");
    private By nameCell = By.xpath("//table[@id='resultTable']//td[1]//a");
    private By group=By.xpath("//img[@title='Mailing Group']");
    private By linkName=By.xpath("//img[@title='Mailing Group']//..//a");
    public By deleteBtn = By.xpath("//button[@id='btnDelete']//div[text()='Delete']");
    private By inviteUserBtn = By.xpath("//button[text()='Invite user']");
    private By inviteSpan = By.xpath("//span[contains(text(),'Invite')]");
    private By searchUserTxtBox = By.xpath("//div[@class='auiUserSelect']//input");
    private By emailNotificationChkBox = By.xpath("//input[@id='sendMailOnInvite']");

    public void verifyPageTitle() {
        commonMethods.waitForElement(driver, pageTitle);
        Assert.assertTrue($(pageTitle).isDisplayed());
    }

    /**
     * Method to input all the text boxes present in the directory search page
     *
     * @param firstNameVar
     * @param familyNameVar
     * @param organizationNameVar
     * @param jobTitleVar
     * @param divisionVar
     */
    public void fillFieldsAndSearch(String firstNameVar, String familyNameVar, String organizationNameVar, String jobTitleVar, String divisionVar) {
        //Checking if we need to set each text box value
        commonMethods.waitForElementExplicitly(2000);
        $(loadingProgressIcon).should(disappear);
        commonMethods.waitForElement(driver, jobTitle, 20);
        commonMethods.waitForElementExplicitly(1500);
        if (firstNameVar != null) {
            $(groupName).clear();
            $(groupName).sendKeys(firstNameVar);
        }
        if (familyNameVar != null) {
            $(familyName).clear();
            $(familyName).sendKeys(familyNameVar);
        }
        if (organizationNameVar != null) {
            $(organizationName).clear();
            $(organizationName).sendKeys(organizationNameVar);
        }
        if (jobTitleVar != null) {
            $(jobTitle).clear();
            $(jobTitle).sendKeys(jobTitleVar);
        }
        if (divisionVar != null) {
            $(division).clear();
            $(division).sendKeys(divisionVar);
        }
        searchBtnClick();
    }

    /**
     * Method to click the search button
     */
    public void searchBtnClick() {
        commonMethods.waitForElementExplicitly(3500);
        commonMethods.waitForElement(driver, searchBtn);
        $(searchBtn).click();
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Method to click a retrieved row's entry
     */
    public void selectRecipient() {
        commonMethods.waitForPageLoad(driver);
        commonMethods.waitForElement(driver, userList, 25);
        $(userList).click();
    }

    /**
     * Method to click on the To Recipient button
     */
    public void clickToBtn() {
        $(addUserToBtn).click();
    }

    /**
     * Method to select the reciepient
     */
    public void selectToRecipient() {
        selectRecipient();
        clickToBtn();
    }


    /**
     * Method to navigate to Global Directory and verify for the title of the page
     */
    public void navigateToGlobalDirAndVerify() {
        getMenuSubmenu("Directory", "Global Directory");
        Assert.assertTrue("Global Directory Page title is not matched", verifyPageTitle("Search - Directory"));
    }

    /**
     * Method to navigate to Project Directory and verify for the title of the page
     */
    public void navigateToProjectDirectory() {
        getMenuSubmenu("Directory", "Project Directory");
        Assert.assertTrue("Project Directory Page title is not matched", verifyPageTitle("Search - Directory"));
    }

    /**
     * Method to click on the OK Button
     */
    public void clickOkBtn() {
        commonMethods.waitForElement(driver, okBtn, 10);
        $(okBtn).click();
    }

    public void addRecipient(String group, Map<String, Object> map) {
        String full_name = map.get("full_name").toString();
        String groupName = full_name.split(" ")[0];
        String familyName = full_name.split(" ")[1];
        String orgName = "";
        if(map.containsKey("org_name")){
             orgName = map.get("org_name").toString();
        }
        commonMethods.waitForElementExplicitly(2000);
        clickGlobalDirectoryLink();
        commonMethods.waitForElementExplicitly(6000);
        fillFieldsAndSearch(groupName, familyName, orgName, null, null);
        selectRecipientGroup(group);
        commonMethods.waitForElementExplicitly(1000);
        clickOkBtn();
    }

    public void addRecipientUnderProject(String group, Map<String, Object> map) {
        String full_name = map.get("full_name").toString();
        String groupName = full_name.split(" ")[0];
        String familyName = full_name.split(" ")[1];
        fillFieldsAndSearch(groupName, familyName, null, null, null);
        selectRecipientGroup(group);
        clickOkBtn();
    }

    public void selectUser() {
        $(selectUser).click();
    }

    public void selectRecipientGroup(String group) {
        selectRecipient();
        String recipientGroup = "//div[@id='searchResultsToolbar']//div[@class='uiButton-label'][contains(text(),'";
        switch (group) {
            case "To":
            case "Sent To":
                $(By.xpath(recipientGroup + "To')]")).click();
                break;
            case "Cc":
                $(By.xpath(recipientGroup + "Cc')]")).click();
                break;
            case "Bcc":
                $(By.xpath(recipientGroup + "Bcc')]")).click();
                break;
            case "Sent From":
                $(By.xpath(recipientGroup + "From')]")).click();
                break;
            case "Add":
                $(addBtn).click();
                break;

        }
    }

    /**
     * Method to select Global directory link
     */
    public void clickGlobalDirectoryLink() {
        if ($(globalDirectoryLink).isDisplayed()) {
            $(globalDirectoryLink).click();
        }
    }

    /**
     * Method to select Project directory link
     */
    public void clickProjectDirectoryLink() {
        if ($(projectDirectoryLink).isDisplayed()) {
            $(projectDirectoryLink).click();
        }
    }

    /**
     * Method to select Multiple Recipients based on Org
     */
    public void selectMultipleRecipients(int numberOfRecipients) {
        verifyAndSwitchFrame();
        selectMultipleEntries(numberOfRecipients);
        $(fromBtn).click();
        commonMethods.waitForElementExplicitly(1000);
        clickOkBtn();
    }

    /**
     * Method to get First user after searching with Org
     *
     * @param map
     * @return
     */
    public String getFirstUser(Map<String, Object> map) {
        String org_name = map.get("org_name").toString();
        $(organizationName).sendKeys(org_name);
        searchBtnClick();
        commonMethods.waitForElement(driver, topUserTxt, 5);
        return $(topUserTxt).getText();
    }

    /**
     * Method to select Multiple entries
     *
     * @param numberOfEntries
     */
    public void selectMultipleEntries(int numberOfEntries) {
        verifyAndSwitchFrame();
        for (int i = 1; i <= numberOfEntries; i++) {
            commonMethods.waitForElementExplicitly(1000);
            $(By.xpath("//table[@id='resultTable']//tr[" + i + "]//input[@name='USERS_LIST']")).click();
        }

    }

    /**
     * Function to get number of users
     *
     * @return
     */
    public ArrayList returnListOfUsers() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(1000);
        ArrayList usersList = new ArrayList();
        List<WebElement> users = driver.findElements(userNames);
        for (int i = 0; i <= users.size() - 1; i++) {
            String optionsText = users.get(i).getText();
            usersList.add(optionsText);
        }
        return usersList;
    }

    /**
     * Function to verify that No users are found from search results
     *
     * @return
     */

    public boolean verifyEmptyRecords() {
        return $(noRecordsMessage).isDisplayed();
    }

    /**
     * Function to search users in Global Directory
     *
     * @param user
     */

    public void globalDirectorySearch(String user) {
        String full_name = commonMethods.getUserData(user, "name");
        String groupName = full_name.split(" ")[0];
        String familyName = full_name.split(" ")[1];
        clickGlobalDirectoryLink();
        fillFieldsAndSearch(groupName, familyName, null, null, null);

    }

    public void clickCreateMailingGroup() {
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, createMailingGroupBtn);
        $(createMailingGroupBtn).click();
        commonMethods.waitForElementExplicitly(500);
    }

    /**
     * Method to verify if the directory page is open
     *
     * @return
     */
    public boolean checkDirectoryPage() {
        if ($(header).isDisplayed()) {
            return true;
        } else return false;
    }

    /**
     * Method to Create a Mailing Group
     *
     * @param groupName,groupUsers
     * @return
     */
    public String createMailingGroup(String groupName, List<String> groupUsers) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, createMailingGroupBtn);
        $(createMailingGroupBtn).click();
        String mailGroupName = groupName + formatter.format(new Date());
        setGroupName(mailGroupName);

        for (String user : groupUsers) {
            $(editUsersBtn).click();
            commonMethods.waitForElement(driver, selectRecipientsHeader);
            commonMethods.waitForElementExplicitly(2000);
            selectRecipient(user);
            commonMethods.waitForElementExplicitly(2000);
            getElementInView(searchBtn);
            $(addUserToBtn).click();
            $(okBtn).click();
        }
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, pageSaveBtn);
        $(pageSaveBtn).click();
        commonMethods.waitForElementExplicitly(2000);
        return mailGroupName;
    }

    /**
     * Method to select receipient on a select directory
     *
     * @param user
     */
    public void selectRecipient(String user) {
        verifyAndSwitchFrame();
        Map<String, Map<String, Object>> jsonMap = dataSetup.loadJsonDataToMap(userDataPath);
        Map<String, Object> userMap = jsonMap.get(user);
        String firstName = userMap.get("full_name").toString().split(" ")[0];
        commonMethods.scrollToTop(driver);
        commonMethods.waitForElementExplicitly(2000);
        $(groupName).clear();
        commonMethods.enterTextValue(groupName,firstName);
        searchButton();
        commonMethods.waitForElementExplicitly(3000);
        By by = By.xpath("//td//a[contains(text(),'" + firstName +"')]//..//..//input[@type='checkbox']");
        $(by).click();
    }

    /**
     * Method to set the Group Name
     *
     * @param groupName
     * @return
     */
    public String setGroupName(String groupName) {
        commonMethods.waitForElement(driver, inputGroupName);
        $(inputGroupName).clear();
        $(inputGroupName).sendKeys(groupName);
        return $(inputGroupName).getText();
    }

    /**
     * Method to search for the group name
     *
     * @param mailGroupName
     * @return
     */
    public void searchGroupName(String mailGroupName) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, groupName);
        $(groupName).sendKeys(mailGroupName);
        $(searchBtn).click();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, dataResults);
        $(firstResult).click();
    }

    /**
     * Method to verify Group Name
     *
     * @param groupName
     */
    public void verifyGroupName(String groupName) {
        commonMethods.waitForElementExplicitly(2000);
        Assert.assertEquals($(inputGroupName).getAttribute("value"), groupName);
    }

    /**
     * Method to verify Mail options
     *
     * @param option
     * @return
     */

    public boolean verifyMailOption(String option) {
        return $(By.xpath("//a[contains(text(),'" + option + "')]")).isDisplayed();
    }

    /**
     * Method to get create guest button is displayed
     */
    public boolean getCreateGuest() {
        return $(createGuestBtn).isDisplayed();
    }

    /**
     * Method to click on create guest
     */
    public void clickCreateGuest() {
        commonMethods.waitForElement(driver, createGuestBtn);
        $(createGuestBtn).click();
    }

    /**
     * Method to click on create guest
     */
    public void searchUserInDirectory(String userAdded) {
        String groupNameInput = userAdded.split(" ")[0];
        String familyNameInput = userAdded.split(" ")[1];
        $(groupName).clear();
        $(familyName).clear();
        $(groupName).sendKeys(groupNameInput);
        $(familyName).sendKeys(familyNameInput);
        searchBtnClick();
    }

    /**
     * Method to return first result on Directory Search
     */
    public String returnFirstResult() {
        return $(userNames).getText();
    }

    /**
     * Method to verify directory labels
     */
    public void verifyDirectoryLabels() {
        Assert.assertTrue($(searchDirectoryHeader).isDisplayed());
        Assert.assertTrue($(createMailingGroupBtn).isDisplayed());
        Assert.assertTrue($(createGuestBtn).isDisplayed());

    }

    /**
     * Method to verify if okay button is present in the screen
     */
    public void verifyOkButton() {
        Assert.assertTrue($(okBtn).isDisplayed());
    }

    /**
     * Method to verify the Search Panel Labels
     */
    public void verifySearchPanelLabels() {
        commonMethods.waitForElement(driver, projectDirectoryLink);
        commonMethods.waitForElement(driver, globalDirectoryLink);
        $(groupName).shouldBe(Condition.appear);
        $(familyName).shouldBe(Condition.appear);
        $(jobTitle).shouldBe(Condition.appear);
        $(division).shouldBe(Condition.appear);
        $(organizationName).shouldBe(Condition.appear);
        $(searchBtn).shouldBe(Condition.appear);
    }

    /**
     * Method to verify if the sub menu options are displayed
     * We are looking for Global Directory and Project Directory
     */
    public void verifySubMenu() {
        Assert.assertTrue(verifySubMenuExist("Global Directory"));
        Assert.assertTrue(verifySubMenuExist("Project Directory"));
    }

    /**
     * Method to verify if the expected messages are displayed in the ui
     *
     * @param text text to verify
     * @return
     */
    public boolean verifyNoResults(String text) {
        return $(noResultsText).getText().contains(text);
    }

    /**
     * Method to verify if the search returns no results
     */
    public void verifyNoResults() {
        Assert.assertTrue($(noSearchResult).isDisplayed());
    }

    /**
     * Method to verify if the search button is displayed
     *
     * @return
     */
    public boolean isSeachBtnDisplayed() {
        return $(searchBtn).isDisplayed();
    }

    /**
     * Method to verify if both the global and project directory tabs are available
     *
     * @return
     */
    public boolean verifyTabs() {
        if ($(projectDirectoryLink).isDisplayed() && $(globalDirectoryLink).isDisplayed()) {
            return true;
        }
        return false;
    }


    /**
     * Method to search for organization by filling the organization field
     *
     * @param orgName
     */
    public void searchOrganization(String orgName) {
        $(organizationName).clear();
        $(organizationName).sendKeys(orgName);
        $(searchBtn).click();
    }

    /**
     * Method to search for the division by filling the division field
     *
     * @param divisionValue
     */
    public void searchDivision(String divisionValue) {
        $(division).sendKeys(divisionValue);
        $(searchBtn).click();
    }

    /**
     * Method to return the column headers of the result table
     * In project tab, by default it appears.
     * In global tab, it is displayed when we have entered a search criteria and click on search.
     *
     * @return
     */
    public List<String> returnColumnHeaders() {
        List<WebElement> elementsList = driver.findElements(columnHeaders);
        List<String> values = new ArrayList<>();
        for (WebElement element : elementsList) {
            values.add(element.getText());
        }
        return values;
    }

    /**
     * Method to return the values in the organization column of the result table
     *
     * @return
     */
    public List<String> returnOrgValues() {
        List<String> values = null;
        for(WebElement element : $$(orgValues)){
            values.add(element.getText());
        }
        return values;
    }

    /**
     * Method to return the values in the organization column of the result table
     *
     * @return
     */
    public List<String> returnColumnValues(String column) {
        List<WebElement> list = new ArrayList<>();
        if (column.equalsIgnoreCase("division")) {
            list = driver.findElements(divisionValues);
        } else if (column.equalsIgnoreCase("organization")) {
            list = driver.findElements(orgValues);
        } else if (column.equalsIgnoreCase("given_name") || column.equalsIgnoreCase("family_name") ||
                column.equalsIgnoreCase("group_name")) {
            list = driver.findElements(full_name);
        } else if (column.equalsIgnoreCase("job_title")) {
            list = driver.findElements(job_title_col);
        }

        List<String> values = new ArrayList<>();
        for (WebElement element : list) {
            values.add(element.getText());
        }
        return values;
    }

    /**
     * Method to click on a mailing group
     *
     * @param groupName
     */
    public void clickGroup(String groupName) {
        commonMethods.waitForElementExplicitly(3000);
        By by = By.xpath("//img[@title='Mailing Group']//..//a[text()='" + groupName + "']");
        commonMethods.waitForElement(driver,by);
        Actions actions = new Actions(driver);
        actions.moveToElement($(by)).click().perform();
        if($(by).isDisplayed()){
            $(by).click();
        }
    }

    /**
     * Delete all mail groups
     */
    public void deleteMailGroup() {
        List<WebElement> groups = driver.findElements(group);
        for (int i = 0; i < groups.size(); i++) {
            $(linkName).click();
            $(deleteBtn).click();
            commonMethods.acceptAlert(driver);
        }
    }

    /**
     * Method to hover on the user type
     *
     * @param identifier
     */
    public void hover(String identifier) {
        Actions actions = new Actions(driver);
        String[] list = identifier.split(" ");
        By givenName = By.xpath("//a[contains(text(),'" + list[0] + "')]//..//img");
        System.out.println($(givenName).isDisplayed());
        actions.moveToElement($(givenName)).build().perform();
    }

    /**
     * Method to verify the icons for user, guest and group
     *
     * @param name
     * @param userType
     * @return
     */
    public boolean verifyIcon(String name, String userType) {
        String[] list = name.split(" ");
        By givenName = By.xpath("//a[contains(text(),'" + list[0] + "')]//..//img");
        if (userType.equalsIgnoreCase("user")) {
            return $(givenName).getAttribute("title").equalsIgnoreCase("user");
        } else if (userType.equalsIgnoreCase("group")) {
            return $(givenName).getAttribute("title").equalsIgnoreCase("Group");
        } else if (userType.equalsIgnoreCase("guest")) {
            return $(givenName).getAttribute("title").equalsIgnoreCase("Guest");
        }
        return false;
    }

    /**
     * Method to click on the values returned in the data table
     *
     * @param id
     */
    public void clickRowEntry(String id) {
        By by = By.xpath("//a[contains(text(),'" + id + "')]");
        $(by).click();
    }

    /**
     * Method to click on the next and the previous button
     *
     * @param option
     */
    public void clickOnPagination(String option) {
        if (option.equalsIgnoreCase("next")) {
            $(nextPage).click();
        } else if (option.equalsIgnoreCase("previous")) {
            $(previousPage).click();
        }
    }

    /**
     * Method to click on the page number and navigate to the page
     *
     * @param number
     */
    public void navigateToPage(int number) {
        By by = By.xpath("//a[text()='" + number + "']");
        commonMethods.waitForElement(driver, by);
        List<WebElement> list = driver.findElements(by);
        $(list.get(0)).click();
    }

    /**
     * Method to return the name of the user/group
     *
     * @return
     */
    public String returnName() {
        return $(nameCell).getText();
    }

    /**
     * Method to click on invite user button
     */
    public void clickInviteUser() {
        $(inviteUserBtn).click();
    }

    /**
     * Method to invite a user into a project
     * @param name
     */
    public void inviteUser(String name) {
        $(searchUserTxtBox).clear();
        $(searchUserTxtBox).sendKeys(name);
        commonMethods.waitForElementExplicitly(2500);
        $(searchUserTxtBox).sendKeys(Keys.ENTER);
        $(emailNotificationChkBox).setSelected(true);
        $(inviteSpan).click();
    }

    public void verifyLinkElements()
    {
        Assert.assertTrue("Search directory header is not displayed", $(searchDirectoryHeader).isDisplayed());
        Assert.assertTrue("Create Mail Group button is not displayed", $(createMailingGroupBtn).isDisplayed());
        Assert.assertTrue("Create Guest button is not displayed", $(createGuestBtn).isDisplayed());
        Assert.assertTrue("Invite User button is not displayed", $(inviteUser).isDisplayed());
    }
}
