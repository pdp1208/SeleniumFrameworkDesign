package com.oracle.babylon.Utils.setup.dataStore.pojo;

/**
 * Class which contains the fields related to document, along with the respective setters and getters
 * Author : susgopal
 */
public class Document {
    private String documentNumber;
    private String documentStatusId;
    private String revision;
    private String comments;
    private String hasFile;
    private String[] attribute1;
    private String[] attribute2;
    private String discipline;
    private String documentTypeId;
    private String title;
    private String revisionDate;
    private String project;
    private String username;
    private String accessList;
    private String author;
    private String[] category;
    private String reference;
    private String[] selectList1;
    private String[] selectList2;
    private String[] vdrcode;
    private String dateCreated;
    private String dateModified;


    public String getDocumentNumber() {
        return documentNumber;
    }

    public void setDocumentNumber(String documentNumber) {
        this.documentNumber = documentNumber;
    }

    public String getDocumentStatusId() {
        return documentStatusId;
    }

    public void setDocumentStatusId(String documentStatusId) {
        this.documentStatusId = documentStatusId;
    }

    public String getRevision() {
        return revision;
    }

    public void setRevision(String revision) {
        this.revision = revision;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getHasFile() {
        return hasFile;
    }

    public void setHasFile(String hasFile) {
        this.hasFile = hasFile;
    }

    public String[] getAttribute1() {
        return attribute1;
    }

    public void setAttribute1(String[] attribute1) {
        this.attribute1 = attribute1;
    }

    public String[] getAttribute2() {
        return attribute2;
    }

    public void setAttribute2(String[] attribute2) {
        this.attribute2 = attribute2;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getDiscipline() {
        return discipline;
    }

    public void setDiscipline(String discipline) {
        this.discipline = discipline;
    }

    public String getDocumentTypeId() {
        return documentTypeId;
    }

    public void setDocumentTypeId(String documentTypeId) {
        this.documentTypeId = documentTypeId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getRevisionDate() {
        return revisionDate;
    }

    public void setRevisionDate(String revisionDate) {
        this.revisionDate = revisionDate;
    }

    public String getProject() {
        return project;
    }

    public void setProject(String project) {
        this.project = project;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getAccessList() {
        return accessList;
    }

    public void setAccessList(String accessList) {
        this.accessList = accessList;
    }

    public String[] getCategory() {
        return category;
    }

    public void setCategory(String[] category) {
        this.category = category;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String[] getSelectList1() {
        return selectList1;
    }

    public void setSelectList1(String[] selectList1) {
        this.selectList1 = selectList1;
    }

    public String[] getVdrCode() {
        return vdrcode;
    }

    public void setVdrCode(String[] vdrcode) {
        this.vdrcode = vdrcode;
    }

    public String getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(String dateCreated) {
        this.dateCreated = dateCreated;
    }

    public String getDateModified() {
        return dateModified;
    }

    public void setDateModified(String dateModified) {
        this.dateModified = dateModified;
    }

    public String[] getSelectList2() {
        return selectList2;
    }

    public void setSelectList2(String[] selectList2) {
        this.selectList2 = selectList2;
    }
}
