package com.oracle.babylon.pages.Organization;

import com.codeborne.selenide.WebDriverRunner;
import com.github.javafaker.Faker;
import com.oracle.babylon.Utils.helper.Navigator;
import com.oracle.babylon.Utils.setup.dataStore.pojo.Organization;
import com.oracle.babylon.Utils.setup.dataStore.pojo.User;
import org.json.simple.parser.ParseException;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Map;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class RegisterOrganizationPage extends Navigator {

    //Initialization of the Web Elements
    private By orgNameTxtBox = By.name("ORG_NAME");
    private By CRNTxtBox = By.name("ABN");
    private By addressTxtBox = By.name("POSTAL_ADDRESS1");
    private By addressTxtBox2 = By.name("POSTAL_ADDRESS2");
    private By cityTxtBox = By.name("POSTAL_SUBURB");
    private By stateTxtBox = By.name("POSTAL_STATE");
    private By countrySelectBox = By.name("POSTAL_COUNTRY");
    private By postCodeTxtBox = By.name("POSTAL_POSTCODE");
    private By tradingNameTxtBox = By.name("TRADING_NAME");
    private By orgAbbreviationTxtBox = By.name("ORG_CODE");
    private By firstNameTxtBox = By.name("USER_FIRST_NAME");
    private By lastNameTxtBox = By.name("USER_LAST_NAME");
    private By emailIdTxtBox = By.name("EMAIL");
    private By phoneTxtBox = By.name("USER_PHONE");
    private By loginNameTxtBox = By.name("USER_NAME");
    private By passwordTxtBox = By.name("PASSWORD");
    private By confirmPasswordTxtBox = By.name("passwordConfirm");
    private By acceptTermsChkBox = By.name("acceptTermsOfService");
    private By registerBtn = By.xpath("//button//span[text()='Register']");
    private By thankYouMessage = By.xpath("//p[text()='Thank you, your registration is now being processed.']");
    private By registerYourOrganization = By.xpath("//div[text()='Register your organization']");
    private By aconexLogo=By.xpath("//div[@class='acxOrgRegistrationHeader-logo']");
    private By notificationBannerMsg=By.xpath("//div[@class='auiMessage info']");
    private By popOverContent=By.xpath("//div[@class='auiPopover-content']//span[@class='ng-binding ng-scope']");
    protected By postalCountryErrorMsg=By.xpath("//select[@name='POSTAL_COUNTRY']//..//..//*[contains(text(),'This field is required')]");
    protected By postalCountryLabel=By.xpath("(//select[@name='POSTAL_COUNTRY']//..//..//*[contains(@class,'ng-binding')])[1]");
    protected By postalCountryOptions=By.xpath("//select[@name='POSTAL_COUNTRY']//option");
    private By requiredAllMsg=By.xpath("//span[contains(text(),'Please complete all required fields.')]");
    private By termsOfUse=By.xpath("//div[@class='terms-of-use-data']");
    private By consentContent=By.xpath("//label[@class='auiField-checkbox']//label");
    private By notesSection1=By.xpath("(//div[@class='auiText-small auiText-muted acxOrgRegistrationForm-note']//p)[1]");
    private By notesSection2=By.xpath("(//div[@class='auiText-small auiText-muted acxOrgRegistrationForm-note']//p)[2]");
    private By emailFormatMsg=By.xpath("//span[contains(text(),'The email address you entered is invalid.')]");
    private By uniqueEmail=By.xpath("//span[@ng-message='unique']");
    private By matchPassword=By.xpath("//span[@ng-message='match']");
    private By suggestedAbbreviations=By.xpath("//p[@class='acxOrgRegistrationForm-orgCodeSuggestionHint ng-binding ng-scope']//..//..//p");
    private By suggestedAbbreviationsLabel=By.xpath("//p[contains(text(),'Suggested abbreviations')]");
    private By successIndicator=By.xpath("//div[@class='acxOrgRegistrationSuccess-processIndicator']");

    Faker faker = new Faker();

    public void verifyPage() {
        commonMethods.waitForElement(driver, registerYourOrganization, 60);
        if (!$(registerYourOrganization).isDisplayed()) {
            Assert.fail("Navigation to Register organization page failed");
        }

    }

    /**
     * Fill up all the fields of the Create Organization page using Selenium libraries
     */
    public void fillOrganizationDetails() {
        //Initialization of references
        this.driver = WebDriverRunner.getWebDriver();

        //Get Organization and User pojos
        commonMethods.waitForElementExplicitly(1000);
        Organization organization = dataStore.getOrganizationInfo("organization");
        User userInfo = dataStore.getUser("user");
        commonMethods.waitForPageLoad(driver);
        commonMethods.waitForElement(this.driver, orgNameTxtBox, 3);
        //Filling up the organization fields in UI by using Selenide
        $(orgNameTxtBox).sendKeys(organization.getOrganizationName());
        $(CRNTxtBox).sendKeys(organization.getCrn());
        $(addressTxtBox).sendKeys(organization.getAddress());
        $(addressTxtBox2).sendKeys(organization.getAddress2());
        $(cityTxtBox).sendKeys(organization.getCity());
        $(stateTxtBox).sendKeys(organization.getCounty());
        Select select = new Select($(countrySelectBox));
        select.selectByValue(organization.getCountry());
        $(postCodeTxtBox).sendKeys(organization.getPostcode());
        //$(tradingNameTxtBox).sendKeys(organization.getTradingName());
        $(orgAbbreviationTxtBox).sendKeys(organization.getOrgAbbreviation());
        $(firstNameTxtBox).sendKeys(organization.getContactFirstName());
        $(lastNameTxtBox).sendKeys(organization.getContactLastName());
        $(emailIdTxtBox).sendKeys(organization.getContactEmailAddress());
        $(phoneTxtBox).clear();
        $(phoneTxtBox).sendKeys(organization.getContactPhone());
        $(loginNameTxtBox).sendKeys(userInfo.getUsername());
        $(passwordTxtBox).sendKeys(userInfo.getPassword().toString());
        $(confirmPasswordTxtBox).sendKeys(userInfo.getPassword().toString());
        $(acceptTermsChkBox).setSelected(true);
        commonMethods.waitForElementExplicitly(500);
        $(registerBtn).click();
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(this.driver, thankYouMessage, 60);
        $(thankYouMessage).isDisplayed();
    }

    /**
     * Function to fill the details the organization to a file
     *
     * @return a map of user
     * @throws IOException
     * @throws ParseException
     */
    public User enterOrgUserDetailsToFile(String userId) {
        Organization organization = dataStore.getOrganizationInfo("organization");
        User userInfo = dataStore.getUser("user");
        String[] keys = {"username", "password", "full_name", "org_name"};
        Map<String, Map<String, Object>> mapOfMap = new Hashtable<>();
        Map<String, Object> valueMap = new Hashtable<>();
        valueMap.put(keys[0], userInfo.getUsername());
        valueMap.put(keys[1], userInfo.getPassword());
        valueMap.put(keys[2], userInfo.getFullName());
        valueMap.put(keys[3], organization.getOrganizationName());
        mapOfMap.put(userId, valueMap);
        dataSetup.fileWrite(userId, mapOfMap, userDataPath);
        return userInfo;
    }
    /**
     * Function to verify Logo
     */
    public boolean verifyLogo()
    { return $(aconexLogo).isDisplayed();}
    /**
     * Function to return notification banner message
     */
    public String getNotificationBannerMsg()
    { return $(notificationBannerMsg).getText();}
    /**
     * Function to return field name in register page
     */
    public String getFieldName(String fieldProperty)
    {
        return $(By.xpath("(//input[@name='"+fieldProperty+"']//..//..//*[contains(@class,'ng-binding')])[1]")).getText();
    }
    /**
     * Function to return Max Length
     */
    public String getMaxLength(String fieldProperty)
    { return $(By.xpath("//input[@name='"+fieldProperty+"']")).getAttribute("maxlength");}
    /**
     * Function to validate Mandatory Error Message
     */
    public Boolean validateMandatoryErrorMsg(String fieldProperty)
    { return $(By.xpath("//input[@name='"+fieldProperty+"']//..//..//*[contains(text(),'This field is required')]")).isDisplayed();}
    /**
     * Function to validate the Country Drop Down in Register page
     */
    public void verifyCountryDropDown(String label,int optionSize)
    {
        Assert.assertEquals(label,$(postalCountryLabel).getText());
        Assert.assertTrue($(postalCountryErrorMsg).isDisplayed());
        Assert.assertEquals(optionSize,$$(postalCountryOptions).size());
    }
    /**
     * Function to click Register button
     */
    public void clickRegisterBtn()
    {
        commonMethods.waitForElement(driver,registerBtn);
        $(registerBtn).click();
    }
    /**
     * Function to get Tool Tip
     */
    public String getToolTipMessage(String fieldProperty)
    {
        $(By.xpath("//input[@name='"+fieldProperty+"']//..//button[@title='More information']")).click();
        commonMethods.waitForElement(driver,popOverContent);
        return $(popOverContent).getText();
    }
    /**
     * Function to return required all fields message in register page
     */
    public boolean verifyRequiredFieldsMsg()
    { return $(requiredAllMsg).isDisplayed(); }

    /**
     * Function to return terms/notes message present in the register page
     */
    public String getTerms(String reference)
    {
        if(reference.contains("Terms"))
            return (reference.contains("use"))?$(termsOfUse).getText():$(consentContent).getText();
        else
            return (reference.contains("Section1"))?$(notesSection1).getText():$(notesSection2).getText();
    }
    /**
     * Function to verify the minimum error message in register page
     */
    public String getMinimumMsg(String fieldProperty,int length)
    {

        $(By.xpath("//input[@name='"+fieldProperty+"']")).sendKeys(faker.number().digits(2));
       return $(By.xpath("//input[@name='"+fieldProperty+"']//..//..//span[@ng-message]")).getText();
    }
    /**
     * Function to validate Email Type and format
     */
    public void validateEmailInput()
    {
        $(emailIdTxtBox).sendKeys(faker.company().name().substring(0,3));
        clickRegisterBtn();
        Assert.assertTrue($(emailFormatMsg).isDisplayed());
    }
    /**
     * Function to verify existing login name
     */
    public String existingLoginName(String user)
    {
        $(loginNameTxtBox).sendKeys(commonMethods.getUserData(user,"username"));
        clickRegisterBtn();
        return $(uniqueEmail).getText();
    }
    /**
     * Function to validate the password mismatch error message
     */
    public String validatePasswordMismatch()
    {
        $(passwordTxtBox).sendKeys(faker.company().name().substring(2,5));
        $(confirmPasswordTxtBox).sendKeys(faker.company().name().substring(2,5));
        clickRegisterBtn();
        return $(matchPassword).getText();
    }
    /**
     * Function to verify the success indicator
     */
    public Boolean getSuccessIndicator()
    { return $(successIndicator).isDisplayed(); }
    /**
     * Function to validate the Suggested Abbreviations
     */
    public int validateSuggestedAbbreviations(String orgName)
    {
        $(orgNameTxtBox).sendKeys(orgName);
        $(orgAbbreviationTxtBox).click();
        $(tradingNameTxtBox).click();
        commonMethods.waitForElement(driver,suggestedAbbreviationsLabel);
        return $$(suggestedAbbreviations).size();
    }
    /**
     * Function to return WhatNext Message
     */
    public String getWhatNextMessage(String index)
    {
        commonMethods.waitForElement(driver,thankYouMessage);
        return (index.contains("2"))?$(By.xpath("(//p[@class='ng-binding'])["+index+"]")).getText():$(By.xpath("(//p[@class='ng-binding'])["+index+"]")).getText();
    }
    /**
     * Function to return user disable message
     */
    public String getDisabledMsg()
    {  return $(By.xpath("//div[@id='main']")).getText(); }
}


