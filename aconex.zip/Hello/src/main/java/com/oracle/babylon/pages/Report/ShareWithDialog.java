package com.oracle.babylon.pages.Report;

import com.oracle.babylon.Utils.helper.Navigator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;
import java.util.List;

import static com.codeborne.selenide.Condition.appear;
import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Selenide.$;

public class ShareWithDialog extends Navigator {

    private By shareWithDialog = By.cssSelector("#shareWithDialog");
    private By shareWithDropDown = By.cssSelector("#select-share-with-list");
    private By save = By.cssSelector("#shareWithBtnSave");
    private By cancel = By.cssSelector("#shareWithBtnCancel");
    private By shareSuccessMessage = By.xpath("//div[contains(@class,'success')]/div[contains(text(),'Report shared successfully')]");
    private By reportNameLabel = By.xpath("//*[contains(@class,'report-name-label')]");
    private String projectScopeRadioLocator = "//label[contains(text(),'SCOPE')]/preceding-sibling::input[@type='radio']";
    
    /**
     * Method to wait untill share with dialog appears.
     *
     */
    public void waitForShareWithDialogToOpen(){
        $(shareWithDialog).waitUntil(appear, 6000);
    }

    /**
     * Method to set 'share wtih' option for the report.
     *
     * @param shareWith - 'Share with' option to be selected.
     */
    public void selectShareWithScope(String shareWith){
        Select shareWithList = new Select($(shareWithDropDown).waitUntil(appear, 6000));
        shareWithList.selectByValue(shareWith);
        $(save).click();
        $(shareSuccessMessage).waitUntil(appear, 15000);
        $(shareSuccessMessage).waitUntil(disappear, 10000);
        commonMethods.waitForElementExplicitly(10000);
    }

    /**
     * Method to set 'share wtih' option for the report.
     *
     * @param shareWith 'Share with' option to be selected.
     * @param scope 'scope' option to be selected.
     */
    public void selectShareWithAndScope(String shareWith, String scope){
        Select shareWithList = new Select($(shareWithDropDown).waitUntil(appear, 6000));
        if(!shareWith.equalsIgnoreCase("EMPTY")) {
            shareWithList.selectByValue(shareWith);
        }
        if(!scope.equalsIgnoreCase("EMPTY")) {
            $(By.xpath(projectScopeRadioLocator.replace("SCOPE", scope))).click();
        }
        $(save).click();
        $(shareSuccessMessage).waitUntil(appear, 15000);
        $(shareSuccessMessage).waitUntil(disappear, 10000);
    }

    /**
     * Method to get list of available 'share wtih' option for the report.
     *
     */
    public List<String> getShareWithOptions(){
        List<String> availableOptions = new ArrayList<>();
        for(WebElement element : new Select($(shareWithDropDown)).getOptions()){
            if(element.getAttribute("class").isEmpty() || !element.getAttribute("class").equalsIgnoreCase("hidden")) {
                availableOptions.add(element.getAttribute("id"));
            }
        }
        $(cancel).click();
        return availableOptions;
    }

    /**
     * Get report name dispalyed on share with dialog.
     *
     */
    public String getReportNameDisplayedOnShareWithDialog(){
        return $(reportNameLabel).waitUntil(appear, 5000).getText();
    }

    /**
     * Close share with dialog.
     *
     */
    public void close(){
        $(cancel).waitUntil(appear, 5000).click();
    }
}