package com.oracle.babylon.pages.Tenders;

import com.oracle.babylon.pages.Directory.DirectoryPage;
import com.oracle.babylon.pages.Document.DocumentPage;
import com.oracle.babylon.pages.Document.DrawingsPage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Selenide.*;

public class TenderInvitationPage extends TenderPage {

    private By pageTitle = By.xpath("//h1[contains(text(),'New Tender')]");
    private By zipDownload=By.xpath("//button[@title='Download attachments as a single zip file']");
    private By tenderNumber = By.xpath("//input[@id='tenderNo']");
    private By tenderTitle = By.xpath("//input[@id='title']");
    private By deleteRecipient = By.xpath("//div[contains(@id,'recipients')]//div[@class='auiIcon trash']");
    private By contactRecipient = By.xpath("//div[contains(@id,'recipients')]//input");
    private By coverLetter = By.xpath("//textarea[@id='coverLetter']");
    private By attachBtn = By.xpath("//button[@id='btnAttach_page']//div[contains(text(),'Attach')]");
    private By saveToDraftBtn = By.xpath("//div[@id='tenderSubToolbar']//button[contains(.,'Save To Draft')]");
    private By invitationAccess = By.xpath("//input[@id='allowAccessWhenClosed']");
    private By submission = By.xpath("//input[@id='allowSubmissionWhenClosed']");
    private By aconexSubmission = By.xpath("//input[@id='aconexSubmission']");
    private By lockBox = By.xpath("//input[@id='lockBox']");
    private By addressBookBtn = By.xpath("//div[contains(text(),'Address Book')]");
    private By closeBtn = By.xpath("//button[@id='btnexcludedDocs_ok']//div[contains(text(),'Close')]");
    SimpleDateFormat formatter = new SimpleDateFormat("dd-HH-mm-ss");
    private By okBtn = By.xpath("//div[contains(text(),'OK')]");
    private static String tender;
    private By attachDocFromDropDown = By.xpath("//li[@class='uiMenu-item']//div[contains(text(),'Documents')]");
    private DocumentPage documentPage = new DocumentPage();
    private DrawingsPage drawingsPage = new DrawingsPage();
    private By attachmentsLabel = By.xpath("//span[text()='Attachments']");
    private By filesLabel = By.xpath("//div[text()='Files']");
    private By documentsLabel = By.xpath("//div[text()='Documents']");
    private By tenderInvTab = By.xpath("//div[text()='Create New']//parent::div//div[2]");
    private By hourField = By.xpath("//span[@id='closingDateTimePicker']//select[1]");
    private By minField = By.xpath("//span[@id='closingDateTimePicker']//select[2]");
    private By secField = By.xpath("//span[@id='closingDateTimePicker']//select[3]");
    private By callOutField = By.xpath("//div[@class='calloutContent']");
    private By toolTip = By.xpath("//div[@class='info-icon']");

    private By fileIcon = By.xpath("//div[@title='Open File']");
    private By transmittalHeader = By.xpath("//h1");
    private By printRequestBtn = By.xpath("//button[contains(@title,'Send selected documents to a Print Shop')]");
    private By attachDocuments = By.xpath("//div[@class='attachmentsWrapper']//div[@id='checkboxselect']");
    private By createSubmissionBtn = By.xpath("//button[@id='btnCreateSubmission']");
    private By submittedValue = By.xpath("//div[text()='Submitted']");
    private By localFileCancelBtn = By.xpath("//button[@id='attachLocalFile-cancel']");
    private By tenderNumberData = By.xpath("//label[text()='Tender No']//..//following::td//label");
    private By titleData = By.xpath("//label[text()='Title']//..//following::td//label");
    private By submittedTenderLink = By.xpath("//span[@class='textlink']");
    private By warningMessage = By.xpath("//li[@class='message warning']//div");
    private By noteMessage = By.xpath("//li[@class='message note']//div");
    private By successMsg = By.xpath("//div[text()='The tender has been successfully sent.']");
    private By dataNoResults = By.xpath("//div[@class='dataNoResults']");
    private By cancelBtn = By.xpath("//button[@title='Cancel']");
    private By sentDate = By.xpath("//div[@id='recipientsGrid']//tr[contains(@class,'dataRow')]//td[3]//div");
    private By viewedDate = By.xpath("//div[@id='recipientsGrid']//tr[contains(@class,'dataRow')]//td[4]//div");
    private By recipientTxtBox = By.xpath("//input[contains(@value,'Add a recipient')]");
    private By editBtn = By.xpath("//button[@id='btnEditTender']");
    private By coverLetterTxtArea = By.xpath("//textArea[@id='coverLetter']");
    private By addRecipientsBtn = By.xpath("//button[@id='btnAddRecipients']");
    private By declineInviteBtn = By.xpath("//button[@id='btnDecline']");
    private By declineCommit = By.xpath("//button[@id='pnlDeclineTender-commit']");
    private By documentCheckBox=By.xpath("//tbody//input[@type='checkbox']");

    /**
     * Method to navigate to create tender invitation page
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Tenders", "Tender Invitation");
        $(loadingIcon).should(disappear);
        Assert.assertTrue("Tender Invitation Page title is not matched", verifyPageTitle(pageTitle));
    }


    public boolean verifyPageTitle() {
        return verifyPageTitle(pageTitle);
    }

    /**
     * Method to enter the invitation details
     *
     * @param data
     */
    public void enterInvitationDetails(String data) {
        switchTo().defaultContent();
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(3000);
        Map<String, String> table = dataStore.getTable(data);
        for (String tableData : table.keySet()) {
            switch (tableData) {
                case "Title":
                    Date dt2 = new Date();
                    String tenderTitle = table.get(tableData) + " " + formatter.format(dt2);
                    enterTenderTitle(tenderTitle);
                    break;
                //aded a case to enter Tender title without appending closing date to it.
                case "Bid Title":
                    tenderTitle = table.get(tableData);
                    enterTenderTitle(tenderTitle);
                    break;
                case "Tender No":
                    Date dt1 = new Date();
                    String tenderNum = table.get(tableData) + " " + formatter.format(dt1);
                    tender = tenderNum;
                    enterTenderNumber(tenderNum);
                    break;
                case "Bid Number":
                    tenderNum = table.get(tableData);
                    tender = tenderNum;
                    enterTenderNumber(tenderNum);
                    break;
                case "Invitation Access":
                    setInvitationAccess(table.get(tableData));
                    break;
                case "Closing Date":
                    String[] closingDateTime = table.get(tableData).split(",");
                    String day = closingDateTime[0];
                    String date = commonMethods.getDate(configFileReader.getTimeZone(), day);
                    String[] time = closingDateTime[1].split(":");
                    enterClosingDate(date, time);
                    commonMethods.waitForElementExplicitly(5000);
                    break;
                case "Initiator Contact":
                    commonMethods.waitForElementExplicitly(5000);
                    String[] initiators = table.get(tableData).split(",");
                    for (String initiator : initiators) {
                        Map<String, Map<String, Object>> mapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
                        Map<String, Object> userMap = mapOfMap.get(initiator);
                        String fullName = userMap.get("full_name").toString();
                        //clickAddressBook();
                        enterContactInitiator(fullName);
                    }
                    commonMethods.waitForElementExplicitly(1000);
                    break;
                case "Recipients":
                    String[] recipients = table.get(tableData).split(",");
                    for (String recipient : recipients) {
                        Map<String, Map<String, Object>> mapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
                        Map<String, Object> userMap = mapOfMap.get(recipient);
                        String fullName = userMap.get("full_name").toString();
                        String orgName = userMap.get("org_name").toString();
                        clickAddressBook();
                        enterContactRecipient(fullName, orgName);
                    }
                    commonMethods.waitForElementExplicitly(1000);
                    break;
                case "Attachment":
                    String[] doc = table.get(tableData).split(",");
                    attachDocument(doc[0], doc[1]);
                    break;
                case "Local Attachment":
                    attachLocalFile(table.get(tableData));
                    break;
                case "Submit after closing date":
                    setSubmission(tableData);
            }
        }
    }

    public String draftTenderInvitation(String data) {
        enterInvitationDetails(data);
        clickSaveToDraft();
        return tender;
    }

    public String createTenderInvitation(String data) {
        enterInvitationDetails(data);
        sendTender();
//        clickOk();
        return tender;
    }


    /**
     * Method to enter tender number
     *
     * @param number as tender number
     */
    public void enterTenderNumber(String number) {
        verifyAndSwitchFrame();
        $(tenderNumber).clear();
        $(tenderNumber).sendKeys(number);
    }

    /**
     * Method to enter tender number
     *
     * @param title as title
     */
    public void enterTenderTitle(String title) {
        verifyAndSwitchFrame();
        $(tenderTitle).clear();
        $(tenderTitle).sendKeys(title);
    }

    /**
     * Method to enter contact recipient
     *
     * @param name as initiator
     */
    public void enterContactRecipient(String name, String orgName) {
        verifyAndSwitchFrame();
        Map<String, Object> map = new HashMap<>();
        map.put("full_name", name);
        map.put("org_name", orgName);
        DirectoryPage directoryPage = new DirectoryPage();
        directoryPage.addRecipient("Add", map);
    }

    public void enterRecipientName(String name) {
        verifyAndSwitchFrame();

        $(recipientTxtBox).click();
        $(recipientTxtBox).sendKeys(name);
        commonMethods.waitForElementExplicitly(2000);
        $(recipientTxtBox).sendKeys(Keys.ENTER);
        commonMethods.waitForElementExplicitly(3000);


    }

    /**
     * Method to set invitation access
     *
     * @param access as true or false
     */
    public void setInvitationAccess(String access) {
        verifyAndSwitchFrame();
        $(invitationAccess).setSelected(Boolean.parseBoolean(access));

    }

    /**
     * Method to set submission
     *
     * @param access as true or false
     */
    public void setSubmission(String access) {
        $(submission).setSelected(Boolean.parseBoolean(access));

    }

    /**
     * Method to set Aconex submission
     *
     * @param access as true or false
     */
    public void setAconexSubmission(String access) {
        verifyAndSwitchFrame();
        commonMethods.scrollToTop(driver);
        $(aconexSubmission).setSelected(Boolean.parseBoolean(access));
    }


    /**
     * Method to set Lock Box
     *
     * @param access as true or false
     */
    public void setLockBox(String access) {
        commonMethods.scrollToTop(driver);
        $(lockBox).setSelected(Boolean.parseBoolean(access));
    }

    /**
     * Method to click save to draft button
     */
    public void clickSaveToDraft() {
        commonMethods.waitForElement(driver, saveToDraftBtn);
        commonMethods.scrollToTop(driver);
        $(saveToDraftBtn).click();
    }

    /**
     * Method to click send button
     */
    public void sendTender() {
        commonMethods.waitForElementExplicitly(3000);
        verifyAndSwitchFrame();
        commonMethods.scrollToTop(driver);
        commonMethods.waitForElement(driver, sendBtn, 30);
        $(sendBtn).click();
        commonMethods.waitForElementExplicitly(1000);
        clickOk();
    }

    public void clickSendBtn() {
        commonMethods.scrollToTop(driver);
        commonMethods.waitForElement(driver,sendBtn);
        $(sendBtn).click();
    }


    /**
     * Method to click ok button
     */
    public void clickOk() {
        if ($(okBtn).isDisplayed()) {
            $(okBtn).click();
        }
    }


    /**
     * Method to click Address Bok button
     */
    public void clickAddressBook() {
        verifyAndSwitchFrame();
        $(addressBookBtn).click();
    }

    /**
     * Method to click on attach button
     */
    public void clickAttachBtn() {
        driver.switchTo().defaultContent();
        verifyAndSwitchFrame();
        getElementInView(attachBtn);
        commonMethods.clickOnElement(attachBtn);
    }

    /**
     * Method to click on close button
     */
    public void clickCloseBtn() {
        driver.switchTo().defaultContent();
        verifyAndSwitchFrame();
        getElementInView(closeBtn);
        commonMethods.clickOnElement(closeBtn);
    }

    /**
     * Function to Attach a Document from Tender Invitation page
     *
     * @param documentNum
     */
    public void attachDocument(String documentNum, String source) {
        verifyAndSwitchFrame();
        // getElementInView(attachDropDown);
        commonMethods.waitForElement(driver, attachDropDown);
        $(attachDropDown).click();
        $(attachDocFromDropDown).click();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.switchToFrame(driver, "attachDocs_iframe");
        if (source.equals("Drawings")) {
            drawingsPage.clickOnDrawings();
        }
        commonMethods.waitForElementExplicitly(2000);
        String[] docList = documentNum.split(";");
        String searchString = "";
        for(String document:docList){
            searchString = searchString + commonMethods.returnDocNumberInJson(document) + " OR ";
        }
        searchString = searchString.substring(0, searchString.length()-4);
        documentPage.searchDocumentNo(searchString);
        sleep(1000);
        if (source.equals("Drawings")) {
            drawingsPage.clickOnListView();
        }
        documentPage.selectAllRecords();
        driver.switchTo().defaultContent();
        verifyAndSwitchFrame();
        $(attachBtn).click();
        commonMethods.waitForElement(driver, closeBtn, 35);
        $(closeBtn).click();
        commonMethods.scrollToTop(driver);
    }

    /**
     * Method to return the recipient name from the text area
     *
     * @param userId
     * @return
     */
    public boolean returnRecipientDisplayed(String userId) {
        Map<String, Map<String, Object>> mapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
        Map<String, Object> userMap = mapOfMap.get(userId);
        String organization = userMap.get("org_name").toString();
        String fullName = userMap.get("full_name").toString();
        By by = By.xpath("//*[contains(text(),'" + fullName + " - " + organization + "')]");
        commonMethods.waitForElementExplicitly(500);
        return $(by).isDisplayed();
    }

    public void verifyLabels() {
        commonMethods.waitForElement(driver, documentsLabel);
        Assert.assertTrue($(documentsLabel).isDisplayed());
        Assert.assertTrue($(filesLabel).isDisplayed());
        Assert.assertTrue($(attachmentsLabel).isDisplayed());
    }


    /**
     * Method to validate the sub menu
     *
     * @return
     */
    public boolean verifySubMenu() {
       return verifySubMenuExist("Tender Invitation");
    }

    /**
     * Method to validate if all the required
     * buttons are displayed
     */
    public void verifyBtn() {
        Assert.assertTrue($(saveToDraftBtn).isDisplayed());
        Assert.assertTrue($(sendBtn).isDisplayed());
        Assert.assertTrue($(addressBookBtn).isDisplayed());
        getElementInView(attachDropDown);
        Assert.assertTrue($(attachDropDown).isDisplayed());
    }

    /**
     * Verify whether the required dropdown is present
     */
    public void verifyDropDown() {
        Assert.assertTrue($(hourField).isDisplayed()
                && $(hourField).getAttribute("class").contains("isRequired"));
        Assert.assertTrue($(minField).isDisplayed()
                && $(minField).getAttribute("class").contains("isRequired"));
        Assert.assertTrue($(secField).isDisplayed()
                && $(secField).getAttribute("class").contains("isRequired"));

    }

    /**
     * Verify if the required text box are present
     */
    public void verifyTxtBox() {
        Assert.assertTrue($(tenderNumber).isDisplayed() && $(tenderNumber).getAttribute("class").contains("isRequired"));
        Assert.assertTrue($(tenderTitle).isDisplayed() && $(tenderTitle).getAttribute("class").contains("isRequired"));
        Assert.assertTrue($(contactInitiator).isDisplayed() && $(contactInitiator).getAttribute("class").contains("isRequired"));
        Assert.assertTrue($(contactRecipient).isDisplayed() && $(contactRecipient).getAttribute("class").contains("isRequired"));
        Assert.assertTrue($(coverLetter).isDisplayed() && !$(coverLetter).getAttribute("class").contains("isRequired"));

    }


    /**
     * Verify if the required check boxes are present
     */
    public void verifyCheckBox() {
        Assert.assertTrue($(invitationAccess).isDisplayed() && $(invitationAccess).isSelected());
        Assert.assertTrue($(aconexSubmission).isDisplayed() && $(aconexSubmission).isSelected());
        Assert.assertTrue($(lockBox).isDisplayed() && $(lockBox).isSelected());
        Assert.assertTrue($(submission).isDisplayed() && $(submission).isSelected());
    }

    /**
     * Method to verify the text message of the tool tip
     * @param messages
     */
    public void verifyToolTip(List<String> messages) {
        commonMethods.scrollToTop(driver);
        $(toolTip).click();
        String uiText = $(callOutField).getText();
        for (String message : messages) {
            Assert.assertTrue(uiText.contains(message));
        }
    }


    /**
     * Method to return the tender number field value
     *
     * @return
     */
    public String tenderNumField() {
        return $(tenderNumber).getValue();
    }

    /**
     * Method to click on the File Icon
     */
    public void clickFileIcon() {
        $(fileIcon).click();
    }


    /**
     * Method to clear the recipients value from the
     */
    public void clearRecipients() {
        commonMethods.scrollToTop(driver);
        commonMethods.waitForElementExplicitly(3000);
        $(deleteRecipient).click();
    }

    /**
     * Method to clear the recipients value from the
     */
    public void clearRecipient(String username) {
        commonMethods.scrollToTop(driver);
        By xpath = By.xpath("//div[contains(text(),'" + username + "')]//..//..//..//td[2]//div[@class='auiIcon trash']");
        $(xpath).click();
    }


    public void validateMandatoryFieldCheck(List<String> messageList) {
        for (String elementValue : messageList) {
            By checkStar = By.xpath("//*[contains(text(),'" + elementValue + "')]//span[@class='required']");
            Assert.assertTrue($(checkStar).getText().equalsIgnoreCase("*"));
            By isRequiredField = By.xpath("//*[contains(text(),'" + elementValue + "')]//..//..//*[contains(@class,'isRequired invalid')]");
            Assert.assertTrue($(isRequiredField).isDisplayed());

        }
    }

    /**
     * Return the header from the tender transmittal mail
     *
     * @return
     */
    public String returnTitle() {
        return $(titleData).getText();
    }

    /**
     * Return the header from the tender transmittal mail
     *
     * @return
     */
    public String returnTenderNumber() {
        commonMethods.waitForElementExplicitly(5000);
        return $(tenderNumberData).getText();
    }

    /**
     * Method to click on the print request button
     */
    public void clickPrintRequestBtn() {
        $(printRequestBtn).click();
    }

    /**
     * Method to attach a document
     */
    public void selectDocument() {
        commonMethods.waitForElement(driver, attachDocuments, 60);
        $(attachDocuments).click();

    }

    /**
     * Method to click on the Create Submission tab
     */
    public void clickCreateSubmissionBtn() {
        $(createSubmissionBtn).click();
    }

    /**
     * Method to verify if cover letter is displayed
     *
     * @return
     */
    public boolean coverLetterDisplayed() {
        commonMethods.waitForElement(driver, coverLetter);
        return $(coverLetter).isDisplayed();
    }

    /**
     * Method to enter data to cover field
     *
     * @param value
     */
    public void fillCoverField(String value) {
        $(coverLetter).clear();
        $(coverLetter).sendKeys(value);
    }

    /**
     * Method to return the submitted text for a tender
     *
     * @return
     */
    public boolean submittedTextDisplayed() {
        commonMethods.waitForElement(driver, submittedValue);
        return $(submittedValue).isDisplayed();
    }

    /**
     * Method to click on the document attachment dropdown
     */
    public void attachDropDownClick() {
        $(attachDropDown).click();
    }

    public void attachDocDropDown() {
        $(attachDocFromDropDown).click();
    }

    public void cancelLocalFile() {
        $(localFileCancelBtn).click();
    }

    /**
     * Method to click on the link for submitted tender
     */
    public void openSubmission() {
        commonMethods.waitForElement(driver, submittedTenderLink);
        $(submittedTenderLink).click();
    }

    /**
     * Method to return the warning message that appears in the screen
     *
     * @return
     */
    public String returnWarningMsg() {
        System.out.println($(warningMessage).getText());
        return $(warningMessage).getText();
    }

    /**
     * Method to return the note message that appears in the screen
     *
     * @return
     */
    public String returnNoteMsg() {
        return $(noteMessage).getText();
    }

    /**
     * Method to return the no results message
     *
     * @return
     */
    public String returnNoResults() {
        return $(dataNoResults).getText();
    }

    /**
     * Method to click on cancel button
     */
    public void clickCancelBtn() {
        $(cancelBtn).click();
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * method to verify the messages when the organization is removed from the tender invitation
     *
     * @param recipientOrg recipient organization name
     * @param userName     user who belongs to the organization
     * @param senderOrg    the organization from where the tender is sent
     */
    public void validateRemovedOrgMsg(String recipientOrg, String userName, String senderOrg) {
        By by = By.xpath("//div[contains(text(),'" + recipientOrg + " (Organization Status: Removed - " + userName + " - " + senderOrg + " ')]");
        commonMethods.waitForElement(driver, by, 20);
        Assert.assertTrue($(by).isDisplayed());
    }

    /**
     * Method to return the sent date column value
     *
     * @return
     */
    public String getSentDate(String name) {
        By by = By.xpath("//div[@id='recipientsGrid']//tr[contains(@class,'dataRow')]//div[contains(text(),'"+  name +"')]//following::td[1]");
         return $(by).getText();
    }

    /**
     * Method to return the viewed date column value
     *
     * @return
     */
    public String getViewedDate(String name) {
        By by = By.xpath("//div[@id='recipientsGrid']//tr[contains(@class,'dataRow')]//div[contains(text(),'"+  name +"')]//following::td[2]");
        return $(by).getText();
    }


    /**
     * Method to select the recipient
     *
     * @param recipient
     */
    public void selectRecipient(String recipient) {
        commonMethods.waitForElementExplicitly(1500);
        By by = By.xpath("//div[contains(@title,'Aconex Participant') and contains(text(),'" + recipient + "')]//../..//..//td[1]//input");
        if($(by).isDisplayed()){
            commonMethods.waitForElement(driver, by);
            $(by).setSelected(true);
        }

    }

    /**
     * Return the success message
     * @return
     */
    public Boolean returnSuccess() {
        commonMethods.waitForElement(driver, successMsg);
        return $(successMsg).isDisplayed();
    }

    /**
     * Method to select the first row recipient
     */
    public void selectFirstRecipient() {
        By by = By.xpath("//div[contains(@title,'Aconex Participant')]//../..//..//td[1]//input");
        commonMethods.waitForElement(driver, by);
        $(by).click();

    }

    /**
     * Method to click on edit button inside a tender
     */
    public void editTender() {
        $(editBtn).click();
        System.out.println("Inside Tender");
    }

    /**
     * Method to enter sample value to a cover letter text area
     */
    public void fillSampleCoverLetter() {
        $(coverLetterTxtArea).sendKeys("Sample Cover Letter");

    }

    /**
     * Method to click on add recipients button
     */
    public void clickAddRecipients() {
        $(addRecipientsBtn).click();
    }

    /**
     * Method to decline the invitation
     */
    public void declineInvitation() {
        $(declineInviteBtn).click();
        $(declineCommit).click();
    }

//    public void selectDocument()
//    {
//        commonMethods.waitForElementExplicitly(5000);
//        commonMethods.waitForElement(driver,documentCheckBox);
//        $(documentCheckBox).setSelected(true);
//    }

    public void clickZipDownload()
    {
        commonMethods.waitForElement(driver,zipDownload);
        $(zipDownload).click();
    }
}