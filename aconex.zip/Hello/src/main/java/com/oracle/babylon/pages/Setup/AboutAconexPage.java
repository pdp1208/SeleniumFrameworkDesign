package com.oracle.babylon.pages.Setup;

import com.oracle.babylon.Utils.helper.FileOperations;
import com.oracle.babylon.Utils.helper.Navigator;
import com.oracle.babylon.Utils.setup.utils.ConfigFileReader;
import org.junit.Assert;
import org.openqa.selenium.By;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

import static com.codeborne.selenide.Selenide.$;

public class AboutAconexPage extends Navigator {

    private By babylonVersion = By.xpath("//p[contains(text(),'Aconex Limited') and contains(text(),'Copyright')]");
    private String reportsFilePath = "src/main/resources/reports.properties";


    public void navigate(){
        getMenuSubmenu("Setup", "About Aconex");
    }

    public String returnBabylonVersion() {
        String text = $(babylonVersion).getText();
        text = text.substring(text.indexOf("(")+1, text.indexOf(")"));
        text = text.replace(", build", "");
        text = text.replace("Release ", "");
        text = text.replace(" ", ".");
        return text;
    }

     public void writeVersion(String version) {
         File file = new File(reportsFilePath);
         Properties table = new Properties();
         table.setProperty("rpm_version",version);
         try{
             FileOperations.saveProperties(file, table);
         } catch(IOException ioException){
             System.out.println("Unable to write version");
             Assert.fail();
         }
    }
}
