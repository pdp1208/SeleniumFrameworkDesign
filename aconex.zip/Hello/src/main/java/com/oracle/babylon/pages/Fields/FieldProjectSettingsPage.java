package com.oracle.babylon.pages.Fields;

import com.oracle.babylon.Utils.helper.Navigator;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.*;
import static com.codeborne.selenide.Condition.appears;
import static com.codeborne.selenide.Condition.checked;

public class FieldProjectSettingsPage extends Navigator {

    private By projectSearchField = By.xpath("//*[@id='mainProject']");
    private String projectLocator = "//li[contains(@class,'ui-menu-item')]/*[contains(text(),'PROJECT_ID')]";
    private By enabledRadioBtn = By.xpath("//input[contains(@class,'Field')][@id='projectSettings']");
    private By chooseFileButton = By.xpath("//*[@type='file']");
    private By uploadAreasButton = By.xpath("//*[@type='submit']");
    private By uploadSuccessMessage = By.xpath("//*[contains(@class,'success')][not(contains(@class,'ng-hide'))]");
    private By addMorePeople = By.xpath("//*[@id='add-more-people']");
    private By addMoreOrgs = By.xpath("//*[@id='add-more-orgs']");
    private final String zipFilePath = System.getProperty("user.dir") + "/src/main/resources/fieldAreaZipFiles/";
    private By resetAreas = By.xpath("//*[text()='Reset Areas']");
    private By dailyReportCheckbox = By.xpath("//*[contains(@id,'DailyReports')][@type='checkbox']");
    private By logout = By.xpath("//*[contains(text(),'Logout')]");
    private By dailyReportEnableRadio = By.xpath("//input[contains(@ng-model, 'organisation.dailyReportsEnabled')]");

    /**
     * Method to enable field for project.
     *
     * @param projectId project id.
     */
    public void enableFieldModuleForProject(String projectId){
        $(projectSearchField).waitUntil(appears, 4000).setValue(projectId);
        $(By.xpath(projectLocator.replace("PROJECT_ID", projectId))).click();
        if($(enabledRadioBtn).isSelected()==false){
            $(enabledRadioBtn).click();
        }
    }

    /**
     * Method to add local areas through zip file.
     *
     * @param fileNmae .zip file name.
     */
    public void addLocalAreas(String fileNmae){
        $(chooseFileButton).waitUntil(appears, 4000).setValue(zipFilePath + fileNmae);
        $(uploadAreasButton).waitUntil(appears, 10000).click();
        $(uploadSuccessMessage).waitUntil(appears, 10000);
    }

    /**
     * Method to add people for field issue.
     *
     * @param user User name.
     */
    public void addMorePeople(String user){
        $(addMorePeople).waitUntil(appears, 4000).setValue(user);
        String locator = "//*[contains(text(),'USERNAME')]".replaceAll("USERNAME", user);
        $(By.xpath(locator)).waitUntil(appears, 4000).click();
    }

    /**
     * Method to add organization to list.
     *
     * @param org name of the organization.
     */
    public void addMoreOrganizations(String org) {
        if(!$(By.xpath("//div[contains(@class,'checklist-orgs')]//td[text()='" + org + "']")).isDisplayed()){
            $(addMoreOrgs).clear();
            for (Character c : (org.split(" ")[0]).toCharArray()) {
                $(addMoreOrgs).sendKeys(c.toString());
            }
            commonMethods.waitForElement(driver, By.xpath("//li//*[contains(text(),'" + org + "')]"), 7);
            $(By.xpath("//li//*[contains(text(),'" + org + "')]")).hover().click();
            $(By.xpath("//div[contains(@class,'checklist-orgs')]//td[text()='" + org + "']")).waitUntil(appears, 10000);
        }
    }

    /**
     * Method to enable/disable daily reports role for org.
     *
     * @param dailyReport true or false.
     */
    public void setDailyReportRole(boolean dailyReport){
        if(dailyReport){
            $(dailyReportEnableRadio).click();
        }
    }

    /**
     * Method to select daily report role for user.
     *
     * @param role daily report role.
     */
    public void selectDailyReportRole(String username, String role){
        $(By.xpath("(//*[text()='Manage users']/parent::fieldset//table[@class='auiTable']//td[contains(@class,'user-name')][text()='" + username + "']/following-sibling::td[contains(@class,'user-role')])[last()]")).click();
        $(By.xpath("//li//*[text()='" + role + "']")).click();
    }

    /**
     * Method to set daily report feature flag.
     *
     * @param flag true or false.
     */
    public void setDailyReportsFlag(boolean flag){
        if(!($(dailyReportCheckbox).is(checked)==flag)){
            $(dailyReportCheckbox).click();
        }
    }

    /**
     * Method to perform logout.
     *
     */
    public void logout(){
        commonMethods.waitForElement(driver, logout, 7);
        $(logout).click();
    }
}
