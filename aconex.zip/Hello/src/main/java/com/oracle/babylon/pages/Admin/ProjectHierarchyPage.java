package com.oracle.babylon.pages.Admin;

import com.oracle.babylon.pages.Setup.ProjectSettingsPage;
import org.junit.Assert;
import org.openqa.selenium.By;

import java.io.File;

import static com.codeborne.selenide.Selenide.$;

/**
 * Class that contains methods to manage configurations
 * Author : Sai
 */
public class ProjectHierarchyPage extends AdminTools{

    //Web element initialization
    private By txtBoxProjectId = By.xpath("//input[@name='configuringProjectId']");
    private By hdrProjectHierarchy = By.xpath("//h1[contains(text(),'Configure Project Hierarchy')]");
    private By btnLookup = By.xpath("//button[@id='btnLookupProjectId']");
    private By btnReset = By.xpath("//div[contains(text(),'Reset')]");
    private By btnRemoveHierarchies = By.xpath("//div[contains(text(),'Remove Hierarchies')]");
    private By btnSave = By.xpath("//div[contains(text(),'Save')]");
    private By lblProjectName = By.xpath("//td[contains(text(),'Project Name')]");
    private By lblImportFile = By.xpath("//td[contains(text(),'Import File')]");
    private By btnChooseFile = By.xpath("//table[@class='formTable']//span[@class='uiFileField']");
    private By txtBoxChooseFile = By.xpath("//table[@class='formTable']//span/input");
    private By lblCsvFormat = By.xpath("//*[contains(text(),'must be in csv format')]");
    private By lblUploadError = By.xpath("//div[contains(text(),'File upload failed. File must be in CSV format.')]");
    private By lblUploadSuccess = By.xpath("//div[contains(text(),'Success: Your file import was successful')]");
    private By lblRemoveSuccess = By.xpath("//div[contains(text(),'All existing hierarchies have been removed from the project.')]");
    private By txtEmptyFileError = By.xpath("//div[text()='File upload failed. Some fields were empty. Please add values for all headers and try again.']");

    ProjectSettingsPage projectSettingsPage = new ProjectSettingsPage();

    /**
     * Function to Assert project Hierarchy tab
     */
    public void verifyProjectHierarchyTab(String role) {
        commonMethods.waitForElement(driver, btnReset, 20);
        if(role.equalsIgnoreCase("admin")) {
            Assert.assertTrue($(hdrProjectHierarchy).isDisplayed());
            Assert.assertTrue($(txtBoxProjectId).isDisplayed());
            Assert.assertTrue($(btnLookup).isDisplayed());
        }
        Assert.assertTrue($(btnReset).isDisplayed());
        Assert.assertTrue($(btnRemoveHierarchies).isDisplayed());
        Assert.assertTrue($(btnSave).isDisplayed());
    }

    /**
     * Function to search project
     */
    public void searchProject(String projectId) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, txtBoxProjectId,20);
        commonMethods.enterTextValue(txtBoxProjectId,projectId);
        commonMethods.waitForElementExplicitly(500);
        $(btnLookup).click();
    }

    /**
     * Function to verify Project Hierarchy project fields
     */
    public boolean verifyProjectFields(String role, String projectName) {
        commonMethods.waitForElementExplicitly(5000);
        if(role.equalsIgnoreCase("admin"))
            return $(lblProjectName).isDisplayed() && $(By.xpath("//td[contains(text(),'" + projectName + "')]")).isDisplayed() && $(lblImportFile).isDisplayed() && $(btnChooseFile).isDisplayed() && $(lblCsvFormat).isDisplayed();
        else
            return $(lblImportFile).isDisplayed() && $(btnChooseFile).isDisplayed() && $(lblCsvFormat).isDisplayed();

    }

    /**
     * Function to click on reset button
     */
    public void clickReset() {
        $(btnReset).click();
    }

    /**
     * Function to click on Remove Hierarchies button
     */
    public void clickRemoveHierarchies() {
        $(btnRemoveHierarchies).click();
    }

    /**
     * Function to click on Choose file button
     */
    public void clickChooseFile() {
        commonMethods.waitForElement(driver, btnChooseFile, 20);
        $(btnChooseFile).click();
    }

    /**
     * Function to close upload file window
     */
    /*public void closeUploadWindow() {
        try {
            commonMethods.waitForElementExplicitly(2000);
            Robot robot = new Robot();
            robot.keyPress(KeyEvent.VK_ESCAPE);
            robot.keyRelease(KeyEvent.VK_ESCAPE);
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }*/

    /**
     * Function to select file
     */
    public void selectFile(String fileName) {
        $(txtBoxChooseFile).sendKeys(new File(configFileReader.getTestDataPath() + fileName).getAbsolutePath());
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Function to verify file upload error
     */
    public boolean verifyFileUploadError() {
        commonMethods.waitForElement(driver,lblUploadError,30);
        return $(lblUploadError).isDisplayed();
    }

    /**
     * Function to verify file upload success
     */
    public boolean verifyFileUpload() {
        commonMethods.waitForElement(driver,lblUploadSuccess,30);
        return $(lblUploadSuccess).isDisplayed();
    }

    /**
     * Function to verify file upload failure error
     */
    public boolean verifyUploadFieldError(String name) {
        By element = By.xpath("//div[contains(text(),'File upload failed. Field " + name + " cannot be used in a hierarchy. Please amend the import file and try again.')]");
        commonMethods.waitForElement(driver,element,30);
        return $(element).isDisplayed();
    }

    /**
     * Function to verify file upload failure for invalid field values
     */
    public boolean verifyUploadValueError(String name) {
        By element = By.xpath("//div[contains(text(),'File upload failed. " + name + " not found for this project')]");
        commonMethods.waitForElement(driver,element,30);
        return $(element).isDisplayed();
    }

    /**
     * Function to verify file upload failure for hierarchy already exist
     */
    public boolean verifyHierarchyError(String name) {
        By element = By.xpath("//div[contains(text(),'File upload failed. Field " + name + " has already been used in a hierarchy. Please amend the import file or delete all existing hierarchies and try again.')]");
        commonMethods.waitForElement(driver,element,30);
        return $(element).isDisplayed();
    }

    /**
     * Function to verify remove hierarchy success message
     */
    public boolean verifyRemoveHierarchies() {
        commonMethods.waitForElement(driver,lblRemoveSuccess,30);
        return $(lblRemoveSuccess).isDisplayed();
    }

    /**
     * Function to switch frames for acnx admin and user
     */
    public void switchFrames(String role) {
        verifyAndSwitchFrame();
        if (role.equalsIgnoreCase("user"))
            projectSettingsPage.switchProjectSettingsFrame();
    }

    /**
     * Function to verify file upload failure error for empty file
     */
    public boolean verifyEmptyFileError() {
        commonMethods.waitForElement(driver,txtEmptyFileError,30);
        return $(txtEmptyFileError).isDisplayed();
    }
}
