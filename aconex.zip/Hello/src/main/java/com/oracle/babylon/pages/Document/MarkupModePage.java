package com.oracle.babylon.pages.Document;

import org.junit.Assert;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.close;

/**
 * Class to control the actions of the Markup mode in the document
 * We combine this class with some of the actions in Doc Review Doc Mode page
 * Created by susgopal
 */
public class MarkupModePage extends DocumentPage{
    //Identifiers
    By dots = By.xpath("//div[@class='ag-pinned-left-cols-container']/div/div[1]/div//button[@class='auiMenuButton auiButton ng-binding']");
    By markUpHeader = By.xpath("//h3[text()='Markup Mode']");
    By saveBtn = By.xpath("//button[@title='Save & Close']");
    By toggleSidePanel = By.xpath("//span[@id='toggleSidePanel']");
    By thumbnails = By.xpath("//span[@title='Thumbnails']");
    By outLine = By.xpath("//span[@title='Outline']");
    By fullDocSearch = By.xpath("//span[@title='Full Document Search']");
    By successMessage = By.xpath("//span[text()='Your markups have been saved successfully']");
    By closeBtn = By.xpath("//button[@title='Close']");

    /**
     * Method to validate the header of the Viewer page
     * @return
     */
    public boolean validateMarkUpMode(){
        commonMethods.waitForElementExplicitly(5000);
        commonMethods.waitForElement(driver, markUpHeader, 60);
        return $(markUpHeader).isDisplayed();
    }

    /**
     * Method to click on the save button
     */
    public void clickPageSave(){
        commonMethods.waitForElement(driver, saveBtn);
        commonMethods.waitForElementExplicitly(2000);
        $(saveBtn).click();

    }

    /**
     * Method to verify if the save was successful
     */
    public void verifySave(){
        commonMethods.waitForElement(driver, successMessage,60);
        Assert.assertTrue($(successMessage).isDisplayed());
        $(closeBtn).click();

    }

    /**
     * Method to click on thumbnails
     */
    public void clickThumbnails(){
        $(thumbnails).click();
    }

    /**
     * Method to validate the thumbnails
     * @return
     */
    public boolean validateThumbnails(){
        return $(thumbnails).isDisplayed();
    }

    /**
     * Method to click on the outline icon
     */
    public void clickOutline(){
        $(outLine).click();
    }

    /**
     * Method to validate the outline icon
     * @return
     */
    public boolean validateOutline(){
        return $(outLine).isDisplayed();
    }

    /**
     * Method to click on the left toggle panel
     */
    public void clickLeftTogglePanel(){
        $(toggleSidePanel).click();
    }










}
