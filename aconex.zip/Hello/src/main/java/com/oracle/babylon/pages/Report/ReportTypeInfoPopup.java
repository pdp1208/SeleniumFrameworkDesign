package com.oracle.babylon.pages.Report;

import com.oracle.babylon.Utils.helper.Navigator;
import org.openqa.selenium.By;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class ReportTypeInfoPopup extends Navigator {

    private String subjectAreaCheckboxLocator = "//*[contains(text(),'SUBJECTAREA')]/parent::*/input[@type='checkbox']";
    public By reportTypeOptions = By.xpath("//*[@class='report-types']//li//input[@type='checkbox']/following-sibling::span");
    public By reportTypeCheckbox = By.xpath("//*[@class='report-types']//li//input[@type='checkbox']");
    public By saveButton = By.xpath("//*[contains(text(),'Save')]/parent::button[@id='reportTypeSave']");

    /**
     * Method to select subject are types on report info popup.
     *
     * @param subjectAreaList List of subject area types.
     */
    public void selectSubjectAreaTypesToAdd(Set<String> subjectAreaList){
        String subjectAreaLocator = "";
        String subjectArea[] = null;
        int index = 0;
        for(String subjectAreaName : subjectAreaList){
            subjectArea = subjectAreaName.split(" ");
            if(subjectArea.length>1){
                index = 1;
            }
            subjectAreaLocator = subjectAreaCheckboxLocator.replace("SUBJECTAREA", subjectArea[index]);
            if(!$(By.xpath(subjectAreaLocator)).isSelected()){
                $(By.xpath(subjectAreaLocator)).click();
            }
            index = 0;
        }
        commonMethods.waitForElementClickable(driver, saveButton, 5);
        $(saveButton).click();
    }

    /**
     * Method to save report info.
     *
     */
    public void saveReportInfo(){
        List<String> reportTypes = new ArrayList<>();
        $(reportTypeOptions).waitUntil(appears, 6000);
        $$(reportTypeOptions).forEach(element -> reportTypes.add(element.getText()));
        selectSubjectAreaTypesToAdd(reportTypes.stream().collect(Collectors.toSet()));
    }

    /**
     * Method to get selected types on report info popup.
     *
     */
    public List<String> getSelectedReportTypes(){
        $(reportTypeCheckbox).waitUntil(appears, 6000);
        return $$(reportTypeCheckbox).stream()
                .filter(element -> element.isSelected())
                .map(element -> element.getAttribute("title"))
                .collect(Collectors.toList());
    }
}
