package com.oracle.babylon.pages.Setup.ProjectSettings;

import com.oracle.babylon.pages.Setup.ProjectSettingsPage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import java.util.*;

import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Selenide.*;

public class DocumentDrawingSetting extends ProjectSettingsPage {
    private By document = By.xpath("//div[@id='project-settings-navigation']//span[contains(text(),'Documents')]");
    private By title = By.xpath("//h1[contains(.,'Project Setting')]");
    private By drawingTab = By.xpath("//div[@id='project-settings-navigation']//div[contains(text(),'Drawings')]");
    private By drawingHeader = By.xpath("//body[@class='ng-scope']/acx-edit-current-set[@class='panel panel-default']/div[@class='editCurrentSet ng-scope']/div[1]");
    private By definitionHeader = By.xpath("//body[@class='ng-scope']/acx-edit-current-set[@class='panel panel-default']/div[@class='editCurrentSet ng-scope']/div[2]");
    private By editDefinition = By.xpath("//div[@class='editCurrentSet ng-scope']//a[@class='ng-scope auiIcon edit']");
    private By addDocumentTypeBtn = By.xpath("//div[contains(text(),'Add Document Type')]");
    private By saveBtn = By.xpath("//button[contains(.,'Save')]");
    private By cancelBtn = By.xpath("//button[contains(.,'Cancel')]");
    private By addMoreBtn = By.xpath("//div[contains(text(),'Add more')]");
    private By drawingDefination = By.xpath("//h1[contains(text(),'Definition')]");
    private By drawings = By.xpath("//div[@class='auiCollapsibleSection-body']//div[contains(text(),'Drawings')]");
    private By drawingDefinitionTxt = By.xpath("//table//tr//td[2]");
    private By docTypes = By.xpath("//div[@class='docType ng-binding']");

    public void navigateAndVerifyPage() {
        getMenuSubmenu("Setup", "Project Settings");
        $(loadingIcon).should(disappear);
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, document, 10);
        $(document).click();
        commonMethods.waitForElement(driver, drawingTab, 20);
        $(drawingTab).click();
        Assert.assertTrue($(title).text().contains("Project Settings"));
    }

    public Map<String, String> getSettingDetails() {
        switchProjectSettingsFrame();
        Map<String, String> detail = new HashMap<>();
        sleep(1000);
        detail.put("Drawing", $(drawingHeader).text());
        detail.put("Definition", $(definitionHeader).text());
        return detail;
    }

    /**
     * Function to Click on Drawing Edit Definition
     */
    public void clickEditDefinition() {
        switchProjectSettingsFrame();
        commonMethods.waitForElement(driver, editDefinition, 25);
        $(editDefinition).click();
    }

    /**
     * Function to Delete Document Type
     *
     * @param type
     */
    public void deleteDocumentType(String type) {
        switchProjectSettingsFrame();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,-1000)", "");
        commonMethods.waitForElement(driver, addDocumentTypeBtn, 30);
        if ($(By.xpath("//span[text()='" + type + "']")).isDisplayed()) {
            $(By.xpath("//span[text()='" + type + "']")).click();
            By delete = By.xpath("//div[@class='auiModal-dialog tableContent']//div[@class='auiModal-body']//div[@class='restriction ng-scope']//span[text()='" + type + "']/following-sibling::span");
            if ($(delete).isDisplayed()) {
                $(delete).click();
            }
        }

    }

    /**
     * @param forType
     */
    public void clickAddMore(String forType) {
        switchProjectSettingsFrame();
        By addMore = By.xpath("//div[@class='auiModal-dialog tableContent']//div[@class='auiModal-body']//div[@class='restriction ng-scope']//span[text()='" + forType + "']/parent::div//a[contains(.,'Add more')]");
        commonMethods.getElementInViewAndUp(addMore);
        $(addMore).click();
    }

    /**
     * Function click on Save
     */
    public void clickSave() {
        switchProjectSettingsFrame();
        $(saveBtn).click();
    }

    /**
     * Function to click on Cancel
     */
    public void clickCancel() {
        switchProjectSettingsFrame();
        $(cancelBtn).click();
    }

    /**
     * Function to verify doc type ChkBoc selected
     *
     * @param docType
     * @return
     */
    public Boolean verifyDocumentTypeChkBoxSelected(String docType) {
        return $(By.xpath("//label[text()='" + docType + "']//..//input")).isSelected();
    }

    /**
     * Function to verify add More filed value
     *
     * @param type
     * @return
     */
    public Boolean verifyAddMoreFields(String type) {
        return $(By.xpath("//label[text()='" + type + "']")).isDisplayed();
    }

    /**
     * Click on Add More
     */
    public void clickAddMore() {
        switchProjectSettingsFrame();
        $(addMoreBtn).click();
    }

    /**
     * Click on Add Document Type
     */
    public void clickAddDocType() {
        switchProjectSettingsFrame();
        $(addDocumentTypeBtn).click();
    }

    /**
     * Function to Add Document Type
     *
     * @param docType
     */
    public void addDocumentType(String docType) {
        switchProjectSettingsFrame();
        if (!$(By.xpath("//span[text()='" + docType + "']")).isDisplayed()) {
            clickAddDocType();
            $(By.xpath("//label[text()='" + docType + "']//..//input")).click();
        }
        System.out.println("Document Type" + docType + " is present Continuing with Execution....");
        clickSave();
    }

    /**
     * Function to verify Document Type
     *
     * @param docType
     */
    public boolean verifyDocumentType(String docType) {
        switchProjectSettingsFrame();
        return $(By.xpath("//span[text()='" + docType + "']")).isDisplayed();
    }

    /**
     * Function to Add More value for Doc Type
     *
     * @param docType
     * @param field
     * @param fieldValue
     */
    public void addMoreValues(String docType, String field, List<String> fieldValue) {
        switchProjectSettingsFrame();
        if (!$(By.xpath("//span[text()='" + docType + "']/following-sibling::div//div[contains(text(),'" + field + "')]")).isDisplayed()) {
            $(By.xpath("//span[text()='" + docType + "']//..//div[text()='Add more']")).click();
            $(By.xpath("//span[text()='" + docType + "']//..//div[@class='auiMenuButton-dropdown ng-scope']//label[text()='" + field + "']//..//input")).setSelected(true);
            $(By.xpath("//span[text()='" + docType + "']//..//div[text()='Add more']")).click();
        }
        for (String value : fieldValue) {
            addFieldValue(docType, field, value);
        }
        clickSave();
    }

    /**
     * Function to Add Doc type and values for Doc Type
     *
     * @param docType
     * @param values
     */
    public void addDocTypeAndValues(String docType, String fieldName, List<String> values) {
        switchProjectSettingsFrame();
        if (!$(By.xpath("//span[text()='" + docType + "']")).isDisplayed()) {
            clickAddDocType();
            $(By.xpath("//label[text()='" + docType + "']//..//input")).click();
            clickAddDocType();
        }
        addMoreValues(docType, fieldName, values);
        commonMethods.waitForElementExplicitly(5000);
    }

    /**
     * Function to verify More value for Doc Type
     *
     * @param fieldValue
     */
    public void verifyMoreValues(String doctype, List<String> fieldValue) {
        for (String value : fieldValue) {
            Assert.assertTrue($(By.xpath("//span[contains(text(),'" + doctype + "')]//parent::div//span[contains(text(),'" + value + "')]")).isDisplayed());
        }
    }

    /**
     * Function to Edit and Add status value
     *
     * @param docType
     * @param fieldValue
     */
    public void addStatusValue(String docType, String field, List<String> fieldValue) {
        switchProjectSettingsFrame();
        By element = By.xpath("//span[text()='" + docType + "']//..//div//input");
        commonMethods.waitForElement(driver, element, 25);
        $(element).click();
        for (String value : fieldValue) {
            addFieldValue(docType, field, value);
        }
        clickSave();
    }

    /**
     * Function to Add filed value for Doc type
     *
     * @param docType
     * @param value
     */
    public void addFieldValue(String docType, String fieldName, String value) {
        switchProjectSettingsFrame();
        $(By.xpath("//span[text()='" + docType + "']//..//div[text()='" + fieldName + "']//..//input[@type='search']")).click();

        By fieldSelect = By.xpath("//div[text()='" + value + "']");
        By fieldTxt = By.xpath("//span[text()='" + value + "']");
        if (!$(fieldTxt).isDisplayed()) {
            $(fieldSelect).click();
        }
    }

    /**
     * Function to remove child value associated to Doc type
     *
     * @param docType
     * @param childValue
     */
    public void removeChildRecord(String docType, String childValue) {
        switchProjectSettingsFrame();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,-1000)", "");
        $(By.xpath("//span[text()='" + docType + "']")).click();
        $(By.xpath("//span[text()='" + docType + "']//..//span[text()='" + childValue + "']//../../..//span[@class='close ui-select-match-close']")).click();
    }

    /**
     * Function to remove entire child record associated with doc type
     *
     * @param docType
     */
    public void removeAllChildRecords(String docType) {
        switchProjectSettingsFrame();
        commonMethods.waitForElement(driver, By.xpath("//span[text()='" + docType + "']"));
        $(By.xpath("//span[text()='" + docType + "']")).click();
        commonMethods.waitForElement(driver, By.xpath("//span[text()='" + docType + "']//..//span[@class='removeCondition auiIcon close']"));
        $(By.xpath("//span[text()='" + docType + "']//..//span[@class='removeCondition auiIcon close']")).click();
    }

    /**
     * Function to click on Drawings tab and verify the header on the page
     *
     * @return
     */

    public boolean clickDrawings() {
        $(drawings).click();
        switchProjectSettingsFrame();
        commonMethods.waitForElement(driver, drawingHeader, 35);
        Assert.assertTrue($(drawingHeader).isDisplayed());
        return $(drawingDefination).isDisplayed();
    }

    /**
     * Function to get all dropdown values from Add More
     *
     * @return list
     */
    public List<String> getAddMoreFields(String type) {
        return commonMethods.getValues(By.xpath("//span[text()='" + type + "']//..//following-sibling::div[@class='auiDetails-label']//ul/li//label"));
    }

    /**
     * Function to get child records for a given type and attribute
     *
     * @return list
     */
    public List<String> getChildAttributeValues(String type, String attribute) {
        return commonMethods.getValues(By.xpath("//span[text()='" + type + "']/..//div[text()='" + attribute + "']/..//span//span[@class='ng-binding ng-scope']"));
    }

    /**
     * Function to get the drawing definition list
     *
     * @return
     */

    public List<String> getDrawingDefinition() {
        List<String> drawDefList = new ArrayList<>();
        for (WebElement element : $$(drawingDefinitionTxt)) {
            drawDefList.add(element.getText());
        }
        return drawDefList;
    }

    /**
     * Function to remove the Project field in Edit Drawing Definition if present
     */
    public void removeProjectField(String projectField) {
        By projectFieldElement = By.xpath("//div[text()='" + projectField + "']/following::div[1]/aui-select/../span");
        commonMethods.waitForElement(driver, projectFieldElement, 10);
        $(projectFieldElement).click();
    }

    /**
     * Function to verify the Project field in Edit Drawing Definition
     *
     * @return
     */
    public boolean verifyProjectField(String fieldName) {
        return $(By.xpath("//div[text()='" + fieldName + "']/following::div[1]/aui-select/../span")).isDisplayed();
    }

    /**
     * Function to get all drawing defintions from project settings
     */
    public Map<String, Map<String, String>> getAllDrawingDefs() {
        Map<String, Map<String, String>> drawingDefs = new LinkedHashMap<>();
        String docType = "";
        commonMethods.waitForElement(driver, drawingDefination);
        List<WebElement> drawingTypes = new ArrayList<>($$(docTypes));
        for (WebElement type : drawingTypes) {
            Map<String, String> docAttrs = new LinkedHashMap<>();
            docType = $(type).getText().trim();
            List<WebElement> definitions = new ArrayList<>($$(By.xpath("//div[text()='" + docType + "']/../table/tbody//tr")));
            for (int i = 1; i <= definitions.size(); i++)
                docAttrs.put($(By.xpath("(//div[text()='" + docType + "']/../table[" + i + "]//tr/td)[1]")).getText().trim(), $(By.xpath("(//div[text()='" + docType + "']/../table[" + i + "]//tr/td)[2]")).getText().trim());
            drawingDefs.put(docType, docAttrs);
        }
        return drawingDefs;
    }
}
