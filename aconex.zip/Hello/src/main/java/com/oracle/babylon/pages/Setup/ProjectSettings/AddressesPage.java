package com.oracle.babylon.pages.Setup.ProjectSettings;

import com.oracle.babylon.pages.Setup.ProjectSettingsPage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.UnhandledAlertException;

import java.util.List;

import static com.codeborne.selenide.Selenide.$;

public class AddressesPage extends ProjectSettingsPage {

    private By postalAddress = By.xpath("//td[contains(text(),'Postal Address')]");
    private By projectName = By.xpath("//td[contains(text(),'Project Name')]");
    private By inputProjectName = By.xpath("//input[@name='ProjectShortName']");
    private By projectAddress = By.xpath("//td[contains(text(),'Project Address')]");
    private By orgDetails = By.xpath("//td[contains(text(),'Organization Details')]");
    private By deliveryAddress = By.xpath("//td[contains(text(),'Delivery Address')]");
    private By editFaxInSettings = By.xpath("//div[contains(text(),'Edit Fax-In Settings')]");
    private By editEmailInSettings = By.xpath("//div[contains(text(),'Edit Email-In Settings')]");
    private By newFaxButton = By.xpath("//div[contains(text(),'New Fax')]");
    private By faxNumbers = By.xpath("//td[contains(text(),'Fax numbers not listed')]");
    private By saveFax = By.xpath("//td[contains(text(),'Save fax as')]");
    private By aconexMailRadioOption = By.xpath("//input[@value='email']");
    private By documentRadioOption = By.xpath("//input[@value='document']");
    private By aconexMail = By.xpath("//input[@value='mail']");
    private By documentOption = By.xpath("//input[@value='doc']");
    private By recordRecipient = By.xpath("//td[contains(text(),'Record recipient as')]");
    private By recordRecipientDropdown = By.xpath("//select[@name='defaultRecipientId']");
    private By faxNumberSaveBtn = By.xpath("//td[@class='messagecell']//button[@title='Save']");
    private By faxPageSaveBtn = By.xpath("//div[@class='toolbar clearFloats noprint']//div[contains(text(),'Save')]");
    private By faxPageBackBtn = By.xpath("//button[@class='uiBackButton uiButton']");
    private By faxNumber = By.xpath("//td[contains(text(),'Fax Number')]");
    private By lookUpFrom = By.xpath("//td[contains(text(),'Lookup From')]");
    private By fromField = By.xpath("//td[contains(text(),'From')]");
    private By toField = By.xpath("//td[contains(text(),'To')]");
    private By saveFaxAs = By.xpath("//td[contains(text(),'Save fax as')]");
    private By lookupButton = By.xpath("//button[@title='Look up this name in the Address Directory']");
    private By toDropdown = By.xpath("//select[@name='ToUserId']");
    private By prjPAddress1 = By.xpath("//input[@name='PostalAddress1']");
    private By prjDAddress1 = By.xpath("//input[@name='DeliveryAddress1']");
    private By postalCity = By.xpath("//input[@name='PostalSuburb']");
    private By deliveryAddressCity = By.xpath("//input[@name='DeliverySuburb']");
    private By postalCountry = By.xpath("//select[@name='PostalCountry']");
    private By country = By.xpath("//select[@name='DeliveryCountry']");
    private By saveMyChanges = By.xpath("//div[contains(text(),'Save my changes')]");
    private By ignoreMyChanges = By.xpath("//div[contains(text(),'Ignore my changes')]");
    private By addressSaveButton = By.xpath("//button[@id='btnSave']");
    private By countryCode = By.xpath("//input[@name='CountryCode']");
    private By areaCode = By.xpath("//input[@name='AreaCode']");
    private By inputFaxNumber = By.xpath("//input[@name='FaxNumber']");
    private By targetList = By.xpath("//h2[contains(text(),'Target List')]");
    private By searchDirectory = By.xpath("//div[@id='searchConfig']");
    private By searchResults = By.xpath("//div[@class='searchResults']");
    private By inputCheckbox = By.xpath("//input[@type='checkbox']");
    private By selectRecipientsOkBtn = By.xpath("//div[contains(text(),'OK')]");
    private By selectRecipientToBtn = By.xpath("//div[@class='flow-right']//button[@id='btnAddTo_page']");
    private By assignFaxNumSaveBtn = By.xpath("//button[@title='Save']");
    private By assignFaxNumBackBtn = By.xpath("//button[@id='btnBack']");
    private By faxInServiceFaxNumber = By.xpath("//td[contains(text(),'Fax Number')]");
    private By faxInServiceFromField = By.xpath("//td[contains(text(),'From')]");
    private By faxInServiceToField = By.xpath("//td[contains(text(),'To')]");
    private By faxInServiceMailDocField = By.xpath("//td[contains(text(),'Mail')]");
    private By faxInServiceDeleteIcon = By.xpath("//a//img");
    private By faxInServiceSettingBackBtn = By.xpath("//button[@title='Back']");
    private By noFaxAvailableMsg = By.xpath("//td[contains(text(),'There are no fax numbers defined for this project')]");
    private By emailInSettingsProject = By.xpath("//td[contains(text(),'Project')]");
    private By emailInSettingsMailFilter = By.xpath("//td[contains(text(),'Mail Filter')]");
    private By emailInSettingsMailMsg = By.xpath("//span[contains(text(),'Note: Leave mail filter blank to accept all emails OR enter one or more valid domain names separated by commas.')]");
    private By emailInSettingsRecipient = By.xpath("//td[contains(text(),'Recipient')]");
    private By emailInSettingsRecipientDropdown = By.xpath("//select[@name='RECIPIENT_ID']");
    private By emailInSettingsSaveBtn = By.xpath("//button[@title='Save Changes']");
    private By addressTab = By.xpath("//div[contains(text(),'Addresses')]");

    /**
     * Function to verify Address Fields present on the page
     */

    public void verifyAddressFields(List<String> data) {
        for (String field : data) {
            getElementInView(By.xpath("//td[contains(text(),'" + field + "')]"));
            Assert.assertTrue($(By.xpath("//td[contains(text(),'" + field + "')]")).isDisplayed());
        }
    }

    /**
     * Function to verify the postal Address fields present on Address page
     */

    public void verifyPostalAddress(List<String> data) {
        for (String field : data) {
            getElementInView(By.xpath("//td[contains(text(),'" + field + "')]//..//td//../..//td[contains(text(),'Postal Address')]"));
            Assert.assertTrue($(By.xpath("//td[contains(text(),'" + field + "')]//..//td//../..//td[contains(text(),'Postal Address')]")).isDisplayed());
        }
    }

    /**
     * Function to verify the Delivery Address fields present on Address page
     */

    public void verifyDeliveryAddress(List<String> data) {
        for (String field : data) {
            getElementInView(By.xpath("//td[contains(text(),'" + field + "')]//..//td//../..//td[contains(text(),'Delivery Address')]"));
            Assert.assertTrue($(By.xpath("//td[contains(text(),'" + field + "')]//..//td//../..//td[contains(text(),'Delivery Address')]")).isDisplayed());
        }
    }

    /**
     * Function to validate Short Name field of Address page
     */

    public void validateShortName() {
        $(inputProjectName).clear();
        $(pageSaveBtn).click();
        verifyAlert("A project requires a short name.");
    }

    /**
     * Function to validate Postal Address present on the Address page
     */

    public void validatePostalAddress() {
        $(prjPAddress1).clear();
        $(pageSaveBtn).click();
        verifyAlert("You must supply a postal address for the project");
    }

    /**
     * Function to validate Delivery Address present on the Address page
     */

    public void validateDeliveryAddress() {
        getElementInView(deliveryAddress);
        $(prjDAddress1).clear();
        $(pageSaveBtn).click();
        verifyAlert("Please supply a delivery address for the project");
    }

    /**
     * Function to validate Postal city present on the Address page
     */

    public void validatePostalCity() {
        getElementInView(postalCity);
        $(postalCity).clear();
        $(pageSaveBtn).click();
        verifyAlert("Please supply a city/suburb for the postal address");
    }

    /**
     * Function to validate Delivery Address city present on the Address page
     */

    public void validateDeliveryAddressCity() {
        getElementInView(deliveryAddressCity);
        $(deliveryAddressCity).clear();
        $(pageSaveBtn).click();
        verifyAlert("Please supply a city/suburb for the delivery address");
    }

    /**
     * Function to validate Postal Address country present on the Address page
     */

    public void validatePostalCountry() {
        getElementInView(postalCountry);
        $(postalCountry).selectOptionContainingText("Choose One");
        $(pageSaveBtn).click();
        verifyAlert("Please supply a country for the postal address");
    }

    /**
     * Function to validate Postal Address country present on the Address page
     */

    public void validateCountry() {
        getElementInView(country);
        $(country).selectOptionContainingText("Choose One");
        $(pageSaveBtn).click();
        verifyAlert("Please supply a delivery country");
    }

    /**
     * Function to edit Postal Address city present on the Address page
     */

    public void editCity(String cityName) {
        getElementInView(postalCity);
        commonMethods.waitForElement(driver,postalCity,45);
        $(postalCity).clear();
        $(postalCity).sendKeys(cityName);
    }

    /**
     * Function to click Save My Changes button
     */

    public void clickSaveMyChanges() {
        commonMethods.waitForElement(driver,saveMyChanges,45);
        $(saveMyChanges).click();
    }

    /**
     * Function to click Ignore My Changes button
     */

    public void clickIgnoreMyChanges() {
        commonMethods.waitForElement(driver,ignoreMyChanges,45);
        $(ignoreMyChanges).click();
    }

    /**
     * Function to verify Postal City present
     *
     * @retyrn
     */

    public boolean verifyPostalCity(String cityName) {
        getElementInView(postalCity);
        commonMethods.waitForElement(driver,postalCity,45);
        return $(postalCity).getValue().equals(cityName);
    }

    /**
     * Function to click Save button on the address page
     */

    public void clickSaveButton() {
        $(addressSaveButton).click();
    }

    /**
     * Function to click on the Address tab and verify
     *
     * @return
     */

    public boolean verifyAddressTab() {
        $(addressTab).click();
        switchProjectSettingsFrame();
        commonMethods.waitForElement(driver, postalAddress, 45);
        return $(postalAddress).isDisplayed();
    }

    /**
     * Function to get the delivery address
     */
    public String getDeliveryAddress() {
        getElementInView(deliveryAddress);
        commonMethods.waitForElement(driver,prjDAddress1,30);
        return $(prjDAddress1).getAttribute("value");
    }
}
