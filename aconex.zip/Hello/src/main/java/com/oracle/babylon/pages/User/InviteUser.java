package com.oracle.babylon.pages.User;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.WebDriverRunner;
import com.oracle.babylon.Utils.helper.Navigator;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class InviteUser extends Navigator {
    public InviteUser() {
        this.driver = WebDriverRunner.getWebDriver();
    }
    private By inviteUserBtn =By.xpath("//button[text()='Invite user']");
    private By inviteUserModal=By.xpath("//div[@class='auiModal-content']//div[text()='Invite user']");
    private By inviteUserInput=By.xpath("//div[@class='auiModal-body ng-scope']//div[starts-with(@class,'auiSelect ui-select-container ui-select-multiple')]//input");
    private By selectUser=By.xpath("//span[@class='ui-select-choices-row-inner']//div");
    private By closeSelectedUserButton=By.xpath("//span[@class='ui-select-match ng-scope']//*[@class='close ui-select-match-close']");
    private By inviteUsersBtn=By.xpath("//div[@class='auiModal-footer']//span[contains(text(),'Invite')]");
    private By cancelBtn=By.xpath("//button[contains(text(),'Cancel')]");
    private By sendEmailNotificationsLabel=By.xpath("//label['Send email notification']");
    private By advancedSearchBtn=By.xpath("//button[text()='Advanced Search']");
    private By targetList=By.xpath("//h2[text()='Target List']");
    private By addAsFullUser=By.xpath("//div[@id='searchResultsToolbar']//button[@id='btnAddFull_page']//div[text()='Add as Full User']");
    private By addAsShadowUser=By.xpath("//div[@id='searchResultsToolbar']//button[@id='btnAddShadow_page']//div[text()='Add as Shadow User']");
    private By targetListUser=By.xpath("//div[@id='recipients']//td[@colspan]");
    private By loadMoreResults=By.xpath("//span[@class='ui-select-choices-row-inner']//div//span[contains(text(),'Load more results')]");
    private By searchResultsSize=By.xpath("//span[@class='ui-select-choices-row-inner']//div[@class='ng-binding ng-scope']");
    private By addUsers = By.xpath("//span[text()='Invite 1 user']");
    private By noResults = By.xpath("//div[text()='No results']");
    @Override
    public WebElement menuFinder(String css, String text) {
        return super.menuFinder(css, text);
    }

    public void clickInviteUser()
    {
        commonMethods.waitForElement(driver, inviteUserBtn);
        $(inviteUserBtn).click();
    }

    public void verifyInviteUserPopUp()
    {
        Assert.assertTrue($(inviteUserModal).isDisplayed());
        Assert.assertTrue($(inviteUsersBtn).isDisplayed());
        Assert.assertTrue($(cancelBtn).isDisplayed());
        Assert.assertTrue($(sendEmailNotificationsLabel).isDisplayed());
    }

    public void validateUserClose(String userName)
    {
        commonMethods.waitForElement(driver,inviteUserInput);
        selectUser(userName);
        commonMethods.waitForElement(driver,closeSelectedUserButton);
        $(closeSelectedUserButton).click();
    }

    public void selectUser(String userName)    {
        $(inviteUserInput).sendKeys(userName);
        $(selectUser).click();
    }

    /**
     * Method to enter the user name in the text box
     * @param userName
     */
    public void enterUser(String userName){
        $(inviteUserInput).sendKeys(userName);

    }
    public void repeatSearchUser(String userName)
    {
        commonMethods.waitForElement(driver,inviteUserInput);
        $(inviteUserInput).sendKeys(userName);
        $(selectUser).shouldBe(Condition.hidden);
    }

    public int getNoOfUsersInvited()
    {
        String noOfUsers=$(inviteUsersBtn).getText().substring(7,8);
        return Integer.valueOf(noOfUsers);
    }

    public void clickInviteBtn()
    {
        commonMethods.waitForElement(driver,inviteUsersBtn);
        $(inviteUsersBtn).click();
    }
    public void clickAdvancedSearchBtn()
    {
        commonMethods.waitForElement(driver,advancedSearchBtn);
        $(advancedSearchBtn).click();
    }
    public void verifyAdvancedSearchBtn(Boolean instance)
    {
        if(instance)
            $(advancedSearchBtn).shouldBe(Condition.appear);
        else
            $(advancedSearchBtn).shouldBe(Condition.hidden);
    }


    public void verifyAdvancedSearchPanel()
    {
        $(targetList).shouldBe(Condition.appear);
        $(addAsFullUser).shouldBe(Condition.appear);
        $(addAsShadowUser).shouldBe(Condition.appear);
    }

    /**
     * Method to return the user in the target list
     * @return
     */
    public String getTargetListUser()
    {
        $(addAsFullUser).click();
        commonMethods.waitForElement(driver,targetListUser);
        return $(targetListUser).getText();
    }

    /**
     * Method to return all the loaded results
     * @param searchKeyword
     * @return
     */
    public int returnLoadedResults(String searchKeyword)
    {
        commonMethods.waitForElement(driver,inviteUserInput);
        $(inviteUserInput).sendKeys(searchKeyword);
        $(selectUser).shouldBe(Condition.appear);
        return $$(searchResultsSize).size();
    }

    /**
     * Method to load more results
     * @return
     */
    public int clickLoadMoreResults()
    {
        $(loadMoreResults).scrollTo();
        $(loadMoreResults).shouldBe(Condition.appear);
        $(loadMoreResults).click();
        commonMethods.waitForElementExplicitly(3000);
        return $$(searchResultsSize).size();
    }

    /**
     * Method to click on invite user button after users are added in the text box
     */
    public void clickInviteUsers(){
        $(addUsers).click();
    }

    /**
     * Method to assert if no results are returned when we search for users
     */
    public void assertNoResults(){
        commonMethods.waitForElement(driver, noResults);
        Assert.assertTrue($(noResults).isDisplayed());

    }
}
