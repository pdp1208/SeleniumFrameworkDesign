package com.oracle.babylon.pages.Setup;
import org.openqa.selenium.By;

import java.util.List;

import static com.codeborne.selenide.Selenide.$;

public class AvailableUserRoleSettings {

    private By saveBtn = By.xpath("//button[@id='btnSave']");
    public By userRoleConfigBtn = By.xpath("//button[@id='btnViewRolesSecuredAssets']");

    /**
     * Method to set a asset in the list
     * @param assetName
     */
    public void setAsset(String assetName){

         By assedId = By.xpath("//label[contains(.,'"+ assetName + "')]//..//input");
         if(!$(assedId).isSelected()){
             $(assedId).click();
         }
         $(saveBtn).click();
    }

    /**
     * Method to set a assets in the list
     *
     * @param assets list of assets.
     */
    public void setAssets(List<String> assets){
        for(String asset : assets){
            By assedId = By.xpath("//label[contains(.,'"+ asset + "')]//..//input");
            if(!$(assedId).isSelected()){
                $(assedId).click();
            }
        }
        $(saveBtn).click();
    }

    /**
     * Method to navigate to Configure User Role Settings Page.
     *
     */
    public void navigateToConfigureUserRoleSettingPage(){
        $(userRoleConfigBtn).click();
    }

    /**
     * Method to unset a asset in the list
     * @param assetName
     */
    public void unsetAsset(String assetName){
        $(By.xpath("//label[contains(.,'"+ assetName + "')]//..//input")).setSelected(false);
        $(saveBtn).click();
    }
}