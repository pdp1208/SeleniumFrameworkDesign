package com.oracle.babylon.pages.Package;

import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

import static com.codeborne.selenide.Selenide.$;

public class SearchPackage extends Navigator {

    private By title = By.xpath("//div[text()='Search - Packages']");
    private By packageNumber = By.xpath("//div[text()='Package No']//..//input");
    private By packageTitle = By.xpath("//div[text()='Package Title']//..//input");
    private By newPackage = By.xpath("//a[text()='New Package']");
    private By tableRows = By.xpath("//table[@class='auiTable']//tbody//tr");
    private By firstPackage = By.xpath("//table[@class='auiTable']//tbody//tr//td[3]//a");
    private By packageTypeSelect = By.xpath("//select[@name='package_type']");
    private By stateSelect = By.xpath("//select[@name='state']");
    private By applyFilter = By.xpath("//button[@id='btnApply']");
    private By nameField = By.xpath("//input[@ng-model='configuration.name']");
    private By savedSearchBtn = By.xpath("//button//div[contains(text(),'Saved Searches')]");
    private By deleteSavedSearch = By.xpath("//button[text()='Delete']");
    private By confirmDeleteBtn = By.xpath("//button[text()='Yes, Delete']");
    private By description = By.xpath("//div[@class='configuration-items']//textarea");

    public void navigateAndVerifyPage(){
        getMenuSubmenu("Packages", "Packages");
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, title);
        Assert.assertTrue("Packages page title is not displayed", $(title).isDisplayed());
    }

    /**
     * Method to search the package through package number
     * @param packageNo
     */
    public void searchPackage(String packageNo){
    	$(packageNumber).clear();
        $(packageNumber).sendKeys(packageNo);
        $(packageNumber).sendKeys(Keys.ENTER);
    }

    public void clickFirstPackage(){
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, firstPackage);
        $(firstPackage).click();
    }

    /**
     * Method to validate if the package is present for the user
     */
    public void verifyPackageAvailable(){
        commonMethods.waitForElement(driver, tableRows);
        int count = driver.findElements(tableRows).size();
        Assert.assertTrue("Package count is not matched", count == 1);
    }

    /**
     * Method that returns the package number from the search package page
     * @param rowNumber
     * @return
     */
    public String returnPackageNo(int rowNumber){
        By packageNumber = By.xpath("//table[@class='auiTable']//tbody//tr[" + rowNumber + "]//td[2]//span");
        return $(packageNumber).getText();
    }

    /**
     * Method that returns the package title from the search package page
     * @param rowNumber
     * @return
     */
    public String returnPackageTitle(int rowNumber){
        By packageTitle = By.xpath("//table[@class='auiTable']//tbody//tr[" + rowNumber + "]//td[3]//a");
        return $(packageTitle).getText();
    }
    /**
     * Method that returns the package number from the search package page
     * @param rowNumber
     * @return
     */
    public String returnRevision(int rowNumber){
        By revision = By.xpath("//table[@class='auiTable']//tbody//tr[" + rowNumber + "]//td[4]");
        return $(revision).getText();
    }

    /**
     * Method to select the value of package drop down
     * @param packageType
     */
    public void selectPackageType(String packageType){
        $(packageTypeSelect).click();
        Select select = new Select($(packageTypeSelect));
        select.selectByVisibleText(packageType);
    }

    /**
     * Method to select the value of state drop down
     * @param packageType
     */
    public void selectState(String packageType){
        $(stateSelect).click();
        Select select = new Select($(stateSelect));
        select.selectByVisibleText(packageType);
    }

    /**
     * Method to click on Apply Filter button
     */
    public void clickApplyFilter(){
        $(applyFilter).click();;
    }

    /**
     * Method to click on the saved search button
     */
    public void clickSavedSearchBtn() {
        $(savedSearchBtn).click();
    }

    /**
     * Method to create a saved search
     *
     * @param name
     * @param criteria
     */
    public void createSavedSearch(String name, String criteria) {
        if (verifySavedSearch(name)) {
            deleteSavedSearch(name);
        }
        clickSaveBtn();
        commonMethods.waitForElement(driver, nameField);
        $(nameField).clear();
        $(nameField).sendKeys(name);
        $(description).sendKeys("This is a " + name + " Saved search");
        By by = By.xpath("//input[@value='" + criteria + "']");
        $(by).setSelected(true);
        clickSaveBtn();
    }

    /**
     * Method to verify if the package saved searches are displayed
     *
     * @param savedSearch
     * @param type
     * @return
     */
    public boolean verifySaveSearchList(String savedSearch, String type) {
        By by;
        if (type.equalsIgnoreCase("org")) {
            by = By.xpath("//strong[text()='My Organization's Searches']//..//li//label[text()='" + savedSearch + "']");
        } else if (type.equalsIgnoreCase("project")) {
            by = By.xpath("//strong[text()='My Project's Searches']//..//li//label[text()='" + savedSearch + "']");
        } else {
            by = By.xpath("//strong[text()='My Searches']//..//li//label[text()='" + savedSearch + "']");
        }
        return $(by).isDisplayed();
    }

    /**
     * Function to verify created saved search
     */
    public Boolean verifySavedSearch(String mySavedSearch) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, savedSearchBtn, 30);
        $(savedSearchBtn).click();
        commonMethods.waitForElementExplicitly(2000);
        By savedSearch = By.xpath("//div[@id='savedsearches']//label[text()='" + mySavedSearch + "']");
        try {
            commonMethods.waitForElement(driver, savedSearch, 20);
        } catch (TimeoutException e) {
            System.out.println("Element not found Proceeding");
        }
        return $(savedSearch).isDisplayed();
    }

    /**
     * Function to Delete saved My searches
     *
     * @param savedSearchName
     */
    public void deleteSavedSearch(String savedSearchName) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, savedSearchBtn, 30);
        $(savedSearchBtn).click();
        if ($(By.xpath("//div[text()='" + savedSearchName + "']/../following-sibling::div//span[@title='Edit saved search']")).isDisplayed()) {
            $(By.xpath("//div[text()='" + savedSearchName + "']/../following-sibling::div//span[@title='Edit saved search']")).click();
            commonMethods.waitForElementExplicitly(1000);
            $(deleteSavedSearch).click();
            commonMethods.waitForElement(driver, confirmDeleteBtn, 20);
            $(confirmDeleteBtn).click();
        }
    }
}
