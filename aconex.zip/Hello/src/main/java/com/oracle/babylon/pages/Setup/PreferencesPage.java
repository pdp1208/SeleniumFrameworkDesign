package com.oracle.babylon.pages.Setup;

import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Selenide.*;


public class PreferencesPage extends Navigator {
    protected By prefTable = By.xpath("//table[@class='indented dataTable preferences-table']");
    protected By saveButton = By.xpath("//div[contains(text(),'Save')]");
    protected By closeBtn = By.xpath("//div[contains(text(),'Close')]");
    protected By userLookup = By.xpath("//input[@id='lookupUsers_query']");
    protected By accessListOkBtn = By.xpath("//div[@id='accessListPanel']//button[contains(.,'OK')]");
    protected String tblPreferences = "//table[@class='indented dataTable preferences-table']";
    private By plainTextBtn = By.xpath("//button//div[contains(text(),'New - Plain Text')]");
    private By newHtmlBtn = By.xpath("//button//div[contains(text(),'New - HTML')]");
    private By autoTextName = By.xpath("//tr[1]//td[contains(.,'Auto Text Name')]//following-sibling::td//input");
    private By signatureName = By.xpath("//tr[1]//td[contains(.,'Signature Name')]//following-sibling::td//input");
    private By signatureTextArea = By.xpath("//tr[2]//td[contains(.,'Signature')]//following-sibling::td//textarea");
    private By autoTextNameSelect = By.xpath("//tr[1]//td[contains(.,'Auto Text Name')]//following-sibling::td//select");
    private By signatureNameSelect = By.xpath("//tr[1]//td[contains(.,'Signature Name')]//following-sibling::td//select");
    private By autoText = By.xpath("//tr[2]//td[contains(.,'Auto Text')]//following-sibling::td//textarea");
    private By selectedMailTypes = By.xpath("//tr[3]//td[contains(.,'Mail Type')]//following-sibling::td//div[contains(@class,'uiBidi-right')]//select");
    private By autoTextSaveBtn = By.xpath("//button//div[contains(text(),'Save')]");
    private By saveMessage = By.xpath("//li[@class='message success']//*[contains(text(),'Save complete')]");
    private By message = By.xpath("//div[@class='page']//ul[@class='messagePanel']");
    private By htmlAutoText = By.xpath("//body[contains(@class,'cke_editable cke_editable_themed cke_contents_ltr cke_show_borders')]//p");
    private By htmlAutoTextArea = By.xpath("//div[@id='cke_editor1']");
    private By autoTextNameLabel = By.xpath("//table[@class='formTable']//tr[1]//td[contains(.,'Auto Text Name')]");
    private By autoSignatureNameLabel = By.xpath("//table[@class='formTable']//tr[1]//td[contains(.,'Signature Name')]");
    private By autoTextConfigureOkBtn = By.xpath("//div[@id='btnEditMailTypeSettings_panel']//div[contains(text(),'OK')]");
    private By deleteAutoTextBtn = By.xpath("//div[contains(text(),'Delete')]");
    private By signatureDefaultBtn = By.xpath("//div[contains(text(),'Set To Default')]");
    private By mailAutoTextHtmlframe = By.xpath("//iframe[contains(@class,'cke_wysiwyg_frame cke_reset')]");
    private By defaultSelectedAutoTextField = By.xpath("//div[@id='btnEditMailTypeSettings_panel']//select[@id='SELECTED_DEFAULT_AUTOTEXT']");
    private By removeBtn = By.xpath("//button[@title='Remove item from list']");
    private By okButton = By.xpath("//div[@id='documentColumnsPanel_buttons']//button[@title='OK and close window']");
    private By okTempButton = By.xpath("//button[@id='btntempRegisterColumnsPanel_ok' and @title='OK and close window']");
    private By okWorkflowBtn = By.xpath("//button[@id='btnworkflowColumnsPanel_ok' and @title='OK and close window']");
    private By addButton = By.xpath("//button[@title='Add item to list']");
    private By allSelectedItems = By.xpath("//div[@class='uiBidi-right']//select//option");
    private By itemsInSelectedList = By.xpath("//div[@class='uiBidi-right']//select//option[1]");

    private By reasonForIssueTypes = By.xpath("//table//table[@class='dataTable']//tbody//tr//td[1]");
    private By reasonForIssueTextArea = By.xpath("//form[@id='command']/table[1]//textarea[@name='PREFERENCE_mailreasonforissuelist_new']");
    private By reasonForIssueAddBtn = By.xpath("//form[@id='command']/table[1]//a[contains(.,'Add')]");
    private By reasonDefaultCheckBox = By.xpath("//input[@name='reset' and @value='reset']");
    private By userTab = By.xpath("//li[@id='user-tab']");
    private By projectTab = By.xpath("//li[@id='project-tab']");
    private By orgTab = By.xpath("//li[@id='organization-tab']");
    private By defaultTab = By.xpath("//li[@id='default-tab']");
    private By reasonIssueChkBox = By.xpath("//table//table[@class='dataTable']//tbody//tr//td[2]//input");
    protected By userDocLabel = By.xpath("(//tr[@class='dataSubGroup'])[1]//td");
    protected By projectDocLabel = By.xpath("(//tr[@class='dataSubGroup'])[3]//td");
    protected By orgDocLabel = By.xpath("(//tr[@class='dataSubGroup'])[4]//td");
    private By reasonForIssueValues = By.xpath("//table[@class='dataTable']//td[1]");

    private By rows = By.xpath("//table[@class='dataTable']//tr");
    private By autoRegDefault =By.xpath("//input[@name='PREFERENCE_autoregisterfromtransmittal_USE_DEFAULT']");
    private By autoRegDisplay=By.xpath("//input[@name='PREFERENCE_autoregisterfromtransmittal_DISPLAY']");

    private By sltNotificationTypes = By.xpath("//select[@name='PREFERENCE_notificationssend_DISPLAY']");
    private By lblPreventEmail = By.xpath("//td[@id='notifications.email.responded.td']");
    private By ckbBoxPrvntEmailSetting = By.xpath("//input[@name='PREFERENCE_notificationsemailresponded_DISPLAY']");
    private By configDefaultColSearchReg= By.xpath("//table[@class='indented dataTable preferences-table']//tr[@id='documentregistereddefaultcolumns.tr']//td/button");
    private By configDefaultColTempFiles= By.xpath("//table[@class='indented dataTable preferences-table']//tr[@id='documentunregistereddefaultcolumns.tr']//td/button");
    private By warningMessage= By.xpath("//div[@class='message check']");
    /**
     * Function select default setting checkbox for preference
     *
     * @param tab
     */
    public void navigateAndVerifyPage(String tab) {
        commonMethods.waitForElementExplicitly(2000);
        getMenuSubmenu("Setup", "Preferences");
        verifyAndSwitchFrame();
        if (tab.equalsIgnoreCase("projecttab") || tab.equalsIgnoreCase("project")) {
            verifyAndSwitchFrame();
            commonMethods.waitForElement(driver, projectTab, 20);
            $(projectTab).click();
        }
        if (tab.equalsIgnoreCase("organisation") || tab.equalsIgnoreCase("organization") || tab.equalsIgnoreCase("org tab")) {
            verifyAndSwitchFrame();
            commonMethods.waitForElement(driver, orgTab, 20);
            $(orgTab).click();
        }
        if (tab.equalsIgnoreCase("default") || tab.equalsIgnoreCase("default tab")) {
            verifyAndSwitchFrame();
            commonMethods.waitForElement(driver, defaultTab, 20);
            $(defaultTab).click();
        }
        sleep(3000);
        verifyPageTitle("Edit Preferences");
    }


    /**
     * Function select default setting checkbox for preference
     *
     * @param preference
     */
    public void selectDefaultSettings(String preference, Boolean flag) {
        int prefRow = getPrefRow(preference);
        WebElement checkBox = driver.findElement(prefTable).findElement(By.xpath("//tr[" + prefRow + "]//td[3]//input[@type='checkbox']"));
        $(checkBox).setSelected(flag);
    }

    /**
     * Function to click edit button for preference
     *
     * @param preference
     */
    public void clickEditButtonForSetting(String preference) {
        int prefRow = getPrefRow(preference);
        int prefCol = 2;
        WebElement editButton = driver.findElement(prefTable).findElement(By.xpath("//tr[" + prefRow + "]//td[" + prefCol + "]//div[@class='uiButton-label'][contains(text(),'Edit')]"));
        editButton.click();
    }

    /**
     * Function to select setting for preference
     *
     * @param preference
     * @param option
     */
    public void selectSettingFrom(String preference, String option) {
        int prefRow = getPrefRow(preference);
        int settingCol = 2;
        int defaultSettingColumn = 3;
        WebElement checkBox = driver.findElement(prefTable).findElement(By.xpath("//tr[" + prefRow + "]//td[" + defaultSettingColumn + "]//input[@type='checkbox']"));
        if (!checkBox.isSelected()) {
            selectOption(option, prefRow, settingCol);
        } else if (checkBox.isSelected()) {
            checkBox.click();
            selectOption(option, prefRow, settingCol);
        }
    }

    /**
     * Function to select option from dropdown for preference
     *
     * @param option
     * @param row
     * @param column
     */
    public void selectOption(String option, int row, int column) {
        WebElement selectOptionFromList = driver.findElement(prefTable).findElement(By.xpath("//tr[" + row + "]//td[" + column + "]//select"));
        $(selectOptionFromList).selectOption(option);
    }

    /**
     * Function to select non default setting for preferences
     *
     * @param preference
     * @param flag
     */
    public void selectNonDefaultSettings(String preference, String flag) {
        commonMethods.waitForElementExplicitly(4000);
        int prefRow = getPrefRow(preference);
        int defaultsettingCol = 3;
        int settingColumn = 2;
        boolean setting = Boolean.parseBoolean(flag.toLowerCase());
        WebElement defaultSettingcheckBox = driver.findElement(prefTable).findElement(By.xpath("//tr[" + prefRow + "]//td[" + defaultsettingCol + "]//input[@type='checkbox']"));
        WebElement settingCheckbox = driver.findElement(prefTable).findElement(By.xpath("//tr[" + prefRow + "]//td[" + settingColumn + "]//input[@type='checkbox']"));
        if (setting) {
            if (defaultSettingcheckBox.isSelected()) {
                defaultSettingcheckBox.click();
                if (settingCheckbox.isSelected()) {
                    $(saveButton).click();
                } else {
                    settingCheckbox.click();
                    $(saveButton).click();
                }
            } else {
                if (settingCheckbox.isSelected()) {
                    $(saveButton).click();
                } else {
                    settingCheckbox.click();
                    $(saveButton).click();
                }
            }
        } else {
            if (defaultSettingcheckBox.isSelected()) {
                defaultSettingcheckBox.click();
                if (settingCheckbox.isSelected()) {
                    settingCheckbox.click();
                    $(saveButton).click();
                } else {
                    $(saveButton).click();
                }
            } else {
                if (settingCheckbox.isSelected()) {
                    settingCheckbox.click();
                    $(saveButton).click();
                } else {
                    $(saveButton).click();
                }
            }
        }
        commonMethods.waitForElement(driver, closeBtn);
        $(closeBtn).click();
        driver.navigate().refresh();
    }

    /**
     * Function to get preference row in table
     *
     * @param prefName
     */
    public int getPrefRow(String prefName) {
        switchToOriginal();
        verifyAndSwitchFrame();
        List<WebElement> prefLists;
        commonMethods.waitForElement(driver, prefTable, 10);
        prefLists = driver.findElement(prefTable).findElements(By.xpath("//tr//td[1]"));
        int prefRow = 0;
        for (int i = 1; i < prefLists.size(); i++) {
            if (prefLists.get(i).getText().contains(prefName)) {
                prefRow = i + 3;
                break;
            }
        }
        return prefRow;
    }


    /**
     * Function to select default setting and add/remove user form list
     *
     * @param preference name of preferences
     * @param flag       true or false
     */
    public void setDefaultSetting(String preference, String flag) {
        verifyAndSwitchFrame();
        int prefRow = getPrefRow(preference);
        int defaultSettingCol = 3;
        int settingColumn = 2;
        boolean setting = Boolean.parseBoolean(flag.toLowerCase());
        WebElement defaultSettingCheckBox = driver.findElement(prefTable).findElement(By.xpath("//tr[" + prefRow + "]//td[" + defaultSettingCol + "]//input[@type='checkbox']"));
        if (flag.equals("true")) {
            if (!defaultSettingCheckBox.isSelected()) {
                defaultSettingCheckBox.click();
            }
        }
        if (flag.equals("false")) {
            if (defaultSettingCheckBox.isSelected()) {
                defaultSettingCheckBox.click();
                By checkBoxElement = By.xpath("//table[@class='indented dataTable preferences-table']//tr[" + prefRow + "]//td[" + settingColumn + "]//input");
                if ($(checkBoxElement).isDisplayed()) {
                    if (!$(checkBoxElement).isSelected()) {
                        $(checkBoxElement).click();
                    }
                }
            }
        }
    }

    public void saveAndClose() {
        verifyAndSwitchFrame();
        $(saveButton).click();
        if(commonMethods.isAlertPresent(driver)){
            acceptAlert();
        }else{
            commonMethods.waitForElement(driver, closeBtn, 10);
            $(closeBtn).click();
        }

    }


    /**
     * Function to add users in access list
     *
     * @param users list of users
     */
    public void editAccessList(List<String> users) {
        verifyAndSwitchFrame();
        for (String user : users) {
            jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
            userMap = jsonMapOfMap.get(user);
            $(userLookup).clear();
            $(userLookup).sendKeys(userMap.get("full_name").toString());
            $(userLookup).sendKeys(Keys.ENTER);
            commonMethods.waitForElementExplicitly(3000);
        }
        getElementInView(accessListOkBtn);
        $(accessListOkBtn).click();
    }

    /**
     * Function to get all selected Items in Add Remove column pop up
     *
     * @return
     */

    public List<String> getAllSelectedItems() {
        verifyAndSwitchFrame();
        List<String> allSelText = new ArrayList<>();
        commonMethods.waitForElement(driver, allSelectedItems, 40);
        List<WebElement> allItems = driver.findElements(allSelectedItems);
        for (WebElement e : allItems) {
            allSelText.add(e.getText());
        }
        return allSelText;
    }

    /**
     * Function to remove column names from selected List
     */

    public void removeColumns() {
        verifyAndSwitchFrame();
        List<String> allSelectItems = getAllSelectedItems();
        for (int i = 1; i <= allSelectItems.size(); i++) {
            $(itemsInSelectedList).click();
            commonMethods.waitForElement(driver, removeBtn, 3);
            $(removeBtn).click();
        }
    }

    /**
     * Function to verify if preference is present or not
     *
     * @param preferenceName
     */
    public boolean verifyPreferencesPresent(String preferenceName) {
        verifyAndSwitchFrame();
        List<WebElement> prefLists = driver.findElement(prefTable).findElements(By.xpath("//tr//td[1]"));
        for (WebElement e : prefLists) {
            if (e.getText().toLowerCase().trim().contains(preferenceName.toLowerCase())) return true;
        }
        return false;
    }

    /**
     * Function to verify preference can be edit
     *
     * @param preference
     */
    public boolean verifyPreferenceEditable(String preference) {
        verifyAndSwitchFrame();
        WebElement editButton = driver.findElement(prefTable).findElement(By.xpath("//tr[" + getPrefRow(preference) + "]//td[2]//div[@class='uiButton-label'][contains(text(),'Edit')]"));
        return editButton.isDisplayed();
    }


    /**
     * Function to verify elements present in mail auto text and signature page
     *
     * @param elements as list
     */
    public void verifyElement(List<String> elements) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, autoTextSaveBtn, 20);
        for (String element : elements) {
            switch (element.toLowerCase()) {
                case "new - plain text":
                    Assert.assertTrue($(plainTextBtn).exists());
                    break;
                case "new - html":
                    Assert.assertTrue($(newHtmlBtn).exists());
                    break;
                case "auto text name":
                    Assert.assertTrue($(autoTextName).exists());
                    break;
                case "auto text":
                    Assert.assertTrue($(autoText).exists());
                    break;
                case "mail type":
                    Assert.assertTrue($(selectedMailTypes).exists());
                    break;
                case "Signature Name":
                    Assert.assertTrue($(signatureName).exists());
                    break;
                case "Signature Text":
                    Assert.assertTrue($(signatureTextArea).exists());
                    break;
            }
        }
    }

    /**
     * Function to add column names to Selected List
     *
     * @param data
     */

    public void addSelectedColumns(String preference, List<String> data) {
        verifyAndSwitchFrame();
        for (String text : data) {
            $(By.xpath("//option[@title='" + text + "']")).click();
            commonMethods.waitForElement(driver, addButton, 3);
            $(addButton).click();
        }
        if (preference.contains("Registered Documents")) {
            $(okButton).click();
        } else if (preference.contains("Workflows")) {
            $(okWorkflowBtn).click();
        } else {
            $(okTempButton).click();
        }

        commonMethods.waitForElement(driver, closeBtn, 35);
        $(closeBtn).click();
    }

    /**
     * Function to set auto text name
     *
     * @param name
     */
    public void fillAutoTextName(String name) {
        switchTo().defaultContent();
        verifyAndSwitchFrame();
        $(autoTextName).setValue(name);
    }

    /**
     * Function to fill auto text for mail
     *
     * @param description
     */
    public void fillAutoText(String description) {
        verifyAndSwitchFrame();
        $(autoText).setValue(description);
    }

    /**
     * Function to fill auto signature text for mail
     *
     * @param description
     */
    public void fillSignatureText(String description) {
        verifyAndSwitchFrame();
        $(signatureTextArea).setValue(description);
    }

    /**
     * Function to fill signature name for mail
     *
     * @param name
     */
    public void fillSignatureName(String name) {
        verifyAndSwitchFrame();
        $(signatureName).sendKeys(name);
    }

    /**
     * Function to select mail type for auto text configuration
     *
     * @param selectMailType
     */
    public void selectMailType(String selectMailType) {
        verifyAndSwitchFrame();
        String[] mailTypes = selectMailType.split(",");
        for (String mailType : mailTypes) {
            $(By.xpath("//body//tr[3]//td[2]//div[@class='uiBidi-left']//select/option[contains(.,'" + mailType + "')]")).doubleClick();
        }
    }


    /**
     * Function to click new plain text button
     */
    public void clickNewPlainText() {
        verifyAndSwitchFrame();
        $(plainTextBtn).click();
    }

    /**
     * Function to click new html text button
     */
    public void clickNewHtml() {
        verifyAndSwitchFrame();
        $(newHtmlBtn).click();
    }

    /**
     * Function to click save button on auto text page
     */
    public void autoTextSave() {
        verifyAndSwitchFrame();
        $(autoTextSaveBtn).click();
    }

    /**
     * Function to verify auto text / signature save complete
     */
    public void verifySaveComplete() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(4000);
        Assert.assertTrue($(saveMessage).exists());
    }


    /**
     * Function to verify  duplicate auto text / signature name
     */
    public void verifyDuplicateNameError(String caseValue) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, message, 5);
        switch (caseValue.toLowerCase()) {
            case "auto text":
                Assert.assertTrue($(message).text().contains("Please choose a different name for this Auto Text"));
                break;
            case "signature":
                Assert.assertTrue($(message).text().contains("Please choose a different name for this Signature"));
        }

    }

    /**
     * Function to set html auto text description for mail
     *
     * @param text
     */
    public void fillHtmlAutoText(String text) {
        verifyAndSwitchFrame();
        $(htmlAutoTextArea).click();
        verifyAndSwitchFrame(mailAutoTextHtmlframe);
        $(htmlAutoText).sendKeys(text);
    }

    /**
     * Function to set html auto signature description for mail
     *
     * @param text
     */
    public void fillHtmlSignatureText(String text) {
        verifyAndSwitchFrame();
        $(htmlAutoTextArea).click();
        switchTo().frame($(mailAutoTextHtmlframe));
        $(htmlAutoText).sendKeys(text);
    }

    /**
     * Function to delete auto text for mails
     */
    public void deleteAutoText() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, deleteAutoTextBtn, 6);
        $(deleteAutoTextBtn).click();
    }


    /**
     * Function to verify delete button
     */
    public boolean verifyDeleteButton() {
        verifyAndSwitchFrame();
        return $(deleteAutoTextBtn).exists();
    }

    /**
     * Function to set signature as default
     */
    public void setDefaultSignature() {
        verifyAndSwitchFrame();
        $(signatureDefaultBtn).click();

    }

    /**
     * Function to delete auto text for mails
     */
    public void deleteAutoTextName(String name) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, autoTextNameLabel, 20);
        if ($(autoTextNameSelect).exists()) {
            if ($(By.xpath("//tr[1]//td[contains(.,'Auto Text Name')]//following-sibling::td//select//option[contains(.,'" + name + "')]")).exists()) {
                $(autoTextNameSelect).selectOptionByValue(name);
                deleteAutoText();
            }
        }
    }

    /**
     * Function to delete auto signature for mails
     */
    public void deleteSignatureName(String name) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, autoSignatureNameLabel, 20);
        if ($(signatureNameSelect).exists()) {
            if ($(By.xpath("//tr[1]//td[contains(.,'Signature Name')]//following-sibling::td//select//option[contains(.,'" + name + "')]")).exists()) {
                $(signatureNameSelect).selectOptionByValue(name);
                deleteAutoText();
            }
        }
    }

    /**
     * Function to select mail type in configure mail type option
     *
     * @param mailType
     */
    public void selectAutoText(String mailType) {
        verifyAndSwitchFrame();
        $(By.xpath("//table[@class='dataTable']//tr[contains(.,'" + mailType + "')]//button")).click();
    }

    /**
     * Function to select mail type auto text default
     *
     * @param autoTextName
     */
    public void selectAutoTextDefault(String autoTextName) {
        verifyAndSwitchFrame();
        if ($(By.xpath("//div[@id='btnEditMailTypeSettings_panel']//select[@id='SELECTED_DEFAULT_AUTOTEXT']/option[contains(.,'" + autoTextName + "')]")).exists()) {
            $(defaultSelectedAutoTextField).selectOptionContainingText(autoTextName);
        }
    }

    /**
     * Function to click ok button on auto text page
     */
    public void clickConfigureAutoTextOk() {
        verifyAndSwitchFrame();
        $(autoTextConfigureOkBtn).click();
        sleep(2000);
    }

    /**
     * Function to select mail signature as default
     *
     * @param signature
     */
    public void selectDefaultSignature(String signature) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, autoSignatureNameLabel, 20);
        if ($(signatureNameSelect).exists()) {
            if ($(By.xpath("//tr[1]//td[contains(.,'Signature Name')]//following-sibling::td//select//option[contains(.,'" + commonMethods.getMailNumFromJson(signature) + "')]")).exists()) {
                $(signatureNameSelect).selectOptionByValue(commonMethods.getMailNumFromJson(signature));
                setDefaultSignature();
                sleep(2000);
            }
        }

    }

    /**
     * Function to all reason for issue assigned to project mail
     */
    public List<String> getAllReasonForIssueTypes() {
        verifyAndSwitchFrame();
        List<String> values = new ArrayList<>();
        for (WebElement e : driver.findElements(reasonForIssueTypes)) {
            values.add(e.getText());
        }
        return values;
    }

    /**
     * Function to add reason for issue
     */
    public List<String> addReasonForIssue(List<String> types) {
        verifyAndSwitchFrame();
        for (String type : types) {
            $(reasonForIssueTextArea).sendKeys(type);
            $(reasonForIssueTextArea).sendKeys(Keys.ENTER);
        }
        $(reasonForIssueAddBtn).click();
        sleep(2000);
        closeAlertMsg();
        return getAllReasonForIssueTypes();
    }

    /**
     * Function to verify that duplicate reason for issue cannot be added
     *
     * @param reason for issue name
     */
    public void verifyDuplicateReason(String reason) {
        verifyAndSwitchFrame();
        $(reasonForIssueTextArea).sendKeys(reason);
        $(reasonForIssueAddBtn).click();
        sleep(2000);
        Assert.assertTrue($(warningMessage).getText().trim().equalsIgnoreCase("The following item is a duplicate and will not be added: " + reason + ""));
        closeAlertMsg();
    }


    /**
     * Function to remomve reason for issue
     *
     * @param types for issue name
     */
    public List<String> removeReasonForIssue(List<String> types) {
        verifyAndSwitchFrame();
        for (String type : types) {
            $(By.xpath("//table//table[@class='dataTable']//tbody//tr[contains(.,'" + type + "')]//td[2]//input")).setSelected(true);
        }
        saveAndClose();
        return getAllReasonForIssueTypes();
    }


    /**
     * Function to remomve reason for issue if available in the list
     *
     * @param types for issue name
     */
    public List<String> removeReasonForIssueIfAvailable(List<String> types) {
        verifyAndSwitchFrame();
        for (String type : types) {
            if ($(By.xpath("//table//table[@class='dataTable']//tbody//tr[contains(.,'" + type + "')]//td[2]//input")).isDisplayed()) {
                $(By.xpath("//table//table[@class='dataTable']//tbody//tr[contains(.,'" + type + "')]//td[2]//input")).setSelected(true);
            }
        }
        $(saveButton).click();
        sleep(2000);
        closeAlertMsg();
        return getAllReasonForIssueTypes();
    }

    /**
     * Function to set reason for issue to default value set by admin
     */
    public void setReasonToDefault() {
        verifyAndSwitchFrame();
        $(reasonDefaultCheckBox).setSelected(true);
        $(saveButton).click();
        sleep(2000);
        closeAlertMsg();
    }

    /**
     * Function to remomve all reason for issues
     */
    public boolean removeAllIssues() {
        verifyAndSwitchFrame();
        int size = driver.findElements(reasonIssueChkBox).size();
        for (int i = 1; i <= size; i++) {
            $(By.xpath("//table//table[@class='dataTable']//tbody//tr[" + i + "]//td[2]//input")).setSelected(true);
        }
       saveAndClose();
        return $(reasonIssueChkBox).isDisplayed();
    }

    /**
     * Function to validate the Label Instances on preferences page - On User, Projects and Organization tab
     *
     * @param instance
     */

    public void validateDocType(String instance) {
        verifyAndSwitchFrame();
        $(userTab).click();
        commonMethods.waitForElement(driver, userDocLabel);
        Assert.assertEquals($(userDocLabel).getText(), instance);
        $(projectTab).click();
        commonMethods.waitForElement(driver, projectDocLabel);
        Assert.assertTrue($(By.xpath("(//tr[@class='dataSubGroup']//td[contains(text(),'"+instance+"')])[1]")).isDisplayed());
        $(orgTab).click();
        commonMethods.waitForElement(driver, orgDocLabel);
        Assert.assertEquals($(orgDocLabel).getText(), instance);
    }

    /**
     * Function to verify reason for issue values
     *
     * @return
     */
    public ArrayList verifyReasonForIssueValues() {
        ArrayList reasonForIssueValuesTxt = new ArrayList();
        List<WebElement> options = driver.findElements(reasonForIssueValues);
        for (int i = 0; i <= options.size() - 1; i++) {
            String optionsText = options.get(i).getText();
            reasonForIssueValuesTxt.add(optionsText);
        }
        return reasonForIssueValuesTxt;
    }


    /**
     * Method to return the string values of the data
     * @return
     */
    public List<String> returnValues(){
        commonMethods.waitForElementExplicitly(1500);
        List<String> values = new ArrayList<>();
        List<WebElement> elements = driver.findElements(rows);
        for (int i=2;i<elements.size();i++) {
            WebElement element = driver.findElement(By.xpath("//table[@class='dataTable']//tr[" + i + "]//td[1]//input"));
            if(element.getAttribute("checked")!=null&&element.getAttribute("checked").equalsIgnoreCase("true")){
                values.add(driver.findElement(By.xpath("//table[@class='dataTable']//tr[" + i + "]//td[3]")).getText());
            }
        }
        clickBackButton();
        return values;
    }

    /**
     * Method to set the checkbox based on instance for the Automatic Update on Register
     * @return
     */
    public void setAutoRegister(boolean instance)
    {
        commonMethods.waitForElement(driver,autoRegDefault);
        $(autoRegDefault).setSelected(instance);
        if(instance==false)
            $(autoRegDisplay).setSelected(instance);
    }

    /**
     * Method to verify email notifications type
     * @return
     */
    public List<String> verifyEmailNotificationTypes() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, sltNotificationTypes, 20);
        return commonMethods.returnAllOptionsInDropDown(driver, sltNotificationTypes);
    }

    /**
     * Method to select email notifications type
     * @return
     */
    public void selectEmailNotification(String option) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, sltNotificationTypes, 20);
        commonMethods.enterDropdownValue(sltNotificationTypes, option);
        if(commonMethods.isAlertPresent(driver))
            commonMethods.acceptAlert(driver);
    }

    /**
     * Method to verify prevent email option
     * @return
     */
    public boolean verifyPreventEmail() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(5000);
        return $(lblPreventEmail).isDisplayed();
    }

    /**
     * Method to return select mail notification selected option
     * @return
     */
    public String verifyNotificationOption() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, sltNotificationTypes, 20);
        return $(sltNotificationTypes).getSelectedOption().getText();
    }

    /**
     * Method to return Prevent Email Default Notification s
     * @return
     */
    public String verifyPreventEmailSetting() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, ckbBoxPrvntEmailSetting, 20);
        return $(ckbBoxPrvntEmailSetting).getAttribute("checked");
    }

    /**
     * Method to verify metadata copied from source to new project for default col in doc and temp search register
     * @return
     */
    public boolean verifyConfigDefaultCol() {
        return $(configDefaultColSearchReg).isDisplayed() && $(configDefaultColTempFiles).isDisplayed();
       }

     /**
     * Function to verify default setting checked or not
     *
     * @param preference name of preferences
     */
    public boolean verifyDefaultSetting(String preference) {
        verifyAndSwitchFrame();
        int prefRow = getPrefRow(preference);
        int defaultSettingCol = 3;
        WebElement defaultSettingCheckBox = driver.findElement(prefTable).findElement(By.xpath("//tr[" + prefRow + "]//td[" + defaultSettingCol + "]//input[@type='checkbox']"));
        return defaultSettingCheckBox.isSelected();
    }

    /**
     * Function to add users in access list
     *
     * @param users list of users
     */
    public void verifyAccessList(List<String> users) {
        verifyAndSwitchFrame();
        for (String user : users) {
            jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
            userMap = jsonMapOfMap.get(user);
            $(userLookup).clear();
            $(userLookup).sendKeys(userMap.get("full_name").toString());
            $(userLookup).sendKeys(Keys.ENTER);
            commonMethods.waitForElementExplicitly(3000);
        }
        getElementInView(accessListOkBtn);
        $(accessListOkBtn).click();
    }

    /**
     * Method to select and set the project invitation method
     * @param preferenceMap
     */
    public void selectProjectInvitation(Map<String, String> preferenceMap) {
        for(String key:preferenceMap.keySet()){
            By by = By.xpath("//td[contains(text(),'"+ key +"')]//..//select");
            By checkbox = By.xpath("//td[contains(text(),'"+ key +"')]//..//input[@value='remove']");
            $(checkbox).setSelected(false);
            $(by).click();
            Select select = new Select($(by));
            String value = preferenceMap.get(key).replaceAll(" ","");
            select.selectByValue(value);
        }


    }

    /**
     * Method to return the value of the checkbox for a property
     * @param settingName
     * @param condition
     * @return
     */
    public String returnChecked(String settingName, String condition) {
        int prefRow = getPrefRow(settingName);
        int defaultSettingCol = 3;
        int settingColumn = 2;
        if(condition.contains("default")){
            WebElement defaultSettingsChkBox = driver.findElement(prefTable).findElement(By.xpath("//tr[" + prefRow + "]//td[" + defaultSettingCol + "]//input[@type='checkbox']"));
            return String.valueOf(defaultSettingsChkBox.isSelected());
        } else {
            WebElement settingChkBox = driver.findElement(prefTable).findElement(By.xpath("//tr[" + prefRow + "]//td[" + settingColumn + "]//input[@type='checkbox']"));
            return String.valueOf(settingChkBox.isSelected());

        }

    }
}

