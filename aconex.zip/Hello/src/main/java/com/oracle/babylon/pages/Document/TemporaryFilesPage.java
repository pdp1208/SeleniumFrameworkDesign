package com.oracle.babylon.pages.Document;

import com.codeborne.selenide.WebDriverRunner;
import com.oracle.babylon.Utils.helper.FileOperations;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Selenide.$;

public class TemporaryFilesPage extends DocumentPage {

    private By pageTitle = By.xpath("//h1[contains(text(),'Search -')]//span[text()='Temporary Files']");
    private By documentRegisterPage = By.xpath("//h1[contains(text(),'Search -')]//span[text()='Document Register']");
    private By documentRegisterTab = By.xpath("//li[contains(.,'Document Register')]");
    private By deleteBtn = By.xpath("//button[@title='Delete this item']");
    private By noResultsFound = By.xpath("//p[text()='No results found matching your search criteria.']");
    private By showMyUploads = By.xpath("//input[@id='isShowUploadedByMeOnly']");
    private By moveToRegister = By.xpath("//button[contains(text(),'Move to Register')]");
    private By title = By.xpath("//div[@col-id='title']");
    private By revision = By.xpath("//input[@name='revision']");
    private By discipline = By.xpath("//select[@id = 'discipline']");
    private By revisionDate = By.xpath("//input[@title='Revision Date']");
    private By registerBtn = By.xpath("//button[contains(text(),'Register')]");
    private By projectChangerArrow = By.xpath("//span[@class='projectChanger-arrow']");
    private By registerMessage = By.xpath("//div[@class='auiMessage-content']//span[contains(.,'document moved to your organization's Document Register')]");
    private By successMessage = By.xpath("//div[@class='auiMessage success']");
    private By openFullSearch = By.xpath("//div[contains(text(),'Open Full Search Page')]");
    private By docTitle = By.xpath("//input[@name='title']");
    private By docUploadSuccess = By.xpath("//div[@class='auiMessage success']");
    private By candidateDocNo = By.xpath("//div[not(@role='presentation') and @col-id='candidateno']");
    private By downloadOption  = By.xpath("//div[@class='auiMenuButton-dropdownContents']//a[text()='Download']");
    private By autoAssigned  = By.xpath("//input[@value='-- Auto assigned --']");
    private By btnDelete = By.xpath("//button[@id='btnDeleteUnregDoc']");
    private By updateCandidateCheckBox = By.xpath("//input[@id='isShowSupercedeCandidates']");
    private By btnUpdate = By.xpath("//button[@id='bulkSupersede']");
    private By fileNames = By.xpath("//div[@col-id='filename' and @role='gridcell']");
    SimpleDateFormat formatter = new SimpleDateFormat("dd-HH-mm-ss");
    Actions action = new Actions(driver);
    FileOperations fileOperations=new FileOperations();
    private By docNoGrid = By.xpath("//div[@id='MoveToRegisterGrid']//tbody//tr//td[2]");

    public TemporaryFilesPage() {
        this.driver = WebDriverRunner.getWebDriver();
    }

    /**
     * Method to navigate to Document and verify for the title of the page
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Documents", "Temporary Files");
        commonMethods.waitForElementExplicitly(3000);
        Assert.assertTrue(verifyPageTitle(pageTitle));
    }

    /**
     * Method to navigate to Document and verify for the title of the page
     */
    public void navigateAndVerifyPage(String instance) {
        getMenuSubmenu(instance, "Temporary Files");
        commonMethods.waitForElementExplicitly(3000);
        Assert.assertTrue(verifyPageTitle(pageTitle));
    }

    /**
     * Default method to verify page title
     */
    public void verifyPageTitle() {
        super.verifyPageTitle(pageTitle);
    }

    /**
     * Method to switch to Document Register
     */
    public void switchToDocRegister() {
        verifyAndSwitchFrame();
        $(documentRegisterTab).click();
        Assert.assertTrue(verifyPageTitle(documentRegisterPage));
    }

    /**
     * Method to click delete button
     */
    public void clickDeleteBtn() {
        $(deleteBtn).click();
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.acceptAlert(driver);
        commonMethods.acceptAlert(driver);
    }

    /**
     * Method to click on show my uploads only
     */

    public void clickShowMyUploads() {
        verifyAndSwitchFrame();
        if (!$(showMyUploads).isSelected()) {
            $(showMyUploads).click();
        }
    }

    /**
     * Method to click on Move To Register
     */

    public void clickMoveToRegisterBtn() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, moveToRegister);
        commonMethods.waitForElementExplicitly(1000);
        $(moveToRegister).click();
    }

    /**
     * Method to fill the details of Register Document page
     *
     * @param data
     */

    public void enterRegisterDocumentFields(String data) {
        verifyAndSwitchFrame();
        Map<String, String> table = dataStore.getTable(data);
        commonMethods.waitForElement(driver, type, 60);
        String documentNumber = "";
        Date dt = new Date();
        String name = "";
        if (table.get("Title") == null) {
            name = faker.file().fileName().substring(0, 6);
            if(name.contains("_")) name = name.replace('_', name.toCharArray()[0]);
            if(name.contains("\\")) name = name.replace('\\', name.toCharArray()[0]);
            documentNumber = name + "_" + formatter.format(dt);
        } else {
            documentNumber = table.get("Title");
        }

        //When we are superseding the old document number has to persist
        if (!$(docTitle).getAttribute("value").equalsIgnoreCase("")) {
            commonMethods.waitForElement(driver, docTitle, 60);
            documentNumber = $(docTitle).getAttribute("value");
        }
        documentNumber = documentNumber.replace(" ", "");
        if ($(docTitle).getAttribute("value").equalsIgnoreCase("")) {
            commonMethods.waitForElement(driver, docTitle, 60);
            $(docTitle).clear();
            $(docTitle).sendKeys(documentNumber);
        }
        for (String tableData : table.keySet()) {
            switch (tableData.toLowerCase()) {
                case "document no":
//                        String number = table.get("Title") + " " + formatter.format(dt);
                    commonMethods.setDocumentNumInJson((table.get("Document No")), documentNumber);
                    if(!$(autoAssigned).isDisplayed())
                    $(documentNumberField).clear();
                    $(documentNumberField).sendKeys(documentNumber);
                    break;
                case "type":
                    $(type).selectOptionContainingText(table.get(tableData));
                    break;
                case "revision":
                    $(revision).sendKeys(table.get(tableData));
                    break;
                case "status":
                    if ($(status).exists()) {
                        $(status).selectOptionContainingText(table.get(tableData));
                    }
                    break;
                case "discipline":
                    $(discipline).selectOptionContainingText(table.get(tableData));
                    break;
                case "revision date":
                    if ($(revisionDate).isDisplayed()) {
                        $(revisionDate).sendKeys(commonMethods.getTodayDate(configFileReader.getTimeZone()));
                        $(revisionDate).sendKeys(Keys.ENTER);
                    }
                    break;
                case "version":
                    action.moveToElement($(version)).click().sendKeys(table.get(tableData)).build().perform();
                    break;

            }
//                case "document no":
//                    Date dt = new Date();
//                    String number = table.get("Title") + " " + formatter.format(dt);
//                    commonMethods.setDocumentNumInJson((table.get("Document No")), number);
//                    action.moveToElement($(documentNumberField)).click().sendKeys(number).build().perform();
//                    break;
//                case "revision":
//                    action.moveToElement($(revision)).click().sendKeys(table.get(tableData)).build().perform();
//                    break;
//                case "version":
//                    action.moveToElement($(version)).click().sendKeys(table.get(tableData)).build().perform();
//                    break;
//                case "type":
//                    action.moveToElement($(type)).click().build().perform();
//                    Select selectobj = new Select($(type));
//                    selectobj.selectByVisibleText(table.get(tableData));
//                    break;
//                case "title":
//                    action.moveToElement($(title)).click().sendKeys(table.get(tableData)).build().perform();
//                    break;
//                case "description":
//                    action.moveToElement($(description)).click().sendKeys(table.get(tableData)).build().perform();
//                    break;
//                case "status":
//                    action.moveToElement($(status)).click().build().perform();
//                    Select selobj = new Select($(status));
//                    selobj.selectByVisibleText(table.get(tableData));
//                    break;
//                case "discipline":
//                    Select selobject = new Select($(discipline));
//                    selobject.selectByVisibleText(table.get(tableData));
//                    break;
//                case "revision date":
//                    $(revisionDate).click();
//                    $(revisionDate).sendKeys(commonMethods.getTodayDate("Australia/Sydney"));
//                    $(revisionDate).sendKeys(Keys.ENTER);
//                    break;
        }
    }

    /**
     * Method to click on Register button
     */

    public void clickRegisterBtn() {
        commonMethods.waitForElementExplicitly(4000);
        commonMethods.clickOnElement(registerBtn);
    }

    /**
     * Method to check whether register message is displayed
     *
     * @return
     */

    public boolean verifyRegisterMessage() {
        return $(registerMessage).isDisplayed();
    }

    /**
     * Method to verify success message on move to register
     */
    public void verifySuccessRegisterMessage(String instance) {
        commonMethods.waitForElement(driver, docUploadSuccess,55);
        Assert.assertTrue($(docUploadSuccess).getText().contains(instance.toLowerCase() + "(s) moved to " + instance + " Register of your organization"));
    }


    /**
     * Method to change project to different one
     */

    public void selectDifferentProject(String project) {
        driver.switchTo().defaultContent();
        $(projectChangerArrow).click();
        $(By.xpath("//div[@class='projectChanger-list']//span[contains(text(),'" + project + "')]")).click();
    }

    /**
     * Method to get the number of rows of the results returned
     * @return
     */
    public int getRowCount(){
        List<WebElement> list = driver.findElements(candidateDocNo);
        return list.size()-1;
    }


    /**
     * Method to return the title of the file that the search result returns
     * @return
     */
    public String getFileTitle(){
        List<WebElement> fileList = driver.findElements(title);
        return fileList.get(1).getText();
    }

    /**
     * Function to click on update button
     */
    public List<String> verifyTempFiles(){
        verifyAndSwitchFrame();
        return commonMethods.getValues(candidateDocNo);
    }

    /**
     * Method to click delete button from old temporary files screen
     */
    public void clickDelete() {
        $(btnDelete).click();
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.acceptAlert(driver);
    }

    /**
     * Function to verify the candidate number
     *
     * @param docNum
     * @return
     */
    public boolean verifyDocument(String docNum) {
        driver = WebDriverRunner.getWebDriver();
        String docNo = returnCandidateDocumentNumber(driver);
        return docNo.contains(commonMethods.returnDocNumberInJson(docNum));
    }

    /**
     * Function to click on checkbox show update candidate
     */

    public void clickShowUpdateCandidate(boolean value) {
        $(updateCandidateCheckBox).setSelected(value);
    }

    /**
     * Function to click on update button
     */

    public void clickUpdate() {
        commonMethods.waitForElement(driver, btnUpdate, 60);
        $(btnUpdate).click();
    }

    /**
     * Function to get the file names from the temp file register
     */
    public List<String> verifyTempFileNames(){
        commonMethods.waitForElementExplicitly(2000);
        return commonMethods.getValues(fileNames);
    }

    /**
     * Method to verify success message on move to temporary files
     */
    public boolean verifySuccessTempFile() {
        commonMethods.waitForElement(driver, docUploadSuccess,55);
        return $(docUploadSuccess).getText().contains("moved to the temporary files");
    }

    /**
     * Function to click on document number in move to register page
     */
    public void clickDocNoMoveRegister(int number) {
        commonMethods.waitForElementExplicitly(2000);
        $(By.xpath("//div[@id='MoveToRegisterGrid']//tbody//tr["+number+"]//td[2]")).click();
    }
}