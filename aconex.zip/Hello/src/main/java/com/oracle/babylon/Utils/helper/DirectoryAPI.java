package com.oracle.babylon.Utils.helper;


import com.oracle.babylon.Utils.setup.dataStore.DataSetup;
import com.oracle.babylon.Utils.setup.utils.ConfigFileReader;
import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class DirectoryAPI extends APIHelper {

    ConfigFileReader configFileReader = new ConfigFileReader();
    protected Map<String, Map<String, Object>> jsonMapOfMap = null;
    protected Map<String, Object> userMap = null;
    protected String userDataPath = configFileReader.getUserDataPath();
    DataSetup dataSetup = new DataSetup();
    APIHelper apiHelper = new APIHelper();

    /**
     * Method to return the user id by calling the directory api.
     * Given and Family names are used as query params
     *
     */
    public List<String> searchProjectDirectory(String userIdentifiers, String projectId) {
        String[] names = userIdentifiers.split(",");
        List<String> userIds = new ArrayList<>();
        for (String name : names) {
            Map<String, Object> userMap = dataSetup.loadJsonDataToMap(userDataPath).get(name);
            String fullName = userMap.get("full_name").toString();
            String given_name = fullName.split(" ")[0];
            String family_name = fullName.split(" ")[1];
            String url = ConfigFileReader.getApplicationUrl() + "api/projects/" + projectId + "/directory?" +
                    "given_name=" + given_name + "&family_name=" + family_name;
            String basicAuth = basicAuthCredentialsProvider(name);
            HttpResponse response = apiHelper.getRequest(url, basicAuth, configFileReader.getContentType());

            try {
                String json = EntityUtils.toString(response.getEntity());
                System.out.println(json);
                JSONObject jsonObj = new JSONObject(json);
                JSONArray searchResults = (JSONArray) (jsonObj.get("searchResults"));
                jsonObj = searchResults.getJSONObject(0);
                userIds.add(jsonObj.get("userId").toString());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return userIds;
    }

    /**
     * Method to return the user id by calling the User Information API.
     *
     */
    public List<String> viewUserInformation(String userIdentifiers) {
        String[] names = userIdentifiers.split(",");
        List<String> userIds = new LinkedList<>();
        for (String name : names) {
            String url = ConfigFileReader.getApplicationUrl() + "api/user";
            String basicAuth = basicAuthCredentialsProvider(name);
            HttpResponse response = apiHelper.getRequest(url, basicAuth, configFileReader.getContentType());
            try {
                String json = EntityUtils.toString(response.getEntity());
                System.out.println(json);
                JSONObject jsonObj = new JSONObject(json);
                userIds.add(jsonObj.get("userId").toString());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return userIds;
    }

}
