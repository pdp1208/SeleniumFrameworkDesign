package com.oracle.babylon.pages.Document;

import org.junit.Assert;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Selenide.$;

/**
 * Class that contains all the methods specific to the Document Register search filter chips
 */
public class SmartFoldersTab extends DocumentRegisterPage {

    //Initialization of Web Elements
    private By tabDocRegister = By.xpath("//li[@id='CDRegisteredList']");
    private By tabDrawings = By.xpath("//li[@id='drawingList']");
    private By tabTempFiles = By.xpath("//li[@id='CDUnregisteredList']");
    private By tabApproved = By.xpath("//li[contains(text(),'Approved')]");
    private By tabIssuedForApproval = By.xpath("//li[contains(text(),'Issued for approval')]");
    private By tabDrawingsModifiedToday = By.xpath("//li[contains(text(),'Drawings modified today')]");
    private By tabTempFilesUploadedByMe = By.xpath("//li[contains(text(),'Temporary files uploaded by me today')]");
    private By lnkCollapse = By.xpath("//a[contains(text(),'Collapse')]");
    private By pageTitle = By.xpath("//div[@id='header']//h1");
    private By loadingIcon = By.cssSelector(".loading_progress");

    public void collpaseSmartFolders() {
        if($(lnkCollapse).isDisplayed()) {
            $(lnkCollapse).click();
        }
    }

    public void navigateToSmartFolderTabs(String tabName) {
        verifyAndSwitchFrame();
        expandSmartFolders();
        switch (tabName.toLowerCase()) {
            case "document register":
                $(tabDocRegister).click();
                break;
            case "drawings":
                $(tabDrawings).click();
                break;
            case "temporary files":
                $(tabTempFiles).click();
                break;
        }
        $(loadingIcon).should(disappear);
        commonMethods.waitForElementExplicitly(1000);
        Assert.assertTrue(verifyPageTitle(pageTitle));
    }

    public void navigateToSavedSearch(String searchName) {
        verifyAndSwitchFrame();
        expandSmartFolders();
        $(By.xpath("//li[@title='"+ searchName + "']")).click();
        $(loadingIcon).should(disappear);
    }

}
