package com.oracle.babylon.pages.Tenders;

import com.oracle.babylon.Utils.setup.utils.ConfigFileReader;
import com.oracle.babylon.pages.Document.DocumentPage;
import org.junit.Assert;
import org.openqa.selenium.By;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.sleep;

public class TenderAddendaPage extends TenderPage {

    private By addendaSubject = By.xpath("//input[@id='subject']");
    private By addendaBody = By.xpath("//textarea[@id='addendumNote']");
    private By addendaNote = By.xpath("//td[text()='Addendum Note']");
    private By addendaSendBtn = By.xpath("//button[@id='btnSendAddendum']//div[contains(text(),'Send')]");
    private By createAddendumBtn = By.xpath("//div[contains(text(),'Create Addendum')]");
    private By subjectLbl = By.xpath("//label[text()='Subject']//..//..//td[2]");
    private By tableSubject = By.xpath("//div[@id='tenderTabContent']//table//tbody//td[2]//span");
    private By body = By.xpath("//table[contains(@class,'formTable')]//tbody//tr[3]");

    private By attachFromDocument = By.xpath("//ul[@id='attachFileMenu']//div[contains(text(),'Documents')]");
    private By attachBtn = By.xpath("//div[@id='attachDocs_buttons']//button[@title='Attach a File']");
    private By editAttachBtn = By.xpath("//span[@id='btnAttach']//button[@title='Attach a File']");
    private By closeBtn = By.xpath("//button[@id='btnexcludedDocs_ok']");
    private By addendaLink = By.xpath("//span[@class='textlink']");
    private By recipientUser = By.xpath("//li[@class='user']");
    private By closingDateLabel = By.xpath("//td//label[text()='Closing Date']");
    private By previousValueLabel = By.xpath("//td//label[text()='Previous Value']");
    private By updatedValueLabel = By.xpath("//td//label[text()='Updated Value']");
    private By previousValue = By.xpath("//td//label[text()='Closing Date']//..//following::td[1]//label");
    private By updatedValue = By.xpath("//td//label[text()='Closing Date']//..//following::td[3]//label");
    private By editBtn = By.xpath("//button[@id='btnEditAddendum']");
    private By draftInProgress = By.xpath("//div[text()='Draft in progress']");
    private By draftSuccess = By.xpath("//div[contains(text(),'Your Addendum has been saved to draft at')]");
    private By coverLetter = By.xpath("//textarea[@id='coverLetter']");
    private By noAddenda = By.xpath("//td[text()='No addendum has been created']");
    private By selectAddenda = By.xpath("//div[contains(text(),'Select an Addendum from the list above')]");
    private By binIcon = By.xpath("//div[@class='auiIcon trash']");
    private By submissionChkBox = By.xpath("//input[@id='allowSubmissionWhenClosed']");
    private By addendumDetails = By.xpath("//div[@id='addendumDetails']//h2");
    private By selectAll = By.xpath("(//ul//li/div[text()='Select All'])[3]");
    protected Map<String, Map<String, Object>> jsonMapOfMap = null;
    protected Map<String, Object> userMap = null;
    private DocumentPage documentPage = new DocumentPage();
    ConfigFileReader configFileReader = new ConfigFileReader();
    String tenderFilePath = configFileReader.getTenderDataPath();
    Map<String, Map<String, Object>> jsonData = new HashMap<>();
    Map<String, Object> map = new HashMap<>();

    /**
     * Method to click create addendum button
     */
    public void clickCreateAddendum() {
        verifyAndSwitchFrame();
        $(createAddendumBtn).click();
    }


    /**
     * Method to verify tender addendum button
     */
    public boolean verifyCreateAddendumBtn(){
        return $(createAddendumBtn).isDisplayed();
    }
    /**
     * Method to create a addendum
     *
     * @param attribute details for addendum
     */
    public void createAddendum(String attribute) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(3000);
        Map<String, String> table = dataStore.getTable(attribute);
        for (String tableData : table.keySet()) {
            switch (tableData) {
                case "Subject":
                    enterAddendumSubject(table.get(tableData));
                    break;
                case "Body":
                    enterAddendumBody(table.get(tableData));
                    break;
                case "Attachment":
                    attachDocument(table.get(tableData));
                    break;
                case "Local Attachment":
                    attachLocalFile(table.get(tableData));
                    break;
                case "Closing Date":
                    String[] closingDateTime = table.get(tableData).split(",");
                    String day = closingDateTime[0];
                    String date = commonMethods.getDate(configFileReader.getTimeZone(), day);
                    String[] time = closingDateTime[1].split(":");
                    enterClosingDate(date, time);
                    commonMethods.waitForElementExplicitly(5000);
                    break;
                case "Initiator Contact":
                    commonMethods.waitForElementExplicitly(500);
                    String[] initiators = table.get(tableData).split(",");
                    for (String initiator : initiators) {
                        Map<String, Map<String, Object>> mapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
                        Map<String, Object> userMap = mapOfMap.get(initiator);
                        String fullName = userMap.get("full_name").toString();
                        enterContactInitiator(fullName);
                    }
                    commonMethods.waitForElementExplicitly(1000);
                    break;
            }

        }
    }


    /**
     * Method to enter addendum subject
     */
    public void enterAddendumSubject(String subject) {
        verifyAndSwitchFrame();
        $(addendaSubject).clear();
        $(addendaSubject).sendKeys(subject);
    }

    /**
     * Method to enter addendum body details
     */
    public void enterAddendumBody(String body) {
        verifyAndSwitchFrame();
        $(addendaBody).clear();
        $(addendaBody).click();
        $(addendaBody).sendKeys(body);
    }

    /**
     * Method to fill the body field
     * @param body
     */
    public void fillAddendaBody(String body){
        $(addendaBody).sendKeys(body);
        commonMethods.waitForElementExplicitly(1500);
    }

    /**
     * Method to click on edit tender addenda
     */
    public void clickEdit(){
        $(editBtn).click();

    }
    /**
     * Method to send addendum
     */
    public void sendAddenda() {
        commonMethods.scrollPageUp(driver);
        $(addendaSendBtn).click();
        driver.switchTo().alert().accept();
    }

    /**
     * Method to click on the addenda
     */
    public void clickAddenda(){
        commonMethods.waitForElement(driver, addendaLink);
        $(addendaLink).click();
    }

    public boolean verifyDraft(){
        return $(draftInProgress).isDisplayed();
    }
    /**
     * Method to verify Addendum
     *
     * @param addenda details
     */
    public void verifyAddendum(String addenda) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(3000);
        Map<String, String> table = dataStore.getTable(addenda);
        $(By.xpath("//div[@id='addendaGrid']//tbody//tr[td[contains(.,'" + table.get("Subject") + "')]]//td[2]//span")).click();
        for (String tableData : table.keySet()) {
            switch (tableData) {
                case "Subject":
                    Assert.assertTrue($(subjectLbl).getText().contains(table.get(tableData)));
                    break;
                case "Body":
                    Assert.assertTrue($(body).getText().contains(table.get(tableData)));
                    break;
                case "Tender no":
                    jsonData = dataSetup.loadJsonDataToMap(tenderFilePath);
                    map = jsonData.get(table.get(tableData));
                    String tenderNo = map.get("tender_num").toString();
                    Assert.assertTrue($(By.xpath("//h2[contains(text(),'"+ tenderNo +"')]")).isDisplayed());
                    break;
                case "userid":
                    jsonData = dataSetup.loadJsonDataToMap(userDataPath);
                    map = jsonData.get(table.get(tableData));
                    String fullName = map.get("full_name").toString();
                    String orgName = map.get("org_name").toString();
                    Assert.assertTrue($(recipientUser).getText().contains(fullName + " - " + orgName));
                    break;

            }

        }

    }

    /**
     * Function to Attach a Document from Tender Addenda Page
     *
     * @param documentNum
     */
    public void attachDocument(String documentNum) {
        verifyAndSwitchFrame();
        getElementInView(coverLetter);
        commonMethods.waitForElement(driver, attachDropDown);
        $(attachDropDown).click();
        $(attachFromDocument).click();
        commonMethods.waitForElementExplicitly(2000);
        verifyAndSwitchFrame("attachDocs_iframe");
        documentPage.searchDocumentNo(commonMethods.returnDocNumberInJson(documentNum));
        sleep(1000);
        documentPage.selectAllRecords();
        driver.switchTo().defaultContent();
        verifyAndSwitchFrame();
        $(attachBtn).click();
        commonMethods.waitForElement(driver, closeBtn, 35);
        $(closeBtn).click();
    }

    public boolean validateTable(List<String> inputList){

        boolean flag = true;
        commonMethods.waitForElementExplicitly(2000);
        for(String input:inputList){
            By xpath = By.xpath("//div[text()='"+ input +"']");
            if(!$(xpath).isDisplayed()){
                flag = false;
            }
        }
        return flag;
    }

    public void validateClosingDate(){
        commonMethods.waitForElement(driver, closingDateLabel);
        Assert.assertTrue($(closingDateLabel).isDisplayed());
        Assert.assertTrue(!$(previousValue).getText().isEmpty());
        Assert.assertTrue(!$(updatedValue).getText().isEmpty());
        Assert.assertTrue($(previousValueLabel).isDisplayed());
        Assert.assertTrue($(updatedValueLabel).isDisplayed());
    }

    public void clickSaveDraftBtn(){
        commonMethods.scrollPageUp(driver);
        commonMethods.waitForElement(driver, saveToDraft);
        $(saveToDraft).click();
    }

    public boolean returnSuccessMsg() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, draftSuccess);
        return $(draftSuccess).isDisplayed();
    }

    public void removeInitiator(String fullName) {
        By deleteIcon = By.xpath("//td//div[contains(text(),'"+ fullName +"')]//following::td");
        $(deleteIcon).click();
    }


    public void enterCoverLetter(String coverLetterStr) {
        $(coverLetter).sendKeys(coverLetterStr);

    }

    public String returnSubjectLength() {
        return $(addendaSubject).getAttribute("maxlength");
    }

    public String returnBody() {
        return $(addendaBody).getText();
    }

    public boolean returnHeaderPresent() {
        commonMethods.waitForElement(driver, addendaNote);
        return $(addendaNote).isDisplayed();
    }

    public boolean returnNoAddendaMsg() {
        commonMethods.waitForElement(driver, noAddenda);
        return $(noAddenda).isDisplayed();
    }

    public boolean selectAddendaMsg() {
        return $(selectAddenda).isDisplayed();
    }

    public void btnPresent() {
        Assert.assertTrue($(saveToDraft).isDisplayed());
        Assert.assertTrue($(addendaSendBtn).isDisplayed());
        Assert.assertTrue($(binIcon).isDisplayed());
        commonMethods.scrollToBottom(driver);
        Assert.assertTrue($(editAttachBtn).isDisplayed());
    }

    public void txtFieldPresent() {
        Assert.assertTrue($(coverLetter).isDisplayed());
        Assert.assertTrue($(addendaBody).isDisplayed());
        Assert.assertTrue($(addendaSubject).isDisplayed());
    }

    public void otherFieldPresent() {
        Assert.assertTrue($(closingDate).isDisplayed());
        Assert.assertTrue($(contactInitiator).isDisplayed());
        Assert.assertTrue($(submissionChkBox).isDisplayed());
    }



    public void clickSubmissionChkBox(boolean value) {
        $(submissionChkBox).setSelected(value);
    }



    public String returnSubject() {
        return $(tableSubject).getText();
    }

    public void lblPresent() {
        Assert.assertTrue($(subjectLbl).isDisplayed());
        Assert.assertTrue($(body).isDisplayed());
    }

    /**
     * Method to verify addendum details in tender addenda page.
     */
    public boolean verifyAddenda(String value) {
        commonMethods.waitForElement(driver, addendaTab, 60);
        return $(addendumDetails).getText().contains(value);
    }

    /**
     * Method to select all attached documents
     */
    public void selectAllDocs() {
        commonMethods.waitForElement(driver, selectAllMenu, 60);
        $(selectAllMenu).click();
        $(selectAll).click();
    }
}
