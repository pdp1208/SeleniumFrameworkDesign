package com.oracle.babylon.pages.Workflows;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static com.codeborne.selenide.Selenide.*;

/**
 * Class to handle the actions of the Workflow reports page
 * All the verifications will be done inside the reports page
 * created by sai
 */
public class WorkflowReportsPage extends WorkflowsPage {

    private By hdrWorkflowReports = By.xpath("//div[@id='header']//h1");
    private By btnBack = By.xpath("//button[@id='btnBack']");
    private By btnExportToExcel = By.xpath("//div[contains(text(),'Export to Excel')]");
    private By txtAddress = By.xpath("//div[@id='main']/table//tr[2]/td[@class='HEADING2']");
    private By lblLegend = By.xpath("//td[contains(text(),'Legend')]");
    private By tblColumns = By.xpath("//table[@class='dataTable']//tbody/tr[1]/td");
    private String tblDocRows = "//table[@class='dataTable']//tbody/tr";
    private By hdrExportToExcel = By.xpath("//h1[contains(text(),'Export to Excel Status')]");
    private By btnTemporaryFiles = By.xpath("//button//div[contains(text(),'Temporary Files')]");
    private By txtSuccessMessage = By.xpath("//div[contains(text(),'Export to Excel has successfully commenced. It will run in the background as a low-priority process.')]");
    private By txtEmailNotification = By.xpath("//div[contains(text(),'Export to Excel has successfully commenced. It will run in the background as a low-priority process.')]");
    private By txtClickTempFiles = By.xpath("//p[contains(text(),'Click below to view your temporary files')]");

    /**
     * Function to verify page title
     */
    public void verifyPage(String title) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, hdrWorkflowReports, 60);
        Assert.assertTrue($(hdrWorkflowReports).getText().contains(title));
    }

    /**
     * Function to click on back button
     */
    public void clickBackBtn() {
        commonMethods.waitForElement(driver, btnBack, 40);
        $(btnBack).click();
    }

    /**
     * Function to verify reports page headers and buttons
     */
    public void verifyReportsPage(String wfName, String projectName, Map<String, String> headers) {
        verifyAndSwitchFrame();
        Assert.assertTrue($(hdrWorkflowReports).getText().contains(wfName));
        Assert.assertTrue($(btnBack).isDisplayed());
        Assert.assertTrue($(btnExportToExcel).isDisplayed());
        Assert.assertTrue($(By.xpath("//td[contains(text(),'" + projectName + "')]")).isDisplayed());
        Assert.assertTrue($(txtAddress).isDisplayed());
        Assert.assertTrue($(lblLegend).isDisplayed());
        for (String key : headers.keySet()) {
            if (key.equalsIgnoreCase("Step Headers"))
                Assert.assertTrue(getTableHeaders(1).containsAll(Arrays.asList(headers.get(key).split(":"))));
            else if (key.equalsIgnoreCase("Field Headers"))
                Assert.assertTrue(getTableHeaders(2).containsAll(Arrays.asList(headers.get(key).split(":"))));
        }
    }

    /**
     * Function to get report headers
     */
    public List<String> getTableHeaders(int headerRow) {
        List<WebElement> elements = new ArrayList<>($$(By.xpath("//table[@class='dataTable']//tr[@class='dataHeaders'][" + headerRow + "]/th")));
        List<String> headers = new ArrayList<>();
        for (WebElement element : elements)
            headers.add(element.getText().replace("\n", " "));
        return headers;
    }

    /**
     * Function to return document details
     */
    public String getDocDetails(String key, int row) {
        return $(By.xpath("//table[@class='dataTable']/tbody/tr[" + row + "]/td[" + getColIndex(key) + "]")).getText();
    }

    /**
     * Function to return step outcome details
     */
    public String getStepOutcomes(int key, int row) {
        return $(By.xpath("//table[@class='dataTable']/tbody/tr[" + row + "]/td[" + key + "]")).getText();
    }

    /**
     * Function to return column index
     */
    public int getColIndex(String colName) {
        List<String> headers = getTableHeaders(2);
        return headers.indexOf(colName) + 1;
    }

    /**
     * Function to return column index
     */
    public List<Integer> getColIndexes(String colName) {
        List<String> headers = getTableHeaders(2);
        return IntStream.range(0, headers.size()).filter(i -> colName.equals(headers.get(i))).boxed().collect(Collectors.toList());
    }

    /**
     * Function to get all steps outcome details
     */
    public List<String> getStepOutcomeDetails(List<Integer> indexes, int row) {
        List<String> values = new ArrayList<>();
        for (int index : indexes)
            values.add(getStepOutcomes(index + 1, row).trim());
        return values;
    }

    /**
     * Function to get color code of steps
     */
    public String getColorCode(Integer index, int row) {
        return commonMethods.getBGColorInHex($(By.xpath("//table[@class='dataTable']/tbody/tr[" + row + "]/td[" + index + "]")).getCssValue("background-color"));
    }

    /**
     * Function to get workflow status details
     */
    public String getWorkFlowStatus(String colName, int row) {
        if (colName.equalsIgnoreCase("Workflow Status"))
            return getWFOverallStatus(getColumnsCount() - 2, row).trim();
        else if (colName.equalsIgnoreCase("Overall Days Late"))
            return getWFOverallStatus(getColumnsCount() - 1, row).trim();
        else if (colName.equalsIgnoreCase("Notes"))
            return getWFOverallStatus(getColumnsCount(), row).trim();
        else return getWFOverallStatus(getColIndex(colName), row).trim();
    }

    public int getColumnsCount() {
        return $$(tblColumns).size();
    }

    /**
     * Function to get legend color
     */
    public String getWFStatusColor(String colName, int row) {
        String xpath = "//table[@class='dataTable']/tbody/tr[" + row + "]/td[";
        if (colName.equalsIgnoreCase("Workflow Status"))
            return commonMethods.getBGColorInHex($(By.xpath(xpath + (getColumnsCount() - 2) + "]")).getCssValue("background-color"));
        else if (colName.equalsIgnoreCase("Overall Days Late"))
            return commonMethods.getBGColorInHex($(By.xpath(xpath + (getColumnsCount() - 1) + "]")).getCssValue("background-color"));
        else if (colName.equalsIgnoreCase("Notes"))
            return commonMethods.getBGColorInHex($(By.xpath(xpath + (getColumnsCount()) + "]")).getCssValue("background-color"));
        else
            return commonMethods.getBGColorInHex($(By.xpath(xpath + (getColIndex(colName)) + "]")).getCssValue("background-color"));
    }

    /**
     * Function to get WF overall status
     */
    public String getWFOverallStatus(int index, int row) {
        return $(By.xpath("//table[@class='dataTable']/tbody/tr[" + row + "]/td[" + index + "]")).getText();
    }

    /**
     * Function to get legend name
     */
    public boolean getLegendName(String legend) {
        return $(By.xpath("//table[@class='formTable']//td[text()='" + legend + "']")).isDisplayed();
    }

    /**
     * Function to get legend value
     */
    public boolean getLegendValue(String legend, String expValue) {
        return $(By.xpath("//table[@class='formTable']//td[text()='" + legend + "']/../td[text()='" + expValue + "']")).isDisplayed();
    }

    /**
     * Function to get legend color
     */
    public String getLegendColor(String legend) {
        By xpath = By.xpath("//table[@class='formTable']//td[text()='" + legend + "']/../td[1]");
        return commonMethods.getBGColorInHex(commonMethods.getBGColor(xpath));
    }

    /**
     * Function to get document row number
     */
    public int getDocRow(String docName) {
        List<WebElement> elements = new ArrayList<>($$(By.xpath(tblDocRows)));
        for (int i = 1; i <= elements.size(); i++)
            if ($(By.xpath(tblDocRows + "[" + i + "]/td[2]")).getText().trim().equalsIgnoreCase(docName)) return i;
        return 1;
    }

    /**
     * Function to get workflow row number
     */
    public int getWFRow(String wfNo) {
        List<WebElement> elements = new ArrayList<>($$(By.xpath(tblDocRows)));
        for (int i = 1; i <= elements.size(); i++)
            if ($(By.xpath(tblDocRows + "[" + i + "]/td[1]")).getText().trim().equalsIgnoreCase(wfNo)) return i;
        return 1;
    }

    /**
     * Function to click on Export to Excel button
     */
    public void clickExportToExcel() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, btnExportToExcel, 30);
        $(btnExportToExcel).click();
    }

    /**
     * Function to click on Export to Excel button
     */
    public void clickTemporaryFiles() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, btnTemporaryFiles, 30);
        $(btnTemporaryFiles).click();
    }

    /**
     * Function to verify export to excel page
     */
    public void verifyExportToExcel() {
        Assert.assertTrue($(hdrExportToExcel).isDisplayed());
        Assert.assertTrue($(txtSuccessMessage).isDisplayed());
        Assert.assertTrue($(txtEmailNotification).isDisplayed());
        Assert.assertTrue($(txtClickTempFiles).isDisplayed());
        Assert.assertTrue($(btnTemporaryFiles).isDisplayed());
        Assert.assertTrue($(btnBack).isDisplayed());
    }

    /**
     * Function to click on hyperlinks
     */
    public void clickOnLink(String mailNum) {
        $(By.xpath("//a[contains(text(),'" + mailNum + "')]")).click();
    }

}
