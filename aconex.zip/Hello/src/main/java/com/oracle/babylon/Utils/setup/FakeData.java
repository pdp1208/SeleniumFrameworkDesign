package com.oracle.babylon.Utils.setup;
import com.github.javafaker.Faker;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

/**
 * Class that creates a company and document data every time a object of the class is created
 */
public class FakeData {

    private Faker faker = new Faker();
    /**
     * Constructor call to set the company and the document data
     */
    public FakeData(){
        setCompanyName();
        setDocumentNumber();
    }

    //Initialization of the variables
    private String companyName;
    private String documentNumber;

    /**
     * Function to generate company data and set it
     */
    public void setDocumentNumber(){
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();
        Random random = new Random();
        String firstPart = faker.file().fileName().substring(0,8).replace("\\","");
        if(firstPart.endsWith("_")) firstPart = firstPart.substring(0, firstPart.length() - 1);
        this.documentNumber = firstPart + "_" + random.nextInt(1000) + dateFormat.format(date);
    }

    /**
     * Function to return the document number
     * @return
     */
    public String getDocumentNumber()
    {
        return documentNumber;
    }

    /**
     * Function to return the company name
     * @return
     */
    public String getCompanyName() {
        return companyName;
    }

    /**
     * Generate company name and set it
     */
    public void setCompanyName() {
        Faker faker = new Faker();
        this.companyName = faker.company().name();

    }
}
