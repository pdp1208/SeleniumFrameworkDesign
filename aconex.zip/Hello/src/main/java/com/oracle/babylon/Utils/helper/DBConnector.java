package com.oracle.babylon.Utils.helper;

import com.oracle.babylon.Utils.setup.utils.ConfigFileReader;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class DBConnector {
    public String dbConfigFilePath = "src/main/resources/database.properties";
    Properties properties = new Properties();
    ConfigFileReader configFileReader = new ConfigFileReader();
    Connection connection = null;
    ResultSet resultSet = null;

    /**
     * Load the data from the config file and make it accessible to the Properties variable
     */
    public DBConnector() {
        BufferedReader reader;
        try {
            reader = new BufferedReader(new FileReader(dbConfigFilePath));
            try {
                properties.load(reader);
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            throw new RuntimeException("email.properties not found at " + dbConfigFilePath);
        }
    }

    /**
     * Function to get column values for a given query
     */
    public List<String> getColumnValues(String query, String colName) {
        connectToDataBase();
        executeQuery(query);
        return getColValues(colName);
    }

    /**
     * Function to create connection to database
     */
    public void connectToDataBase() {
        try {
            String driverName = getDriverName();
            Class.forName(driverName).newInstance();
            String connectionUrl = getDBConnection();
            connection = DriverManager.getConnection(connectionUrl);
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Function to close DB connection
     */
    public void CloseDBConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                System.out.println("Closing Database Connection");
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    /**
     * Function to get results set from database for a given query
     */
    public void executeQuery(String query) {
        try {
            Statement stmt = connection.createStatement();
            resultSet = stmt.executeQuery(query);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Function to get column values from a given column in a table
     */
    public List<String> getColValues(String colName) {
        List<String> colValues = new ArrayList<>();
        try {
            while (resultSet.next())
                colValues.add(resultSet.getString(colName));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return colValues;
    }

    /**
     * Function to get database driver name
     */
    public String getDriverName() {
        String driverName = properties.getProperty("DB_DRIVER_NAME");
        if (driverName != null) return driverName;
        else throw new RuntimeException("DB Driver name is not specified in the configuration.properties file");
    }

    /**
     * Function to get Partner ID for SSO setup
     */
    public String getDBConnection() {
        return "jdbc:sqlserver://" + getDBServer() + ";"
                + "database=" + getDBName() + ";"
                + "user=" + getDBUserName() + ";"
                + "password=" + getDBPassword() + ";"
                + "encrypt=true;"
                + "trustServerCertificate=true;"
                + "loginTimeout=30;";
    }

    /**
     * Function to get DB server details based on instance
     */
    public String getDBServer() {
        if (configFileReader.getApplicationUrl().contains("mumbaiqa17"))
            return properties.getProperty("MUMBAIQA17_DB_SERVER");
        else if (configFileReader.getApplicationUrl().contains("mumbaiqa15")) return "";
        return null;
    }

    /**
     * Function to get DB server name based on instance
     */
    public String getDBName() {
        if (configFileReader.getApplicationUrl().contains("mumbaiqa17"))
            return properties.getProperty("MUMBAIQA17_DB_NAME");
        else if (configFileReader.getApplicationUrl().contains("mumbaiqa15")) return "";
        return null;
    }

    /**
     * Function to get DB server username based on instance
     */
    public String getDBUserName() {
        if (configFileReader.getApplicationUrl().contains("mumbaiqa17"))
            return properties.getProperty("MUMBAIQA17_DB_USERNAME");
        else if (configFileReader.getApplicationUrl().contains("mumbaiqa15")) return "";
        return null;
    }

    /**
     * Function to get DB server password based on instance
     */
    public String getDBPassword() {
        if (configFileReader.getApplicationUrl().contains("mumbaiqa17"))
            return properties.getProperty("MUMBAIQA17_DB_PASSWORD");
        else if (configFileReader.getApplicationUrl().contains("mumbaiqa15")) return "";
        return null;
    }

}
