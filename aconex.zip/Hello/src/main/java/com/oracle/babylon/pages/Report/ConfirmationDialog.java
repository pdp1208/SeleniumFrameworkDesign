package com.oracle.babylon.pages.Report;

import org.openqa.selenium.By;

import static com.codeborne.selenide.Condition.appear;
import static com.codeborne.selenide.Selenide.$;

/**
 * This is a page object class for confirmation box.
 *
 */
public class ConfirmationDialog {

    private static final String confirmationDialogSelecor = "//*[@id='standardConfirm']//*[@class='auiModal-content']";
    private By confirmButton = By.xpath(confirmationDialogSelecor + "//button[contains(@id,'Ok')]");
    private By cancelButton = By.xpath(confirmationDialogSelecor + "//button[contains(@id,'Cancel')]");
    private By confirmationDialog = By.xpath(confirmationDialogSelecor);

    /**
     * Method to wait for confirmation box to appear.
     *
     */
    public void waitForConfirmationDialogToOpen(){
        $(confirmationDialog).waitUntil(appear, 6000);
    }

    /**
     * Method to confirm the action.
     *
     */
    public void confirm(){
        $(confirmButton).click();
    }

    /**
     * Method to cancel the action.
     *
     */
    public void cancel(){
        $(cancelButton).click();
    }
}
