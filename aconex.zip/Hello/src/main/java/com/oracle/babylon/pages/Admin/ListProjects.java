package com.oracle.babylon.pages.Admin;


import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;


import static com.codeborne.selenide.Selenide.$;

public class ListProjects extends Navigator {

    Actions action = new Actions(driver);


    private By hiddenPrjChkbox = By.xpath("//input[@name='hidden']");
    private By visiblePrjChkBox = By.xpath("//input[@name='visible']");
    private By projectName = By.xpath("//input[@name='projectName']");
    private By searchBtn = By.xpath("//div[contains(text(),'Search')]");
    private By dots = By.xpath("//table[@id='resultTable']//div[@title='Click to show Actions']");
    private By editPrjDetails = By.xpath("//div[contains(text(),'Edit Project Details')]");
    private By projectParticipantsLink=By.xpath("//ul[@class='uiMenu']//div[contains(text(),'Project Participants')]");
    /**
     * Method to navigate and verify for the title of the page
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Setup", "List My Projects");
        Assert.assertTrue(verifyPageTitle("Project"));
    }

    /**
     * Method to select checkbox of hidden, visible and allOrgPrj checkbox
     */

    public void showAllChkBox() {
        $(hiddenPrjChkbox).setSelected(true);
        $(visiblePrjChkBox).setSelected(true);
        if($(allOrgPrjChkBox).isDisplayed()){
            $(allOrgPrjChkBox).setSelected(true);
        }
    }

    /**
     * Method to search for a project
     * @param project
     */

    public void searchProject(String project) {
        showAllChkBox();
        $(projectName).sendKeys(project);
        $(searchBtn).click();
    }

    /**
     * Method to click Edit project Details
     */

    public void clickEditProject()
    {
        action.moveToElement($(dots)).build().perform();
        $(dots).click();
        $(editPrjDetails).click();
    }
    /**
     * Method to navigate to project participants from the list projects
     */
    public void navigateToProjectParticipants(String project)
    {
        commonMethods.waitForElement(driver,projectName);
        $(By.xpath("//td[text()='"+project+"']//..//td[2]")).click();
        commonMethods.waitForElement(driver,projectParticipantsLink);
        $(projectParticipantsLink).click();
    }

}
