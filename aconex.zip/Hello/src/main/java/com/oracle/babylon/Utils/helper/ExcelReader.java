package com.oracle.babylon.Utils.helper;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class ExcelReader {

    private static Sheet sheet = null;
    private Workbook workbook = null;
    CommonMethods commonMethods = new CommonMethods();

    /**
     * Method to fetch a set of values from a particular column.
     *
     * @param file
     * @param rowId    Row to look out for the column header
     * @param columnId column header we are looking out for
     * @return
     */
    public List<String> fetchColumnValues(File file, String rowId, String columnId) {
        List<String> list = new ArrayList<>();
        excelHelper(file.getAbsolutePath(),0);
        Iterator<Row> rowIterator = sheet.iterator();
        int column_count = 0, req_col = -1;
        while (rowIterator.hasNext()) {
            //Iterating each row in the excel
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();
            while (cellIterator.hasNext()) {
                Cell cell = cellIterator.next();
                //Checking for the cell to be of string type
                if (cell.getCellType() == CellType.STRING) {
                    //Checking for the row in which we need to check the column
                    if (cell.getStringCellValue().equals(rowId)) {
                        column_count = 0;
                    }
                    //Checking for the column
                    if (cell.getStringCellValue().equals(columnId)) {
                        req_col = column_count;
                        break;
                    }
                    column_count++;
                    //Getting the column values by checking the column index with the cell index
                    if (req_col == cell.getColumnIndex()) {
                        list.add(cell.getStringCellValue());
                    }
                }
            }
        }
        System.out.println(list);
        return list;
    }

    /**
     * Method to return a row of values from an excel sheet
     *
     * @param file     file to be parsed
     * @param rowIndex row number of the row to be fetched
     * @return
     * @throws IOException
     */
    public Row returnRow(File file, int rowIndex) throws IOException {
        FileInputStream fis = new FileInputStream(file);
        HSSFWorkbook wb = new HSSFWorkbook(fis);
        HSSFSheet sheet = wb.getSheetAt(0);
        Row row = sheet.getRow(rowIndex);
        return row;
    }

    /**
     * Method to initiate workbook
     *
     * @param fileName
     * @param sheetIndex
     */
    public void excelHelper(String fileName, int sheetIndex) {
        try {
            FileInputStream file = new FileInputStream(fileName);
            if (fileName.endsWith(".xls")) workbook = new HSSFWorkbook(file);
            else if (fileName.endsWith(".xlsx")) workbook = new XSSFWorkbook(file);
            sheet = workbook.getSheetAt(sheetIndex);
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    /**
     * Method to write content to existing workbook
     *
     * @param filePath complete file path including name of the file
     * @param index
     * @param values   column values sent in list
     */
    public void writeToExcel(String filePath, int index, List<String> values) {
        try {
            excelHelper(filePath, index);
            Row row = sheet.createRow(sheet.getPhysicalNumberOfRows());
            for (int i = 0; i < values.size(); i++) row.createCell(i).setCellValue(values.get(i));
            FileOutputStream out = new FileOutputStream(filePath);
            workbook.write(out);
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Method to get all column values of a particular row from existing workbook
     *
     * @param filePath complete file path including name of the file
     * @param index
     * @param rowNum
     */
    public Map<String, String> getExcelData(String filePath, int index, int rowNum) {
        try {
            String colValue;
            Map<String, String> details = new HashMap<>();
            excelHelper(filePath, index);
            Row row = sheet.getRow(rowNum);
            int colNum = sheet.getRow(0).getPhysicalNumberOfCells();
            for (int i = 0; i < colNum; i++) {
                if (row.getCell(i) == null) colValue = "";
                else colValue = row.getCell(i).toString().trim();
                details.put(sheet.getRow(0).getCell(i).toString().trim(), colValue);
            }
            return details;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Method to create a excel file
     *
     * @param filePath complete file path including name of the file
     */
    public void createExcelFile(String filePath, String fileName) throws IOException {
        FileOutputStream fileOutputStream = null;
        try {
            fileOutputStream = new FileOutputStream(filePath + File.separator + fileName);
            if (fileName.split("\\.")[1].equalsIgnoreCase("xls"))
                workbook = new HSSFWorkbook();
            else workbook = new XSSFWorkbook();
            sheet = workbook.createSheet("sheet0");
            workbook.write(fileOutputStream);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            fileOutputStream.flush();
            fileOutputStream.close();
        }
    }

    /**
     * Method to delete rows in an excel file
     */
    public void deleteRows(String filePath) {
        try {
            excelHelper(filePath, 0);
            int rows = sheet.getPhysicalNumberOfRows();
            for (int i = rows - 1; i >= 1; i--) {
                Row row = sheet.getRow(i);
                row.setRowNum(i);
                sheet.removeRow(row);
            }
            FileOutputStream out = new FileOutputStream(filePath);
            workbook.write(out);
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Rows are not deleted");
        }
    }

    /**
     * Method to get all tab names present in an excel
     */
    public List<String> getExcelAllTabs(String fileName) {
        excelHelper(fileName, 0);
        return IntStream.range(0, workbook.getNumberOfSheets()).mapToObj(i -> workbook.getSheetName(i)).collect(Collectors.toList());
    }

    /**
     * Method to get first 2 column values of a particular row from existing workbook
     *
     * @param filePath  complete file path including name of the file
     * @param sheetName
     */
    public Map<String, String> getExcelData(String filePath, String sheetName, String rowHeader) {
        int numberOfRows;
        int rowIndex = 0;
        Map<String, String> details = new LinkedHashMap<>();
        try {
            excelHelper(filePath, getExcelAllTabs(filePath).indexOf(sheetName));
            numberOfRows = sheet.getLastRowNum();
            for (int index = 0; index < numberOfRows; index++) {
                if (rowHeader.equalsIgnoreCase(getCellData(index, 0))) {
                    rowIndex = index + 1;
                    break;
                }
            }
            for (int i = rowIndex; i <= numberOfRows; i++)
                if (getCellData(i, 0) == null) break;
                else
                    details.put(getCellData(i, 0), getCellData(i, 1));
            workbook.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return details;
    }

    /**
     * Method to get all column values of a particular row from existing workbook
     *
     * @param filePath  complete file path including name of the file
     * @param sheetName
     */
    public List<Map<String, String>> getAllCellValues(String filePath, String sheetName, String rowHeader) {
        int numberOfRows, numberOfColumns;
        int rowIndex = 0;
        int headersRow = 0;
        List<Map<String, String>> details = new LinkedList<>();
        try {
            excelHelper(filePath, getExcelAllTabs(filePath).indexOf(sheetName));
            numberOfRows = sheet.getLastRowNum();
            for (int index = 0; index < numberOfRows; index++) {
                if (rowHeader.equalsIgnoreCase(getCellData(index, 0))) {
                    headersRow = index + 1;
                    rowIndex = headersRow + 1;
                    break;
                }
            }
            numberOfColumns = sheet.getRow(rowIndex).getPhysicalNumberOfCells();
            for (int i = rowIndex; i <= numberOfRows; i++) {
                Map<String, String> colValues = new LinkedHashMap<>();
                if (getCellData(rowIndex, i) == null) break;
                else {
                    for (int j = 0; j < numberOfColumns; j++)
                        colValues.put(getCellData(headersRow, j), getCellData(i, j));
                }
                details.add(colValues);
            }
            workbook.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return details;
    }


    /**
     * Method to get all column values of a particular row from existing workbook
     *
     * @param filePath  complete file path including name of the file
     * @param sheetName
     */
    public Map<String, String> getExcelData(String filePath, String sheetName, String rowHeader, String value) {
        int numberOfRows, numberOfColumns;
        int rowIndex = 0;
        Map<String, String> details = new LinkedHashMap<>();
        try {
            excelHelper(filePath, getExcelAllTabs(filePath).indexOf(sheetName));
            numberOfRows = sheet.getLastRowNum();
            for (int index = 0; index < numberOfRows; index++) {
                if (rowHeader.equalsIgnoreCase(getCellData(index, 0))) {
                    rowIndex = index + 1;
                    break;
                }
            }
            numberOfColumns = sheet.getRow(rowIndex).getPhysicalNumberOfCells();
            for (int i = rowIndex + 1; i <= numberOfRows; i++)
                if (getCellData(i, 0).equalsIgnoreCase(value)) {
                    for (int j = 0; j < numberOfColumns; j++) details.put(getCellData(rowIndex, j), getCellData(i, j));
                    break;
                }
            workbook.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return details;
    }

    /**
     * Method to get all column values of a particular row from existing workbook
     *
     * @param filePath  complete file path including name of the file
     * @param sheetName
     */
    public Map<String, String> getExcelData(String filePath, String sheetName, String rowHeader, String header, String value) {
        int numberOfRows, numberOfColumns;
        int rowIndex = 0;
        Map<String, String> details = new LinkedHashMap<>();
        try {
            excelHelper(filePath, getExcelAllTabs(filePath).indexOf(sheetName));
            numberOfRows = sheet.getLastRowNum();
            for (int index = 0; index < numberOfRows; index++) {
                if (rowHeader.equalsIgnoreCase(getCellData(index, 0))) {
                    rowIndex = index + 1;
                    break;
                }
            }
            for (int index = rowIndex; index < numberOfRows; index++) {
                if (header.equalsIgnoreCase(getCellData(index, 0))) {
                    rowIndex = index + 1;
                    break;
                }
            }
            numberOfColumns = sheet.getRow(rowIndex).getLastCellNum();
            for (int i = rowIndex + 1; i <= numberOfRows; i++)
                if (getCellData(i, 0).equalsIgnoreCase(value)) {
                    for (int j = 0; j < numberOfColumns; j++) details.put(getCellData(rowIndex, j), getCellData(i, j));
                    break;
                }
            workbook.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return details;
    }

    /**
     * Method to get cell values
     */
    public String getCellData(int rowNumber, int colNumber) {
        try {
            Row row;
            Cell cellData;
            row = sheet.getRow(rowNumber);
            if (row != null) {
                cellData = row.getCell(colNumber);
                if (cellData != null) return cellData.toString().trim();
                else return "";
            }
        } catch (Exception exception) {
            return "";
        }
        return null;
    }

    /**
     * Method to get 2 column values of all row from existing workbook
     *
     * @param filePath  complete file path including name of the file
     * @param sheetName
     */
    public Map<String, String> getMultiColValues(String filePath, String sheetName, String rowHeader, String value) {
        int numberOfRows, numberOfColumns;
        int rowIndex = 0;
        int colIndex = 0;
        Map<String, String> details = new LinkedHashMap<>();
        try {
            excelHelper(filePath, getExcelAllTabs(filePath).indexOf(sheetName));
            numberOfRows = sheet.getLastRowNum();
            for (int index = 0; index < numberOfRows; index++) {
                if (rowHeader.equalsIgnoreCase(getCellData(index, 0))) {
                    rowIndex = index + 1;
                    break;
                }
            }
            numberOfColumns = sheet.getRow(rowIndex).getLastCellNum();
            for (int i = 0; i < numberOfColumns; i++) {
                if (getCellData(rowIndex, i).equals(value)) {
                    colIndex = i;
                    rowIndex = rowIndex + 2;
                }
            }
            for (int j = rowIndex; j < numberOfRows; j++)
                if (getCellData(j, colIndex) == null) break;
                else {
                    details.put(getCellData(j, colIndex), getCellData(j, colIndex + 1));
                }
            workbook.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return details;
    }

    /**
     * Method to get 1 column values of all row from existing workbook
     *
     * @param filePath  complete file path including name of the file
     * @param sheetName
     */
    public List<String> getSingleColValues(String filePath, String sheetName, String rowHeader, String value) {
        int numberOfRows, numberOfColumns;
        int rowIndex = 0;
        int colIndex = 0;
        List<String> details = new LinkedList<>();
        try {
            excelHelper(filePath, getExcelAllTabs(filePath).indexOf(sheetName));
            numberOfRows = sheet.getLastRowNum();
            for (int index = 0; index < numberOfRows; index++) {
                if (rowHeader.equalsIgnoreCase(getCellData(index, 0))) {
                    rowIndex = index + 1;
                    break;
                }
            }
            numberOfColumns = sheet.getRow(rowIndex).getLastCellNum();
            for (int i = 0; i < numberOfColumns; i++) {
                if (getCellData(rowIndex, i).equals(value)) {
                    colIndex = i;
                    rowIndex = rowIndex + 1;
                }
            }
            for (int j = rowIndex; j <= numberOfRows; j++)
                if (getCellData(j, colIndex).isEmpty()) break;
                else {
                    details.add(getCellData(j, colIndex));
                }
            workbook.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return details;
    }

    /**
     * Method to get 2 column values of a particular row from existing workbook
     *
     * @param filePath  complete file path including name of the file
     * @param rowHeader
     */
    public Map<String, String> getColValues(String filePath, String sheetName, String rowHeader, int col1, int col2) {
        int numberOfRows;
        int rowIndex = 0;
        Map<String, String> details = new LinkedHashMap<>();
        try {
            excelHelper(filePath, getExcelAllTabs(filePath).indexOf(sheetName));
            numberOfRows = sheet.getLastRowNum();
            for (int index = 0; index < numberOfRows; index++)
                if (rowHeader.equalsIgnoreCase(getCellData(index, 0))) {
                    rowIndex = index;
                    break;
                }
            for (int i = rowIndex; i <= numberOfRows; i++)
                if (((getCellData(i, 0).equalsIgnoreCase(rowHeader) || getCellData(i, 0).isEmpty())) && !getCellData(i, col1).isEmpty())
                    details.put(getCellData(i, col1), getCellData(i, col2));
            workbook.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return details;
    }

    /**
     * Method to get 1 column values of a particular row from existing workbook
     *
     * @param filePath  complete file path including name of the file
     * @param rowHeader
     */
    public List<String> getSingleColValues(String filePath, String sheetName, String rowHeader, int col) {
        int numberOfRows;
        int rowIndex = 0;
        List<String> details = new LinkedList<>();
        try {
            excelHelper(filePath, getExcelAllTabs(filePath).indexOf(sheetName));
            numberOfRows = sheet.getLastRowNum();
            for (int index = 0; index < numberOfRows; index++)
                if (rowHeader.equalsIgnoreCase(getCellData(index, 0))) {
                    rowIndex = index + 1;
                    break;
                }
            for (int i = rowIndex; i < numberOfRows; i++)
                if (getCellData(i, col) == null) break;
                else details.add(getCellData(i, col));
            workbook.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return details;
    }

    /**
     * Method to get 2 column values of a particular row from existing workbook
     *
     * @param filePath complete file path including name of the file
     */
    public Map<String, String> getColValues(String filePath, String sheetName, String type, String rule, String condition, int col1, int col2) {
        int numberOfRows;
        int rowIndex = 0;
        int counter = 0;
        int rowCounter;
        Map<String, String> details = new LinkedHashMap<>();
        try {
            excelHelper(filePath, getExcelAllTabs(filePath).indexOf(sheetName));
            numberOfRows = sheet.getLastRowNum();
            for (int index = 0; index < numberOfRows; index++)
                if (type.equalsIgnoreCase(getCellData(index, 0))) {
                    rowIndex = index + 1;
                    break;
                }
            for (int index = rowIndex; index < numberOfRows; index++)
                if (rule.equalsIgnoreCase(getCellData(index, 0))) {
                    rowIndex = index + 1;
                    break;
                }
            for (int i = rowIndex; i < numberOfRows; i++)
                if ((getCellData(i, 0).equalsIgnoreCase(condition))) {
                    rowIndex = i;
                    for (rowCounter = rowIndex + 1; rowCounter <= numberOfRows; rowCounter++) {
                        if (!getCellData(rowCounter, 0).isEmpty()) {
                            counter = rowCounter;
                            break;
                        }
                        if (rowCounter == numberOfRows) counter = rowCounter + 1;
                    }
                }
            for (int i = rowIndex; i < counter; i++)
                details.put(getCellData(i, col1), getCellData(i, col2));
            workbook.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return details;
    }

    /**
     * Method to get 2 column values of a particular row from existing workbook
     *
     * @param filePath complete file path including name of the file
     */
    public Map<String, String> getColValues(String filePath, String sheetName, String type, String condition, int col1, int col2) {
        int numberOfRows;
        int rowIndex = 0;
        Map<String, String> details = new LinkedHashMap<>();
        try {
            excelHelper(filePath, getExcelAllTabs(filePath).indexOf(sheetName));
            numberOfRows = sheet.getLastRowNum();
            for (int index = 0; index < numberOfRows; index++)
                if (type.equalsIgnoreCase(getCellData(index, 0))) {
                    rowIndex = index + 1;
                    break;
                }
            for (int i = rowIndex; i < numberOfRows; i++) {
                if ((getCellData(i, 0).equalsIgnoreCase(condition) || getCellData(i, 0).isEmpty())) {
                    details.put(getCellData(i, col1), getCellData(i, col2));
                    if (!getCellData(i + 1, 0).isEmpty()) break;
                }
            }
            workbook.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return details;
    }

    /**
     * Method to get 2 column values of a particular row from existing workbook
     *
     * @param filePath complete file path including name of the file
     */
    public Map<String, String> getColValues(String filePath, String sheetName, String type, String condition, int col1, int col2, int counter) {
        int numberOfRows;
        int rowIndex = 0;
        Map<String, String> details = new LinkedHashMap<>();
        try {
            excelHelper(filePath, getExcelAllTabs(filePath).indexOf(sheetName));
            numberOfRows = sheet.getLastRowNum();
            for (int index = 0; index < numberOfRows; index++)
                if (type.equalsIgnoreCase(getCellData(index, 0))) {
                    rowIndex = index + 1;
                    break;
                }
            for (int i = rowIndex; i < numberOfRows; i++) {
                if (getCellData(i, 0).equalsIgnoreCase(condition)) {
                    for (int j = 1; j <= counter; j++) {
                        details.put(getCellData(i, col1), getCellData(i, col2));
                        i++;
                    }
                    break;
                }
            }
            workbook.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return details;
    }

    /**
     * Method to get multi row values of a single columns for a particular condition from existing workbook
     *
     * @param filePath  complete file path including name of the file
     * @param sheetName
     */
    public List<String> getMultiRows(String filePath, String sheetName, String rowHeader, String value, int col) {
        int numberOfRows;
        int rowIndex = 0;
        List<String> details = new LinkedList<>();
        try {
            excelHelper(filePath, getExcelAllTabs(filePath).indexOf(sheetName));
            numberOfRows = sheet.getLastRowNum();
            for (int index = 0; index < numberOfRows; index++) {
                if (rowHeader.equalsIgnoreCase(getCellData(index, 0))) {
                    rowIndex = index + 1;
                    break;
                }
            }
            for (int i = rowIndex + 1; i < numberOfRows; i++)
                if ((getCellData(i, 0).equalsIgnoreCase(value) || getCellData(i, 0) == null) && getCellData(i, 1) != null) {
                    details.add(getCellData(i, col));
                }
            workbook.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return details;
    }

    /**
     * Method to get multi row values of a single columns for a particular condition from existing workbook
     *
     * @param filePath  complete file path including name of the file
     * @param sheetName
     */
    public List<String> getAllRows(String filePath, String sheetName, String rowHeader, String value) {
        int numberOfRows, numberOfColumns;
        int rowIndex = 0;
        List<String> details = new LinkedList<>();
        try {
            excelHelper(filePath, getExcelAllTabs(filePath).indexOf(sheetName));
            numberOfRows = sheet.getLastRowNum();
            for (int index = 0; index < numberOfRows; index++) {
                if (rowHeader.equalsIgnoreCase(getCellData(index, 0))) {
                    rowIndex = index + 1;
                    break;
                }
            }
            numberOfColumns = sheet.getRow(rowIndex).getPhysicalNumberOfCells();
            for (int i = rowIndex; i <= numberOfRows; i++) {
                if (getCellData(i, 0).equals(value)) {
                    for (int j = 0; j < numberOfColumns; j++)
                        details.add(getCellData(i, j));
                    break;
                }
            }
            workbook.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return details;
    }

    /**
     * Method to get all column values of a particular row from existing workbook if color is matched
     *
     * @param filePath  complete file path including name of the file
     * @param sheetName
     */
    public List<String> getColoredCellValue(String filePath, String sheetName, String rowHeader, String color) {
        int numberOfRows, numberOfColumns;
        int rowIndex = 0;
        List<String> details = new LinkedList<>();
        try {
            excelHelper(filePath, getExcelAllTabs(filePath).indexOf(sheetName));
            numberOfRows = sheet.getLastRowNum();
            for (int index = 0; index < numberOfRows; index++) {
                if (rowHeader.equalsIgnoreCase(getCellData(index, 0))) {
                    rowIndex = index + 1;
                    break;
                }
            }
            numberOfColumns = sheet.getRow(rowIndex).getPhysicalNumberOfCells();
            for (int i = 0; i < numberOfColumns; i++)
                if (getCellBGColor(rowIndex, i) == Integer.parseInt(color))
                    details.add(getCellData(rowIndex, i));
            workbook.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return details;
    }

    /**
     * Method to get cell background color
     */
    public int getCellBGColor(int rowNumber, int colNumber) {
        try {
            Row row;
            CellStyle cellBGColor;
            row = sheet.getRow(rowNumber);
            if (row != null) {
                cellBGColor = row.getCell(colNumber).getCellStyle();
                return cellBGColor.getFillBackgroundColor();
            }
        } catch (Exception exception) {
            return 0;
        }
        return 0;
    }

    /**
     * Method to get all column values of a particular row from existing workbook
     *
     * @param filePath  complete file path including name of the file
     * @param sheetName
     */
    public List<Map<String, String>> getAllCellValues(String filePath, String sheetName, int headerRow) {
        int numberOfRows, numberOfColumns;
        int rowIndex = headerRow + 1;
        int counter = 1;
        String header;
        List<Map<String, String>> details = new LinkedList<>();
        try {
            excelHelper(filePath, getExcelAllTabs(filePath).indexOf(sheetName));
            numberOfRows = sheet.getLastRowNum();
            numberOfColumns = sheet.getRow(rowIndex).getPhysicalNumberOfCells();
            for (int i = rowIndex; i <= numberOfRows; i++) {
                Map<String, String> colValues = new LinkedHashMap<>();
                if (getCellData(i, 0).equalsIgnoreCase("")) break;
                else {
                    for (int j = 0; j < numberOfColumns; j++) {
                        if (getCellData(headerRow, j).equalsIgnoreCase(""))
                            header = getCellData(headerRow - 1, j);
                        else header = getCellData(headerRow, j);
                        if(colValues.containsKey(header)) {
                            header = header + counter;
                            counter++;
                        }
                        colValues.put(header, getCellData(i, j));
                    }
                }
                details.add(colValues);
                counter = 1;
            }
            workbook.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return details;
    }

}
