package com.oracle.babylon.pages.Setup;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.oracle.babylon.Utils.helper.Navigator;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.*;

/**
 * Function that contains the methods related to core user/role page
 * Author : kukumavi
 */

public class AssignUserRolePage extends Navigator {

    protected By givenName = By.xpath("//input[@id='display.givenName']");
    protected By familyName = By.xpath("//input[@id='display.familyName']");
    protected By search = By.xpath("//div[contains(text(),'Search')]");
    protected By projectTab = By.xpath("//li[@id='ORG_AND_PROJECT_list']");
    protected By disabledAccount = By.cssSelector("#display.showDisabled");
    protected By next = By.linkText("next");
    protected By previous = By.linkText("previous");
    protected By createRoleBtn = By.xpath("//div[contains(text(),'Create Role')]");
    protected By configureUserRoleSettingsBtn = By.xpath("//div[contains(text(),'User Role Configuration')]");
    protected By saveBtn = By.xpath("//div[contains(text(),'Save')]");
    protected By resultTable = By.xpath("//table[@id='resultTable']");
    protected By disabledUser = By.xpath("//input[@id='display.showDisabled']");
    protected By organizationTab = By.xpath("//li[@id='ORG_WIDE_list']");
    private By availableAssetsBtn = By.xpath("//button[@id='btnViewAccessibleAssets']");
    private By userRoleAssignmentBtn=By.xpath("//div[@class='uiButton-content']//*[text()='User Role Assignment']");
    private By lblNewRole = By.xpath("//h1[contains(text(),'New Role')]");
    private By txtboxRoleName = By.xpath("//input[@name='RoleName']");
    private By chkboxDefaultRole = By.xpath("//input[@name='DefaultRole']");

    public void navigateAndVerifyPage() {
        getMenuSubmenu("Setup", "User Role Assignment");
        verifyPageTitle("Role Assignment");
    }
 //Repeated method
    public void selectProjectTab(){
        switchTo().defaultContent();
        switchTo().frame("frameMain");
        $(projectTab).click();
    }

    public void searchUser(String user) {
        String[] currencies = user.split(" ");
        switchTo().defaultContent();
        switchTo().frame("frameMain");
        $(givenName).sendKeys(currencies[0]);
        $(familyName).sendKeys(currencies[currencies.length - 1]);
        $(search).click();
    }

    public void showDisabledAccount() {
        //Keep the coding style same for all conditional statements
        if (!$(disabledAccount).isSelected())
            $(disabledAccount).click();
    }
    public void verifyCreateRole() {
        $(createRoleBtn).shouldBe(Condition.visible);
    }

    public void verifyConfigureUserRoleSettings() {
        $(configureUserRoleSettingsBtn).shouldBe(Condition.visible);
    }

    public void saveBtn() {
        $(saveBtn).shouldBe(Condition.visible);
        //Name the method according to the action
    }

    /**
     * Method to click on the Available assets button
     */
    public void clickAvailableAssets(){
        $(availableAssetsBtn).click();
    }

    /**
     * Method to click on the Configure user role settings button
     */
    public void clickConfigureUserRoleSettingsBtn(){
        $(configureUserRoleSettingsBtn).click();
    }

    public void assignRoleToUser(String role, String fullName, boolean assign){
        int index = -1;
        searchUser(fullName);
        ElementsCollection headers = $$(By.xpath("//tr[@class='dataHeaders']/th"));
        for(int i=0; i<headers.size(); i++) {
            if (headers.get(i).getText().contains(role)) {
                index = i;
                break;
            }
        }
        index++;
        if(assign && $(resultTable).find(By.xpath("//tr[@class='dataRow']//td[" + index + "]/input")).getValue().equals("0")) {
            $(resultTable).find(By.xpath("//tr[@class='dataRow']//td[" + index + "]/input[@type='checkbox']")).click();
        } else if(!assign && $(resultTable).find(By.xpath("//tr[@class='dataRow']//td[" + index + "]/input")).getValue().equals("1")){
            $(resultTable).find(By.xpath("//tr[@class='dataRow']//td[" + index + "]/input[@type='checkbox']")).click();
        }
        $(saveBtn).click();
    }
    public void clickUserRoleAssignment()
    {
        commonMethods.waitForElement(driver,userRoleAssignmentBtn);
        $(userRoleAssignmentBtn).click();
    }

    public void verifyUserListDisplayed()
    {
        $(dataRows).shouldBe(Condition.appear);
    }

    public void verifySaveBtn()
    {$(saveTxtButton).shouldBe(Condition.appear);}

    /**
     * Method to create a new user role
     * @param roleName
     */
    public void createRole(String roleName) {
        commonMethods.waitForElement(driver, createRoleBtn);
        $(createRoleBtn).click();
        commonMethods.waitForElement(driver, lblNewRole);
        commonMethods.enterTextValue(txtboxRoleName, roleName);
        commonMethods.clickOnElement(chkboxDefaultRole);
        commonMethods.clickOnElement(saveBtn);
    }

    /**
     * Method to verify role
     */
    public boolean verifyRole(String roleName) {
        commonMethods.waitForElement(driver, createRoleBtn);
        return $(By.xpath("//a[text()='" + roleName + "']")).isDisplayed();
    }
}
