package com.oracle.babylon.pages.Mail;

import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Selenide.*;

public class ViewMail extends Navigator {

    private By mailNumber = By.xpath("//div[@data-automation-id='mailHeader-number-value']");
    private By mailType = By.xpath("//div[@data-automation-id='mailHeader-type-value']//span");
    private By edit = By.xpath("//button[contains(text(),'Edit')]");
    private By pageTitle = By.xpath("//h1[contains(.,'View Mail')]");
    private By sendBtn = By.xpath("//button[@class='auiButton primary ng-binding ng-scope']");
    private By loadingIcon = By.cssSelector(".loading_progress");
    private By mailNo = By.xpath("//div[@class='mailHeader-numbers']//div[2]//div[2]");
    private By referenceMailNo = By.xpath("//div[@class='mailHeader-numbers']//div[3]//div[2]");
    private By errorMsg = By.xpath("//div[@id='messagePanel']");
    private By valueRegisterResponse = By.xpath("//a[contains(text(),'Register an incoming reply')]");
    private By awaitingForApprovalMsg = By.xpath("//div[@class='auiMessage-content']");
    private By textRegisterMail = By.xpath("//h1[@id='editMailHeading']");
    private By startWorkflowBtn = By.xpath("//button[contains(text(),'Start a Workflow')]");
    private By mailStatusOnViewMail = By.xpath("//div[@class='mailHeader']/div[@class='auiDetails']/div[contains(.,'Status')]");
    private By errorTextDocuments = By.xpath("//span[@id='excludedDocs_title']");
    private By closeBtn = By.xpath("//button[@id='btnexcludedDocs_ok']");
    private By textWorkflowWizard = By.xpath("//div[@id='toolbar_left']");
    private By printBtn = By.xpath("//button[contains(text(),'Print')]");
    private By screenStyleBtn = By.xpath("//div[@class='auiMenuButton-dropdown ng-scope']//a[contains(text(),'Screen Style')]");
    private By letterStyleBtn = By.xpath("//div[@class='auiMenuButton-dropdown ng-scope']//a[contains(text(),'Letter Style')]");
    private By documentDetail = By.xpath("//mail-document-properties-grid[@class='ng-isolate-scope']//tbody//tr[1]");
    private By actionMailBodyBtn = By.xpath("//descendant::button[contains(text(),'Actions')][2]");
    private By actionOnTopBtn = By.xpath("//button[contains(text(),'Actions')]");
    private By mailSubject = By.xpath("//div[@class='mailHeader-subject']");
    private By recipient = By.xpath("//li[@class='mailRecipients-firstRecipient']");
    private By backBtn = By.xpath("//button[@title='Back']");
    private By markAsUnread = By.xpath("//a[@class='ng-binding ng-scope']");
    private By markedAsUnreadMsg = By.xpath("//div[contains(text(),'Marked as unread')]");
    private By updateRegisterBtn = By.xpath("//button[contains(text(),'Update Register')]");
    private By viewFilePropertyBtn = By.xpath("//button[contains(text(),'View File Properties')]");
    private By alreadyUpdatedTxt = By.xpath("//span[text()='Already updated']");
    private By unableToUpdateTxt = By.xpath("//span[text()='Unable to update register']");
    private By updateRegistercloseBtn = By.xpath("//button[@id='cancel']");
    private By mailBody = By.xpath("//div[@class='mailBody']");
    private By mailDocumentTransamittal = By.xpath("//mail-attached-documents[@class='ng-isolate-scope']//div[@class='auiCollapsibleSection']");
    private By mailDocument = By.xpath("//table[@class='auiTable ng-scope']");
    private By typeEmail = By.xpath("//div[@class='mailHeader-value']");
    private By openDocument = By.xpath("//table[@class='auiTable']//tbody//tr[1]/td[1]/input");
    private By startWorkFlowBtn = By.xpath("//button[contains(text(),'Start a Workflow')]");
    private By printRequest = By.xpath("//a[contains(text(),'Submit a Print Request')]");
    private By latestVersionDocument = By.xpath("//a[contains(text(),'View Documents in Register - Latest Versions')]");
    private By transmittedVersionDocument = By.xpath("//a[contains(text(),'View Documents in Register - Transmitted Versions')]");
    private By registerUpdateMessage = By.xpath("//div[@class='auiModal-content']");
    private By fileProperty = By.xpath("//button[contains(text(),'View File Properties')]");
    private By closeOutStatus = By.xpath("//div[@class='auiDetails']//span[contains(text(),'Closed-Out')]");
    private By mailAttachments = By.xpath("//div[@class='mailAttachedMails ng-scope']//table//tbody//tr//td[3]");
    private By forwardBtn = By.xpath("//button[contains(text(),'Forward')]");
    private By markAsCloseOutBtn = By.xpath("//button[text()='Mark as Closed-Out']");
    private By markThreadAsCloseOutBtn = By.xpath("//button[contains(text(),'Mark thread as Closed-Out')]");
    private By replyBtn = By.xpath("//button[contains(text(),'Reply')]");
    private By replyAllBtn = By.xpath("//button[text()='Reply to All']");
    private By filePropBtn = By.xpath("//button[contains(text(),'View File Properties')]");
    private By confidential = By.xpath("//div[@class='mailConfidential-banner']");
    private By confidentialTxt = By.xpath("//span[contains(text(),'Confidential')]");
    private By userRegistered = By.xpath("//span[contains(text(),'Mail manually registered')]");
    private By markAsClosedOutBtn = By.xpath("//button[contains(text(),'Mark as Closed-Out')]");
    private By markMailThreadClosedOutPopUp = By.xpath("//button[contains(text(),'Mark thread as Closed-Out')]");
    private By fileAttachments = By.xpath("//span[contains(.,' Attachments')]");
    private By mailStatus = By.xpath("//div[text()='Status']//..//span//span");
    private By parentMail = By.xpath("//div[contains(@class,'mailThreadSlat auiReset-font ng-isolate')]");
    private By threadMail=By.xpath("//div[contains(@class,'mailThreadSlat auiReset-font ng-scope ng-isolate-scope')]");
    private By threadMailNum = By.xpath("//div[@class='mailThreadSlat auiReset-font ng-scope ng-isolate-scope']//div [2]//div[3]");
    private By parentUserNameOnThread = By.xpath("//div[contains(@class,'mailThreadSlat auiReset-font ng-isolate')]//div[contains(@class,'mailThreadSlat-fromUser ng-binding')]");
    private By replyUserNameOnThread = By.xpath("//div[contains(@class,'mailThreadSlat auiReset-font ng-scope ng-isolate')]//div[contains(@class,'mailThreadSlat-fromUser ng-binding')]");
    private By replyUserNameOnThread_AppHub = By.xpath("//div[contains(@class,'mailThreadSlat auiReset-font ng-scope ng-isolate-scope unread')]//div[contains(@class,'mailThreadSlat-fromUser ng-binding')]");
    private By mailSenderFrom = By.xpath("//div[@class='auiDetails-value']//*[@user='mail.sender']");
    private By mailReceiverTo = By.xpath("//div[@class='auiDetails-value']//*[@user='recipient.user']");
    private By numberOfThreadMails = By.xpath("//div[contains(@class,'mailThreadSlat auiReset-font ng-')]");
    private By messageCollapseLink = By.xpath("//*[@class='viewMail-collapsibleSectionHeader ng-scope']//span[contains(text(),'Message')]");
    private By messageBody = By.xpath("//div[@class='mailBody']");
    private By statusOnViewMail = By.xpath("//div[@class='auiDetails-row noprint_letterMode']");
    private By docWarningMsg = By.xpath("//div[@class='modal-dialog-content']//p");
    private By downloadCloseBtn = By.xpath("//button[text()='Close']");
    private By documentActions = By.xpath("//div[@class='auiCollapsibleSection-body']//button[contains(text(),'Actions')]");
    MailPage mailpage = new MailPage();
    private By fileDetailPanel = By.xpath("//div[@class='auiModal-body documentProperties-modalBody ng-scope']");
    private By mailNote = By.xpath("//div[@class='auiCollapsibleSection collapsed']//div//a[@class='auiCollapsibleSection-header']//span[contains(text(),'Notes')]");
    private By downloadBtn = By.xpath("//button[contains(text(),'Download')]");
    private By zipDownloadLink = By.xpath("//div[@class='auiMenuButton-dropdown ng-scope']//a[1][contains(.,'Zip Download')]");
    private By zipDownloadMarkup = By.xpath("//div[@class='auiMenuButton-dropdown ng-scope']//a[contains(.,'Zip Download with Markups')]");
    private By toRecipientUser = By.xpath("//div[@class='mailHeader']/div[@class='auiDetails']/div[contains(.,'To')]");
    private By ccRecipientUser = By.xpath("//div[@class='mailHeader']/div[@class='auiDetails']/div[contains(.,'Cc')]");
    private By bccRecipientUser = By.xpath("//div[@class='mailHeader']/div[@class='auiDetails']/div[contains(.,'Bcc')]");
    private By mailStatusForm = By.xpath("//div[@class='mailHeader']/div[@class='auiDetails']/div[contains(.,'Status')]");
    private By draftStatusOnThread = By.xpath("//*[@class='mailThreadSlat-badge mailThreadSlat-hasPopover mailThreadSlat-badge-status mailThreadSlat-badge-status-border-none']//*[@class='ng-binding oj-badge oj-badge-subtle']");
    private By deleteDraftBtn = By.xpath("//button[contains(text(),'Delete Draft')]");
    private By deleteConfirmBtn = By.xpath("//button[@data-automation-id='mailNavBar-btnDeleteDraftConfirm']");
    private By oneDoc = By.xpath("//span[contains(text(),'(1)')]");
    private By actionsBtn = By.xpath("//div[@class='auiCollapsibleSection-body']//button[contains(text(),'Actions')]");
    private By docLatestVersion = By.xpath("//a[contains(text(),'View Documents in Register - Latest Versions')]");
    private By createForward = By.xpath("//button[@title='Create a Forwarding mail without attaching the unregistered documents']");
    private By showMoreAttachments = By.xpath("//div[@class='mailAttachedDocuments-showAll ng-scope']");
    private By attachmentSize = By.xpath("//table[@class='auiTable']//tbody//tr");
    private By newWindowElement = By.xpath("//div[@class='viewMail-container viewMail-container-framed']");
    private By actionsOnAttachment = By.xpath("//*[@class='viewMail-section noprint_letterMode']//button[contains(text(),'Actions')]");
    private By actionSubmittedDocument = By.xpath("//a[contains(text(),'Action Submitted Documents')]");
    private By attachmentFileName = By.xpath("//div[@id='fldAttachments']//table[@class='dataTable']//tbody//tr//td[3]");
    private By lblPendingApproval = By.xpath("//div[contains(text(),'Approval in progress - this mail has not been sent')]");
    private By fileAttachList = By.xpath("//table[@class='auiTable ng-scope']//a");
    private By fileList = By.xpath("//table[@class='auiTable']//tbody//tr/td[3]//div/div");
    private By lnkMailAttachments = By.xpath("//table//td[@class='mailAttachedFiles-filename']//a");
    private By selectAllChkBox = By.xpath("//*[@attached-mail-parent-id='attachedMailParentId']//table//th/input");
    private By btnZipDownload = By.xpath("//*[@attached-mail-parent-id='attachedMailParentId']//button[contains(text(),'Zip Download')]");
    private By zdwmSuccessMessage = By.xpath("//p[text()='Your Zip Download with Markups job has commenced and will run in the background.']");
    private By showHideThead = By.xpath("//div[@title='Show / Hide Thread']");
    private By attachmentView = By.xpath("//table[@class='auiTable']//th[@class='tight auiText-left']/following::th");


    /**
     * Method to verify page title
     */
    public void verifyPageTitle() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, pageTitle, 90);
        $(pageTitle).exists();
    }

    /**
     * Method to get mail number
     *
     * @return mail number
     */
    public String retrieveMailNumber() {
        verifyAndSwitchFrame();
        String mailNumberText = $(mailNumber).getText();
        driver.switchTo().defaultContent();
        return mailNumberText;
    }

    /**
     * Method to get mail type
     *
     * @return mail type
     */
    public String retrieveMailType() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, mailType, 40);
        String mailTypeText = $(mailType).getText();
        driver.switchTo().defaultContent();
        return mailTypeText;
    }

    /**
     * Method to click edit button
     */
    public void editMail() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, edit, 10);
        $(edit).click();
    }

    /**
     * Method to click send button on view mail page
     * and set mail number in mailpage.mailNumber
     */
    public String sendMail() {
        commonMethods.waitForElement(driver, sendBtn);
        $(sendBtn).click();
        $(loadingIcon).should(disappear);
        commonMethods.waitForElementExplicitly(4000);
        return mailpage.mailNumber = $(mailNo).getText();

    }

    /**
     * Function to click send button
     */

    public void clickOnSend() {
        commonMethods.waitForElement(driver, sendBtn, 15);
        $(sendBtn).click();
    }

    /**
     * Function to verify the Error message Panel is displayed
     */
    public Boolean verifyErrorMsg() {
        commonMethods.waitForElement(driver, sendBtn, 10);
        $(sendBtn).click();
        commonMethods.waitForElement(driver, errorMsg, 10);
        return $(errorMsg).isDisplayed();
    }


    /**
     * Function to verify mail details
     *
     * @param mailAttribute to be verified
     */
    public void viewMailDetails(String mailAttribute) {
//        commonMethods.switchToFrame(driver, "frameMain");
        Map<String, String> table = dataStore.getTable(mailAttribute);
        //According to the keys passed in the table, we select the fields
        verifyAndSwitchFrame();
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
        for (String tableData : table.keySet()) {
            switch (tableData) {
                case "To":
                    String[] namesListForTo = table.get(tableData).split(",");
                    for (String name : namesListForTo) {
                        String toUser = $(toRecipientUser).text();
                        userMap = jsonMapOfMap.get(name);
                        Assert.assertTrue(toUser.contains(userMap.get("full_name").toString()));
                    }
                    break;
                case "Cc":
                    String[] namesListForcc = table.get(tableData).split(",");
                    for (String name : namesListForcc) {
                        String cctoUser = $(ccRecipientUser).text();
                        userMap = jsonMapOfMap.get(name);
                        Assert.assertTrue(cctoUser.contains(userMap.get("full_name").toString()));
                    }
                    break;
                case "Bcc":
                    String[] namesListForBcc = table.get(tableData).split(",");
                    for (String name : namesListForBcc) {
                        String bccUser = $(bccRecipientUser).text();
                        userMap = jsonMapOfMap.get(name);
                        Assert.assertTrue(bccUser.contains(userMap.get("full_name").toString()));
                    }
                    break;
                case "Status":
                    Assert.assertTrue($(mailStatusForm).text().contains(table.get(tableData)));
                    break;
                case "Subject":
                    String subject = $(mailSubject).text();
                    Assert.assertTrue(subject.contains(table.get(tableData)));
                    break;
                case "Mail Type":
                    commonMethods.waitForElement(driver, typeEmail, 10);
                    String mailType = $(typeEmail).text();
                    Assert.assertTrue(mailType.contains(table.get(tableData)));
                    break;
                case "Attachment":
                    String attachment;
                    if (table.get("Mail Type").equals("Transmittal")) {
                        attachment = $(mailDocumentTransamittal).text();
                    } else {
                        attachment = $(mailDocument).text();
                    }
                    Assert.assertTrue(attachment.contains(table.get(tableData)));
                    break;
                case "File Type":
                    String attachmentType = $(mailDocument).text();
                    Assert.assertTrue(attachmentType.contains(table.get(tableData)));
                    break;
            }
        }
        driver.switchTo().defaultContent();
    }


    /**
     * Function to verify there is no error
     */
    public void verifyNoError() {
        try {
            String alertText = driver.switchTo().alert().getText();
            driver.switchTo().alert().accept();
        } catch (Exception e) {
            System.out.println("No Error Message" + e.getMessage());
        }
    }

    /**
     * Function to verify presence of button on view mail page
     */
    public void verifyButton(String button) {
        switch (button.toLowerCase()) {
            case "print":
                commonMethods.waitForElementExplicitly(2000);
                Assert.assertFalse($(printBtn).exists());
        }
    }

    /**
     * Function to verify attached document
     *
     * @param document name
     */
    public void verifyDocumentDetails(String document) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, openDocument, 20);
        getElementInView(openDocument);
        commonMethods.waitForElementExplicitly(5000);
        $(openDocument).setSelected(true);
        $(filePropBtn).click();
        commonMethods.waitForElement(driver, documentDetail);
        String docDetail = $(documentDetail).text();
        Assert.assertTrue(docDetail.contains(document));
    }

    /**
     * Function to click on update document register
     *
     * @param document
     */
    public Boolean updateDocumentRegister(String document) {
        commonMethods.waitForElementExplicitly(2000);
        verifyAndSwitchFrame();
        getElementInView(openDocument);
        commonMethods.waitForElement(driver, openDocument, 30);
        $(openDocument).click();
        commonMethods.waitForElement(driver, updateRegisterBtn, 20);
        $(updateRegisterBtn).click();
        if ($(alreadyUpdatedTxt).isDisplayed()) {
            System.out.println("Document already updated");
            return false;
        }
        commonMethods.waitForElement(driver, updateRegistercloseBtn, 30);
        $(updateRegistercloseBtn).click();
        return true;
    }

    /**
     * Function to click on Actions button and view latest version in document Register
     */
    public void clickLatestVersion() {
        commonMethods.waitForElementExplicitly(2000);
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, openDocument, 60);
        getElementInView(openDocument);
        commonMethods.waitForElement(driver, openDocument, 30);
        $(openDocument).click();
        commonMethods.waitForElement(driver, actionsBtn, 20);
        $(actionsBtn).click();
        $(docLatestVersion).click();

    }

    /**
     * Function to mark mail as unread
     */

    public void markAsUnread() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, actionOnTopBtn, 20);
        $(actionOnTopBtn).click();
        $(markAsUnread).click();
    }

    /**
     * Function to verify text Awaiting for Approval
     *
     * @return
     */
    public Boolean verifyAwaitingForApproval() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(5000);
        return $(awaitingForApprovalMsg).isDisplayed();
    }

    /**
     * Function to verify Register incoming mail text is displayed
     *
     * @return
     */
    public Boolean verifyRegisterResponsePage() {
        selectRegisterMail();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, textRegisterMail);
        return $(textRegisterMail).isDisplayed();
    }

    /**
     * Function to verify error for workflow wizard
     *
     * @return
     */
    public Boolean verifyErrorMsgForWorkflows() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, openDocument, 20);
        $(openDocument).click();
        $(startWorkflowBtn).click();
        commonMethods.waitForElement(driver, errorTextDocuments, 20);
        Boolean present = $(errorTextDocuments).isDisplayed();
        $(closeBtn).click();
        return present;
    }

    /**
     * Function to verify start workflow page wizard
     */
    public Boolean verifyStartWorkflowWizard() {
        initiateWorkflow();
        commonMethods.waitForElement(driver, textWorkflowWizard, 20);
        return $(textWorkflowWizard).isDisplayed();

    }

    /**
     * Function to initiate workflow from view mail
     */
    public void initiateWorkflow() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        getElementInView(openDocument);
        commonMethods.waitForElement(driver, openDocument, 20);
        $(openDocument).setSelected(true);
        commonMethods.waitForElement(driver, startWorkflowBtn, 20);
        $(startWorkflowBtn).click();
    }


    /**
     * Function to click on close out mail option
     */
    public void clickOnCloseOut() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, markAsCloseOutBtn, 20);
        $(markAsCloseOutBtn).click();
        $(markThreadAsCloseOutBtn).click();
        commonMethods.waitForElementExplicitly(3000);
    }

    /**
     * Function to click back button
     */
    public void clickOnBackButton() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, backBtn, 30);
        $(backBtn).click();
        driver.switchTo().defaultContent();
    }

    /**
     * Function to submit print request for document
     *
     * @param document name
     */
    public void submitPrintRequest(String document) {
        action(document);
        commonMethods.waitForElement(driver, printRequest);
        $(printRequest).click();
    }

    /**
     * Function to view latest version of document
     *
     * @param document name
     */
    public void viewLatestVersion(String document) {
        action(document);
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, latestVersionDocument);
        $(latestVersionDocument).click();
    }

    /**
     * Function to view transmitted version of document
     *
     * @param document name
     */
    public void viewTransmittedVersion(String document) {
        action(document);
        commonMethods.waitForElement(driver, transmittedVersionDocument);
        $(transmittedVersionDocument).click();

    }

    /**
     * Function to get action option for document
     *
     * @param document name
     */
    public void action(String document) {
        $(loadingIcon).should(disappear);
        commonMethods.waitForElementExplicitly(5000);
        verifyAndSwitchFrame();
        getElementInView((openDocument));
        commonMethods.waitForElement(driver, By.xpath("//mail-attached-documents[@class='ng-isolate-scope']//div[@class='auiCollapsibleSection-body']//tr[td//text()[contains(., '" + document + "')]]//td[1]//input"), 10);
        $(By.xpath("//mail-attached-documents[@class='ng-isolate-scope']//div[@class='auiCollapsibleSection-body']//tr[td//text()[contains(., '" + document + "')]]//td[1]//input")).click();
        sleep(2000);
        commonMethods.waitForElement(driver, actionMailBodyBtn, 16);
        $(actionMailBodyBtn).click();
    }

    /**
     * Function to update register with documents
     *
     * @param document
     */
    public void updateRegisterWithDocument(String document) {
        commonMethods.waitForElementExplicitly(2000);
        $(loadingIcon).should(disappear);
        verifyAndSwitchFrame();
        String[] docs = document.split(",");
        for (String doc : docs) {
            $(By.xpath("//mail-attached-documents[@class='ng-isolate-scope']//div[@class='auiCollapsibleSection-body']//tr[td//text()[contains(., '" + commonMethods.returnDocNumberInJson(doc) + "')]]//td[1]//input")).click();
        }
        commonMethods.waitForElement(driver, updateRegisterBtn);
        $(updateRegisterBtn).click();
    }

    public void viewFileProperties(String document) {
        commonMethods.waitForElementExplicitly(2000);
        $(loadingIcon).should(disappear);
        verifyAndSwitchFrame();
        String[] docs = document.split(",");
        for (String doc : docs) {
            $(By.xpath("//mail-attached-documents[@class='ng-isolate-scope']//div[@class='auiCollapsibleSection-body']//tr[td//text()[contains(., '" + commonMethods.returnDocNumberInJson(doc) + "')]]//td[1]//input")).click();
        }
        commonMethods.waitForElement(driver, viewFilePropertyBtn);
        $(viewFilePropertyBtn).click();
    }

    /**
     * Function to get update message
     *
     * @return message text
     */
    public String updateMessage() {
        commonMethods.waitForElementExplicitly(1000);
        return $(registerUpdateMessage).text();
    }

    /**
     * Function to get document details
     *
     * @return panel text
     */
    public String getFullDetailText() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, fileDetailPanel, 20);
        return $(fileDetailPanel).text();
    }

    /**
     * Function to get status of closeout
     *
     * @return status
     */
    public String verifyClosedOutStatus() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(4000);
        return $(closeOutStatus).text();
    }

    /**
     * Function to click on Forward
     */
    public void clickForward() {
        verifyAndSwitchFrame();
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.or(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Forward')]"))));
        $(forwardBtn).click();
    }

    /**
     * Function to click on create Forward
     */

    public void createForward() {
        $(createForward).click();
    }

    /**
     * Function to click on Reply
     */
    public void clickReply() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, replyBtn, 30);
        $(replyBtn).click();
    }

    /**
     * Click on reply All
     */
    public void clickReplyAll() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, replyAllBtn, 10);
        $(replyAllBtn).click();
    }

    /**
     * Function verify attached mail
     *
     * @return mail text
     */
    public String verifyAttachedMail() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(5000);
        commonMethods.waitForElement(driver, mailAttachments, 30);
        return $(mailAttachments).text();
    }

    /**
     * Function to open attached mail
     *
     * @param attachedMailNumber
     */
    public void openAttachedMail(String attachedMailNumber) {
        verifyAndSwitchFrame();
        $(By.xpath("//tbody//tr[td//text()[contains(., '" + attachedMailNumber + "')]]//td[2]//img")).click();
    }


    /**
     * Function to verify attached document in a mail
     *
     * @param document name
     */
    public void verifyAttachmentAttachedMail(String document) {
        verifyAndSwitchFrame();
        String defaultWindow = driver.getWindowHandle();
        for (String newWindow : driver.getWindowHandles()) {
            driver.switchTo().window(newWindow);
        }
        commonMethods.waitForElementExplicitly(4000);
        List<WebElement> list = driver.findElements(newWindowElement);
        Assert.assertTrue(list.size() == 1);

        driver.switchTo().window(defaultWindow);
    }

    /**
     * Function to verify Mark As Closed Out Button is Present or not
     */

    public boolean verifyMarkAsClosedOutButtonDisplayed() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(3000);
        if ($(markAsClosedOutBtn).isDisplayed()) {
            return true;
        }
        return false;
    }

    /**
     * Function to click on Mark As Closed Out Button
     */
    public void clickOnMarkAsClosedOutButton() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, markAsClosedOutBtn, 30);
        $(markAsClosedOutBtn).click();
        $(markMailThreadClosedOutPopUp).click();
    }

    /**
     * Function to verify Mark As Closed Out Button is Enabled or not
     */
    public boolean verifyMarkAsClosedOutButtonEnabled() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, markAsClosedOutBtn, 10);
        if ($(markAsClosedOutBtn).isEnabled()) {
            return true;
        }
        return false;
    }

    /**
     * Function to verify response of mail registration
     *
     * @param user
     */
    public void verifyUserRegisteredResponse(String user) {
        verifyAndSwitchFrame();
        Assert.assertTrue($(userRegistered).text().contains(user));
    }

    /**
     * Function to verify confidentiality of mail
     */
    public void verifyConfidential() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, confidential, 20);
        Assert.assertTrue($(confidential).text().contains("CONFIDENTIAL"));
    }

    /**
     * Function to verify print request options
     *
     * @param options to be verified
     */
    public void verifyPrintOptions(List<String> options) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, printBtn, 40);
        $(printBtn).click();
        for (String option : options) {
            $(By.xpath("//a[contains(text(),'" + option + "')]")).exists();
        }
    }

    /**
     * Method to select register mail from Actions
     */
    public void selectRegisterMail() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, actionOnTopBtn, 20);
        $(actionOnTopBtn).click();
        $(valueRegisterResponse).click();
    }

    /**
     * Function to get reference Mail Number
     */
    public String getReferenceMailNumber() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(5000);
        $(loadingIcon).should(disappear);
        commonMethods.waitForElement(driver, referenceMailNo, 15);
        String mailNumber = $(referenceMailNo).getText();
        driver.switchTo().defaultContent();
        return mailNumber;
    }

    /**
     * Method to get mail number from view mail
     */
    public String getMailNumber() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, mailNo, 20);
        return $(mailNo).getText();
    }

    /**
     * Method to verify document attached in mail
     *
     * @param docNo
     * @return
     */
    public boolean verifyDocumentsAttached(String docNo) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, fileAttachments, 60);
        getElementInView(fileAttachments);
        return $(By.xpath("//table[@class='auiTable']//div[contains(.,'" + docNo + "')]")).isDisplayed();
    }

    /**
     * Function to return thread mail number
     *
     * @return
     */
    public String returnThreadMailNumber() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, threadMailNum, 20);
        return $(threadMailNum).getText();
    }

    /**
     * Function to verify Mail Status
     */
    public boolean verifyMailStatus(String status) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, mailStatus, 40);
        return $(mailStatus).getText().contains(status);
    }

    /**
     * Function to verify Mail Recipient
     *
     * @param directory
     * @param user
     * @return
     */
    public boolean verifyMailRecipient(String directory, String user) {
        verifyAndSwitchFrame();
        By recipient = By.xpath("//span[text()='" + directory + "']//../..//span//span//span");
        commonMethods.waitForElement(driver, recipient, 20);
        return $(recipient).getText().contains(user);
    }

    /**
     * Method to verify Mail recipient
     *
     * @return
     */

    public boolean verifyMailRecipient(String recipient) {
        verifyAndSwitchFrame();
        By recipientLocator = By.xpath("//span[contains(.,'" + recipient + "')]");
        try {
            commonMethods.waitForElement(driver, recipientLocator, 30);
        } catch (TimeoutException e) {
            e.printStackTrace();
        }

        return $(recipientLocator).isDisplayed();
    }

    /**
     * Function to click on Parent Mail
     */
    public void clickParentMail() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, parentMail, 30);
        $(parentMail).click();
        commonMethods.waitForElementExplicitly(8000);
    }
    /**
     * Function to click on Thead Mail
     */
    public void clickThreadMail() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(5000);
        if($(threadMail).isDisplayed()) {
            $(threadMail).click();
            commonMethods.waitForElementExplicitly(7000);
        }
    }

    /**
     * Method to get mail number from view mail
     */
    public boolean verifyMailSubject(String subject) {
        verifyAndSwitchFrame();
        By subjectTxt = By.xpath("//span[contains(text(),'" + subject + "')]");
        commonMethods.waitForElement(driver, subjectTxt, 20);
        return $(subjectTxt).isDisplayed();
    }

    /**
     * Function to verify error Msg for Update doc register
     *
     * @param message
     */
    public Boolean verifyUpdateDocumentRegister(String message) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        getElementInView(openDocument);
        commonMethods.waitForElement(driver, openDocument, 30);
        $(openDocument).click();
        commonMethods.waitForElement(driver, updateRegisterBtn, 20);
        $(updateRegisterBtn).click();
        commonMethods.waitForElementExplicitly(2000);
        By registerMsg = By.xpath("//span[contains(text(),'" + message + "')]");
        commonMethods.waitForElement(driver, registerMsg, 20);
        Assert.assertTrue($(oneDoc).isDisplayed());
        return $(registerMsg).isDisplayed();
    }

    /**
     * Function to open attached Doc
     *
     * @param docName
     */
    public void downloadAttachedDoc(String docName) {
        verifyAndSwitchFrame();
        By downloadImg = By.xpath("//div[text()='" + docName + "']//ancestor::tr//td[2]//img");
        commonMethods.waitForElement(driver, openDocument, 20);
        getElementInView(openDocument);
        commonMethods.waitForElement(driver, downloadImg, 20);
        $(downloadImg).click();
    }

    /**
     * Function to verify download erorr Msg
     *
     * @return
     */
    public boolean verifyDownloadErrorMsg() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, docWarningMsg, 20);
        return $(docWarningMsg).isDisplayed();
    }

    /**
     * Function to close download window
     */
    public void closeDownloadWindow() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, downloadCloseBtn, 20);
        $(downloadCloseBtn).click();
    }

    /**
     * Function to verify update register button present
     *
     * @return
     */

    public boolean verifyUpdateRegisterBtn() {
        verifyAndSwitchFrame();
        getElementInView(openDocument);
        commonMethods.waitForElement(driver, openDocument, 60);
        $(openDocument).click();
        return $(updateRegisterBtn).isDisplayed();
    }

    /**
     * Function to select Doc Options from Actions
     *
     * @param action
     */
    public void selectDocActions(String action) {
        commonMethods.waitForElementExplicitly(3000);
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, openDocument, 80);
        getElementInView(openDocument);
        $(openDocument).click();
        commonMethods.waitForElement(driver, documentActions, 80);
        $(documentActions).click();
        commonMethods.waitForElementExplicitly(2000);
        $(By.xpath("//a[contains(text(),'" + action + "')]")).click();
    }

    /**
     * Function to get Mail status
     *
     * @return
     */
    public String getMailStatus() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, mailStatusOnViewMail, 10);
        sleep(2000);
        return $(mailStatusOnViewMail).text();
    }

    /**
     * Fumction to verify mail note
     *
     * @return
     */
    public boolean verifyNotesAvailable() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, mailNote, 10);
        return $(mailNote).isDisplayed();
    }

    /**
     * Function to download document
     *
     * @param downloadOption
     */
    public void downloadDocument(String downloadOption) {
        verifyAndSwitchFrame();
        sleep(3000);
        //$(By.xpath("//mail-attached-documents[@class='ng-isolate-scope']//div[@class='auiCollapsibleSection-body']//tr[td//text()[contains(., '" + commonMethods.returnDocNumberInJson(document) + "')]]//td[1]//input")).setSelected(true);
        //$(downloadBtn).click();
        $(By.xpath("//div[contains(@class,'mailAttachedFiles')]//th//input[@type='checkbox']")).click();
        switch (downloadOption) {
            case "zip download":
                $(By.xpath("//button[contains(text(),'Zip Download')]")).click();
                commonMethods.waitForElementExplicitly(10000);
                break;
            case "zip download wih markup":
                $(zipDownloadMarkup).click();
                break;
        }
    }
    public void downloadDocument(String document,String downloadOption)
    {
        verifyAndSwitchFrame();
        sleep(3000);
        $(By.xpath("//mail-attached-documents[@class='ng-isolate-scope']//div[@class='auiCollapsibleSection-body']//tr[td//text()[contains(., '" + commonMethods.returnDocNumberInJson(document) + "')]]//td[1]//input")).setSelected(true);
        $(downloadBtn).click();
        switch (downloadOption) {
            case "zip download":
                $(zipDownloadLink).click();
                commonMethods.waitForElementExplicitly(10000);
                break;
            case "zip download wih markup":
                $(zipDownloadMarkup).click();
                break;
        }
    }
    /**
     * Function to verify download options
     *
     * @param document
     * @param downloadOption
     */
    public void verifyDownloadOptions(String document, String downloadOption) {
        verifyAndSwitchFrame();
        sleep(3000);
        $(By.xpath("//mail-attached-documents[@class='ng-isolate-scope']//div[@class='auiCollapsibleSection-body']//tr[td//text()[contains(., '" + commonMethods.returnDocNumberInJson(document) + "')]]//td[1]//input")).setSelected(true);
        $(downloadBtn).click();
        switch (downloadOption) {
            case "zip download":
                Assert.assertTrue($(zipDownloadLink).isDisplayed());
                break;
            case "zip download wih markup":
                Assert.assertTrue($(zipDownloadMarkup).isDisplayed());
                break;
        }
    }

    /**
     * Method to Verify mandatory buttons on the view mail page
     */
    public void verifyNavigationButtons() {
        commonMethods.waitForElement(driver, actionOnTopBtn);
        Assert.assertTrue($(markAsClosedOutBtn).isDisplayed());
        Assert.assertTrue($(printBtn).isDisplayed());
        Assert.assertTrue($(forwardBtn).isDisplayed());
        Assert.assertTrue($(replyBtn).isDisplayed());
    }

    /**
     * Method to Verify Thread Count and User Info in the Panel
     *
     * @param expectedCount
     */
    public void verifyThreadCountWithUserInfo(int expectedCount, String parentUser, String threadUser) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, parentMail, 60);
        $$(numberOfThreadMails).shouldHaveSize(expectedCount);
        Assert.assertTrue($(parentUserNameOnThread).getText().contains(commonMethods.getUserData(parentUser, "name")));
        Assert.assertTrue($(replyUserNameOnThread).getText().contains(commonMethods.getUserData(threadUser, "name")));
    }


    /**
     * Method to Verify sender and receiver on each thread
     *
     * @param sender,receiver
     */

    public void verifyThreadNavigation(String sender, String receiver) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, parentMail);
        commonMethods.waitForElementExplicitly(2000);
        Assert.assertTrue($(mailSenderFrom).getText().contains(commonMethods.getUserData(sender, "name")));
        Assert.assertTrue($(mailReceiverTo).getText().contains(commonMethods.getUserData(receiver, "name")));
    }

    /**
     * Method to Verify Mandatory Fields on the Mail Component
     */
    public void validateMandatoryFieldsOnViewMail() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, mailType);
        Assert.assertTrue("Mail type is not displayed", $(mailType).isDisplayed());
        Assert.assertTrue("Mail Number is not displayed", $(mailNumber).isDisplayed());
        Assert.assertTrue("Reference Mail Number is not displayed", $(referenceMailNo).isDisplayed());
        Assert.assertTrue("Mail Subject is not displayed", $(mailSubject).isDisplayed());
        Assert.assertTrue("Mail Sender From is not displayed", $(mailSenderFrom).isDisplayed());
        Assert.assertTrue("Mail Received To is not displayed", $(mailReceiverTo).isDisplayed());
        Assert.assertTrue("Status on view mail is not displayed", $(statusOnViewMail).isDisplayed());
        Assert.assertTrue("Mail note is not displayed", $(mailNote).isDisplayed());
        Assert.assertTrue("Mail message body is not displayed", $(messageBody).isDisplayed());
    }

    /**
     * Method to Verify Print Options on the Mail Component
     *
     * @param option
     */

    public void validatePrintOption(String option) {
        commonMethods.waitForElement(driver, printBtn);
        $(printBtn).click();
        switch (option) {
            case "Screen Style": {
                commonMethods.waitForElement(driver, screenStyleBtn);
                $(screenStyleBtn).click();
                break;
            }
            case "Letter Style": {
                commonMethods.waitForElement(driver, letterStyleBtn);
                $(letterStyleBtn).click();
                break;
            }
        }
    }

    /**
     * Method to Verify Draft Mail and delete the draft on the Mail Component
     *
     * @param mailNum
     */
    public void verifyDraftThread(String mailNum) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, mailNumber);
        Assert.assertTrue($(mailNumber).getText().contains(mailNum));
        commonMethods.waitForElement(driver, draftStatusOnThread);
        Assert.assertTrue($$(numberOfThreadMails).size() > 1);
    }

    /**
     * Function to delete draft mail on the View Mail Page
     */
    public void deleteDraftOnViewMail() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, deleteDraftBtn, 10);
        $(deleteDraftBtn).click();
        commonMethods.waitForElement(driver, deleteConfirmBtn, 10);
        $(deleteConfirmBtn).click();
    }

    /**
     * Function to select start workflow for document
     *
     * @param document name
     */
    public void startWorkflow(String document) {
        commonMethods.waitForElement(driver, startWorkFlowBtn, 40);
        getElementInView(openDocument);
        $(By.xpath("//mail-attached-documents[@class='ng-isolate-scope']//div[@class='auiCollapsibleSection-body']//tr[td//text()[contains(., '" + document + "')]]//td[1]//input")).click();
        $(startWorkFlowBtn).exists();
        $(startWorkFlowBtn).click();
    }

    /**
     * Function to click on Show All Attachments.
     */
    public void clickOnShowAllAttachments() {
        $(loadingIcon).should(disappear);
        verifyPageTitle();
        $(showMoreAttachments).click();
    }

    /**
     * Function to get the attachments count
     */
    public int getAttachmentsCount() {
        $(loadingIcon).should(disappear);
        return $$(attachmentSize).size();
    }

    /**
     * Function to verify start sub workflow btn
     *
     * @return
     */
    public boolean verifyStartSubWorkflowBtn() {
        commonMethods.waitForElement(driver, openDocument, 40);
        return $(startWorkflowBtn).isDisplayed();
    }

    /**
     * Function to Navigate to SD from Attachment
     */
    public void navigateToSDOnAttachment() {
        commonMethods.waitForElement(driver, actionsOnAttachment, 120);
        $(actionsOnAttachment).click();
        commonMethods.waitForElement(driver, actionSubmittedDocument);
        $(actionSubmittedDocument).click();
    }

    /**
     * Function to verify delete draft button
     */
    public boolean verifyDeleteDraft() {
        verifyAndSwitchFrame();
        return $(deleteDraftBtn).isDisplayed();
    }

    /**
     * Function to verify Approval banner in view mail page
     */
    public boolean verifyPendingApprovalBanner() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, lblPendingApproval, 30);
        return $(lblPendingApproval).isDisplayed();
    }

    /**
     * Method to get mail subject from view mail
     */
    public String getMailSubject() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, mailSubject, 20);
        return $(mailSubject).getText();
    }

    /**
     * Function to verify file is displayed
     */
    public boolean verifyFileDisplayed(List<String> fileName) {
        clickForward();
        verifyAttachmentMailForward(fileName);
        return true;
    }

    /**
     * Function to verify file visible in mail
     */
    public boolean verifyFileViewMail(List<String> expectedFileName) {
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, fileAttachList, 30);
        return commonMethods.getValues(fileAttachList).containsAll(expectedFileName);
    }

    /**
     * Function to verify documents in forward mail section
     */
    public boolean verifyTransmittalForwrdMail(List<String> expectedFileName) {
        clickForward();
        commonMethods.waitForElementExplicitly(3000);
        return commonMethods.getValues(attachmentFileName).containsAll(expectedFileName);
    }

    /**
     * Function to verify attachments in  forward mail
     */
    public void verifyAttachmentMailForward(List<String> expectedFileName) {
        commonMethods.waitForElementExplicitly(3000);
        for (WebElement element : $$(attachmentFileName)) {
            Assert.assertTrue("File name matches", expectedFileName.contains(element.getText()));
        }
    }

    /**
     * Function to verify multiple files in mail section
     */
    public boolean verifyFileTransmittalMail(List<String> docNo) {
        return commonMethods.getValues(fileList).containsAll(docNo);
    }

    /**
     * Function to click on package number present in package section
     */
    public void clickPackage(String packageId) {
        By xpath = By.xpath("//package-info//a[contains(text(),'" + packageId + "')]");
        commonMethods.waitForElement(driver, xpath, 30);
        $(xpath).click();
    }

    /**
     * Function to get attachment document names in view mail page
     */
    public List<String> getAttachments() {
        List<String> attachments = new ArrayList<>();
        for (WebElement element : $$(lnkMailAttachments))
            attachments.add(element.getText().trim());
        return attachments;
    }

    /**
     * Function to select all mail attachments
     */
    public void selectAllDocuments(boolean value) {
        commonMethods.waitForElement(driver, selectAllChkBox, 60);
        $(selectAllChkBox).setSelected(value);
    }

    /**
     * Function to click on Zip download button
     */
    public void clickZipDownload() {
        $(btnZipDownload).click();
    }

    /**
     * Function to download all documents attached in a mail
     *
     * @param downloadOption
     */
    public void downloadAllDocuments(String downloadOption) {
        commonMethods.waitForElement(driver, downloadBtn);
        $(downloadBtn).click();
        switch (downloadOption) {
            case "zip download":
                commonMethods.waitForElement(driver, zipDownloadLink);
                $(zipDownloadLink).click();
                break;
            case "zip download with markups":
                commonMethods.waitForElement(driver, zipDownloadMarkup);
                $(zipDownloadMarkup).click();
                break;
        }
    }

    /**
     * Function to verify download button
     */
    public String verifyDownloadButton() {
        return $(downloadBtn).getAttribute("disabled");
    }

    /**
     * Function to verify ZDWM success message is displayed
     */
    public boolean verifyZDWMMessage() {
        commonMethods.waitForElement(driver, zdwmSuccessMessage);
        return $(zdwmSuccessMessage).isDisplayed();
    }

    /**
     * Function to expand Mail Thread section if it is not expanded
     */
    public void clickMailThreadExpand() {
        if (configFileReader.getAppHubEnable()) {
            verifyAndSwitchFrame();
            commonMethods.waitForElement(driver, showHideThead, 120);
            String checkThread = $(showHideThead).getAttribute("class");
            if (checkThread.equalsIgnoreCase("icon icon-expando")) {
                $(showHideThead).click();
            }
        }
    }

    /**
     * Function to expand close the Mail Thread section if it is expanded
     */
    public void closeMailThreadExpanded() {
        if(configFileReader.getAppHubEnable()) {
            verifyAndSwitchFrame();
            commonMethods.waitForElement(driver, showHideThead,120);
            String checkThread = $(showHideThead).getAttribute("class");
            if (checkThread.equalsIgnoreCase("icon icon-expando expanded")) {
                $(showHideThead).click();
            }
        }
    }
    /**
     * Method to get the Attachment view column headers
     *
     * return
     */
    public List<String> getAttachmentViewColmOrder() {
        verifyAndSwitchFrame();
        List<String> attachmentViewHeader=commonMethods.getValues(attachmentView);
        attachmentViewHeader.replaceAll(String::toUpperCase);
        return attachmentViewHeader;
    }
    /**
     * Method to verify the footer message
     */
    public boolean verifyFooterMessage(String Message) {
        return $(By.xpath("//*[contains(text(),'" + Message + "')]")).isDisplayed();
    }
}