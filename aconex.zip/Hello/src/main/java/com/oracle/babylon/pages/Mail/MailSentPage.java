package com.oracle.babylon.pages.Mail;

import com.codeborne.selenide.WebDriverRunner;
import org.junit.Assert;
import org.openqa.selenium.By;

import java.util.Map;

import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.switchTo;

public class MailSentPage extends MailPage {

    public MailSentPage() {
        this.driver = WebDriverRunner.getWebDriver();
    }


    //Initializing the web elements
    private By pageTitle = By.xpath("//h1//span[text()='Search Mail']");
    private By markAsClosedOutUnderTools = By.xpath("//a[contains(text(),'Mark as Closed-Out')]");
    private By markMailAsClosedOut = By.xpath("//button[contains(text(),'Mark mail as Closed-Out')]");
    private By loadingIcon = By.cssSelector(".loading_progress");
    private By mailNumberField = By.xpath("//div[@class='mailHeader-numbers']//div[2]//div[2]");
    public static String mailNumber = null;



    /**
     * Function to navigate to a sub menu from the Aconex home page
     */
    public void navigateAndVerifyPage() {
        $(loadingIcon).should(disappear);
        getMenuSubmenu("Mail", "Sent");
        verifyPageTitle(pageTitle);
    }

    /**
     * Function to verify whether Mark As closed out option is avialable under Tools
     */

    public boolean verifyMarkAsClosedOutButton()
    {
        $(toolsBtn).click();
        commonMethods.waitForElementExplicitly(2000);
        if($(markAsClosedOutUnderTools).isDisplayed()){
            return true;
        }
        return false;
    }
}
