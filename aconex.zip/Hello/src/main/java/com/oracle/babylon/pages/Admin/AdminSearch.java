package com.oracle.babylon.pages.Admin;

import com.codeborne.selenide.WebDriverRunner;
import com.github.javafaker.Faker;
import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.Hashtable;
import java.util.Map;

import static com.codeborne.selenide.Selenide.$;

/**
 * Class file to contain all the method related to the Admin Xoogle Search Page
 * Author : susgopal
 */
public class AdminSearch extends Navigator {

    //Initialization the web elements
    private By xoogleLabel = By.xpath("//table[@class='formTable']//td//label[text()='Xoogle']");
    private By searchKeywords = By.name("SRCH_KEYWORDS");
    private By accountDisabledCheckBox = By.name("USER_DISABLED");
    private By userLockedCheckBox = By.name("USER_LOCKED");
    private By userLocked = By.xpath("//input[@name='USER_LOCKED']");
    private By userDisabled = By.xpath("//input[@name='USER_DISABLED']");
    private By userPage = By.xpath("//h1[contains(text(),'User Information')]");
    private By saveBtn = By.xpath("//div[contains(text(),'Save')]");
    private By passwordBtn = By.xpath("//div[contains(text(),'Password')]");
    private By currentPassword = By.xpath("//input[@id='PASSWORD']");
    private By newPassword = By.xpath("//input[@id='NEW_PASSWORD']");
    private By confirmPassword = By.xpath("//input[@id='CONFIRM_PASSWORD']");
    private By passwordChangeMsg = By.xpath("//div[@id='messagePanel']");
    private By enterAconexLink=By.xpath("//a[contains(text(),'Enter Aconex')]");
    Map<String, Object> mapToReplace = new Hashtable<>();
    Map<String, Map<String, Object>> mapOfMap = new Hashtable<>();
    private By projectField = By.xpath("//a[@title='Show project information page']//..");



    public AdminSearch(){
        this.driver = WebDriverRunner.getWebDriver();
    }

    /**
     * Method to navigate and verify for the title of the page
     */
    public void navigateAndVerifyPage() {
        getMenuSubmenu("Setup", "Search");
        Assert.assertTrue(verifyPageTitle("Search"));
    }

    /**
     * Returns the id for a single element search. Matches the name of the result obtained, retrieves the associated id
     * @param searchText
     * @return
     */
    public String returnResultId(String searchText){
        search(searchText);
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, projectField, 30);
        String projectId = $(projectField).getText();
        projectId = projectId.substring(projectId.indexOf('[')+1, projectId.indexOf("]"));
        switchToOriginal();
        return projectId;
    }

    /**
     * Returns the id for a single element search. Matches the name of the result obtained, retrieves the associated id
     * @param searchText
     * @return
     */
    public String returnResultId(String searchText, String orgName){
        String nameLocator;
        String orgNameLocator;
        String finalLocator;
        search(searchText);
        //Search result displayed 20 chcracters only. So need to crop the string if lenght is more than 20.
        if(searchText.length()>20){
            searchText =  searchText.substring(0, 20);
        }
        verifyAndSwitchFrame();
        //If search text contains single quotes, we need to enclose the locator in doubl quotes and vice versa.
        if(searchText.contains("'")){
            nameLocator = "//td[contains(.,\"" + searchText + "\")]";
        }else{
            nameLocator = "//td[contains(.,'" + searchText + "')]";
        }
        if(orgName.contains("'")){
            orgNameLocator = "[contains(.,\"" + orgName + "\")]";
        }else{
            orgNameLocator = "[contains(.,'" + orgName + "')]";
        }
        finalLocator = nameLocator + orgNameLocator;

        commonMethods.waitForElement(driver, By.xpath(finalLocator), 80);
        String elementInfo = $(By.xpath(finalLocator)).parent().getText();
        driver.switchTo().defaultContent();

        return elementInfo.substring(elementInfo.indexOf('[')+1, elementInfo.indexOf(']'));
    }

    /**
     * Click on the search results. Some test scenarios need the user to navigate to the information of the results
     * @param searchText Text to be searched and specified in the Search text box
     * @param returnResultText Text/ID constant that we use to click on the returned results
     */
    public void clickSearchResults(String searchText, String returnResultText){
        search(searchText);
        commonMethods.switchToFrame(driver, "frameMain");
        By searchResult = By.xpath("//td//a[contains(text(),\""+ returnResultText+ "\")]");
        commonMethods.waitForElement(driver, searchResult);
        $(searchResult).click();
        driver.switchTo().defaultContent();
    }

    /**
     * Search using a key to retrieve associated rows
     */
    public void search(String searchKey){
      //  driver = commonMethods.switchToFrame(driver, "frameMain");
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, xoogleLabel, 2);
        $(searchKeywords).sendKeys(searchKey);
        $(searchKeywords).pressEnter();
        driver.switchTo().defaultContent();
    }

    /**
     * Method to make user Disabled
     */

    public void makeUserDisabled() {
        getElementInView(accountDisabledCheckBox);
        $(accountDisabledCheckBox).setSelected(true);
        $(saveBtn).click();
    }
    /**
     * Method to make user Enabled
     */

    public void makeUserEnabled() {
        getElementInView(accountDisabledCheckBox);
        $(accountDisabledCheckBox).setSelected(false);
        $(saveBtn).click();
    }
    /**
     * Method to lock a user
     */

    public void lockUser() {
        getElementInView(userLockedCheckBox);
        $(userLockedCheckBox).setSelected(true);
        $(saveBtn).click();
    }

    /**
     * Function to select search group
     * @param group
     */
    public void selectSearchGroup(String group) {
        verifyAndSwitchFrame();
        $(By.xpath("//div[@class='flow-left']//div[contains(.,'" + group + "')]//input")).setSelected(true);
    }

    /**
     * Function to select result
     * @param key
     */
    public void selectResult(String key) {
        verifyAndSwitchFrame();
        By result = By.xpath("//div[@id='searchResultsWrapper']//tbody//tr[@class='hvr']//a[contains(.,'" + key + "')]");
        commonMethods.waitForElement(driver, result, 20);
        $(result).click();
    }

    /**
     * Function to enable Account security
     */
    public void enableAccountSecurity() {
        commonMethods.waitForElement(driver, userPage, 15);
        $(userDisabled).setSelected(false);
        $(userLocked).setSelected(false);

    }

    /**
     * Click on save
     */
    public void save() {
        $(saveBtn).click();
    }

    /**
     * Function to change user password
     * @param user
     */
    public void resetPassword(String user) {
        verifyAndSwitchFrame();
        $(passwordBtn).click();
        commonMethods.waitForElement(driver, currentPassword, 20);
        $(currentPassword).sendKeys(configFileReader.getPassword());
        Faker faker = new Faker();
        String password = faker.internet().password(9, 12, true);
        password = password + "@08";
        $(newPassword).sendKeys(password);
        $(confirmPassword).sendKeys(password);
        $(saveBtn).click();
        commonMethods.waitForElement(driver, passwordChangeMsg, 10);
        Assert.assertTrue($(passwordChangeMsg).text().contains("Your password has been successfully updated"));
        mapToReplace.put("password", password);
        mapOfMap.put(user, mapToReplace);
        dataSetup.fileWrite(user, mapOfMap, configFileReader.getUserDataPath());
    }
    public void replacePassword(String password)
    {
        $(newPassword).sendKeys(password);
        $(confirmPassword).sendKeys(password);
        $(saveBtn).click();
        commonMethods.waitForElement(driver, passwordChangeMsg, 40);
        Assert.assertTrue($(passwordChangeMsg).text().contains("Your password has been successfully updated"));
    }

    /**
     * Function to change user password
     *
     */
    public String resetPassword() {
        verifyAndSwitchFrame();
        $(passwordBtn).click();
        commonMethods.waitForElement(driver, currentPassword, 20);
        $(currentPassword).sendKeys(configFileReader.getPassword());
        Faker faker = new Faker();
        String password = faker.internet().password(9, 12, true);
        password = password + "@08";
        $(newPassword).sendKeys(password);
        $(confirmPassword).sendKeys(password);
        $(saveBtn).click();
        commonMethods.waitForElement(driver, passwordChangeMsg, 10);
        Assert.assertTrue($(passwordChangeMsg).text().contains("Your password has been successfully updated"));
        return password;
    }

    public void clickEnterAconexLink()
    {
        commonMethods.waitForElement(driver,enterAconexLink);
        $(enterAconexLink).click();
    }
}
