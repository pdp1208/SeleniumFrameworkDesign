package com.oracle.babylon.pages.SupplierDocs;

import com.codeborne.selenide.Condition;
import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.*;

public class SupplierDocSearchPage extends SupplierDocPage {

    private By progressSummaryText = By.xpath("(//tr//td[@class='progressSummaryText'])[1]");
    private By resetBtn = By.xpath("//button[@id='btnReset']//div[contains(text(),'Reset')]");
    private By sortField = By.id("sortField");
    private By dateRange = By.xpath("//select[@class='drp_query']");
    private By dateGroupIn = By.xpath("//select[@class='drp_qualifier']");
    private By commentsOnSubmission = By.xpath("//textarea[@id='comments']");
    private By markAsSubmittedOKBtn = By.xpath("//button[@id='markAsSubmitted-commit']//div[text()='OK']");
    private By selectFirstDocument = By.xpath("(//tr[contains(@class,'dataRow ')][1]//td//input[@type='checkbox'])[1]");
    private By suppDocSearchDP_add = By.id("SuppDocSearchDP_add");
    private By deleteIconOnDateRange = By.xpath("(//div//img[@title='Remove this date query'])[2]");
    private By dateFromInput = By.id("SuppDocSearchDP_Date1_1_da");
    private By dateToInput = By.id("SuppDocSearchDP_Date2_1_da");
    private By dataNoResults = By.xpath("//div[@class='dataNoResults']");
    private By disciplineDropDown = By.id("discipline");
    private By showSubmissionHistory = By.id("showSubmissionHistory");
    private By toggleShowHideAdvancedSearch = By.xpath("//div[@class='searchFilter']//a//img[contains(@title,'advanced search fields')]");
    private By advancedFields = By.xpath("//tr[@class='advancedFields']");
    private By paginationToPrevious = By.xpath("(//div[@class='paging flow-right']//a[contains(text(),'previous')])[1]");
    private By resetColumnBtn = By.xpath("//button[@id='btnReset']//div[contains(text(),'Reset')]");
    private By selectOption = By.xpath("(//select[@id='bidi_configColumns_AVAIL']//option)[1]");
    private By searchOption = By.xpath("//select[@id='bidi_configColumns_AVAIL']");
    private By addColumnArrow = By.xpath("//button[@id='btnbidi_configColumns_ADD']//div[contains(text(),'>>')]");
    private By btnReportsMenu = By.xpath("//button[@id='btnReportsMenu']//div[text()='Reports']");
    private By bannerMsgContent = By.xpath("//*[@class='auiMessage message-banner info']//*[@class='auiMessage-content']");
    private By temporaryFilesBtn = By.xpath("//a[text()='Temporary Files']");
    private By delegateHeader = By.xpath("//div[text()='Delegate Selected Supplier Documents']");
    private By originalAssignee_query = By.id("originalAssignee_query");
    private By newAssignees_query = By.id("newAssignees_query");
    private By viewDetailsDelegate = By.xpath("//span[text()='View details']");
    private By delegateOkBtn = By.id("btndelegate_ok");
    private By delegateCancelBtn = By.id("btndelegate_cancel");
    private By lookupUser = By.xpath("//div[@class='lookup-assignee  lookup-user truncated']");
    private By lookUpMessage = By.xpath("//div[@class='lookup-error-message']");
    private By assigneeLookUp = By.xpath("//table[@id='newAssignees_container']//div[@class='lookup-assignee lookup-user truncated']");
    private By firstDocumentOnResult = By.xpath("(//tr[contains(@class,'dataRow ')]//td//div[@class='searchResults-cellWrap'])[1]");
    private By viewDetailsText = By.xpath("//*[contains(text(),'Note: 1 of the selected documents were not available for this action - ')]");
    private By excludeDocListMessage = By.xpath("//div[@id='excludedDocList']//td[text()='The document is not in a supplier document process']");
    private By excludeDocListSubmissionMsg = By.xpath("//div[@id='excludedDocList']//td[text()='The document is not assigned to your organization']");
    private By successMsgOnDelegate = By.xpath("//h2//*[text()='Tasks successfully delegated']");
    private By delegateSelectedSupplierDoc = By.xpath("//*[@id='delegate_title' and text()='Delegate Selected Supplier Documents']");
    private By viewSubmissionHistory = By.xpath("//a//img[@title='View submission history of document']");
    private By supplierDocSubmissionHistoryHeader = By.xpath("//*[@id='submissionHistory_title' and text()='Supplier Documents Submission History']");
    private By accessDocumentsMenu = By.xpath("//td//img[@title='Access document options menu']");
    private By updateRevision = By.xpath("//input[@title='Document Revision Number/Letter']");
    private By supersedeDocButton = By.xpath("//button[@title='Supersede this document']");
    private By supersedeDocOption = By.xpath("//*[contains(text(),'Edit / Upload new version')]");
    private By selectAllAvailableColumns = By.xpath("(//select[@id='bidi_configColumns_AVAIL']//option)[1]");
    private By selectAvailableColumns = By.xpath("//select[@id='bidi_configColumns_AVAIL']");
    private By addSelectedColumns = By.xpath("//button[@id='btnbidi_configColumns_ADD']//div[contains(text(),'>>')]");
    private By packageNumberOnBidi = By.xpath("//span[@id='selectedOptions_packageNumbers']");
    private By submissionStatusBidi = By.id("selectedOptions_submissionStatuses");
    private By inputDocNo = By.xpath("//input[@name='docno']");
    private By closeBtnOnSubmissionDialog = By.xpath("//button[@id='excludedDocs-cancel']//div[text()='Close']");
    private By closeDelegateBtn = By.xpath("//button[@id='btndelegate_close']");
    public String noSDMatchedYourRequestMsg = "No supplier documents matched your request";
    private By saveSearchHeader = By.xpath("//*[@id='saveSearchPanel_title']");
    private By saveSearchName = By.id("savedSearchName");
    private By saveSearchDescription = By.id("savedSearchDescription");
    private By saveSearchFlagForOrg = By.id("savedSearchSharedFlag");
    private By saveSearchOkBtn = By.xpath("//button[@id='btnsaveSearchPanel_ok']//div[@class='uiButton-label'][contains(text(),'OK')]");
    private By saveSearchCancelBtn = By.xpath("//button[@id='btnsaveSearchPanel_cancel']//div[@class='uiButton-label'][contains(text(),'Cancel')]");
    private By saveSearchAsBtn = By.xpath("//button[@id='btnSaveSearchAs']//div[@class='uiButton-label'][contains(text(),'Save Search As')]");
    private By savedSearchDropDown = By.xpath("//span[@id='savedSearchSelector']");
    private By manageSavedSearch = By.xpath("//option[contains(text(),'Manage Saved Searches')]");
    private By savedSearchManageDrpDown = By.xpath("//select[@id='savedSearchManageSSList']");
    private By deleteSavedSearchLink = By.xpath("//a[@class='delete-link']");
    private By closeSaveSearchPanel = By.xpath("//div[@id='btnsaveSearchPanel_closeBox']");
    private By publisherName = By.xpath("//tr[@id='savedSearchPublishedByRow']//td[@class='contentcell']");
    private By savedSearchHeader = By.xpath("//h1//*[@id='savedSearchTitle']");
    public String searchHeader = "Search - Supplier Documents";


    /**
     * Method to navigate to page no
     */
    public void navigateToPage(int pageNo) {
        commonMethods.waitForElement(driver, numberOfResults);
        By pageLoc = By.xpath("(//div[@id='searchResultsContainer']//a[text()=" + pageNo + "])[1]");
        commonMethods.waitForElement(driver, pageLoc);
        $(pageLoc).click();
    }

    /**
     * Method to verify the Search on Document No
     */
    public boolean verifySearchOnDocNo(String docNo) {
        commonMethods.waitForElement(driver, inputDocNo);
        $(inputDocNo).sendKeys(docNo);
        clickSearchBtn();
        By docResultDisplay = By.xpath("//tr[contains(@class,'dataRow ')]//td//div[@class='searchResults-cellWrap']//..//*[contains(text(),'" + docNo + "')]");
        commonMethods.waitForElement(driver, docResultDisplay, 80);
        return $(docResultDisplay).isDisplayed();
    }

    /**
     * Method to get No match result message
     */
    public String getNoMatchResultsMsg() {
        commonMethods.waitForElementExplicitly(3000);
        return $(dataNoResults).getText();
    }

    /**
     * Method to search package with Title
     */
    public void searchPackageWithTitle(String title) {
        commonMethods.waitForElement(driver, titleName);
        $(titleName).sendKeys(title);
        clickSearchBtn();
    }

    /**
     * Method to add a column in search
     */
    public void addAColumn(String columnName) {
        clickAddAColumn();
        By columnElement = By.xpath("//select[@id='bidi_configColumns_AVAIL']//option[text()='" + columnName + "']");
        getElementInView(columnElement);
        $(columnElement).doubleClick();
    }

    /**
     * Method to click Add A Column Button
     */
    public void clickAddAColumn() {
        commonMethods.waitForElement(driver, addRemoveColumnsBtn);
        getElementInView(disciplineDropDown);
        $(addRemoveColumnsBtn).click();
    }

    /**
     * Method to click Reset to default columns
     */
    public void resetDefaultColumns() {
        commonMethods.waitForElement(driver, resetColumnBtn);
        $(resetColumnBtn).click();
    }

    /**
     * Method to select all available columns in the List
     */
    public void selectAllAvailableColumns() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, selectOption);
        $(selectOption).click();
        $(searchOption).sendKeys(Keys.chord(Keys.CONTROL, "a"));
        $(addColumnArrow).click();
    }

    /**
     * Method to click OK Button in Add Column
     */
    public void clickOkBtnInAddColumn() {
        commonMethods.waitForElement(driver, addColumnOkBtn);
        $(addColumnOkBtn).click();
    }

    /**
     * Method to click Reset Button in Add Column section
     */
    public void clickResetBtnInAddColumn() {
        commonMethods.waitForElement(driver, resetBtn);
        $(resetBtn).click();
    }

    /**
     * Method to click cancel button in Add Column Section
     */
    public void clickCancelBtnInAddColumn() {
        commonMethods.waitForElement(driver, addColumnCancelBtn);
        $(addColumnCancelBtn).click();
    }

    /**
     * Method to select discipline in the drop down
     */
    public void selectDiscipline(String value) {
        commonMethods.waitForElement(driver, disciplineDropDown);
        $(disciplineDropDown).selectOptionContainingText(value);
        clickSearchBtn();
    }

    /**
     * Method to verify the Search columns with the row values provided
     */
    public boolean verifyColumnSearch(String columnName, String value) {
        boolean executionFlag = false;
        By columnHeader = By.xpath("//table[@class='dataTable']//thead//tr[1]//th[contains(text(),'" + columnName + "')]");
        commonMethods.waitForElement(driver, columnHeader);
        commonMethods.waitForElementExplicitly(3000);
        System.out.println($$(tableResults).size());
        for (int rowIterator = 1; rowIterator <= $$(tableResults).size(); rowIterator++) {
            System.out.println(" " + rowIterator);
            Assert.assertTrue($(By.xpath("(//tr[contains(@class,'dataRow ')])[" + rowIterator + "]//td[contains(text(),'" + value + "')]")).isDisplayed());
            executionFlag = true;
        }
        return executionFlag;
    }

    /**
     * Method to clear the search query
     */
    public void clearSearchQuery() {
        commonMethods.waitForElement(driver, searchQuery);
        $(searchQuery).clear();
    }

    /**
     * Method to click on Show Submission History
     */
    public void checkShowSubmissionHistory() {
        commonMethods.waitForElement(driver, showSubmissionHistory);
        $(showSubmissionHistory).setSelected(true);
    }

    /**
     * Method to verify submission history
     */
    public boolean verifySubmissionHistory() {
        boolean verifyFlag = false;
        for (int iterator = 1; iterator <= $$(tableResults).size(); iterator++) {
            String style = $(By.xpath("(//tr[contains(@class,'dataRow ')])[" + iterator + "]")).getAttribute("style");
            if (iterator == $$(tableResults).size())
                Assert.assertEquals(style, "font-weight: bold;");
            else
                Assert.assertEquals(style, "");
            verifyFlag = true;
        }
        return verifyFlag;
    }

    /**
     * Method to get the search results size
     */
    public String getSearchSize() {
        commonMethods.waitForElement(driver, tableResults);
        int totalSize = $$(tableResults).size();
        return String.valueOf(totalSize);
    }

    /**
     * Method to toggle between advanced search fields
     */
    public void showHideAdvancedSearchField() {
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, toggleShowHideAdvancedSearch);
        $(toggleShowHideAdvancedSearch).click();
    }

    /**
     * Method to verify the Show Hide Advanced Search Fields
     */
    public void verifyShowHideAdvSearchField(boolean instance) {
        Assert.assertTrue($(searchQuery).isDisplayed());
        int fieldSize = $$(advancedFields).size();
        $$(advancedFields).shouldHaveSize(8);
        for (int iteartor = 1; iteartor <= fieldSize; iteartor++)
            Assert.assertEquals(instance, $(By.xpath("(//tr[@class='advancedFields'])[" + iteartor + "]")).isDisplayed());

    }

    /**
     * Method to get show per page drop down value
     */
    public String getShowPerPage() {
        return $(showPerPageDropDown).getSelectedText();
    }

    /**
     * Method to get group By drop down value
     */
    public String getGroupBy() {
        return $(selectGroupBy).getSelectedText();
    }

    /**
     * Method to verify search default message
     */
    public void verifySearchDefaultMessage() {
        commonMethods.waitForElement(driver, searchDefaultMessage, 10);
        Assert.assertTrue($(searchDefaultMessage).isDisplayed());
    }

    /**
     * Function to verify the results on each groupBy
     *
     * @param showOptionA,showOptionB
     * @param hideOptionA,hideOptionB
     */
    public void verifyGroupBy(By showOptionA, By showOptionB, By hideOptionA, By hideOptionB) {
        commonMethods.waitForElement(driver, tableResults, 10);
        Assert.assertTrue($(showOptionA).isDisplayed());
        Assert.assertTrue($(showOptionB).isDisplayed());
        $(hideOptionA).shouldBe(Condition.hidden);
        $(hideOptionB).shouldBe(Condition.hidden);
    }

    /**
     * Method to verify the access denied message
     */
    public String returnAccessDeniedMsg() {
        return $(mainBlock).getText();
    }

    /**
     * Method to click on the active package with package No
     */
    public void clickActivePackage(String packageNo) {
        $(By.xpath("//a[@title='Click to view the supplier document package details' and contains(text(),'" + packageNo + "')]")).click();
    }

    /**
     * Method to click on progress summary text
     */
    public void clickProgressSummaryText() {
        commonMethods.waitForElement(driver, progressSummaryText);
        $(progressSummaryText).click();
    }

    /**
     * Method to get the column label name based on the column index
     */
    public String getColumnLabel(int columnIndex) {
        String value = "";
        commonMethods.waitForElementExplicitly(2000);
        if (columnIndex == 1)
            value = $(By.xpath("(//tr[@class='dataHeaders']//th)[" + columnIndex + "]//a")).getAttribute("title");
        else
            value = $(By.xpath("(//tr[@class='dataHeaders']//th)[" + columnIndex + "]")).getText();
        return value;
    }

    /**
     * Method to get sortable column label names
     */
    public String getSortColumnLabel(int columnIndex) {
        return $(By.xpath("(//tr[@class='dataHeaders']//th[@class='sortable'])[" + columnIndex + "]")).getText();
    }

    /**
     * Method to click on Arrow On Add Columns
     */
    public void clickArrowOnAddColumns(String instance) {

        By obj = By.xpath("//button[@id='btnMove" + instance + "List_page']");
        commonMethods.waitForElement(driver, obj);
        $(obj).click();
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Method to select a column name in Add/Remove columns section
     */
    public void selectColumn(String availableColumn) {
        By columnElement = By.xpath("//select[@id='bidi_configColumns']//option[text()='" + availableColumn + "']");
        commonMethods.waitForElement(driver, columnElement);
        commonMethods.waitForElementExplicitly(3000);
        $(columnElement).click();
    }

    /**
     * Method to get exclude document message
     */
    public String getDefaultSortBy() {
        commonMethods.waitForElement(driver, sortField);
        return $(sortField).getSelectedText();
    }

    /**
     * Method to get All Sort By Options available in the drop down
     */
    public ArrayList<String> getAllSortByOptions() {
        commonMethods.waitForElement(driver, sortField);
        return commonMethods.returnAllOptionsInDropDown(driver, sortField);
    }

    /**
     * Method to get date range drop down options
     */
    public ArrayList<String> getDateRangeDropDown() {
        commonMethods.waitForElement(driver, dateRange);
        return commonMethods.returnAllOptionsInDropDown(driver, dateRange);
    }

    /**
     * Method to select date range option based on the index
     */
    public void selectDateRangeOption(String option, String index) {
        commonMethods.waitForElement(driver, dateRange);
        $(By.xpath("(//select[@class='drp_query'])[" + index + "]")).selectOptionContainingText(option);
    }

    /**
     * Method to get period of date range dropdown
     */
    public ArrayList<String> getPeriodDateRangeDropDown() {
        commonMethods.waitForElement(driver, dateGroupIn);
        return commonMethods.returnAllOptionsInDropDown(driver, dateGroupIn);
    }

    /**
     * Method to select particular period range based on the option and index
     */
    public void selectPeriodRangeOption(String option, String index) {
        commonMethods.waitForElement(driver, dateGroupIn);
        $(By.xpath("(//select[@class='drp_qualifier'])[" + index + "]")).selectOptionContainingText(option);
    }

    /**
     * Method to verify the data results are visible
     */
    public void verifyDataResults() {
        commonMethods.waitForElement(driver, tableResults);
        $(tableResults).shouldBe(visible);
    }

    /**
     * Method to enter comments on submission
     */
    public void enterCommentsOnSubmission(String comments) {
        commonMethods.waitForElement(driver, commentsOnSubmission);
        $(commentsOnSubmission).sendKeys(comments);
    }

    /**
     * Method to click Ok in Mark Submission Dialog box
     */
    public void clickOkMarkSubmission() {
        commonMethods.waitForElement(driver, markAsSubmittedOKBtn);
        $(markAsSubmittedOKBtn).click();
    }

    /**
     * Method to select First Supplier Document on Result
     */
    public void selectFirstDocumentOnResult() {
        getElementInView(searchBtn);
        commonMethods.waitForElement(driver, selectFirstDocument);
        $(selectFirstDocument).setSelected(true);
    }

    /**
     * Method to click on Add Another Date Query
     */
    public void addAnotherDateQuery() {
        commonMethods.waitForElement(driver, suppDocSearchDP_add);
        $(suppDocSearchDP_add).click();
        commonMethods.waitForElement(driver, deleteIconOnDateRange, 30);
        $(deleteIconOnDateRange).click();
        commonMethods.waitForElement(driver, suppDocSearchDP_add);
        $(suppDocSearchDP_add).click();
    }

    /**
     * Method to enter search date range from
     */
    public void enterDateFrom(String dateFrom) {
        commonMethods.waitForElement(driver, dateFromInput);
        $(dateFromInput).sendKeys(dateFrom + Keys.ENTER);
    }

    /**
     * Method to enter search date range to
     */
    public void enterDateTo(String dateTo) {
        commonMethods.waitForElement(driver, dateToInput);
        $(dateToInput).sendKeys(dateTo + Keys.ENTER);
    }

    /**
     * Method to get search date range from and to based on instance
     */
    public String getDateRange(String instance) {
        commonMethods.waitForElement(driver, dateToInput);
        return $(By.id("SuppDocSearchDP_Date" + instance + "_1_da")).getValue();
    }

    /**
     * Method to verify the date picker
     */
    public boolean verifyDatePicker(String instance) {
        commonMethods.waitForElement(driver, dateToInput);
        return $(By.xpath("//input[@id='SuppDocSearchDP_Date" + instance + "_1_btn']")).isDisplayed();
    }

    /**
     * Method to select the value of submission status filer
     */
    public void selectSubmissionStatus(String value) {
        commonMethods.waitForElement(driver, submissionStatusMultiSelect);
        getElementInView(disciplineDropDown);
        $(submissionStatusMultiSelect).click();
        commonMethods.waitForElement(driver, submissionStatusInput, 40);
        $(submissionStatusInput).sendKeys(value);
        By columnElement = By.xpath("//select[@id='bidi_submissionStatuses_AVAIL']//option[text()='" + value + "']");
//        By columnElement=By.xpath("//select[@id='bidi_submissionStatuses_AVAIL']//option[text()='"+value+"']");
        getElementInView(columnElement);
        $(columnElement).doubleClick();
        $(submissionStatusOk).click();
        clickSearchBtn();
    }

    /**
     * Method to get the total search results size on Search Screeen
     */
    public int getTotalSearchResults() {
        commonMethods.waitForElement(driver, numberOfResults, 60);
        String noOfResults = $(numberOfResults).getText();
        int resultsCount = 0;
        if (noOfResults.contains("1 - 25")) {
            resultsCount = getResultsCount();
        }
        return resultsCount;
    }

    /**
     * Method to get total results count
     */
    public int getResultsCount() {
        String noOfResults = $(numberOfResults).getText();
        int startValue = noOfResults.indexOf("of ");
        String textValue = noOfResults.substring(0, startValue);
        if (noOfResults.contains("of "))
            noOfResults = noOfResults.replace("of ", "");
        noOfResults = noOfResults.replace(textValue, "");
        int indexValue = noOfResults.indexOf(" results");
        int totalLength = noOfResults.length();
        String textResults = noOfResults.substring(indexValue, totalLength);
        noOfResults = noOfResults.replace(textResults, "");
        noOfResults = noOfResults.replaceAll("[^\\d.]", "");
        return Integer.valueOf(noOfResults);
    }

    /**
     * Method to click Reports Button
     */
    public void clickReportBtn() {
        commonMethods.waitForElement(driver, btnReportsMenu);
        $(btnReportsMenu).click();
    }

    /**
     * Method to select doc on the submission
     */
    public boolean verifyExportToExcel(int totalSearchCount) {
        By export = By.xpath("//a[text()='Export to Excel (" + totalSearchCount + " documents) ']");
        commonMethods.waitForElement(driver, export);
        return $(export).isDisplayed();
    }

    /**
     * Method to click on Export to excel
     */
    public void clickExportToExcel(int totalSearchCount) {
        By export = By.xpath("//a[text()='Export to Excel (" + totalSearchCount + " documents) ']");
        commonMethods.waitForElement(driver, export);
        $(export).click();
    }

    /**
     * Method to get successful exported message
     */
    public String getExportToExcelMsg() {
        commonMethods.waitForElement(driver, bannerMsgContent);
        return $(bannerMsgContent).getText();
    }

    /**
     * Method to click on temporary files from export to excel on SD
     */
    public void clickTemporaryFiles() {
        commonMethods.waitForElement(driver, temporaryFilesBtn);
        Actions actions = new Actions(driver);
        actions.moveToElement($(temporaryFilesBtn)).click().perform();
    }

    /**
     * Method to save button is present
     */
    public boolean checkSaveBtn() {
        commonMethods.waitForElement(driver, viewOnlyEditSuppliedBy, 20);
        commonMethods.waitForElement(driver, viewOnlyEditRequiredBy, 20);
        return $(saveBtn).isDisplayed();
    }

    /**
     * Method to check Add Documents
     */
    public boolean checkAddDocuments() {
        commonMethods.waitForElement(driver, viewOnlyEditSuppliedBy, 20);
        commonMethods.waitForElement(driver, viewOnlyEditRequiredBy, 20);
        return $(btnAddDocumentsMenu).isDisplayed();
    }

    /**
     * Method to verify Submission Status for a document
     */
    public boolean verifySubmissionStatusOnDoc(String documentNum, String status) {
        commonMethods.waitForElement(driver, tableResults);
        return $(By.xpath("//div[@class='searchResults-cellWrap' and text()='" + documentNum + "']//..//..//td[contains(text(),'" + status + "')]")).isDisplayed();
    }

    /**
     * Method to click Delegate Button
     */
    public void clickDelegateButton() {
        commonMethods.waitForElement(driver, delegateBtn, 40);
        $(delegateBtn).click();
    }

    /**
     * Method to verify the Delegate results
     */
    public void verifyDelegateResult(String access, String lookUp) {
        commonMethods.waitForElement(driver, delegateHeader, 50);

        if (lookUp.length() < 2)
            $(originalAssignee_query).shouldBe(visible);
        else
            Assert.assertTrue(getLookUpAssigneeOnSubmission().contains(lookUp));
        $(newAssignees_query).shouldBe(visible);
        commonMethods.waitForElementExplicitly(3000);
        if (access.equalsIgnoreCase("yes"))
            Assert.assertFalse($(viewDetailsDelegate).isDisplayed());
        else
            Assert.assertTrue($(viewDetailsDelegate).isDisplayed());
    }

    /**
     * Method to verify the Delegate Attribute
     */
    public boolean verifyDelagateAttribute(String attribute) {
        By attributeLoc = By.xpath("//div[@id='validDocList']//td[contains(text(),'" + attribute + "')]");
        commonMethods.waitForElement(driver, attributeLoc, 60);
        return $(attributeLoc).isDisplayed();
    }

    /**
     * Method to click Cancel in Delegate Btn
     */
    public void clickCancelDelegateBtn() {
        commonMethods.waitForElement(driver, delegateCancelBtn);
        $(delegateCancelBtn).click();
    }

    /**
     * Method to OK in Delegate Button
     */
    public void clickOkDelegateBtn() {
        commonMethods.waitForElementExplicitly(4000);
        commonMethods.waitForElement(driver, delegateOkBtn);
        $(delegateOkBtn).click();
    }

    /**
     * Method to select doc on the submission
     */
    public void selectDocOnSubmissionScreen(String docNum) {
        By docSelect = By.xpath("//div[@id='submissionRequiredSearchResultsWrapper']//td[contains(text(),'" + docNum + "')]//..//input[@type='checkbox']");
        commonMethods.waitForElement(driver, docSelect, 60);
        $(docSelect).click();
    }

    /**
     * Method to select Doc on the Review
     */
    public void selectDocOnReviewScreen(String docNum) {
        By docSelect = By.xpath("//div[@id='submittedSearchResultsWrapper']//td//a[contains(text(),'" + docNum + "')]//..//..//input[@type='checkbox']");
        commonMethods.waitForElement(driver, docSelect, 60);
        $(docSelect).click();
    }

    /**
     * Method to get LookUp Assignee from the submission screen
     */
    public String getLookUpAssigneeOnSubmission() {
        commonMethods.waitForElement(driver, lookupUser, 40);
        return $(lookupUser).getText();
    }

    /**
     * Method to get Lookup Error Message
     */
    public String getLookUpErrorMessage() {
        commonMethods.waitForElement(driver, lookUpMessage, 40);
        return $(lookUpMessage).getText();
    }

    /**
     * Method to search Assignee
     */
    public String searchAssignee(String userName, String accessInstance) {
        enterAssignee(userName);
        if (accessInstance.equalsIgnoreCase("yes"))
            return getLookupAssignee();
        else
            return getLookUpErrorMessage();
    }

    /**
     * Method to Enter Assignee
     */
    public void enterAssignee(String userName) {
        commonMethods.waitForElement(driver, newAssignees_query);
        $(newAssignees_query).clear();
        $(newAssignees_query).sendKeys(userName + Keys.ENTER);
    }

    /**
     * Method to click on Lookup Trash Icon
     */
    public void clickLookupTrash(String lookUpUser) {
        By lookupTrash = By.xpath("//div[contains(text(),'" + lookUpUser + "')]//..//..//a//div[@class='auiIcon trash']");
        commonMethods.waitForElement(driver, lookupTrash);
        $(lookupTrash).click();
    }

    /**
     * Method to verify the Assignee
     */
    public boolean verifyAssignee(String lookUpUser) {
        By assigneeLookUp = By.xpath("//table[@id='newAssignees_container']//*[contains(text(),'" + lookUpUser + "')]");
        commonMethods.waitForElement(driver, assigneeLookUp);
        return $(assigneeLookUp).isDisplayed();
    }

    /**
     * Method to get the Lookup Assignee
     */
    public String getLookupAssignee() {
        commonMethods.waitForElement(driver, assigneeLookUp);
        return $(assigneeLookUp).getText();
    }

    /**
     * Method to select doc based on the document no
     */
    public void selectDocOnPagination(String documentNo) {
        getElementInView(searchQuery);
        $(loadingIcon).should(disappear);
        boolean flag = verifyDocPresent(documentNo);
        if (flag == false) {
            clickOnPagination("next");
        }
        selectDoc(documentNo);
        getElementInView(searchQuery);
    }

    /**
     * Method to verify whether the document is present
     */
    public boolean verifyDocPresent(String docNo) {
        try {
            $(By.xpath("//div[text()='" + docNo + "']//..//..//td//input[@type='checkbox']")).isDisplayed();
            WebElement documentCheckBox = driver.findElement(By.xpath("//div[text()='" + docNo + "']//..//..//td//input[@type='checkbox']"));
            WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.visibilityOf(documentCheckBox));
            wait.until(ExpectedConditions.elementToBeClickable(documentCheckBox));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Method to click on first page on search result
     */
    public void clickOnFirstSearchResultsPage() {
        commonMethods.waitForElementExplicitly(4000);
        if ($(firstPageOnSearch).isDisplayed())
            $(firstPageOnSearch).click();
    }

    /**
     * Method to verify the Assigned To on Document
     */
    public boolean verifyAssignedToOnDoc(String docNo, String AssignedTo) {
        By assignedTo = By.xpath("//div[@id='validDocList']//td[text()='" + docNo + "']//..//td[contains(text(),'" + AssignedTo + "')]");
        commonMethods.waitForElement(driver, assignedTo);
        return $(assignedTo).isDisplayed();
    }

    /**
     * Method to Document No in the First result
     */
    public String getDocNoOnFirstResult() {
        commonMethods.waitForElement(driver, firstDocumentOnResult);
        return $(firstDocumentOnResult).getText();
    }

    /**
     * Method to click View Details on Delegate Dialog box
     */
    public void clickViewDetailsOnDelegate() {
        commonMethods.waitForElement(driver, viewDetailsText);
        $(viewDetailsDelegate).click();
    }

    /**
     * Method to verify the Exclude document message is displayed
     */
    public boolean verifyExcludeDocMsg() {
        commonMethods.waitForElement(driver, viewDetailsDelegate);
        return $(excludeDocListMessage).isDisplayed();
    }

    /**
     * Method to edit comments out section
     */
    public boolean verifyExcludeDocSubmittedMsg() {
        commonMethods.waitForElement(driver, viewDetailsDelegate);
        return $(excludeDocListSubmissionMsg).isDisplayed();
    }

    /**
     * Method to verify the success on Delegate Msg
     */
    public boolean verifySuccessDelegateMsg() {
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, delegateSelectedSupplierDoc);
        return $(successMsgOnDelegate).isDisplayed();
    }

    /**
     * Method to edit comments out section
     */
    public String editEnterCommentsOut() {
        String comments = "Verify Save and Continue on the SD Review " + faker.number().digits(4);
        enterComments(commentsOut, comments);
        return comments;
    }

    /**
     * Method to click on Show Submission History
     */
    public void clickShowSubmissionHistory() {
        commonMethods.waitForElement(driver, viewSubmissionHistory);
        $(viewSubmissionHistory).click();
        commonMethods.waitForElement(driver, supplierDocSubmissionHistoryHeader, 60);
    }

    /**
     * Method to verify submission history on supplier based on the attribute
     */
    public boolean verifySubmissionHistoryOnSupplier(String attribute) {
        commonMethods.waitForElementExplicitly(2000);
        return $(By.xpath("//*[@id='submissionHistory_body']//td[text()='" + attribute + "']")).isDisplayed();
    }

    /**
     * Method to click progress summary section for the instance
     */
    public void clickAccessDocumentsMenu() {
        commonMethods.waitForElement(driver, accessDocumentsMenu);
        $(accessDocumentsMenu).click();
    }

    /**
     * Method to click supersede button and wait for the loading of the document
     */
    public void clickSupersedeDoc() {
        commonMethods.waitForElement(driver, supersedeDocOption);
        $(supersedeDocOption).click();
        $(loadingIcon).should(disappear);
        commonMethods.waitForElementExplicitly(5000);
    }

    /**
     * Method to click supersede button on Doc Option
     */
    public void clickSupersede() {
        commonMethods.waitForElement(driver, supersedeDocOption);
        $(supersedeDocOption).click();
    }

    /**
     * Method to click progress summary section for the instance
     */
    public void clickLinkProgress(String progressSummary) {
        By linkProgress = By.xpath("//*[@id='progressSummary']//*[contains(text(),'" + progressSummary + "')]");
        getElementInView(progressSummaryText);
        commonMethods.waitForElement(driver, linkProgress);
        $(linkProgress).click();
    }

    /**
     * Method to get submission screen in Autofilled data
     */
    public String getSubmissionAutoFill() {
        commonMethods.waitForElement(driver, submissionStatusBidi);
        return $(submissionStatusBidi).getText();
    }

    /**
     * Method to get packageNo on prefill
     */
    public String getPackageNoPreFill() {
        commonMethods.waitForElement(driver, packageNumberOnBidi);
        return $(packageNumberOnBidi).getText();
    }

    /**
     * Method to get percentage onprogress
     */
    public String getPercentageOnProgress(String progressSummary) {
        if (progressSummary.equalsIgnoreCase("Canceled"))
            progressSummary = "CANCELLED";
        if (progressSummary.contains(" "))
            progressSummary = progressSummary.replace(" ", "_");

        By linkProgress = By.xpath("//tr[@class='" + progressSummary.toUpperCase() + "']//td[3]");
        commonMethods.waitForElement(driver, linkProgress);
        return $(linkProgress).getText();
    }

    /**
     * Method to search using Document No on the SD search screen
     */
    public void searchDocumentNo(String docNum) {
        commonMethods.waitForElement(driver, inputDocNo);
        $(inputDocNo).clear();
        $(inputDocNo).sendKeys(docNum);
        getElementInView(searchQuery);
        clickSearchBtn();
    }

    /**
     * Method to select Document No on results
     */
    public void selectDocOnResults(String docNo) {
        By docSelect = By.xpath("//div[@id='searchResultsContainer']//*[contains(text(),'" + docNo + "')]//..//..//input[@type='checkbox']");
        commonMethods.waitForElement(driver, docSelect);
        $(docSelect).setSelected(true);
    }

    /**
     * Method to click close button on submission dialog box
     */
    public void clickCloseBtnOnSubmissionDialog() {
        commonMethods.waitForElement(driver, closeBtnOnSubmissionDialog);
        $(closeBtnOnSubmissionDialog).click();
    }

    /**
     * Method to select the value of submission status filer
     */
    public void selectReviewStatus(String value) {
        commonMethods.waitForElement(driver, reviewStatusMultiSelect);
        getElementInView(disciplineDropDown);
        $(reviewStatusMultiSelect).click();
        commonMethods.waitForElement(driver, reviewStatusInput, 40);
        $(reviewStatusInput).sendKeys(value);
        By columnElement = By.xpath("//select[@id='bidi_reviewstatus_AVAIL']//option[text()='" + value + "']");
//        By columnElement=By.xpath("//select[@id='bidi_submissionStatuses_AVAIL']//option[text()='"+value+"']");
        getElementInView(columnElement);
        $(columnElement).doubleClick();
        $(reviewStatusOk).click();
        clickSearchBtn();
    }

    /**
     * Method to verify the Search columns with the row values provided
     */
    public boolean verifyReviewStatusSearch(String columnName, String value) {
        boolean executionFlag = false;
        By columnHeader = By.xpath("//table[@class='dataTable']//thead//tr[1]//th[contains(text(),'" + columnName + "')]");
        commonMethods.waitForElement(driver, columnHeader);
        commonMethods.waitForElementExplicitly(3000);
        for (int rowIterator = 1; rowIterator <= $$(tableResults).size(); rowIterator++) {
            if (value.equalsIgnoreCase("None")) {
                Assert.assertEquals(columnName, $(By.xpath("//table[@class='dataTable']//thead//tr[1]//th[8]")).getText());
                String reviewValue = $(By.xpath("(//tr[contains(@class,'dataRow ')])[" + rowIterator + "]//td[8]")).getText();
                Assert.assertTrue(reviewValue.length() == 0);
            } else
                Assert.assertTrue($(By.xpath("(//tr[contains(@class,'dataRow ')])[" + rowIterator + "]//td//a[contains(text(),'" + value + "')]")).isDisplayed());
            executionFlag = true;
        }
        return executionFlag;
    }

    /**
     * Method to sort column based on Column Name
     */
    public void sortColumn(String columnName) {
        By column = By.xpath("//th[@class='sortable' and contains(text(),'" + columnName + "')]");
        commonMethods.waitForElement(driver, column);
        $(column).click();
        commonMethods.waitForElement(driver, closeButtonOnSort);
        $(closeButtonOnSort).click();
        commonMethods.waitForElementExplicitly(4000);
    }

    /**
     * Method to verify the sort based on submission status
     */
    public boolean verifySortOnSubmissionStatus(List<String> orderValue, String instance) {
        boolean flag = false;
        for (int iterator = 0; iterator < $$(By.xpath("//tr[contains(@class,'dataRow')]")).size(); iterator++) {
            int iterate = iterator + 1;
            if (instance.equalsIgnoreCase("Submission Status"))
                Assert.assertEquals(orderValue.get(iterator), $(By.xpath("//tr[contains(@class,'dataRow')][" + iterate + "]//td[7]")).getText());
            else {
                if (orderValue.get(iterator).equalsIgnoreCase("None"))
                    Assert.assertTrue($(By.xpath("//tr[contains(@class,'dataRow')][" + iterate + "]//td[8]")).getText().length() < 1);
                else
                    Assert.assertEquals(orderValue.get(iterator), $(By.xpath("//tr[contains(@class,'dataRow')][" + iterate + "]//td[8]")).getText().trim());
            }
            flag = true;
        }
        return flag;
    }

    /**
     * Method to select Access Menu on Submission Required
     */
    public void selectAccessMenuOnSubmissionRequired(String docNum) {
        By accessMenu = By.xpath("//div[@id='submissionRequiredSearchResultsWrapper']//td[contains(text(),'" + docNum + "')]//..//td//img[@title='Access document options menu']");
        commonMethods.waitForElement(driver, accessMenu, 60);
        $(accessMenu).click();
    }

    /**
     * Method to select Access Menu on Submission
     */
    public void selectAccessMenuOnSubmitted(String docNum) {
        By accessMenu = By.xpath("//div[@id='submittedSearchResultsWrapper']//td//a[contains(text(),'" + docNum + "')]//..//..//td//img[@title='Access document options menu']");
        commonMethods.waitForElement(driver, accessMenu, 60);
        $(accessMenu).click();
    }

    /**
     * Method to select Access Menu on Submission
     */
    public void switchToAttachDocsFrame() {
        switchToOriginal();
        verifyAndSwitchFrame();
        verifyAndSwitchFrame("attachDocs_frame");
    }

    /**
     * close the delegate dialog box
     */
    public void clickCloseDelegateBtn() {
        $(closeDelegateBtn).click();
    }

    /**
     * Method to click Save Search As
     */
    public void clickSaveSearchAs() {
        commonMethods.waitForElement(driver, saveSearchAsBtn);
        $(saveSearchAsBtn).click();
    }

    /**
     * Method to click Cancel on save search
     */
    public void clickCancelOnSaveSearch() {
        commonMethods.waitForElement(driver, saveSearchCancelBtn);
        $(saveSearchCancelBtn).click();
    }

    /**
     * Method to verify Saved Search panel
     */
    public String verifySavedSearchPanel(String flag) {
        commonMethods.waitForElement(driver, saveSearchHeader, 20);
        Assert.assertTrue($(saveSearchName).isDisplayed());
        Assert.assertTrue($(saveSearchDescription).isDisplayed());
        if (flag.equalsIgnoreCase("enable"))
            Assert.assertTrue($(saveSearchFlagForOrg).isDisplayed());
        else
            Assert.assertFalse($(saveSearchFlagForOrg).isEnabled());
        Assert.assertTrue($(saveSearchOkBtn).isDisplayed());
        Assert.assertTrue($(saveSearchCancelBtn).isDisplayed());
        System.out.println($(saveSearchFlagForOrg).getTagName());
        return $(saveSearchHeader).getText();
    }


    /**
     * Function to delete saved search if present
     */
    public boolean deleteSavedSearchIfPresent(String attribute) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, savedSearchDropDown, 30);
        $(savedSearchDropDown).click();
        Map<String, String> table = dataStore.getTable(attribute);
        if ($(By.xpath("//select[@id='savedsearches']//option[contains(text(),'" + table.get("Name") + "')]")).isDisplayed()) {
            clickManageSavedSearch();
            deleteSavedSearch(table.get("Name"));
            return true;
        } else
            return false;
    }

    public void clickManageSavedSearch() {
        commonMethods.waitForElement(driver, manageSavedSearch);
        $(manageSavedSearch).click();
    }

    public void deleteSavedSearch(String searchName) {
        $(savedSearchManageDrpDown).selectOptionContainingText(searchName);
        clickDeleteSavedSearch();
        commonMethods.waitForElementExplicitly(2000);
        acceptAlert();
        commonMethods.waitForElementExplicitly(2000);
        $(closeSaveSearchPanel).click();
    }

    public void clickDeleteSavedSearch() {
        commonMethods.waitForElement(driver, deleteSavedSearchLink);
        $(deleteSavedSearchLink).click();
    }

    /**
     * Function to save a search
     *
     * @param attribute
     */
    public void enterAndSaveSearch(String attribute) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, saveSearchName, 30);
        Map<String, String> table = dataStore.getTable(attribute);
        for (String tableData : table.keySet()) {
            switch (tableData) {
                case "Name":
                    $(saveSearchName).clear();
                    $(saveSearchName).setValue(table.get(tableData));
                    break;
                case "Description":
                    $(saveSearchDescription).clear();
                    $(saveSearchDescription).setValue(table.get(tableData));
                    break;
                case "Share":
                    $(saveSearchFlagForOrg).setSelected(Boolean.parseBoolean(table.get(tableData)));
                    break;
            }
        }
    }

    /**
     * Function to click save button
     */
    public void clickSaveSearchOkBtn() {
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, saveSearchName, 20);
        $(saveSearchOkBtn).click();
    }

    public void enterSaveSearchName(String attribute) {
        Map<String, String> table = dataStore.getTable(attribute);
        $(saveSearchName).clear();
        $(saveSearchName).setValue(table.get("Name"));
    }

    /**
     * Function to verify saved search on supplier doc is present
     *
     * @param name
     */
    public boolean verifySdSavedSearch(String name) {
        commonMethods.waitForElementExplicitly(2000);
        verifyAndSwitchFrame();
        return $(By.xpath("//select[@id='savedsearches']//option[contains(text(),'" + name + "')]")).isDisplayed();
    }

    /**
     * Function to verify saved search on supplier doc is present
     *
     * @param name
     */
    public boolean verifySdSavedSearchSplChar(String name) {
        commonMethods.waitForElementExplicitly(2000);
        verifyAndSwitchFrame();
        return $(By.xpath("//select[@id='savedsearches']//option[contains(.,'\"" + name + "\">')]")).isDisplayed();
    }

    /**
     * Function to click saved search dropdown option
     */
    public void clickSavedSearchDropDown() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, savedSearchDropDown, 20);
        $(savedSearchDropDown).click();
    }

    /**
     * Function to verify the Mandatory SavedSearch Name
     */
    public void verifyMandtorySaveSearchName(String errorMsg) {
        Assert.assertEquals($(saveSearchName).getAttribute("class"), "medium   isRequired");
        clickSaveSearchOkBtn();
        commonMethods.waitForElementExplicitly(2000);
        Assert.assertEquals(errorMsg, getAlertText());
        acceptAlert();
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Function to verify the Max Length on Saved Search Name
     */
    public void verifyMaxLengthOnSaveSearchName(String value) {
        commonMethods.waitForElement(driver, saveSearchName);
        Assert.assertEquals(value, $(saveSearchName).getAttribute("maxlength"));
    }

    /**
     * Function to navigate saved search from dropdown
     *
     * @param name
     */
    public void navigateToSavedSearch(String name) {
        By savedSearchName = By.xpath("//select[@id='savedsearches']//option[contains(text(),'" + name + "')]");
        commonMethods.waitForElement(driver, savedSearchName);
        $(savedSearchName).click();
        commonMethods.waitForElementExplicitly(4000);
    }


    /**
     * Function to select existing saved search
     *
     * @param existingSearch to be edited
     */
    public void selectExistingSavedSearch(String existingSearch) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, savedSearchManageDrpDown, 30);
        $(savedSearchManageDrpDown).selectOptionContainingText(existingSearch);
    }

    /**
     * Function to save a search
     *
     * @param attribute
     */
    public void verifyExistingSearch(String attribute) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, saveSearchName, 30);
        Map<String, String> table = dataStore.getTable(attribute);
        for (String tableData : table.keySet()) {
            switch (tableData) {
                case "Name":
                    Assert.assertEquals(table.get(tableData), $(saveSearchName).getValue());
                    break;
                case "Description":
                    Assert.assertEquals(table.get(tableData), $(saveSearchDescription).getValue());
                    break;
                case "Share":
                    Assert.assertEquals(Boolean.parseBoolean(table.get(tableData)), $(saveSearchFlagForOrg).isSelected());
                    break;
            }
        }
    }

    /**
     * Function to verify Publisher Name
     */
    public String verifyPublisherName() {
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, publisherName, 40);
        return $(publisherName).text();
    }


    /**
     * Function to verify saved search under user saved search
     *
     * @param name
     */
    public boolean verifyMySavedSearch(String name) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(3000);
        return $(By.xpath("//select[@id='savedsearches']//optgroup[@id='savedsearchesgroup']//option[contains(text(),'" + name + "')]")).isDisplayed();
    }

    /**
     * Function to verify saved search under organisation saved search
     *
     * @param name
     */
    public boolean verifyOrganisationSavedSearch(String name) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(3000);
        return $(By.xpath("//select[@id='savedsearches']//optgroup[@id='savedsearchessharedgroup']//option[contains(text(),'" + name + "')]")).isDisplayed();
    }

    /**
     * Function to verify saved search header
     *
     * @param headerText
     */
    public void verifySavedSearchHeader(String headerText) {
        commonMethods.waitForElement(driver, savedSearchHeader, 40);
        Assert.assertEquals(headerText, $(savedSearchHeader).getText());
    }

    /**
     * Function to verify Search Default Header
     */
    public void verifySearchHeader() {
        commonMethods.waitForElement(driver, header, 40);
        Assert.assertEquals($(header).getText().trim(), searchHeader);
    }
}

