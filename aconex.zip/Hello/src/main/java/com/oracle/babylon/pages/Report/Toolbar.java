package com.oracle.babylon.pages.Report;

import com.oracle.babylon.Utils.helper.Navigator;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;

import java.util.List;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;

/**
 * Page object class for tool bar options.
 *
 */
public class Toolbar extends Navigator {

    private String layoutSelectionId = "layout-selection";
    private String exportDropdownId = "export";
    private String saveAsDropDown = "fileOptions";
    private By loader = By.cssSelector(".auiLoaderOverlay-loader");

    /**
     * Method to select BIP layout.
     *
     * @param layoutName Name of the layout.
     */
    public void selectBIPLayout(String layoutName){
        new MenuDropDown(layoutSelectionId).selectItem(layoutName);
        waitForLoaderToDisappear();
    }

    /**
     * Method to select 'Save as' option.
     *
     */
    public void saveAs(){
        new MenuDropDown(saveAsDropDown).selectItem("Save As");
    }

    /**
     * Method to select 'Save' option.
     *
     */
    public void save(){
        new MenuDropDown(saveAsDropDown).selectItem("Save");
    }

    /**
     * Method to wait untill page loader disappears.
     *
     */
    public void waitForLoaderToDisappear(){
        try {
            commonMethods.waitForElement(driver, loader, 13);
            $(loader).waitUntil(hidden, 50000);
        } catch(TimeoutException | NoSuchElementException e){
            //ignore
        }
    }

    /**
     * Method to select output format for the report.
     *
     * @param format Name of the output format.
     */
    public void selectExportFormat(String format){
        new MenuDropDown(exportDropdownId).selectItem(format);
        try {
            commonMethods.waitForElement(driver, loader, 10);
            $(loader).waitUntil(disappear, 30000);
        } catch(TimeoutException ex){
            //page loader has not been displayed.Hence ignoring the exception.
        }
    }

    /**
     * Method to gete list of available options under save as drop down.
     *
     */
    public List<String> getAvailableOptionsUnderSaveAs(){
        return new MenuDropDown(saveAsDropDown).getAvailableOptions();
    }
}