package com.oracle.babylon.pages.Mail;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;

import java.util.Map;

import static com.codeborne.selenide.Selenide.$;

public class AdvancedSearchPage extends MailPage {

    private By searchBtn = By.xpath("//div[@class='auiModal-dialog large']//button[text()='Search']");
    private By valuesPlus = By.xpath("//div[@class='filters-container ng-scope']//span[@class='additional-pills-text ng-binding ng-scope']");

    /**
     * Function to select Advance search values
     *
     * @param data
     */
    public void selectAdvancedSearchValue(String data) {
        Map<String, String> table = dataStore.getTable(data);
        for (String key : table.keySet()) {
            String[] namesList = table.get(key).split(",");
            for (String name : namesList) {
                selectValue(key, name);
            }
        }
        driver.switchTo().defaultContent();
    }

    /**
     * Function to click on search button for Advance search
     */
    public void clickOnSearch() {
        verifyAndSwitchFrame();
        $(searchBtn).click();
    }

    /**
     * Function to verify + after values exceeds space
     *
     * @return
     */
    public Boolean verifyValueExceedsSpace() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, valuesPlus);
        return $(valuesPlus).isDisplayed();
    }

    /**
     * Function to verify auto text after selecting  value
     *
     * @param column
     * @param value
     * @return
     */
    public Boolean verifyAutoTextForSelectedColumn(String column, String value) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        return $(By.xpath("//div[text()='" + column + "']//../..//span[text()='" + value + "']")).isDisplayed();
    }

    /**
     * Function to select advance search column values
     *
     * @param header
     * @param value
     */
    public void selectValue(String header, String value) {
        String xpath = "//div[@class='auiModal-dialog large']//div[text()='" + header + "']//..//..";
        String multiSelectXpath = xpath + "//div[contains(@class,'selectize-input items')]";
        String txtFieldXpath = xpath + "//input";
        String sltFieldXpath = xpath + "//select";
        commonMethods.waitForElementExplicitly(2000);
        switch (header) {
            case "Type":
            case "Status":
            case "Reason for Issue":
            case "Attribute 1":
            case "Attribute 2":
            case "Attribute 3":
            case "Attribute 4":
                $(By.xpath(multiSelectXpath)).click();
                $(By.xpath(multiSelectXpath + "/../../../div//input")).clear();
                $(By.xpath(multiSelectXpath + "/../../../div//input")).sendKeys(value);
                commonMethods.waitForElementExplicitly(1000);
                $(By.xpath("//div[contains(text(),'" + value + "')]")).click();
                break;
            case "Date":
            case "Closed Out Date":
            case "Due":
                $(By.xpath(txtFieldXpath)).click();
                $(By.xpath("//div[@class='dropdown-menu']//li[contains(text(),'" + value + "')]")).click();
                break;
            case "Recipients":
            case "From":
            case "Closed Out By User":
                if (value.startsWith("user")) value = commonMethods.getUserData(value, "name");
                $(By.xpath(txtFieldXpath)).sendKeys(value);
                break;
            case "To Organization":
            case "From Organization":
            case "Closed Out By Org":
                if (value.startsWith("user")) value = commonMethods.getUserData(value, "organisation");
                $(By.xpath(txtFieldXpath)).sendKeys(value);
                break;
            case "Mail No":
            case "Reference Number":
                if (value.startsWith("mail")) value = commonMethods.getMailNumFromJson(value);
                $(By.xpath(txtFieldXpath)).sendKeys(value);
                break;
            case "Subject":
            case "Comments":
                $(By.xpath(txtFieldXpath)).sendKeys(value);
                break;
            case "Confidential":
                $(By.xpath(sltFieldXpath)).click();
                $(By.xpath("//div[contains(text(),'" + value + "')]")).click();
                break;
            default:
                if (header.startsWith("label_")) fillProjectFields(header, value);
        }
    }

    /**
     * Function to fill project field or restricted fields
     *
     * @param fieldName
     * @param value
     */
    public void fillProjectFields(String fieldName, String value) {
        String xpath = "//div[@class='auiModal-dialog large']//div[contains(text(),'" + commonMethods.getLabelName(fieldName) + "')]//..//..";
        String multiSelectXpath = xpath + "//div[contains(@class,'selectize-input items')]";
        String txtFieldXpath = xpath + "//input";
        String sltFieldXpath = xpath + "//select";
        String fieldType = commonMethods.getLabelType(fieldName);
        switch (fieldType) {
            case "Yes/No":
                commonMethods.enterDropdownValue(By.xpath(sltFieldXpath), value);
                break;
            case "Select List (Single)":
                $(By.xpath(multiSelectXpath)).click();
                $(By.xpath("//div[contains(text(),'" + value + "')]")).click();
                break;
            case "Date":
                $(By.xpath(txtFieldXpath)).click();
                $(By.xpath("//div[@class='dropdown-menu']//li[contains(text(),'" + value + "')]")).click();
                break;
            case "Text":
            case "Text Area":
            case "Number":
                $(By.xpath(txtFieldXpath)).sendKeys(value);
                break;
            case "Select List (Multiple)":
                if (value.contains("user"))
                    $(By.xpath(txtFieldXpath)).sendKeys(commonMethods.getUserData(value, "name") + " - " + commonMethods.getUserData(value, "organisation"));
                else {
                    $(By.xpath(multiSelectXpath)).click();
                    $(By.xpath("//div[contains(text(),'" + value + "')]")).click();
                }
                break;
        }
    }
}
