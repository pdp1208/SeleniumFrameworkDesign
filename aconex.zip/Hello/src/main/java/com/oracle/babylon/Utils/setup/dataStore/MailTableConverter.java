package com.oracle.babylon.Utils.setup.dataStore;

import com.github.javafaker.Faker;
import com.oracle.babylon.Utils.helper.CommonMethods;
import com.oracle.babylon.Utils.setup.FakeData;
import com.oracle.babylon.Utils.setup.dataStore.pojo.Mail;
import io.cucumber.datatable.DataTable;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Class to convert the data tables from the test files to data store tables for a document
 * Author : sai
 */
public class MailTableConverter {
    private Mail mail;
    private CommonMethods commonMethods = new CommonMethods();
    private Faker faker = new Faker();

    public Map<String, Mail> createMailData(String userIdentifier, DataTable dataTable, String projectId) {
        Map<String, Mail> data = new LinkedHashMap<>();

        //Object Initialization
        for (Map<Object, Object> mailHashMap : dataTable.asMaps(String.class, String.class)) {
            mail = new Mail();

            FakeData fakeData = new FakeData();
            Date date = new Date();
            //Fetching data
            String companyName = fakeData.getCompanyName();
            //fieldReflection(mailHashMap);
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'.0Z'");
            //Assigning values to Document Object
            if (mail.getMailNumber() == null) {
                String name = fakeData.getDocumentNumber().replace("\\", "").replace("/", "");
                mail.setMailNumber(name);
            }

            if (mailHashMap.containsKey("TotalAttachments"))
                mail.setTotalAttachments(mailHashMap.get("TotalAttachments").toString());

            mail.setMailTypeId(mailHashMap.get("MailType").toString());

            if (mail.getMailSubject() == null && !mailHashMap.containsKey("Subject"))
                mail.setMailSubject(companyName + " Doc");
            else mail.setMailSubject(mailHashMap.get("Subject").toString());

            if (mailHashMap.containsKey("ResponseRequired"))
                mail.setResponseRequired(mailHashMap.get("ResponseRequired").toString());

            if (mailHashMap.containsKey("ResponseRequiredDate"))
                mail.setResponseRequiredDate(dateFormat.format(commonMethods.getDate(mailHashMap.get("ResponseRequired").toString())));

            if (mailHashMap.containsKey("Attribute 1"))
                mail.setAttribute1(mailHashMap.get("Attribute 1").toString());

            if (mailHashMap.containsKey("Attribute 2"))
                mail.setAttribute2(mailHashMap.get("Attribute 2").toString());

            if (mailHashMap.containsKey("RichMailText"))
                mail.setRichMailText(mailHashMap.get("RichMailText").toString());

            if (mailHashMap.containsKey("RichMailText"))
                mail.setRichMailText(mailHashMap.get("RichMailText").toString());

            mail.setMailBody(faker.book().title());

            data.put("mail" + mailHashMap.get("serial_num"), mail);
        }
        return data;
    }

}
