package com.oracle.babylon.pages.Setup.ProjectSettings;

import com.codeborne.selenide.ex.ElementNotFound;
import com.oracle.babylon.pages.Setup.ProjectSettingsPage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Selenide.$;

public class MailDocumentsRoleSettings extends ProjectSettingsPage {
    protected By mailDocRoleSettingMenu = By.xpath("//div[contains(text(),'Mail/Documents Role Settings')]");
    private By showAllOption = By.cssSelector("#SHOW_ALL");
    private By cancelRole = By.xpath("//button[@id='btnrolePanel_cancel']//div[@class='uiButton-label'][contains(text(),'Cancel')]");
    private By defaultRole = By.xpath("//input[@id='ROLE_IS_DEFAULT']");
    private By roleName = By.xpath("//input[@id='ROLE_NAME']");

    private By createRoleBtn = By.xpath("//button[@id='btnNewProjectRole']");
    private By corrTypeAddBtn = By.xpath("//button[@id='btnSELECTED_CORR_TYPES_ADD']//div[@class='uiButton-label'][contains(text(),'>>')]");
    private By docTypeAddBtn = By.xpath("//button[@id='btnSELECTED_DOC_TYPES_ADD']//div[@class='uiButton-label'][contains(text(),'>>')]");
    private By docStatusAddBtn = By.xpath("//button[@id='btnSELECTED_DOC_STATUSES_ADD']//div[@class='uiButton-label'][contains(text(),'>>')]");
    private By corrTypeRemoveBtn = By.xpath("//button[@id='btnSELECTED_CORR_TYPES_REMOVE']//div[@class='uiButton-label'][contains(text(),'<<')]");
    private By docTypeRemoveBtn = By.xpath("//button[@id='btnSELECTED_DOC_TYPES_REMOVE']//div[@class='uiButton-label'][contains(text(),'<<')]");
    private By docStatusRemoveBtn = By.xpath("//button[@id='btnSELECTED_DOC_STATUSES_REMOVE']//div[@class='uiButton-label'][contains(text(),'<<')]");
    private By rssType = By.xpath("//select[@name='SELECTED_RSS_TYPES_AVAIL']//option");
    private By rssAdd = By.xpath("//button[@id='btnSELECTED_RSS_TYPES_ADD']//div//div");
    private By okBtn = By.xpath("//button[@id='btnrolePanel_ok']//div[@class='uiButton-label'][contains(text(),'OK')]");
    private By copyFromProject = By.xpath("//div[@class='uiButton-label'][contains(text(),'Copy From Project')]");
    private By selectProject = By.xpath("//select[@id='FROM_PROJECT_ID']");
    private By confirmCopyFromProject = By.xpath("//button[@id='btncopyFromProjectPanel_ok']//div[@class='uiButton-label'][contains(text(),'OK')]");
    private By resultTable = By.xpath("//table[@class='blank']");
    private By saveBtn = By.xpath("//td[@class='toolbar clearFloats']//button[@id='btnSave']");
    private By deleteRoleBtn = By.xpath("//button[@id='btnDeleteProjectRole']");
    private By availableMailTypes = By.xpath("//select[@name='SELECTED_CORR_TYPES_AVAIL']//option");
    private By saveButton = By.xpath("//div[contains(text(),'Save')]");
    private By searchAvailableMailTypes = By.xpath("//input[@id='SELECTED_CORR_TYPES_regexp']");
    private By deleteDefaultRole = By.xpath("//div[@id='rolePanel_body']//table[@class='formTable']//tr[2]/td[2]/input[@class ='checkbox']");
    private By tabMailTypes = By.xpath("//li[@id='CORR_TYPES']");
    private By tabDocTypes = By.xpath("//li[@id='DOC_TYPES']");
    private By tabDocStatus = By.xpath("//li[@id='DOC_STATUSES']");
    private By tabReviewStatus = By.xpath("//li[@id='RSS_TYPES']");

    /**
     * method to navigate and verify project settings page
     */

    public void navigateAndVerifyPage() {
        refresh();
        getMenuSubmenu("Setup", "Project Settings");
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, mailDocRoleSettingMenu);
        $(mailDocRoleSettingMenu).click();
//        verifyPageTitle("Project Settings");
    }

    /**
     * Method to click on create Role button
     */

    public void createNewRole() {
        switchProjectSettingsFrame();
        $(createRole).click();
    }

    /**
     * Function to click on show All checkbox
     *
     * @return value
     */

    public void clickShowAllCheckBox(boolean value) {
        $(showAllOption).setSelected(value);
    }

    public void closeCreateRolePanel() {
        switchProjectSettingsFrame();
        $(cancelRole).click();
    }

    /**
     * Method to select different tabs in Roles tab
     */
    public void selectTab(String tab) {
        switchProjectSettingsFrame();
        switch (tab) {
            case "Mail Types":
                $(tabMailTypes).click();
                break;
            case "Doc Types":
                $(tabDocTypes).click();
                break;
            case "Doc Statuses":
                $(tabDocStatus).click();
                break;
            case "Review Status Sets":
                $(tabReviewStatus).click();
                break;
        }
    }

    /**
     * Function to select available types to the selected types section
     *
     * @param type is the option to be selected
     * @tab is the tabName to be selected
     */

    public void addTypes(String tab, String type) {
        String commonPath = "//div[@class='uiBidi-left']//select//option[text() = '";
        switch (tab) {
            case "Mail Types":
                commonMethods.waitForElementExplicitly(3000);
                commonMethods.waitForElement(driver, searchAvailableMailTypes, 30);
                clickShowAllCheckBox(true);
                commonMethods.waitForElementExplicitly(500);
                $(searchAvailableMailTypes).clear();
                commonMethods.waitForElementExplicitly(500);
                $(searchAvailableMailTypes).sendKeys(type);
                commonMethods.waitForElementExplicitly(500);
                if($(By.xpath("//div[@id='CORR_TYPESDiv']" + commonPath + type + "']")).isDisplayed()) {
                    $(By.xpath("//div[@id='CORR_TYPESDiv']" + commonPath + type + "']")).click();
                    $(corrTypeAddBtn).click();
                }
                break;
            case "Doc Types":
                commonMethods.waitForElementExplicitly(3000);
                clickShowAllCheckBox(true);
                if($(By.xpath("//div[@id='DOC_TYPESDiv']" + commonPath + type + "']")).isDisplayed()) {
                    $(By.xpath("//div[@id='DOC_TYPESDiv']" + commonPath + type + "']")).click();
                    $(docTypeAddBtn).click();
                }
                break;
            case "Doc Statuses":
                if($(By.xpath("//div[@id='DOC_STATUSESDiv']" + commonPath + type + "']")).isDisplayed()) {
                    $(By.xpath("//div[@id='DOC_STATUSESDiv']" + commonPath + type + "']")).click();
                    $(docStatusAddBtn).click();
                }
                break;
            case "Review Status Sets":
                //$(rssType).click();
                $(By.xpath("//select[@name='SELECTED_RSS_TYPES_AVAIL']//option[text()='" + type + "']")).click();
                $(rssAdd).click();
        }
    }

    /**
     * Function to create a new role
     *
     * @param roleParams is the options to be selected
     * @type is the type to be selected
     * @role is the name of the role
     */

    public void createRole(String type, String role, String roleParams) {
        switchProjectSettingsFrame();
        if (verifyRole(role)) {
            deleteRole(role);
        }
        commonMethods.waitForElement(driver, createRoleBtn,20);
        $(createRoleBtn).click();
        commonMethods.waitForElement(driver, roleName, 60);
        switch (type.toLowerCase()) {
            case "default":
                $(defaultRole).click();
                break;
            case "normal":
                break;
        }
        $(roleName).sendKeys(role);
        Map<String, String> table = dataStore.getTable(roleParams);
        for (String tableData : table.keySet()) {
            String[] typeValues = table.get(tableData).split(",");
            selectTab(tableData);
            for (String typeValue : typeValues) {
                addTypes(tableData, typeValue.trim());
            }
        }
        $(okBtn).click();
    }

    public void verifyNewRoleName(String name) {
        commonMethods.waitForElementExplicitly(5000);
        Assert.assertTrue($(By.xpath("//table[@class='blank']//thead")).text().contains(name));
    }

    public void copyFromProject(String project) {
        switchProjectSettingsFrame();
        $(copyFromProject).click();
        $(selectProject).selectOptionContainingText(project);
        $(confirmCopyFromProject).click();
    }


    /**
     * Function to delete the Role created
     *
     * @param roleName
     */

    public void deleteRole(String roleName) {
        String columnIndex = Integer.toString(roleColumnIndex(roleName));
        By role = By.xpath("//table[@class='blank']//thead//tr//th[" + columnIndex + "]/a");
        if ($(role).isDisplayed()) {
            $(role).click();
            if ($(deleteDefaultRole).isSelected()) {
                $(deleteDefaultRole).click();
                driver.switchTo().alert().accept();
                commonMethods.waitForElement(driver, role, 20);
                $(role).click();
            }
            commonMethods.waitForElement(driver, deleteRoleBtn);
            $(deleteRoleBtn).click();
            if(commonMethods.isAlertPresent(driver)){
                commonMethods.acceptAlert(driver);
            }
//            verifyAlert("There organizations are assigned to this role. \n Are you sure you want to delete?");
        }

    }

    public void deselectAllOrganisation(String roleName) {
        String columnIndex = Integer.toString(roleColumnIndex(roleName));
        //table[@class='blank']//tr[4]//td[3]/input
        List<WebElement> listOfRows = driver.findElement(resultTable).findElements(By.xpath("//tr//td[1]"));
        int rowSize;
        rowSize = listOfRows.size() - 8;
        for (int i = 1; i <= rowSize; i++) {
            WebElement orgAssociation = $(By.xpath("//table[@class='blank']//tr[" + i + "]//td[" + columnIndex + "]/input"));
            if (orgAssociation.isSelected()) {
                orgAssociation.click();
            }
        }
        $(saveBtn).click();
    }

    public int roleColumnIndex(String roleName) {
        commonMethods.waitForElementExplicitly(2000);
        List<WebElement> listOfColumns = driver.findElement(resultTable).findElements(By.xpath("//thead//tr//th"));
        int column_index = 0;
        for (WebElement e : listOfColumns) {
            String actualRole = e.getText();
            column_index = column_index + 1;
            if (actualRole.contains(roleName)) { //No need for extra brackets
                break;
            }
        }
        return column_index;
    }

    /**
     * Function to get all the Mail Types selected
     *
     * @return
     */

    public List<String> getEnabledMailTypes() {
        List<String> allMailTypes = new ArrayList<>();
        commonMethods.waitForElement(driver, availableMailTypes, 35);
        List<WebElement> allTypes = driver.findElements(availableMailTypes);
        for (WebElement mailTypes : allTypes) {
            allMailTypes.add(mailTypes.getText());
        }
        return allMailTypes;
    }

    /**
     * Function to Assign Roles to the organization
     *
     * @param orgName
     * @param roleName
     */

    public void assignRoles(String orgName, String roleName) {
        By xpath = By.xpath("//td[contains(text(),'" + orgName + "')]//parent::tr//td//input[@title='" + roleName + "']");
        commonMethods.waitForElement(driver, xpath);
        if(!$(xpath).isSelected())
            $(xpath).click();
        commonMethods.waitForElement(driver, saveButton, 20);
        $(saveButton).click();
        commonMethods.waitForElementExplicitly(1500);
        if(commonMethods.isAlertPresent(driver)){
            System.out.println("Alert is present, please close it");
            acceptAlert();
        }

//        verifyAlert("Organizations' roles have been saved successfully");
    }

    /**
     * Function to verify whether the Role is present
     *
     * @param roleName
     * @return
     */

    public boolean verifyRole(String roleName) {
        try {
            By role = By.xpath("//a[contains(text(),'" + roleName + "')]");
            commonMethods.waitForElement(driver, role, 20);
            return $(role).isDisplayed();
        } catch (ElementNotFound e) {
            e.printStackTrace();
            return false;
        } catch (TimeoutException e) {
            System.out.println("Role Not Found");
            return false;
        }
    }

    /**
     * Function to update existing role
     *
     * @param tab is where we have to update mail, doc, status values
     * @type is the type to be selected
     * @role is the name of the role
     * @values is the list of values which needs to be selected or removed
     * @option is to pass 'add' for selection the value 'remove' for removing from selected list
     */

    public void updateRole(String type, String role, String tab, String values, String option) {
        switchProjectSettingsFrame();
        By roleElement = By.xpath("//a[contains(text(),'" + role + "')]");
        commonMethods.waitForElement(driver, roleElement, 20);
        commonMethods.clickOnElement(roleElement);
        commonMethods.waitForElement(driver, roleName, 60);
        switch (type.toLowerCase()) {
            case "default":
                $(defaultRole).click();
                break;
            case "normal":
                break;
        }
        String[] typeValues = values.split(",");
        selectTab(tab);
        for (String mailTypeValue : typeValues) {
            if (option.equalsIgnoreCase("add"))
                addTypes(tab, mailTypeValue.trim());
            else if (option.equalsIgnoreCase("remove"))
                removeTypes(tab, mailTypeValue.trim());
        }
        $(okBtn).click();
    }

    /**
     * Function to remove selected types from the selected types section
     *
     * @param type is the option to be removed
     * @tab is the tabName to be selected
     */

    public void removeTypes(String tab, String type) {
        String commonPath = "//div[@class='uiBidi-right']//select//option[text() = '";
        switch (tab) {
            case "Mail Types":
                if($(By.xpath("//div[@id='CORR_TYPESDiv']//div[@class='uiBidi-right']//select//option[text() = '" + type + "']")).isDisplayed()) {
                    $(By.xpath("//div[@id='CORR_TYPESDiv']//div[@class='uiBidi-right']//select//option[text() = '" + type + "']")).click();
                    $(corrTypeRemoveBtn).click();
                }
                break;
            case "Doc Types":
                if($(By.xpath("//div[@id='DOC_TYPESDiv']" + commonPath + type + "']")).isDisplayed()) {
                    $(By.xpath("//div[@id='DOC_TYPESDiv']" + commonPath + type + "']")).click();
                    $(docTypeRemoveBtn).click();
                }
                break;
            case "Doc Statuses":
                if($(By.xpath("//div[@id='DOC_STATUSESDiv']" + commonPath + type + "']")).isDisplayed()) {
                    $(By.xpath("//div[@id='DOC_STATUSESDiv']" + commonPath + type + "']")).click();
                    $(docStatusRemoveBtn).click();
                }
                break;
        }
    }

    /**
     * Function to save mail/doc settings
     */
    public void saveRoleSettings() {
        $(saveBtn).click();
    }

    /**
     * Function to unassign Roles to the organization
     *
     * @param orgName
     * @param roleName
     */
    public void unassignRoles(String orgName, String roleName) {
        By xpath = By.xpath("//td[contains(text(),'" + orgName + "')]//parent::tr//td//input[@title='" + roleName + "']");
        if($(xpath).isSelected())
            $(xpath).click();
        commonMethods.waitForElementExplicitly(1000);
        commonMethods.waitForElement(driver, saveButton, 20);
        $(saveButton).click();
        verifyAlert("Organizations' roles have been saved successfully");
    }

    /**
     * Function to edit role in mail/doc settings
     */
    public void editRole(String roleName, String tab, String docType) {
        $(By.xpath("//a[text()='" + roleName + "']")).click();
        commonMethods.waitForElementExplicitly(2000);
        selectTab(tab);
        clickShowAllCheckBox(true);
        $(By.xpath("//select[@name='SELECTED_DOC_TYPES_AVAIL']//option[text() = '" + docType.trim() + "']")).click();
        $(docTypeAddBtn).click();
        $(okBtn).click();
    }

    /**
     * Method to click on the role
     *
     * @param roleName
     */
    public void clickRole(String roleName) {
        By role = By.xpath("//a[contains(text(),'" + roleName + "')]");
        $(role).click();

    }

    /**
     * Method to return the selected doc statuses
     *
     * @return
     */
    public List<String> selectedDocStatus() {
        commonMethods.waitForElement(driver, tabDocStatus);
        $(tabDocStatus).click();
        List<String> docStatuses = new ArrayList<>();
        List<WebElement> docStatusList = driver.findElements(By.xpath("//select[@name='SELECTED_DOC_STATUSES']//option"));
        for (WebElement element : docStatusList) {
            docStatuses.add(element.getText());
        }
        return docStatuses;
    }

    /**
     * Method to return the selected mail types
     *
     * @return
     */
    public List<String> selectedMailTypes() {
        $(tabMailTypes).click();
        List<String> mailTypes = new ArrayList<>();
        List<WebElement> mailTypesList = driver.findElements(By.xpath("//select[@name='SELECTED_CORR_TYPES']//option"));
        for (WebElement element : mailTypesList) {
            mailTypes.add(element.getText());
        }
        return mailTypes;
    }

    /**
     * Method to return the selected doc types
     *
     * @return
     */
    public List<String> selectedDocTypes() {
        $(tabDocTypes).click();
        List<String> docTypes = new ArrayList<>();
        List<WebElement> docTypesList = driver.findElements(By.xpath("//select[@name='SELECTED_DOC_TYPES']//option"));
        for (WebElement element : docTypesList) {
            docTypes.add(element.getText());
        }
        return docTypes;
    }

    /**
     * Method to return the selected RSS
     *
     * @return
     */
    public List<String> selectedRSS() {
        $(tabReviewStatus).click();
        List<String> rssTypes = new ArrayList<>();
        List<WebElement> rssList = driver.findElements(By.xpath("//select[@name='SELECTED_RSS_TYPES']//option"));
        for (WebElement element : rssList) {
            rssTypes.add(element.getText());
        }
        return rssTypes;
    }

    public void verifyOrganization(String user) {
        String org = commonMethods.getUserData(user, "organisation");
        Assert.assertTrue($(By.xpath("//td[contains(text(),'"+org+"')]")).isDisplayed());
    }

    /**
     * Method to get organisation prefix
     */
    public String getOrgPrefix(String organization) {
        return $(By.xpath("//td[text()='" + organization + "']/../td[2]")).getText();
    }
}

