package com.oracle.babylon.pages.Document;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import java.io.File;
import java.util.List;

import static com.codeborne.selenide.Selenide.*;

public class UploadDocumentPage extends DocumentPage {

    private By submitBtn = By.xpath("//button[@id='btnSubmit']");
    private By docNumber = By.xpath("//input[@id='docno']");
    private By successMessage = By.xpath("//div[text()='The following documents have been moved to your register.']");
    private By pageHeader = By.xpath("//h2[text()='Upload Documents']");
    private By files = By.xpath("//div[@class='files']//li//div[@class='fileInfo ng-scope']");
    private By updateDocumentMessage = By.xpath("//span[@title='Updating existing document']");
    MultiFileUploadPage multiFileUploadPage = new MultiFileUploadPage();
    private By legacyDocSuccessMsg = By.xpath("//span[text()='Document Uploaded Successfully']");
    private By docRegLink = By.xpath("//h4[text()='View in the document register']");

    /**
     * Method to validate success message
     */
    public boolean validateSuccessMessage() {
        return $(successMessage).isDisplayed();
    }

    /**
     * Method to select second row
     */
    public void clickSecondRow() {
        List<WebElement> list = driver.findElements(files);
        list.get(1).click();
    }

    /**
     * Method to enter document number
     */
    public void enterDocFieldValue(String value) {
        $(docNumber).clear();
        $(docNumber).sendKeys(value);
    }

    /**
     * Method to return document update message
     */
    public boolean updateDocumentDisplayed() {
        commonMethods.waitForElement(driver, updateDocumentMessage);
        return $(updateDocumentMessage).isDisplayed();
    }

    /**
     * Method to verify page title
     */
    public boolean verifyPageTitle() {
        commonMethods.waitForElement(driver, pageHeader);
        return $(pageHeader).isDisplayed();
    }

    /**
     * Method to add document fields for legacy upload document based on field names, values and type passed in parameter
     *
     * @param fieldName
     * @param fieldValue
     * @param type
     */
    public void fillLegacyUploadFields(String fieldName, String fieldValue, String type) {
        verifyAndSwitchFrame();
        switch (type.toLowerCase()) {
            case "dropdown":
                By dropdownElement = By.xpath("//table[@id='docEditFieldCollection']//td/select[contains(@title,'" + fieldName + "')]");
                commonMethods.waitForElement(driver, dropdownElement, 30);
                commonMethods.enterDropdownValue(dropdownElement, fieldValue);
                break;
            case "text":
                By txtElement = By.xpath("//table[@id='docEditFieldCollection']//td//input[contains(@title,'" + fieldName + "')]");
                commonMethods.waitForElement(driver, txtElement, 30);
                commonMethods.enterTextValue(txtElement, fieldValue);
                break;
            case "date":
                updateLegacyDateField(fieldName, fieldValue);
                break;
            case "checkbox":
                updateLegacyCheckboxField(fieldName, fieldValue);
                break;
            case "file":
                $(By.xpath("//div[@class='customFileUploadField ']/input[contains(@title,'" + fieldName + "')]")).sendKeys(new File(configFileReader.getTestDataPath() + fieldValue).getAbsolutePath());
                break;
            case "selectlist":
                fillLegacySelectListField(fieldName, fieldValue);
                break;
        }
    }

    /**
     * Method to update legacy date fields in add/update document document screen
     */
    public void updateLegacyDateField(String fieldName, String dateValue) {
        By dateField = By.xpath("//table[@id='docEditFieldCollection']//td//input[@title='" + fieldName + "']");
        commonMethods.waitForElement(driver, dateField, 30);
        $(dateField).clear();
        commonMethods.waitForElementExplicitly(1000);
        if (dateValue.equalsIgnoreCase("yesterday") || dateValue.equalsIgnoreCase("today") || dateValue.equalsIgnoreCase("tomorrow")) {
            $(dateField).sendKeys(commonMethods.getDate(configFileReader.getTimeZone(), dateValue) + Keys.ENTER);
        } else {
            $(dateField).sendKeys(dateValue + Keys.ENTER);
        }
    }

    /**
     * Method to update legacy checkbox field in add/update document screen
     */
    public void updateLegacyCheckboxField(String fieldName, String fieldValue) {
        By checkboxField = By.xpath("//table[@id='docEditFieldCollection']//td//input[contains(@name,'" + fieldName.toLowerCase() + "')]");
        commonMethods.waitForElement(driver, checkboxField, 30);
        if (!Boolean.parseBoolean(fieldValue.toLowerCase()) == $(checkboxField).isSelected())
            $(checkboxField).setSelected(Boolean.parseBoolean(fieldValue.toLowerCase()));
    }

    /**
     * Method to verify success message displayed while document upload in old doc screen
     */
    public boolean verifyDocSuccessMsg() {
        return $(legacyDocSuccessMsg).isDisplayed();
    }

    /**
     * Method to click on view in Document registry link
     */
    public void clickOnDocRegistryLink() {
        commonMethods.waitForElement(driver, docRegLink, 30);
        $(docRegLink).click();
    }

}
