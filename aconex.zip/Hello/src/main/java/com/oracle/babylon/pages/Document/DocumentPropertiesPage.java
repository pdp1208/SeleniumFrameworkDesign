package com.oracle.babylon.pages.Document;


import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Selenide.*;

public class DocumentPropertiesPage extends Navigator {

    private By supersedeBtn = By.xpath("//button[text()='Update Document']");
    private By revision = By.xpath("//div[@class='tab-content']//li[contains(., 'Revision')][1]//span[1]");
    private By confidentialityStatus = By.xpath("//div[@class='tab-content']//li[contains(., 'Confidential')][1]//span[1]");
    //private By type = By.xpath("//div[@class='tab-content']//li[contains(., 'Type')][1]");
    private By addingUsersTextField = By.xpath("//div[@class='selectList ng-isolate-scope']//div[2]//input");
    private By usersAddedInAccessList = By.xpath("//ul[@class='selectedUserList']//span");
    private By eventLogLink = By.xpath("//a[contains(.,'Event Log')]");

    private By type = By.xpath("//div[@class='tab-content']//li[contains(., 'Type')][1]");
    public static String lastRevision = null;
    private By confidentialityBtn = By.xpath("//button[contains(.,'Confidentiality')]");
    private By confidentialChkBox = By.xpath("//div[@class='toggleContainer']//input[@type='checkbox']");
    private By confidentialChkBoxEmpty = By.xpath("//input[@class='auiField-input ng-valid ng-empty ng-dirty ng-valid-parse ng-touched']");
    private By confidentialityHeader = By.xpath("//h3[text()='Confidentiality']");
    private By okBtn = By.xpath("//button[contains(text(),'OK')]");
    private By searchUserField = By.xpath("//div[contains(@class,'selectize-input items')]//input");
    private By fileName = By.xpath("//div[@class='fileBox-value']//div");
    private By history = By.xpath("//div[contains(text(),'History')]");
    private By viewerErrorMsg = By.xpath("//summary[contains(text(),'This file format is not currently supported for viewing and editing.')]");
    private By openMarkUpBtn = By.xpath("//button[text()='Open Markup Mode']");
    private By latestRevision = By.xpath("//div[text()='Revision']//..//div[2]//span");
    private By title = By.xpath("//div[@class='ag-center-cols-container']//div[@col-id='title']");
    private By viewerTab = By.xpath("//a[text()='Viewer']//..");
    private By pageWidget = By.xpath("//div[@id='pageWidgetContainer1']");
    private By statusText = By.xpath("//div[text()='Status']//..//div[2]//span");
    private By disciplineText = By.xpath("//div[text()='Discipline']//..//div[2]//span");
    private By typeText = By.xpath("//div[text()='Type']//..//div[2]//span");
    private By fieldHeaders = By.xpath("//ul[@class='propertiesPanel-list']//li//div[1]");
    private By fieldValues = By.xpath("//ul[@class='propertiesPanel-list']//li//div[2]");
    private By tableSentMailData = By.xpath("//div[@acx-table='vm.sentMailEventData']//table");
    private By sentTableHeaders = By.xpath("//div[@acx-table='vm.sentMailEventData']//table//th");
    private By noFilesAssociated = By.xpath("//div[text()='No files are attached to this document']");
    private By docPropertyOption = By.xpath("//a[contains(text(),'Properties')]");

    public void verifyPage() {
        verifyPageTitle("Document Properties");
    }

    public void clickSupersedeBtn() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, docPropertyOption, 60);
        commonMethods.waitForElementClickable(driver, supersedeBtn, 30);
        $(supersedeBtn).click();
    }

    public void verifyDocumentFields(String revisionData) {
        Map<String, String> table = dataStore.getTable(revisionData);
        for (String tableData : table.keySet()) {
            switch (tableData.toLowerCase()) {
                case "revision":
                    Assert.assertTrue($(revision).text().contains(table.get(tableData)));
                    break;
                case "title":
                    Assert.assertTrue($(type).text().contains(table.get(tableData)));
                    break;
            }
        }
    }

    public String currentRevision() {
        return $(revision).text();
    }

    public void lastRevision() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, revision, 15);
        lastRevision = $(revision).text();
    }

    /**
     * Function to verify user in Access List
     *
     * @param user
     * @return
     */
    public boolean verifyUserAccessList(String user) {
        verifyAndSwitchFrame();
        By element = By.xpath("//ul[@class='selectedUserList']//span[contains(text(),'" + user + "')]");
        sleep(2000);
        return $(By.xpath("//ul[@class='selectedUserList']//span[contains(text(),'" + user + "')]")).isDisplayed();
    }

    /**
     * function to click confidentiality button
     */
    public void clickConfidentiality() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(5000);
        commonMethods.waitForElement(driver, confidentialityBtn, 35);

        Actions actions = new Actions(driver);
        actions.moveToElement($(confidentialityBtn)).click().build().perform();
    }

    /**
     * function to check confidentiality
     */
    public void checkConfidentiality(String flag) {
        verifyAndSwitchFrame();
        $(confidentialChkBox).click();
        $(confidentialChkBox).setSelected(Boolean.parseBoolean(flag));
    }

    /**
     * function to click ok button
     */
    public void clickOkBtn() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, okBtn, 15);
        $(okBtn).click();
    }

    /**
     * function to get confidential status
     */
    public String getConfidentialStatus() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, confidentialityStatus, 30);
        commonMethods.waitForElementExplicitly(2000);
        return $(confidentialityStatus).getText();
    }

    /**
     * function to check confidentiality option is disabled
     */
    public boolean verifyConfidentiality() {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(5000);
        commonMethods.waitForElement(driver, confidentialityBtn);
        return $(confidentialityBtn).isEnabled();
    }

    /**
     * function to verify confidentiality checkbox is ticked or not
     */
    public boolean verifyConfidentialityChkBox() {
        verifyAndSwitchFrame();
        return $(confidentialChkBox).isSelected();
    }

    public Boolean verifyConfidentialityHeader() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, confidentialityHeader);
        return $(confidentialityHeader).isDisplayed();
    }

    /**
     * function to remove user form access list
     */
    public void removeUserAccess(String name) {
        verifyAndSwitchFrame();
        $(By.xpath("//ul[@class='selectedUserList']//span[contains(.,'" + name + "')]/following-sibling::a")).click();
    }

    /**
     * function to make document as Confidential
     */

    public void makeDocumentConfidential() {
        commonMethods.waitForElement(driver, confidentialChkBox, 15);
        if (!($(confidentialChkBox).isSelected())) {
            commonMethods.clickOnElement(confidentialChkBox);
        }
        commonMethods.waitForElement(driver, okBtn);
        $(okBtn).click();
    }

    /**
     * function to add users in Access List
     */

    public void addUsers(String userName) {
        $(addingUsersTextField).sendKeys(userName);
        $(addingUsersTextField).sendKeys(Keys.ENTER);
        $(okBtn).click();
    }

    /**
     * Method to add user form access list
     */
    public void addUserAccess(String name) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, searchUserField, 15);
        $(searchUserField).clear();
        commonMethods.waitForElementExplicitly(1000);
        $(searchUserField).setValue(name);
        commonMethods.waitForElementExplicitly(2000);
        $(searchUserField).sendKeys(Keys.RETURN);
    }

    /**
     * Function to Add or Remove Doc Confidentiality
     */
    public void addRemoveDocumentConfidentiality(boolean value) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, confidentialityBtn, 20);
        $(confidentialityBtn).click();
        commonMethods.waitForElement(driver, confidentialChkBox, 30);
        try {
            $(confidentialChkBox).setSelected(value);
            sleep(1000);
            boolean flag = $(confidentialChkBox).isSelected();
            if (!flag == value) {
                throw new ActionDeniedException("Action Not Performed");
            }
        } catch (ActionDeniedException e) {
            try {
                $(confidentialChkBox).setSelected(value);
                sleep(1000);
                boolean flag = $(confidentialChkBox).isSelected();
                if (!flag == value) {
                    throw new ActionDeniedException("Action Not Performed");
                }
            } catch (ActionDeniedException e1) {
                $(confidentialChkBox).setSelected(value);
                boolean flag = $(confidentialChkBox).isSelected();
                if (!flag == value) {
                    System.out.println("Action Not Performed");
                    ;
                }
            }
        }
        sleep(1000);
        commonMethods.waitForElement(driver, okBtn, 5);
        $(okBtn).click();
    }

    /**
     * Function to Add List of users to Access List
     *
     * @param userList
     */
    public void addUsersAccessList(List<String> userList) {
        verifyAndSwitchFrame();
        for (String user : userList) {
            addUserAccess(user);
        }
    }

    /**
     * function to click on Event log link
     */

    public void clickOnEventLog() {
        commonMethods.waitForElement(driver, eventLogLink, 13);
        commonMethods.clickOnElement((eventLogLink));
    }

    /**
     * Method to open the mark up mode for a document
     */
    public void clickMarkUpBtn() {
        commonMethods.waitForElementExplicitly(30000);
        commonMethods.waitForElement(driver, openMarkUpBtn, 60);
//        Actions actions = new Actions(driver);
//        actions.moveToElement($(openMarkUpBtn)).click().perform();
       $(openMarkUpBtn).click();
    }

    /**
     * Method to validate the mark up mode button
     *
     * @return
     */
    public boolean validateMarkUpBtn() {
        if ($(openMarkUpBtn).getAttribute("disabled").isEmpty()) {
            return true;
        }
        return false;
    }

    /**
     * Method to validate if a file exists
     *
     * @return
     */
    public boolean validateFileExists() {
        webViewerFrame();
        commonMethods.waitForElement(driver, pageWidget, 30);
        return $(pageWidget).exists();
    }

    /**
     * Method to click on the file present
     */
    public void clickFile() {
        $(pageWidget).click();
    }

    /**
     * Method to return the latest revision of the file
     *
     * @return
     */
    public String returnLatestRevision() {
        commonMethods.waitForElement(driver, latestRevision);
        return $(latestRevision).getText();
    }

    /**
     * Method to return the latest revision of the file
     *
     * @return
     */
    public String returnStatus() {
        return $(statusText).getText();
    }

    /**
     * Method to return the discipline of the file
     *
     * @return
     */
    public String returnDiscipline() {
        return $(disciplineText).getText();
    }

    /**
     * Method to return the type of the file
     *
     * @return
     */
    public String returnType() {
        return $(typeText).getText();
    }

    /**
     * Method to return the latest revision of the file
     *
     * @return
     */
    public String returnTitle() {
        return $(title).getText();
    }

    /**
     * Method to validate the active tab by checking the properties
     *
     * @return
     */
    public boolean validateActiveTab() {
        verifyAndSwitchFrame();
        if ($(viewerTab).getAttribute("class").equals("active")) {
            return true;
        }
        return false;
    }

    /**
     * Method to verify elements in Document properties page
     */

    public void verifyButtons() {
        commonMethods.waitForElement(driver, backButton, 45);
        Assert.assertTrue($(backButton).isDisplayed());
        Assert.assertTrue($(supersedeBtn).isDisplayed());
        commonMethods.waitForElement(driver, eventLogLink, 45);
        Assert.assertTrue($(eventLogLink).isDisplayed());
    }

    /**
     * Method to verify tabs in Document properties page
     */

    public void verifyTabs(List<String> data) {
        for (String name : data) {
            Assert.assertTrue($(By.xpath("//a[contains(text(),'" + name + "')]")).isDisplayed());
        }
    }

    /**
     * Method to click Back Button
     */

    public void clickBackButton() {
        commonMethods.waitForElement(driver, backButton, 40);
        verifyAndSwitchFrame();
        $(backButton).click();

    }

    /**
     * Function to verify viewer Error Message
     *
     * @return
     */

    public boolean verifyViewerError() {
        commonMethods.waitForElement(driver, viewerErrorMsg, 60);
        return $(viewerErrorMsg).isDisplayed();
    }

    /**
     * Method to get the File name
     */

    public String getFileName() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, fileName, 45);
        return $(fileName).getText();

    }

    /**
     * Method to verify the Document Number
     *
     * @return
     */

    public boolean verifyDocument(String docNumber) {
        By element = By.xpath("//h1[contains(text(),'" + docNumber + "')]");
        commonMethods.waitForElement(driver, element, 40);
        return $(element).isDisplayed();
    }

    /**
     * Method to verify History
     *
     * @return
     */

    public boolean verifyHistory() {
        return $(history).isDisplayed();
    }

    /**
     * Method to verify Event Log Details
     *
     * @param data
     */

    public void eventLogDetails(List<String> data) {
        for (String name : data) {
            By element = By.xpath("//th[contains(text(),'" + name + "')]");
            commonMethods.waitForElement(driver, element, 40);
            Assert.assertTrue($(element).isDisplayed());
        }
    }


    /**
     * Method to return the values of field headers
     * @return
     */
    public List<String> returnColumnHeaders(){
        commonMethods.waitForElement(driver, fieldHeaders);
        List<WebElement> elements = driver.findElements(fieldHeaders);
        List<String> values = new ArrayList<>();
        for(WebElement element:elements){
            if(!element.getText().contains("Review")&&!element.getText().equalsIgnoreCase("Version"))
            values.add(element.getText());
        }

        return values;
    }

    public boolean fileAssociation(){
        return $(noFilesAssociated).isDisplayed();
    }

    /**
     * Method to switch tabs in document properties page
     */
    public void switchTab(String tabName) {
        verifyAndSwitchFrame();
        $(By.xpath("//a[text()='" + tabName + "']")).click();
    }

    /**
     * Method to verify sent tab details
     */
    public String verifySentTabDetails(String header) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, tableSentMailData, 30);
        String colId = "";
        List<WebElement> elements = new ArrayList<>($$(sentTableHeaders));
        List<String> headers = new ArrayList<>();
        for(WebElement element: elements) {
            headers.add(element.getText());
        }
        int index = headers.indexOf(header);
        return $(By.xpath("//table[@class='auiTable']/tbody//tr[1]/td[" + (index + 1) + "]")).getText();
    }

    /**
     * Method to verify document fields and values displayed in document property tab
     */
    public String verifyDocProperties(String name) {
        return $(By.xpath("//li[contains(@class,'propertiesPanel-list-item')]/div[contains(text(),'" + name + "')]/..//span")).getText();
    }

    /**
     * Method to verify document field labels are displayed in doc properties tab
     */
    public boolean verifyFields(String field) {
        return $(By.xpath("//li[contains(@class,'propertiesPanel-list-item')]/div[contains(text(),'" + field + "')]")).isDisplayed();
    }
}

class ActionDeniedException extends RuntimeException {
    ActionDeniedException(String s) {
        super(s);
    }

}




