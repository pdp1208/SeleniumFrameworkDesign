package com.oracle.babylon.Utils.helper;



public class APIConstants {


    /**
     * List of API Constants can be used for routing
     */

    public final static String api_projects="/api/projects/";
    public final static String api_trustedProjects="trusted/projects/";
    public final static String api_trustedUsers="trusted/users/";
    public final static String api_register="/register";
    public final static String api_schema="/schema";
    public final static String api_user="/api/user";
    public final static String api_directory="/directory";
    public final static String api_filterOrgName="?org_name=";
    public final static String api_FamilyName="&family_name=";
    public final static String api_projectFields="/projectfields";
    public final static String api_docType="/documenttype";
    public final static String api_document="/documents";
    public final static String api_search="/search";
    public final static String api_project="/projects/";



}
