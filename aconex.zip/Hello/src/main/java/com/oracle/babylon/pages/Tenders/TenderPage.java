package com.oracle.babylon.pages.Tenders;

import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import static com.codeborne.selenide.Selenide.$;

public class TenderPage extends Navigator {

    protected By saveToDraft = By.xpath("//button[@id='btnSaveDraftAddendum']");
    protected By rfiTab = By.xpath("//li[text()='RFIs']");
    protected By addendaTab = By.xpath("//li[text()='Addenda']");
    protected By submissionTab = By.xpath("//li[contains(text(),'Submission')]");
    protected By tendersTab = By.xpath("//div[text()='Tenders']");
    protected By pageTitle = By.xpath("//h1[contains(text(),'Tenders')]");
    private By columns = By.xpath("//thead[@class='headerColBodySync']//tr//th//div");
    private By sortableColumns = By.xpath("//thead[@class='headerColBodySync']//tr//th");
    protected By attachDropDown = By.xpath("//span[@id='btnAttach']//button[contains(@title,'Attach a File')]");
    private By attachLocalFiles = By.xpath("//li[@class='uiMenu-item']//div[contains(text(),'Local Files')]");
    protected By btnAttach = By.xpath("//button[@id='attachLocalFile-commit']");
    protected By txtBoxChooseFile = By.xpath("//div[@class='attachLocalFileRow']/input[@name='FILE_PATH_NAME']");
    protected By invitationTab = By.xpath("//li[text()='Invitation']");
    protected By actionsBtn = By.xpath("//button//div[contains(text(),'Actions')]");
    private By tenderSearchField = By.xpath("//input[@name='tenderSuperSearch']");
    private By recordsCount = By.xpath("//tr[contains(@class,'dataRow')]");
    protected By cancelBtn = By.xpath("//button//div[text()='Cancel']");
    private By cancelTenderBtn = By.xpath("//li//div[text()='Cancel Tender']");
    private By okBtn = By.xpath("//div[text()='OK']");
    protected By closingDate = By.xpath("//input[@id='closeDate_da']");
    private By closingDateLbl = By.xpath("//label[text()='Closing Date']");
    //add select index after string for time picker locator
    private String closingTimePicker = "//span[@id='closingDateTimePicker']//select[";
    protected By contactInitiator = By.xpath("//div[@id='initiatorContactLookup']//input");
    private By activeTab = By.xpath("//li[@class='active']");
    private By localFileDiv = By.xpath("//div[@id='attachLocalFile']");
    private By rfiBtn =By.xpath("//button[@title='Create Request For Information']");
    protected By sendBtn = By.xpath("//button[contains(.,'Send')]");
    protected By selectAllMenu = By.xpath("//div[@id='controlledDocsGrid']//thead//div[@id='checkboxselect']");
    private By selectAll = By.xpath("(//ul//li/div[text()='Select All'])[1]");
    private By btnZipDownload = By.xpath("//button[@title='Download attachments as a single zip file']");

    public boolean verifyPageTitle() {
        return verifyPageTitle(pageTitle);
    }

    /**
     * Method to select rfi tab
     */
    public void clickRfiTab() {
        commonMethods.waitForElementExplicitly(500);
        commonMethods.getElementInViewAndUp(rfiTab);
        $(rfiTab).click();
    }

    /**
     * Method to select Addenda tab
     */
    public void clickOnAddendaTab() {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, addendaTab);
        $(addendaTab).click();
    }


    /**
     * Method to select Submission tab
     */
    public void clickOnSubmissionTab() {
        verifyAndSwitchFrame();
        $(submissionTab).click();
    }

    /**
     * Method to select Submission tab
     */
    public void clickInvitationTab() {
        verifyAndSwitchFrame();
        $(invitationTab).click();
    }

    /**
     * Method to validate if all the tabs are present
     */
    public void tabsPresent() {
        Assert.assertTrue($(addendaTab).isDisplayed());
        Assert.assertTrue($(submissionTab).isDisplayed());
        Assert.assertTrue($(rfiTab).isDisplayed());
        Assert.assertTrue($(invitationTab).isDisplayed());
    }

    /**
     * Method to return the values of the columns present in the table
     * @return
     */
    public List<String> returnColumns() {
        List<WebElement> elements = driver.findElements(columns);
        List<String> values = new ArrayList<>();
        for (WebElement element : elements) {
            values.add(element.getText());
        }
        return values;
    }

    /**
     * Method to verify if the provided columns are sortable
     * @param data
     * @return
     */
    public boolean verifyColumnsSorting(List<String> data){
        List<WebElement> elements = driver.findElements(sortableColumns);
        for (WebElement element:elements) {
            if(data.contains(element.getText()) && !element.getAttribute("class").contains("sortable")){
                return false;
            }
        }
        return true;
    }


    /**
     * Method to click on the tender and navigate into it
     * @param tenderNumber
     */
    public void openTender(String tenderNumber){
        By by = By.xpath("//a[text()='"+ tenderNumber + "']");
        commonMethods.waitForElement(driver, by, 120);
        $(by).click();
        commonMethods.waitForElementExplicitly(1000);
    }

    /**
     * Verify if the tender is opened
     * @param tenderNumber
     * @return
     */
    public boolean verifyTenderHeader(String tenderNumber){
        By by = By.xpath("//h1[contains(text(),'"+ tenderNumber + "')]");
        return $(by).isDisplayed();
    }
    /**
     * Function to Attach a Local File to tender invitation page
     *
     * @param fileName
     */
    public void attachLocalFile(String fileName) {
        getElementInView(attachDropDown);
        commonMethods.waitForElement(driver, attachDropDown);
        $(attachDropDown).click();
        $(attachLocalFiles).click();
        commonMethods.waitForElement(driver,btnAttach,30);
        $(txtBoxChooseFile).sendKeys(new File(configFileReader.getTestDataPath() + "/" + fileName).getAbsolutePath());
        $(btnAttach).click();
        commonMethods.waitForElementExplicitly(5000);
    }

    public boolean localAttachBtnDisplayed(){
        return $(localFileDiv).isDisplayed();

    }
    /**
     * Method to search tender
     */
    public void searchTender(String tenderNum){
        verifyAndSwitchFrame();
        $(tenderSearchField).click();
        $(tenderSearchField).clear();
        $(tenderSearchField).sendKeys(tenderNum);
        System.out.println("Searching tender number--->"+tenderNum);
        clickSearch();

    }

    /**
     * Method to click on search button
     */
    public void clickSearch(){
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, searchBtn, 60);
        $(searchBtn).click();
    }

    public int recordsCount(){
        commonMethods.waitForElementExplicitly(5000);
        List<WebElement> list = driver.findElements(recordsCount);
        return list.size();
    }

    /**
     * Method to cancel the tender invitation
     */
    public void cancelTender(){
        $(actionsBtn).click();
        $(cancelTenderBtn).click();
        $(okBtn).click();
    }

    public void validateUserPresent(String fullName, String orgName){
        String searchQuery = fullName + " - " + orgName;
        By by = By.xpath("//div[text()='" + searchQuery + "']");
        Assert.assertTrue($(by).isDisplayed());
    }

    public void verifyUser(String fullName){
        String searchQuery = "No match found for " + fullName + "";
        By by = By.xpath("//div[contains(text(),'" + searchQuery + "')]");
        Assert.assertTrue($(by).isDisplayed());
    }


    /**
     * Method to enter closing date and time
     *
     * @param date as closing date
     * @param time as closing time
     */
    public void enterClosingDate(String date, String[] time) {
        //verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, closingDate);
        $(closingDate).clear();
        $(closingDate).sendKeys(date);
        $(By.xpath(closingTimePicker + "1]")).selectOptionContainingText(time[0]);
        $(By.xpath(closingTimePicker + "2]")).selectOptionContainingText(time[1]);
        $(By.xpath(closingTimePicker + "3]")).selectOptionContainingText(time[2]);
    }

    /**
     * Method to enter contact initiator
     *
     * @param name as initiator
     */
    public void enterContactInitiator(String name) {
        verifyAndSwitchFrame();

        $(contactInitiator).click();
        commonMethods.waitForElementExplicitly(2000);
        $(contactInitiator).clear();
        $(contactInitiator).sendKeys(name);
        $(contactInitiator).sendKeys(Keys.ENTER);
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Method to remove contact initiator
     *
     * @param name of contact to remove
     */
    public void removeInitiatorContact(String name) {
        verifyAndSwitchFrame();
        String contactTable = "//tr[td[contains(.,'Initiator Contact')]]//td[2]//table//tr[td[contains(.,'";
        $(By.xpath(contactTable + name + "')]]//td[2]//div[@class='auiIcon trash']")).click();
    }


    public boolean returnInitiatorDisplayed(String fullName) {
        By user = By.xpath("//td//div[contains(text(),'"+ fullName +"')][@class='lookup-assignee truncated lookup-user']");
        return $(user).isDisplayed();
    }


    public void clearInitiatorContact() {
        $(contactInitiator).clear();
    }

    public String clickedTab() {
        return $(activeTab).getText();
    }


    /**
     * Method to enter the values into the date field
     * @param date
     */
    public void enterDate(String date) {
        $(closingDate).clear();
        $(closingDate).sendKeys(date);
        $(closingDateLbl).click();
    }

    /**
     * Method to clear the closing date
     */
    public void clearClosingDate() {
        $(closingDate).clear();
    }

    /**
     * Method to verify if the submission tab is present
     * @return
     */
    public boolean submissionTabPresent() {
        return $(submissionTab).isDisplayed();
    }

    /**
     * Method to verify if recipient is added to the tender invitation
     * @param recipient
     */
    public void verifyRecipient(String recipient) {
        By by = By.xpath("//div[contains(@title,'Aconex Participant') and contains(text(),'" + recipient + "')]");
        commonMethods.waitForElement(driver, by);
        Assert.assertTrue($(by).isDisplayed());
    }


    /**
     * Method to verify if the RFI tav is pree
     * @return
     */
    public boolean returnRFITab() {
        commonMethods.waitForElement(driver, rfiTab);
        return $(rfiTab).isDisplayed();
    }

    /**
     * Method to verify if the RFI button is present
     * @return
     */
    public boolean returnRFIBtn() {
        commonMethods.waitForElementExplicitly(2500);
        return $(rfiBtn).isDisplayed();
    }

    /**
     * Method to select all attached documents
     */
    public void selectAllDocs() {
        commonMethods.waitForElement(driver, selectAllMenu, 60);
        $(selectAllMenu).click();
        $(selectAll).click();
    }

    /**
     * Method to click on Zip download button
     */
    public void clickZipDownload() {
        commonMethods.waitForElement(driver, btnZipDownload);
        $(btnZipDownload).click();
    }
}
