package com.oracle.babylon.pages.Cost;

import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import static com.codeborne.selenide.Selenide.$;

public class CostPage extends Navigator {

    private String costPath = configFileReader.getcostDataPath();

    private By costBim = By.xpath("//iframe[contains(@src,'/cost')]");
    private By costHeader = By.xpath("//li[@class='nav-header' and text()='Cost']");
    private By pageHeader = By.xpath("//h1//small");
    private By addButton = By.xpath("(//div[@class='dropdown btn-add']//a)[1]");
    private By toggleLeftPane = By.xpath("//div[@class='toggle-pane toggle-left-explorer-pane ng-animate-disabled toggle-pane-collapsed']");
    private By toggleBottomPane = By.xpath("//div[@class='toggle-pane toggle-bottom-pane toggle-pane-collapsed']");
    private By downStream = By.xpath("//a[contains(text(),'Downstream')]");
    private By submitBtn = By.xpath("//button[contains(text(),'Submit')]");
    private By auiSubmitBtn = By.xpath("//div[@class='auiModal-footer']//button[contains(text(),'Submit')]");
    //Cost WorkSheet
    private By costWorkSheet = By.xpath("//ul[@class='nav nav-list']//li//a[text()='Cost Worksheet']");
    private By addControlAccount = By.xpath("//a//span[text()='Add Control Account']");
    private By controlAccountHeader = By.xpath("//h3[text()='Add Control Account']");
    private By inputCode = By.xpath("//input[@name='code']");
    private By inputName = By.xpath("//input[@name='name']");
    private By addControlAccountButton = By.xpath("//button[contains(text(),'Add Control Account')]");
    private By searchCostWorkSheet = By.xpath("//input[@placeholder='Search Cost Worksheet']");

    private By editBaselineBudget = By.xpath("//div[contains(@class,'cell-field-details-baselineBudget')]");
    private By inputBaseLineBudget = By.xpath("//div[contains(@class,'cell-field-details-baselineBudget')]//input[@type='text']");


    //Control Element
    private By controlElements = By.xpath("//ul[@class='nav nav-list']//li//a[text()='Control Elements']");
    private By viewBtn = By.xpath("//div[@class='dropdown view-dropdown']");
    private By viewCostBtn = By.xpath("//div[contains(@class,'dropdown view-dropdown')]//a//span[text()='Cost']");
    //private By addButtonOn=By.xpath("//div[@class='dropdown btn-add']//a");
    private By controlElementHeader = By.xpath("//h3[text()='Add Control Element']");
    private By selectControlElement = By.xpath("//span[@role='combobox']");
    private By inputSearchControlElement = By.xpath("//input[@class='select2-search__field']");
    private By checkBoxGeneral = By.xpath("//div[@class='checkbox-title']//..//input[@type='checkbox']");
    private By addControlElementButton = By.xpath("//button[contains(text(),'Add Control Element')]");
    private By searchControlElements = By.xpath("//input[@placeholder='Search Control Elements']");
    private By originalBudgetAmount = By.xpath("//div[contains(@class,'controlAccountName') and text()='Test123']//..//div[contains(@class,'cell-number cell-field-details-baselineBudget')]");
    private By editOriginalBudgetAmount = By.xpath("//div[contains(@class,'controlAccountName') and text()='Test123']//..//div[contains(@class,'cell-number cell-field-details-baselineBudget')]//input");

    //Direct Actuals
    private By directActuals = By.xpath("//ul[@class='nav nav-list']//li//a[text()='Direct Actuals']");
    private By addDirectActualsHeader = By.xpath("//h3[contains(text(),'Add Direct Actuals')]");
    private By addControlElementOnActual = By.xpath("(//span[@role='combobox'])[2]");
    private By item = By.xpath("//input[@name='item']");
    private By addDirectActualButton = By.xpath("//button[contains(text(),'Add Direct Actual')]");
    private By searchDirectActuals = By.xpath("//input[@placeholder='Search Direct Actuals']");
    //Create a New Report
    private By createNewReportBtn = By.xpath("//button[contains(text(),'Create New Report')]");
    private By titleReport = By.xpath("//div[@label='Title']//input");
    private By saveAsReport = By.xpath("//button[text()='Save as New Report']");
    private By exportReport = By.xpath("//button[contains(text(),'Export')]");
    private By exportReportPDF = By.xpath("//li//a[text()='Save as PDF']");


    //Contract
    private By contracts = By.xpath("//ul[@class='nav nav-list']//li//a[text()='Contracts']");
    private By contractHeader = By.xpath("//h3[text()='Add Contract']");
    private By upStreamContract = By.xpath("//*[@name='participantAconexId']//*[@role='combobox']");
    private By controlAccountId = By.xpath("//*[@name='controlAccountId']//*[@role='combobox']");
    private By controlElementCategoryId = By.xpath("//*[@name='controlElementCategoryId']//*[@role='combobox']");
    private By partnerName = By.xpath("//input[@name='partnerName']");
    private By initialPayItemCode = By.xpath("//input[@name='initialPayItemCode']");
    private By amount = By.xpath("//input[@name='amount']");
    private By addContractButton = By.xpath("//button[contains(text(),'Add Contract')]");
    private By searchContracts = By.xpath("//input[@placeholder='Search Contracts']");
    private By txtBoxSearch = By.xpath("//form[@name='modalForm']//div[contains(@class,'search-container')]//input");
    //private By searchProgressClaim=By.xpath("//input[@placeholder='Search Progress Claim']");


    //Progress Claims
    private By progressClaims = By.xpath("//ul[@class='nav nav-list']//li//a[text()='Progress Claims']");
    private By progressClaimsHeader = By.xpath("//h3[text()='Add Progress Claim']");
    private By contractId = By.xpath("//*[@name='contractId']//*[@role='combobox']");
    private By progressClaimsButton = By.xpath("//button[contains(text(),'Add Progress Claim')]");


    //Change Events
    private By changeEvents = By.xpath("//ul[@class='nav nav-list']//li//a[text()='Change Events']");
    private By changeEventHeader = By.xpath("//h3[text()='Add Change Event']");
    private By budgetStatus = By.xpath("//*[@name='budgetStatus']//*[@role='combobox']");
    private By costStatus = By.xpath("//*[@name='costStatus']//*[@role='combobox']");
    private By nextBtn = By.xpath("//button[contains(text(),'Next')]");
    private By finishBtn = By.xpath("//button[contains(text(),'Finish')]");
    private By verify = By.xpath("//div[contains(@class,'cell-field-code') and text()='KMA']//..//..//div[contains(@class,'field-budgetStatus')]//span[contains(text(),'Active')]");


    //Change Impact Review
    private By ChangeImpactReview = By.xpath("//ul[@class='nav nav-list']//li//a[text()='Change Impact Review']");
    private By changeImpact = By.xpath("(//div[contains(@class,'cell-boolean cell-field-checked')]//span[contains(@class,'cell-toggle-editor')])[1]");
    private By actions = By.xpath("//*[@label='Actions']//button");
    private By documentNo = By.xpath("(//div[contains(@class,'cell-boolean cell-field-checked')]//span[contains(@class,'cell-toggle-editor')])[1]//..//..//div[contains(@class,'cell-field-documentNo')]");
    private By linkToExistingVariations = By.xpath("//a[contains(text(),'Link to Existing Variations')]");
    private By linkBtn = By.xpath("//button[contains(text(),'Link')]");
    private By completeStatus = By.xpath("//div[contains(@class,'cell-field-reviewStatus')]//div[contains(text(),'Complete')]");

    //Mail
    private By costSectionOnMail = By.xpath("//a//*[contains(text(),'Cost')]");
    private By actionsBtnOnMail = By.xpath("(//div[@class='auiCollapsibleSection-body']//button[contains(text(),'Actions')])[2]");
    private By linkToExistingVariationsOnMail = By.xpath("//a[contains(text(),'Link to Existing Variations')]");
    private By linkToExistingChangeEventsOnMail = By.xpath("//a[contains(text(),'Link To Existing Change Events')]");

    // PlaceHolders
    public String searchCW = "Search Cost Worksheet";
    public String searchCE = "Search Control Elements";
    public String searchDirectActual = "Search Direct Actuals";
    public String searchChange = "Search";
    public String searchChangeEvents = "Search Change Events";
    public String searchProgressClaim = "Search Progress Claim";
    public String searchChangeImpactList = "Search Change Impact List";


    public void navigateAndVerifyPage() {
        getMenuSubmenu("Cost", "Cost Management");
        commonMethods.waitForElementExplicitly(5000);
        verifyAndSwitchFrame();
        switchToFrameCost();
        commonMethods.waitForElement(driver, costHeader, 40);
    }

    public void navigateAndVerifyPage(String instance) {
        getMenuSubmenu("Cost", instance);
        commonMethods.waitForElementExplicitly(5000);
        verifyAndSwitchFrame();
        switchToFrameCost();
    }

    public void switchToFrameCost() {
        commonMethods.waitForElementExplicitly(3000);
        driver.switchTo().frame($(costBim));
    }

    public void clickSection(String linkName) {
        By activeLink = By.xpath("//ul[@class='nav nav-list']//li//a[text()='" + linkName + "']");
        commonMethods.waitForElement(driver, activeLink, 40);
        $(activeLink).click();
    }

    public String getHeader() {
        commonMethods.waitForElementExplicitly(4000);
        commonMethods.waitForElement(driver, pageHeader, 40);
        return $(pageHeader).getText();
    }

    public void clickCostWorkSheet() {
        commonMethods.waitForElement(driver, costWorkSheet);
        $(costWorkSheet).click();
    }

    public void clickDirectActuals() {
        commonMethods.waitForElement(driver, directActuals);
        $(directActuals).click();
    }

    public void clickControlElements() {
        commonMethods.waitForElement(driver, controlElements);
        $(controlElements).click();
    }

    public void clickContracts() {
        commonMethods.waitForElement(driver, contracts);
        $(contracts).click();
    }

    public void clickProgressClaims() {
        commonMethods.waitForElement(driver, progressClaims);
        $(progressClaims).click();
    }

    public void clickChangeEvents() {
        commonMethods.waitForElement(driver, changeEvents);
        $(changeEvents).click();
    }

    public void clickChangeImpactReviews() {
        commonMethods.waitForElement(driver, ChangeImpactReview);
        $(ChangeImpactReview).click();
    }

    public String addControlAccount() {
        commonMethods.waitForElementExplicitly(15000);
        commonMethods.waitForElement(driver, addButton);
        $(addButton).click();
        commonMethods.waitForElement(driver, addControlAccount);
        $(addControlAccount).click();
        commonMethods.waitForElementExplicitly(5000);
        commonMethods.waitForElement(driver, controlAccountHeader);
        String code = faker.name().firstName();
        if (code.length() > 4)
            code = code.substring(0, 4);
        $(inputCode).sendKeys(code);
        $(inputName).sendKeys(faker.name().lastName());
        /*Actions act=new Actions(driver);
        act.moveToElement($(selectControlElement)).click($(selectControlElement)).build().perform();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver,inputSearchControlElement);
        $(inputSearchControlElement).sendKeys("Cost"+ Keys.ENTER);*/
        commonMethods.waitForElementExplicitly(2000);
        $(addControlAccountButton).click();
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, searchCostWorkSheet);
        $(searchCostWorkSheet).sendKeys(code);
        By addControlAccountsAdded = By.xpath("//div[contains(@class,'slickgrid')]//*[contains(text(),'" + code + "')]");
        commonMethods.waitForElement(driver, addControlAccountsAdded);
        return code;
    }

    public void addControlElement(String code) {
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, addButton);
        $(viewBtn).click();
        commonMethods.waitForElement(driver, viewCostBtn);
        $(viewCostBtn).click();
        commonMethods.waitForElement(driver, addButton);
        $(addButton).click();
        commonMethods.waitForElement(driver, controlElementHeader);
        commonMethods.waitForElementExplicitly(3000);
        Actions act = new Actions(driver);
        act.moveToElement($(selectControlElement)).click($(selectControlElement)).build().perform();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, inputSearchControlElement);
        $(inputSearchControlElement).click();
        $(inputSearchControlElement).sendKeys(code + Keys.ENTER);
        commonMethods.waitForElementExplicitly(1000);
        $(checkBoxGeneral).setSelected(true);
        $(addControlElementButton).click();
        commonMethods.waitForElementExplicitly(4000);
        By addControlElementAdded = By.xpath("//div[contains(@class,'controlAccountCode') and text()='" + code + "']");
        searchPlaceHolderValue("Search Control Elements", code);
//        commonMethods.waitForElement(driver, addControlElementAdded);
    }

    public void writeCostCodeToJson(String codeId, String code) {
        //Write the data to the json file
        Map<String, Object> map = new Hashtable<>();
        Map<String, Map<String, Object>> mapOfMap = new HashMap<>();
        map.put("code_val", code);
        mapOfMap.put(codeId, map);
        dataSetup.fileWrite(codeId, mapOfMap, costPath);
    }

    public void writeCostContractCodeToJson(String contractCodeId, String contractCode, String key) {
        //Write the data to the json file
        Map<String, Object> map = new Hashtable<>();
        Map<String, Map<String, Object>> mapOfMap = new HashMap<>();
        map.put(key, contractCode);
        mapOfMap.put(contractCodeId, map);
        dataSetup.fileWrite(contractCodeId, mapOfMap, costPath);
    }

    public String getCostFromJSON(String codeId) {
        Map<String, Map<String, Object>> jsonData = new HashMap<>();
        Map<String, Object> map = new HashMap<>();
        jsonData = dataSetup.loadJsonDataToMap(costPath);
        map = jsonData.get(codeId);
        return map.get("code_val").toString();
    }

    public String getContractCodeFromJSON(String contractCodeId, String key) {
        Map<String, Map<String, Object>> jsonData = new HashMap<>();
        Map<String, Object> map = new HashMap<>();
        jsonData = dataSetup.loadJsonDataToMap(costPath);
        map = jsonData.get(contractCodeId);
        return map.get(key).toString();
    }

    public void togglePane() {
        commonMethods.waitForElementExplicitly(4000);
        if ($(toggleBottomPane).isDisplayed())
            $(toggleBottomPane).click();
    }

    public void updateOriginalBudget(String value) {
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, editBaselineBudget);
        $(editBaselineBudget).doubleClick();
        $(inputBaseLineBudget).clear();
        $(inputBaseLineBudget).sendKeys(value + Keys.ENTER);
        commonMethods.waitForElementExplicitly(3000);
    }

    public void searchCode(String search) {
        commonMethods.waitForElement(driver, searchCostWorkSheet);
        commonMethods.waitForElementExplicitly(4000);
        $(searchCostWorkSheet).clear();
        commonMethods.waitForElementExplicitly(3000);
        $(searchCostWorkSheet).sendKeys(search + Keys.ENTER);
    }

    public String getOriginalBudget(String code) {
        commonMethods.waitForElementExplicitly(3000);
        By getBaseLineBudgetOnCost = By.xpath("//div[contains(@class,'slickgrid')]//*[contains(text(),'" + code + "')]//..//div[contains(@class,'cell-field-cost-baselineBudget')]");
        commonMethods.waitForElement(driver, getBaseLineBudgetOnCost);
        return $(getBaseLineBudgetOnCost).getText();
    }

    public void selectEntryCode(String code) {
        By addControlAccountsAdded = By.xpath("//div[contains(@class,'slickgrid')]//*[contains(text(),'" + code + "')]");
        commonMethods.waitForElement(driver, addControlAccountsAdded);
        $(addControlAccountsAdded).click();

    }

    public String addActuals(String code) {
        By selectCode = By.xpath("//a[contains(text(),'" + code + "')]");
        if($(toggleLeftPane).isDisplayed()) {
            commonMethods.waitForElementExplicitly(1000);
            $(toggleLeftPane).click();
            commonMethods.waitForElementExplicitly(2000);
        }
        $(selectCode).click();
        commonMethods.waitForElement(driver, addButton);
        $(addButton).click();
        commonMethods.waitForElement(driver, addDirectActualsHeader);
        String actualItem = faker.name().fullName().substring(0, 4).replaceAll("[^a-zA-Z0-9]+", "");
        if (actualItem.length() > 4)
            actualItem = actualItem.substring(0, 4);
        $(item).sendKeys(actualItem);
        commonMethods.waitForElementExplicitly(2000);
        Actions act = new Actions(driver);
        act.moveToElement($(addControlElementOnActual)).click($(addControlElementOnActual)).build().perform();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, inputSearchControlElement);
        $(inputSearchControlElement).sendKeys("General" + Keys.ENTER);
        getElementInView(addDirectActualButton);
        $(addDirectActualButton).click();
        return actualItem;
    }

    public void searchActuals(String actuals) {
        commonMethods.waitForElement(driver, searchDirectActuals, 60);
        $(searchDirectActuals).sendKeys(actuals + Keys.ENTER);
        commonMethods.waitForElementExplicitly(3000);
        By actualVal = By.xpath("//div[contains(@class,'cell-grid-cell cell-field-item') and text()='" + actuals + "']");
        commonMethods.waitForElement(driver, actualVal, 40);
        Assert.assertTrue("Cost Actual is not displayed", $(actualVal).isDisplayed());
    }

    public String createNewReport() {
        commonMethods.waitForElement(driver, createNewReportBtn);
        $(createNewReportBtn).click();
        commonMethods.waitForElementExplicitly(5000);
        commonMethods.waitForElement(driver, addControlElementOnActual);
        Actions act = new Actions(driver);
        act.moveToElement($(addControlElementOnActual)).click($(addControlElementOnActual)).build().perform();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, inputSearchControlElement);
        $(inputSearchControlElement).sendKeys("Actuals" + Keys.ENTER);
        String reportName = faker.name().firstName() + " - " + faker.number().digits(3).replaceAll("[^a-zA-Z0-9]+", "");
        $(inputName).sendKeys(reportName);
        $(titleReport).sendKeys("Title Report");
        $(saveAsReport).click();
        return reportName;
    }

    public void exportReportAsPDF(String reportName) {
        commonMethods.waitForElementExplicitly(4000);
        By reportValue = By.xpath("//a[text()='" + reportName + "']");
        commonMethods.waitForElement(driver, reportValue);
        $(reportValue).click();
        commonMethods.waitForElementExplicitly(4000);
        commonMethods.waitForElement(driver, exportReport);
        $(exportReport).click();
        commonMethods.waitForElementExplicitly(4000);
        commonMethods.waitForElement(driver, exportReportPDF);
        $(exportReportPDF).click();
        commonMethods.waitForElementExplicitly(4000);
    }

    public void clickDownstream() {
        commonMethods.waitForElementExplicitly(4000);
        $(downStream).click();
    }

    public String addContracts(String user, String code) {
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, addButton);
        $(addButton).click();
        commonMethods.waitForElement(driver, contractHeader);
        commonMethods.waitForElementExplicitly(5000);
        $(inputName).sendKeys("Test");
        String codeValue = $(inputCode).getValue();
        hoverAndEnter(upStreamContract, commonMethods.getUserData(user, "name"));
        hoverAndEnter(controlAccountId, code);
        hoverAndEnter(controlElementCategoryId, "General");
        $(partnerName).sendKeys("test");
        getElementInView(initialPayItemCode);
        $(initialPayItemCode).sendKeys("Test123");
        $(amount).sendKeys("1234");
        $(addContractButton).click();
        return codeValue;
    }

    public void hoverAndEnter(By by, String value) {
        commonMethods.waitForElementExplicitly(3000);
        Actions act = new Actions(driver);
        act.moveToElement($(by)).click($(by)).build().perform();
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, inputSearchControlElement);
        $(inputSearchControlElement).sendKeys(value + Keys.ENTER);
    }

    public void approveContract(String contractNo) {
        By verifyContract = By.xpath("//*[contains(@class,'cell-field-shared-code') and contains(text(),'" + contractNo + "')]");
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, verifyContract);
        $(verifyContract).click();
        By contractStatus = By.xpath("//*[contains(@class,'cell-field-shared-code') and contains(text(),'" + contractNo + "')]//..//div[contains(@class,'cell-field-shared-status')]");
        $(contractStatus).click();
        hoverAndEnter(contractStatus, "Approved");
        commonMethods.waitForElementExplicitly(3000);
    }

    public void searchContractText(String search) {
        commonMethods.waitForElement(driver, searchContracts);
        $(searchContracts).sendKeys(search + Keys.ENTER);
    }

    public void searchPlaceHolderValue(String placeHolder, String search) {
        By searchLoc = By.xpath("//input[@placeholder='" + placeHolder + "']");
        commonMethods.waitForElement(driver, searchLoc, 30);
        $(searchLoc).sendKeys(search + Keys.ENTER);
    }

    public String addProgressClaims(String contractCode) {
        commonMethods.waitForElementExplicitly(5000);
        commonMethods.waitForElement(driver, addButton);
        $(addButton).click();
        commonMethods.waitForElement(driver, progressClaimsHeader, 40);
        hoverAndEnter(contractId, contractCode);
        commonMethods.waitForElementExplicitly(3000);
        String codeValue = faker.number().digits(5);
        $(inputCode).clear();
        $(inputCode).sendKeys(codeValue);
        commonMethods.waitForElementExplicitly(2000);
        $(inputName).sendKeys("Test");
        commonMethods.waitForElementExplicitly(3000);
        $(progressClaimsButton).click();
        return codeValue;
    }

    public void submitClaims() {
        commonMethods.waitForElement(driver, submitBtn, 60);
        $(submitBtn).click();
        commonMethods.waitForElementExplicitly(4000);
        $(auiSubmitBtn).click();
        commonMethods.waitForElementExplicitly(4000);
        $(backButton).click();
    }

    public void verifyProgressClaim(String progressClaim) {
        By progress = By.xpath("//div//a[contains(text(),'" + progressClaim + "')]//..//..//div//span[contains(text(),'Submitted')]");
        commonMethods.waitForElementExplicitly(4000);
        commonMethods.waitForElement(driver, progress);
        Assert.assertTrue("Process claim is not displayed", $(progress).isDisplayed());
    }

    public String addChangeEvents(String contractCode) {
        commonMethods.waitForElementExplicitly(4000);
        commonMethods.waitForElement(driver, addButton);
        $(addButton).click();
        commonMethods.waitForElement(driver, changeEventHeader);
        $(inputCode).clear();
        String input = faker.number().digits(4);
        $(inputCode).sendKeys(input);
        commonMethods.waitForElementExplicitly(2000);
        $(inputName).sendKeys("Test");
        $(nextBtn).click();
        searchPlaceHolderValue(searchChange, contractCode);
        By loc = By.xpath("//div[contains(@class,'field-shared-code')]//..//span[@class='cell-toggle-editor ']");
        $(loc).click();
        $(nextBtn).click();
        commonMethods.waitForElement(driver, finishBtn);
        $(finishBtn).click();
        commonMethods.waitForElementExplicitly(5000);
        searchPlaceHolderValue(searchChangeEvents, input);
        By ver = By.xpath("//div[contains(@class,'cell-field-code') and text()='" + input + "']//..//..//div[contains(@class,'field-budgetStatus')]//span[contains(text(),'Active')]");
        Assert.assertTrue("Change Event is not displayed", $(ver).isDisplayed());
        return input;
    }

    public void addChangeImpactReviews(String mailNo) {
        commonMethods.waitForElementExplicitly(4000);
        searchPlaceHolderValue(searchChangeImpactList, mailNo);
        commonMethods.waitForElement(driver, changeImpact);
        $(changeImpact).click();
        commonMethods.waitForElementExplicitly(3000);
        String docNo = $(documentNo).getText();
        commonMethods.waitForElement(driver, actions);
        $(actions).click();
        commonMethods.waitForElementExplicitly(3000);
        commonMethods.waitForElement(driver, linkToExistingVariations);
        $(linkToExistingVariations).click();
        commonMethods.waitForElementExplicitly(3000);
        searchPlaceHolderValue(searchChange, "234");
        commonMethods.waitForElementExplicitly(3000);
        $(changeImpact).click();
        $(linkBtn).click();
        commonMethods.waitForElementExplicitly(3000);
        //searchPlaceHolderValue(searchChangeImpactList,mailNo);
        commonMethods.waitForElement(driver, completeStatus, 40);
        Assert.assertTrue("Change Impact Review Status is not displayed correctly", $(completeStatus).isDisplayed());
    }

    public void setCostSectionOnMail() {
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, costSectionOnMail);
        getElementInView(costSectionOnMail);
        $(costSectionOnMail).click();
    }

    public void clickActions() {
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, actionsBtnOnMail);
        getElementInView(actionsBtnOnMail);
        $(actionsBtnOnMail).click();
    }

    public void linkToExistingChangeEvent(String changeEventVal) {
        commonMethods.waitForElement(driver, linkToExistingChangeEventsOnMail, 40);
        $(linkToExistingChangeEventsOnMail).click();
        commonMethods.waitForElementExplicitly(5000);
        switchToFrameCost();
        searchPlaceHolderValue(searchChange, changeEventVal);
        commonMethods.waitForElement(driver, changeImpact, 40);
        $(changeImpact).click();
        commonMethods.waitForElementExplicitly(2000);
        $(linkBtn).click();
        commonMethods.waitForElementExplicitly(3000);
        verifyAndSwitchFrame();
        By changeEventText = By.xpath("(//td//*[contains(text(),'" + changeEventVal + "')])[1]//..//..//td[contains(text(),'Change Event')]");
        commonMethods.waitForElement(driver, changeEventText, 40);
        Assert.assertTrue("Change Event is not displayed", $(changeEventText).isDisplayed());
    }

    public void linkExistingVariationsOnMail(String variation) {
        $(By.xpath("(//button[contains(text(),'Actions')])[2]")).click();
        commonMethods.waitForElement(driver, linkToExistingVariationsOnMail, 40);
        $(linkToExistingVariationsOnMail).click();
        commonMethods.waitForElementExplicitly(4000);
        switchToFrameCost();
        searchPlaceHolderValue(searchChange, variation);
        commonMethods.waitForElement(driver, changeImpact, 40);
        $(changeImpact).click();
        commonMethods.waitForElementExplicitly(2000);
        $(linkBtn).click();
        commonMethods.waitForElementExplicitly(3000);
        verifyAndSwitchFrame();
        By variationText = By.xpath("(//td//*[contains(text(),'" + variation + "')])[1]//..//..//td[contains(text(),'Variation')]");
        commonMethods.waitForElement(driver, variationText, 40);
        Assert.assertTrue("Variation text is not displayed", $(variationText).isDisplayed());
    }

}
