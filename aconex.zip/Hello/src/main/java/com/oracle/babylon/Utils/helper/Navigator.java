package com.oracle.babylon.Utils.helper;

import com.codeborne.selenide.WebDriverRunner;
import com.github.javafaker.Faker;
import com.oracle.babylon.Utils.setup.dataStore.DataSetup;
import com.oracle.babylon.Utils.setup.dataStore.DataStore;
import com.oracle.babylon.Utils.setup.dataStore.pojo.User;
import com.oracle.babylon.Utils.setup.utils.ConfigFileReader;
import org.apache.commons.codec.binary.Base64;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;

/**
 * Base class for all page files
 * Author: vsingsi
 * Edited by : susgopal
 * Edited by : Kukumavi
 */
public class Navigator {

    protected User user = new User();
    protected DataStore dataStore = new DataStore();
    protected ConfigFileReader configFileReader = new ConfigFileReader();
    protected WebDriver driver = null;
    protected CommonMethods commonMethods = new CommonMethods();
    protected APIHelper apiHelper = new APIHelper();
    protected DataSetup dataSetup = new DataSetup();
    protected Map<String, String> projectMap = null;
    protected Map<String, Object> userMap = null;
    protected Map<String, Object> mailMap = null;
    protected Map<String, Object> sdMap = null;
    protected Map<String, Map<String, Object>> jsonMapOfMap = null;
    protected By avatar = By.xpath("//span[@id='nav-info']/span[@class='nav-userAvatar']");
    public By titleName = By.xpath("//input[@name='title']");
    private By usernameTxtBox = By.id("userName");
    private By passwordTxtBox = By.id("password");
    private By loginBtn = By.id("login");
    protected By projectChangerSelect = By.id("projectChanger-name");
    private By projectTxtBox = By.xpath("//input[@id='searchProjects']");
    //protected By projectChangerSelect = By.xpath("//div[@class='nav-infoHolder']//span[@id='projectChanger-name']//span");
    private By projectChangerContainer = By.xpath("//span[@class='projectChanger-container']");
    private By userDetails = By.xpath("//span[@class='nav-userDetails']");
    private By orgDetails = By.xpath("//span[@class='nav-orgDetails']");
    protected By loadingProgressIcon = By.cssSelector(".loading_progress");
    private By loginFailureMessage = By.xpath("//li[@class='message warning']//div[text()='Your login name or password is incorrect. Check that caps lock is not on.']");
    private By logOutNavigator = By.xpath("//span[@class='nav-userDetails']");
    private By logOffBtn = By.xpath("//div[@class='auiPopover-content']//a[@id='logoff']");
    private By registerLink = By.xpath("//a[text()='Register']");
    private By attributeClickOk = By.xpath("//button[@id='attributePanel-commit' and @title='OK']");
    protected By header = By.xpath("//h1");
    protected String userDataPath = null;
    protected String mailDataPath = null;
    protected String docDataPath = null;
    private By otherTabsArrow = By.xpath("//div[contains(@title,'Your current screen size is too small to view all modules')]");
    private By loggedUser = By.xpath("//div[@class='nav-extras']//span[@class='nav-userDetails']");
    protected By loadingIcon = By.cssSelector(".loading_progress");
    private By okBtn = By.xpath("//button[@id='btnattachDocs_panel_ok']");
    static public String globalProjectType;
    static public String globalProjectName;
    private By newDocSearchOption = By.xpath("//div[@class='auiMessage message-banner info']//a[@id='banner-opt-in']");
    private By switchToClassicView = By.xpath("//div[@class='auiMessage message-banner info']//a[contains(text(),'Switch back to the classic')]");
    protected By webViewerFrame = By.xpath("//iframe[@title='webviewer']");
    private By sslCertPage = By.cssSelector("body.ssl");
    private By advancedButton = By.cssSelector("button#details-button");
    protected By agreeTermsAndConditions = By.xpath("//input[contains(@id,'highComplianceTermsAgreed')]/following-sibling::button");
    private By collapsableArrow = By.xpath("//div[@class='collapse-container ng-scope']");
    private By proceedLink = By.cssSelector("a#proceed-link");
    protected By backBtn = By.xpath("//button[@id='btnBack']//div[@class='uiButton-content']");
    private By fedRampNotice = By.xpath("//body//div[@class='auiModal-content']");
    private By agreeBtn = By.xpath("//body//div[@class='auiModal-content']//button[contains(.,'I agree')]");
    protected By menuChanger = By.xpath("//div[contains(@title,'Click here to view the hidden modules')]");
    protected By moreMenuItems = By.xpath("//div[@class='nav-barRow']//div[contains(@class,'navBar-chevronUp')]");
    private By sentTab = By.xpath("//div[@class='center-content']//a[contains(text(),'Sent')]");
    private By inboxTab = By.xpath("//div[@class='center-content']//a[contains(text(),'Inbox')]");
    private By draftTab = By.xpath("//div[@class='center-content']//a[contains(text(),'Draft')]");
    protected By firstMenu = By.xpath("//div[@id='nav-bar']//button[1]");
    protected By document = By.xpath("//div[@id='nav-bar']//button[@id='nav-bar-DOC']//div[@class='uiButton-label']");
    private By loginBtnAfterLogout = By.xpath("//button[@id='btnLogin' and contains(.,'Log in')]");
    public By saveButton = By.xpath("//button[contains(text(),'Save')]");
    public By saveBtn = By.xpath("//button[@id='btnSave']");
    public By saveToDraft = By.xpath("//button[@id='btnSaveDraftAddendum']");
    public By saveTxtButton = By.xpath("//div[@class='uiButton-content']//*[contains(text(),'Save')]");
    public By pageSaveBtn = By.xpath("//button[@id='btnSave']");
    public By backButton = By.xpath("//a[@class='auiButton back']");
    protected By dataHeaders = By.xpath("//tr[@class='dataHeaders']//th");
    protected By dataRows = By.xpath("//div[@id='searchResultsContainer']//tr[@class='dataRow']");
    protected By menuBar = By.xpath("//div[@id='nav-bar']//button");
    protected By errorMessages = By.xpath("//*[contains(@id,'failure-message')]");
    protected By setUpLink = By.xpath("//button[contains(@class,'uiButton navBarButton')]//div[text()='Setup']");
    protected By continueBtn = By.xpath("//button[@id='btnContinue']");
    protected Faker faker = new Faker();
    protected By searchButton = By.xpath("//button[@id='btnSearch_page']");
    protected By searchBtn = By.xpath("//button[contains(@id,'btnSearch')]//div[text()='Search']");
    private By nextLink = By.xpath("//a[text()='next>>']");
    public By selectGroupBy = By.xpath("//select[@id='groupBy']");
    public By addRemoveColumnsBtn = By.xpath("//div[contains(text(),'Add/Remove Columns')]");
    public By addColumnOkBtn = By.xpath("//button[@id='btnconfigColumns_ok']//div[@class='uiButton-label'][contains(text(),'OK')]");
    public By addColumnCancelBtn = By.xpath("//button[@id='btnconfigColumns_cancel']//div[@class='uiButton-label'][contains(text(),'Cancel')]");
    public By showPerPageDropDown = By.xpath("//select[@id='pageSize']");
    public By searchDefaultMessage = By.xpath("//div[contains(text(),'Enter your search criteria above, then click the Search button.')]");
    public By mainBlock = By.id("main");
    public By headerToolBarSection = By.xpath("//*[@id='toolbar_left']");
    public By headerSection = By.xpath("//h1");
    public By header5Section = By.xpath("//h5");
    public By headerSpanSection = By.xpath("//h1//span");
    public By toolBarSection = By.xpath("//div[contains(@class,'auiToolbar-header')]");
    protected By documentLink = By.xpath("//button[contains(@class,'uiButton navBarButton')]//div[text()='Documents']");
    private By tryNewSearch = By.xpath("//a[text()='Try out the new Document Search']");
    private By tryNewUpload = By.xpath("//button[@id='doc-unified-upload-try-now']");
    private By btnMenuUpArrow = By.xpath("//div[@class='navBar-chevron navBar-chevronUp']");
    private By btnAdd = By.xpath("//button[contains(text(),'Add')]");
    public By delegateBtn = By.xpath("//button[@id='btnDelegate']");
    private By btnDocumentsMenu = By.xpath("//button[@id='nav-bar-DOC']");
    private By loaderOverlay = By.cssSelector(".uiLoadingBlocker");
    private By menuRow = By.xpath("//div[@class='nav-barRow']");
    protected By narrowDown = By.xpath("//div[@class='navBar-chevron']");
    public By closeButtonOnSort = By.xpath("//button[@id='btnsortingTip_cancel']//*[text()='Close']");
    protected By btnCancel = By.xpath("//button[text()='Cancel']");
    private By dropdownLogOff = By.xpath("//span[@class='nav-user-dropdown open']//a[@id='logoff']");
    private By btnAccessCmpnyAct = By.xpath("//div[text()=\"Access Aconex via your company's network\"]");
    private By txtBoxWorkEmail = By.xpath("//input[@id='userEmail']");
    private By btnContinue = By.xpath("//button[@id='btnLogin']");
    private By ssoUserName = By.xpath("//input[@id='username']");
    private By ssoPassword = By.xpath("//input[@id='password']");
    private By btnSignOn = By.xpath("//a[contains(text(),'Sign On')]");
    private By oldDocLink = By.xpath("//button[@id='doc-unified-upload-opt-out']");
    private By closeBtn = By.xpath("//button[@id='alertPanel-cancel']");
    private By alertMsg = By.xpath("//*[@id='alertPanel']//*[contains(text(),'Alert')]");
    protected By allOrgPrjChkBox = By.xpath("//input[@name='allProjects']");
    private By cancelBtn = By.xpath("//button[contains(text(),'Cancel')]");
    private By editIcon = By.xpath("//div[@class='auiIcon edit list-group-item-icon pull-left']");
    protected By btnUpArrow = By.xpath("//button[@id='btnMoveUpList_page']//div[@class='uiButton-label']");
    protected By btnDownArrow = By.xpath("//button[@id='btnMoveDownList_page']//div[@class='uiButton-label']");
    private By btnBIMMenu = By.xpath("//button[@id='nav-bar-BIM']");
    private By lnkNoThanks = By.xpath("//a[@title='No thanks']");

    //AAS Identifiers
    private By aasUsernameTxtBox = By.xpath("//div//oj-input-text[@id='userName']");
    private By aasBtnNext = By.xpath("//div//oj-button[@id='nextButton']");
    private By aasPasswordTxtBox = By.xpath("//div//oj-input-password[@id='password']");
    private By aasLoginBtn = By.xpath("//div//oj-button[@id='nextButton']");


    AppHubNavigator appHubNavigator = new AppHubNavigator();

    public Navigator() {
        if (!(configFileReader.onlyAPIFlag))
            driver = WebDriverRunner.getWebDriver();
        userDataPath = configFileReader.getUserDataPath();
        mailDataPath = configFileReader.getMailDataPath();
        docDataPath = configFileReader.getDocumentDataPath();
    }

    /**
     * Method to login using the user id from the feature file. One of the overloaded methods
     *
     * @param page
     * @param username user id from the feature file
     * @param block
     * @param <P>
     */
    public <P> void loginAsUser(P page, String username, Consumer<P> block) {
        user = dataStore.getUser(username);
        loginAsUser(user);
        block.accept(page);
    }

    /**
     * Method to login using the details from userData.json. We convert json data to user object and use it.
     *
     * @param page
     * @param userId
     * @param block
     * @param <P>
     */
    public <P> void loginAsUser(P page, String userId, String projectNumber, Consumer<P> block) {
        //Parse the json to retrieve the essential information and store it in user object
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
        commonMethods.waitForElementExplicitly(1000);
        userMap = jsonMapOfMap.get(userId);
        if (projectNumber != null) {
            String projectIndex = projectNumber.substring(projectNumber.length() - 1);
            globalProjectType = projectNumber;
            HashMap<String, String> map = commonMethods.getDocumentTypeDetail(globalProjectType);
            String projectName = userMap.get(map.get("projectname") + projectIndex).toString();
            globalProjectName = projectName;
            if (projectName != null) {
                user.setProjectName(projectName);
            }
        }
        user.setUsername(userMap.get("username").toString());
        user.setPassword(userMap.get("password").toString());
        user.setFullName(userMap.get("full_name").toString());

        loginAsUser(user);
        block.accept(page);
    }

    /**
     * Method to login to aconex as a admin user
     *
     * @param page
     * @param block
     * @param <P>
     */


    public <P> void loginAsUser(P page, Consumer<P> block) {
        user.setUsername(configFileReader.getAdminUsername());
        user.setPassword(configFileReader.getPassword());
        user.setProjectName(null);
        loginAsUser(user);
        block.accept(page);
    }


    public <P> void loginAsUser(User user) {
        launchApplication(user);
        new ConfigSingleton(driver);
        if (user.getProjectName() != null) {
            selectProject(user.getProjectName());
        }
    }

    public <P> void on(P page, Consumer<P> block) {
        block.accept(page);
    }

    public void enterCreds(String username, String password) {
        try {
            commonMethods.waitForPageLoad(WebDriverRunner.getWebDriver());
            commonMethods.waitForElement(driver, usernameTxtBox, 60);
        } catch (NoSuchElementException | TimeoutException e) {
            logout();
            openAconexUrl();
        }
        if(configFileReader.getAASEnable()) {
            commonMethods.waitForElement(driver, aasUsernameTxtBox, 120);
            $(aasUsernameTxtBox).sendKeys(username);
            commonMethods.waitForElementClickable(driver, aasBtnNext, 15);
            $(aasBtnNext).click();
            commonMethods.waitForElement(driver, aasPasswordTxtBox);
            $(aasPasswordTxtBox).sendKeys(password);
            $(aasLoginBtn).click();
        } else {
            commonMethods.waitForElement(driver, usernameTxtBox, 60);
            $(usernameTxtBox).clear();
            $(usernameTxtBox).setValue(username);
            $(passwordTxtBox).clear();
            $(passwordTxtBox).setValue(password);
            $(loginBtn).click();
        }
        $(".loading_progress").should(disappear);
        //Accept terms and condition
        try {
            commonMethods.waitForElementExplicitly(5000);
            commonMethods.waitForElement(driver, agreeTermsAndConditions, 6);
            $(agreeTermsAndConditions).click();
        } catch (TimeoutException e) {
            //ignore
        }
    }

    public void selectProject(String projectName) {
        commonMethods.waitForPageLoad(driver);
        commonMethods.waitForElementExplicitly(2500);
        if (configFileReader.getAppHubEnable()) {
            appHubNavigator.selectProject(projectName);
        } else {
            try {
                commonMethods.waitForElement(driver, avatar, 45);
            } catch (Exception e) {
                refresh();
                commonMethods.waitForPageLoad(driver);
                commonMethods.waitForElement(driver, avatar, 45);
                commonMethods.waitForElementExplicitly(5000);
            }
            if (projectName != null) {
                commonMethods.waitForElement(driver, projectChangerSelect, 60);
                WebDriverWait wait = new WebDriverWait(driver, 40);
                wait.until(ExpectedConditions.or(ExpectedConditions.visibilityOfElementLocated(By.id("projectChanger-name"))));
                if ($(projectChangerSelect).isDisplayed()) {
                    if ($(projectChangerSelect).text().equals(projectName)) {
                        if (configFileReader.getEnableNewDocSearchFlag()) enableNewDocSearch();
                        return;
                    } else {
                        //project select dropdown shows 20characters only. So need to crop the project name if lenght is more than 20.
                        if (projectName.length() > 20) {
                            projectName = projectName.substring(0, 20);
                        }

                        $(projectChangerSelect).click();
                        $(projectTxtBox).sendKeys(projectName);
                        By projectXpath = By.xpath("//div[@class='projectChanger-listItem']//span[text()='" + projectName + "']");
                        commonMethods.waitForElement(driver, projectXpath, 20);
                        if ($(projectXpath).isDisplayed()) {
                            $(projectXpath).click();
                            if (configFileReader.getEnableNewDocSearchFlag()) enableNewDocSearch();
                        } else {
                            System.out.println("User not part of the project");
                        }
                    }
                } else {
                    System.out.println("No projects available to select");
                }

            } else {
                System.out.println("No Projects Exist in the Organization / Creating new Project /Admin Login");
            }
        }
        //refresh();
    }

    /**
     * Method to enable the new document search feature
     */
    public void enableNewDocSearch() {
        if (configFileReader.getAppHubEnable()) {
            appHubNavigator.enableNewDocSearch();
        } else {
            commonMethods.waitForElement(driver, document, 60);
            $(document).click();
            commonMethods.waitForElementExplicitly(1000);
            if ($(newDocSearchOption).exists()) {
                $(newDocSearchOption).click();
            }
            refresh();
        }
    }

    /**
     * Method to switch to the classic document search
     */
    public void switchClassicDocSearch() {
        if (configFileReader.getAppHubEnable()) {
            appHubNavigator.switchClassicDocSearch();
        } else {
            commonMethods.waitForElement(driver, document, 25);
            $(document).click();
            commonMethods.waitForElementExplicitly(1000);
            if ($(switchToClassicView).exists()) {
                $(switchToClassicView).click();
            }
            refresh();
        }
    }

    /**
     * Method to navigate to the menu and the submenu
     *
     * @param menu
     * @param submenu
     * @return
     */
    public WebDriver getMenuSubmenu(String menu, String submenu) {
        commonMethods.waitForElementExplicitly(2500);
        if (configFileReader.getAppHubEnable()) {
            return appHubNavigator.getMenuSubmenu(menu, submenu);
        } else {
            driver = WebDriverRunner.getWebDriver();
            driver.switchTo().defaultContent();
            WebDriverWait wait = new WebDriverWait(driver, 65);
            wait.until(ExpectedConditions.or(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='nav-barRow']"))));
            By Menu = By.xpath("//button[contains(@class,'uiButton navBarButton')]//div[text()='" + menu + "']");
            try {
                commonMethods.waitForElement(driver, firstMenu, 30);
            } catch (Exception e) {
                refresh();
                commonMethods.waitForElement(driver, firstMenu, 30);
            }
            if (!$(Menu).isDisplayed() && $(menuChanger).isDisplayed()) {
                $(menuChanger).click();
            }
            $(Menu).click();

            wait.until(ExpectedConditions.or(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class,'navBarPanel-menuItem') and text()='" + submenu + "']"))));
            $(By.xpath("//div[contains(@class,'navBarPanel-menuItem') and text()='" + submenu + "' ]")).click();
            $(loadingProgressIcon).should(disappear);
            commonMethods.waitForElementExplicitly(5000);
            return driver;
        }
    }

    /**
     * Method to navigate to a section with menu and submenu.
     * Section is required if two submenus in a menu have the same name
     *
     * @param menu
     * @param section
     * @param submenu
     * @return
     */
    public WebDriver getMenuSubmenu(String menu, String section, String submenu) {
        if (configFileReader.getAppHubEnable()) {
            return appHubNavigator.getMenuSubmenu(menu, section, submenu);
        } else {
            driver = WebDriverRunner.getWebDriver();
            driver.switchTo().defaultContent();
            WebDriverWait wait = new WebDriverWait(driver, 20);
            wait.until(ExpectedConditions.or(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='nav-barRow']"))));
            By navigationMenu = By.xpath("//button[@class='uiButton navBarButton']//div[text()='" + menu + "']");
            commonMethods.waitForElement(driver, firstMenu, 25);
            if ($(menuChanger).isDisplayed() && !$(navigationMenu).isDisplayed()) {
                $(menuChanger).click();
            }
            commonMethods.waitForElement(driver, navigationMenu, 10);
            $(navigationMenu).click();
            wait.until(ExpectedConditions.or(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='navBarPanel-menuItem' and text()='" + submenu + "' ]"))));
            $(By.xpath("//div[@class='navBarPanel-menuSubSection' and contains(.,'" + section + "')]//div[contains(.,'" + submenu + "')]")).click();
            $(loadingProgressIcon).should(disappear);
            return driver;
        }
    }

    public WebElement menuFinder(String css, String text) {
        return driver.findElements(By.cssSelector(css)).stream()
                .filter(e -> e.getText().equalsIgnoreCase(text) && e.isDisplayed() && e.isEnabled())
                .findFirst()
                .get();
    }

    /**
     * Verify if the user is present in the page
     *
     * @param fullname
     */
    public void verifyUserPresent(String fullname) {
        if (configFileReader.getAppHubEnable()) {
            appHubNavigator.verifyUserPresent(fullname);
        } else {
            commonMethods.waitForElement(driver, userDetails);
            $(userDetails).getText().contains(fullname);
        }
    }

    public void verifyOrganisationPresent(String orgName) {
        if (configFileReader.getAppHubEnable()) {
            appHubNavigator.verifyUserPresent(orgName);
        } else {
            commonMethods.waitForElement(driver, orgDetails);
            $(orgDetails).getText().contains(orgName);
        }
    }

    public void verifyUserNotPresent() {
        if (configFileReader.getAppHubEnable()) {
            appHubNavigator.verifyUserNotPresent();
        } else {
            $(userDetails).shouldNot(text(user.getFullName()));
        }
    }

    public void verifyLoginFailed() {
        $(loginFailureMessage).shouldHave(text("Your login name or password is incorrect. Check that caps lock is not on."));
    }


    /**
     * Function to logout from the server.
     */
    public void logout() {
        if (configFileReader.getAppHubEnable()) {
            appHubNavigator.logout();
        } else {
            if (driver.getCurrentUrl().contains(ConfigFileReader.getApplicationUrl())) {
                if (commonMethods.isAlertPresent(WebDriverRunner.getWebDriver())) acceptAlert();
                switchToOriginal();
                commonMethods.waitForPageLoad(WebDriverRunner.getWebDriver());
                if (!$(avatar).isDisplayed()) refresh();
                commonMethods.waitForElementExplicitly(2000);
                Actions actions = new Actions(WebDriverRunner.getWebDriver());
                WebDriverRunner.getWebDriver().switchTo().defaultContent();
                commonMethods.waitForElementClickable(WebDriverRunner.getWebDriver(), avatar, 60);
                actions.moveToElement($(avatar)).click().build().perform();
                commonMethods.waitForElementExplicitly(500);
                try {
                    commonMethods.waitForElement(driver, dropdownLogOff, 5);
                } catch (Exception e) {
                    switchToOriginal();
                    actions.moveToElement($(avatar)).doubleClick().build().perform();
                    commonMethods.waitForElementExplicitly(500);
                    commonMethods.waitForElementClickable(WebDriverRunner.getWebDriver(), logOffBtn, 10);
                }
                switchToOriginal();
                commonMethods.waitForElementClickable(WebDriverRunner.getWebDriver(), logOffBtn, 10);
                actions.moveToElement($(logOffBtn)).click().build().perform();
            }
        }
    }


    /**
     * Function to click on Register link to create a organization
     */
    public void clickRegisterLink() {
        commonMethods.waitForElement(driver, registerLink, 60);
        $(registerLink).click();
    }

    public void openAconexUrl() {
        try {
            open(ConfigFileReader.getApplicationUrl());
        } catch (TimeoutException e) {
            if (e.toString().contains("Timed out receiving message from renderer:")) {
                open(ConfigFileReader.getApplicationUrl());
            }
        }
        if ($(sslCertPage).isDisplayed()) {
            $(advancedButton).click();
            $(proceedLink).click();
        }

        //Accept terms and condition
        try {
            commonMethods.waitForElement(driver, agreeTermsAndConditions, 6);
            $(agreeTermsAndConditions).click();
        } catch (TimeoutException e) {
            //ignore
        }
        new ConfigSingleton(driver);
    }

    /**
     * Method to select the ok button when selecting the attribute value
     */
    public void selectAttributeClickOK() {
        $(attributeClickOk).click();
    }

    public Map<String, String> returnProjectMap() {
        return projectMap;
    }

    /**
     * Method to verify the element is displayed
     *
     * @param by
     * @return
     */
    public boolean verifyPageTitle(By by) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, by, 60);
        Boolean isDisplayed = $(by).isDisplayed();
        return isDisplayed;
    }

    /**
     * Method to verify the text of the element
     *
     * @param pageTitle
     * @return
     */
    public boolean verifyPageTitle(String pageTitle) {
        verifyAndSwitchFrame();
        commonMethods.waitForElementExplicitly(2000);
        new WebDriverWait(driver, 40).until(ExpectedConditions.textToBePresentInElementLocated(header, pageTitle));
        boolean flag = ($(header).text()).contains(pageTitle);
        driver.switchTo().defaultContent();
        return flag;
    }

    public void findOtherTabs() {
        $(otherTabsArrow).click();
    }

    /**
     * Method to verify and switch to mail frame
     */
    public void verifyAndSwitchFrame() {
        if (configFileReader.getAppHubEnable()) {
            appHubNavigator.verifyAndSwitchFrame();
        }
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        String currentFrame = null;
        By frame = By.xpath("//iframe[@id='frameMain']");
        $(".loading_progress").should(disappear);
        try {
            currentFrame = (String) jsExecutor.executeScript("return self.name");
        } catch (UnhandledAlertException e) {
            $(".loading_progress").should(disappear);
            currentFrame = (String) jsExecutor.executeScript("return self.name");
        }
        try {
            if (!currentFrame.equalsIgnoreCase("main")) {
                switchTo().defaultContent();
                commonMethods.switchToFrame(driver, "frameMain");
            }
        } catch (NoSuchElementException e) {
            switchTo().defaultContent();
            commonMethods.waitForElement(driver, frame, 10);
            commonMethods.switchToFrame(driver, "frameMain");
        }
    }

    /**
     * Method to switch the the default frame
     */
    public void switchToOriginal() {
        driver.switchTo().defaultContent();
    }

    /**
     * Method to switch to a specific frame if it exists
     *
     * @param frameName
     */
    public void verifyAndSwitchFrame(String frameName) {
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        String currentFrame = (String) jsExecutor.executeScript("return self.name");
        if (!currentFrame.equalsIgnoreCase(frameName)) {
            commonMethods.switchToFrame(driver, frameName);
        }
    }

    /**
     * Method to switch to a specific frame by its locator
     *
     * @param frameLocator
     */
    public void verifyAndSwitchFrame(By frameLocator) {
        commonMethods.waitForElement(driver, frameLocator, 10);
        switchTo().frame($(frameLocator));
    }

    /**
     * Method to refresh page
     */
    public void refresh() {
        if (configFileReader.getAppHubEnable()) {
            appHubNavigator.refresh();
        } else {
            driver.navigate().refresh();
            commonMethods.acceptAlert(driver);
            commonMethods.waitForPageLoad(driver);
            try {
                commonMethods.waitForElement(driver, firstMenu, 60);
            } catch (TimeoutException e) {
                driver.navigate().refresh();
                commonMethods.waitForElement(driver, firstMenu, 60);
            }
        }
    }

    /**
     * function to get logged in user name with salutation
     *
     * @return
     */
    public String getLoggedInUser() {
        if (configFileReader.getAppHubEnable()) {
            return appHubNavigator.getLoggedInUser();
        } else {
            driver.switchTo().defaultContent();
            String userName = $(loggedUser).text();
            String[] user = userName.split(" ");
            userName = user[1] + " " + user[2];
            return userName;
        }
    }

    /**
     * function to get element in the view
     *
     * @param element to make visible
     */
    public void getElementInView(By element) {
        WebElement e = $(element);
        commonMethods.waitForElement(driver, element, 60);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", e);
    }

    /**
     * Function to press enter on page
     */
    public void hitEnter() {
        verifyAndSwitchFrame();
        $(By.xpath("//html")).sendKeys(Keys.ENTER);
    }

    public void clickOkBtn() {
        commonMethods.waitForElementExplicitly(2000);
        if ($(okBtn).exists()) {
            $(okBtn).click();
        }

    }

    public void navigateAndVerifyPage(String menu, String submenu) {
        commonMethods.waitForElementExplicitly(3000);
        getMenuSubmenu(menu, submenu);

    }

    public void navigateAndVerifyPage(String menu, String section, String submenu) {
        commonMethods.waitForElementExplicitly(3000);
        getMenuSubmenu(menu, section, submenu);

    }

    /**
     * Method to switch to the Web Viewer frame needed for workflows and document viewer test cases
     */
    public void webViewerFrame() {
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        String currentFrame = jsExecutor.executeScript("return self.name").toString();
        if (currentFrame.equals("main")) {
            commonMethods.waitForElement(driver, webViewerFrame, 40);
            driver.switchTo().frame($(webViewerFrame));
        }
    }

    /**
     * Method to accept the alert box
     */
    public void acceptAlert() {
        commonMethods.waitForElementExplicitly(2000);
        if (commonMethods.isAlertPresent(driver)) {
            driver.switchTo().alert().accept();
        }

    }

    /**
     * Method to close the alert box
     */
    public void dismissAlert() {
        commonMethods.waitForElementExplicitly(1000);
        driver.switchTo().alert().dismiss();
    }

    /**
     * Method to click on Close button
     */
    public void closeAlertMsg() {
        commonMethods.waitForElement(driver, alertMsg, 80);
        $(closeBtn).click();
    }

    /**
     * Function to click on back button
     */
    public void clickBackButton() {
        commonMethods.waitForElementExplicitly(2000);
        commonMethods.waitForElement(driver, backBtn, 40);
        $(backBtn).click();
    }

    /**
     * Function to switch to mail attachpanel
     */
    public void switchToMailAttachPanel() {
        switchTo().defaultContent();
        verifyAndSwitchFrame();
        if (!driver.findElements(By.xpath("//iframe[@id='attachOnNewPanel_iframe']")).isEmpty()) {
            switchTo().frame("attachOnNewPanel_iframe");
        }
    }

    /**
     * Function to switch tab for document and mail pages
     *
     * @param page name
     * @param tab  name
     */
    public boolean switchTab(String page, String tab) {
        switch (page.toLowerCase()) {
            case "document":
                verifyAndSwitchFrame();
                commonMethods.waitForElementExplicitly(10000);
                By element = By.xpath("//li[@title='" + tab + "']");
                if ($(element).isDisplayed() == false) {
                    $(collapsableArrow).click();
                }
                $(element).click();
                return $(By.xpath("//h1[contains(text(),'Search -')]//span[text()='" + tab + "']")).isDisplayed();
            case "mail":
                $(By.xpath("//div[@class='center-content']//a[contains(text(),'" + tab + "')]")).click();
                break;
            case "mail panel":
                switchToMailAttachPanel();
                commonMethods.waitForElementExplicitly(2000);
                $(By.xpath("//div[@class='center-content']//a[contains(text(),'" + tab + "')]")).click();
                break;
        }
        return true;
    }

    /**
     * Function to check if message is displayed on the page.
     *
     * @param message expected message.
     * @return
     */
    public boolean isMessageDispalyedOnPage(String message) {
        try {
            commonMethods.waitForElement(driver, By.xpath("//*[contains(text(),'" + message + "')]"), 50);
            $(By.xpath("//*[contains(text(),'" + message + "')]")).waitUntil(disappears, 10000);
            return true;
        } catch (TimeoutException e) {
            return false;
        }
    }

    /**
     * Function to wait until loader disappers.
     */
    public void waitForLoaderToDisappear() {
        try {
            commonMethods.waitForElement(driver, loaderOverlay, 8);
            $(loaderOverlay).waitUntil(hidden, 50000);
        } catch (TimeoutException e) {
            //ignore
        }
    }

    /**
     * Function to verify alert message
     *
     * @actual is the message to verify in alert text box
     */

    public boolean verifyAlert(String actual) {
        try {
            String windowHandle = driver.getWindowHandle();
            commonMethods.waitForElementExplicitly(4000);
            String text = driver.switchTo().alert().getText();
            driver.switchTo().alert().accept();
            driver.switchTo().window(windowHandle);
            Assert.assertTrue((text).contains(actual));
            return true;
        } catch (UnhandledAlertException e) {
            e.printStackTrace();
            return false;
        } catch (NoAlertPresentException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    /**
     * Function to click save button
     */
    public void clickSaveBtn() {
        commonMethods.waitForElement(driver, saveButton);
        $(saveButton).click();
    }

    /**
     * Function to click save button
     */
    public void clickSaveButton() {
        $(pageSaveBtn).click();
    }

    /**
     * Function to get alter window message
     */
    public String getAlertText() {
        commonMethods.waitForElementExplicitly(1000);
        return driver.switchTo().alert().getText();
    }

    /**
     * Function to Get the column number on the result table
     *
     * @param columnName
     * @return
     */
    public int getColumnIndex(String rowClassName, String columnName) {
        int columnIndex = 0;
        commonMethods.waitForElement(driver, dataRows);
        for (int iterator = 1; iterator <= $$(dataHeaders).size(); iterator++) {
            if ($(By.xpath("(//tr[@class='" + rowClassName + "']//th)[" + iterator + "]")).getText().contains(columnName)) {
                columnIndex = iterator;
                break;
            }
        }
        return columnIndex;
    }

    /**
     * Method to return the selected dropdown
     *
     * @return
     */
    public String returnSelectedDropDown(By element) {
        commonMethods.waitForElement(driver, element);
        return $(element).getSelectedText();
    }

    public boolean verifyMenuExists(String menuHeader, String menuName) {
        if (configFileReader.getAppHubEnable()) {
            return appHubNavigator.verifyMenuExists(menuHeader, menuName);
        } else {
            driver = WebDriverRunner.getWebDriver();
            driver.switchTo().defaultContent();
            WebDriverWait wait = new WebDriverWait(driver, 45);
            wait.until(ExpectedConditions.or(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='nav-barRow']"))));
            By Menu = By.xpath("//button[contains(@class,'uiButton navBarButton')]//div[text()='" + menuHeader + "']");
            commonMethods.waitForElementExplicitly(3000);
            commonMethods.waitForElement(driver, Menu);
            $(Menu).click();
            return $(By.xpath("//div[@class='navBarPanel-menuItem' and contains(text(),'" + menuName + "')]")).isDisplayed();
        }
    }

    /**
     * Method to click on search button
     */
    public void searchButton() {
        $(searchButton).shouldBe(appear);
        $(searchButton).click();
    }

    /**
     * Method to click on menu changer icon
     *
     * @return
     */
    public boolean clickMenuChangerIcon() {
        if (configFileReader.getAppHubEnable()) {
            return appHubNavigator.clickMenuChangerIcon();
        } else {
            if ($(menuChanger).isDisplayed()) {
                $(menuChanger).click();
                commonMethods.waitForElementExplicitly(2000);
                return true;
            } else
                return false;
        }
    }

    /**
     * Method to return the text present in the alert box
     *
     * @return
     */
    public String returnAlertText() {
        return commonMethods.returnAlertText(driver);
    }


    /**
     * Function to click on next
     */
    public void clickNext() {
        commonMethods.waitForElement(driver, nextLink, 40);
        $(nextLink).click();
    }

    /**
     * Function to check if error displayed on the page.
     *
     * @return
     */
    public boolean isErrorDisplayedOnPage() {
        try {
            commonMethods.waitForElement(driver, errorMessages, 10);
        } catch (TimeoutException e) {
            return false;
        }
        return true;
    }

    /**
     * Function to check if error displayed on the page.
     *
     * @return
     */
    public boolean isErrorDispalyedOnPage() {
        commonMethods.waitForElementExplicitly(5000);
        return $(errorMessages).isDisplayed();
    }

    /**
     * Function to select the Group By with the passed param
     *
     * @param option
     */
    public void selectGroupByFilter(String option) {
        verifyAndSwitchFrame();
        commonMethods.waitForElement(driver, selectGroupBy);
        $(selectGroupBy).selectOptionContainingText(option);
        commonMethods.waitForElementExplicitly(6000);
    }

    /**
     * Function to select page Size
     *
     * @param size
     */
    public void selectPageSize(String size) {
        verifyAndSwitchFrame();
        $(showPerPageDropDown).selectOption(size);
        commonMethods.waitForElement(driver, searchButton);
        $(searchButton).click();
    }

    public void enableUnifiedUpload(String projectId) {
        if (configFileReader.getAppHubEnable()) {
            appHubNavigator.enableUnifiedUpload(projectId);
        } else {
            HashMap<String, String> map = commonMethods.getDocumentTypeDetail(projectId);
            String key = map.get("registermenu");
            By by = By.xpath("//button[contains(@class,'uiButton navBarButton')]//div[text()='" + key + "']");
            commonMethods.waitForElement(driver, by);
            $(by).click();
            if ($(tryNewSearch).isDisplayed()) {
                $(tryNewSearch).click();
            }
            if ($(tryNewUpload).isDisplayed()) {
                $(tryNewUpload).click();
            }
            refresh();
        }
    }

    /**
     * Method to click menu up arrow
     */
    public void clickMenuUpArrow() {
        if (configFileReader.getAppHubEnable()) {
            appHubNavigator.clickMenuPreviousArrow();
        } else {
            driver.switchTo().defaultContent();
            if ($(btnMenuUpArrow).isDisplayed()) {
                $(btnMenuUpArrow).click();
                commonMethods.waitForElementExplicitly(1000);
            }
        }
    }

    /**
     * Method to double click on menu name
     */
    public WebDriver doubleClickMenu(String menu) {
        if (configFileReader.getAppHubEnable()) {
            return appHubNavigator.doubleClickMenu(menu);
        } else {
            switchToOriginal();
            commonMethods.waitForElement(driver, menuRow, 65);
            By Menu = By.xpath("//button[contains(@class,'uiButton navBarButton')]//div[text()='" + menu + "']");
            commonMethods.waitForElement(driver, firstMenu, 30);
            if ($(moreMenuItems).exists() && !$(Menu).isDisplayed()) $(moreMenuItems).click();
            $(loadingProgressIcon).should(disappear);
            commonMethods.waitForElementExplicitly(1000);
            $(Menu).doubleClick();
            commonMethods.waitForElementExplicitly(5000);
            return driver;
        }
    }

    /**
     * Method to click on menu name
     */
    public WebDriver clickMenu(String menu) {
        if (configFileReader.getAppHubEnable()) {
            return appHubNavigator.clickMenu(menu);
        } else {
            switchToOriginal();
            commonMethods.waitForElement(driver, menuRow, 65);
            By Menu = By.xpath("//button[contains(@class,'uiButton navBarButton')]//div[text()='" + menu + "']");
            commonMethods.waitForElement(driver, firstMenu, 30);
            if ($(moreMenuItems).exists() && !$(Menu).isDisplayed()) $(moreMenuItems).click();
            $(loadingProgressIcon).should(disappear);
            commonMethods.waitForElementExplicitly(1000);
            $(Menu).click();
            commonMethods.waitForElementExplicitly(5000);
            return driver;
        }
    }

    public void resetCredentials(String userName, String password) {
        commonMethods.waitForElementExplicitly(3000);
        try {
            commonMethods.waitForElement(driver, btnContinue, 120);
            $(btnContinue).click();
        } catch (Exception e) {
            commonMethods.waitForElementExplicitly(3000);
            driver.get(configFileReader.getApplicationUrl());
        }
        commonMethods.waitForElement(driver, usernameTxtBox, 120);
        $(usernameTxtBox).clear();
        $(usernameTxtBox).setValue(userName);
        $(passwordTxtBox).clear();
        $(passwordTxtBox).setValue(password);
        sleep(1000);
        $(loginBtn).click();
    }


    /**
     * Method to verify project name is present in the project list of logged in user
     */
    public boolean verifyProjectList(String userId, String projectId) {
        if (configFileReader.getAppHubEnable()) {
            return appHubNavigator.verifyProjectList(userId, projectId);
        } else {
            driver.switchTo().defaultContent();
            commonMethods.waitForElement(driver, projectChangerSelect, 30);
            $(projectChangerSelect).click();
            return $(By.xpath("//div[@class='projectChanger-list']//span[contains(text(),'" + commonMethods.getProjectName(userId, projectId) + "')]")).isDisplayed();
        }
    }

    /**
     * Method to click on Add button
     */
    public void clickAdd() {
        $(btnAdd).click();
    }

    /**
     * Method to verify tool tip messages
     */
    public String verifyToolTips(By element) {
        Actions actions = new Actions(driver);
        actions.moveToElement($(element)).perform();
        return $(element).getAttribute("title");
    }

    /**
     * Method to return documents menu name
     */
    protected String getDocumentMenuName() {
        if (configFileReader.getAppHubEnable()) {
            return appHubNavigator.getDocumentMenuName();
        } else {
            switchToOriginal();
            commonMethods.waitForElement(driver, btnDocumentsMenu, 60);
            return $(btnDocumentsMenu).getText();
        }
    }

    public void loadingIconDone() {
        $(loadingProgressIcon).should(disappear);
    }

    /**
     * Method to click Setup link on the menu bar
     */
    public void clickSetupLink() {
        if (configFileReader.getAppHubEnable()) {
            appHubNavigator.clickSetupLink();
        } else {
            if ($(narrowDown).exists() && !$(setUpLink).isDisplayed()) {
                $(narrowDown).click();
            }
            commonMethods.waitForElement(driver, setUpLink);
            $(setUpLink).click();
        }
    }

    public boolean verifyMenu(String menuName) {
        if (configFileReader.getAppHubEnable()) {
            return appHubNavigator.verifyMenu(menuName);
        } else {
            By menu = By.xpath("//button[contains(@class,'uiButton navBarButton')]//div[text()='" + menuName + "']");
            return $(menu).isDisplayed();
        }
    }

    /**
     * Method to wait till link select all displayed
     */
    public void waitForResultsDisplay(By element) {
        $(loadingIcon).should(disappear);
        commonMethods.waitForElement(driver, element, 60);
    }

    /**
     * Method to login into Application using Single Sign On
     *
     * @param page
     * @param userId user id from the feature file
     * @param block
     * @param <P>
     */
    public <P> void loginAsSSO(P page, String userId, Consumer<P> block) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
        commonMethods.waitForElementExplicitly(1000);
        userMap = jsonMapOfMap.get(userId);
        launchApplication();
        enterUserAccount(userMap.get("username").toString());
        enterSSODetails(userMap.get("idp_username").toString(), userMap.get("idp_password").toString());
        block.accept(page);
    }

    /**
     * Method to open the Aconex application in a browser
     */
    public void launchApplication() {
        if (configFileReader.getAppHubEnable()) {
            appHubNavigator.launchApplication();
        } else {
            switchTo().defaultContent();
            if ($(avatar).isDisplayed()) {
                refresh();
                logout();
                commonMethods.waitForElementExplicitly(4000);
            }
            openAconexUrl();
        }
    }
    
    /**
     * Method to open the Aconex application in a browser
     */
    public void launchApplication(User user) {
        if (configFileReader.getAppHubEnable()) {
            appHubNavigator.launchApplication(user);
        } else {
            switchTo().defaultContent();
            if ($(avatar).isDisplayed()) {
                refresh();
                logout();
                commonMethods.waitForElementExplicitly(4000);
            }
            openAconexUrl();
            enterCreds(user.getUsername(), user.getPassword());
        }
    }

    /**
     * Method to enter Company Account details
     */
    public void enterUserAccount(String userName) {
        commonMethods.waitForElement(driver, btnAccessCmpnyAct);
        $(btnAccessCmpnyAct).click();
        commonMethods.waitForElement(driver, txtBoxWorkEmail, 60);
        commonMethods.enterTextValue(txtBoxWorkEmail, userName);
        $(btnContinue).click();
    }

    /**
     * Method to enter Single Sign On details
     */
    public void enterSSODetails(String userName, String password) {
        commonMethods.waitForElement(driver, ssoUserName, 60);
        commonMethods.enterTextValue(ssoUserName, userName);
        commonMethods.enterTextValue(ssoPassword, password);
        $(btnSignOn).click();
    }

    /**
     * Method to Register user to IDP User
     */
    public void registerIdpUser(String userId) {
        commonMethods.waitForElement(driver, usernameTxtBox);
        commonMethods.enterTextValue(usernameTxtBox, commonMethods.getUserData(userId, "username"));
        commonMethods.enterTextValue(passwordTxtBox, commonMethods.getUserData(userId, "password"));
        $(btnContinue).click();
    }

    /**
     * Function to switch to the old document page
     */
    public void enableOldDoc() {
        if (configFileReader.getAppHubEnable()) {
            appHubNavigator.enableOldDoc();
        } else {
            commonMethods.waitForElementExplicitly(3000);
            driver = WebDriverRunner.getWebDriver();
            driver.switchTo().defaultContent();
            By Menu = By.xpath("//button[contains(@class,'uiButton navBarButton')]//div[text()='Documents']");
            commonMethods.waitForElement(driver, Menu);
            $(Menu).click();
            commonMethods.waitForElementExplicitly(3000);
            if ($(oldDocLink).isDisplayed()) {
                $(oldDocLink).click();
            }
            refresh();
        }
    }

    /**
     * Method to launch application
     */
    public <P> void loginAsUser(String url, String userId) {
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userDataPath);
        commonMethods.waitForElementExplicitly(1000);
        userMap = jsonMapOfMap.get(userId);
        launchApplication(url);
        enterCreds(userMap.get("username").toString(), userMap.get("password").toString());
    }

    /**
     * Method to launch application
     */
    public void launchApplication(String url) {
        switchTo().defaultContent();
        if ($(avatar).isDisplayed()) {
            refresh();
            logout();
            commonMethods.waitForElementExplicitly(4000);
        }
        openAconexUrl(url);
        new ConfigSingleton(driver);
    }

    /**
     * Method to open the Aconex application in a browser by providing url
     */
    public void openAconexUrl(String url) {
        try {
            open(url);
        } catch (TimeoutException e) {
            if (e.toString().contains("Timed out receiving message from renderer:")) {
                open(url);
            }
        }
        if ($(sslCertPage).isDisplayed()) {
            $(advancedButton).click();
            $(proceedLink).click();
        }

        //Accept terms and condition
        try {
            commonMethods.waitForElement(driver, agreeTermsAndConditions, 6);
            $(agreeTermsAndConditions).click();
        } catch (TimeoutException e) {
            //ignore
        }
        new ConfigSingleton(driver);

    }

    public String returnProjectName() {
        if (configFileReader.getAppHubEnable()) {
            return appHubNavigator.returnProject();
        } else {
            commonMethods.waitForElement(driver, projectChangerSelect);
            return $(projectChangerSelect).getText();

        }
    }

    /**
     * Method to click on menu item
     *
     * @return
     */
    public void clickOnMenu(String menuHeader) {
        if (configFileReader.getAppHubEnable()) {
            appHubNavigator.clickOnMenu(menuHeader);
        } else {
            driver = WebDriverRunner.getWebDriver();
            driver.switchTo().defaultContent();
            commonMethods.waitForElement(driver, menuRow, 45);
            By Menu = By.xpath("//button[contains(@class,'uiButton navBarButton')]//div[text()='" + menuHeader + "']");
            commonMethods.waitForElementExplicitly(3000);
            commonMethods.waitForElement(driver, Menu);
            $(Menu).click();
        }
    }

    /**
     * Method to verify sub menu items
     *
     * @return
     */
    public boolean verifySubMenuExist(String subMenu) {
        if (configFileReader.getAppHubEnable()) {
            return appHubNavigator.verifySubMenuExist(subMenu);
        } else {
            driver = WebDriverRunner.getWebDriver();
            driver.switchTo().defaultContent();
            By xpath = By.xpath("//div[@class='navBarPanel-menuItem' and text()='" + subMenu + "']");


            return $(xpath).isDisplayed();
        }
    }

    /**
     * Method to return the Menu Size
     */
    public int returnMenuSize() {
        if (configFileReader.getAppHubEnable())
            return appHubNavigator.returnMenuSize();
        else {
            commonMethods.waitForElement(driver, avatar);
            commonMethods.waitForElement(driver, menuBar);
            return $$(menuBar).size();
        }
    }

    /**
     * Function to switch to project settings frame
     */
    public void switchProjectSettingsFrame() {
        switchTo().defaultContent();
        verifyAndSwitchFrame();
        verifyAndSwitchFrame("project-settings-page");
    }

    /**
     * Function to cancel the edit field window
     */
    public void clickOnCancelBtn() {
        $(cancelBtn).click();
    }

    /**
     * Function to edit the project field
     */
    public void editProjectField() {
        $(editIcon).click();
    }

    public void switchToUnifiedUpload() {
        if (configFileReader.getAppHubEnable()) {
            appHubNavigator.switchToUnifiedUpload();
        } else {
            By by = By.xpath("//button[contains(@class,'uiButton navBarButton')]//div[text()='Documents']");
            commonMethods.waitForElement(driver, by);
            $(by).click();
            if ($(tryNewUpload).isDisplayed()) {
                $(tryNewUpload).click();
            }
            refresh();
        }
    }

    public void dragAndDrop(By source, By destination) {
        commonMethods.waitForElementExplicitly(2000);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("function createEvent(typeOfEvent) {\n" + "var event =document.createEvent(\"CustomEvent\");\n" + "event.initCustomEvent(typeOfEvent,true, true, null);\n" + "event.dataTransfer = {\n" + "data: {},\n" + "setData: function (key, value) {\n" + "this.data[key] = value;\n" + "},\n" + "getData: function (key) {\n" + "return this.data[key];\n" + "}\n" + "};\n" + "return event;\n" + "}\n" + "\n" + "function dispatchEvent(element, event,transferData) {\n" + "if (transferData !== undefined) {\n" + "event.dataTransfer = transferData;\n" + "}\n" + "if (element.dispatchEvent) {\n" + "element.dispatchEvent(event);\n" + "} else if (element.fireEvent) {\n" + "element.fireEvent(\"on\" + event.type, event);\n" + "}\n" + "}\n" + "\n" + "function simulateHTML5DragAndDrop(element, destination) {\n" + "var dragStartEvent =createEvent('dragstart');\n" + "dispatchEvent(element, dragStartEvent);\n" + "var dropEvent = createEvent('drop');\n" + "dispatchEvent(destination, dropEvent,dragStartEvent.dataTransfer);\n" + "var dragEndEvent = createEvent('dragend');\n" + "dispatchEvent(element, dragEndEvent,dropEvent.dataTransfer);\n" + "}\n" + "\n" + "var source = arguments[0];\n" + "var destination = arguments[1];\n" + "simulateHTML5DragAndDrop(source,destination);", $(source), $(destination));
        commonMethods.waitForElementExplicitly(4000);
    }

    public String verifyHeader(String instance) {
        if (configFileReader.getAppHubEnable()) {
            return appHubNavigator.verifyHeader(instance);
        } else {
            String headerText = "";
            switch (instance) {
                case "toolbar": {
                    commonMethods.waitForElement(driver, headerToolBarSection);
                    headerText = $(headerToolBarSection).getText();
                    break;
                }
                case "span": {
                    commonMethods.waitForElement(driver, headerSpanSection);
                    headerText = $(headerSpanSection).getText();
                    break;
                }
                case "h1": {
                    commonMethods.waitForElement(driver, headerSection);
                    headerText = $(headerSection).getText();
                    break;
                }
                case "h5": {
                    commonMethods.waitForElement(driver, header5Section);
                    headerText = $(header5Section).getText();
                    break;
                }
                case "ngHeader": {
                    commonMethods.waitForElement(driver, toolBarSection);
                    headerText = $(toolBarSection).getText();
                    break;
                }
            }
            return headerText;
        }
    }

    /**
     * Method to return documents menu name
     */
    protected String getBIMMenu() {
        if (configFileReader.getAppHubEnable()) {
            return appHubNavigator.getBIMMenu();
        } else {
            switchToOriginal();
            commonMethods.waitForElement(driver, btnBIMMenu, 60);
            return $(btnBIMMenu).getText();
        }
    }

    /**
     * Method to click on No thanks button
     */
    public void clickNoThanks() {
        commonMethods.waitForElementExplicitly(5000);
        if($(lnkNoThanks).isDisplayed())
            $(lnkNoThanks).click();
    }
}