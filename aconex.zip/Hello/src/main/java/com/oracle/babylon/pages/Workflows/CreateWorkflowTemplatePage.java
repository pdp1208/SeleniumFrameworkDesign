package com.oracle.babylon.pages.Workflows;

import com.github.javafaker.Faker;
import com.oracle.babylon.Utils.helper.Navigator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import java.text.SimpleDateFormat;
import java.util.*;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class CreateWorkflowTemplatePage extends Navigator {


    // Initiate identfier
    private By pageTitle = By.xpath("//h1[contains(text(),'New Workflow Template')]");
    private By templateName = By.xpath("//input[@id='name']");
    private By workflowNote = By.xpath("//textarea[@id='instructionNote']");
    private By stepInitiator = By.xpath("//a[@id='dragClicker']");
    private By stepDropArea = By.xpath("//div[@id='builder']/table//td[@class='wf-endcell droptarget']");
    private By editDetailBtn = By.xpath("//a[@class='wf-stepprop']");
    private By stepName = By.xpath("//input[@id='builder_stepname']");
    private By toParticipant = By.xpath("//input[@id='builder_stepto_query']");
    private By ccParticipant = By.xpath("//input[@id='builder_stepcc_query']");
    String userFilePath = configFileReader.getUserDataPath();
    private By activateBtn = By.xpath("//button[contains(.,'Activate')]");
    public By saveToDraft = By.xpath("//button[@id='btnSaveToDraft']");
    private By stepOkBtn = By.xpath("//button[@id='btnbuildersp_ok']//div[@class='uiButton-label'][contains(text(),'OK')]");
    private By templateCreatedMsg = By.xpath("//div[@id='messagePanel']//li//div");
    private Faker faker = new Faker();
    public static String wfTemplate;
    private By reasonForIssue = By.xpath("//select[@id='selectedReason']");
    SimpleDateFormat formatter = new SimpleDateFormat("dd-HH-mm-ss");
    private By initiatorStartAction = By.xpath("//label//input[@id='startAction']");
    private By initiatorToolsLbl = By.xpath("//td[text()='Initiator Options']");
    private By initiatorEditAssignee = By.xpath("//label[@for='initiatorCanEditAsignees']");
    private By initiatorSkipSteps = By.xpath("//label[@for='initiatorCanSkipSteps']");
    private String parallelStep = "//table[@class='wf-grid']//div[@class='wf-steppage']";
    private By skipInitiatorSteps = By.xpath("//input[@id='initiatorCanSkipSteps']");
    private By editParticipants = By.xpath("//input[@id='initiatorCanEditAsignees']");
    private By completionRule = By.xpath("//select[@id='parallelStepSatisfactionRule']");
    private By completionRuleTxt = By.xpath("//select[@id='parallelStepSatisfactionRule']//option[text()='All steps completed']");
    private By finalStepOutCome = By.xpath("//input[@id='useFinalReviewer_1']");
    private By stepDuration = By.xpath("//*[contains(@class,'duration')]");
    private By rejectionRule = By.xpath("//select[@id='rejectionRule']");
    private By rejectionRuleTxt = By.xpath("//select[@id='rejectionRule']//option[text()='Continue to next step']");
    private By mainMenuWorkflow = By.xpath("//button[@class='uiButton navBarButton']//div[text()='Workflows']");
    private By subMenuTemplate = By.xpath("//div[@class='navBarPanel-menuSubSection' and contains(.,'Create New')]//div[contains(.,'Template')]");
    private By lowestStepOutcome = By.xpath("//input[@id='useFinalReviewer_2']");
    private By initiatorCanEdit = By.xpath("//input[@id='startAction']");
    private By defaultStatus = By.xpath("//td[text()='Draft']");
    private By duration = By.xpath("//td[@class='wf-flowcell']//input");
    private By templateErrorMsg = By.xpath("//div[contains(text(),'A template with this name already exists. Please use a different template name')]");
    private By stepToContainer = By.xpath("//table[@id='builder_stepto_container']//div[@class='lookup-assignee lookup-user truncated']");
    private By stepToErrorMsg = By.xpath("//div[@id='builder_stepto_list']//div[@class='lookup-error-message']");
    private By stepCcContainer = By.xpath("//table[@id='builder_stepcc_container']//div[@class='lookup-assignee lookup-user truncated']");
    private By stepCcErrorMsg = By.xpath("//div[@id='builder_stepcc_list']//div[@class='lookup-error-message']");
    private By closeBtn = By.xpath("//button[@id='alertPanel-cancel']");
    private By saveDraftToolTip = By.xpath("//button[@title='Save this workflow to draft']");
    private By activateToolTip = By.xpath("//button[@title='Activate this workflow']");
    private By finalTransmittal = By.xpath("//input[@id='finalRecipients_query']");
    private By finalRecipients = By.xpath("//table[@id='finalRecipients_container']//div[@class='lookup-assignee lookup-user truncated']");
    private By finalRecipientErrorMsg = By.xpath("//div[@id='finalRecipients_list']//div[@class='lookup-error-message']");
    private By attributeValues = By.xpath("//select[@multiple='multiple']//option");
    private By lookupErrorMsg = By.xpath("//div[@class='lookup-error-message']");
    Actions act = new Actions(driver);
    Random random = new Random();

    /**
     * Function to navigate to a sub menu from the Aconex home page
     */
    public void navigateAndVerifyPage() {
        commonMethods.waitForElementExplicitly(2000);
        getMenuSubmenu("Workflows", "Create New", "Template");
        commonMethods.waitForElementExplicitly(2000);
        Assert.assertTrue(verifyPageTitle(pageTitle));
    }

    /**
     * Method create workflow template
     *
     * @param attributes of template
     */

    public String createWorkFlowTemplate(String action, String attributes) {
        verifyAndSwitchFrame();
        Map<String, String> table = dataStore.getTable(attributes);
        for (String tableData : table.keySet()) {
            switch (tableData.toLowerCase()) {
                case "template name":
                    Date date = new Date();
                    Random random = new Random();
                    String name = table.get(tableData) + formatter.format(date) + random.nextInt(100);
                    setTemplateName(name);
                    wfTemplate = name;
                    break;
                //Added a case for adding workflow name without appending date to it.
                case "workflow name":
                    wfTemplate = table.get(tableData);
                    setTemplateName(wfTemplate);
                    break;
                case "workflow note":
                    setTemplateNote(table.get(tableData));
                    break;
                case "reason for issue":
                    selectReasonForIssue(table.get(tableData));
                    break;
                case "initiator":
                    commonMethods.getElementInViewAndUp(initiatorStartAction);
                    $(initiatorStartAction).setSelected(Boolean.getBoolean(table.get(tableData)));
                    $(editParticipants).setSelected(Boolean.getBoolean(table.get(tableData)));
                    $(skipInitiatorSteps).setSelected(Boolean.getBoolean(table.get(tableData)));
                    break;
                case "completion rule":
                    selectCompletionRule(table.get(tableData));
                    break;
                case "skipinitiator":
                    selectSkipSteps();
                    break;
                case "editparticipants":
                    selectEditParticipants();
                    break;
                case "startaction":
                    selectStartAction(table.get(tableData));
                    break;
                case "workflow outcome":
                    selectWorkflowOutCome();
                    break;
                case "on rejection":
                    selectRejection(table.get(tableData));
                    break;
                default:
                    if (tableData.toLowerCase().contains("step info"))
                        createStep(table, tableData);
                    break;
//                    String stepInfo = table.get(tableData);
//                    String[] values = stepInfo.split(",");
//                    List<String> stepCountList = splitStepInfo(stepInfo, "step");
//                    int stepCount = 0;
//                    while (stepCount < stepCountList.size()) {
//                        Actions act = new Actions(driver);
//                        getElementInView(stepInitiator);
//                        if (values[0].equalsIgnoreCase("parallel")) {
//                            if (stepCount == 0) {
//                                act.dragAndDrop($(stepInitiator), $(stepDropArea)).build().perform();
//                            } else {
//                                act.dragAndDrop($(stepInitiator), $(parallelStep)).build().perform();
//                            }
//                        } else {
//                            act.dragAndDrop($(stepInitiator), $(stepDropArea)).build().perform();
//                        }
//                        commonMethods.waitForElementExplicitly(500);
//                       // enterStepDetails(table.get(tableData), stepCount);
//                        commonMethods.waitForElementExplicitly(2000);
//                        $(stepOkBtn).click();
//                        stepCount++;
//                    }
            }
        }
        if (action.equalsIgnoreCase("create")) {
            clickActivateBtn();
        } else {
            $(saveToDraft).click();
        }
        return wfTemplate;
    }


    public void createStep(Map<String, String> table, String tableData) {
        String stepData = table.get(tableData);
        String[] multipleTypeStr = stepData.split(";");
        getElementInView(stepInitiator);
        int stepCount = $$(editDetailBtn).size();
        int parallelCount = 0;
        String duration = "0";
        int totalDuration = 0;
        for (String singleTypeStr : multipleTypeStr) {
            String[] typeStepData = singleTypeStr.split(":");
            String type = typeStepData[0];
            String[] stepValues = typeStepData[1].split(",");

            for (String value : stepValues) {
                String[] toStrList;
                String[] ccStrList = new String[0];
                if (table.get(value).contains(";") || table.get(value).contains("to")) {
                    String[] userStr = table.get(value).split(";");
                    toStrList = userStr[0].substring(userStr[0].indexOf(":") + 1).split(",");
                    ccStrList = userStr[1].substring(userStr[1].indexOf(":") + 1).split(",");
                } else {
                    toStrList = table.get(value).split(",");
                }
                if (type.equalsIgnoreCase("parallel")) {
                    if (parallelCount == 0) {
                        act.dragAndDrop($(stepInitiator), $(stepDropArea)).build().perform();
                        int stepDurationCount = $$(stepDuration).size() - 1;
                        new Actions(driver).moveToElement($$(stepDuration).get(stepDurationCount)).click().sendKeys(Keys.BACK_SPACE).sendKeys(duration).build().perform();
                    } else {
                        By xpath = By.xpath("(" + parallelStep + ")[" + stepCount + "]");
                        act.dragAndDrop($(stepInitiator), $(xpath)).build().perform();
                    }
                } else if (type.equalsIgnoreCase("serial")) {
                    act.dragAndDrop($(stepInitiator), $(stepDropArea)).build().perform();
                    int stepDurationCount = $$(stepDuration).size() - 1;
                    new Actions(driver).moveToElement($$(stepDuration).get(stepDurationCount)).click().sendKeys(Keys.BACK_SPACE).sendKeys(duration).build().perform();
                }
                if (table.containsKey(value + "_duration")) {
                    duration = table.get(value + "_duration");
                }
                totalDuration = totalDuration + Integer.valueOf(duration);
                enterStepDetails(toStrList, ccStrList, stepCount);
                commonMethods.waitForElementExplicitly(2000);
                $(stepOkBtn).click();
                parallelCount++;
                stepCount = $$(editDetailBtn).size();
            }
        }


        //List<String> stepCountList = splitStepInfo(stepInfo, "step");
    }

    /**
     * Function to select skip steps
     */
    public void selectSkipSteps() {
        commonMethods.waitForElementExplicitly(500);
        commonMethods.waitForElement(driver, skipInitiatorSteps, 20);
        $(skipInitiatorSteps).click();
    }

    /**
     * Function to select Edit participants
     */
    public void selectEditParticipants() {
        commonMethods.waitForElement(driver, editParticipants, 40);
        $(editParticipants).click();
    }

    /**
     * Method to select the start action option
     *
     * @param value
     */
    public void selectStartAction(String value) {
        if (value.equalsIgnoreCase("true")) {
            $(initiatorStartAction).click();
        } else {
            $(initiatorStartAction).setSelected(false);
        }

    }

    /**
     * Function to select completion rule
     *
     * @param rule
     */
    public void selectCompletionRule(String rule) {
        commonMethods.waitForElement(driver, completionRule, 40);
        $(completionRule).selectOption(rule);
        acceptAlert();
    }

    /**
     * Function to select WF out come
     */
    public void selectWorkflowOutCome() {
        commonMethods.waitForElement(driver, finalStepOutCome, 40);
        $(finalStepOutCome).click();
    }

    /**
     * Function to select rejection rule
     *
     * @param value
     */
    public void selectRejection(String value) {
        commonMethods.waitForElement(driver, rejectionRule, 40);
        $(rejectionRule).selectOption(value);
        acceptAlert();
    }

    /**
     * Method to verify the successful creation of workflow template
     */
    public void verifyTemplateCreated() {
        verifyAndSwitchFrame();
        Assert.assertTrue($(templateCreatedMsg).text().contains("Template activated successfully"));
    }

    /**
     * Method to verify the successful creation of workflow template
     */
    public void verifyTemplateSaved() {
        verifyAndSwitchFrame();
        Assert.assertTrue($(templateCreatedMsg).text().contains("Template saved to draft successfully"));
    }


    /**
     * Method to enter the step details on the workflow template
     */
    public void enterStepDetails(String[] toList, String[] ccList, int stepCount) {

        JavascriptExecutor js = (JavascriptExecutor) driver;
        commonMethods.waitForElementExplicitly(1000);
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        commonMethods.waitForElementExplicitly(800);
        List<WebElement> elements = driver.findElements(editDetailBtn);
        elements.get(stepCount).click();
        $(stepName).clear();
        $(stepName).sendKeys("step" + (stepCount + 1));
        jsonMapOfMap = dataSetup.loadJsonDataToMap(userFilePath);
        $(toParticipant).clear();
        $(ccParticipant).clear();
        for (String userId : toList) {
            userMap = jsonMapOfMap.get(userId);
            String user = userMap.get("full_name").toString();
            $(toParticipant).sendKeys(user);
            $(toParticipant).sendKeys(Keys.ENTER);
            commonMethods.waitForElementExplicitly(4000);
        }
        if (ccList.length != 0) {
            for (String userId : ccList) {
                userMap = jsonMapOfMap.get(userId);
                String user = userMap.get("full_name").toString();
                $(ccParticipant).sendKeys(user);
                $(ccParticipant).sendKeys(Keys.ENTER);
                commonMethods.waitForElementExplicitly(4000);
            }
        }
    }
//
//    /**
//     * Method to enter the step details on the workflow template
//     *
//     * @param stepDetail details of the step
//     */
//    public void enterStepDetails(String stepDetail, int stepCount) {
//        List<String> stepCountList = splitStepInfo(stepDetail, "step");
//        List<String> userList = splitStepInfo(stepDetail, "user");
//        JavascriptExecutor js = (JavascriptExecutor) driver;
//        commonMethods.waitForElementExplicitly(1000);
//        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
//        commonMethods.waitForElementExplicitly(800);
//        List<WebElement> elements = driver.findElements(editDetailBtn);
//        elements.get(stepCount).click();
//        $(stepName).clear();
//        $(stepName).sendKeys(stepCountList.get(stepCount));
//        jsonMapOfMap = dataSetup.loadJsonDataToMap(userFilePath);
//        $(participant).clear();
//        for (String userId:userList) {
//            userMap = jsonMapOfMap.get(userId);
//            String user = userMap.get("full_name").toString();
//            $(participant).sendKeys(user);
//            $(participant).sendKeys(Keys.ENTER);
//            commonMethods.waitForElementExplicitly(500);
//        }
//
//
//    }

    /**
     * Method to enter template name
     */
    public void setTemplateName(String name) {
        $(templateName).clear();
        $(templateName).sendKeys(name);
    }

    /**
     * Method to enter template name for wf template
     */
    public void setTemplateNote(String note) {
        $(workflowNote).clear();
        $(workflowNote).sendKeys(note);
    }

    /**
     * Method to select reason for issue in template creation
     */
    public void selectReasonForIssue(String option) {
        verifyAndSwitchFrame();
        $(reasonForIssue).selectOptionContainingText(option);
    }

    /**
     * Method used when we need to create a workflow template with multiple steps
     *
     * @param stepInfo complete string
     * @param pattern  regex to search
     * @return
     */
    public List<String> splitStepInfo(String stepInfo, String pattern) {
        String[] stepStr = stepInfo.split(",");
        List<String> returnStr = new ArrayList<>();
        for (int count = 0; count < stepStr.length; count++) {
            if (stepStr[count].contains(pattern)) {
                returnStr.add(stepStr[count]);
            }
        }
        return returnStr;
    }

    /**
     * Function to return values for reason for issue
     *
     * @return
     */
    public List<String> getReasonForIssueValues() {
        ArrayList reasonForIssuesValues = new ArrayList();
        List<WebElement> options = driver.findElements(By.xpath("//select[@id='selectedReason']//option"));
        for (int i = 1; i <= options.size() - 1; i++) {
            String optionsText = options.get(i).getText();
            reasonForIssuesValues.add(optionsText);
        }
        return reasonForIssuesValues;

    }

    /**
     * Verify template option
     *
     * @return
     */
    public boolean verifyCreateTemplateOption() {
        commonMethods.waitForElementExplicitly(2000);
        switchToOriginal();
        $(mainMenuWorkflow).click();
        return $(subMenuTemplate).isDisplayed();

    }

    /**
     * Function to verify default page fields
     */
    public void verifyPageFields() {
        commonMethods.waitForElementExplicitly(2000);
        verifyAndSwitchFrame();
        Assert.assertTrue($(defaultStatus).isDisplayed());
        Assert.assertTrue($(activateBtn).isDisplayed());
        Assert.assertTrue($(saveToDraft).isDisplayed());
        Assert.assertTrue($(lowestStepOutcome).isSelected());
        Assert.assertFalse($(initiatorCanEdit).isSelected());
        Assert.assertFalse($(editParticipants).isSelected());
        Assert.assertFalse($(skipInitiatorSteps).isSelected());
        Assert.assertTrue($(completionRuleTxt).isDisplayed());
        Assert.assertTrue($(rejectionRuleTxt).isDisplayed());

    }

    /**
     * Function to validate Max characters  in field
     *
     * @param maxValue
     */
    public void validateDurationValue(String maxValue) {
        verifyAndSwitchFrame();
        $(defaultStatus).click();
        getElementInView(stepInitiator);
        act.dragAndDrop($(stepInitiator), $(stepDropArea)).build().perform();
        commonMethods.waitForElementExplicitly(1000);
        $(duration).sendKeys(String.valueOf(random.nextInt(Integer.parseInt(maxValue))));
        $(duration).sendKeys(Keys.ENTER);
    }

    /**
     * Function to verify wf note alert
     *
     * @param maxValue
     */
    public void verifyWorkflowNoteAlert(String maxValue) {
        $(workflowNote).sendKeys(commonMethods.getRandomString(Integer.parseInt(maxValue)));
        $(workflowNote).sendKeys(Keys.ENTER);
    }

    /**
     * Function to verify template max value
     *
     * @param maxValue
     */
    public void verifyTemplateMaxValue(String maxValue) {
        Assert.assertTrue($(templateName).getAttribute("maxlength").equalsIgnoreCase(maxValue));
        $(templateName).sendKeys(commonMethods.getRandomString(Integer.parseInt(maxValue)));
        $(templateName).sendKeys(Keys.ENTER);
    }

    /**
     * Function to click save to drafts
     */
    public void clickSaveDraft() {
        commonMethods.waitForElement(driver, saveToDraft, 40);
        $(saveToDraft).click();
    }

    /**
     * click on activate button
     */
    public void clickActivateBtn() {
        commonMethods.waitForElement(driver, activateBtn, 40);
        $(activateBtn).click();
    }

    /**
     * Add step name
     *
     * @param name
     */
    public void addStepName(String name) {
        commonMethods.waitForElement(driver, stepName, 40);
        $(stepName).clear();
        $(stepName).sendKeys(name);
        $(stepOkBtn).click();
    }

    /**
     * Function verify template error msg for same name
     */
    public boolean validateErrorMsg() {
        commonMethods.waitForElement(driver, templateErrorMsg, 40);
        return $(templateErrorMsg).isDisplayed();
    }

    /**
     * Function to save template to drafts
     *
     * @param name
     */
    public void saveTemplate(String name) {
        commonMethods.waitForElement(driver, templateName, 40);
        $(templateName).sendKeys(name);
        $(saveToDraft).click();
    }

    /**
     * Function to add step
     */
    public void addStep() {
        verifyAndSwitchFrame();
        getElementInView(stepInitiator);
        act.dragAndDrop($(stepInitiator), $(stepDropArea)).build().perform();
        commonMethods.waitForElementExplicitly(1000);
    }

    /**
     * click edit detail button
     */
    public void clickEditDetailBtn() {
        $(editDetailBtn).click();
    }

    /**
     * Enter values to participant and CC
     *
     * @param search
     * @param user
     */
    public void enterUserQuery(String search, String user) {
        if (search.equalsIgnoreCase("Participants")) {
            $(toParticipant).clear();
            $(toParticipant).sendKeys(user);
            $(toParticipant).sendKeys(Keys.ENTER);
            commonMethods.waitForElementExplicitly(2000);
        } else {
            $(ccParticipant).clear();
            $(ccParticipant).sendKeys(user);
            $(ccParticipant).sendKeys(Keys.ENTER);
            commonMethods.waitForElementExplicitly(2000);
        }
    }

    /**
     * Function to validate search
     *
     * @param user
     * @param type
     */
    public void validateUserSearch(String user, String search, String type) {
        commonMethods.waitForElementExplicitly(2000);
        if (search.equalsIgnoreCase("Participants")) {
            if (type.equals("valid"))
                Assert.assertEquals($(stepToContainer).getText(), commonMethods.getUserData(user, "name") + " - " + commonMethods.getUserData(user, "organisation"));
            else
                Assert.assertEquals($(stepToErrorMsg).getText(), "No match found for " + commonMethods.getUserName(user) + ". Try a less specific query or remove");
        } else {
            if (type.equals("valid"))
                Assert.assertEquals($(stepCcContainer).getText(), commonMethods.getUserData(user, "name") + " - " + commonMethods.getUserData(user, "organisation"));
            else
                Assert.assertEquals($(stepCcErrorMsg).getText(), "No match found for " + commonMethods.getUserName(user) + ". Try a less specific query or remove");

        }
    }

    /**
     * verify alert msg
     *
     * @param msg
     * @return
     */
    public boolean verifyErrorMsg(String msg) {
        commonMethods.waitForElementExplicitly(1000);
        return $(By.xpath("//div[text()='" + msg + "']")).isDisplayed();
    }

    /**
     * click on close button
     */
    public void clickCloseBtn() {
        $(closeBtn).click();
    }

    /**
     * Function to verify tool tips for buttons
     */
    public void verifyTooTips() {
        Assert.assertTrue($(saveDraftToolTip).isDisplayed());
        Assert.assertTrue($(activateToolTip).isDisplayed());
    }

    /**
     * verify reason for issue values
     *
     * @param values
     * @return
     */
    public boolean verifyReasonForIssue(List<String> values) {
        List<String> newValues = new LinkedList<String>();
        Select sc = new Select($(reasonForIssue));
        List<WebElement> issueValues = sc.getOptions();
        for (int i = 1; i < issueValues.size(); i++) {
            String txt = issueValues.get(i).getText();
            newValues.add(txt);
        }
        return values.equals(newValues);
    }

    /**
     * search for user in final transmittal cc list
     *
     * @param full_name
     */
    public void searchUser(String full_name) {
        $(finalTransmittal).clear();
        $(finalTransmittal).sendKeys(full_name);
        $(finalTransmittal).sendKeys(Keys.ENTER);
        commonMethods.waitForElementExplicitly(2000);
    }

    /**
     * Function to final Recipients user search
     *
     * @param user
     * @param type
     */
    public void validateAdditionalCcUsers(String user, String type) {
        commonMethods.waitForElementExplicitly(2000);
        if (type.equals("valid"))
            Assert.assertEquals($(finalRecipients).getText(), commonMethods.getUserData(user, "name") + " - " + commonMethods.getUserData(user, "organisation"));
        else
            Assert.assertEquals($(finalRecipientErrorMsg).getText(), "No match found for " + commonMethods.getUserName(user) + ". Try a less specific query or remove");
    }

    /**
     * Function to verify attribute values
     *
     * @param values
     * @return
     */
    public boolean verifyAttributeValues(List<String> values, int attributeValue) {
        List<String> newValues = new LinkedList<String>();
        commonMethods.waitForElementExplicitly(1000);
        $(By.xpath("//div[@id='attribute" + attributeValue + "']")).click();
        commonMethods.waitForElement(driver, attributeValues, 20);
        List<WebElement> issueValues = driver.findElements(attributeValues);
        for (int i = 0; i < issueValues.size(); i++) {
            String txt = issueValues.get(i).getText();
            newValues.add(txt);
        }
        commonMethods.waitForElementExplicitly(2000);
        $(By.xpath("//button[@id='attribute" + attributeValue + "_panel-commit']")).click();
        return values.equals(newValues);
    }

    /**
     * Method to enter hidden user in step
     *
     * @param hiddenUserId
     */
    public void enterUser(String hiddenUserId) {
        String[] toList = new String[]{hiddenUserId};
        Actions act = new Actions(driver);
        getElementInView(stepInitiator);
        act.dragAndDrop($(stepInitiator), $(stepDropArea)).build().perform();
        enterStepDetails(toList, toList, 0);

    }

    /**
     * Method to return the error message inside the step
     */
    public String returnErrorMessage() {
        return $(lookupErrorMsg).getText();
    }

}
